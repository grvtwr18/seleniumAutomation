# TWFramework #

## Please review prior to contributing:##

### Coding standards ###
[https://google.github.io/styleguide/javaguide.html](https://google.github.io/styleguide/javaguide.html)
* exceptions: we have a base indent of 4 (continuation 8), and max line length of soft 120, hard 180.

There are two places you can import xml in IntelliJ IDEA to check and reformat your code.

#### Editor configuration (as of version 2017.1) ####
* go to Settings (Ctrl+Alt+S; on Windows/Linux) or Preferences (Mac)
* go to Editor > Code Style
* import a Scheme by clicking the gear next to the dropdown and choose Import Scheme > IntelliJ IDEA code style XML
* import the XML at root Importable-Google-TW-IntelliJ-code_style.xml; name the scheme whatever you want.

This allows you to use the "Reformat Code" and enable some automatic reformatting while you work (e.g. "Optimize
imports on the fly").

#### CheckStyle configuration (as of version 2017.1) ####
* install the CheckStyle-IDEA plugin
* go to Settings (Ctrl+Alt+S; on Windows/Linux) or Preferences (Mac)
* go to Other Settings > Checkstyle
* click the + icon next to the "Configuration File" pane
* With whatever description you want, select "Use a local Checkstyle file" and browse to
CheckStyle/CheckStyle-TW-Google_Checks.xml
* click Next and Finish
* check the box next to your new Configuration File to set is as "active"

This allows you to use CheckStyle as a code inspection. You may need to configure your Inspections (see below).

#### Checkstyle use ####

Initial:
* select Analyze > Inspect Code
* click the "..." next to "Inspection Profile" to look at the inspections configured, and confirm the CheckStyle
inspection is checked as enabled (should be by default).

While working:
* the CheckStyle pane should be on the default bottom pane, next to the "Terminal" option
* if you open it, you'll have the option to run your active configuration - or any stored configuration - against a
file or files you're working on, using the buttons on the left.

More on [enforcing coding standards automatically](https://sterlingts.atlassian.net/wiki/display/SDET/CheckStyle%2C+Enforcing+coding+standards+automatically).


### Patterns and practices for test code ###
[https://sterlingts.atlassian.net/wiki/display/SDET/Patterns+and+practices+for+test+code](https://sterlingts.atlassian.net/wiki/display/SDET/Patterns+and+practices+for+test+code)

### Need help getting started? ###
* [https://sterlingts.atlassian.net/wiki/display/SDET/How+to+structure+your+IntelliJ+Idea+Project](https://sterlingts.atlassian.net/wiki/display/SDET/How+to+structure+your+IntelliJ+Idea+Project)
* [https://sterlingts.atlassian.net/wiki/display/SDET/Maven+in+Intellij+Idea](https://sterlingts.atlassian.net/wiki/display/SDET/Maven+in+Intellij+Idea)
    * You will need to run Maven at least once