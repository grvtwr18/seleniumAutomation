package adminportal.manageuberforms;

import DataBase.DbReader;
import Sites.AdminConsole.AdminHomePage;
import Sites.AdminConsole.CustomerSupport.ScreeningSupport.UberForms.ManageUberformsPage;
import Sites.AdminConsole.Login.ExistingAccountLoginPage;
import TWFramework.SeleniumTest;
import org.testng.annotations.Test;
import screening.TestData;

import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;

/**
 * Created by WBoyde on 3/7/2018.
 */
public class CloneUberFormTests extends SeleniumTest {

    @Test(groups = {"P3"})
    public void basicCloneUberformTest() throws UnknownHostException {
        // define test account to use
        // TODO perhaps augment test to create new account, uberforms specific for test
        String emailAddress = "clone-test1@donotuse.com";

        logger.info("Login to the ADMIN PORTAL");
        ExistingAccountLoginPage.navigateToAndSignInAs(TestData.Common.ADMIN_USER, TestData.Common.ADMIN_USER_PASSWORD);

	}
}