package Products.Packages.Transactions;

import Products.Enums.PackageEnums.ProductGroups.OtherProductGroup;
import Products.Enums.PackageEnums.TransactionType;
import Products.Packages.Package;
import Sites.AdminConsole.BuildPackagePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Page object that represents the options that become available when "Demo Units" is selected as the
 * transaction type in package construction.
 * @author eelefson
 */
public class DemoUnits implements Package {
	@SuppressWarnings("unused")

	private List<OtherProductGroup> otherProductGroupList;
	
	@FindBy(how = How.NAME, using = "package[]")
	private WebElement productGroupDropDown;
	
	/**
	 * Constructs a new Demo Units package page object.
	 */
	public DemoUnits() {

	}
	
	/**
	 * Selects the specified other product group from the package's "Product Group" drop down menu.
	 * @param productGroup The other product group for the package
	 */
	public void selectOtherProductGroup(OtherProductGroup productGroup) {
		Select productGroupSelect = new Select(productGroupDropDown);
		productGroupSelect.selectByVisibleText(productGroup.toString());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void createPackage(BuildPackagePage buildPackagePage) {
		buildPackagePage.selectTransactionType(TransactionType.DEMO_UNITS);
		
		for(OtherProductGroup otherProductGroup : otherProductGroupList) {
			
			selectOtherProductGroup(otherProductGroup);
			
			buildPackagePage.clickRecalculateAndCheckButton();
			buildPackagePage.clickConfirmAndVerifyPackageButton();
			buildPackagePage.clickBuildPackageButton().clickAddAnotherPackageLink();
		}
	}
}
