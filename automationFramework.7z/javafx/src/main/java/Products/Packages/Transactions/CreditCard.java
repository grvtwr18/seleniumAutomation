package Products.Packages.Transactions;

import Products.Enums.PackageEnums.Classification;
import Products.Enums.PackageEnums.MainReferID;
import Products.Enums.PackageEnums.ProductGroups.OtherProductGroup;
import Products.Enums.PackageEnums.TransactionType;
import Products.Packages.Package;
import Sites.AdminConsole.BuildPackagePage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Page object that represents the options that become available when "Credit Card" is selected as the
 * transaction type in package construction.
 * @author eelefson
 */
public class CreditCard implements Package {

	private Classification classification;
	private String mainReferIdString;
	private MainReferID secondaryReferIdEnum;
	private String duration;
	private List<OtherProductGroup> otherProductGroupList;
	
	@FindBy(how = How.NAME, using = "Classification")
	private WebElement classificationDropDown;
	
	@FindBy(how = How.NAME, using = "referrer")
	private WebElement mainReferIdElement;
	
	@FindBy(how = How.NAME, using = "salesrefer")
	private WebElement secondaryReferIdElement;
	
	@FindBy(how = How.NAME, using = "duration")
	private WebElement durationBox;
	
	@FindBy(how = How.NAME, using = "package[]")
	private WebElement productGroupDropDown;
	
	/**
	 * Constructs a new Credit Card package page object.
	 */
	public CreditCard() {

	}
	
	/**
	 * Selects the specified classification from the package's "Classification" drop down menu.
	 * @param classification The classification for the package
	 * @return A new build package page object
	 */
	public BuildPackagePage selectClassification(Classification classification) {
		Select classificationSelect = new Select(classificationDropDown);
		classificationSelect.selectByVisibleText(classification.toString());
		return PageFactory.initElements(Driver.getDriver(), BuildPackagePage.class);
	}
	
	/**
	 * Types the specified main refer ID into the package's "Main Refer ID" text box.
	 * @param mainReferId The main refer ID for the package
	 */
	public void typeMainReferId(String mainReferId) {
		SeleniumTest.clearAndSetText(mainReferIdElement, mainReferId);
	}
	
	/**
	 * Selects the specified secondary refer ID from the package's "Secondary Refer ID" drop down menu.
	 * @param secondaryReferId The secondary refer ID for the package
	 */
	public void selectSecondaryReferId(MainReferID secondaryReferId) {
		Select secondaryReferIdSelect = new Select(secondaryReferIdElement);
		secondaryReferIdSelect.selectByVisibleText(secondaryReferId.toString());
	}
	
	/**
	 * Types the specified duration into the package's "Duration" text box.
	 * @param duration The duration for the package
	 */
	public void typeDuration(String duration) {
		SeleniumTest.clearAndSetText(durationBox, duration);
	}
	
	/**
	 * Selects the specified other product group from the package's "Product Group" drop down menu.
	 * @param productGroup The other product group for the package
	 */
	public void selectOtherProductGroup(OtherProductGroup productGroup) {
		Select productGroupSelect = new Select(productGroupDropDown);
		productGroupSelect.selectByVisibleText(productGroup.toString());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void createPackage(BuildPackagePage buildPackagePage) {
		buildPackagePage.selectTransactionType(TransactionType.CREDIT_CARD);
		
		selectClassification(classification);
		
		typeMainReferId(mainReferIdString);
		
		selectSecondaryReferId(secondaryReferIdEnum);
		
		typeDuration(duration);
		
		for(OtherProductGroup otherProductGroup : otherProductGroupList) {
			
			selectOtherProductGroup(otherProductGroup);
			
			buildPackagePage.clickRecalculateAndCheckButton();
			buildPackagePage.clickConfirmAndVerifyPackageButton();
			buildPackagePage.clickBuildPackageButton().clickAddAnotherPackageLink();
		}
	}
}
