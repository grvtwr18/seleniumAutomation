package Products.Packages.Transactions;

import Products.Enums.PackageEnums.Classification;
import Products.Enums.PackageEnums.MainReferID;
import Products.Enums.PackageEnums.ProductGroups.InvoiceBillingProductGroup;
import Products.Enums.PackageEnums.TransactionType;
import Products.Packages.Package;
import Sites.AdminConsole.BuildPackagePage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Page object that represents the options that become available when "Invoice Billing" is selected as the
 * transaction type in package construction.
 * @author eelefson
 */
public class InvoiceBilling implements Package {

	private Classification classification;
	private MainReferID mainReferIdEnum;
	private String companyName;
	private List<InvoiceBillingProductGroup> invoiceBillingProductGroupList;
	
	@FindBy(how = How.NAME, using = "Classification")
	private WebElement classificationDropDown;
	
	@FindBy(how = How.NAME, using = "referrer")
	private WebElement mainReferIdElement;
	
	@FindBy(how = How.NAME, using = "companyname")
	private WebElement companyNameBox;
	
	@FindBy(how = How.NAME, using = "package[]")
	private WebElement productGroupDropDown;

	/**
	 * Constructs a new Invoice Billing package page object.
	 */
	public InvoiceBilling() {

	}
	
	/**
	 * Selects the specified classification from the package's "Classification" drop down menu.
	 * @param classification The classification for the package
	 * @return A new build package page object
	 */
	public BuildPackagePage selectClassification(Classification classification) {
		Select classificationSelect = new Select(classificationDropDown);
		classificationSelect.selectByVisibleText(classification.toString());
		return PageFactory.initElements(Driver.getDriver(), BuildPackagePage.class);
	}
	
	/**
	 * Selects the specified main refer ID from the package's "Main Refer ID" drop down menu.
	 * @param mainReferId The main refer ID for the package
	 */
	public void selectMainReferId(MainReferID mainReferId) {
		Select mainReferIdSelect = new Select(mainReferIdElement);
		mainReferIdSelect.selectByVisibleText(mainReferId.toString());
	}
	
	/**
	 * Types the specified company name into the package's "Company Name" text box.
	 * @param companyName The company name for the package
	 */
	public void typeCompanyName(String companyName) {
		SeleniumTest.clearAndSetText(companyNameBox, companyName);
	}
	
	/**
	 * Selects the specified invoice billing product group from the package's "Product Group" drop down menu.
	 * @param productGroup The invoice billing product group for the package
	 */
	public void selectInvoiceBillingProductGroup(InvoiceBillingProductGroup productGroup) {
		Select productGroupSelect = new Select(productGroupDropDown);
		productGroupSelect.selectByVisibleText(productGroup.toString());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void createPackage(BuildPackagePage buildPackagePage) {
		buildPackagePage.selectTransactionType(TransactionType.INVOICE_BILLING);
		
		selectClassification(classification);
		
		selectMainReferId(mainReferIdEnum);
		
		typeCompanyName(companyName);
		
		for(InvoiceBillingProductGroup invoiceBillingProductGroup : invoiceBillingProductGroupList) {
			
			selectInvoiceBillingProductGroup(invoiceBillingProductGroup);
			
			buildPackagePage.clickRecalculateAndCheckButton();
			buildPackagePage.clickConfirmAndVerifyPackageButton();
			buildPackagePage.clickBuildPackageButton().clickAddAnotherPackageLink();
		}
	}
}
