package Products.Packages.Transactions;

import Products.Enums.PackageEnums.Classification;
import Products.Enums.PackageEnums.MainReferID;
import Products.Enums.PackageEnums.ProductGroups.QuoteProductGroup;
import Products.Enums.PackageEnums.QuoteTransactionType;
import Products.Enums.PackageEnums.TransactionType;
import Products.Packages.Package;
import Sites.AdminConsole.BuildPackagePage;
import Sites.AdminConsole.SuccessfulPackageAndApproveQuotePage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Page object that represents the options that become available when "Quote" is selected as the
 * transaction type in package construction.
 * @author eelefson
 */
public class Quote implements Package {

	private QuoteTransactionType quoteTransactionType;
	private Classification classification;
	private MainReferID mainReferIdEnum;
	private String duration;
	private boolean priceOverride;
	private boolean commissionable;
	private String companyName;
	private List<QuoteProductGroup> quoteProductGroupList;
	
	@FindBy(how = How.NAME, using = "QuoteTransactionType")
	private WebElement quoteTransactionTypeDropDown;
	
	@FindBy(how = How.NAME, using = "Classification")
	private WebElement classificationDropDown;
	
	@FindBy(how = How.NAME, using = "referrer")
	private WebElement mainReferIdElement;
	
	@FindBy(how = How.NAME, using = "duration")
	private WebElement durationBox;
	
	@FindBy(how = How.NAME, using = "PriceOverride")
	private WebElement priceOverrideCheckBox;
	
	@FindBy(how = How.NAME, using = "Commissionable")
	private WebElement commissionableCheckBox;
	
	@FindBy(how = How.NAME, using = "companyname")
	private WebElement companyNameBox;
	
	@FindBy(how = How.NAME, using = "package[]")
	private WebElement productGroupDropDown;
	
	/**
	 * Constructs a new Quote package page object.
	 */
	public Quote() {

	}
	
	/**
	 * Selects the specified quote transaction type from the package's "Quote Transaction Type" drop down menu.
	 * @param quoteTransactionType The quote transaction type for the package
	 * @return A new build package page object
	 */
	public BuildPackagePage selectQuoteTransactionType(QuoteTransactionType quoteTransactionType) {
		Select quoteTransactionTypeSelect = new Select(quoteTransactionTypeDropDown);
		quoteTransactionTypeSelect.selectByVisibleText(quoteTransactionType.toString());
		return PageFactory.initElements(Driver.getDriver(), BuildPackagePage.class);
	}
	
	/**
	 * Selects the specified classification from the package's "Classification" drop down menu.
	 * @param classification The classification for the package
	 * @return A new build package page object
	 */
	public BuildPackagePage selectClassification(Classification classification) {
		Select classificationSelect = new Select(classificationDropDown);
		classificationSelect.selectByVisibleText(classification.toString());
		return PageFactory.initElements(Driver.getDriver(), BuildPackagePage.class);
	}
	
	/**
	 * Selects the specified main refer ID from the package's "Main Refer ID" drop down menu.
	 * @param mainReferId The main refer ID for the package
	 */
	public void selectMainReferId(MainReferID mainReferId) {
		Select mainReferIdSelect = new Select(mainReferIdElement);
		mainReferIdSelect.selectByVisibleText(mainReferId.toString());
	}
	
	/**
	 * Types the specified duration into the package's "Duration" text box.
	 * @param duration The duration for the package
	 */
	public void typeDuration(String duration) {
		SeleniumTest.clearAndSetText(durationBox, duration);
	}
	
	/**
	 * Clicks the price override check box.
	 */
	public void clickPriceOverrideCheckBox() {
		priceOverrideCheckBox.click();
	}
	
	/**
	 * Clicks the commissionable check box.
	 */
	public void clickCommissionableCheckBox() {
		commissionableCheckBox.click();
	}
	
	/**
	 * Types the specified company name into the package's "Company Name" text box.
	 * @param companyName The company name for the package
	 */
	public void typeCompanyName(String companyName) {
		SeleniumTest.clearAndSetText(companyNameBox, companyName);
	}
	
	/**
	 * Selects the specified quote product group from the package's "Product Group" drop down menu.
	 * @param productGroup The quote product group for the package
	 */
	public void selectQuoteProductGroup(QuoteProductGroup productGroup) {
		Select productGroupSelect = new Select(productGroupDropDown);
		productGroupSelect.selectByVisibleText(productGroup.toString());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void createPackage(BuildPackagePage buildPackagePage) {
		buildPackagePage.selectTransactionType(TransactionType.QUOTE);
		
		selectQuoteTransactionType(quoteTransactionType);
		
		selectClassification(classification);
		
		selectMainReferId(mainReferIdEnum);
		
		typeDuration(duration);
		
		if(priceOverride) {
			clickPriceOverrideCheckBox();
		}
		
		if(commissionable) {
			clickCommissionableCheckBox();
		}
		
		typeCompanyName(companyName);
		
		for(QuoteProductGroup quoteProductGroup : quoteProductGroupList) {
			
			selectQuoteProductGroup(quoteProductGroup);
			
			buildPackagePage.clickRecalculateAndCheckButton();
		
			buildPackagePage.clickConfirmAndVerifyPackageButton();
			
			SuccessfulPackageAndApproveQuotePage success = buildPackagePage.clickBuildPackageButton();
			
			success.clickAddAnotherPackageLink();
		}
	}
}
