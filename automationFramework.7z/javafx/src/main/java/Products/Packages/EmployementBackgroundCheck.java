package Products.Packages;

import Sites.TalentWiseDashboard.CustomerDashboardPages;
import Sites.TalentWiseDashboard.CustomerLoginPage;
import Sites.TalentWiseDashboard.ProductFormPages.verifications.EducationVerificationLaunchPage;
import Sites.TalentWiseDashboard.Search.Screen.ScreeningPage;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class EmployementBackgroundCheck {

    @FindBy(how = How.XPATH, using = "//a[contains(normalize-space(),'Fill with test')]")
    private static WebElement lnkFillTestData;

    @FindBy(how = How.XPATH, using = "//div[@id='uberform']//input[@type='checkbox'][contains(@name,'agree')]")
    private static WebElement chkAgreeUberFormAddData;

    @FindBy(how = How.XPATH, using = "//div[@class='stripe buttonstripe']//input[@type='submit']")
    private static WebElement btnContinueFillAddress;

    @FindBy(how = How.XPATH, using = "//form[@id='UberSearch']//div[@class='stripe buttonstripe']//input")
    private static WebElement btnContinueOptionalSearchUberForm;

    @FindBy(how = How.XPATH, using = ".//*[@id='pageContainer']//*[@id='_searchstring']")
    private static WebElement btnProceedToCheckOut;

    @FindBy(how = How.ID, using = "btnProceed to Checkout")
    private static WebElement lnkEnterCreditCard;

    @FindBy(how = How.XPATH, using = "//div[a[@class='searchAddRemoveLink dbLinkNoUnderline']]//preceding-sibling::h3[.='Payment Information']")
    private static WebElement lnkEditCC;

    @FindBy(how = How.ID, using = "submitAccount")
    private static WebElement btnUpdateSetting;

    @FindBy(how = How.XPATH, using = "//span[.='Credit Card']")
    private static WebElement lnkCreditCard;

    @FindBy(how = How.XPATH, using = "//iframe[contains(@name,'_privateStripeFrame5')]")
    private static WebElement ifrmCredeitCard;

    @FindBy(how = How.XPATH, using = "//input[@name='cardnumber']")
    private static WebElement inpCreditCardNumber;

    @FindBy(how = How.CLASS_NAME, using = "__PrivateStripeElement-input")
    private static WebElement inpCCNumber;

    @FindBy(how = How.XPATH, using = "//input[@name='exp-date']")
    private static WebElement inpexpdate;

    @FindBy(how = How.XPATH, using = "//input[@name='cvc']")
    private static WebElement inpcvc;

    @FindBy(how = How.ID, using = "stripeSave-input")
    private static WebElement btnSave;

    @FindBy(how = How.XPATH, using = "//button[.='Save']")
    private static WebElement btnSaveForm;

    @FindBy(how = How.XPATH, using = "(//div[.='You have successfully updated your payment information.'])[1]")
    private static WebElement divVerify;

    @FindBy(how = How.XPATH, using = "//div[.='Your Transaction Was Successful']")
    private static WebElement divVerifyTransSuccessfull;

    @FindBy(how = How.XPATH, using = "//input[@value='Confirm Purchase']")
    private static WebElement btnConfirmPurchase;

    static {
        PageFactory.initElements(Driver.getDriver(), EmployementBackgroundCheck.class);
    }

    public Boolean fillTestData() {
        JavaScriptHelper.VisibilityCheckAndClick(lnkFillTestData);
        EducationVerificationLaunchPage objEducationVerificationLaunchPage = new EducationVerificationLaunchPage();
        objEducationVerificationLaunchPage.setEmployeeNameEducationVerificationPage("Test");
        objEducationVerificationLaunchPage.setPhoneNumbersEducationVerificationPage("8908908908");
        objEducationVerificationLaunchPage.setCityEducationVerificationPage("HuntsVille");
        objEducationVerificationLaunchPage.setJobTitleEducationVerificationPage("Job");

        objEducationVerificationLaunchPage.selectROF("Still Employed");
        objEducationVerificationLaunchPage.selectState("Alabama");
        objEducationVerificationLaunchPage.selectROFYear("2010");
        objEducationVerificationLaunchPage.selectROFDOBMonth("Jan");
        objEducationVerificationLaunchPage.chkSameAsCurrentSchool();
        SeleniumTest.check(chkAgreeUberFormAddData);
        JavaScriptHelper.VisibilityCheckAndClick(btnContinueFillAddress);
        objEducationVerificationLaunchPage.ClickConfirmBtn();
        return objEducationVerificationLaunchPage.verifySalesTax("19");
    }


    public Boolean PurchaseEmployementBackgroundVerififcation() {
        JavaScriptHelper.VisibilityCheckAndClick(lnkFillTestData);
        EducationVerificationLaunchPage objEducationVerificationLaunchPage = new EducationVerificationLaunchPage();
        objEducationVerificationLaunchPage.setEmployeeNameEducationVerificationPage("Test");
        objEducationVerificationLaunchPage.setPhoneNumbersEducationVerificationPage("8908908908");
        objEducationVerificationLaunchPage.setCityEducationVerificationPage("HuntsVille");
        objEducationVerificationLaunchPage.setJobTitleEducationVerificationPage("Job");

        objEducationVerificationLaunchPage.selectROF("Still Employed");
        objEducationVerificationLaunchPage.selectState("Alabama");
        objEducationVerificationLaunchPage.selectROFYear("2010");
        objEducationVerificationLaunchPage.selectROFDOBMonth("Jan");
        objEducationVerificationLaunchPage.chkSameAsCurrentSchool();
        SeleniumTest.check(chkAgreeUberFormAddData);
        JavaScriptHelper.VisibilityCheckAndClick(btnContinueFillAddress);
        objEducationVerificationLaunchPage.ClickConfirmBtn();
        return objEducationVerificationLaunchPage.verifyPublicPurchaseConfirm();
    }
}
