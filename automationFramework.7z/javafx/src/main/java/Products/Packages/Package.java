package Products.Packages;

import Sites.AdminConsole.BuildPackagePage;

/**
 * Interface used for all package types.
 * @author eelefson
 */
public interface Package {
	
	/**
	 * Creates a package on the build package page.
	 * @param buildPackagePage The page object representing the build package page
	 */
	public void createPackage(BuildPackagePage buildPackagePage);
}
