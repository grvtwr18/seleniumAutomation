package Products.Enums.UberFormEnums;

/**
 * Stores and enumerates the inheritance options used in uber form construction.
 * @author eelefson
 */
public enum Inheritance {
	INHERIT_NONE("inherit_none"), INHERIT_ALL("inherit_all"), INHERIT_SOME("inherit_some");
	
	private String name;
	
	Inheritance(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the enum associated with the given string.
	 * @param inheritance The string to be searched for
	 * @return The enum that represents the given string (if it exists)
	 */
	public static Inheritance getInheritance(String inheritance) {
		for (Inheritance i : Inheritance.values()) {
			if(i.toString().equals(inheritance)) {
				return i;
			}
		}
		throw new IllegalArgumentException("No constant with text " + inheritance + " found");
	}
}
