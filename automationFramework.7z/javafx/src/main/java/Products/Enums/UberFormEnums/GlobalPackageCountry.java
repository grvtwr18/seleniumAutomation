package Products.Enums.UberFormEnums;

/**
 * Stores and enumerates the global package countries used in uber form construction.
 * @author eelefson
 */
public enum GlobalPackageCountry {
	NO_SPECIFIC_COUNTRY_USE_DEFAULTS("No Specific Country (Use Defaults)"), ARGENTINA("Argentina"),
	BRAZIL("Brazil"), CHILE("Chile"), COLOMBIA("Colombia"), COSTA_RICA("Costa Rica"),
	ECUADOR("Ecuador"), MEXICO("Mexico"), PANAMA("Panama"), PERU("Peru"), VENEZUELA("Venezuela");
	
	private String name;
	
	GlobalPackageCountry(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the enum associated with the given string.
	 * @param globalPackageCountry The string to be searched for
	 * @return The enum that represents the given string (if it exists)
	 */
	public static GlobalPackageCountry getGlobalPackageCountry(String globalPackageCountry) {
		for (GlobalPackageCountry gpc : GlobalPackageCountry.values()) {
			if(gpc.toString().equals(globalPackageCountry)) {
				return gpc;
			}
		}
		throw new IllegalArgumentException("No constant with text " + globalPackageCountry + " found");
	}
}
