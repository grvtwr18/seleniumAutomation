package Products.Enums.UberFormEnums;

/**
 * Stores and enumerates the form types used in uber form construction.
 * @author eelefson
 */
public enum FormType {
	STANDARD_SCREENING_FORM_CUSTOMER_FACING("Standard Screening Form (Customer-Facing)"),
	VERIFY_MULTI_STATE_HIT_ADMIN_FACING("Verify Multi-State Hit (Admin-Facing)"),
	ONBOARDING_KMS_CUSTOMER_FACING("Onboarding - KMS (Customer-Facing)"),
	CDLIS_DMV_SEARCH_ADMIN_FACING("CDLIS DMV Search (Admin-Facing)"),
	PHYSICAL_PRODUCT_CUSTOMER_FACING("Physical Product (Customer-Facing)"),
	STAND_ALONE_ADVERSE_ACTION_CUSTOMER_FACING("Stand-Alone Adverse Action (Customer-Facing)"),
	ONBOARDING_IN_HOUSE_CUSTOMER_FACING("Onboarding - In-House (Customer-Facing)"),
	QUESTIONNAIRE_CUSTOMER_FACING("Questionnaire (Customer-Facing)"),
	RANDOM_DRUG_SCREENING_CUSTOMER_FACING("Random Drug Screening (Customer-Facing)"),
	TAX_CREDITS_CUSTOMER_FACING("Tax Credits (Customer-Facing)");
	
	private String name;
	
	FormType(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the enum associated with the given string.
	 * @param formType The string to be searched for
	 * @return The enum that represents the given string (if it exists)
	 */
	public static FormType getFormType(String formType) {
		for (FormType ft : FormType.values()) {
			if(ft.toString().equals(formType)) {
				return ft;
			}
		}
		throw new IllegalArgumentException("No constant with text " + formType + " found");
	}
}
