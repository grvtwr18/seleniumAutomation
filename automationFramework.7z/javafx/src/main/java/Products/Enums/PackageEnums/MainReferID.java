package Products.Enums.PackageEnums;

/**
 * Stores and enumerates the main refer IDs used in package construction.
 * @author eelefson
 */
public enum MainReferID {
	SELECT_A_REFERRER("SELECT A REFERRER"), INTELIUS_SALES("2146 (INTELIUS SALES)");
	
	private String name;
	
	MainReferID(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the enum associated with the given string.
	 * @param mainReferID The string to be searched for
	 * @return The enum that represents the given string (if it exists)
	 */
	public static MainReferID getMainReferID(String mainReferID) {
		for (MainReferID mri : MainReferID.values()) {
			if(mri.toString().equals(mainReferID)) {
				return mri;
			}
		}
		throw new IllegalArgumentException("No constant with text " + mainReferID + " found");
	}
}
