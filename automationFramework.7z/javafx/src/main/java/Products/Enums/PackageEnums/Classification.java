package Products.Enums.PackageEnums;

/**
 * Stores and enumerates the classifications used in package construction.
 * @author eelefson
 */
public enum Classification {
	BATCH_UPLOAD("BATCH UPLOAD"), OTHERS("OTHERS"), TENANT_SCREENING("TENANT SCREENING"),
	EMPLOYMENT_SCREENING("EMPLOYMENT SCREENING"), LIST_GENERATION("LIST GENERATION");
	
	private String name;
	
	Classification(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the enum associated with the given string.
	 * @param classification The string to be searched for
	 * @return The enum that represents the given string (if it exists)
	 */
	public static Classification getClassification(String classification) {
		for (Classification c : Classification.values()) {
			if(c.toString().equals(classification)) {
				return c;
			}
		}
		throw new IllegalArgumentException("No constant with text " + classification + " found");
	}
}
