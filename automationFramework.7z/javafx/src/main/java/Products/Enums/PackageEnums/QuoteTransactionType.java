package Products.Enums.PackageEnums;

/**
 * Stores and enumerates the quote transaction types used in package construction.
 * @author eelefson
 */
public enum QuoteTransactionType {
	CREDIT_CARD("CREDIT CARD"), POSTAL_MAIL("POSTAL MAIL"),
	ACCOUNT_RECEIVABLE("ACCOUNT RECEIVABLE"), INVOICE_BILLING("INVOICE BILLING");
	
	private String name;
	
	QuoteTransactionType(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the enum associated with the given string.
	 * @param quoteTransactionType The string to be searched for
	 * @return The enum that represents the given string (if it exists)
	 */
	public static QuoteTransactionType getQuoteTransactionType(String quoteTransactionType) {
		for (QuoteTransactionType qtt : QuoteTransactionType.values()) {
			if(qtt.toString().equals(quoteTransactionType)) {
				return qtt;
			}
		}
		throw new IllegalArgumentException("No constant with text " + quoteTransactionType + " found");
	}
}
