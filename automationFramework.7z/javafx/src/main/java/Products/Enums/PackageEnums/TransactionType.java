package Products.Enums.PackageEnums;

/**
 * Stores and enumerates the transaction types used in package construction.
 * @author eelefson
 */
public enum TransactionType {
	CREDIT_CARD("CREDIT CARD"), ACCOUNT_RECEIVABLE("ACCOUNT RECEIVABLE"),
	FREE_SEARCH_CREDIT("FREE SEARCH CREDIT"), INVOICE_BILLING("INVOICE BILLING"),
	QUOTE("QUOTE"), DEMO_UNITS("DEMO UNITS");
	
	private String name;
	
	TransactionType(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the enum associated with the given string.
	 * @param transactionType The string to be searched for
	 * @return The enum that represents the given string (if it exists)
	 */
	public static TransactionType getTransactionType(String transactionType) {
		for (TransactionType tt : TransactionType.values()) {
			if(tt.toString().equals(transactionType)) {
				return tt;
			}
		}
		throw new IllegalArgumentException("No constant with text " + transactionType + " found");
	}
}
