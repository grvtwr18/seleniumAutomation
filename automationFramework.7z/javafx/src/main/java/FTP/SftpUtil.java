package FTP;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/**
 * This class manipulates files in a remote FTP server, including upload and download to the local machine,
 * using the JSch library.
 */
public class SftpUtil implements AutoCloseable {
    private String sftpHost = "sftp.talentwise.com";
    private int sftpPort = 22;
    private String sftpUser = "twtest";
    private String sftpPass = "Y0dawG!";

    private Session session;
    private Channel channel;
    private ChannelSftp channelSftp;
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public SftpUtil() throws JSchException {
        JSch jsch = new JSch();
        session = jsch.getSession(sftpUser, sftpHost, sftpPort);
        session.setPassword(sftpPass);
        session.setServerAliveInterval(5000);
        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");
        config.put("compression.s2c", "zlib@openssh.com,zlib,none");
        config.put("compression.c2s", "zlib@openssh.com,zlib,none");
        config.put("compression_level", "9");
        session.setConfig(config);
        session.connect();
        logger.info("SFTP session started.");

        channel = session.openChannel("sftp");
        channel.connect();
        logger.info("Channel connected.");
        channelSftp = (ChannelSftp) channel;
        logger.info("SFTP channel cast.");
    }

    /**
     * Uploads a File object to the remote SFTP.
     *
     * @param remoteDir the remote directory to upload to, as a String
     * @param file the File object to upload
     * @throws FileNotFoundException
     * @throws JSchException
     * @throws SftpException
     */
    public void uploadFile(String remoteDir, File file) throws FileNotFoundException, JSchException, SftpException {
        channelSftp.cd(remoteDir);
        channelSftp.put(new FileInputStream(file), file.getName());
        logger.info(file.getName() + " uploaded: " + remoteDir);
    }
    
    /**
     * Returns the last modified time of a file on the remote SFTP as a LocalDateTime. This method will work
     * only for uniquely-named files. Returns null if no files are found by the given name.
     *
     * @param remoteDir the remote directory to work in, as a String
     * @param fileName the filename to examine, as a String
     * @return a LocalDateTime object representing the file's mtime, or null if no file was found
     * @throws SftpException
     */
    public LocalDateTime getFileModificationDateTime(String remoteDir, String fileName) throws SftpException {
        channelSftp.cd(remoteDir);
        Vector lsList = channelSftp.ls(fileName);
        if (lsList.isEmpty()) {
            logger.debug("No files returned from 'ls {}' in directory {}", fileName, remoteDir);
            return null;
        }
        ChannelSftp.LsEntry fileLsEntry = (ChannelSftp.LsEntry)lsList.firstElement();
        int mTime = fileLsEntry.getAttrs().getMTime();
        // getMTime() returns a timestamp as seconds since epoch UTC, so convert to system default timezone for LocalDateTime.
        return LocalDateTime.from((Instant.ofEpochSecond(mTime)).atZone(ZoneId.systemDefault()));
    }

    /**
     * Uses the SFTP channel to download a file by name from a given directory, returning it as a list of Strings, each
     * representing a line of the file.
     *
     * @param remoteDir the remote directory to work in, as a String
     * @param fileName the filename to download, as a String
     * @return a List of Strings, each representing a line of the downloaded file
     * @throws SftpException
     */
    public List<String> downloadFileAsList (String remoteDir, String fileName) throws SftpException, IOException {
        channelSftp.cd(remoteDir);
        InputStream inputStream = channelSftp.get(fileName);
        System.out.println(fileName + " downloaded as List from SFTP successfully.");

        List<String> outputFileAsList = new ArrayList<String>();
        BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
        for (String line = br.readLine(); line != null; line = br.readLine()) {
            outputFileAsList.add(line);
        }
        return outputFileAsList;
    }

    /**
     * Uses the SFTP channel to remove a file from a given directory on the SFTP.
     *
     * @param remoteDir
     * @param fileName
     * @throws SftpException
     */
    public void removeFile(String remoteDir, String fileName) throws SftpException {
        channelSftp.cd(remoteDir);
        channelSftp.rm(fileName);
        System.out.println(fileName + " removed from SFTP successfully.");
    }

    public void close() {
        if (channelSftp != null) {
            channelSftp.exit();
            System.out.println("SFTP channel exited.");
        }
        if (channel != null) {
            channel.disconnect();
            System.out.println("Channel disconnected.");
        }
        if (session != null) {
            session.disconnect();
            System.out.println("Host session disconnected.");
        }
    }

    public void setSftpPass(String sftpPass) {
        this.sftpPass = sftpPass;
    }

    public String getSftpHost() {
        return sftpHost;
    }

    public void setSftpHost(String sftpHost) {
        this.sftpHost = sftpHost;
    }

    public int getSftpPort() {
        return sftpPort;
    }

    public void setSftpPort(int sftpPort) {
        this.sftpPort = sftpPort;
    }

    public String getSftpUser() {
        return sftpUser;
    }

    public void setSftpUser(String sftpUser) {
        this.sftpUser = sftpUser;
    }
}