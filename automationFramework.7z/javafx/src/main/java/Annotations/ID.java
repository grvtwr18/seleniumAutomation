package Annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by ssmith on 4/7/2015.
 * Example usage:
 * @Test
 * @ID (name = "AA E2E v1", BVT = true)
 * public void aTestCase() {
 *
 * The annotation Documented puts this in javadoc
 * The annotation Retention makes this annotation discoverable via reflection
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
public @interface ID {
    String name();
    boolean BVT();
}
