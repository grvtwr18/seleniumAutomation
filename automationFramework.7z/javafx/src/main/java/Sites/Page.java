package Sites;

import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;

public interface Page {
    static <T extends Page> T getPage(Class<T> type) {
        return PageFactory.initElements(Driver.getDriver(), type);
    }

    boolean isOnPage();
}
