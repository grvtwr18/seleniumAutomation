package Sites.TalentWiseDashboard;


import Sites.CandidatePortal.Eda.ElectronicDisclosurePage;
import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.ProductFormPages.TestRegistrationPage;
import TWFramework.BodyTextHelper;
import TWFramework.JavaScriptHelper;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;

import WebDriver.Driver;
import Workflows.Candidate;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.WebDriverException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Page object that represents the ticket form page.
 *
 * @author tjoshi
 */

/*TODO: method to return portal URL 
 * method to portal temp password*/
public class TicketForm {

    public Header header;
    public Footer footer;

    // The name for a logger is usually the name of the class, so that we
    // know which class threw the exception that may have been logged ...
    private static final Logger logger = LoggerFactory.getLogger(TicketForm.class);

    @FindBy(how = How.CSS, using = "#dbIdContentInner > div:nth-child(2)")
    private static WebElement passwordSentToCandidate;

    @FindBy(how = How.ID, using = "ticketLinkSentToCandidate")
    private static WebElement ticketLinkSentToCandidate;

    @FindBy(how = How.ID, using = "fillWithTestDataLink")
    private static WebElement fillWithTestDataLink;

    @FindBy(how = How.ID, using = "qfcramanualagree")
    private static WebElement fcraManualAgreeCheckBox;

    @FindBy(how = How.NAME, using = "qf")
    private static WebElement firstNameBox;

    @FindBy(how = How.NAME, using = "qmi")
    private static WebElement middleNameBox;

    @FindBy(how = How.NAME, using = "qn")
    private static WebElement lastNameBox;

    @FindBy(how = How.NAME, using = "qee")
    private static WebElement emailAddressBox;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement btnSubmit;

    @FindBy(how = How.XPATH, using = "//*[@class='flushTop dbSuccessColor']")
    private static WebElement ticketText;

    @FindBy(how = How.XPATH, using = "//*[@class='k-grid-content k-auto-scrollable']")
    private static WebElement productListTable;

    @FindBy(how = How.XPATH, using = "//*[@class='k-pager-wrap k-grid-pager k-widget k-floatwrap']")
    private static WebElement kendoPaginator;

    @FindBy(how = How.ID, using = "sendDisclosure")
    private static WebElement sendEdaCheckbox;

    @FindBy(how = How.ID, using = "manualDisclosure")
    private static WebElement manualDisclosureCheckbox;

    private static final By reuseDisclosureCheckboxLocator = By.id("reuseDisclosure");
    @FindBy(how = How.ID, using = "reuseDisclosure")
    private static WebElement reuseDisclosureCheckbox;

    @FindBy(how = How.ID, using = "qfcrareuseagree")
    private static WebElement reuseDisclosureCheckbox2;

    @FindBy(xpath = ".//*[@id='qempstate']")
    private static WebElement qempstate;

    @FindBy(how = How.ID, using="qempcity")
    private static WebElement qempcity;

    @FindBy(how = How.ID, using="usernameLink")
    private static WebElement usernameLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"userMenu\"]/li[2]/a")
    private static WebElement signOutLink;

    @FindBy(how = How.ID, using = "qempcity")
    private static WebElement cityOfEmpTextBox;

    // This control is usually not available ...
    @FindBy(how = How.ID, using = "refcode")
    private static WebElement refCodeDropDown;

    //alacarte add products button
    @FindBy(how = How.ID, using = "AddProductButton")
    private static WebElement addProductButton;

    @FindBy(how = How.ID, using = "uberform")
    private static WebElement ticketPageContent;

    // alacarte add products modal
    @FindBy(how = How.CLASS_NAME, using = "k-widget")
    public static WebElement addProductsModal;

    public static By kendoBusyImageLocator = By.cssSelector("div.k-loading-image");
    @FindBy(how = How.CSS, using = "div.k-loading-image")
    public static WebElement kendoBusyImage;

    @FindBy(how = How.XPATH, using = ".//*[@id='uberform']//p[@class='flushTop']")
    private static WebElement disclosureAgreementText;

    @FindBy(how = How.XPATH, using = ".//*[@id='packageDescription']//li")
    private static List<WebElement> packageDescription;

    @FindBy(how = How.XPATH, using = ".//*[@class='contents']/div[1]/div[2]")
    public static WebElement selfProvideDisClosureText;

    private static final String bccEmailCheckBoxLocatorPath = "//*[@id=\"dhs-uber-subform\"]/input[starts-with(@name, \"qsendemail_\")]";
    private static final By bccEmailCheckBoxLocator = By.xpath(bccEmailCheckBoxLocatorPath);

    @FindBy(how = How.XPATH, using = bccEmailCheckBoxLocatorPath)
    private static WebElement bccEmailCheckBox;

    @FindBy(how = How.XPATH, using = "//*[@id=\"dhs-uber-subform\"]/label")
    private static WebElement bccEmailText;

    private static final String reasonForTestDropDownLocatorPath = "//*[starts-with(@id, \"qtestreason_Group\")]";
    private static final By reasonForTestDropDownLocator = By.xpath(reasonForTestDropDownLocatorPath);
    @FindBy(how = How.XPATH, using = reasonForTestDropDownLocatorPath)
    private static WebElement reasonForTestDropDown;

    private static final String reasonForTestErrorMessageLocatorPath = "//*[starts-with(@id, \"div_Group\")]/div[@class=\"subformerror\"]";
    private static final By reasonForTestErrorMessageLocator = By.xpath(reasonForTestErrorMessageLocatorPath);
    @FindBy(how = How.XPATH, using = reasonForTestErrorMessageLocatorPath)
    private static WebElement reasonForTestErrorMessage;

    @FindBy(how = How.XPATH, using = "//div[contains(text(),'DEV: Password sent to the candidate:')]")
    private static WebElement oneTimePwd;

    @FindBy(how = How.XPATH, using = "//*[@class='searchField']//b")
    private static WebElement disclosureAuthorizationOptionsText;

    @FindBy(how = How.XPATH, using = "//*[contains(text(),'Complete Test Registration')]")
    private static WebElement completeTest;

    /**
     * Constructs a new Product Form page object.
     */
    public TicketForm() {
        this.setDriver();
        this.header = PageFactory.initElements(Driver.getDriver(), Header.class);
        this.footer = PageFactory.initElements(Driver.getDriver(), Footer.class);
    }

    static {
        PageFactory.initElements(Driver.getDriver(), TicketForm.class);
    }

    /**
      * Runs the java script behind the "Fill with test data" link to fill the form out with
     * default data.
     */
    public static void fillWithTestDataJs() {
        logger.info("Filling test data");
        if (!SeleniumTest.isElementVisibleNoWaiting(By.id("fillWithTestDataLink"))) {

            String url = SeleniumTest.getCurrentUrl();

            if (!url.contains("&prefill=1")) {
                url += "&prefill=1";
                SeleniumTest.navigateToUrl(url);
                SeleniumTest.waitForPageLoad();
            }
        }

        SeleniumTest.waitForElementToBeClickable(fillWithTestDataLink);
        JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
        // TODO: Find out which exceptions are thrown by this, and catch all that are reasonably expected ...
        js.executeScript("fillWithTestData(); return false;");
    }

    /**
     * Creates the ticket and returns the ticket ID
     *
     * @return The Ticket ID of the recently created Ticket.
     */
    public static String clickSubmitButton() {
        SeleniumTest.waitForElementToBeClickable(btnSubmit);
        // Sometime in mid-November, 2015, btnSubmit.click() started failing. Calling a JS click instead does the trick.
        JavaScriptHelper.click(btnSubmit);
        SeleniumTest.waitForElementVisible(ticketText);

        // extract the ticket number from the page.
//        return ticketText.getText().replaceAll("[^0-9]", "");
        return ticketText.getText().split("#")[1].split(" has been")[0];
    }

    /**
     * Returns newly generated ticket number
     *
     * This must be called after successful ticket purchase
     *
     * @return
     */
    public static String getTicketNumber() {
        return ticketText.getText().split("#")[1].split(" has been")[0];
    }

    /**
     * Click submit and wait for reload
     */
    public static void clickSubmitButtonAndWaitForPageLoad() {
        /**
         * For some reason SeleniumTest.click() does not work.
         * It does click the button but submission does not happen. Perhaps since the button
         * has onclick code something... Therefore using JavaScript instead.
         *
         * SeleniumTest.click(btnSubmit); // does not submit
         */
        JavaScriptHelper.click(btnSubmit);

        // Lets wait for page reload after submission
        SeleniumTest.waitForPageLoad();
    }

    public static String getTicketLink() {
        return ticketLinkSentToCandidate.getAttribute("href");
    }

    /**
     * Is the Submit/Generate Ticket button enabled?
     * @return true if the Submit/Generate Ticket button is enabled
     */
    public static boolean isSubmitButtonEnabled() {
        return btnSubmit.isEnabled();
    }

    public void setDriver() {

    }

    /**
     * pull the value prefilled in firstName box
     */
    public static String getInitialFirstNameValue() {
        return firstNameBox.getAttribute("value");
    }

    /**
     * pull the value prefilled in MiddleName box
     */
    public static String getInitialMiddleNameValue() {
        return middleNameBox.getAttribute("value");
    }

    /**
     * pull the value prefilled in lastName box
     */
    public static String getInitialLastNameValue() {
        return lastNameBox.getAttribute("value");
    }

    /**
     * pull the value prefilled in email box
     */
    public static String getEmail() {
        return emailAddressBox.getAttribute("value");
    }

    public static void setFirstName(String firstName) {
        SeleniumTest.waitForElementEnabled(firstNameBox);
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
    }

    public static void setMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameBox, middleName);
    }

    public static void setLastName(String lastName) {
        lastNameBox.sendKeys(lastName);
    }

    public static void setEmail(String email) {
        SeleniumTest.clearAndSetText(emailAddressBox, email);

        // pause for the lame email widget to complete verification
        // TODO: Use a wait for element rather than this explicit wait
        SeleniumTest.waitMs(2000);
    }

    public static void setCandidateData(Candidate candidate) {
        setFirstName(candidate.getFirstName());
        setMiddleName(candidate.getMiddleName());
        setLastName(candidate.getLastName());
        setEmail(candidate.getEmailAddress());
    }

    public static void chooseReferenceCodeDropDown(int index) {
        SeleniumTest.selectByDropDownIndexFromDropDown(refCodeDropDown, index);
    }

    /**
     * Ticks the FCRA Manual Agreement checkbox.
     */
    public static void checkFCRAManualAgreeCheckBox() {
        if (SeleniumTest.isElementVisibleNoWaiting(By.id("qfcramanualagree"))) {
            SeleniumTest.check(fcraManualAgreeCheckBox);
        }
    }

    /**
     * Ticks the send EDA checkbox.
     */
    public static void checkSendEdaCheckbox() {
        try {
            SeleniumTest.check(sendEdaCheckbox);
        } catch (WebDriverException e) {
            // Selenium erroneously thinks this checkbox is not clickable
            // because another element would supposedly receive the click ...
            WaitUntil.waitUntil(() -> {
                JavaScriptHelper.click(sendEdaCheckbox);
                return SeleniumTest.isCheckboxChecked(sendEdaCheckbox);
            });
        }
    }

    /**
     * Ticks the Manual Disclosure checkbox
     */
    public static void checkManualDisclosureCheckbox() {
        try {
            SeleniumTest.check(manualDisclosureCheckbox);
        } catch(WebDriverException e) {
            // Sometimes Selenium is deceived into thinking, "Other element would receive the click."
            WaitUntil.waitUntil(() -> {
                if (!SeleniumTest.isCheckboxChecked(manualDisclosureCheckbox)) {
                    JavaScriptHelper.click(manualDisclosureCheckbox);
                }

                return SeleniumTest.isCheckboxChecked(manualDisclosureCheckbox);
            });
        }
    }

    /**
     * Validates whether checkbox for reusing EDA is visible
     *
     * @return
     */
    public static boolean isReuseDisclosureCheckboxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(reuseDisclosureCheckboxLocator);
    }

    /**
     * Validates whether checkbox for EDA checkbox is visible
     *
     * @return
     */
    public static boolean isEdaCheckboxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("sendDisclosure"));
    }


    /**
     * Checks checkbox for reusing EDA
     */
    public static void checkReuseDisclosureCheckbox() {
        SeleniumTest.check(reuseDisclosureCheckbox);
    }

    /**
     * Checks checkbox for reusing EDA
     */
    public static void checkReuseDisclosureCheckbox2() {
        SeleniumTest.check(reuseDisclosureCheckbox2);
    }

    /**
     * Extract the password from a string like, "DEV: Password sent to the candidate: RFuPUdWc"
     * @return the password displayed after Submitting / Generating a Ticket
     */
    public static String getPasswordSentToCandidate() {
        String[] arrayWithPasswordAtEnd = passwordSentToCandidate.getText().split(": ");
        return arrayWithPasswordAtEnd[arrayWithPasswordAtEnd.length - 1];
    }

    /**
     * Validates whether temporary password has been generated
     * This normally happens for new candidates
     * For existing candidates no password is generated, they should have one already.
     *
     * @return
     */
    public static boolean isPasswordSentToCandidateVisible() {
        return passwordSentToCandidate.getText().contains("Password sent to the candidate: ");
    }


    /**
     * Clicks the "Ticket link sent to candidate" Link
     */
    public static ElectronicDisclosurePage clickTicketLinkSentToCandidate() {
        SeleniumTest.click(ticketLinkSentToCandidate);
        return PageFactory.initElements(Driver.getDriver(),ElectronicDisclosurePage.class);
    }

    public static void selectLocationOfEmployment(String state) {
        SeleniumTest.selectByVisibleTextFromDropDown(qempstate, state);
    }

    public static void setLocationOfEmploymentCity(String city) {
        SeleniumTest.setTextValue(qempcity, city);
    }

    public static void fillLocationOfEmploymentSection(String state, String cityOfEmployment) {
        TicketForm.selectLocationOfEmployment(state);
        TicketForm.typeCityOfEmployment(cityOfEmployment);
    }

    private static void typeCityOfEmployment(String cityOfEmployment) {
        SeleniumTest.clearAndSetText(cityOfEmpTextBox, cityOfEmployment);
    }

    public static String getAddProductButtonText() {
        return addProductButton.getText();
    }

    public static String getExpectedaddProductButonText(LocaleHelper.Locale locale) {
        switch (locale.toString()) {
            case "en_US":       return "Add Products";

            case "qps_PLOC":    return "[{16ec} Ȧḓḓ Ƥřǿḓŭƈŧş]";

            default:            return "Add Products";
        }
    }

    public static WebElement getAddProductsModal() {
        return addProductsModal;
    }

    public static WebElement getProductListTable() {
        return productListTable;
    }

    public static WebElement getKendoPaginator() {
        return kendoPaginator;
    }

    public static void clickAddProducts() {
        SeleniumTest.waitForElementToBeClickable(addProductButton);
        addProductButton.click();
        waitForKendoGridRefresh();
    }

    /**
     * If the kendoBusyImage indicator is present, waits for it to go away
     */
    private static void waitForKendoGridRefresh() {
        logger.info("Wait for Kendo Grid to Refresh");

        if (TWFramework.SeleniumTest.isElementVisibleNoWaiting(kendoBusyImageLocator)) {
            logger.debug("Found busy image");
            new FluentWait<WebDriver>(Driver.getDriver())
                    .withTimeout(60, TimeUnit.SECONDS)
                    .pollingEvery(3, TimeUnit.SECONDS)
                    .until(new Predicate<WebDriver>() {
                               public boolean apply(WebDriver driver) {
                                   if (!SeleniumTest.isElementVisibleNoWaiting(kendoBusyImageLocator)) {
                                       logger.debug("Busy image is gone");
                                       return true;
                                   }
                                   return false;
                               }
                           }
                    );
        }
    }

    public static List<String> getPackageDescription(){
        List<String> packages = new ArrayList<String>();
        for(WebElement elements: packageDescription){
            packages.add(SeleniumTest.getText(elements));
        }
        return packages;
    }

    public static String getDisclosureText(){
        return SeleniumTest.getText(disclosureAgreementText);
    }


    public static String getSelfDisclosureText() {
        return SeleniumTest.getText(selfProvideDisClosureText);
    }

    public static WebElement getTicketPageContent() {
        return ticketPageContent;
    }

    public static void hideTicketText() {
        BodyTextHelper.hideElement(ticketText);
    }

    public static void clickGenerateButton() {
        SeleniumTest.click(btnSubmit);
    }

    public static boolean isCheckboxbccVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(bccEmailCheckBoxLocator);
    }

    public static boolean isCheckboxbccChecked() {
        return SeleniumTest.isCheckboxChecked(bccEmailCheckBox);
    }

    public static void checkbccEmail() {
        SeleniumTest.check(bccEmailCheckBox);
    }

    public static void uncheckbccEmail() {
        SeleniumTest.unCheck(bccEmailCheckBox);
    }

    public static String getbccEmailText(){
        return SeleniumTest.getText(bccEmailText);
    }

    public static boolean isReasonForTestDropDownVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(reasonForTestDropDownLocator);
    }

    public static void chooseReasonForTestOption(String option) {
        SeleniumTest.selectByVisibleTextFromDropDown(reasonForTestDropDown, option);
    }

    public static String getSingleSelectedVisibleTextFromReasonForTestDropDown() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(reasonForTestDropDown);
    }

    public static boolean isReasonForTestErrorMessageVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(reasonForTestErrorMessageLocator);
    }

    /**
     * Validates successful submission of the ticket with the given email
     *
     * @param email
     * @return
     */
    public static boolean verifySuccessfulMessage(String email) {
        String successPattern = String.format("Ticket #\\d+ has been emailed to %s", email);
        logger.info(String.format("Validating success pattern <%s>", successPattern));
        return SeleniumTest.verifyPattern(successPattern);
    }

    /*On ticket form page one time password is shown in Dev enviornment */
    public static String getOTP(){
        return SeleniumTest.getText(oneTimePwd);
    }

    public static String getTextDisclosureAuthorizationOptionsText(){
        return SeleniumTest.getText(disclosureAuthorizationOptionsText);
    }

    public static  TestRegistrationPage clickcompleteTest(){
        SeleniumTest.click(completeTest);
        SeleniumTest.waitForPageLoadToComplete();
        TestRegistrationPage testRegistrationPage = PageFactory.initElements(Driver.getDriver(), TestRegistrationPage.class);
        return testRegistrationPage;
    }

    public String getCandidateIDFromTicketLink(String ticketLink)
    {
        return ticketLink.split("&OverrideCandidateID=")[1];
    }

}
