package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.CustomerDashboardPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TimeOutWarningModal extends CustomerDashboardPages {

    @FindBy(how = How.CLASS_NAME, using = "modalButton")
    private static WebElement continueButton;

    @FindBy(how = How.ID, using = "closeBox")
    private static WebElement closeXButton;

    static {
        PageFactory.initElements(Driver.getDriver(), TimeOutWarningModal.class);
    }

    public static boolean isVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.className("modalButton"))
                && SeleniumTest.isElementVisibleNoWaiting(By.id("closeBox"))
                && SeleniumTest.isElementVisibleNoWaiting(By.id("divContinueModalTitleText"));
    }

    public static void clickContinueButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(continueButton, By.className("modalButton"));
    }

    public static void clickCloseXButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(closeXButton, By.id("closeBox"));
    }
}
