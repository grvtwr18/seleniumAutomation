package Sites.TalentWiseDashboard;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by wogden on 6/24/2016.
 */
public class ActivatePortalAccessModal extends CustomerDashboardPages {
    @FindBy(how = How.XPATH, using = "//*[@id=\"divEditProfileContent\"]/div[3]/div/div/p")
    private static WebElement bodyText;

    @FindBy(how = How.XPATH, using = "//input[@value='Confirm Changes']")
    private static WebElement confirmChangesButton;

    public static String getBodyText() {
        return bodyText.getText();
    }

    public static void clickConfirmChangesButton() {
        confirmChangesButton.click();
    }
}
