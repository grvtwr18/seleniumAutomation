package Sites.TalentWiseDashboard;

import Sites.AdminConsole.CustomerSupport.ScreeningSupport.RequestAndSsnTools.MoveToManualPage;
import Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import TWFramework.JavaScriptHelper;

/**
 * Created by abrackett on 11/2/2015.
 */
public class CustomerDashboardPages extends Sites.TalentWiseDashboard.ProductFormPages.ProductFormPages {

    private static final Logger staticLogger = LoggerFactory.getLogger(CustomerDashboardPages.class);

    @FindBy(how = How.XPATH, using = ".//button[text()='Ticket']")
    private static WebElement ticketBtn;

    @FindBy(how = How.XPATH, using = "//input[@value='Launch']")
    private static WebElement launchBtn;

    @FindBy(how = How.XPATH, using = "(//img[@alt='View Report'])[2]")
    private static WebElement viewReportInProgress;

    @FindBy(how = How.XPATH, using = "//img[@alt='View Report']")
    private static WebElement viewReportLink;

    @FindBy(how = How.XPATH, using = "//span[@class='material-icons context-switch66']")
    private static WebElement spnDownArrow;

    @FindBy(how = How.XPATH, using = "//li//p[text()='Account Settings']")
    private static WebElement lnkAccoutnSettingLink;

    @FindBy(how = How.XPATH, using = "//span[.='Credit Card']")
    private static WebElement lnkCreditCard;

    @FindBy(how = How.XPATH, using = "//iframe[contains(@name,'_privateStripeFrame5')]")
    private static WebElement ifrmCredeitCard;

    @FindBy(how = How.XPATH, using = "//input[@name='cardnumber']")
    private static WebElement inpCreditCardNumber;

    @FindBy(how = How.XPATH, using = "//input[@name='exp-date']")
    private static WebElement inpCCNumber;

    @FindBy(how = How.XPATH, using = "//input[@name='cvc']")
    private static WebElement inpexpdate;

    @FindBy(how = How.ID, using = "stripeSave")
    private static WebElement inpcvc;

    @FindBy(how = How.XPATH, using = "__PrivateStripeElement-input")
    private static WebElement btnSave;

    @FindBy(how = How.XPATH, using = "//button[@class='actionButton primaryAction']")
    private static WebElement btnSave2;

    @FindBy(how = How.XPATH, using = "(//div[contains(.,'successfully')])[1]")
    private static WebElement divVerify;

    @FindBy(how = How.XPATH, using = "//span[@class='dashboard-link']")
    private static WebElement lnkDashboard;

    @FindBy(how = How.XPATH, using = "//div[@id='subsectionDistro']//div[@id='5']//button[.='Launch']")
    private static WebElement btnLaunch;

    @FindBy(how = How.XPATH, using = "Enter credit card']")
    private static WebElement lnkEnterCreditCard;

    @FindBy(how = How.XPATH, using = "//div[a[@class='searchAddRemoveLink dbLinkNoUnderline']]//preceding-sibling::h3[.='Payment Information']")
    private static WebElement lnkEditCC;

    @FindBy(how = How.ID, using = "submitAccount")
    private static WebElement btnUpdateSetting;

    @FindBy(how = How.XPATH, using = "//div[@class='alert']")
    private static WebElement divVerifyCCDataIB;

    @FindBy(how = How.ID, using = "CC_Number")
    private static WebElement inpCCNumbers;

    @FindBy(how = How.ID, using = "CC_Name")
    private static WebElement inpCCName;

    @FindBy(how = How.ID, using = "CC_SecurityCode")
    private static WebElement inpcvc2;

    @FindBy(how = How.ID, using = "CC_Address")
    private static WebElement inpCCAdd;

    @FindBy(how = How.ID, using = "CC_City")
    private static WebElement inpCCCity;

    @FindBy(how = How.ID, using = "CC_State")
    private static WebElement inpCCState;

    @FindBy(how = How.ID, using = "CC_PostCode")
    private static WebElement inpCCZipCode;

    @FindBy(how = How.XPATH, using = "//a[contains(.,'Dashboard')]")
    private static WebElement linkDashboard;

    @FindBy(how = How.XPATH, using = "//span[contains(@aria-owns,'CC_ExpYear_listbox')]")
    private static WebElement drpExpDate;

    @FindBy(how = How.XPATH, using = "//span[contains(@aria-owns,'CC_ExpYear_listbox')]//span[contains(@class,'k-dropdown-wrap')]")
    private static WebElement drpExpDate2;
    @FindBy(how = How.XPATH, using = "(//span[@class='InputContainer']//input)[1]")
    private static WebElement inpAdd;
    @FindBy(how = How.XPATH, using = "(//span[@class='InputContainer']//input)[2]")
    private static WebElement inpDate;
    @FindBy(how = How.XPATH, using = "(//span[@class='InputContainer']//input)[3]")
    private static WebElement inpCVC;

    By verifydiv = By.xpath("(//div[contains(.,'successfully')])[1]");

    public CustomerDashboardPages() {
        // Adding a wait to the constructor so the page load completes before the call returns
        //Commenting the wait for ajax as it goes into catch block and then Webdriver instance is null. 
        //SeleniumTest.waitForJQueryAjaxDone();
    }


    static {
        PageFactory.initElements(Driver.getDriver(), CustomerDashboardPages.class);
    }
    /**
     *
     * @param uberFormName
     * @param buttonName
     */
    public static ScreeningLaunchPage clickforScreening(String uberFormName, String buttonName) {
        SeleniumTest.click(By.xpath(String.format("//a[contains(text(),'%s')]/../../../*[@class=\"buttoncolumn\"]//a/button[contains(text(),'%s')]",uberFormName,buttonName)));
        SeleniumTest.waitForPageLoadToComplete();
        return PageFactory.initElements(Driver.getDriver(),ScreeningLaunchPage.class);
    }

    public static ScreeningLaunchPage clickforScreeningLaunchButton(String uberFormName, String buttonName) {
        SeleniumTest.click(By.xpath(String.format("//a[contains(text(),'%s')]/../../../*[@class=\"buttoncolumn\"]//a/button[contains(text(),'%s')]",uberFormName,buttonName)));
        SeleniumTest.waitForPageLoadToComplete();
        return PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
    }

    public static void clickViewReportInProgress(){
        SeleniumTest.click(viewReportInProgress);
    }

    public static void clickViewReport(){
        SeleniumTest.waitForElementToBeClickable(viewReportLink);
        SeleniumTest.click(viewReportLink);
    }
    public static void clickLaunchButton(){
        SeleniumTest.waitMs(3000);
        SeleniumTest.click(launchBtn);
    }
    public static <T>T clickforScreening(String uberFormName, String buttonName,Class<T> type) {
        SeleniumTest.click(By.xpath(String.format("//a[contains(text(),'%s')]/../../../*[@class=\"buttoncolumn\"]//a/button[contains(text(),'%s')]",uberFormName,buttonName)));
        SeleniumTest.waitForPageLoadToComplete();
        return PageFactory.initElements(Driver.getDriver(),type);
    }

    public void NavigateToAccountSettingsCCData() {
        SeleniumTest.waitForElementVisible(spnDownArrow);
        JavaScriptHelper.click(spnDownArrow);
        SeleniumTest.waitForElementVisible(lnkAccoutnSettingLink);
        JavaScriptHelper.click(lnkAccoutnSettingLink);
        SeleniumTest.waitForElementVisible(lnkCreditCard);
        JavaScriptHelper.click(lnkCreditCard);
    }


    public Boolean VerifyCreditCardCheck() {
        Driver.getDriver().switchTo().frame(ifrmCredeitCard);
        SeleniumTest.clearAndSetText(inpCreditCardNumber, "5555555555554444");
        SeleniumTest.clearAndSetText(inpcvc, "234");
        SeleniumTest.clearAndSetText(inpexpdate, "2055");
        Driver.getDriver().switchTo().defaultContent();
        SeleniumTest.waitForElementVisible(btnSave);
        JavaScriptHelper.click(btnSave);
        //SeleniumTest.getTextByLocator(divVerify);
        Boolean flag = divVerify.isDisplayed();
        return flag;
    }


    public void selectExpDate(String varexpdate) {
        staticLogger.info("select ExpDate");
        JavaScriptHelper.selectDropDownOption(drpExpDate, varexpdate, "Text");
    }


    public void selectExpDate2(String varexpdate2) {
        staticLogger.info("select ExpDate");
        JavaScriptHelper.selectDropDownOption(drpExpDate2, varexpdate2, "Text");
    }


    public Boolean VerifyCCCheck() {
        SeleniumTest.clearAndSetText(inpCCName, "Test");
        SeleniumTest.switchToFrame(ifrmCredeitCard);
        SeleniumTest.clearAndSetText(inpCCNumbers, "5555555555554444");
        SeleniumTest.clearAndSetText(inpcvc2, "234");
        selectExpDate("2055");
        SeleniumTest.switchToDefault();
        SeleniumTest.clearAndSetText(inpCCAdd, "Huntsville");
        SeleniumTest.clearAndSetText(inpCCCity,"David Villa");
        SeleniumTest.clearAndSetText(inpCCZipCode,"35749");
        JavaScriptHelper.selectDropDownOption(inpCCState,"AL","value");
        clickButtonSave();
        SeleniumTest.isElementPresent(verifydiv,5);
        return true;
    }

    public Boolean VerifyCCCheck2() {
        SeleniumTest.clearAndSetText(inpCCName, "Test");
        SeleniumTest.switchToFrame(ifrmCredeitCard);
        SeleniumTest.clearAndSetText(inpAdd, "5555555555554444");
        SeleniumTest.clearAndSetText(inpDate, "2525");
        SeleniumTest.clearAndSetText(inpCVC, "234");
        SeleniumTest.switchToDefault();
        SeleniumTest.clearAndSetText(inpCCAdd, "David Villa");
        SeleniumTest.clearAndSetText(inpCCCity,"Huntsville");
        SeleniumTest.clearAndSetText(inpCCZipCode,"35749");
        JavaScriptHelper.selectDropDownOption(inpCCState,"AL","value");
        clickButtonSave();
        SeleniumTest.isElementPresent(verifydiv,5);
        return true;
    }

    public void clickonLaunchButton() {
        SeleniumTest.waitForElementVisible(linkDashboard);
        JavaScriptHelper.click(linkDashboard);
        SeleniumTest.waitForElementVisible(btnLaunch);
        JavaScriptHelper.click(btnLaunch);
    }

    public Boolean validateCrediCardforInvoiceBillingUser() {
        Boolean flag = divVerifyCCDataIB.isDisplayed();
        return flag;
    }

    public void clickButtonSave() {
        SeleniumTest.waitForElementVisible(btnSave2);
        JavaScriptHelper.click(btnSave2);
    }

}
