package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by jgupta on 1/7/2016.
 */
public class AddPositionModal extends AddPackageModal {

    @FindBy(how = How.CSS, using = "input.button.buttonwidth125")
    public static WebElement addPositionButton;

    @FindBy(how = How.ID, using = "modalMask")
    private static WebElement modalMask;

    @FindBy(how = How.ID, using = "qpositionid")
    private static WebElement positionIdSelect;

    static {
        PageFactory.initElements(Driver.getDriver(), AddPositionModal.class);
    }

    /**
     * Selects position from Add Position drop down by visible position name.
     * @param positionName
     */
    public static void selectPosition(String positionName) {
        SeleniumTest.waitForPageLoadToComplete();
        Select positionDropDown = new Select(positionIdSelect);
        positionDropDown.selectByVisibleText(positionName);
    }

    /**
     * Selects position from Add Position drop-down by value (position ID).
     *
     * @param positionId positionId value as int
     */
    public static void selectPositionById(int positionId) {
        new Select(positionIdSelect).selectByValue(String.valueOf(positionId));
    }

    /**
     * Clicks on add position button to return the page.
     * @return
     */
    public static CustomerDashboardPages clickAddPositionButton(Class<? extends CustomerDashboardPages> returnClass) {
        clickAddPositionButton();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Clicks on Add Position button and waits for modal to close. No return value.
     */
    public static void clickAddPositionButton() {
        addPositionButton.click();
        TWFramework.SeleniumTest.waitForElementNotVisible(modalMask);
    }

    public static void selectPositionFromModal(String positionName) {
        staticlogger.info("{}. Select position from position drop down in Add Position modal dialog");
        AddPositionModal.selectPosition(positionName);
        staticlogger.info("{}. Click on Add Position Button to add the position.");
        AddPositionModal.clickAddPositionButton(CandidateDetailsPage.class);
    }
}
