package Sites.TalentWiseDashboard;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import Sites.TalentWiseDashboard.ProductFormPages.ProductFormPages;
import TWFramework.WaitUntil;
import WebDriver.Driver;

/**
 * Created by abrackett on 10/19/2015.
 */
public class ResendNotificationModal {
    public Sidebar sidebar;
    public Header header;
    public Footer footer;

    @FindBy(how = How.CLASS_NAME, using = "modalWindowLowerActions>input")
    private static WebElement inputButton;

    /**
     * Closes the Resend Notification Modal Dialog
     * @return CandidateDetailsPage
     */
    public static ProductFormPages closeResendNotification(Class<? extends ProductFormPages> returnedClass) {
        WaitUntil.waitUntil(() -> inputButton.isEnabled());
        inputButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
