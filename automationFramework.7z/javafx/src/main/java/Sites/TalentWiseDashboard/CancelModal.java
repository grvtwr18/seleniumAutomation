package Sites.TalentWiseDashboard;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Sites.TalentWiseDashboard.ProductFormPages.ProductFormPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by abrackett on 11/20/2015.
 */
public class CancelModal {
    @FindBy(how = How.XPATH, using = "//div/input[@value='Close']")
    private WebElement closeButton;

    @FindBy(how = How.XPATH, using = "//div/input[@value='Confirm Cancellation']")
    private static WebElement confirmButton;

    public static CancelModal getInstance() {
        return PageFactory.initElements(Driver.getDriver(), CancelModal.class);
    }

    public void clickClose() {
        closeButton.click();
    }

    public ProductFormPages clickConfirmCancellation(Class<? extends ProductFormPages>
                                                             returnedClass) {
        return clickConfirm(returnedClass);
    }
    public static ProductFormPages clickConfirm(Class<? extends ProductFormPages> returnedClass) {
        confirmButton.click();
        // Explicit wait for page refresh after cancel dialog is closed
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 2);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
