package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import static TWFramework.JavaScriptHelper.runScript;

/**
 * Page object that represents the Forgot Password page for the Customer Dashboard website.
 * @author wogden
 */
public class ForgotPasswordPage {
	@SuppressWarnings("unused")

	@FindBy(how = How.NAME, using = "csrf_token")
	private static WebElement csrfToken;
	// use getLockedOutMessage to retrieve this from the page
	private static final String csrfErrorMessageExpectedText = "There was a problem resetting the password.";

	@FindBy(how = How.NAME, using = "EmailAddr")
	private static WebElement emailBox;
	
	@FindBy(how = How.XPATH, using = "//input[@value='Submit']")
	private static WebElement submitButton;

	@FindBy(how = How.CLASS_NAME, using = "resetPasswordMessage")
	private static WebElement resetPasswordMessage;
	private final static String RESET_PASSWORD_MESSAGE_EXPECTED_TEXT = "You have made too many password attempts. Please reset your password.";

	@FindBy(how = How.CLASS_NAME, using = "dbMessage")
	private static WebElement lockedOutMessage;
	private final static String LOCKED_OUT_MESSAGE_EXPECTED_TEXT = "Your account has been deactivated.\n"
			+ "Please contact Customer Support for assistance.";

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'temporary password')]")
	private static WebElement thankYouForResettingText;

	@FindBy(how = How.CLASS_NAME, using = "dbMessage")
	private static WebElement tempPasswordConfirmationMessage;

	//note that this is a hidden field which only shows up in dev
	@FindBy(how = How.ID, using = "tempPassword")
	private static WebElement tempPassword;

	static {
		PageFactory.initElements(Driver.getDriver(), ForgotPasswordPage.class);
	}

	
	/**
	 * Constructs a new Forgot Password page object.
	 */
	public ForgotPasswordPage() {
		SeleniumTest.waitForJQueryAjaxDone();
    }

	public static String getResetPasswordMessage() {
		return resetPasswordMessage.getText();
	}

	public static String getThankyouForResettingMessage() {
		return thankYouForResettingText.getText();
	}

	public static String getResetPasswordMessageExpectedText() {
		return RESET_PASSWORD_MESSAGE_EXPECTED_TEXT;
	}

	public static String getLockedOutMessage() {
		return lockedOutMessage.getText();
	}

	public static String getLockedOutMessageExpectedText() {
		return LOCKED_OUT_MESSAGE_EXPECTED_TEXT;
	}

	public static String getEmail() {
		return emailBox.getAttribute("Value");
	}

	public static void setEmail(String email) {
		SeleniumTest.clearAndSetText(emailBox, email);
	}

	public static String getTempPassword() {
		// getText doesn't work for hidden fields, thus textContent
		return tempPassword.getAttribute("textContent");
	}

	public static String getTempPasswordSentConfirmation() {
		return tempPasswordConfirmationMessage.getText();
	}

	//FDN-615 AC2
	public static String getExpectedTempPasswordConfirmationText(String email) {
		return "A new, temporary password has been sent to " + email + ". If you don't receive an email containing your temporary password within ten minutes, please check to see that you are using the correct email address and try again.\n"
				+ "After you receive your new, temporary password, click here to sign in.";
	}

	/**
	 * Types the specified email into the email text box.
	 * @param email The email to be typed
	 */
	public static void typeEmail(String email) {
		SeleniumTest.clearAndSetText(emailBox, email);
	}
	
	/**
	 * Clicks the "Submit" button.
	 */
	public static void clickSubmitButton() {
		submitButton.click();
	}

	public static boolean isCsrfTokenHidden() {
		return !csrfToken.isDisplayed();
	}

	public static String getCsrfErrorMessageExpectedText() {
		return csrfErrorMessageExpectedText;
	}

	public static String getCsrfTokenValue() {
		return csrfToken.getAttribute("value");
	}

	public static void clearCsrfTokenValue() {
		setCsrfTokenValue("");
	}

	public static void setCsrfTokenValue(String newValue) {
		runScript("document.getElementsByName('csrf_token')[0].value = '" + newValue + "'");
	}
}
