package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jayagupta on 5/7/18.
 */
public class CancelTicketModal extends CustomerPortalPage {
    @FindBy(how = How.CSS, using = "div.modalWindowLowerActions input[value='Cancel']")
    private WebElement cancelButton;

    @FindBy(how = How.XPATH, using = "//div/input[@value='Continue']")
    private WebElement continueButton;

    public CustomerPortalPage clickContinueButton(Class<? extends CustomerPortalPage>
                                            returnedClass) {
        SeleniumTest.click(continueButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public CustomerPortalPage clickCancelButton(Class<? extends CustomerPortalPage>
                                                          returnedClass) {
        SeleniumTest.click(cancelButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
