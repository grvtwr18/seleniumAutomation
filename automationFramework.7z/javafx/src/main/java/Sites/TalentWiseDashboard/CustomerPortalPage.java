package Sites.TalentWiseDashboard;

import Sites.Pages;
import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;

/**
 * A parent class for all the customer portal (or "Dashboard") pages (including the one that is actually the Dashboard).
 * Used for the common header, footer, and sidebar we all know and love.
 *
 * Created by jpflager on 8/26/2016.
 */
public abstract class CustomerPortalPage extends Pages {
    // TODO: make these private. Will require refactoring existing tests to use the getters.
    public static Sidebar sidebar = PageFactory.initElements(Driver.getDriver(), Sidebar.class);
    public static Header header = PageFactory.initElements(Driver.getDriver(), Header.class);
    public static Footer footer = PageFactory.initElements(Driver.getDriver(), Footer.class);

    public static Sidebar getSidebar() {
        return sidebar;
    }

    public static Header getHeader() {
        return header;
    }

    public static Footer getFooter() {
        return footer;
    }
}
