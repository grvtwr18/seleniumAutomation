package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Page object for the common items present in report builder-made reports
 *
 * @author rporras
 */
public class BasicReportPage extends CustomerPortalPage {

    @FindBy(how = How.XPATH, using = "//div[@class='noprint']/a")
    private static WebElement backToReportsLink;

    @FindBy(how = How.XPATH, using = "//div[@class='field userFilter']/label[text()[contains(translate(.,"
                                     + "'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'candidate')"
                                     + "]]/input[@class='searchtext']")
    private static WebElement candidateIDInput;

    @FindBy(how = How.XPATH, using = "//div[@class='field userFilter' or @class='field multiselectField "
                                     + "userFilter']/label[text()[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',"
                                     + " 'abcdefghijklmnopqrstuvwxyz'), 'package')]]/node()[self::input or self::button]")
    private static WebElement packageInput;

    @FindBy(how = How.CLASS_NAME, using = "title")
    private static WebElement reportTitleLabel;

    @FindBy(how = How.XPATH, using = "//div[@class='field'][2]//input[@class='dateField k-input']")
    private static WebElement fromInput;

    @FindBy(how = How.XPATH, using = "//div[@class='field'][3]//input[@class='dateField k-input']")
    private static WebElement toInput;

    @FindBy(how = How.CLASS_NAME, using = "customDate")
    private static WebElement reportCreateTimeDropdown;

    @FindBy(how = How.XPATH, using = "//div[@class='dbSearchBox modernDesign']/input[@class='button']")
    private static WebElement searchBtn;

    @FindBy(how = How.CLASS_NAME, using = "clearLink")
    private static WebElement clearAllLink;

    @FindBy(how = How.ID, using = "metricsButton")
    private static WebElement metricsDefinitionsLink;

    @FindBy(how = How.XPATH, using = "//span[@class='k-icon k-i-close']")
    private static WebElement metricsDefinitionsClose;

    @FindBy(how = How.ID, using = "exportExcelGrid")
    private static WebElement exportToExcelButton;

    @FindBy(how = How.XPATH, using = "//div[@class='k-pager-wrap k-grid-pager k-widget k-floatwrap']")
    private static WebElement reportGridFoot;

    @FindBy(how = How.XPATH, using = "//div[@id='mainGrid']/div[@class='k-grid-content k-auto-scrollable']/table")
    private static WebElement customGrid;

    @FindBy(how = How.XPATH, using = "//div[@id='mainGrid']//span[@class='k-widget k-dropdown "
                                     + "k-header']//select[@data-role='dropdownlist']")
    private static WebElement itemsPerPageDropdown;

    @FindBy(how = How.CLASS_NAME, using = "userIdSelector")
    private static WebElement viewReportForDropDown;

    static {
        PageFactory.initElements(Driver.getDriver(), BasicReportPage.class);
    }

    /**
     * Gets the grid data in a main list of maps where each HashMap represents a row from the Report grid.
     *
     * @return List of maps of strings that contains all the Reporting custom grid data.
     */
    public static List<HashMap<String, Object>> getCustomGrid() {
        final List<WebElement> customGridHeaders = Driver.getDriver().findElements(By.xpath
                ("//div[@id='mainGrid']//table[@role='grid']/thead[@role='rowgroup']//th[@role='columnheader']"));
        final List<WebElement> customGridRows = customGrid.findElements(By.xpath(".//tbody[@role='rowgroup']//.//tr"));

        List<HashMap<String, Object>> gridData = new ArrayList<>();

        // Get the grid headers as string.
        List<String> gridHeaders = customGridHeaders.stream().map(WebElement::getText).collect(Collectors.toList());

        int rowsCount = customGridRows.size();          // Get the number of rows in the grid.
        int columnsCount = customGridHeaders.size();    // Get the number of columns in the grid.

        // Get the grid data from cells.
        for (int row = 0; row < rowsCount; row++) {
            // Get cells from current row.
            List<WebElement> currentRowCells = customGridRows.get(row).findElements(By.tagName("td"));

            /*
             * TODO: Review if current design to get the grid data and results from DB can be changed to use Map
             *       interface instead of HashMap implementation.
             */
            HashMap<String, Object> currentRow = new HashMap<>(columnsCount);

            // Save the row data from the cells
            for (int col = 0; col < columnsCount; col++) {
                currentRow.put(gridHeaders.get(col), currentRowCells.get(col).getText());
            }

            // Add the current row to our main list of maps where the data from the grid is stored.
            gridData.add(currentRow);
        }

        return gridData;
    }

    public static String getFromDate() {
        return fromInput.getAttribute("value");
    }

    public static String getToDate() {
        return toInput.getAttribute("value");
    }

    public static String getReportCreateTime() {
        return reportCreateTimeDropdown.getAttribute("value");
    }

    public static String getReportTitle() {
        return reportTitleLabel.getText();
    }

    /**
     * Gets the number of items per page to be displayed in the current dynamic report.
     *
     * @return String with the number of items per page.
     */
    public static String getItemsPerPage() {
        // Get the options from the customized dropdown.
        List<WebElement> dropDownOptions = itemsPerPageDropdown.findElements(By.tagName("option"));
        // Get the first selected item value.
        Optional<WebElement> result = dropDownOptions.stream().filter(option -> option.isSelected()).findFirst();
        return result.isPresent() ? result.get().getAttribute("value") : "";
    }

    public static void setCandidateID(String data) {
        SeleniumTest.clearAndSetText(candidateIDInput, data);
    }

    public static void setPackageName(String data) {
        SeleniumTest.clearAndSetText(packageInput, data);
    }

    public static void setToInput(String data) {
        SeleniumTest.clearAndSetText(toInput, data);
    }

    public static void setFromInput(String data) {
        SeleniumTest.clearAndSetText(fromInput, data);
    }

    /**
     * Selects the given date range from the "Report Create Time/Date" drop down in the dynamic reports.
     *
     * @param dateRange the date selection drop down attribute 'value' to be selected. It must be one of the following
     *                  valid values:
     *                  - "custom"
     *                  - "last-week"
     *                  - "this-week"
     *                  - "today"
     *                  - "yesterday"
     *                  - "last-seven-days"
     *                  - "last-thirty-days"
     *                  - "last-sixty-days"
     */
    public static void setReportDateRange(final String dateRange) {
        SeleniumTest.selectByValueFromDropDown(reportCreateTimeDropdown, dateRange);
    }

    public static void clickSearch() {
        SeleniumTest.click(searchBtn);
    }

    public static void clickClearAll() {
        SeleniumTest.click(clearAllLink);
    }

    public static void clickBackToReports() {
        SeleniumTest.click(backToReportsLink);
    }

    public static void clickMetricsDefinitions() {
        SeleniumTest.click(metricsDefinitionsLink);
    }

    public static void clickMetricsDefinitionsClose() {
        SeleniumTest.click(metricsDefinitionsClose);
    }

    public static void clickExportToExcel() {
        SeleniumTest.click(exportToExcelButton);
    }

    public static boolean isBackToReportsLinkDisplayed() {
        return backToReportsLink.isDisplayed();
    }

    public static boolean isFromInputDisplayed() {
        return fromInput.isDisplayed();
    }

    public static boolean isToInputDisplayed() {
        return toInput.isDisplayed();
    }

    public static boolean isReportCreateTimeDropdownDisplayed() {
        return reportCreateTimeDropdown.isDisplayed();
    }

    public static boolean isSearchBtnDisplayed() {
        return searchBtn.isDisplayed();
    }

    public static boolean isClearAllLinkDisplayed() {
        return clearAllLink.isDisplayed();
    }

    public static boolean isMetricsDefinitionsLinkDisplayed() {
        return metricsDefinitionsLink.isDisplayed();
    }

    public static boolean isExportToExcelButtonDisplayed() {
        return exportToExcelButton.isDisplayed();
    }

    public static boolean isReportGridFootDisplayed() {
        return reportGridFoot.isDisplayed();
    }

    /**
     * Verifies that the "View Report For" drop down is displayed.
     *
     * @return true if the "View Report For" drop down is displayed. Otherwise, false.
     */
    public static boolean isViewReportForDropDownDisplayed() {
        return viewReportForDropDown.isDisplayed();
    }

    /**
     * Verifies that the "Candidate ID" text input is displayed.
     *
     * @return true if the "Candidate ID" text input is displayed. Otherwise, false.
     */
    public static boolean isCandidateIDTextInputDisplayed() {
        return candidateIDInput.isDisplayed();
    }

    /**
     * Verifies that the "Package" text input is displayed.
     *
     * @return true if the "Package" text input is displayed. Otherwise, false.
     */
    public static boolean isPackageTextInputDisplayed() {
        return packageInput.isDisplayed();
    }

    /**
     * Model the valid items for the Date Range Selection dropdown.
     *
     * @author aserrano
     */
    public enum DateRangeSelection {

        CUSTOM_DATE_RANGE("custom", "Custom Date Range"),
        LAST_WEEK("last-week", "Last Week"),
        THIS_WEEK("this-week", "This Week"),
        TODAY("today", "Today"),
        YESTERDAY("yesterday", "Yesterday"),
        LAST_7_DAYS("last-seven-days", "Last 7 Days"),
        LAST_30_DAYS("last-thirty-days", "Last 30 Days"),
        LAST_60_DAYS("last-sixty-days", "Last 60 Days");

        private final String value;
        private final String displayedText;

        /**
         * Initialize the Date Range Selection dropdown 'value' attribute and displayed text for each valid item.
         *
         * @param value the attribute 'value' defined for each dropdown item.
         * @param visibleText the displayed text for each dropdown item.
         */
        DateRangeSelection(final String value, final String visibleText) {
            this.value = value;
            this.displayedText = visibleText;
        }

        /**
         * Gets the attribute 'value' for the valid dropdown item.
         *
         * @return the dropdown item attribute 'value'.
         */
        public String getValue() {
            return value;
        }

        /**
         * Gets the displayed text for the valid dropdown item.
         *
         * @return the dropdown item displayed text.
         */
        public String getDisplayedText() {
            return displayedText;
        }
    }

}