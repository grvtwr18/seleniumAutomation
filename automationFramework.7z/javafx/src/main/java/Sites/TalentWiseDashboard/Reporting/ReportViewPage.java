package Sites.TalentWiseDashboard.Reporting;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by vdavila on 8/17/17.
 */
public class ReportViewPage {

    //User Filters
    @FindBy(how = How.NAME, using = "filters[CandidateID][value]")
    private static WebElement candidateIDTextBox;

    @FindBy(how = How.NAME, using = "filters[uberform][value]")
    private static WebElement packageNameTextBox;

    @FindBy(how = How.NAME, using = "filters[CandidateID][value]")
    private static WebElement referenceCodeTextBox;

    @FindBy(how = How.NAME, using = "filters[CandidateID][value]")
    private static WebElement billingCodeTextBox;

    @FindBy(how = How.CLASS_NAME, using = "button")
    private static WebElement searchButton;

}
