package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

/**
 * Page object for report builder functionality
 *
 * @author rporras
 */
public class ReportBuilderPage extends CustomerPortalPage {

    @FindBy(how = How.XPATH, using = "//button[@class='saveReport actionButton primaryAction'][3]")
    private static WebElement saveBtn;

    @FindBy(how = How.XPATH, using = "//button[@class='saveReport actionButton primaryAction'][2]")
    private static WebElement saveAndActivateBtn;

    @FindBy(how = How.XPATH, using = "//button[@class='saveReport actionButton primaryAction'][1]")
    private static WebElement saveAndPreviewBtn;

    @FindBy(how = How.XPATH, using = "//button[@class='cancelReport actionButton secondaryAction']")
    private static WebElement cancelBtn;

    @FindBy(how = How.XPATH, using = "//div[@id='field_1']//i[@class='fa fa-trash']")
    private static WebElement deleteBtnPosition2;

    @FindBy(how = How.XPATH, using = "//th[2]//input[@class='k-textbox']")
    private static WebElement searchFieldsTxt;

    @FindBy(how = How.XPATH, using = "//button[@class='actionButton primaryAction']")
    private static WebElement refreshResultsBtn;

    @FindBy(how = How.ID, using = "add_chart_type")
    private static WebElement chartDropdown;

    @FindBy(how = How.ID, using = "addChartBtn")
    private static WebElement addChartBtn;

    @FindBy(how = How.XPATH, using = "//span[@class='ui-icon ui-icon-triangle-2-n-s']")
    private static WebElement widgetDropdown;

    @FindBy(how = How.XPATH, using = "//div[@id='fieldsGrid']//td[2]")
    private static WebElement searchFieldResult;

    @FindBy(how = How.XPATH, using = "//th[2]//button[@class='k-button k-button-icon']")
    private static WebElement clearResultBtn;

    @FindBy(how = How.ID, using = "fieldsContainer")
    private static WebElement fieldContainer;

    @FindBy(how = How.ID, using = "userFiltersContainer")
    private static WebElement userFilterContainer;

    @FindBy(how = How.ID, using = "hardFiltersContainer")
    private static WebElement hardFilterContainer;


    static {
        PageFactory.initElements(Driver.getDriver(), ReportBuilderPage.class);
    }

    public static String getSearchFieldResult() {
        return searchFieldResult.getText();
    }

    public static void setChartDropdown(String data) {
        SeleniumTest.clearAndSetText(chartDropdown, data);
    }

    public static void setSearchFieldsTxt(String data) {
        SeleniumTest.clearAndSetText(searchFieldsTxt, data);
        searchFieldsTxt.sendKeys(Keys.ENTER);
    }

    public static void setFieldAlias(String fieldNumber, String fieldAlias, String fieldFx) {

        String fieldAliasXPathPart1 = "//div[@id='field_";
        String fieldAliasXPathPart2 = "']//div[3]//input[@class='fields_alias fieldProperty']";

        String fieldFXXPathPart1 = "//div[@id='field_";
        String fieldFXXPathPart2 = "']//select[@class='fieldOptions fieldProperty']";

        SeleniumTest.clearAndSetText(By.xpath(fieldAliasXPathPart1 + fieldNumber + fieldAliasXPathPart2),
                                     fieldAlias);
        WebElement fxDropdown = Driver.getDriver().findElement(
                By.xpath(fieldFXXPathPart1 + fieldNumber + fieldFXXPathPart2));
        Select fxSelect = new Select(fxDropdown);
        fxSelect.selectByVisibleText(fieldFx);
    }

    public static void setFilterAlias(String filterNumber, String filterAlias) {

        String filterAliasXPathPart1 = "//div[@id='userFilter_";
        String filterAliasXPathPart2 = "']//div[2]//input[@class='userFilters_alias fieldProperty']";

        SeleniumTest.clearAndSetText(By.xpath(filterAliasXPathPart1 + filterNumber +
                                              filterAliasXPathPart2), filterAlias);
    }

    /**
     * Sets the Static Filter condition defined by the given arguments. This method applies only for the 0-index
     * position, which means, the first Static Filter to be configured.
     *
     * @param hardFilterIndex  the position (0-indexed) at which the Static Filter is located
     * @param hardFilterOption the option to be selected in the condition drop down
     * @param conditionValue   the condition value to be evaluated based on the selected option from the drop down
     */
    public static void setStaticFilterCondition(final int hardFilterIndex, final String hardFilterOption,
                                                final String conditionValue) {
        setStaticFilterCondition(hardFilterIndex, hardFilterOption, conditionValue, "");
    }

    /**
     * Sets the Static Filter condition defined by the given arguments. This method applies from the first position
     * and so on (1-index, ..., n-index).
     *
     * @param hardFilterIndex  the position (0-indexed) at which the Static Filter is located
     * @param hardFilterOption the option to be selected in the condition drop down
     * @param conditionValue   the condition value to be evaluated based on the selected option from the drop down
     * @param logicalOperator  the logical operator "AND", "OR" for the subsequent added conditions, it applies ONLY
     *                         from the first position and so on (1-index, ..., n-index).
     */
    public static void setStaticFilterCondition(final int hardFilterIndex, final String hardFilterOption,
                                                final String conditionValue, final String logicalOperator) {
        // Xpath to find the dynamic dropdown for Static Condition Option.
        String hardFilterDropDown =
                String.format("//div[@id='hardFilter_%d']/div[2]/select[@class='hardFiltersOptions']", hardFilterIndex);

        // Xpath to find the dynamic text input for the Static Condition Value.
        String hardFilterConditionTextInput =
                String.format("//div[@id='hardFilter_%d']/div[2]/input[@class='hardFiltersValue']", hardFilterIndex);

        // Get the actual web element.
        WebElement fxDropDown = Driver.getDriver().findElement(By.xpath(hardFilterDropDown));

        /*
         * Get the real web element, it looks like a drop down but it is a select! Then select the given filter
         * option by visible text.
         */
        Select fxSelect = new Select(fxDropDown);
        fxSelect.selectByVisibleText(hardFilterOption);

        // Set the given condition value.
        SeleniumTest.clearAndSetText(By.xpath(hardFilterConditionTextInput), conditionValue);

        /*
         * Logical operator applies only from the position 1 of the static filter.
         *
         * Get the index used to locate the logical operators, "AND" defined by index=1, "OR" defined by index=2.
         *
         * Initialize operator type with 0 which is not valid, however, let's leverage the responsibility to know if
         * the element is present or not to Selenium rather than throwing an exception.
         */
        if (!"".equals(logicalOperator) && hardFilterIndex > 0) {
            int operatorType = 0;

            switch(logicalOperator.toUpperCase()) {
                case "AND":
                    operatorType = 1;
                    break;
                case "OR":
                    operatorType = 2;
                    break;
            }

            // Xpath to find the logical operator "AND", "OR".
            String logicalOperatorElement =
                    String.format("//div[@id='hardFilter_%d']/div[@class='logicalOperators']/label[%d]",
                                  hardFilterIndex, operatorType);

            // Check the logical operator with the given value.
            SeleniumTest.click(By.xpath(logicalOperatorElement));
        }
    }

    public static void dragAndDropField() {
        (new Actions(Driver.getDriver())).dragAndDrop(searchFieldResult, fieldContainer).perform();
    }

    public static void dragAndDropUserFilter() {
        (new Actions(Driver.getDriver())).dragAndDrop(searchFieldResult, userFilterContainer).perform();
    }

    /**
     * Drags the first element result of a search from the "Search fields" input to the "Static filters" section.
     */
    public static void dragAndDropStaticFilter() {
        (new Actions(Driver.getDriver())).dragAndDrop(searchFieldResult, hardFilterContainer).perform();
    }

    public static void clickClearResultBtn() {
        SeleniumTest.click(clearResultBtn);
    }

    public static void clickSave() {
        SeleniumTest.click(saveBtn);
    }

    public static void clickSaveAndActivate() {
        SeleniumTest.click(saveAndActivateBtn);
    }

    public static void clickDeletePosition2() {
        SeleniumTest.click(deleteBtnPosition2);
    }

    public static void clickSaveAndPreview() {
        SeleniumTest.click(saveAndPreviewBtn);
    }

    public static void clickCancel() {
        SeleniumTest.click(cancelBtn);
    }

    public static void clickRefreshResults() {
        SeleniumTest.click(refreshResultsBtn);
    }

    public static void clickAddChart() {
        SeleniumTest.click(addChartBtn);
    }

    public static boolean isChartDropdownDisplayed() {
        return chartDropdown.isDisplayed();
    }

    public static boolean isSearchFieldsTxtDisplayed() {
        return searchFieldsTxt.isDisplayed();
    }

    public static boolean isSaveBtnDisplayed() {
        return saveBtn.isDisplayed();
    }

    public static boolean isSaveAndActivateBtnDisplayed() {
        return saveAndActivateBtn.isDisplayed();
    }

    public static boolean isSaveAndPreviewBtnDisplayed() {
        return saveAndPreviewBtn.isDisplayed();
    }

    public static boolean isCancelBtnDisplayed() {
        return cancelBtn.isDisplayed();
    }

    public static boolean isAddChartBtnDisplayed() {
        return addChartBtn.isDisplayed();
    }
}