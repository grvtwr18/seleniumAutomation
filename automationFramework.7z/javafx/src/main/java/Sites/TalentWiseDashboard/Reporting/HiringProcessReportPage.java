package Sites.TalentWiseDashboard.Reporting;

import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Created by qli on 5/12/17.
 */
public class HiringProcessReportPage {
    @FindBy(how = How.ID, using = "isHistory")
    private static WebElement selectIsHistory;

    @FindBy(how = How.ID, using = "processForm")
    private static WebElement selectProcessForm;

    @FindBy(how = How.CLASS_NAME, using = "button")
    private static WebElement buttonGo;

    @FindBy(how = How.ID, using = "workflowIds")
    private static WebElement workflowIds;

    @FindBy(how = How.ID, using = "dbIdContentInner")
    private static WebElement reportSection;

    @FindBy(how = How.ID, using = "formId")
    private static WebElement formId;

    static {
        PageFactory.initElements(Driver.getDriver(), HiringProcessReportPage.class);
    }

    /**
     * Click 'Go' button
     */
    public static void clickGoButton() {
        buttonGo.click();
    }

    /**
     * select option for ViewReportFor dropdown list
     * @param value
     */
    public static void selectViewReportFor(String value) {
        SeleniumTest.selectByValueFromDropDown(selectIsHistory, value);
    }

    /**
     * Select option for ViewBy dropdown list
     * @param value
     */
    public static void selectViewBy(String value) {
        SeleniumTest.selectByValueFromDropDown(selectProcessForm, value);
    }

    public static String getGoButtonValue() {
        return buttonGo.getAttribute("value");
    }

    public static WebElement getReportSection() {
        return reportSection;
    }

    /**
     * hide those areas which contains unpredictable data
     * @param isFormIdPresent
     */
    public static void hideVariableElements(boolean isFormIdPresent) {
        //List<WebElement> kendogridCells = Driver.getDriver().findElements(By.xpath("//*[@id=\"dbIdContentInner\"]/*/*/table/tbody/tr/td"));
        List<WebElement> kendogridCells = Driver.getDriver().findElements(By.xpath("//table[@class='report']/.//td"));
        if (isFormIdPresent) {
            BodyTextHelper.hideElement(formId);
        } else {
            BodyTextHelper.hideElement(workflowIds);
        }
        for (WebElement cell : kendogridCells) {
            BodyTextHelper.hideElement(cell);
        }
    }

}
