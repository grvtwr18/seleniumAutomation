package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import java.util.List;
import org.apache.commons.lang.SystemUtils;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.testng.Assert;

/**
 * Page object that represents the Invoices and Statements page on the TalentWise Dashboard website (Ex. "https://talentwise.dvm-eelefson1.sea.talentwise.com/screening/billing.php?view=invoices").
 * @author eelefson
 */
public class InvoicesAndStatementsPage extends CustomerPortalPage {
	public ReportingTabs tabs;
	
	/**
	 * Constructs a new Invoices and Statements page object.
	 */
    public InvoicesAndStatementsPage() {
        this.tabs = PageFactory.initElements(Driver.getDriver(), ReportingTabs.class);
    }

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final By invoiceReportPDF = By.xpath(".//tr[2]//td[@id='pdfImage']//a");

	private final By billingReportPDF = By.xpath(".//tr[2]//td[contains(@class,'statementBillingAcumatica')]/a[1]");

	private final By billingReportExcel = By.xpath(".//tr[2]//td[contains(@class,'statementBillingAcumatica')]/a[2]");

	public boolean isInvoiceReportPDFVisible()
	{
		return SeleniumTest.isElementVisibleNoWaiting(invoiceReportPDF);
	}

	public void openInvoiceReportPDF()
	{
		logger.info("Opening Invoice PDF");
		SeleniumTest.waitForElementToBeClickable(invoiceReportPDF,10);
		SeleniumTest.click(invoiceReportPDF);
	}

	public boolean isGivenContentVisiblePDF(String str)
	{
		//PDF take time to load hence i preferred using isElementVisible instead of using isElementVisibleNoWaiting
		SeleniumTest.waitForPageLoad();
		return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//div[contains(text(),'"+str+"')]"));
	}

	public boolean isBillingReportPDFVisible()
	{
		return SeleniumTest.isElementVisibleNoWaiting(billingReportPDF);
	}

	public void openBillingReportPDF()
	{
		logger.info("Opening Billing Reports");
		SeleniumTest.click(billingReportPDF);
	}

	public boolean isBillingReportExcelVisible()
	{
		return SeleniumTest.isElementVisibleNoWaiting(billingReportExcel);
	}

	public void downloadBillingReportExcel() {
		logger.info("Downloading Billing Report Excel");
		if (!deleteDownloadedTaskListExcelFiles()) {
			logger.info("Not all Files were deleted!  TEST MAY FAIL!");
		}
		openBillingCodeExcel();
		WaitUntil.waitUntil(() -> {
			return doesDownloadedExcelFileExist();
		});
	}

	public boolean deleteDownloadedTaskListExcelFiles() {
		File[] children = getDownloadedTaskListExcelFiles();
		boolean deleted = false;
		int counter = 0;
		for (File f : children) {
			deleted = f.delete();
			if (!deleted) {
				counter++;
			}
		}
		WaitUntil.waitUntil(() -> {
			return !doesDownloadedExcelFileExist();
		});
		return counter == 0;
	}

	public void openBillingCodeExcel()
	{
		SeleniumTest.click(billingReportExcel);
	}

	public boolean doesDownloadedExcelFileExist() {
		File[] children = getDownloadedTaskListExcelFiles();
		return children.length != 0;
	}

	public File[] getDownloadedTaskListExcelFiles() {
		File parent = null;

		if (!SystemUtils.IS_OS_WINDOWS) {
			parent = new File(System.getProperty("user.home") + "/Downloads");
		} else {
			parent = new File(System.getenv("USERPROFILE") + "\\Downloads");
		}
		return parent != null ? parent.listFiles(file -> {
			return file.getName().toLowerCase().contains("billing_report.xlsx");
		}) : new File[0];
	}

	public boolean isContentPresentInExcel() throws IOException {
		String strFilePath = System.getenv("USERPROFILE") + "\\Downloads\\";
		String strFileName = "billing_report.xlsx";
		String strFullPath = strFilePath+strFileName;
		File downloadedFile =new File(strFullPath);
		XSSFWorkbook workbook = null;
		FileInputStream inputStream = null;
		if(downloadedFile.exists()){
			inputStream = new FileInputStream(strFullPath);
			workbook = new XSSFWorkbook(inputStream);
		}
		// Return first sheet from the XLSX workbook
		XSSFSheet mySheet = workbook.getSheetAt(0);

		int rowCount = mySheet.getLastRowNum() - mySheet.getFirstRowNum();
		for (int i = 0; i < rowCount + 1; i++) {
			Row row = mySheet.getRow(i);
			for (int j = 0; j < row.getLastCellNum(); j++) {
				if (!row.getCell(j).getStringCellValue().isEmpty()) {
					logger.info("Data is displayed in excel "+row.getCell(j).getStringCellValue());
					return true;
				}
			}
		}
	  return false;
	}


	private final By reportTable = By.xpath(".//*[@class='dbGrid']/table");

	private final By noInvoiceFoundMessage = By.className("dbMessage");

	@FindBy(how = How.ID,using = "month")
	private WebElement monthDropDownLocator;

	@FindBy(how = How.XPATH,using = ".//*[contains(@class,'statementSearchButton')]")
	private WebElement goButton;

	@FindBy(how = How.XPATH, using = ".//*[@class='dbGrid']/table//tr")
	private List<WebElement> resultedTableRecordsCount;

	@FindBy(how = How.XPATH,using = ".//*[@id='dbpaginator']/div[1]")
	private WebElement noOfRecords;

	@FindBy(how = How.NAME,using = "billingcode")
	private WebElement billingCodeDropDownLocator;

	@FindBy(how = How.NAME,using = "grouping")
	private WebElement groupByDropDownLocator;

    public int getMonthFilterValuesCount()
	{
		return new Select(monthDropDownLocator).getOptions().size();
	}

	public void monthFilter(int i)
	{
		SeleniumTest.selectByDropDownIndexFromDropDown(monthDropDownLocator,i);
		SeleniumTest.click(goButton);
		SeleniumTest.waitForPageLoad();
	}

	public String validateResultedTable()
	{
		String strMessage;
		int count=0;
		if(SeleniumTest.isElementVisibleNoWaiting(reportTable))
		{
			String strCount = SeleniumTest.getText(noOfRecords);
			String[] strActualCount = strCount.split(" ");
			count = Integer.parseInt(strActualCount[strActualCount.length-1]);
			int Tablecount = resultedTableRecordsCount.size();
			int pageCount = count/10;
			int minusCount = pageCount;
			int RpageCount = count%10;
			if(RpageCount!=0)
			{
				pageCount = pageCount +1;
			}
			while (pageCount!=1)
			{
				SeleniumTest.click(By.linkText(String.valueOf(pageCount)));
				Tablecount = Tablecount+resultedTableRecordsCount.size();
				pageCount--;
			}
			return String.valueOf(count);
		}
		else if(SeleniumTest.isElementVisibleNoWaiting(noInvoiceFoundMessage))
		{
			strMessage = SeleniumTest.getTextByLocator(noInvoiceFoundMessage);
			return strMessage;
		}
		return "Error";
	}

	public int getBillingCodeVlauesCount()
	{
		return new Select(billingCodeDropDownLocator).getOptions().size();
	}

	public void billingCodeFilter(int i)
	{
		SeleniumTest.selectByDropDownIndexFromDropDown(monthDropDownLocator,0);
		SeleniumTest.selectByDropDownIndexFromDropDown(billingCodeDropDownLocator,i);
		SeleniumTest.click(goButton);
		SeleniumTest.waitForPageLoad();
	}

	public int getGroupByVlauesCount()
	{
		return new Select(groupByDropDownLocator).getOptions().size();
	}

	public void groupByFilter(int i)
	{
		SeleniumTest.selectByDropDownIndexFromDropDown(billingCodeDropDownLocator,0);
		SeleniumTest.selectByDropDownIndexFromDropDown(groupByDropDownLocator,i);
		SeleniumTest.click(goButton);
		SeleniumTest.waitForPageLoad();
	}


}