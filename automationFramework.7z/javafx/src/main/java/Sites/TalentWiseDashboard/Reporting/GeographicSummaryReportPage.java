package Sites.TalentWiseDashboard.Reporting;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the geographic summary report page on the TalentWise Dashboard website (Ex.
 * "https://dvm-rporras1.aws.talentwise.com/screening/billing.php?ReportUIV2=1&view=report-view&ReportID=172").
 *
 * @author rporras
 */
public class GeographicSummaryReportPage extends BasicReportPage {

    @FindBy(how = How.ID, using = "exportChoropleth_0")
    private static WebElement turnaroundTimeforUSCountiesGeochartDropdown;

    @FindBy(how = How.ID, using = "exportChoropleth_1")
    private static WebElement turnaroundTimeforUSStatesGeochartDropdown;

    @FindBy(how = How.ID, using = "exportChoropleth_2")
    private static WebElement candidateVolumebyUSCountiesGeochartDropdown;

    static {
        PageFactory.initElements(Driver.getDriver(), GeographicSummaryReportPage.class);
    }

    public static String getTurnaroundTimeForUSCountiesGeochartDropdown() {
        return turnaroundTimeforUSCountiesGeochartDropdown.getAttribute("value");
    }

    public static String getTurnaroundTimeForUSStatesGeochartDropdown() {
        return turnaroundTimeforUSStatesGeochartDropdown.getAttribute("value");
    }

    public static String getCandidateVolumeByUSCountiesGeochartDropdown() {
        return candidateVolumebyUSCountiesGeochartDropdown.getAttribute("value");
    }

    public static void setTurnaroundTimeForUSCountiesGeochartDropdown(String data) {
        SeleniumTest.clearAndSetText(turnaroundTimeforUSCountiesGeochartDropdown, data);
    }

    public static void setTurnaroundTimeForUSStatesGeochartDropdown(String data) {
        SeleniumTest.clearAndSetText(turnaroundTimeforUSStatesGeochartDropdown, data);
    }

    public static void setCandidateVolumeCyUSCountiesGeochartDropdown(String data) {
        SeleniumTest.clearAndSetText(candidateVolumebyUSCountiesGeochartDropdown, data);
    }
}
