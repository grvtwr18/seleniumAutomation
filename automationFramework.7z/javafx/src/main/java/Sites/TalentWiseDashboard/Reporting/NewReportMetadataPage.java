package Sites.TalentWiseDashboard.Reporting;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by rporras on 8/7/17.
 */
public class NewReportMetadataPage {


    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    private static WebElement saveButton;

    @FindBy(how = How.NAME, using = "ReportName")
    private static WebElement reportNameInput;

    @FindBy(how = How.NAME, using = "Description")
    private static WebElement descriptionInput;

    @FindBy(how = How.XPATH, using = "//label[@for='CategoryID']/following-sibling::span/span")
    private static WebElement categoryDropdown;

    @FindBy(how = How.ID, using = "Link")
    private static WebElement staticLinkInput;

    @FindBy(how = How.XPATH, using = "//label[@for='ReportStatus']/following-sibling::span/span")
    private static WebElement reportAvailabilityDropdown;

    @FindBy(how = How.XPATH, using = "//label[@for='ReportRule']/following-sibling::span/span")
    private static WebElement reportRulesDropdown;

    public static String getCategory() {
        return categoryDropdown.getText();
    }

    public static void selectCategory(String selection) {
        selectByVisibleTextFromKendoDropDown(categoryDropdown, "CategoryID-list", selection);
    }

    public static String getReportAvailability() {
        return reportAvailabilityDropdown.getText();
    }

    public static void selectReportAvailability(String selection) {
        selectByVisibleTextFromKendoDropDown(reportAvailabilityDropdown, "ReportStatus-list", selection);
    }

    public static String getReportRules() {
        return reportRulesDropdown.getText();
    }

    public static void selectReportRules(String selection) {
        selectByVisibleTextFromKendoDropDown(reportRulesDropdown, "ReportRule-list", selection);
    }

    public static String getReportName() {
        return reportNameInput.getAttribute("value");
    }

    public static void setReportName(String data) {
        SeleniumTest.clearAndSetText(reportNameInput, data);
    }

    public static String getDescription() {
        return descriptionInput.getAttribute("value");
    }

    public static void setDescription(String data) {
        SeleniumTest.clearAndSetText(descriptionInput, data);
    }

    public static String getStaticLink() {
        return staticLinkInput.getAttribute("value");
    }

    public static void setStaticLink(String data) {
        SeleniumTest.clearAndSetText(staticLinkInput, data);
    }

    public static void clickSave() {
        SeleniumTest.click(saveButton);
    }

    /**
     * Selects by visible text the given value from a kendo drop down.
     *
     * NOTE: This method is a workaround of SeleniumTest.selectByValueFromDropDown() method. This "Report Metadata" page
     * is using a kendo dropdown (apparently not used in any other place) which is composed by several web elements.
     *
     * We might need to review if in the future if SeleniumTest.selectByValueFromDropDown() can be enhanced to handle
     * those kendo dropdowns. For now, since this is the only page using them, it is ok having this method here.
     *
     * @param kendoDropDown from which value is going to be selected.
     * @param divIdentifier for main div web element which contains the kendo dropdown items.
     * @param valueToSelect string value to be selected.
     */
    private static void selectByVisibleTextFromKendoDropDown(final WebElement kendoDropDown, final String
            divIdentifier, final String valueToSelect) {
        // Click on the kendo dropdow web element to display its available options.
        SeleniumTest.click(kendoDropDown);
        // Wait for the kendo dropdown div web element which contains the dropdown items.
        SeleniumTest.waitForElementVisible(By.id(divIdentifier));
        // Find the element to be selected by visible text.
        WebElement kendoDropDownItem = Driver.getDriver().findElement(By.xpath("//li[text()='" + valueToSelect + "']"));
        // Click on the element to be selected to actually select it.
        SeleniumTest.clickUntilConditionMet(kendoDropDownItem, () -> kendoDropDownItem.isDisplayed());
    }
}
