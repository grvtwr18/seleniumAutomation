package Sites.TalentWiseDashboard.Reporting;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class CandidateExportPageHelper {

    private CandidateExportPage page;

    public CandidateExportPageHelper(CandidateExportPage candidateExportPage) {
        page = candidateExportPage;
    }

    /*
    * Method to click and get the search results from the table.
    **/
    public LinkedHashMap<String, String> SearchAndReturnResults() {
        page.clickSearch();
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForJQueryAjaxDone();
        LinkedHashMap<String, String> rows = new LinkedHashMap<String, String>();
        LinkedHashMap<String, String> tablelist = new LinkedHashMap<>();
        tablelist = page.getSearchResultsList();
        return tablelist;
    }

    /*
     * Method to click and save new search.
     **/
    public void saveNewSearch(String searchName) {
        page.clickSaveNewSearchButton();
        page.typeTextInSavedSearchTextField(searchName);
        page.clickSaveNewSearch();
        page.clickSavedSearchDropdown();
    }
}