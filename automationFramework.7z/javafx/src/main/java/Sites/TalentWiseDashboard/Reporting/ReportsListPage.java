package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by jpflager on 7/3/17.
 */
public class ReportsListPage extends CustomerPortalPage {

    private static final Logger staticLogger = LoggerFactory.getLogger(ReportsListPage.class.getName());

    @FindBy(how = How.ID, using = "newReportBtn")
    private static WebElement createNewButton;

    @FindBy(how = How.ID, using = "reportListSearchBox")
    private static WebElement searchInputBox;

    static {
        PageFactory.initElements(Driver.getDriver(), ReportsListPage.class);
    }

    public static NewReportMetadataPage createNewButtonClick() {
        SeleniumTest.click(createNewButton);
        return PageFactory.initElements(Driver.getDriver(), NewReportMetadataPage.class);
    }

    /**
     * Clicks on the report name link for the given report.
     *
     * @param report the report
     */
    public static void clickReportNameLink(Reports report) {
        // TODO: Sometimes this page has been observed to not show reports; it finishes loading to just blank white,
        // after Sites.TalentWiseDashboard.Helpers.Header.clickReportingTab() ...
        final By locator =
                By.xpath("//a[contains(@href, 'screening/billing.php?view=" + report.getLinkTextViewQueryParam() + "')]");
        WebElement link = null;

        try {
            link = WaitUntil.waitUntil(ExpectedConditions.presenceOfElementLocated(locator));
        } catch (NoSuchElementException nse) {
            staticLogger.warn("Attempting to click Report Name Link \"{}\" that's just not showing, so refreshing page to try again.",
                    report.getLinkTextViewQueryParam());
            SeleniumTest.refreshCurrentPage();
            link = WaitUntil.waitUntil(ExpectedConditions.presenceOfElementLocated(locator));
        }

        SeleniumTest.click(link);
    }

    public static NewReportMetadataPage clickEditReportMetadata(String reportName) {
        SeleniumTest.click(By.xpath("//a[text()='" + reportName + "']/parent::td/following-sibling::td[3]/div/a"));
        return PageFactory.initElements(Driver.getDriver(), NewReportMetadataPage.class);
    }

    public static NewReportMetadataPage clickDesignReport(String reportName) {
        SeleniumTest.click(By.xpath("//a[text()='" + reportName + "']/parent::td/following-sibling::td[3]/div/a[2]"));
        waitForLoadingImageNotPresent();
        return PageFactory.initElements(Driver.getDriver(), NewReportMetadataPage.class);
    }

    public static NewReportMetadataPage clickReportLink(String reportName) {
        SeleniumTest.click(By.xpath("//a[text()='" + reportName + "']"));
        waitForLoadingImageNotPresent();
        return PageFactory.initElements(Driver.getDriver(), NewReportMetadataPage.class);
    }

    public static void searchReport(String data) {
        SeleniumTest.clearAndSetText(searchInputBox, data);
    }

    public static String getSearchReportText() {
       return searchInputBox.getAttribute("value");
    }

    /**
     * Waits for loading image web element to go away.
     */
    public static void waitForLoadingImageNotPresent() {
        SeleniumTest.waitForElementNotPresent(By.className("k-loading-image"));
    }

    /**
     * Enumeration for (standard! customs should go elsewhere) reports on the Reports list page.
     */
    public enum Reports {
        BILLING_REPORT("billing"),
        CANDIDATE_EXPORT("export"),
        DRUG_TESTING_AND_PHYSICALS("ohs"),
        FORM_I9_EXPIRATION("i9reverify"),
        HIRING_PROCESS_REPORT("hpm"),
        I9_EVERIFY("everify"),
        INVOICES_AND_STATEMENTS("invoices"),
        SUMMARY_REPORT("summary"),
        TURNAROUND_REPORT("turnaround");

        private String linkTextViewQueryParam;

        Reports(String linkTextViewQueryParam) {
            this.linkTextViewQueryParam = linkTextViewQueryParam;
        }

        public String getLinkTextViewQueryParam() {
            return this.linkTextViewQueryParam;
        }

    }

    public static InvoicesAndStatementsPage clickReportLink(String reportName,Class<? extends InvoicesAndStatementsPage> returnedClass) {
        SeleniumTest.click(By.xpath("//a[text()='" + reportName + "']"));
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static BillingReportPage clickBillingCodeReportLink(String reportName) {
        SeleniumTest.click(By.xpath("//a[text()='" + reportName + "']"));
        return PageFactory.initElements(Driver.getDriver(), BillingReportPage.class);
    }
}
