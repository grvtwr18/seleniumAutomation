package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Summary Report page on the TalentWise Dashboard website (Ex. "https://talentwise.dvm-eelefson1.sea.talentwise.com/screening/billing.php?view=summary").
 * @author eelefson with some Rporras
 *
 * TODO: ideally should extend a ReportingPage abstract class that handles the ReportingTabs in here; that in turn would
 * extend CustomerPortal Page.
 */
public class SummaryReportPage extends CustomerPortalPage {

    @FindBy(how = How.XPATH, using = "//*[@id='summary']/table/tbody")
    private static WebElement report;

    @FindBy(how = How.ID, using = "dbIdContentInner")
    private static WebElement summaryReportSection;

    @FindBy(how = How.ID, using = "acct")
    private static WebElement viewReportForSelect;

    @FindBy(how = How.ID, using = "statusDate")
    protected static WebElement statusDateRangeSelect;

    @FindBy(how = How.ID, using = "jdp_statusDateFrom")
    protected static WebElement fromDatePicker;

    @FindBy(how = How.ID, using = "jdp_statusDateTo")
    protected static WebElement toDatePicker;

    @FindBy(how = How.CLASS_NAME, using = "button")
    private static WebElement searchBtn;

	public ReportingTabs tabs;
	
	/**
	 * Constructs a new Summary Report page object.
	 */
    public SummaryReportPage() {
        this.tabs = PageFactory.initElements(Driver.getDriver(), ReportingTabs.class);
    }

    static {
        PageFactory.initElements(Driver.getDriver(), SummaryReportPage.class);
    }

    public static WebElement getSummaryReportSection() {
        return summaryReportSection;
    }

    public static void hideVariableElements() {
        BodyTextHelper.hideElement(report);
        BodyTextHelper.hideElement(viewReportForSelect);
    }


    /**
     * 1 = custom, 2 - last week, 3 = this week, etc.
     * TODO: consider an enum
     * @param value
     */
    public static void selectDateRangeByValue(String value) {
        SeleniumTest.selectByStartOfValueFromDropDown(statusDateRangeSelect, value);
    }

    public static String getFromDate() {
        return fromDatePicker.getAttribute("value");
    }

    public static String getToDate() {
        return toDatePicker.getAttribute("value");
    }

    public static String getFromPlaceholder() {
        return fromDatePicker.getAttribute("placeholder");
    }

    public static String getToPlaceholder() {
        return toDatePicker.getAttribute("placeholder");
    }

    public static String getSearchButtonValue(){
        return searchBtn.getAttribute("value");
    }

    public static void setToInput(String data) {
        SeleniumTest.clearAndSetText(toDatePicker, data);
    }

    public static void setFromInput(String data) {
        SeleniumTest.clearAndSetText(fromDatePicker, data);
    }

}
