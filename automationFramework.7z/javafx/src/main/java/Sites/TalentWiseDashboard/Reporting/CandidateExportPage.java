package Sites.TalentWiseDashboard.Reporting;

import Sites.Site;
import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import Sites.TalentWiseDashboard.Search.SearchPages;
import Sites.URL;
import TWFramework.SeleniumTest;
import TWFramework.TableHelper;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.apache.commons.lang.SystemUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jgupta on 8/17/2015.
 * <p>
 * TODO: ideally should extend a ReportingPage abstract class that handles the ReportingTabs in here; that in turn would
 * extend CustomerPortal Page. Search functionality should go elsewhere.
 */
public class CandidateExportPage extends SearchPages {

    protected static final Logger staticLogger = LoggerFactory.getLogger(CandidateExportPage.class);

    private String homepageUrl = "/screening/billing.php?view=export&";

    public Header header;
    public Footer footer;
    public Sidebar sidebar;
    public ReportingTabs tabs;

    @FindBy(how = How.CLASS_NAME, using = "dbMessage")
    private WebElement noCandidatesToExportMessage;

    @FindBy(how = How.CSS, using = "button:nth(3)")
    private WebElement statusDropDown;

    @FindBy(how = How.CSS, using = "button:nth(4)")
    private WebElement resultDropDown;

    @FindBy(how = How.ID, using = "jdp_statusDateFrom")
    private WebElement statusDateFrom;

    @FindBy(how = How.ID, using = "jdp_statusDateTo")
    private WebElement statusDateTo;

    @FindBy(how = How.ID, using = "candidateCreation")
    private WebElement candidateCreationDropDown;

    @FindBy(how = How.ID, using = "jdp_candidateCreationFrom")
    private WebElement candidateCreationFromDate;

    @FindBy(how = How.ID, using = "jdp_candidateCreationTo")
    private WebElement candidateCreationToDate;

    @FindBy(how = How.ID, using = "lastModified")
    private Select lastModifiedDateDropDown;

    @FindBy(how = How.ID, using = "jdp_lastModifiedFrom")
    private WebElement lastModifiedFromDate;

    @FindBy(how = How.ID, using = "jdp_lastModifiedTo")
    private WebElement lastModifiedToDate;

    @FindBy(how = How.ID, using = "startDate")
    private WebElement candidateStartDateDropDown;

    @FindBy(how = How.ID, using = "jdp_startDateFrom")
    private WebElement candidateStartDateFrom;

    @FindBy(how = How.ID, using = "jdp_startDateTo")
    private WebElement candidateStartDateTo;

    @FindBy(how = How.ID, using = "aDeselectAll")
    private WebElement deselectAllLink;

    @FindBy(how = How.ID, using = "checkbox_export_profile")
    private WebElement profileCheckbox;
    //@FindBy(how = How.XPATH, using = "")
    //private WebElement profileCheckbox;


    @FindBy(how = How.ID, using = "checkbox_export_eeo")
    private WebElement EEOCheckbox;

    @FindBy(how = How.ID, using = "checkbox_export_i9_latest")
    private WebElement mostRecentI9Checkbox;

    @FindBy(how = How.ID, using = "checkbox_export_i9_all")
    private WebElement allI9Checkbox;

    @FindBy(how = How.ID, using = "checkbox_export_tax_federal")
    private WebElement federalIncomeTaxWitholdingCheckbox;

    @FindBy(how = How.ID, using = "checkbox_export_tax_state")
    private WebElement stateAndLocalIncomeTaxWithholdingCheckbox;

    @FindBy(how = How.ID, using = "checkbox_package_status")
    private WebElement packageStatusCheckbox;

    @FindBy(how = How.ID, using = "checkbox_export_additional_package_status_detail")
    private WebElement additionalPackageCheckbox;

    @FindBy(how = How.ID, using = "checkbox_export_request_level_detail")
    private WebElement requestLevelCheckbox;

    @FindBy(how = How.ID, using = "checkbox_export_mvr")
    private WebElement mvrCheckbox;

    @FindBy(how = How.CSS, using = "input[value='Search']")
    private WebElement searchButton;

    @FindBy(how = How.ID, using = "saveSearch")
    private Select selectSavedViewDropDown;

    @FindBy(how = How.XPATH, using = "//a[contains(@href,'screening/billing')][contains(@href, 'view=export')]")
    private WebElement downloadInExcelFormatLink;

    @FindBy(how = How.CLASS_NAME, using = "report")
    public WebElement reportTable;

    @FindBy(how = How.LINK_TEXT, using = "30")
    private WebElement thirtyLink;

    @FindBy(how = How.CSS, using = "#savedSearchWidgets > div.field.multiselectField > button")
    private WebElement savedSearchDropdown;

    @FindBy(how = How.ID, using = "dbpaginator")
    private WebElement pageCount;

    @FindBy(how = How.ID, using = "search-name-input")
    private WebElement savedSearchInput;

    @FindBy(how = How.ID, using = "savedSearchNewSearchBtn")
    private WebElement saveNewSearchButton;

    @FindBy(how = How.XPATH, using = "//*[@id='dbpaginator']//*[@class='count']")
    private static WebElement recordcount;

    @FindBy(how = How.XPATH, using = ".//*[@class='report']//tr//td[1]")
    private static List<WebElement> recordCandidateIDList;

    @FindBy(how = How.XPATH, using = ".//*[@class='report']//tr//td[5]")
    private static List<WebElement> recordCandidateLastNameList;

    @FindBy(how = How.XPATH, using = ".//*[@class='report']//tr//td[6]")
    private static List<WebElement> recordCandidateFirstNameList;

    @FindBy(how = How.XPATH, using = ".//*[@class='report']//tr//td[7]")
    private static List<WebElement> recordCandidateMiddleNameList;

    @FindBy(how = How.XPATH, using = ".//*[@class='report']//tr//td[21]")
    private static List<WebElement> recordCandidateEmailAddressList;

    @FindBy(how = How.XPATH, using = ".//*[@class='report']//tr//td[24]")
    private static List<WebElement> recordCandidateStatesLivedInIndicatorList;

    @FindBy(how = How.XPATH, using = ".//*[@class='report']//tr//td[25]")
    private static List<WebElement> recordCandidateStatesWorkedInIndicatorList;

    protected static final Logger logger = LoggerFactory.getLogger("CandidateExportPage");

    /**
     * Constructs a new Candidate Export page object.
     */
    public CandidateExportPage(boolean usePseudoLocale) {
        if (usePseudoLocale) {
            homepageUrl += "?locale=qps-PLOC";
        }

        this.tabs = PageFactory.initElements(Driver.getDriver(), ReportingTabs.class);
        this.initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    /**
     * Navigates to the Admin Tools | Workflows page using a QA environment test user account
     * and then calls PageFactory.initElements.
     */
    public CandidateExportPage navigateTo() {
        SeleniumTest.navigateToUrl(URL.getURL(Site.CUSTOMER_DASHBOARD) + homepageUrl);
        SeleniumTest.waitForPageLoadToComplete();
        this.initializePageFactory();
        return this;
    }

    /**
     * Navigates to the Admin portal with a QA environment admin account, then proxies into a test user account,
     * then navigates to the Admin Tools | Workflows page and calls PageFactory.initElements.
     */
    public void navigateToProxied(int customerUserId) {
        Driver.getDriver().get(URL.getURL(Sites.Site.ADMIN_CONSOLE) +
                homepageUrl + "&OverrideUserID=" + Integer.toString(customerUserId));
        //Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + homepageUrl);
        this.initializePageFactory();
    }

    public static void clickClearAll() {
        logger.info("Clicking Clear All");
        SeleniumTest.click(clearAllLink);
    }

    public void clickDeselectAll() {
        logger.info("Clicking Deselect All");
        SeleniumTest.click(deselectAllLink);
    }

    /**
     * Select values from Hiring Processes dropdown.
     */
    public void selectFromHiringProcessesDropDown(String... value) {
        Driver.getDriver().findElement(By.xpath("//form//div/label[text()='Hiring Process(es)']/following-sibling::button")).click();
        checkValues(value);
        ((HasInputDevices) Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    /**
     * Select values from Position dropdown.
     */
    public void selectFromPositionDropDown(String... value) {
        Driver.getDriver().findElement(By.xpath("//form//div/label[text()='PluralPositionLabel2']/following-sibling::button")).click();
        checkValues(value);
        ((HasInputDevices) Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    /**
     * Select values from Package(s) dropdown.
     */
    public void selectValueFromPackagesDropDown(String... value) {
        Driver.getDriver().findElement(By.xpath("//form//div/label[text()='Package(s)']/following-sibling::button")).click();
        SeleniumTest.waitForPageLoad();
        checkValues(value);
        ((HasInputDevices) Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    /**
     * Select values from Status(es) dropdown.
     */
    public void selectValueFromStatusesDropDown(String... value) {
        SeleniumTest.click(By.xpath("//form//div/label[text()='Status(es)']/following-sibling::button"));
        checkValues(value);
        ((HasInputDevices) Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    /**
     * Select values from Result(s) dropdown.
     */
    public void selectValueFromResultsDropDown(String... value) {
        resultDropDown.click();
        checkValues(value);
    }

    /**
     * Select values from Status Date dropdown.
     */
    public void selectStatusDateDropDownByValue(String value) {
        Select statusDateDropDown = new Select(Driver.getDriver().findElement(By.id("statusDate")));
        statusDateDropDown.selectByValue(value);
    }

    /**
     * Type date in Status Date From field
     */
    public void typeStatusDateFrom(String date) {
        statusDateFrom.sendKeys(date);
    }

    /**
     * Type date in Status Date To field
     */
    public void typeStatusDateTo(String date) {
        statusDateTo.sendKeys(date);
    }

    /**
     * Select an option from Candidate Creation drop down.
     *
     * @param value
     */
    public void selectCandidateCreationDateDropDownByValue(String value) {
        Select candidateCreationDate = new Select(candidateCreationDropDown);
        candidateCreationDate.selectByValue(value);
    }

    /**
     * Type candidate creation from date
     *
     * @param date
     */
    public void typeCandidateCreationDateFrom(String date) {
        candidateCreationFromDate.sendKeys(date);
    }

    /**
     * Type candidate creation to date
     */
    public void typeCandidateCreationToDate(String date) {
        candidateCreationToDate.sendKeys(date);
    }

    /**
     * Select a value from Last Modified drop down
     */
    public void selectLastModifiedDropDown(String value) {
        lastModifiedDateDropDown.selectByVisibleText(value);
    }

    /**
     * Type last modified from date
     */
    public void typeLastModifiedFromDate(String date) {
        lastModifiedFromDate.sendKeys(date);
    }

    /**
     * Type last modified to date
     */
    public void typeLastModifiedToDate(String date) {
        lastModifiedToDate.sendKeys(date);
    }

    /**
     * Select value from Candidate Start date drop down
     */
    public void selectFromCandidateStartDateDropDown(String visibleText) {
        candidateStartDateDropDown.click();
        Select s = new Select(candidateStartDateDropDown);
        s.selectByVisibleText(visibleText);
        candidateStartDateDropDown.click();
    }

    /**
     * Type Candidate Start Date From date
     *
     * @param date
     */
    public void typeCandidateStartDateFrom(String date) {
        candidateStartDateFrom.sendKeys(date);
    }

    /**
     * Type Candidate Start Date To date
     *
     * @param date
     */
    public void typeCandidateStartDateTo(String date) {
        candidateStartDateTo.sendKeys(date);
    }

    /**
     * Generic method to Type text in a custom field with a corresponding label.
     * This is required as every customer has different labels for custom fields.
     *
     * @param customFieldLabel
     * @param textToBeTyped
     */
    public void typeTextInCustomTextField(String customFieldLabel, String textToBeTyped) {
        WebElement customFieldTextBox = Driver.getDriver().findElement(By.xpath("//div[@class='field']/label[contains(text(),'" + customFieldLabel + "')]/following-sibling::input[1]"));
        SeleniumTest.clearAndSetText(customFieldTextBox, textToBeTyped);
    }

    /**
     * Generic method to select a value from any custom field dropdown.
     * This is required as every customer has different labels for custom fields.
     *
     * @param customFieldLabel
     * @param value
     */
    public void selectValueFromCustomDropDownField(String customFieldLabel, String... value) {
        WebElement customFieldDropDown = Driver.getDriver().findElement(By.xpath("//div[contains(@class,'field')]/label[contains(text(),'" + customFieldLabel + "')]/following-sibling::button"));
        customFieldDropDown.click();
        checkValues(value);
    }

    /**
     * Click on Save New Search Button.
     */
    public void clickSaveNewSearchButton() {
        logger.info("Clicking Save New Search Button");
        SeleniumTest.click(saveNewSearchButton);
    }

    /**
     * Generic method to type text in Saved search field.
     *
     * @param saveSearchName
     */
    public void typeTextInSavedSearchTextField(String saveSearchName) {
        SeleniumTest.clearAndSetText(savedSearchInput, saveSearchName, false);
    }

    /**
     * Click Save to save the new search name.
     */
    public void clickSaveNewSearch() {
        SeleniumTest.click(By.xpath("/html/body/div[12]/ul/li[1]/label/div[4]/i[2]"));
    }


    /**
     * @param customFieldLabel
     * @param customFieldCount
     * @return list of webelements which are the options in the dropdown
     */
    public List<WebElement> getEnumCustomFieldSearchOptions(String customFieldLabel, int customFieldCount) {
        Driver.getDriver().findElement(By.xpath("//div[@class='field']/label[contains(text(),'" + customFieldLabel + "')]/following-sibling::button")).click();
        Integer count = 0;
        ArrayList<WebElement> customFieldEnumOptions = new ArrayList();
        while (true) {
            final By locator = getEnumCustomFieldSelectionLocator(customFieldCount, count);

            if (!SeleniumTest.isElementVisibleNoWaiting(locator)) {
                break;
            }

            customFieldEnumOptions.add(Driver.getDriver().findElement(locator));
            logger.info("Found {}", customFieldEnumOptions.get(count).getAttribute("Title"));
            count++;
        }
        return customFieldEnumOptions;
    }

    public String getPageCount() {
        return SeleniumTest.getText(pageCount);
    }

    /**
     * Check Profile checkbox.
     */
    public void checkProfileCheckbox() {
        SeleniumTest.waitForElementToBeClickable(profileCheckbox);
        profileCheckbox.click();
    }

    /**
     * Check EEO checkbox
     */
    public void checkEEOCheckbox() {
        EEOCheckbox.click();
    }

    /**
     * Check MVR checkbox
     */
    public void checkMVRCheckbox() {
        mvrCheckbox.click();
    }

    /**
     * Check Federal Income Tax Withholding checkbox
     */
    public void checkFederalTaxWithholdingCheckbox() {
        federalIncomeTaxWitholdingCheckbox.click();
    }

    /**
     * Check State and Local Income Tax Withholding checkbox.
     */
    public void checkStateAndIncomeTaxWithholdingCheckbox() {
        stateAndLocalIncomeTaxWithholdingCheckbox.click();
    }

    /**
     * Check Package Status checkbox.
     */
    public void checkPackageStatusCheckbox() {
        packageStatusCheckbox.click();
    }

    /**
     * Checks Most Recent I-9s checkbox
     */
    public void checkMostRecentI9() {
        SeleniumTest.check(mostRecentI9Checkbox);
    }

    /**
     * Unchecks Most Recent I-9s checkbox
     */
    public void unCheckMostRecentI9() {
        SeleniumTest.unCheck(mostRecentI9Checkbox);
    }

    /**
     * Returns disabled satus of Most Recent I-9s checkbox
     *
     * @return boolean
     */
    public boolean isMostRecentI9Disabled() {
        return SeleniumTest.isElementDisabled(mostRecentI9Checkbox);
    }

    /**
     * Checks All I-9s checkbox
     */
    public void checkAllI9Checkbox() {
        SeleniumTest.check(allI9Checkbox);
    }

    /**
     * Unchecks All I-9s checkbox
     */
    public void unCheckAllI9Checkbox() {
        SeleniumTest.unCheck(allI9Checkbox);
    }

    /**
     * Returns disabled satus of All I-9s checkbox
     *
     * @return boolean
     */
    public boolean isAllI9Disabled() {
        return SeleniumTest.isElementDisabled(allI9Checkbox);
    }

    /**
     * Checks Package Status checkbox
     */
    public void checkPackageStatus() {
        SeleniumTest.check(packageStatusCheckbox);
    }

    /**
     * Unchecks Package Status checkbox
     */
    public void unCheckPackageStatus() {
        SeleniumTest.unCheck(packageStatusCheckbox);
    }

    /**
     * Returns disabled satus of Package Status checkbox
     *
     * @return boolean
     */
    public boolean isPackageStatusDisabled() {
        return SeleniumTest.isElementDisabled(packageStatusCheckbox);
    }

    /**
     * Checks Additional Package Status Detail checkbox
     */
    public void checkAdditionalPackageStatusDetail() {
        SeleniumTest.check(additionalPackageCheckbox);
    }

    /**
     * Unchecks Additional Package Status Detail checkbox
     */
    public void unCheckAdditionalPackageStatusDetail() {
        SeleniumTest.unCheck(additionalPackageCheckbox);
    }

    /**
     * Returns disabled satus of Additional Package Status Detail checkbox
     *
     * @return boolean
     */
    public boolean isAdditionalPackageStatusDetailDisabled() {
        return SeleniumTest.isElementDisabled(additionalPackageCheckbox);
    }

    /**
     * Checks Request Level Detail checkbox
     */
    public void checkRequestLevelDetail() {
        SeleniumTest.check(requestLevelCheckbox);
    }

    /**
     * Unchecks Request Level Detail checkbox
     */
    public void unCheckRequestLevelDetail() {
        SeleniumTest.unCheck(requestLevelCheckbox);
    }

    /**
     * Returns disabled satus of Request Level checkbox
     *
     * @return boolean
     */
    public boolean isRequestLevelDetailDisabled() {
        return SeleniumTest.isElementDisabled(requestLevelCheckbox);
    }

    /**
     * Check a custom candidate export selection
     *
     * @param name
     */
    public void checkCustomCheckbox(String name) {
        WebElement checkbox = Driver.getDriver().findElement(By.cssSelector("input[value='" + name + "']"));
        logger.info("Checking Candidate Export selection {}", name);
        SeleniumTest.check(checkbox, checkbox);
    }

    /**
     * Click on Search Button.
     */
    public void search() {
        logger.info("Clicking Search Button");
        searchButton.click();
    }

    /**
     * False if no next page was found
     *
     * @return
     */
    public boolean clickNextPage() {
        WebElement pageLink = Driver.getDriver().findElement(By.xpath("//div[@class='pages']/span[@class='active']/following-sibling::*[1]"));
        if (pageLink.getTagName().equals("a")) {
            pageLink.click();
            return true;
        } else {
            return false;
        }
    }

    /**
     * Click on last page in list of pages
     */
    public void clickLastPage() {
        // find the spacer element within the pages collection, then back up to previous sibling
        // if there is only one page, it will click on "page 1"
        String xpath = "//div[@id='dbpaginator']/div[@class='pages']/span[@class='pagesSpacer']/preceding-sibling::*[1]";
        WebElement pageLink = Driver.getDriver().findElement(By.xpath(xpath));
        pageLink.click();
    }

    public boolean hasSearchResults() {
        try {
            SeleniumTest.waitForElementVisible(
                    By.cssSelector("table.report"), 60, 2);
            return true;
        } catch (TimeoutException toe) {
            return false;
        }
    }

    public void locateCandidate(int candidateId) {
        List<WebElement> linkTotalPages = Driver.getDriver().findElements(
                By.xpath("//a[contains(text(),'Download in Excel Format')]/../following-sibling::div[2]//span[contains(text(),'Viewing Page:')]/../a"));
        int totalPages = linkTotalPages.size();
        WebElement currentPage = Driver.getDriver().findElement(By.xpath("//a[contains(text(),'Download in Excel Format')]/../following-sibling::div[2]//a[contains(text(),'" + totalPages + "')]"));
        currentPage.click();
    }

    public Map<String, String> getRowData(int candidateId) {
        new CandidateExportPage(false).click30();

        List<WebElement> rowHeaders = Driver.getDriver().findElements(
                By.xpath("//div[@class='exportCandidateHeader']"));

        WebElement row = Driver.getDriver().findElement(
                By.xpath("//td[text()='" + candidateId + "']/parent::tr"));

        List<WebElement> listOfCells = row.findElements(By.xpath("./td"));
        Map cellList = new HashMap();

        for (int x = 0; x < rowHeaders.size(); x++) {
            cellList.putIfAbsent(rowHeaders.get(x).getText(), listOfCells.get(x).getText());
        }
        return cellList;
    }

    /**
     * Returns the value in a given cell in grid.
     *
     * @param rowNumber
     * @param columnNumber
     * @return
     */
    public String getCellValue(int rowNumber, int columnNumber) {
        rowNumber = rowNumber + 1; // because first row is column headers
        WebElement cell = null;
        try {
            cell = Driver.getDriver().findElement(By.cssSelector(
                    "table.report tbody tr:nth-child(" + rowNumber + ") td:nth-child(" + columnNumber + ")"));
        } catch (NoSuchElementException e) {
            cell = null;
        }
        return cell == null ? null : cell.getText();
    }

    public boolean doesReportContain(String value) {
        if (TableHelper.getTableRows(reportTable) != null) {
            for (WebElement row : TableHelper.getTableRows(reportTable)) {
                if (row.getText().contains(value)) {
                    return true;
                }
            }
        }
        return false; // returns fall if .getTableRows returns null, or if value isn't found
    }


    /**
     * Clicks on "Download in Excel Format" Link
     */
    public void clickDownloadInExcelFormat() {
        downloadInExcelFormatLink.click();
    }

    private By.ById getEnumCustomFieldSelectionLocator(int customFieldID, int dropDownIndex) {
        return new By.ById("ui-multiselect-CustomField" + customFieldID + "_FormUserArea_1-option-" + dropDownIndex);
    }

    /**
     * Method to check dropdown values. It performs an exact match with value and clicks on it.
     *
     * @param value
     */
    public static void checkValues(String... value) {
        //wait for the label with first value to be visible.
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), SeleniumTest.waitForElementTimeout);
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label/span[text()='" + value[0] + "']")));

        for (int i = 0; i < value.length; i++) {
            //click on the checkbox corresponding to the labels
            WebElement checkBox = Driver.getDriver().findElement(By.xpath("//label/span[text()='" + value[i] + "']/preceding-sibling::input"));
            checkBox.click();
        }
    }

    public String getCustomFieldLabelText(int customFieldID) {
        return Driver.getDriver().findElement(getCustomFieldLabelLocator(customFieldID)).getText();
    }

    public By.ById getCustomFieldDataLocator(int customFieldID) {
        return new By.ById("CustomField" + customFieldID + "_FormUserArea_1");
    }

    public By.ByXPath getCustomFieldLabelLocator(int customFieldID) {
        return new By.ByXPath("//label[@for=\"CustomField" + customFieldID + "_FormUserArea_1\"]");
    }

    /**
     * this finds the label based on it's xpath, used for testing the reorder code
     *
     * @param indexOnPage 1of the first, 2 for the 2nd, etc.
     * @return
     */
    public String getCustomFieldLabelTextByXpath(int indexOnPage) {
        return Driver.getDriver().findElement(getCustomFieldLabelLocatorByXpath(indexOnPage)).getText();
    }

    public By.ByXPath getCustomFieldLabelLocatorByXpath(int indexOnPage) {
        // the first two were 21 and 22, so I assume it's base index is 20
        return new By.ByXPath("//*[@id=\"dbIdContentInner\"]/div[1]/div[2]/form/div[" + Integer.toString(20 + indexOnPage) + "]/label");
    }

    /**
     * Navigates directly to CandidateExport page - no proxy activities happen here
     * you must be directly logged in for this method to work.
     *
     * @throws UnknownHostException
     */
    public CandidateExportPage navigateToDirect() {

        int userId = 0;
        try {
            List<NameValuePair> queryParams =
                    new URIBuilder(Driver.getDriver().getCurrentUrl()).getQueryParams();

            for (NameValuePair nvp : queryParams) {
                if (nvp.getName().equals("OverrideUserID")) {
                    userId = Integer.parseInt(nvp.getValue());
                }
            }
        } catch (URISyntaxException e) {
            // Hoping this never gets hit based on being on a valid URL
            // when calling this method.  Opted to throw RuntimeException to avoid
            // making the whole world add a new exception to their tests.
            throw new RuntimeException(e.getMessage());
        }
        String urlPath = URL.getURL(Site.CUSTOMER_DASHBOARD)
                + "/screening/billing.php?view=export";

        urlPath += userId > 0 ? "&OverrideUserID=" + userId : "";
        logger.info("Navigating directly to {}", urlPath);
        Driver.getDriver().get(urlPath);

        return PageFactory.initElements(Driver.getDriver(), CandidateExportPage.class);

    }

    /**
     * Returns assignee from Package Status Report using passed reportId
     *
     * @param reportId
     * @return
     */
    public String getAssigneeFromPackageStatusReport(String reportId) {
        ArrayList<KVPair> pairs = getKeValuePairListFromPackageStatusReport(
                PackageStatusReportColumns.REPORT_ID, PackageStatusReportColumns.ASSIGNEE);
        String assignee = new String();
        for (KVPair pair : pairs) {
            if (pair.key().equals(reportId)) {
                assignee = pair.value();
                break;
            }
        }
        return assignee;
    }

    public void click30() {
        try {
            thirtyLink.click();
        } catch (NoSuchElementException nse) {
            // this is ok because there is no 30 link.
        }
        SeleniumTest.waitForPageLoadToComplete();
    }

    /**
     * Returns list of Key Value Pairs from Package Status Report using
     * passed Key column and passed value column.
     *
     * @param key
     * @param value
     * @return
     */
    public ArrayList<KVPair> getKeValuePairListFromPackageStatusReport(
            PackageStatusReportColumns key, PackageStatusReportColumns value) {
        List<WebElement> elements = Driver.getDriver()
                .findElements(By.cssSelector("#exportScrollContainer table tbody tr"));
        ArrayList<KVPair> pairs = new ArrayList<>();
        int i = 1;
        while (i < elements.size()) {
            pairs.add(new KVPair(getCellValue(i, key.index), getCellValue(i++, value.index)));
        }
        return pairs;
    }

    public HashMap<Integer, String> getHeaders() {
        logger.info("Retrieve Search Result Headers");
        List<WebElement> headerRows =
                reportTable.findElements(By.xpath(".//th[@class='headercell']/div"));

        HashMap<Integer, String> headers = new HashMap<>();
        Integer counter = 0;

        for (WebElement element : headerRows) {
            headers.put(counter, element.getText());
            counter++;
        }

        return headers;
    }

    public List<WebElement> getRows(String s, ArrayList<String> candidateIds) {
        List<WebElement> rows = null;
        boolean stillSearching = true;

        while (stillSearching) {
            List<WebElement> allRows = reportTable.findElements(By.xpath(".//tr"));
            stillSearching = clickNextPage();
        }
        return rows;
    }

    public List<WebElement> getRows() {
        List<WebElement> rows = null;
        boolean stillSearching = true;

        while (stillSearching) {
            rows = reportTable.findElements(By.xpath(".//tr"));
            stillSearching = clickNextPage();
        }
        return rows;
    }

    public void downloadToCSV_Deletes_Old_Creates_New_File() {
        logger.info("Remove any previously downloaded files");
        if (!deleteDownloadedTaskListCSVFiles()) {
            logger.info("Not all Files were deleted!  TEST MAY FAIL!");
        }
        logger.info("Clicking Download in Excel Format Link");
        downloadInExcelFormatLink.click();
        WaitUntil.waitUntil(60, 2, () -> {
            return doesDownloadedFileExist();
        });
        logger.info("Download of exported data complete");
    }

    private boolean deleteDownloadedTaskListCSVFiles() {
        File[] children = getDownloadedTaskListCSVFiles();
        boolean deleted = false;
        int counter = 0;
        for (File f : children) {
            deleted = f.delete();
            if (!deleted) {
                counter++;
            }
        }
        WaitUntil.waitUntil(() -> {
            return !doesDownloadedFileExist();
        });
        return counter == 0;
    }

    public HashMap<Integer, String> readColumnsFromCSV(File foundFile) {
        boolean didPass = true;
        HashMap<Integer, String> fileMap = new HashMap<>();
        logger.info("Retrieving column headers from downloaded file {}",
                foundFile.getAbsolutePath());
        if (foundFile.canRead()) {
            try (BufferedReader br = new BufferedReader(new FileReader(foundFile))) {
                String line = br.readLine();
                String[] values = line.split(",");

                for (int x = 0; x < values.length; x++) {
                    values[x] = values[x].replace("\"", "");
                    fileMap.put(x, values[x]);
                }
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return fileMap;
    }

    public List<LinkedHashMap<String, String>> readExportedDataFromCSV(File csvFile) {
        List<LinkedHashMap<String, String>> csvData = new ArrayList<LinkedHashMap<String, String>>();
        String line = "";
        int count = 0;
        if (csvFile.canRead()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(csvFile));
                ArrayList<String> columnNames = new ArrayList<String>();
                while ((line = br.readLine()) != null) {
                    if (count == 0) {
                        logger.info("Retrieving column headers from downloaded file {}");
                        String[] values = line.split(",");
                        for (String value : values) {
                            columnNames.add(value.replace("\"", ""));
                        }
                        count++;
                    } else {
                        String[] values = line.split(",");
                        LinkedHashMap<String, String> row = new LinkedHashMap<String, String>();
                        int columnIndex = 0;
                        for (String value : values) {
                            row.put(columnNames.get(columnIndex), value.replace("\"", ""));
                            columnIndex++;
                        }
                        csvData.add(row);
                    }
                }
                br.close();
            } catch (FileNotFoundException e) {
                logger.info("File Not found", e);
            } catch (IOException e) {
                logger.info("IO exception", e);
            }
        }
        logger.info("CSV Data: " + csvData);
        return csvData;
    }

    private boolean doesDownloadedFileExist() {
        File[] children = getDownloadedTaskListCSVFiles();
        return children.length != 0;
    }

    public File[] getDownloadedTaskListCSVFiles() {
        File parent = null;

        if (!SystemUtils.IS_OS_WINDOWS) {
            parent = new File(System.getProperty("user.home") + "/Downloads");
        } else {
            parent = new File(System.getenv("USERPROFILE") + "\\Downloads");
        }
        logger.debug("Retrieving all downloaded files beginning with 'export-'");
        return parent != null ? parent.listFiles(file -> {
            return file.getName().toLowerCase().startsWith("export-")
                    && file.getName().toLowerCase().endsWith("csv");
        }) : new File[0];
    }

    public static void clickSearch() {
        SeleniumTest.click(By.cssSelector("input[value='Search'"));

    }

    /**
     * Selects a saved search from the Save Search Dropdown
     *
     * @param savedSearchName The name of the saved search to retrieve
     */
    public void selectSavedSearch(String savedSearchName) {
        if (!savedSearchDropdown.getAttribute("class").contains("ui-state-active")) {
            clickSavedSearchDropdown();
        }
        Driver.getDriver().findElement(By.xpath("//li/label/div/span[text()='" + savedSearchName + "']")).click();
    }

    /**
     * Clicks on Saved search dropdown.
     */
    public void clickSavedSearchDropdown() {
        // because sometimes it tries to click before the savedSearchDropdown is ready.
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
        savedSearchDropdown.click();
    }

    public boolean hasNoResults() {
        SeleniumTest.waitForPageLoadToComplete();
        try {
            ((EventFiringWebDriver) Driver.getDriver()).findElement(By.className("dbMessage"));
        } catch (NoSuchElementException nse) {
            return false;
        }
        return true;
    }

    public List<LinkedHashMap<String, String>> getSearchResults() {

        return getFilterResultsFromWeb(reportTable);
    }

    /**
     * Get Search data for candidate Export results table into a Linked Hash Map.
     *
     * @return
     */
    public LinkedHashMap<String, String> getSearchResultsList() {
        return getFilterResultsFromWebToList(reportTable);
    }

    private List<LinkedHashMap<String, String>> getFilterResultsFromWeb(WebElement webTable) {
        // create empty table object and iterate through all rows of the found table element
        List<LinkedHashMap<String, String>> userTable = new ArrayList<LinkedHashMap<String, String>>();
        List<WebElement> rowElements = webTable.findElements(By.xpath(".//tr"));
        // get column names of table from table headers
        List<String> columnNames = new ArrayList<String>();
        List<WebElement> headerElements = webTable.findElements(By.xpath(".//th[@class='headercell']"));
        for (WebElement headerElement : headerElements) {
            columnNames.add(headerElement.getText());
        }
        // iterate through all rows and add their content to table array
        for (WebElement rowElement : rowElements) {
            LinkedHashMap<String, String> row = new LinkedHashMap<String, String>();
            // add table cells to current row
            int columnIndex = 0;
            List<WebElement> cellElements = rowElement.findElements(By.xpath(".//td"));
            for (WebElement cellElement : cellElements) {
                row.put(columnNames.get(columnIndex), cellElement.getText());
                columnIndex++;
            }
            if (cellElements.size() > 0) {
                userTable.add(row);
            }
        }
        logger.info("Web Data: " + userTable);
        return userTable;
    }

    /**
     * Navigate to each of the page in the search results and return all the rows in a hashList
     * Key value 0 will contain ColumnHeaders.
     * Key Value "Error" will contain any errors when results are empty.
     * Key value with Candidate ID will contain all the row values.
     *
     * @param webTable
     * @return
     */
    private LinkedHashMap<String, String> getFilterResultsFromWebToList(WebElement webTable) {
        // create empty table object and iterate through all rows of the found table element
        LinkedHashMap<String, String> userTable = new LinkedHashMap<>();

        // The Report ID  will be present only when Package Status is selected and will be unique and Candidate ID may not be unique.
        // CandidateID + report ID will be used as Key when Candidate ID is not unique.
        //Any export other than Package Status will have candidate ID as Unique column.
        int reportIDIndex = 0;
        if (hasNoResults()) {
            String error = SeleniumTest.getTextByLocator(By.className("dbMessage"));
            userTable.put("Error", error);
            return userTable;
        }

        // get column names of table from table headers and always save it with Key as 0
        String columnNames = "";

        List<WebElement> headerElements = webTable.findElements(By.xpath(".//th[@class='headercell']"));
        for (WebElement headerElement : headerElements) {
            columnNames = columnNames + headerElement.getText() + ",";
        }
        columnNames = columnNames.substring(0, columnNames.length() - 1);
        userTable.put("0", columnNames);
        String[] cols = columnNames.split(",");
        reportIDIndex = Arrays.asList(cols).indexOf("Report ID");

        int counter = 1;
        boolean hasNextPage;

        // iterate through all rows and add their content to table array
        //TODO Handle scenario when the cell value has comma.
        do {
            List<WebElement> rowElements = webTable.findElements(By.xpath(".//tr"));
            for (WebElement rowElement : rowElements) {
                List<WebElement> cellElements = rowElement.findElements(By.xpath(".//td"));
                if (cellElements.isEmpty()) {
                    continue;
                }

                //Handle when CandidateID is not unique.
                String key = cellElements.get(0).getText();
                if (reportIDIndex > 0) {
                    key = key + "_" + cellElements.get(reportIDIndex).getText();
                }

                String rowValues = "";
                for (WebElement cellElement : cellElements) {
                    rowValues = rowValues + cellElement.getText() + ",";
                }
                rowValues = rowValues.substring(0, rowValues.length() - 1);
                userTable.put(key, rowValues);
            }
            hasNextPage = clickNextPage();
        } while (hasNextPage);

        logger.info("Web Data: " + userTable);
        return userTable;
    }

    public boolean matchExportResultsinCSV(File foundFile) {
        return getFilterResultsFromWeb(reportTable).equals(readExportedDataFromCSV(foundFile));
    }

    /**
     * Enum to select Package Drop Down Options
     */
    public enum DateRangeOption {
        //        LAST_WEEK("last-week"),
//        THIS_WEEK("this-week"),
//        TODAY("today"),
//        YESTERDAY("yesterday"),
//        LAST_7_DAYS("last-seven-days"),
//        LAST_30_DAYS("last-thirty-days"),
//        LAST_60_DAYS("last-sixty-days");
        LAST_WEEK("2"),
        THIS_WEEK("3"),
        TODAY("4"),
        YESTERDAY("5"),
        LAST_7_DAYS("6"),
        LAST_30_DAYS("7"),
        LAST_60_DAYS("8");
        private final String text;

        DateRangeOption(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Enum to select Package Status Report Columns
     */
    public enum PackageStatusReportColumns {
        CANDIDATE_ID(1),
        EXTERNAL_CANDIDATE_ID(2),
        EXTERNAL_CANDIATE_SOURCE(3),
        EMPLOYEE_ID(4),
        LASTNAME(5),
        FIRSTNAME(6),
        PACKAGE_STATUS(7),
        PACKAGE_LAUNCH_DATE(8),
        PACKAGE_COMPLETE_DATE(9),
        REPORT_ID(10),
        CURRENT_TASK(11),
        CURRENT_ROLE(12),
        ASSIGNEE(13),
        PACKAGE_NAME(14),
        CANDIDATE_POSITION_ID(15),
        CANDIDATE_POSITION(16),
        BILLING_CODE(17),
        REFERENCE_CODE(18);

        private final int index;

        PackageStatusReportColumns(int i) {
            this.index = i;
        }
    }

    /**
     * Generic Key Value Pair helper class
     */
    public class KVPair {
        private final String key;
        private final String value;

        public KVPair(String aKey, String aValue) {
            key = aKey;
            value = aValue;
        }

        public String key() {
            return key;
        }

        public String value() {
            return value;
        }
    }


    public static boolean areNewlyCandidateSubmissionDetialsInTable(Candidate candidate) {
        String[] strRecordCount = recordcount.getText().split("of");
        int recordCount = Integer.parseInt(strRecordCount[1].trim());
        int pageCount = 0;
        boolean sFlag = false;
        if (recordCount != 0) {
            if (recordCount % 10 == 0) {
                pageCount = recordCount / 10;
            } else {
                pageCount = (recordCount / 10) + 1;
            }
        }

        if (!recordCandidateIDList.isEmpty()) {
            while (pageCount != 0) {
                int i;
                for (i = 0; i < recordCandidateIDList.size(); i++) {
                    if (Integer.parseInt(recordCandidateIDList.get(i).getText()) == candidate.getCandidateID()) {
                        if (recordCandidateFirstNameList.get(i).getText().equalsIgnoreCase(candidate.getFirstName())) {
                            if (recordCandidateLastNameList.get(i).getText().equalsIgnoreCase(candidate.getLastName())) {
                                if (recordCandidateMiddleNameList.get(i).getText().equalsIgnoreCase(candidate.getMiddleName())) {
                                    if (recordCandidateEmailAddressList.get(i).getText().equalsIgnoreCase(candidate.getEmailAddress())) {
                                        sFlag = true;
                                        staticLogger.info("Newly created candidate data submission is successfully displayed in resulted table");
                                        return sFlag;
                                    }
                                }
                            }
                        }
                    }

                }
                if (i == recordCandidateIDList.size() && sFlag == false) {
                    pageCount--;
                }
            }
        }
        return sFlag;
    }
}