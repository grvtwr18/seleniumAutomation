package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import Sites.TalentWiseDashboard.Enums.DisplayType;
import Sites.TalentWiseDashboard.Enums.TurnaroundType;
import TWFramework.BodyTextHelper;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Page object that represents the turnaround report page for the TalentWise website (Ex. "https://talentwise.dvm-eelefson1.sea.talentwise.com/screening/billing.php?view=turnaround").
 * @author eelefson
 *
 * TODO: ideally should extend a ReportingPage abstract class that handles the ReportingTabs in here; that in turn would
 * extend CustomerPortal Page.
 */
public class TurnaroundReportPage extends CustomerPortalPage{
	private WebDriverWait wait;
	public ReportingTabs tabs;
	
	@FindBy(how = How.ID, using = "crim")
	private WebElement turnaroundTypeDropDownBox;
	
	@FindBy(how = How.ID, using = "display")
	private WebElement displayTypeDropDownBox;

    @FindBy(how = How.ID, using = "dbIdContentInner")
    private static WebElement turnaroundReportSection;

    @FindBy(how = How.XPATH, using = "//*[@id='turnaround']/table/tbody")
    private static WebElement report;

    @FindBy(how = How.ID, using = "acct")
    private static WebElement viewReportForSelect;

    @FindBy(how = How.CLASS_NAME, using = "button")
    private static WebElement searchBtn;

	/**
	 * Constructs a new turnaround report page object.
	 */
    public TurnaroundReportPage() {

        this.wait = new WebDriverWait(Driver.getDriver(), 10);
        this.tabs = PageFactory.initElements(Driver.getDriver(), ReportingTabs.class);
    }
    
    /**
     * Selects the specified option from the "Turnaround Type" drop down menu.
     * @param turnaroundType The option to be selected from the drop down menu
     */
    public void selectTurnaroundType(TurnaroundType turnaroundType) {
        Select optionSelect = new Select(turnaroundTypeDropDownBox);
    	optionSelect.selectByVisibleText(turnaroundType.toString());
    }
    
    /**
     * Selects the specified option from the "Display Type" drop down menu.
     * @param displayType The option to be selected from the drop down menu
     */
    public void selectDisplayType(DisplayType displayType) {
        Select optionSelect = new Select(displayTypeDropDownBox);
    	optionSelect.selectByVisibleText(displayType.toString());
    }
    
    /**
     * Clicks the "Go" button.
     * @return A new Turnaround Report page object
     */
    public TurnaroundReportPage clickGoButton() {
    	WebElement goButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(".//*[@id='dbIdContentInner']/div[1]/div[1]/form/input[2]")));
    	goButton.click();
    	return PageFactory.initElements(Driver.getDriver(), TurnaroundReportPage.class);
    }

    public static WebElement getTurnaroundReportSection() {
        return turnaroundReportSection;
    }

    public static void hideVariableElements() {
        BodyTextHelper.hideElement(report);
        BodyTextHelper.hideElement(viewReportForSelect);
    }

    public static String getSearchButtonValue(){
        return searchBtn.getAttribute("value");
    }
}