package Sites.TalentWiseDashboard.Reporting;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the sub-tabs that appear when the "Reporting" tab has been selected.
 *
 * @author eelefson
 */
public class ReportingTabs {

    private CandidateExportPage candidateExportPage;

    @FindBy(how = How.ID, using = "subtab_report-list")
    private WebElement reportsSubtab;

    @FindBy(how = How.CSS, using = "a[href*='view=turnaround']")
    private static WebElement turnaroundReportLink;

    @FindBy(how = How.CSS, using = "a[href*='view=billing']")
    private static WebElement billingReportLink;

    @Deprecated
    @FindBy(how = How.ID, using = "subtab_export")
    private static WebElement candidateExportTab;

    @FindBy(how = How.XPATH, using = "//a[contains(@href,'view=export')]")
    private static WebElement candidateExportLink;

    @Deprecated
    @FindBy(how = How.ID, using = "subtab_i9reverify")
    private static WebElement formI9ExpirationTab;

    @FindBy(how = How.CSS, using = "a[href*='view=hpm']")
    private static WebElement hpmReportLink;

    @FindBy(how = How.CSS, using = "a[href*='view=summary']")
    private static WebElement summaryReportLink;

    @FindBy(how = How.XPATH, using = "//a[contains(@href,'view=i9reverify')]")
    private static WebElement formI9ExpirationLink;

    private static final ThreadLocal<ReportingTabs> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(
                () -> PageFactory.initElements(Driver.getDriver(), ReportingTabs.class));
    }

    private static ReportingTabs getInstance() {
        return threadLocalInstance.get();
    }

    /**
     * Clicks on the "Turnaround Report" sub-tab.
     *
     * @return A new Turnaround Report page object
     */
    public static TurnaroundReportPage clickTurnaroundReportLink() {
        turnaroundReportLink.click();
        return PageFactory.initElements(Driver.getDriver(), TurnaroundReportPage.class);
    }

    /**
     * Clicks on the "Billing Report" sub-tab.
     *
     * @return A new Billing Report page object
     */
    public static BillingReportPage clickBillingReportLink() {
        billingReportLink.click();
        return PageFactory.initElements(Driver.getDriver(), BillingReportPage.class);
    }

    /**
     * Clicks on the "Hiring Process Report" link.
     */
    public static void clickHiringProcessReportLink() {
        hpmReportLink.click();
    }

    /**
     * Clicks on the "Summary Report" link.
     */
    public static void clickSummaryReportLink() {
        summaryReportLink.click();
    }

    /**
     * Clicks on the "Candidate Export" sub-tab.
     * TODO: no longer here!
     *
     * @return A new Candidate Export page object
     */
    public CandidateExportPage clickCandidateExportLink() {
        candidateExportLink.click();
        candidateExportPage = new CandidateExportPage(false);
        return candidateExportPage;
    }

    // TODO: no longer here!
    @Deprecated
    public static void clickFormI9ExpirationTab() {
        clickFormI9ExpirationLink();
    }

    public static void clickFormI9ExpirationLink() {
        formI9ExpirationLink.click();
    }

    /**
     * Clicks the Reports subtab. Not necessary while it's the only tab available...
     */
    public static void clickReportsSubtab() {
        getInstance().reportsSubtab.click();
    }
}
