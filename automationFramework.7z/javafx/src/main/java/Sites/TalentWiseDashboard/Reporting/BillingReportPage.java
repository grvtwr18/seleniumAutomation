package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import Sites.TalentWiseDashboard.Enums.View;
import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.List;

/**
 * Page object that represents the Billing Report page on the TalentWise Dashboard website (Ex. "https://talentwise.dvm-eelefson1.sea.talentwise.com/screening/billing.php?view=billing").
 * @author eelefson
 *
 * TODO: ideally should extend a ReportingPage abstract class that handles the ReportingTabs in here; that in turn would
 * extend CustomerPortal Page.
 */
public class BillingReportPage extends CustomerPortalPage {
    private WebDriverWait wait;
    public ReportingTabs tabs;

    @FindBy(how = How.NAME, using = "month")
    private static WebElement monthDropDownBox;

    @FindBy(how = How.ID, using = "level")
    private static WebElement viewDropDownBox;

    @FindBy(how = How.ID, using = "dbIdContentInner")
    private static WebElement billingReportSection;

    @FindBy(how = How.ID, using = "billingReportGoBtn")
    private static WebElement goButton;

    @FindBy(how = How.CLASS_NAME, using = "dbMessage")
    private static WebElement dbMessage;

    @FindBy(how = How.XPATH,using = "//table//div[text()='Summary']/following-sibling::div[contains(text(),'Orders')]")
    private WebElement ordersNo;

    /**
     * Constructs a new Billing Report page object.
     */
    public BillingReportPage() {

        this.wait = new WebDriverWait(Driver.getDriver(), 10);
        this.tabs = PageFactory.initElements(Driver.getDriver(), ReportingTabs.class);
    }
    
    /**
     * Selects the specified option from the "Month" drop down menu.
     * @param yearMonth The option to be selected from the drop down menu by value
     */
    public static void selectMonth(String yearMonth) {
        TWFramework.SeleniumTest.selectByValueFromDropDown(monthDropDownBox, yearMonth);
    }

    /**
     * Selects the specified value from the "Month" drop down menu.
     * @param year The option to be selected from the drop down menu
     * @param month The option to be selected from the drop down menu
     */
    public void selectMonth(int year, int month) {
        TWFramework.SeleniumTest.selectByValueFromDropDown(monthDropDownBox, Integer.toString(year) + String.format("%02d", month));
    }

    /**
     * Selects the specified option from the "View" drop down menu.
     * @param view The option to be selected from the drop down menu
     */
    public void selectView(View view) {
        Select optionSelect = new Select(viewDropDownBox);
        optionSelect.selectByVisibleText(view.toString());
    }

    /**
     * Selects the specified option from the "View" drop down menu.
     * @param selectValue The String value to be selected from the drop down menu
     */
    public void selectView(String selectValue) {
        Select optionSelect = new Select(viewDropDownBox);
        optionSelect.selectByValue(selectValue);
    }

    /**
     * Clicks the "Go" button.
     * @return A new billing report page object
     */
    public BillingReportPage clickGoButton() {
        this.goButton.click();
        return PageFactory.initElements(Driver.getDriver(), BillingReportPage.class);
    }

    public static WebElement getBillingReportSection() {
        return billingReportSection;
    }

    public static String getGoButtonValue() {
        return goButton.getAttribute("value");
    }

    public static void hideVariableElements() {
        BodyTextHelper.hideElement(monthDropDownBox);
        BodyTextHelper.hideElement(viewDropDownBox);

        List<WebElement> dbMessages = Driver.getDriver().findElements(By.className("dbMessage"));
        if( !dbMessages.isEmpty()) {
            for (WebElement msg : dbMessages ) {
                BodyTextHelper.hideElement(msg);
            }
        }

        if (!Driver.getDriver().findElements(By.name("viewfor")).isEmpty()) {
            WebElement accountDropDownBox = Driver.getDriver().findElement(By.name("viewfor"));
            List<WebElement> options = accountDropDownBox.findElements(By.xpath(".//option"));
            for (WebElement option : options) {
                if ("all" != option.getAttribute("value") || "self" != option.getAttribute("value")) {
                    BodyTextHelper.hideElement(accountDropDownBox);
                }
            }
        }
    }

    public String getOrders(){
       return SeleniumTest.getText(ordersNo);
    }

    public int getMonthValuesCount()
    {
        if(SeleniumTest.isElementVisibleNoWaiting(By.name("month")))
        {
           return new Select(monthDropDownBox).getOptions().size();
        }
        else {
            return 0;
        }
    }

    public void monthFilter(int i)
    {
        SeleniumTest.selectByDropDownIndexFromDropDown(monthDropDownBox,i);
        clickGoButton();
        SeleniumTest.waitForPageLoad();
    }

    private static final By reportTable = By.xpath(".//*[@class='dbGrid']/table");

    private static final By noOfOrderslabel= By.xpath(".//*[@class='dbGrid']/table//tr[1]/td/div[2]");

    @FindBy(how = How.XPATH, using = ".//*[@class='dbGrid']/table//tr")
    private List<WebElement> noOfRecords;

    @FindBy(how = How.NAME,using = "viewfor")
    private WebElement accountDropDown;

    @FindBy(how = How.ID,using = "grouping")
    private WebElement groupingDropDown;

    public boolean validateResultedTable(String currency)
    {
        String ExpectedCurrency="";
        if(currency.contains("USD"))
        {
            ExpectedCurrency  = "$";
        }
        else if(currency.contains("CAD"))
        {
            ExpectedCurrency = "CA$";
        }
        else {
            throw new IllegalArgumentException("Expected currency not avialable");
        }

        if(SeleniumTest.isElementVisibleNoWaiting(reportTable))
        {
            String ordersLabel = SeleniumTest.getTextByLocator(noOfOrderslabel);
            String[] order = ordersLabel.split(" ");
            int NoOfOrder = Integer.parseInt(order[0]);
            if(NoOfOrder!=0)
            {
                if(ExpectedCurrency.equals("$"))
                {
                    for(int i=0;i<noOfRecords.size();i++)
                    {
                        if(SeleniumTest.getText(noOfRecords.get(i)).contains("CA$"))
                        {
                            return false;
                        }
                    }
                }

                if(ExpectedCurrency.equals("CA$"))
                {
                    for(int i=0;i<noOfRecords.size();i++)
                    {
                        if(SeleniumTest.getText(noOfRecords.get(i)).contains("$"))
                        {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }

    public int getViewValuesCount()
    {
        return new Select(viewDropDownBox).getOptions().size();
    }

    public void ViewFilter(int i)
    {
        SeleniumTest.selectByDropDownIndexFromDropDown(viewDropDownBox,i);
        clickGoButton();
        SeleniumTest.waitForPageLoad();
    }

}