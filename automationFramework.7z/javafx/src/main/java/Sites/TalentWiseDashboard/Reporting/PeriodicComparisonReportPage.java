package Sites.TalentWiseDashboard.Reporting;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the periodic comparison report page on the TalentWise Dashboard website (Ex.
 * "https://dvm-rporras1.aws.talentwise.com/screening/billing.php?ReportUIV2=1&view=report-view&ReportID=13").
 *
 * @author rporras
 */
public class PeriodicComparisonReportPage extends BasicReportPage {

    @FindBy(how = How.XPATH, using = "//div[@class='userFilter userFilterDate userFilterCalcVolume'][1]/div[@class='field'][2]//input[@class='dateField k-input']")
    private static WebElement fromPeriodAInput;

    @FindBy(how = How.XPATH, using = "//div[@class='userFilter userFilterDate userFilterCalcVolume'][1]/div[@class='field'][3]//input[@class='dateField k-input']")
    private static WebElement toPeriodAInput;

    @FindBy(how = How.XPATH, using = "//div[@class='userFilter userFilterDate userFilterCalcVolume'][2]/div[@class='field'][2]//input[@class='dateField k-input']")
    private static WebElement fromPeriodBInput;

    @FindBy(how = How.XPATH, using = "//div[@class='userFilter userFilterDate userFilterCalcVolume'][2]/div[@class='field'][3]//input[@class='dateField k-input']")
    private static WebElement toPeriodBInput;

    @FindBy(how = How.XPATH, using = "//div[@class='userFilter userFilterDate userFilterCalcVolume'][1]/div[@class='field'][1]//select[@class='customDate']")
    private static WebElement periodADropdown;

    @FindBy(how = How.XPATH, using = "//div[@class='userFilter userFilterDate userFilterCalcVolume'][2]/div[@class='field'][1]//select[@class='customDate']")
    private static WebElement periodBDropdown;

    static {
        PageFactory.initElements(Driver.getDriver(), PeriodicComparisonReportPage.class);
    }

    public static String getFromPeriodADate() {
        return fromPeriodAInput.getAttribute("value");
    }

    public static String gettoPeriodADate() {
        return toPeriodAInput.getAttribute("value");
    }

    public static String getFromPeriodBDate() {
        return fromPeriodBInput.getAttribute("value");
    }

    public static String gettoPeriodBDate() {
        return toPeriodBInput.getAttribute("value");
    }

    public static String getReportCreateTimePeriodA() {
        return periodADropdown.getAttribute("value");
    }

    public static String getReportCreateTime() {
        return periodBDropdown.getAttribute("value");
    }

    public static void setToPeriodAInput(String data) {
        SeleniumTest.clearAndSetText(toPeriodAInput, data);
    }

    public static void setFromPeriodAInput(String data) {
        SeleniumTest.clearAndSetText(fromPeriodAInput, data);
    }

    public static void setToPeriodBInput(String data) {
        SeleniumTest.clearAndSetText(toPeriodBInput, data);
    }

    public static void setFromPeriodBInput(String data) {
        SeleniumTest.clearAndSetText(fromPeriodBInput, data);
    }
}