package Sites.TalentWiseDashboard.Reporting;

import Sites.Site;
import Sites.TalentWiseDashboard.CustomerPortalPage;
import Sites.URL;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.time.LocalDate;
import java.util.List;


/**
 * Created by jgupta on 4/1/2016.
 *
 * TODO: ideally should extend a ReportingPage abstract class that handles the ReportingTabs in here; that in turn would
 * extend CustomerPortal Page.
 */
public class FormI9ExpirationPage extends CustomerPortalPage {
    @FindBy(how = How.ID, using = "fromDate")
    private static WebElement fromDateDropDown;

    @FindBy(how = How.ID, using = "toDate")
    private static WebElement toDateDropDown;

    @FindBy(how = How.CSS, using = "input.button")
    private static WebElement searchButton;

    @FindBy(how = How.CSS, using = ".dbMessage")
    private static WebElement expirationRecordsMessageText;

    @FindBy(how = How.ID, using = "no_longer_employed")
    private static WebElement showCurrentEmployeeReportsOnlyCheckBox;

    protected static final Logger logger = LoggerFactory.getLogger("FormI9ExpirationPage");

    static {
        PageFactory.initElements(Driver.getDriver(), FormI9ExpirationPage.class);
    }

    /**
     * Selects from date.
     * @param option
     */
    public static void selectViewExpirationDateFrom(String option) {
        Select viewExpirationDateFrom = new Select (fromDateDropDown);
        viewExpirationDateFrom.selectByVisibleText(option);
    }

    /**
     * Selects to date
     * @param option
     */
    public static void selectViewExpirationDateTo(String option) {
        Select viewExpirationDateFrom = new Select (toDateDropDown);
        viewExpirationDateFrom.selectByVisibleText(option);
    }

    /**
     * Clicks on go button to initiate search.
     */
    public static void clickSearchButton() {
        searchButton.click();
    }

    /**
     * This method is used to wait for the grid to load.
     */
    public static void waitForGridToLoad() {
        SeleniumTest.waitForElementNotPresent(By.cssSelector("div.k-loading-mask"));
    }

    /**
     * Selects an action.
     * @param action
     */
    public static void selectAction(int reportID, String action) {
        WebElement actionDropDown = Driver.getDriver().findElement(By.xpath("//td/a[contains(text(), '" + reportID  + "')]/..//following-sibling::td/div/select"));
        Select actionDD = new Select (actionDropDown);
        actionDD.selectByVisibleText(action);
        waitForGridToLoad();
    }

    public static void selectAction(String reportID, String action) {
        WebElement actionDropDown = Driver.getDriver().findElement(By.xpath("//td/a[contains(text(), '" + reportID  + "')]/..//following-sibling::td/div/select"));
        Select actionDD = new Select (actionDropDown);
        actionDD.selectByVisibleText(action);
    }

    /**
     * Search on the page.
     * @param fromDate
     * @param toDate
     */
    public static void searchExpirationReports(String fromDate, String toDate) {
        selectViewExpirationDateFrom(fromDate);
        selectViewExpirationDateTo(toDate);
        clickSearchButton();
        waitForGridToLoad();
    }

    public static LocalDate getExpirationDateByReportID(int reportID) {
        String dateString = Driver.getDriver().findElement(
                By.xpath("//a[text()='" + reportID + "']/../following-sibling::td[3]")).getText();
        return LocalDate.parse(dateString, LocaleHelper.getDateFormatShortDateSlash());
    }


    /**
     * Navigates directly to FormI9ExpirationPage page - no proxy activities here
     * you must be directly logged in for this method to work.
     *
     * @throws UnknownHostException
     */
    public static FormI9ExpirationPage navigateTo() {

        int userId = 0;
        try {
            List<NameValuePair> queryParams =
                    new URIBuilder(Driver.getDriver().getCurrentUrl()).getQueryParams();

            for (NameValuePair nvp : queryParams) {
                if (nvp.getName().equals("OverrideUserID")) {
                    userId = Integer.parseInt(nvp.getValue());
                }
            }
        } catch (URISyntaxException e) {
            // Throwing RuntimeException so callers don't have to add a new exception to tests.
            throw new RuntimeException(e.getMessage());
        }
        String urlPath = URL.getURL(Site.CUSTOMER_DASHBOARD)
                + "/screening/billing.php?view=i9reverify";
        urlPath += userId > 0 ? "&OverrideUserID=" + userId : "";
        logger.info("Navigating directly to {}", urlPath);
        Driver.getDriver().get(urlPath);
        return PageFactory.initElements(Driver.getDriver(), FormI9ExpirationPage.class);
    }

    public static String getNoExpirationRecordsMessageText() {
        return expirationRecordsMessageText.getText();
    }

    /**
     * Returns Document Type text for passed Report Id
     * @param reportId
     * @return
     */
    public static String getDocumentType(String reportId) {

        return Driver.getDriver().findElement(
                By.xpath("//td/a[contains(text(), '" + reportId  + "')]/../../td[3]")).getText();
    }

    /**
     * Returns text for passed column specific to passed reportId
     * @param reportId
     * @param column
     * @return
     */
    public static String getReportColumnText(String reportId, ReportColumn column) {

        return Driver.getDriver().findElement(
                By.xpath("//td/a[contains(text(), '" + reportId  + "')]/../../td["+column.getValue()+"]")).getText();
    }

    /**
     * By default upon page load this checkbox is checked. Clicking once after page load should uncheck this box.
     */
    public void clickShowCurrentEmployeeReportsOnlyCheckBox() {
        // The element's checked attribute always equals checked regardless of if it is or not.
        // So there is no good way to see if the element is checked or not before clicking it.
        // However, By default upon page load this checkbox is checked.
        // So If you only click it once it should uncheck the box.
        showCurrentEmployeeReportsOnlyCheckBox.click();
    }

    /**
     * Enum to select Action Drop Down Options
     */
    public enum ActionDropDownOptions {
        NO_LONGER_EMPLOYED("No Longer Employed"),
        REVERIFY_EMPLOYEE("Reverify Employee"),
        VIEW_APPLICANT_REPORT("View Applicant Report");

        private final String text;
        ActionDropDownOptions(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Enum to select ReportColumn
     */
    public enum ReportColumn {
        REPORT_ID("Report ID", 1),
        NAME("Name", 2),
        DOCUMENT_TYPE("Document Type", 3),
        EXPIRATION_DATE("Expiration Date", 4),
        COMPLETED("Completed", 5);

        private final String text;
        private final int value;

        ReportColumn(final String text, int value) {
            this.text = text;
            this.value = value;
        }

        public int getValue() {
            return value;
        }

        @Override
        public String toString() {
            return text;
        }
    }

}
