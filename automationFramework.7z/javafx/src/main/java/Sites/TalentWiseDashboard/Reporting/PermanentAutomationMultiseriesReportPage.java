package Sites.TalentWiseDashboard.Reporting;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Permanent Automation Multiseries Report page on the TalentWise Dashboard website (Ex.
 * "https://dvm-rporras1.aws.talentwise.com/screening/billing.php?ReportUIV2=1&view=report-view&ReportID=344").
 *
 * @author rporras
 */
public class PermanentAutomationMultiseriesReportPage extends BasicReportPage {

    @FindBy(how = How.XPATH, using = "//div[@class='field userFilter'][1]//input[@class='searchtext']")
    private static WebElement pieChartDropdown;

    @FindBy(how = How.XPATH, using = "//div[@class='field userFilter'][2]//input[@class='searchtext']")
    private static WebElement barChartDropdown;

    @FindBy(how = How.XPATH, using = "//div[@class='field userFilter'][3]//input[@class='searchtext']")
    private static WebElement lineChartDropdown;

    @FindBy(how = How.XPATH, using = "//div[@class='field userFilter'][3]//input[@class='searchtext']")
    private static WebElement donutChartDropdown;

    static {
        PageFactory.initElements(Driver.getDriver(), PermanentAutomationMultiseriesReportPage.class);
    }

}
