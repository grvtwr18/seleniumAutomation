package Sites.TalentWiseDashboard.Reporting;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import Sites.TalentWiseDashboard.Enums.ReportSubview;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Page object that represents the Drug Testing and Physicals page on the TalentWise Dashboard website (Ex. "https://talentwise.dvm-eelefson1.sea.talentwise.com/screening/billing.php?view=ohs").
 *
 * TODO: ideally should extend a ReportingPage abstract class that handles the ReportingTabs in here; that in turn would
 * extend CustomerPortal Page.
 *
 * @author eelefson
 */
public class DrugTestingAndPhysicalsPage extends CustomerPortalPage {
	public ReportingTabs tabs;
	
	@FindBy(how = How.ID, using = "reportsubview")
	private WebElement reportSubviewDropDownBox;
	
	/**
	 * Constructs a new Drug Testing and Physicals page object.
	 */
    public DrugTestingAndPhysicalsPage() {
        this.tabs = PageFactory.initElements(Driver.getDriver(), ReportingTabs.class);
    }
    
    /**
     * Selects the specified report subview option.
     * @param reportSubview The report subview to be selected
     * @return A new Drug Testing and Physical page object
     */
    public DrugTestingAndPhysicalsPage selectReportSubview(ReportSubview reportSubview) {
    	Select optionSelect = new Select(reportSubviewDropDownBox);
    	optionSelect.selectByVisibleText(reportSubview.toString());
    	return PageFactory.initElements(Driver.getDriver(), DrugTestingAndPhysicalsPage.class);
    }
}