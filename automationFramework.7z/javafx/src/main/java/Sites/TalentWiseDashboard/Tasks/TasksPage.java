package Sites.TalentWiseDashboard.Tasks;

import Sites.TalentWiseDashboard.Search.SearchPages;
import TWFramework.JavaScriptHelper;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * This abstract TasksPage contains members that are common to the OnboardingTasksPage,
 * the ScreeningTasksPage and any other ...TasksPage that might come along.
 */
public abstract class TasksPage extends SearchPages {

    // The following overrides the searchButton in the SearchPages class
    @FindBy(how = How.XPATH, using = "//input[@value='Search']")
    public static WebElement searchButton;

    // The following overrides the clearAllLink in the SearchPages class which is just "aClearForm" ...
    @FindBy(how = How.ID, using = "aClearFormLower")
    private static WebElement clearAllLink;

    @FindBy(how = How.ID, using = "search_DueDateFrom")
    private static WebElement dueDateFrom;
    @FindBy(how = How.ID, using = "search_DueDateTo")
    private static WebElement dueDateTo;

    private static final Logger staticLogger = LoggerFactory.getLogger(TasksPage.class.getName());

    /**
     * Generic method to click search button
     */
    public static void clickSearchButton() {
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 4);  //Waiting for
        // 3 seconds as tests keep failing even after introducing waitforelementtobeclickable
        searchButton.click();
        SeleniumTest.waitForPageLoadToComplete();
        staticLogger.info("Clicked Search");
    }

    /**
     * Clicks the "Clear All" link.
     */
    public static void clickClearAllLink() {
        try {
            staticLogger.info("Click the Clear All Filters link");
            SeleniumTest.click(clearAllLink);
        } catch (WebDriverException e) {
            staticLogger.warn("Selenium click didn't work, so try JavaScript click");
            JavaScriptHelper.click(clearAllLink);
        }
        staticLogger.info("Clear All Filters link Clicked");
    }

    /**
     * Clears the selected filter
     *
     * @param label The label of the filter.
     */
    public static void clearSelectedCriteria(String label) {
        WebElement element = Driver.getDriver().findElement(By.xpath("//label[text()='" + label +
                "']/following-sibling::button"));
        try {
            if(element.getAttribute("aria-expanded").equals("false")) {
                element.click();
            }
            List<WebElement> clearCriteria = Driver.getDriver().findElements(
                    By.xpath("//div[text()='Clear Selected Criteria']"));
            for(WebElement we : clearCriteria) {
                if (we.isDisplayed()) {
                    we.click();
                }
            }
            if(element.getAttribute("aria-expanded").equals("true")) {
                element.click();
            }
        } catch (NullPointerException npe) {
            if(!element.getAttribute("class").contains("state-active")) {
                element.click();
            }
            //TODO when does this come up?  Need a non en-US locator
            WebElement clearCriteria = Driver.getDriver().findElement(By.linkText("Uncheck All"));
            if(clearCriteria.isDisplayed()) {
                clearCriteria.click();
            }
            if(element.getAttribute("class").contains("state-active")) {
                element.click();
            }
        }
    }

    /**
     * Clears the selected filter with the given label,
     * then selects all values you provide within the multi-select Dropdown
     *
     * @param label The name of the label for the multi-select drop down
     * @param values The values you want selected within the dropdown
     */
    public static void clearThenSelectValuesFromMultiSelectDropdown(String label, String... values) {
        clearSelectedCriteria(label);
        selectValuesFromMultiSelectDropdown(label, values);
    }

    public static void setValueInTextBox(String inputLabel, String value) {
        WebElement textBox = Driver.getDriver().findElement(By.xpath("//label[text()='"
                + inputLabel + "']/following-sibling::input"));
        SeleniumTest.clearAndSetText(textBox, value);
    }
    /**
     * Selects all values you provide within the multi-select Dropdown
     *
     * @param label  The name of the label for the multi-select drop down
     * @param values The values you want selected within the dropdown
     */
    public static void selectValuesFromMultiSelectDropdown(String label, String... values) {
        WebElement dropdown = Driver.getDriver().findElement(By.xpath("//label[text()='"
                + label + "']/following-sibling::button"));
        WebElement selector;
        try {
            selector = Driver.getDriver().findElement(By.xpath("//label[text()=" +
                    "'" + label + "']/following-sibling::div"));

            if (dropdown.getAttribute("aria-expanded").equals("false")) {
                dropdown.click();
            }
            for (String value : values) {
                List<WebElement> wes = selector.findElements(By.xpath(".//li/a[text()='" + value + "']"));
                for (WebElement we : wes) {
                    String title = we.getAttribute("title").trim();
                    if (title.startsWith(value)) {
                        if (!we.getAttribute("aria-checked").equals("true")) {
                            try {
                                we.click();
                            } catch (org.openqa.selenium.ElementNotVisibleException enve) {
                                if (title.startsWith("Task Complete Date")) {
                                    throw (new RuntimeException("MAV-565:  Task Complete Date not " +
                                            "visible - cannot click"));
                                }
                                throw enve;
                            } catch (WebDriverException e) {
                                SeleniumTest.click(we);
                            }
                        }
                    }
                }
            }
            if (dropdown.getAttribute("aria-expanded").equals("true")) {
                dropdown.click();
            }

        } catch (NoSuchElementException | NullPointerException e) {
            // This means we have hit the reference code drop down which react
            selector = Driver.getDriver().findElement(By.xpath("//label[text()=" +
                    "'" + label + "']/following-sibling::select"));

            if (!dropdown.getAttribute("class").contains("active")) {
                dropdown.click();
            }
            for (String value : values) {
                WebElement we = selector.findElement(By.xpath("//li/label/input[@value='" + value + "']"));
                String title = we.getAttribute("title").trim();
                if (title.startsWith(value)) {
                    SeleniumTest.waitUntilElementIsDisplayedThenSelect(we);
                }
            }
            if (dropdown.getAttribute("class").contains("active")) {
                dropdown.click();
            }
        }
    }

    /**
     * Clears and Sets the value of ANY filterable text box in the Search Filter Window
     *
     * @param label The name of the label for the text box you intend to set
     * @param value The value you want placed into the text box field
     */
    public static void clearAndSetValueInTextBox(String label, String value) {
        WebElement textbox = Driver.getDriver().findElement(By.xpath("//label[text()='"
                + label + "']/following-sibling::input"));
        SeleniumTest.clearAndSetText(textbox, value);
    }

    /**
     * Method to type due date from
     * @param date
     */
    public static void typeDueDateFrom(java.time.LocalDate date) {
        setCalendarControlDate(dueDateFrom, date, LocaleHelper.getDateFormatShortDateSlash());
    }

    /**
     * Method to type due date To
     * @param date
     */
    public static void typeDueDateTo(java.time.LocalDate date) {
        setCalendarControlDate(dueDateTo, date, LocaleHelper.getDateFormatShortDateSlash());
    }

    public static void setCalendarControlDate(WebElement controlID, java.time.LocalDate dateToSet, java.time.format.DateTimeFormatter format) {
        String formattedDate = dateToSet.format(format);
        JavaScriptHelper.runScript("$(\"#" + controlID.getAttribute("id") + "\").val('" + formattedDate + "');");
    }
}
