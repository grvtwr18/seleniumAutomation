package Sites.TalentWiseDashboard.Tasks;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author sbashar
 */
public class ScreeningTasksPage extends TasksPage {

    @FindBy(how = How.CSS , using = "span.k-icon.k-i-seek-e")
    private static WebElement goToLastPage;

    @FindBy(how = How.CSS , using = "span.k-icon.k-i-arrow-w")
    private static WebElement goToPreviousPage;

    @FindBy(how = How.CSS, using = "input[value='Confirm']")
    private static WebElement confirmButton;

    @FindBy(how = How.CSS , using = "#bulkActionSelect")
    private static WebElement bulkAction;

    @FindBy(how = How.CSS , using = "#bulkActionSubmit")
    private static WebElement bulkActionSubmit;

    @FindBy(how = How.CSS, using = "input[value='Continue']")
    private static WebElement continueButton;

    @FindBy(how = How.CSS, using = "input[value='Close']")
    private static WebElement closeButton;

    @FindBy(how = How.LINK_TEXT, using = "Onboarding Tasks")
    private static WebElement onboardingTasksSubTab;

    private static final Logger staticLogger = LoggerFactory.getLogger(ScreeningTasksPage.class.getName());

    /**
     * Enum to select Action Drop Down Options partial ids
     */
    public enum ActionDropDownPartialIds {
        VIEW_REPORT("view_report"),
        OPEN_PDF("open_pdf"),
        PRINT_REPORT("print_report"),
        EMAIL_REPORT("email_report"),
        RESEND_NOTIFICATION("resend_notifications"),
        EDIT_TASKS("edit_tasks"),
        CANCEL("cancel"),
        COMPLETE_ADVERSE_ACTION("complete_adverse_action");

        private final String text;
        ActionDropDownPartialIds(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    public static void selectActionDropdown(int candidateId, int
            candidateIndex, ActionDropDownPartialIds partialId) {
        List<WebElement> actionDropdowns = Driver.getDriver().findElements(By.xpath
                (".//td[contains(., '" + candidateId + "')]/preceding-sibling::td/div/span/select"));

        Select actionDropdown = new Select(actionDropdowns.get(candidateIndex));
        SeleniumTest.click(actionDropdowns.get(candidateIndex));

        SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, partialId.toString());
    }

    public static boolean isReportListed(int candidateId) {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath
                (".//td[contains(., '" + candidateId + "')]/preceding-sibling::td/div/span/select"));
    }

    public static void selectCandidateReport(int candidateId) {
        int count = getScreeningTaskCount();
        if (1 != count) {
            staticLogger.warn("ScreeningTasksPage.openScreeningTask(candidateId={}) : {} tasks found when only 1 was expected.",
                    candidateId, count);
        }
        //If .check does not enable bulk action dropdown in lab, try clicking on checkbox and see if it works.
        SeleniumTest.check(By.xpath(".//td[contains(., '" + candidateId + "')]/preceding-sibling::td/input[@type='checkbox']"));
    }

    public static void selectBulkActionAndSubmit(String action) {
        SeleniumTest.waitForElementEnabled(bulkAction);
        logger.info("Wait up to 60 seconds for this Bulck Actions drop-down to be clickable ...");
        logger.info("For some reason it is taking a long time to be clickable in the Jenkins lab");
        SeleniumTest.waitForElementToBeClickable(By.id("bulkActionSelect"), 60);
        SeleniumTest.selectByVisibleTextFromDropDown(bulkAction, action);
        SeleniumTest.click(bulkActionSubmit);
    }

    public static void goToLastPage() {
        SeleniumTest.click(goToLastPage);
    }

    public static ScreeningTasksPage clickConfirm(){
        SeleniumTest.click(confirmButton);
        SeleniumTest.waitForPageLoadToComplete();
        return PageFactory.initElements(Driver.getDriver(), ScreeningTasksPage.class);
    }

    public static ScreeningTasksPage clickContinue(){
        SeleniumTest.click(continueButton);
        return PageFactory.initElements(Driver.getDriver(), ScreeningTasksPage.class);
    }

    public static ScreeningTasksPage clickClose(){
        SeleniumTest.click(closeButton);
        return PageFactory.initElements(Driver.getDriver(), ScreeningTasksPage.class);
    }

    public static OnboardingTasksPage clickOnboardingTasksSubTab() {
        SeleniumTest.click(onboardingTasksSubTab);
        SeleniumTest.waitForPageLoad();
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    /**
     * Go to ugly extremes to obtain the number of Screening Tasks available to the customer on this page.
     * It was very hard to find all the reasons why this routine might not work.
     *
     * @return the number of Screening Tasks available to the customer on this page
     */
    public static int getScreeningTaskCount() {
        final int timeOutInSeconds = 45;
        final int retryInSeconds = 2;

        final By gridErrorNoItemsLocator = By.className("gridError");
        final By pageItemCountLocator = By.className("k-pager-info");

        WaitUntil.waitUntil(timeOutInSeconds, retryInSeconds, () -> {
            return SeleniumTest.isElementVisibleNoWaiting(gridErrorNoItemsLocator)
                    || SeleniumTest.isElementVisibleNoWaiting(pageItemCountLocator);
        });

        if (SeleniumTest.isElementVisibleNoWaiting(gridErrorNoItemsLocator)) {
            staticLogger.info("Screening Task Count = 0 for, \"No results found\"");
            return 0;
        }

        Pattern pattern = Pattern.compile("(?<taskItemCount>\\d+)\\s+items");
        // Yes! You have to go to these extremes to be sure you see the correct number of existing Screening Tasks!
        try {
            WaitUntil.waitUntil(timeOutInSeconds, retryInSeconds, () -> {
                String pageItemCountText = SeleniumTest.getTextByLocator(pageItemCountLocator);
                staticLogger.info("pageItemCountText: {}", pageItemCountText);

                if (null == pageItemCountText) {
                    if (SeleniumTest.isElementVisibleNoWaiting(gridErrorNoItemsLocator)) {
                        staticLogger.info("Saw, \"No results found\"");
                        return true;
                    }
                }
                // Keep checking until the text matches the pattern, or 10 seconds have passed ...
                return pattern.matcher(pageItemCountText).find();
            });
        } catch (TimeoutException e) {
            staticLogger.info("Never found \"\\d+ items\" so assuming no Screening Tasks");
            return 0;
        }

        String pageItemCountText = SeleniumTest.getTextByLocator(pageItemCountLocator);

        if (null == pageItemCountText) {
            if (SeleniumTest.isElementVisibleNoWaiting(gridErrorNoItemsLocator)) {
                staticLogger.info("Screening Task Count = 0 for, \"No results found\"");
            } else {
                staticLogger.warn("Assuming no Screening Tasks, though failing to see, \"No results found\"");
            }

            return 0;
        }

        Matcher matcher = pattern.matcher(pageItemCountText);

        if (matcher.find()) {
            return Integer.parseInt(matcher.group("taskItemCount"));
        } else {
            staticLogger.warn("pageItemCountText stopped showing \"\\d+ items\", but showed this instead: {}", pageItemCountText);
            return 0;
        }
    }

    /**
     * Cancel all Screening Tasks that currently show, all of which are expected to have a status contained within the expectedStatuses.
     * If a current showing task has a status that is not contained within the expectedStatuses, return false.
     * If more than 10 tasks are showing to be cancelled, return false.
     * When this routine returns false, that probably means this page's search filters should be re-applied.
     *
     * @param expectedStatuses expected statuses of tasks that are to be cancelled
     * @return false if more than 10 tasks are showing to be cancelled, or if a showing task has an unexpected status.
     */
    public static boolean cancelAllVisibleScreeningTasks(String... expectedStatuses) {
        for (int count = getScreeningTaskCount(); 0 < count; count = getScreeningTaskCount()) {
            staticLogger.info("{} older Screening Tasks remain to be cancelled", count);

            if (10 < count) {
                staticLogger.warn("Assuming something must be wrong; too many tasks to cancel: " + count);
                return false;
            }

            // For some reason a first click() like this is necessary before one can truly interact with the dropdown ...
            SeleniumTest.waitForElementToBeClickable(By.className("taskactions"));
            SeleniumTest.waitMs(3000);//keeps failing in lab only
            SeleniumTest.click(By.className("taskactions"));
            // Get the current candidateId, and then determine whether its status is contained within expectedStatuses ...
            WebElement taskDropDown = Driver.getDriver().findElement(By.xpath("//select[@id[starts-with(., 'taskselectcandidate_')]]"));
            int candidateId = Integer.parseInt(taskDropDown.getAttribute("id").split("_")[1]);
            staticLogger.info("Attempting to cancel the task for Candidate ID={}", candidateId);
            String taskStatus = getCandidateTaskStatus(candidateId);
            staticLogger.info("The task for Candidate ID={} has Status = {}", candidateId, taskStatus);

            boolean statusIsExpected = false;

            for (String expectedStatus : expectedStatuses) {
                if (expectedStatus.equalsIgnoreCase(taskStatus)) {
                    statusIsExpected = true;
                    break;
                }
            }

            if (!statusIsExpected) {
                staticLogger.warn("The task for Candidate ID={} has an unexpected Status: {}", candidateId, taskStatus);
                return false;
            }

            SeleniumTest.selectByVisibleTextFromDropDown(taskDropDown, "Cancel Task");
            SeleniumTest.waitForAlert();
            SeleniumTest.acceptAlert();
            SeleniumTest.waitForAlertToGoAway();
            SeleniumTest.waitForPageLoad();

            final int lastCount = count;
            // The number of screening tasks should have decreased after doing this!
            WaitUntil.waitUntil(() -> {
                if (SeleniumTest.isAlertPresent()) {
                    SeleniumTest.acceptAlert();
                    return false;
                }

                if (getScreeningTaskCount() < lastCount) {
                    return true;
                }

                // Refresh the page because the visible Item Count label doesn't always update when it should!
                SeleniumTest.refreshCurrentPage();
                return false;
            });
        }

        return true;
    }

    public static void openScreeningTask(int candidateId) {
        int count = getScreeningTaskCount();
        if (1 != count) {
            staticLogger.warn("OnboardingTasksPage.openScreeningTask(candidateId={}) : {} tasks found when only 1 was expected.",
                    candidateId, count);
        }
        // For some reason a first click() like this is necessary before one can truly interact with the dropdown.
        // The following is supposed to click the last dropdown which should correspond with the desired candidateId ...
        List<WebElement> taskActionDropDowns = Driver.getDriver().findElements(By.className("taskactions"));
        SeleniumTest.click(taskActionDropDowns.get(taskActionDropDowns.size() - 1));
        WindowManagement.runMethodToOpenNewWindow(
                () -> SeleniumTest.selectByVisibleTextFromDropDown(By.id("taskselectcandidate_" + candidateId), "Open Task"),
                true);
    }

    public static String getCandidateTaskStatus(int candidateId) {
        return SeleniumTest.getTextByLocator(By.xpath("//select[@id='taskselectcandidate_"
                + candidateId + "']/../../../preceding-sibling::td/following-sibling::td[3]"));
    }

    public static String getCandidateTaskStatusFromSearchResults(int candidateID) {
        return SeleniumTest.getTextByLocator(By.xpath("//td[contains(., '" + candidateID + "')]/preceding-sibling::td[5]"));
    }
}
