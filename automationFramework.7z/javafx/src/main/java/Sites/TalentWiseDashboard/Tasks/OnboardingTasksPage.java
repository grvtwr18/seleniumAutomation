package Sites.TalentWiseDashboard.Tasks;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.TalentWiseDashboard.CustomerDashboardPages;
import Sites.TalentWiseDashboard.EditTasksModal;
import Sites.TalentWiseDashboard.PrintPage;
import Sites.TalentWiseDashboard.ProductFormPages.CancelFormI9Page;
import Sites.TalentWiseDashboard.ResendNotificationModal;
import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import Sites.TalentWiseDashboard.CancelModal;
import Sites.URL;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import Workflows.Candidate;
import org.apache.commons.lang.SystemUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FilenameFilter;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jgupta on 8/21/2015.
 */
public class OnboardingTasksPage extends TasksPage {

    private static final String candidateBoxID = "search_CandidateID";
    @FindBy(how = How.CLASS_NAME, using = "dbSearchBox")
    public static WebElement dbSearchBox;
    @FindBy(how = How.CSS, using = "#savedSearchWidgets > div.field.multiselectField > button")
    public static WebElement savedSearchDropdown;
    @FindBy(how = How.ID, using = "savedSearchNewSearchBtn")
    public static WebElement saveNewSearchButton;
    @FindBy(how = How.ID, using = "search-spinner")
    public static WebElement saveNewSearchSpinner;
    @FindBy(how = How.CSS, using = ".ui-multiselect-checkboxes " +
            "label[for='ui-multiselect-savedSearchDD-option-0']")
    private static WebElement savedSearchDropdownFirstOption;
    @FindBy(how = How.ID, using = "savedSearchUpdateSearchBtn")
    public static WebElement updateSavedSearchButton;
    @FindBy(how = How.ID, using = "savedSearchMessage")
    public static WebElement savedSearchMessage;
    @FindBy(how = How.ID, using = "search-name-input")
    private static WebElement newSavedSearchTextBox;
    @FindBy(how = How.CSS, using = "i[title='Save']")
    private static WebElement saveTickmark;
    @FindBy(how = How.ID, using = "search_VerifierGroup-BTN")
    public static WebElement groupDropDown;
    @FindBy(how = How.ID, using = "search_VerifierGroup_CLEAR")
    private static WebElement groupDropDownClearSelectedCriteria;
    @FindBy(how = How.ID, using = "search_Verifier-BTN")
    private static WebElement assigneeDropDown;
    @FindBy(how = How.ID, using = "search_Verifier-text")
    public static WebElement assigneeDropDownSearchField;
    @FindBy(how = How.ID, using = "search_Verifier_CLEAR")
    private static WebElement assigneeDropDownClearSelectedCriteria;
    @FindBy(how = How.CSS, using = "li > a[title*='Unassigned']")
    public static WebElement assigneeDropDownUnassignedOption;
    @FindBy(how = How.CSS, using = "#search_Verifier > div > ul > li:nth-of-type(2) > a")
    private static WebElement assigneeDropDown2ndOption;
    @FindBy(how = How.ID, using = "search_Status-BTN")
    private static WebElement taskStatusDropDown;
    @FindBy(how = How.ID, using = "search_Status_CLEAR")
    private static WebElement taskStatusDropDownClearSelectedCriteria;
    @FindBy(how = How.CSS, using = "#search_Status > ul > li > a")
    public static WebElement taskStatusDropDownOptions;
    public static By taskStatusDropDownOptionsBy = By.cssSelector("#search_Status > ul > li > a");
    @FindBy(how = How.ID, using = "search_TaskTitle")
    public static WebElement taskTitleTextBox;
    @FindBy(how = How.ID, using = "AdditionalSearchCriteria-BTN")
    private static WebElement additionalSearchCriteriaDropDown;
    @FindBy(how = How.ID, using = "AdditionalSearchCriteria_CLEAR")
    private static WebElement additionalSearchCriteriaDropDownClearSelectedCriteria;
    @FindBy(how = How.CSS, using = "#AdditionalSearchCriteria")
    public static WebElement additionalSearchCriteriaDropDownList;
    @FindBy(how = How.ID, using = candidateBoxID)
    private static WebElement candidateIDTextbox;
    @FindBy(how = How.CSS, using = "input[value='Search']")
    private static WebElement basicSearchButton;
    @FindBy (how = How.CSS, using = "span[class='k-pager-info k-label']")
    private static WebElement taskGridItemsLabel;
    @FindBy(how = How.CSS, using = "td[class='gridError']")
    private static WebElement noResultsFoundMessage;
    @FindBy(how = How.CSS, using = "a[id^='tasklist_open_task_']")
    public static WebElement firstTaskNameHyperlink;
    @FindBy(how = How.CSS, using = "div.divButtonLower>input.button")
    private static WebElement advancedSearchButton;
    @FindBy(how = How.CSS, using = "span[class='k-pager-info k-label']")
    private static WebElement oneToXOfNItems;
    @FindBy(how = How.ID, using = "aShowAdvanced")
    private static WebElement showAdvancedOptionsSymbol;
    @FindBy(how = How.ID, using = "aHideAdvanced")
    private static WebElement hideAdvancedOptionsSymbol;
    @FindBy(how = How.XPATH, using = "//span[@class='taskactions']/select")
    private static WebElement actionDropdown;
    @FindBy(how = How.CSS, using = ".shadow > tbody > tr:first-child > td:nth-child(5)")
    private static WebElement firstTaskRecordAssigneeName;
    @FindBy(how = How.CLASS_NAME, using = "listPage")
    private static WebElement bodyContainer;
    @FindBy(how = How.XPATH, using = "//tbody[@role='rowgroup']/tr[1]/td[8]")
    private static WebElement firstDueDate;

    @FindBy(how = How.LINK_TEXT, using = "Screening Tasks")
    private static WebElement screeningTaskSubTab;

    private static final String OPEN_TASK_ID           = "open_task";
    private static final String VIEW_REPORT_ID         = "view_report";
    private static final String OPEN_PDF_ID            = "open_pdf";
    private static final String PRINT_REPORT_ID        = "print_report";
    private static final String RESEND_NOTIFICATION_ID = "resend_notifications";
    private static final String EDIT_TASKS_ID          = "edit_tasks";
    private static final String CANCEL_ID              = "cancel";


    private static By editTaskLocator = By.cssSelector("option[value^='edit']");
    @FindBy(how = How.ID, using = "customAdditionalColumn")
    private static WebElement columnFilterDropdown;
    @FindBy(how = How.ID, using = "customAdditionalColumns-BTN")
    private static WebElement additionalColumnsDropDown;
    @FindBy(how = How.ID, using = "customAdditionalColumns_CLEAR")
    private static WebElement additionalColumnsClearSelectedCriteria;
    private static WebElement clickableColumnFilterElement;
    @FindBy(how = How.ID, using = "customAdditionalColumns_CLEAR")
    private static WebElement uncheckAllLink;

    @FindBy(how = How.NAME, using = "ms_6_Custom Fields")
    private static WebElement AddSearchCriteriaCustomFields;

    @FindBy(how = How.NAME, using = "search_Verifier_typeahead")
    private static WebElement typeAhead;
    @FindBy(how = How.ID, using = "dlCsvLink")
    private static WebElement downloadCSVLink;
    private static WebElement element;

    static {
        PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    private final Sites.TalentWiseDashboard.Helpers.Sidebar sidebar;
    private final Sites.TalentWiseDashboard.Helpers.Header header;
    private final Sites.TalentWiseDashboard.Helpers.Footer footer;
    protected final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    private static final Logger staticLogger = LoggerFactory.getLogger(OnboardingTasksPage.class.getName());
    private final By openTaskIconLocator = By.xpath("//a[@title='Open Task']");
    public Sites.TalentWiseDashboard.Search.Records.RecordsTabs tabs;
    @FindBy(how = How.CSS, using = "a.ui-multiselect-none span:nth(1)")
    private WebElement uncheckAllGroupDropDown;
    @FindBy(how = How.CSS, using = "a.ui-multiselect-none span:nth(2)")
    private WebElement uncheckAllAssigneeDropDown;
    @FindBy(how = How.CSS, using = "a.ui-multiselect-none span:nth(4)")
    private WebElement uncheckAllTaskStatusDropDown;
    @FindBy(how = How.CSS, using = "button:nth(3)")
    private WebElement positionsDropDown;
    @FindBy(how = How.CSS, using = "button:nth(4)")
    public WebElement packagesDropDown;

    private static final Logger staticlogger = LoggerFactory.getLogger("SearchContributorsTasksPage");

    /**
     * Constructs a new Tasks page object.
     */
    public OnboardingTasksPage() {
        //The title of this page is "Tasks - TalentWise"

        this.sidebar = PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.Helpers.Sidebar.class);
        this.header = PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.Helpers.Header.class);
        this.footer = PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.Helpers.Footer.class);
        SeleniumTest.waitForJQueryAjaxDone();
    }

    /**
     * Navigates to the Tasks page directly or proxy'd
     * additional optional paramter is needed for proxy activity.
     * @throws UnknownHostException
     */
    public static void navigateTo(int... proxyId) throws UnknownHostException {
        int userId = proxyId.length > 0 ? (int) proxyId[0] : 0;
        String tasksUrl = "/screening/tasks.php";

        if (userId > 0) {
            tasksUrl += "?OverrideUserID=" + userId;
        }
        Driver.getDriver().get(URL.getURL(Sites.Site.CUSTOMER_DASHBOARD) + tasksUrl);

        staticLogger.info(
                "Navigated via URL to Tasks Page {}" , userId == 0 ? "directly" : "as proxy");
    }

    /**
     * Selects One or more values from the group dropdown.
     */
    public static void selectValuesFromGroupDropDown(String... values) {
        OnboardingTasksPage.clearThenSelectValuesFromMultiSelectDropdown("Group", values);
    }

    /**
     * Clears All Selected Filters in Group Drop Down, unless no filters are currently selected.
     */
    public static void clearAllSelected_GroupDropDown() {
        if (groupDropDown.getAttribute("aria-expanded").equals("false")) {
            groupDropDown.click();
        }

        if (groupDropDownClearSelectedCriteria.isDisplayed()) {
            groupDropDownClearSelectedCriteria.click();
        }
    }

    /**
     * Returns string of Group DropDown Selected text
     */
    public static String getGroupDropDownSelectedText() {
        return groupDropDown.getText();
    }

    /**
     * Select values from Assignee dropdown.
     */
    public static void selectValueFromAssigneeDropDown(String... values) {
        //TODO possibly remove this method, in favor of searchAndSelectValuesFromAssigneeDropDown() since this drop down works different with ES release.
        Driver.getDriver().findElement(By.xpath("//form//div/label[text()" +
                                                "='Assignee']/following-sibling::button")).click();
        checkValuesAUI(values);
        ((HasInputDevices) Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    // TODO will be used for test cases in the ES search tests
    /**
     * Opens Assignee Dropdown and enters search text into Assignee search field
     */
    public static void enterAssigneeDropDownSearchText(String searchText) {
        openMultiSelectDropDown(OnboardingTasksPage.Columns.ASSIGNEE.toString());
        assigneeDropDownSearchField.sendKeys(searchText);
    }

    /**
     * Opens Assignee Dropdown, clears and enters search text into Assignee search field
     */
    public static void clearAndEnterAssigneeDropDownSearchText(String searchText) {
        openMultiSelectDropDown(OnboardingTasksPage.Columns.ASSIGNEE.toString());
        SeleniumTest.clearAndSetText(assigneeDropDownSearchField, searchText);
    }

    /**
     * Calls enterAssigneeDropDownSearchText(searchText) and selects selectOption.
     */
    public static void enterAssigneeDropDownSearchTextAndSelect(String searchText, String selectOption) {
        staticLogger.info("Enter Search Text.");
        clearAndEnterAssigneeDropDownSearchText(searchText);

        staticLogger.info("Wait for assignee is displayed.");
        WaitUntil.waitUntil(60, 2,()->
                ((EventFiringWebDriver) Driver.getDriver()).getWrappedDriver()
                                                           .findElement(By.xpath("//li/a[contains(., '" + selectOption + "')]"))
                                                           .isDisplayed(), NoSuchElementException.class);

        staticLogger.info("Select assignee.");
        ((EventFiringWebDriver) Driver.getDriver()).getWrappedDriver()
                                                   .findElement(By.xpath("//li/a[contains(., '" + selectOption + "')]")).click();
    }

    /**
     * Opens Assignee Dropdown, clears and enters passed value as search text and
     * selects option containing passed value for each value in values.
     * @param values
     */
    public static void searchAndSelectValuesFromAssigneeDropDown(String... values) {
        openMultiSelectDropDown(TasklistColumn.ASSIGNEE.toString());

        for (String value : values) {
            enterAssigneeDropDownSearchTextAndSelect(value, value);
            staticLogger.info("Assignee Searched and Selected {}", value);

        }

        closeMultiSelectDropDown(TasklistColumn.ASSIGNEE.toString());
    }

    /**
     * Opens Assignee DropDown if not already open, and Selects Unassigned from Assignee DropDown if not already selected.
     */
    public static void selectUnassignedFromAssigneeDropDown() {
        openMultiSelectDropDown(OnboardingTasksPage.Columns.ASSIGNEE.toString());
        if(assigneeDropDownUnassignedOption.getAttribute("aria-checked").contains("false")) {
            assigneeDropDownUnassignedOption.click();
        }
    }

    /**
     * Clears All Selected Filters in Assignee Drop Down, unless no filters are currently selected.
     */
    public static void clearAllSelected_AssigneeDropDown() {
        if (assigneeDropDown.getAttribute("aria-expanded").equals("false")) {
            assigneeDropDown.click();
        }

        if (assigneeDropDownClearSelectedCriteria.isDisplayed()) {
            assigneeDropDownClearSelectedCriteria.click();
        }
    }

    /**
     * Returns string of Assignee Drop Down Selected text.
     */
    public static String getAssigneeDropDownSelectedText() {
        return assigneeDropDown.getText();
    }

    /**
     * Clears All Selected Filters in Task Status Drop Down, unless no filters are currently
     * selected.
     */
    public static void clearAllSelected_TaskStatusDropDown() {
        if (taskStatusDropDown.getAttribute("aria-expanded").equals("false")) {
            taskStatusDropDown.click();
        }

        if (taskStatusDropDownClearSelectedCriteria.isDisplayed()) {
            taskStatusDropDownClearSelectedCriteria.click();
        }
    }

    /**
     * Returns string of Task Status Drop Down Selected text.
     */
    public static String getTaskStatusDropDownSelectedText() {
        return taskStatusDropDown.getText();
    }

    /**
     * Returns string of text currently in Task Title Search Text Box
     */
    public static String getTaskTitleSearchBoxText() {
        return taskTitleTextBox.getText();
    }

    /**
     * Returns string of Additional Search Criteria Drop Down list.
     */
    public static WebElement getAdditionalSearchCriteriaDropDownList() {
        additionalSearchCriteriaDropDown.click();
        return additionalSearchCriteriaDropDownList;
    }

    /**
     * Returns string of Additional Search Criteria Drop Down Selected text.
     */
    public static String getAdditionalSearchCriteriaDropDownText() {
        return additionalSearchCriteriaDropDown.getText();
    }

    /**
     * Clear all selected filters in Additional Search Criteria Drop Down, unless no filters are
     * currently selected.
     */
    public static void clearAllSelected_AdditionalSearchCriteriaDropDown() {
        if (additionalSearchCriteriaDropDown.getAttribute("aria-expanded").equals("false")) {
            additionalSearchCriteriaDropDown.click();
        }

        if (additionalSearchCriteriaDropDownClearSelectedCriteria.isDisplayed()) {
            additionalSearchCriteriaDropDownClearSelectedCriteria.click();
        }
    }

    public static OnboardingTasksPage clickAdditionalSearchCriteriaDropDown() {
        additionalSearchCriteriaDropDown.click();
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    public static OnboardingTasksPage selectAdditionalSearchCriteriaCustomField() {
        if (additionalSearchCriteriaDropDown.getAttribute("aria-expanded").equals("false")) {
            additionalSearchCriteriaDropDown.click();
        }
        AddSearchCriteriaCustomFields.click();
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    private static By.ById getEnumCustomFieldLocator(int customFieldID) {
        return new By.ById("CustomField" + customFieldID + "_FormUserArea_1-BTN");
    }

    private static By.ByXPath getEnumCustomFieldSelectionLocator(int customFieldID, int dropDownIndex) {
        return new By.ByXPath("//*[@id=\"CustomField" + customFieldID + "_FormUserArea_1\"]/div/ul/li[" + (dropDownIndex+1) + "]/a");
    }

    public static List<WebElement> getEnumCustomFieldSearchOptions(int customFieldCount) {
        SeleniumTest.waitForElementToBeClickable(
                Driver.getDriver().findElement(getEnumCustomFieldLocator(customFieldCount)));
        Driver.getDriver().findElement(getEnumCustomFieldLocator(customFieldCount)).click();
        Integer count = 0;
        ArrayList<WebElement> customFieldEnumOptions = new ArrayList();
        while(true) {
            final By locator = getEnumCustomFieldSelectionLocator(customFieldCount, count);

            if (!SeleniumTest.isElementVisibleNoWaiting(locator)) {
                break;
            }

            customFieldEnumOptions.add(
                    Driver.getDriver().findElement(locator));
            staticlogger.info("Found {}", customFieldEnumOptions.get(count).getAttribute("Title"));
            count++;
        }
        return customFieldEnumOptions;
    }

    /**
     * Clicks on "+" button of Advanced Search.only if it is required. Doesn't do anything if
     * advanced search options are already expanded.
     */
    public static OnboardingTasksPage showAdvancedSearchOptions() {
        if (showAdvancedOptionsSymbol.isDisplayed()) {
            showAdvancedOptionsSymbol.click();
        }
        WaitUntil.waitUntil(() -> hideAdvancedOptionsSymbol.isDisplayed());
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    /**
     * Types Candidate ID in Candidate id textbox
     */
    public static OnboardingTasksPage typeCandidateID(String id) {
        SeleniumTest.clearAndSetText(candidateIDTextbox, id);
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    /**
     * Clicks on Search button for basic search
     */
    public static void clickBasicSearchButton() {
        basicSearchButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    /**
     * Clicks on View report icon in the grid in the given row and column
     */
    public static ViewReportPage clickViewReportIconInGrid(int row) {
        //Wait for grid elements to load

        WaitUntil.waitUntil(() -> Driver.getDriver().findElements(By.xpath("//i[@title='Quick View']")).size() >= row);
        List<WebElement> viewReportIcons = Driver.getDriver().findElements(By.xpath("//i[@title='Quick View']"));

        WindowManagement.clickElementToOpenNewWindow(viewReportIcons.get(row - 1));

        return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);
    }

    /**
     * This method returns the text displayed at the bottom of the results grid. Eg: 1 to 10 of 30
     * results
     *
     * @return String
     */
    public static String get1ToXOfNString() {
        return oneToXOfNItems.getText();
    }

    /**
     * This method is used to wait for the grid to load.
     */
    public static void waitForGridToLoad() {
        SeleniumTest.defaultWaitForElementWithMultiplier(.5);
        SeleniumTest.waitForJQueryAjaxDone();
        waitForTaskGridLabelIsVisible();
    }

    /**
     * Types in Task Title textbox
     */
    public static void typeTaskTitle(String title) {
        taskTitleTextBox.sendKeys(title);
    }

    /**
     * Clears Task Title texbox and then Enters passed string into textbox
     */
    public static void clearAndEnterTaskTitleText(String title) {
        SeleniumTest.waitForElementEnabled(taskTitleTextBox);
        SeleniumTest.clearAndSetText(taskTitleTextBox, title, true);
    }

    /**
     * Saves a new search by the specified name
     */
    public static void saveNewSearch_NoWait(String searchName) {
        Actions actions = new Actions(Driver.getDriver());

        // compensates for the lab's view port size.
        actions.moveToElement(saveNewSearchButton, 20, 20).perform();
        saveNewSearchButton.click();

        // because sometimes it moves to text box too fast after clicking the saveNewSearchButton
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
        SeleniumTest.clearAndSetText(newSavedSearchTextBox, searchName);

        // because sometimes it moves to saveTickmark too fast after entering text.
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);

        // again compensating for the lab's view port size.
        actions.moveToElement(saveTickmark, 20, 20).perform();
        saveTickmark.click();
    }

    /**
     * Clicks on Saved search dropdown.
     */
    public static void clickSavedSearchDropdown() {
        // because sometimes it tries to click before the savedSearchDropdown is ready.
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
        savedSearchDropdown.click();
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
    }

    /**
     * Opens Saved Search dropdown only if not already open.
     */
    public static void openSavedSearchDropdown() {
        if (!savedSearchDropdown.getAttribute("class").contains("ui-state-active")) {
            clickSavedSearchDropdown();
        }
    }

    /**
     * Closes Saved Search dropdown only if not already closed.
     * Note: This will fail if user has absolutely no saved searches, otherwise works great.
     */
    public static void closeSavedSearchDropdown() {
        if(savedSearchDropdownFirstOption.isDisplayed()
                && savedSearchDropdown.getAttribute("class").contains("ui-state-active")) {
            clickSavedSearchDropdown();
        }
    }

    /**
     * Opens multi select drop down of passed dropDownLabel only if not already open.
     */
    public static void openMultiSelectDropDown(String dropDownLabel) {
        WebElement dropdown = Driver.getDriver().findElement(By.xpath("//label[contains(text(),'"
                                                                      + dropDownLabel + "')]/following-sibling::button"));
        if (dropdown.getAttribute("aria-expanded").equals("false")) {
            dropdown.click();
        }
        WaitUntil.waitUntil(() -> dropdown.getAttribute("aria-expanded").equals("true"));
    }

    /**
     * Closes multi select drop down of passed dropDownLabel only if not already closed.
     */
    public static void closeMultiSelectDropDown(String dropDownLabel) {
        WebElement dropdown = Driver.getDriver().findElement(By.xpath("//label[contains(text(),'" + dropDownLabel + "')]/following-sibling::button"));
        if (dropdown.getAttribute("aria-expanded").equals("true")) {
            dropdown.click();
        }
    }

    /**
     * Returns a list of all options found in passed dropDownLabel.
     * This is primarily a helper method for multiSelectDropDownContains(),
     * but not exclusively. This may / will also be called directly by future tests.
     * @param dropDownLabel
     * @return
     */
    public static ArrayList<String> getMultiSelectDropDownOptions(String dropDownLabel) {
        openMultiSelectDropDown(dropDownLabel);

        String idString = Driver.getDriver().findElement(By.xpath("//label[text()='" + dropDownLabel + "']")).getAttribute("for").trim();

        List<WebElement> elements = Driver.getDriver().findElements(By.cssSelector("#" + idString + " > div > ul > li > a"));
        ArrayList<String> optionStrings = new ArrayList<>();

        for (WebElement element : elements) {
            optionStrings.add(element.getText());
        }

        return optionStrings;
    }

    /**
     * Returns true if passed dropDownLabel contains passed option.
     * @param dropDownLabel
     * @param option
     * @return
     */
    public static boolean multiSelectDropDownContains(String dropDownLabel, String option) {
        ArrayList<String> optionStrings = getMultiSelectDropDownOptions(dropDownLabel);
        return optionStrings.contains(option);
    }

    /**
     * Clicks on Update Saved Search Button
     */
    public static void clickUpdateSavedSearchButton() {
        updateSavedSearchButton.click();
    }

    /**
     * Deletes the specified search name unless the search isn't there, in which case it does nothing.
     */
    public static void deleteSavedSearch(String savedSearchName) {
        try {

            final By theSelector = By.cssSelector("label[title='" + savedSearchName + "']");
            WebElement element = Driver.getDriver().findElement(
                    theSelector);
            Actions actions = new Actions(Driver.getDriver());
            actions.moveToElement(element, 20, 20).perform();
            if (!element.isDisplayed()) {
                clickSavedSearchDropdown();
            }
            final WebElement deleteButton = ((EventFiringWebDriver) Driver.getDriver())
                    .getWrappedDriver().findElement(By.cssSelector("label[title='" +
                    savedSearchName + "'] div[class='search-multiselect-edit-buttons'] " +
                    "i[title='Delete']"));
            deleteButton.click();
            // Specifically looks for element(s) and a size of 0 before returning true
            // If the element is actually gone - avoids having to handle StaleElementException in
            // catch block. And returns quicker than a timeOut exception
            WaitUntil.waitUntil(() -> ((EventFiringWebDriver) Driver.getDriver())
                    .getWrappedDriver()
                    .findElements(
                            By.cssSelector("label[title='"
                                           + savedSearchName
                                           + "'] div[class='search-multiselect-edit-buttons'] "
                                           + "i[title='Delete']")).size() == 0);
        } catch (NoSuchElementException | TimeoutException e) {
            // do nothing, this just means the search isn't there, and we don't care.
            staticLogger.info("The Saved Search {} was not found in the Saved Search drop down.",
                    savedSearchName);
        }
        closeSavedSearchDropdown();
    }

    /**
     * Opens Saved Search Drop Down if not already open and clicks on Saved search name.
     */
    public static void clickSavedSearchName(String savedSearchName) {
        openSavedSearchDropdown();
        WebElement someElement = Driver.getDriver().findElement(By.xpath("//label[@title='" +
                                                                         savedSearchName + "']"));
        Actions actions = new Actions(Driver.getDriver());
        SeleniumTest.waitForElementVisible(someElement);
        SeleniumTest.waitForElementToBeClickable(someElement,5000);
        actions.moveToElement(someElement);
        actions.perform();
        SeleniumTest.waitMs(2000);
        someElement.click();
        WaitUntil.waitUntil(() -> !saveNewSearchSpinner.isDisplayed());
    }

    /**
     * Returns string of message displayed to user.
     */
    public static String getSavedSearchMessageText() {
        WaitUntil.waitUntil(()->
                savedSearchMessage.getText().length() > 0 &&
                OnboardingTasksPage.savedSearchMessage
                .getAttribute("style").contains("display: block"));
        SeleniumTest.waitMs(2000);
        return savedSearchMessage.getText();
    }

    public static boolean isSavedSearchMessageDisplayed() {
        return OnboardingTasksPage.savedSearchMessage
                .getAttribute("style").contains("display: block");
    }

    /**
     * Returns string of Currently Selected Saved Search Title from Saved Search Dropdown.
     */
    public static String getSelectedSavedSearchTitle() {
        return savedSearchDropdown.getText();
    }

    public static void clearAllFiltersOnThePage() {
        JavaScriptHelper.runScript("javascript:dbClearForm(true)");
    }

    /**
     * Returns all Saved Search Titles strings on the OnboardingTasksPage Page
     *
     * @return List of Strings representing each search title
     */
    private static ArrayList<String> getAllSavedSearchTitlesText() {
        openSavedSearchDropdown();

        WaitUntil.waitUntil(() -> savedSearchDropdownFirstOption.isDisplayed());
        List<WebElement> elements = Driver.getDriver().findElements(By.cssSelector(
                ".ui-multiselect-checkboxes label[for^='ui-multiselect-savedSearchDD-option']"));
        ArrayList<String> searchTitles = new ArrayList<String>();

        for (WebElement element : elements) {
            searchTitles.add(element.getAttribute("title"));
        }

        return searchTitles;
    }

    /**
     * Search Title verify - Returns true only if passed titleString is present in the Saved Search
     * Titles. Throws an exception if the titleString supplied is NULL
     *
     * @return true if the string exists
     */
    public static boolean savedSearchTitleExists(String titleString) {
        if (titleString == null) {
            throw new RuntimeException("You did not supply a string for comparison - nothing to " +
                    "compare");
        }

        for (String title : getAllSavedSearchTitlesText()) {
            if (title == null) {
                continue;
            }

            if (titleString.equals(title)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Select Edit Task
     */
    public static EditTasksModal selectEditTask(String applicantID) {
        // Worked on this for over 2 hours - tired of fighting it put in explicit waits to allow
        // this to work.
        SeleniumTest.waitMs(5000);
        WebElement element = Driver.getDriver().findElement(By.xpath("//select[@id='action_" +
                                                                     applicantID + "']"));
        new Actions(Driver.getDriver()).moveToElement(element).perform();
        SeleniumTest.waitMs(5000);
        element = Driver.getDriver().findElement(By.xpath("//select[@id='action_" + applicantID +
                                                          "']"));
        element.click();
        // Re-find the element because it goes stale the moment you click on it
        SeleniumTest.waitMs(5000);
        element = Driver.getDriver().findElement(By.xpath("//select[@id='action_" + applicantID +
                                                          "']"));
        Select actionSelect = new Select(element);
        //TODO change this to a different locator
        actionSelect.selectByVisibleText("Edit Tasks");

        return PageFactory.initElements(Driver.getDriver(), EditTasksModal.class);
    }

    /**
     * Selects additional columns if any supplied to parameters
     *
     * @param columns The columns you wish to select
     */
    public static void selectAdditionalColumns(Columns... columns) {
        uncheckAllAdditionalColumns();

        List<OnboardingTasksPage.Columns> columnsCollection = ((columns == null) ? java.util.Collections.emptyList() : Arrays.asList(columns));

        for (Columns c : columnsCollection) {
            final WebElement element = Driver.getDriver().findElement(By.xpath("//a[@data-key='"
                                                                               + c.getData_Key() + "']"));
            if (!element.isDisplayed()) {
                clickableColumnFilterElement.click();
            }
            if (!element.getAttribute("aria-checked").equals("true")) {
                element.click();
            }
            WaitUntil.waitUntil(() -> element.getAttribute("aria-checked").equals("true"));
        }

    }

    public static OnboardingTasksPage uncheckAllAdditionalColumns() {
        if (!uncheckAllLink.isDisplayed()) {
            additionalColumnsDropDown.click();
        }
        if (uncheckAllLink.isDisplayed()) {
            uncheckAllLink.click();
        }
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    public static Boolean isAdditionalColumnVisibleAndOrderedCorrectly(Columns column) {

        List<WebElement> elements = Driver.getDriver().findElements(By.xpath
                ("//th[@role='columnheader']"));

        switch (column) {
            case TASK_ROLE:
                if (elements.get(9).getText().equals(column.toString())) {
                    return true;
                }
                break;
            case TASK_COMPLETE_DATE:
                if (elements.get(8).getText().equals(column.toString())) {
                    return true;
                }
                break;
            case PACKAGES:
                if (elements.get(10).getText().equals(column.toString())) {
                    return true;
                }
                break;
            case EMPLOYEE_ID:
                if (elements.get(11).getText().equals(column.toString())) {
                    return true;
                }
            default:
                break;
        }
        return false;
    }

    public static Boolean isAdditionalColumnsDropdownInAlphabeticalOrder() {

        List<WebElement> options = Driver.getDriver().findElements(By.xpath
                ("//div[@id='customAdditionalColumns']/div/ul/li/a"));

        return options.get(0).getAttribute("data-key").equals(Columns.EMPLOYEE_ID.getData_Key()) &&
                options.get(1).getAttribute("data-key").equals(Columns.PACKAGES.getData_Key()) &&
                options.get(2).getAttribute("data-key").equals(Columns.TASK_COMPLETE_DATE.getData_Key()) &&
                options.get(3).getAttribute("data-key").equals(Columns.TASK_ROLE.getData_Key());
    }

    /**
     * Is the label present
     */
    public static boolean isLabelShowing(String label) {
        return Driver.getDriver().findElement(By.xpath("//label[text()='" + label + "']"))
                     .isDisplayed();
    }

    /**
     * Select single value from drop down
     *
     * @param label Label for the value to select
     * @param value the value to select
     */
    public static void selectValueFromSingleSelectDropdown(String label, String value) {
        WebElement dropdown = Driver.getDriver().findElement(By.xpath("//label[text()=" +
                                                                      "'" + label + "']/following-sibling::*"));
        switch(dropdown.getAttribute("type")) {
            case "select-one":
                Select selector = new Select(dropdown);
                selector.selectByVisibleText(value);
                break;
            case "submit":
                if (dropdown.getAttribute("aria-expanded").equals("false")) {
                    dropdown.click();
                }
                WebElement we = dropdown.findElement(By.xpath("//li/a[text()='" + value + "']"));
                String title = we.getAttribute("title").trim();
                if (we.isDisplayed()) {
                    if (title.startsWith(value)) {
                        if (!we.isSelected()) {
                            we.click();
                        }
                    }
                }
                if (dropdown.getAttribute("class").contains("active")) {
                    dropdown.click();
                }
                break;
        }
    }

    public static boolean isResultSetColumnDimensionDefault(Columns column) {
        WebElement columnElement = column.getWebElement();
        // Calculate border thickness * 2 to make sure we account for both sides of width or top
        // and bottom of height
        try {
            String columnAttributes = columnElement.getAttribute("style");
            if (columnAttributes == null) {
                return false;
            }

            int borderThickness = Integer.parseInt(columnAttributes.split(": ")[1]
                    .split(" ")[0].substring(0, 1)) * 2;

            return column.defaultDimension.width <= columnElement.getSize().width &&
                    column.defaultDimension.width + borderThickness >= columnElement.getSize()
                            .width &&
                    column.defaultDimension.height <= columnElement.getSize().height &&
                    column.defaultDimension.height + borderThickness >= columnElement.getSize()
                            .height;
        } catch (NullPointerException npe) {
            return false;
        }
    }

    /**
     * Returns the visible records found on the current page of the result set
     *
     * @return List<Map<String, String>> of the records found
     */
    public static List<Map<String, String>> getVisibleResultSet() {

        List<WebElement> headerRow = Driver.getDriver().findElements(By.xpath
                ("//thead/tr[@role='row']/th[@role='columnheader']"));
        List<String> columns = new ArrayList<>();

        for (WebElement header : headerRow) {
            columns.add(header.getText());
        }

        List<WebElement> tableRows = Driver.getDriver().findElements(By.xpath
                ("//tbody/tr[@role='row']"));
        List<Map<String, String>> records = new ArrayList<>();

        for (WebElement tableRow : tableRows) {

            List<WebElement> fields = tableRow.findElements(By.xpath(".//td"));

            Map<String, String> rowRecord = new HashMap<>();
            for (WebElement field : fields) {
                rowRecord.put(columns.get(fields.indexOf(field)), field.getText());
            }
            records.add(rowRecord);
        }
        return records;
    }

    /**
     * Returns the visible records found on the current page of the result set
     *
     * @return List<Map<String, String>> of the records found
     */
    public static List<Map<String, WebElement>> getVisibleElementResultSet() {

        List<WebElement> headerRow = Driver.getDriver().findElements(By.xpath
                ("//thead/tr[@role='row']/th[@role='columnheader']"));
        List<String> columns = new ArrayList<>();

        for (WebElement header : headerRow) {
            columns.add(header.getText());
        }

        List<WebElement> tableRows = Driver.getDriver().findElements(By.xpath
                ("//tbody/tr[@role='row']"));
        List<Map<String, WebElement>> records = new ArrayList<>();

        for (WebElement tableRow : tableRows) {

            List<WebElement> fields = tableRow.findElements(By.xpath(".//td"));

            Map<String, WebElement> rowRecord = new HashMap<>();
            for (WebElement field : fields) {
                rowRecord.put(columns.get(fields.indexOf(field)), field);
            }
            records.add(rowRecord);
        }
        return records;
    }

    public static void downloadToCSV_Deletes_Old_Creates_New_File() {
        if (!deleteDownloadedTaskListCSVFiles()) {
            staticLogger.info("Not all Files were deleted!  TEST MAY FAIL!");
        }
        downloadCSVLink.click();
        WaitUntil.waitUntil(() -> {
            return doesDownloadedFileExist();
        });
    }

    private static boolean deleteDownloadedTaskListCSVFiles() {
        File[] children = getDownloadedTaskListCSVFiles();
        boolean deleted = false;
        int counter = 0;
        for (File f : children) {
            deleted = f.delete();
            if (!deleted) {
                counter++;
            }
        }
        WaitUntil.waitUntil(() -> {
            return !doesDownloadedFileExist();
        });
        return counter == 0;
    }

    private static boolean doesDownloadedFileExist() {
        File[] children = getDownloadedTaskListCSVFiles();
        return children.length != 0;
    }

    public static File[] getDownloadedTaskListCSVFiles() {
        File parent = null;

        if (!SystemUtils.IS_OS_WINDOWS) {
            parent = new File(System.getProperty("user.home") + "/Downloads");
        } else {
            parent = new File(System.getenv("USERPROFILE") + "\\Downloads");
        }
        return parent != null ? parent.listFiles(file -> {
            return file.getName().toLowerCase().startsWith("talentwise_task_list_export-");
        }) : new File[0];
    }

    /**
     * Selects a saved search from the Save Search Dropdown
     *
     * @param savedSearchName The name of the saved search to retrieve
     */
    public static void selectSavedSearch(String savedSearchName) {
        if (!savedSearchDropdown.getAttribute("class").contains("ui-state-active")) {
            clickSavedSearchDropdown();
        }
        WebElement element =
                Driver.getDriver().findElement(
                        By.xpath("//li/label/div/span[text()='" + savedSearchName + "']"));
        Actions myAction = new Actions(Driver.getDriver());
        myAction.moveToElement(element);
        myAction.perform();
        element.click();

    }

    /**
     * Retrieves the visible text in the filter drop down text box
     *
     * @param label Label for the filter you want the value from
     * @return the value found in the text box of the filter.
     */
    public static String getValueOfFilter(String label) {
        WebElement element = Driver.getDriver().findElement(By.xpath("//label[text()='" + label +
                                                                     "']/following-sibling::*"));
        switch (element.getAttribute("type")) {
            case "text":
                return element.getAttribute("value");
            case "select-one":
                return new Select(element).getAllSelectedOptions().get(0).getText();
            case "select-multiple":
                return Driver.getDriver().findElement(By.xpath("//label[text()='" + label +
                                                               "']/following-sibling::button")).getText();
            default:
                return element.getText();
        }
    }

    /**
     * Places a value directly into the calendar control text box
     *
     * @param label Label for the calendar control to set
     * @param date  the string representation of the date to set.
     */
    public static void setValueInCalendarControl(String label, String date) {
        WebElement calendarControl = Driver.getDriver().findElement(By.xpath("//label[text()='"
                                                                             + label + "']/following-sibling::input"));
        calendarControl.click();
        calendarControl.clear();
        JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
        js.executeScript("document.getElementById('" + calendarControl.getAttribute("id") +
                "').setAttribute('value', '" + date + "')");
        calendarControl.sendKeys(date);
        calendarControl.sendKeys(Keys.ESCAPE);
        // Arbitrary wait of 2 seconds added this calendar control is problematic
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
    }

    /**
     * Verifies whether No Results Found... is displayed in the ES Dropdown
     * @param label The name of the label where the ES Dropdown exists
     * @param searchText The search text to type into the box
     * @return Boolean determining whether or not No Results Found... is displayed
     */
    public static boolean isNoResultsFound(String label, String searchText) {
        WebElement dropdown = Driver.getDriver().findElement(By.xpath("//label[text()=" +
                                                                      "'" + label + "']/following-sibling::button"));
        dropdown.click();
        WaitUntil.waitUntil(() ->
                typeAhead.isDisplayed());
        typeAhead.sendKeys(searchText);
        try {
            WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("searchInputNoResult")).isDisplayed());
            return true;
        } catch(org.openqa.selenium.TimeoutException toe) {
            return false;
        }
    }
    /**
     * Select values from elastic Search drop down
     *
     * @param label      Label for elastic search "Assignee"
     * @param searchText The text to submit to elastic search
     * @param assignee   The values to select from the drop down
     */
    public static void selectValuesFromESMultiSelectDropdown(String label, String searchText,
                                                             String... assignee) {
        WebElement dropdown = Driver.getDriver().findElement(By.xpath("//label[text()=" +
                                                                      "'" + label + "']/following-sibling::button"));
        dropdown.click();
        WaitUntil.waitUntil(() ->
                typeAhead.isDisplayed());
        typeAhead.sendKeys(searchText);

        for (String person : assignee) {
            SeleniumTest.waitUntilElementIsDisplayedThenSelect(
                    Driver.getDriver().findElement(By.xpath(
                            "//div[@id='search_Verifier']/div/ul/li/a[text()='" + person + "']")));
        }
        dropdown.click();
    }

    /**
     * Selects the appropriate Action Dropdown menu from the task result set
     * TODO change the visibleText parameter to take an enum
     * @param candidate      The candidate you intend to find the task for
     * @param candidateIndex The zero based index of which task you want for the given candidate
     * @param visibleText    The en_US visible Text found in the action dropdown you intend to
     *                       invoke
     * @return The page object that represents the result of the action taken
     */
    public static CustomerDashboardPages selectActionDropdown(Candidate candidate, int
            candidateIndex, String visibleText) {
        List<WebElement> actionDropdowns = Driver.getDriver().findElements(By.xpath
                ("//td[contains(text(),'" + candidate.getCandidateID() + "')" +
                        "]/preceding-sibling::td/div/span/select"));

        Select actionDropdown = new Select(actionDropdowns.get(candidateIndex));
        actionDropdowns.get(candidateIndex).click();

        switch (visibleText) {

            case "View Report":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, VIEW_REPORT_ID);
                return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);

            case "Open PDF":
                // Establish the download folder
                File directory;

                if (SystemUtils.IS_OS_WINDOWS) {
                    directory = new File(System.getenv("USERPROFILE") + "/Downloads");
                } else {
                    directory = new File(System.getenv("HOME") + "/Downloads");
                }
                // Create a filename Filter to search for pdfs
                FilenameFilter filter = new FilenameFilter() {
                    @Override
                    public boolean accept(File directory, String name) {
                        return name.toLowerCase().endsWith(".pdf");
                    }
                };
                // Return the list of current pdf files in the directory
                File[] files = directory.listFiles(filter);
                // set the count
                int pdfFilesCount = files.length;
                // select Open PDF from the dropdown
                actionDropdown.selectByVisibleText(visibleText);
                // wait until a new pdf file is found in the download folder
                try {
                    WaitUntil.waitUntil(30, 2, () -> directory.listFiles(filter).length >
                            pdfFilesCount);
                } catch (TimeoutException toe) {
                    throw new RuntimeException("Failed to find the pdf");
                }
                // Return the NEW list of current pdf files in the directory
                File[] files2 = directory.listFiles(filter);
                // enumerate through the list and delete the newly found pdf
                for (File f : Arrays.asList(files2)) {
                    if (!Arrays.asList(files).contains(f)) {
                        f.delete();
                    }
                }

                return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage
                        .class);

            case "Print Report":
                List<WebElement> options = actionDropdown.getOptions();
                for (WebElement option : options) {
                    if (option.getAttribute("id").equals(PRINT_REPORT_ID)) {
                        WindowManagement.clickElementToOpenNewWindow(option, 15, true);
                    }
                }
                return PageFactory.initElements(Driver.getDriver(), PrintPage.class);

            case "Resend Notifications":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, RESEND_NOTIFICATION_ID);
                PageFactory.initElements(Driver.getDriver(), ResendNotificationModal.class);
                ResendNotificationModal.closeResendNotification(OnboardingTasksPage.class);
                // Hard wait for modal dialog to close - waiting on modal disappearing is not
                // working - waiting on elements to be present when themodal closes
                // does not work either.
                // TODO:  Fix this some day.
                SeleniumTest.defaultWaitForElementWithMultiplier(1);
                return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage
                        .class);

            case "Edit Tasks":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, EDIT_TASKS_ID);
                return PageFactory.initElements(Driver.getDriver(), EditTasksModal.class);

            case "Cancel":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, CANCEL_ID);
                SeleniumTest.waitForPageLoadToComplete();
                if (!CancelFormI9Page.onPage()) {
                    PageFactory.initElements(Driver.getDriver(), CancelModal.class);
                    CancelModal.clickConfirm(OnboardingTasksPage.class);
                    return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage
                            .class);
                } else {
                    return PageFactory.initElements(Driver.getDriver(), CancelFormI9Page.class);
                }

            case "Cancel I-9":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, CANCEL_ID);
                return PageFactory.initElements(Driver.getDriver(), CancelFormI9Page.class);

            default:
                return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage
                        .class);
        }
    }

    /**
     * Uncheck all Group drop down values
     */
    public void uncheckAllGroupDropDownValues() {
        //TODO account for groupDropDown already open scenario & uncheckAllGroupDropDown already
        // done scenario
        groupDropDown.click();
        uncheckAllGroupDropDown.click();
    }

    /**
     * Uncheck all Assignee drop down values
     */
    public void uncheckAllAssigneeDropDownValues() {
        Driver.getDriver().findElement(By.xpath("//form//div/label[text()" +
                                                "='Assignee']/following-sibling::button")).click();
        uncheckAllAssigneeDropDown.click();
    }

    /**
     * Uncheck all Tasks drop down values
     */
    public void uncheckAllTasksDropDownValues() {
        Driver.getDriver().findElement(By.xpath("//form//div/label[text()='Task " +
                                                "Status']/following-sibling::button")).click();
        uncheckAllTaskStatusDropDown.click();
    }

    /**
     * Select values from Positions dropdown.
     */
    public void selectValueFromPositionsDropDown(String... value) {
        positionsDropDown.click();
        checkValuesAUI(value);
    }

    /**
     * Clicks on Search button that is displayed when user opens Advanced Search
     */
    public void clickAdvancedSearchButton() {
        advancedSearchButton.click();
    }

    /**
     * Generic method to Type text in a custom field with a corresponding label. This is required as
     * every customer has different labels for custom fields.
     */
    public void typeTextInCustomTextField(String customFieldLabel, String textToBeTyped) {
        WebElement customFieldTextBox = Driver.getDriver().findElement(By.xpath
                ("//div[@class='field']/label[contains(text(),'" + customFieldLabel + "')" +
                        "]/following-sibling::input[1]"));
        SeleniumTest.clearAndSetText(customFieldTextBox, textToBeTyped);
    }

    /**
     * Generic method to select a value from any custom field dropdown. This is required as every
     * customer has different labels for custom fields.
     */
    public static void selectValueFromCustomDropDownField(String customFieldLabel, String... value) {
        WebElement customFieldDropDown = Driver.getDriver().findElement(By.xpath
                ("//div[@class='field multiselectField']/label[contains(text(),'" +
                        customFieldLabel + "')]/following-sibling::button"));
        customFieldDropDown.click();
        checkValuesAUI(value);
    }

    /**
     * Returns the value in a given cell in grid.
     */
    public static String getCellValue(int rowNumber, int columnNumber) {
        rowNumber = rowNumber + 1; // because first row is column headers
        WebElement cell = Driver.getDriver().findElement(By.cssSelector("table.shadow tbody " +
                                                                        "tr:nth-child(" + rowNumber + ") td:nth-child(" + columnNumber + ")"));
        return cell.getText();
    }

    /**
     * Sort column in ascending or descending order
     */
    public static void sort(Boolean isSortTypeAscending, String columnName) {
        WebElement column = Driver.getDriver().findElement(By.xpath("//a[@class='k-link'][text()" +
                                                                    "='" + columnName + "']"));
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(column, SeleniumTest.waitForElementTimeout);
        staticLogger.info("Clicking on column " + columnName);
        try {
            column.click();
        } catch (WebDriverException e) {
            SeleniumTest.waitForElementToBeClickable(column, SeleniumTest.waitForElementTimeout);
            column.click();
        }
        staticLogger.info("wait for sort icon to be clickable");
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(By.xpath("//a[@class='k-link'][text()='" +
                columnName + "']/span"), SeleniumTest.waitForElementTimeout);
        staticLogger.info("Get attribute of sort icon");
        String arrowAttribute = (Driver.getDriver().findElement(By.xpath
                ("//a[@class='k-link'][text()='" + columnName + "']/span"))).getAttribute("class");
        //If sort is in descending order click column name again.
        if (isSortTypeAscending) {
            if (arrowAttribute.equals("k-icon k-i-arrow-s")) {
                column.click();
                SeleniumTest.waitForPageLoadToComplete();
            }
        } else {
            if (arrowAttribute.equals("k-icon k-i-arrow-n")) {
                column.click();
                SeleniumTest.waitForPageLoadToComplete();
            }
        }
    }

    /**
     * Clicks open task Icon
     */
    public CandidatePortalPages clickOpenTaskLink(
            Class<? extends Sites.CandidatePortal.Forms.CandidatePortalPages> returnedClass,
            Workflows.Candidate candidate) {

        WaitUntil.waitUntil(() -> Driver.getDriver().findElements(
                By.xpath("//a[contains(@onclick, 'Candidate=" +
                        candidate.getCandidateID() +
                        "')]")).size() > 0);

        WindowManagement.clickElementToOpenNewWindow(
                Driver.getDriver().findElement(
                        By.xpath("//a[contains(@onclick, 'Candidate=" +
                                candidate.getCandidateID() + "')]")));
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Gets Index From Column Name. helper method for getColumnFromTasklist().
     */
    private static int getIndexFromColumnName(String columnName) {
        return Integer.parseInt(
                Driver.getDriver().findElement(By.cssSelector("#onboardingtasklist " +
                                                              ".k-grid-header th[data-title='" + columnName + "']")).getAttribute("data-index"));
    }

    /**
     * Returns a Column from the Tasklist as an Arraylist of Strings.
     * @param columnName
     * @return
     */
    public static ArrayList<String> getColumnFromTasklist(String columnName) {

        ArrayList<String> dataStrings = new ArrayList<String>();

        if (Driver.getDriver().findElement(By.cssSelector("#onboardingtasklist > table > thead > tr > th"))
                  .getText().equals("No results found")) {
            dataStrings.add("No results found");
            return dataStrings;
        }

        // +1 accounts for index offset between the header column & the row column.
        int index = getIndexFromColumnName(columnName) + 1;
        List<WebElement> elements = Driver.getDriver().findElements(By.cssSelector("#onboardingtasklist > " +
                                                                                   "table > tbody > tr > td:nth-of-type(" + index + ")"));

        for (WebElement element : elements) {
            dataStrings.add(element.getText());
        }

        return dataStrings;
    }

    /**
     * Returns a Column from the Tasklist as an Arraylist of lowercase Strings.
     * @param columnName
     * @return
     */
    public static ArrayList<String> getColumnFromTasklistToLowerCase(String columnName) {

        ArrayList<String> lowerCaseStrings = new ArrayList<>();

        for (String dataString : getColumnFromTasklist(columnName)) {
            lowerCaseStrings.add(dataString.toLowerCase());
        }

        return lowerCaseStrings;
    }

    /**
     * Returns true only if results set is empty or supplied Column Exclusively Contains none, one
     * or more of supplied filterStrings.
     */
    public static boolean columnExclusivelyContains(String columnName, String... filterStrings) {
        if (columnName == null || columnName.isEmpty()) {
            throw new RuntimeException("You did not supply a Column Name");
        }

        if (filterStrings == null || filterStrings.length == 0) {
            throw new RuntimeException("You did not supply any strings for comparison - nothing " +
                    "to compare");
        }

        waitForGridToLoad();
        ArrayList<String> dataStrings = getColumnFromTasklist(columnName);
        ArrayList<String> myFilters = new ArrayList<String>(Arrays.asList(filterStrings));

        for (String dataString : dataStrings) {

            // true found here means empty result set & meets exclusivity condition.
            if (dataString.equals("No results found")) {
                return true;
            }

            if (!myFilters.contains(dataString)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Clicks passed in column header
     */
    public static void clickColumnHeader(String columnName) {
        waitForGridToLoad();
        Driver.getDriver().findElement(By.cssSelector("tr > th[data-title*='" + columnName + "'] > a")).click();
    }

    /**
     * Returns true if column is in ascending alphabetical order
     */
    public static boolean columnIsAlphabeticallyAscending(String columnName) {

        OnboardingTasksPage.waitForGridToLoad();
        ArrayList<String> unsortedList = OnboardingTasksPage.getColumnFromTasklist(columnName);

        // Creates copy to sort, Sorts the copy, and Checks if both are equals.
        ArrayList<String> sortedList = new ArrayList<>(unsortedList);
        Collections.sort(sortedList);
        return sortedList.equals(unsortedList);
    }

    /**
     * Returns true if column is in descending alphabetical order
     */
    public static boolean columnIsAlphabeticallyDescending(String columnName) {

        OnboardingTasksPage.waitForGridToLoad();
        ArrayList<String> unsortedList = OnboardingTasksPage.getColumnFromTasklist(columnName);

        // Creates copy to sort, Sorts the copy, and Checks if both are equals.
        ArrayList<String> revSortedList = new ArrayList<>(unsortedList);
        Collections.sort(revSortedList);
        Collections.reverse(revSortedList);
        return revSortedList.equals(unsortedList);
    }

    /**
     * Returns true if column to lower case is in ascending alphabetical order
     */
    public static boolean columnToLowerIsAlphabeticallyAscending(String columnName) {

        OnboardingTasksPage.waitForGridToLoad();
        ArrayList<String> unsortedList = OnboardingTasksPage.getColumnFromTasklistToLowerCase(columnName);

        // Creates copy to sort, Sorts the copy, and Checks if both are equals.
        ArrayList<String> sortedList = new ArrayList<>(unsortedList);
        Collections.sort(sortedList);
        return sortedList.equals(unsortedList);
    }

    /**
     * Returns true if column to lower case  is in descending alphabetical order
     */
    public static boolean columnToLowerIsAlphabeticallyDescending(String columnName) {

        OnboardingTasksPage.waitForGridToLoad();
        ArrayList<String> unsortedList = OnboardingTasksPage.getColumnFromTasklistToLowerCase(columnName);

        // Creates copy to sort, Sorts the copy, and Checks if both are equals.
        ArrayList<String> revSortedList = new ArrayList<>(unsortedList);
        Collections.sort(revSortedList);
        Collections.reverse(revSortedList);
        return revSortedList.equals(unsortedList);
    }

    /**
     * Waits for spinner to disappear, then sets passed column to Ascending Order only if not already Ascending
     * @param columnName
     */
    public static void sortColumnAscending(String columnName) {
        try {
            if(((EventFiringWebDriver)Driver.getDriver()).getWrappedDriver().findElement(
                    By.xpath("//a[@class='k-link'][text()='" + columnName + "']/span"))
                                                         .getAttribute("class")
                                                         .contains("sort-asc")) {
                return;
            }
        } catch (StaleElementReferenceException | NoSuchElementException e) {
            // Class not found at all - click the header to make sure it is sorted
        }
        OnboardingTasksPage.clickColumnHeader(columnName);
        SeleniumTest.waitMs(2000);

    }

    /**
     * Waits for spinner to disappear, then sets passed column to Descending Order only if not already Descending
     * @param columnName
     */
    public static void sortColumnDescending(String columnName) {
        try {
            if(((EventFiringWebDriver)Driver.getDriver()).getWrappedDriver().findElement(
                    By.xpath("//a[@class='k-link'][text()='" + columnName + "']/span"))
                                                         .getAttribute("class")
                                                         .contains("sort-desc")) {
                return;
            }
        } catch (StaleElementReferenceException | NoSuchElementException e) {
            // Class not found at all - click the header to make sure it is sorted
        }
        OnboardingTasksPage.clickColumnHeader(columnName);
        SeleniumTest.waitForPageLoadToComplete();
    }

    /**
     * Returns Arraylist of Assignee Search Result Strings.
     */
    public static ArrayList<String> getAssigneeSearchResultList() {

        try {
            WaitUntil.waitUntil(()-> OnboardingTasksPage.assigneeDropDown2ndOption.isDisplayed());
        } catch (Exception e) {
            // There was no 2nd option, so do nothing and continue.
        }

        ArrayList<String> resultList = new ArrayList<String>();
        List<WebElement> elements = new ArrayList<>();
        try {
            elements = Driver.getDriver().findElements(By.cssSelector("#search_Verifier > div > ul > li > a"));
        } catch (org.openqa.selenium.NoSuchElementException nse) {
            // Do not crash if no elements are found- simply return an empty list
        }

        for (WebElement element : elements) {
            resultList.add(element.getText());
        }

        return resultList;
    }

    /**
     * Returns true if all Assignee Elastic Search results contain searchString.
     */
    public static boolean allAssigneeSearchResultsContain(String searchString) {
        ArrayList<String> resultList = getAssigneeSearchResultList();
        for(String result : resultList) {
            if(result.equals("Unassigned")) {
                continue;
            }

            if(!result.contains(searchString)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Selects the passed option from the Packages Drop Down, only if
     * Packages is already selected in the Additional Search Criteria DropDown.
     * @param option
     */
    public static void selectOptionFromPackagesDropDown(String option) {
        OnboardingTasksPage.openMultiSelectDropDown(AdditionalSearchCriteriaFilters.PACKAGES.toString());
        Driver.getDriver().findElement(By.cssSelector("#search_Package > div > ul > li > a[data-key*='" + option + "']")).click();
    }

    /**
     * returns a string of the text visible in the Assignee drop down Elastic Search Field
     * @return
     */
    public static String getAssigneeSearchText() {
        return OnboardingTasksPage.assigneeDropDownSearchField.getAttribute("value");
    }

    /**
     * Presses Enter with focus set on specified element
     * @param labelOfElement
     */
    public static void pressEnterOnElement(String labelOfElement) {
        WebElement element = Driver.getDriver().findElement(By.xpath("//label[text()='"
                                                                     + labelOfElement + "']/following-sibling::*"));
        element.sendKeys(org.openqa.selenium.Keys.ENTER);
    }

    public static String getSavedSearchDropDownLabelText() {
        return Driver.getDriver().findElement(By.xpath("//*[@id=\"savedSearchWidgets\"]/div[1]/button/span[2]")).getText();
    }

    /**
     * Returns true only if the "No results found" message is displayed to the user.
     * @return
     */
    public static boolean taskGridContainsNoResultsFound() {
        SeleniumTest.waitForElementNotPresent(By.cssSelector("div.k-loading-mask"));
        return noResultsFoundMessage.getText().contains("No results found");
    }

    /**
     * Returns true if task grid at least contains some non specific results.
     * @return
     */
    public static boolean taskGridContainsResults() {
        waitForGridToLoad();
        ArrayList<String> dataStrings = getColumnFromTasklist(TasklistColumn.ASSIGNEE.toString());

        for (String dataString : dataStrings) {
            if (dataString.equals("No results found")) {
                return false;
            }
        }

        return true;
    }

    public static void waitForTaskGridLabelIsVisible() {

        WaitUntil.waitUntil(() ->
            taskGridItemsLabel.isDisplayed() ||
                    noResultsFoundMessage.isDisplayed(),
                NoSuchElementException.class);
    }

    public static ScreeningTasksPage clickScreeningTasksSubTab() {
        SeleniumTest.click(screeningTaskSubTab);
        SeleniumTest.waitForPageLoad();
        return PageFactory.initElements(Driver.getDriver(), ScreeningTasksPage.class);
    }

    /**
     * Returns true or false whether the page source contains text
     * @param incoming String to find
     * @return boolean whether it was found
     */
    public static boolean pageSourceContains(String incoming) {
        return Driver.getDriver().getPageSource().contains(incoming);
    }

    public static String getFirstTaskAssigneeName()
    {
        return firstTaskRecordAssigneeName.getText();
    }

    /**
     * Returns the body element of a page.  This is the main element without the header,
     * sidebar and footer.
     * @return WebElement the body container of the page
     */
    public static WebElement getBodyContainer() {
        return bodyContainer;
    }

    /**
     * Columns enumerator for Column Name, Data Key and Default Dimensions.
     */
    public enum Columns {
        ACTION("Action", "", new Dimension(63, 29)),
        CANDIDATE_NAME("Candidate Name", "", new Dimension(105, 29)),
        GROUP("Group", "", new Dimension(76, 29)),
        ASSIGNEE("Assignee", "", new Dimension(94, 29)),
        TASK("Task", "", new Dimension(73, 29)),
        TASK_STATUS("Task Status", "", new Dimension(79, 29)),
        TASK_DUE_DATE("Task Due Date", "", new Dimension(111, 29)),
        EMPLOYEE_ID("Employee ID", "employeeIdColumn", new Dimension(83, 29)),
        PACKAGES("Packages", "packageNameColumn", new Dimension(67, 29)),
        TASK_COMPLETE_DATE("Workflow Complete Date", "taskCompleteDateColumn", new Dimension(124, 29)),
        TASK_ROLE("Task Role", "taskRoleColumn", new Dimension(69, 29));

        private final String text;
        private final String data_key;
        private final Dimension defaultDimension;

        Columns(final String text, final String data_key, final Dimension defaultDimension) {

            this.text = text;
            this.data_key = data_key;
            this.defaultDimension = defaultDimension;
        }

        public Dimension getDefaultDimension() {
            return defaultDimension;
        }

        public String getData_Key() {
            return data_key;
        }

        @Override
        public String toString() {
            return text;
        }

        public WebElement getWebElement() {
            try {
                return Driver.getDriver().findElement(By.xpath("//th/a[text()='" + text +
                                                               "']/parent::th"));
            } catch (NoSuchElementException nse) {
                return null;
            }
        }
    }

    /**
     * Enum to select Task List Columns
     */
    public enum TasklistColumn {
        ACTION("Action"),
        ACTIONARRAY("ActionArray"),
        CANDIDATE_NAME("Candidate Name"),
        GROUP("Group"),
        ASSIGNEE("Assignee"),
        TASK("Task"),
        TASK_STATUS("Task Status"),
        TASK_DUE_DATE("Task Due Date"),
        WORKFLOW_COMPLETE_DATE("Workflow Complete Date"),
        TASK_ROLE("Task Role"),
        PACKAGE("Packages"),
        EMPLOYEE_ID("Employee ID"),
        SELECT("Select");

        private final String text;

        TasklistColumn(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Enum to select Task Status filters
     */
    public enum TaskStatus {
        CANCELED("Canceled"),
        COMPLETE("Complete"),
        ESIGNED_DECLINED("eSigned Declined"),
        CANDIDATE_NAME("Candidate Name"),
        EXPIRED("Expired"),
        IN_PROGRESS("In Progress"),
        NEW("New"),
        NO_LONGER_REQUIRED("No Longer Required"),
        OVERDUE_IN_PROGRESS("Overdue - In Progress"),
        OVERDUE_NEW("Overdue - New"),
        OVERDUE_RESUBMITTED("Overdue - Resubmitted"),
        OVERDUE_RETURNED("Overdue - Returned"),
        PENDING("Pending"),
        PRINTED("Printed"),
        REJECTED("Rejected"),
        RESUBMITTED("Resubmitted"),
        RETURNED("Returned"),
        SCHEDULED("Scheduled");

        private final String text;

        TaskStatus(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Enum to select Additional Search Criteria Filters.
     */
    public enum AdditionalSearchCriteriaFilters {
        CANDIDATE_ID("Candidate ID"),
        CANDIDATE_NAME("Candidate Name"),
        CONTRIBUTOR_STATUS("Contributor Status"),
        DUE_DATE("Due Date"),
        PACKAGES("Packages"),
        TASK_COMPLETE_DATE("Task Complete Date");

        private final String text;
        AdditionalSearchCriteriaFilters(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Enum to select Additional Search Criteria Drop Down Options
     */
    public enum AdditionalSearchCriteriaDropDownOptions {
        CANDIDATE_ID("Candidate ID"),
        CANDIDATE_NAME("Candidate Name"),
        CANDIDATE_REFERENCE_CODES("Candidate Reference Codes"),
        CONTIBUTOR_STATUS("Contributor Status"),
        CUSTOM_FIELDS("Custom Fields"),
        DUE_DATE("Due Date"),
        EMPLOYEE_ID("Employee ID"),
        POSITION("Positions"),
        PACKAGES("Packages"),
        REFERENCE_CODES("Reference Codes"),
        TASK_COMPLETE_DATE("Task Complete Date");

        private final String text;
        AdditionalSearchCriteriaDropDownOptions(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * Enum to select Action Drop Down Options
     */
    public enum ActionDropDownOptions {
        VIEW_REPORT("View Report"),
        OPEN_PDF("Open PDF"),
        PRINT_REPORT("Print Report"),
        RESEND_NOTIFICATION("Resend Notifications"),
        EDIT_TASKS("Edit Tasks"),
        CANCEL("Cancel"),
        COMPLETE_ADVERSE_ACTION("Complete Adverse Action");

        private final String text;
        ActionDropDownOptions(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    public static WebElement getFirstDueDate() {
        return firstDueDate;
    }
}
