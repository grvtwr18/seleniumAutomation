package Sites.TalentWiseDashboard.BatchUpload;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by AKaiser on 8/2/2017.
 */
public class ClientCertificationStatementPage {
    @FindBy(how = How.ID, using = "pageContainerDiv")
    private WebElement pageContainerDiv;

    private static final ThreadLocal<ClientCertificationStatementPage> threadLocalInstance;

    static {
        PageFactory.initElements(Driver.getDriver(), ClientCertificationStatementPage.class);
        threadLocalInstance = ThreadLocal.withInitial(
            () -> PageFactory.initElements(Driver.getDriver(), ClientCertificationStatementPage.class));
    }

    private static ClientCertificationStatementPage getInstance() {
        return threadLocalInstance.get();
    }

    public static WebElement getPageContainer() {
        return getInstance().pageContainerDiv;
    }
}
