package Sites.TalentWiseDashboard.BatchUpload;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/2/2015.
 */
public class BatchUploadTabs extends CustomerPortalPage {

    @FindBy(how = How.ID, using = "subtab_batchcurrent")
    private static WebElement currentFilesTab;

    @FindBy(how = How.ID, using = "subtab_batchnew")
    private static WebElement uploadNewFileTab;

    @FindBy(how = How.ID, using = "subtab_batchcandidate")
    private static WebElement importCandidatesTab;

    @FindBy(how = How.ID, using = "subtab_batchauto")
    private static WebElement autoProcessFileTab;

    static {
        PageFactory.initElements(Driver.getDriver(), BatchUploadTabs.class);
    }

    /**
     * Clicks on Upload New File Tab
     * @return
     */
    public static UploadNewFilePage clickUploadNewFileTab() {
        uploadNewFileTab.click();
        return PageFactory.initElements(Driver.getDriver(), UploadNewFilePage.class);
    }

    /**
     * Clicks on Import Candidates Tab
     * @return
     */
    public static ImportCandidatesPage clickImportCandidatesTab() {
        importCandidatesTab.click();
        return PageFactory.initElements(Driver.getDriver(), ImportCandidatesPage.class);
    }

    /**
     * Clicks on Auto Process File
     * @return
     */
    public static ProcessAutoBatchPage clickAutoProcessFileTab() {
        SeleniumTest.click(autoProcessFileTab);
        return PageFactory.initElements(Driver.getDriver(), ProcessAutoBatchPage.class);
    }

    public ProcessAutoBatchPage clickCurrentFilesTab()
    {
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.click(currentFilesTab);
        return PageFactory.initElements(Driver.getDriver(), ProcessAutoBatchPage.class);
    }
}
