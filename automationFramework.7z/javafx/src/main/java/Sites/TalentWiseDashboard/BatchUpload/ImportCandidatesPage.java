package Sites.TalentWiseDashboard.BatchUpload;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.apache.commons.exec.OS;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/4/2015.
 */
public class ImportCandidatesPage extends CustomerPortalPage {

    @FindBy(how = How.NAME, using = "FileUploadName")
    private WebElement chooseFileButton;

    @FindBy(how = How.NAME, using = "filesubmit")
    private WebElement submitButton;

    @FindBy(how = How.XPATH, using =
            "//*[@id='dbIdContentInner']/.//a[contains(@href,'screening/batch.php?view=batchcandidate')]")
    private WebElement uploadAnotherFileLink;

    /**
     * Sets the file to upload
     * @param filePath full path of the file to upload
     * @return
     */
    public ImportCandidatesPage setFileToUpload(String filePath) {
        if(OS.isFamilyWindows()) {
            filePath = filePath.replace('/', '\\');
        }
        ((JavascriptExecutor)Driver.getDriver()).executeScript("document.getElementsByName('" + chooseFileButton.getAttribute("name") + "')[0].style.visibility = 'visible';");
        chooseFileButton.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(submitButton, SeleniumTest.waitForElementTimeout);
        return this;
    }

    /**
     * Submits the the File
     * @return
     */
    public ImportCandidatesPage submitFile() {
        submitButton.click();
        uploadAnotherFileLink.click();
        return PageFactory.initElements(Driver.getDriver(), ImportCandidatesPage.class);
    }
}
