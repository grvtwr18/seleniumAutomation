package Sites.TalentWiseDashboard.BatchUpload;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.apache.commons.exec.OS;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


/**
 * Created by abrackett on 12/2/2015.
 */
public class UploadNewFilePage extends CustomerPortalPage {


    @FindBy(how = How.NAME, using = "FileUploadName")
    private WebElement chooseFileButton;

    @FindBy(how = How.NAME, using = "filesubmit")
    private WebElement submitButton;

    @FindBy(how = How.XPATH, using =
            "//*[@id='dbIdContentInner']/.//a[contains(@href,'screening/batch.php?view=batchcandidate')]")
    private WebElement uploadAnotherFileLink;

    @FindBy(how = How.XPATH, using =
            "//a[contains(@href, 'client-certification-text')]")
    private WebElement clientStatement;

    private static final ThreadLocal<UploadNewFilePage> threadLocalInstance;

    static {
        PageFactory.initElements(Driver.getDriver(), UploadNewFilePage.class);
        threadLocalInstance = ThreadLocal.withInitial(
                () -> PageFactory.initElements(Driver.getDriver(), UploadNewFilePage.class));
    }

    private static UploadNewFilePage getInstance() {
        return threadLocalInstance.get();
    }

    /**
     * Sets the file to upload
     * @param filePath full path of the file to upload
     * @return
     */
    public UploadNewFilePage setFileToUpload(String filePath) {
        if(OS.isFamilyWindows()) {
            filePath = filePath.replace('/', '\\');
        }
        ((JavascriptExecutor)Driver.getDriver()).executeScript("document.getElementById('" + chooseFileButton.getAttribute("id") + "').style.visibility = 'visible';");
        chooseFileButton.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(submitButton, SeleniumTest.waitForElementTimeout);
        return this;
    }

    /**
     * Submits the uploaded file.
     * @return
     */
    public UploadNewFilePage submitFile() {
        submitButton.click();
        uploadAnotherFileLink.click();
        return PageFactory.initElements(Driver.getDriver(), UploadNewFilePage.class);
    }

    /**
     * Clicks the client certification statement link
     */
    public static void clickClientStatement() {
        SeleniumTest.click(getInstance().clientStatement);
    }
}
