package Sites.TalentWiseDashboard.BatchUpload;


import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.apache.commons.exec.OS;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by MNam on 12/12/2017.
 */
public class ProcessAutoBatchPage {

    @FindBy(how = How.NAME, using = "FileUploadName")
    private WebElement chooseFileButton;

    @FindBy(how = How.ID, using = "acceptClientCertificateId")
    private WebElement acceptClientCertificateIdButton;

    @FindBy(how = How.NAME, using = "filesubmit")
    private WebElement submitButton;

    @FindBy(how = How.NAME, using = "comments")
    private WebElement commentBox;

    @FindBy(how = How.CSS, using = "div.dbMessage.dbSuccessColor")
    private WebElement successMessage;

    @FindBy(how = How.LINK_TEXT, using = "View Details")
    private WebElement viewDetails;

    @FindBy(how = How.XPATH, using = "//div[@id='dbIdContentInner']/div/div/div[3]/div[2]")
    private WebElement fileStatus;

    static{
        PageFactory.initElements(Driver.getDriver(), ProcessAutoBatchPage.class);
    }

    public static ProcessAutoBatchPage getInstance() {
        return PageFactory.initElements(Driver.getDriver(), ProcessAutoBatchPage.class);
    }
    /**
     * Sets the file to upload
     * @param filePath full path of the file to upload
     * @return
     */
    public ProcessAutoBatchPage setFileToUpload(String filePath) {
        if(OS.isFamilyWindows()) {
            filePath = filePath.replace('/', '\\');
        }
        ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementsByName('" + chooseFileButton.getAttribute("name") + "')[0].style.visibility = 'visible';");
        chooseFileButton.sendKeys(filePath);
        return this;
    }

    /**
     * Ceck acceptClientCertificate
     * @return
     */
    public ProcessAutoBatchPage checkAcceptClientCertificateIdButton() {
        SeleniumTest.check(acceptClientCertificateIdButton);
        return this;
    }

    /**
     * Submits the the File
     * @return
     */
    public void submitFile() {
        SeleniumTest.click(submitButton);
    }

    public void enterTextIntoCommentBox(String comment)
    {
        SeleniumTest.clearAndSetText(commentBox,comment);
    }

    public String successMessageText()
    {
       return SeleniumTest.getText(successMessage);
    }

    public void viewDetailsForCurrentFileUpload()
    {
        SeleniumTest.click(viewDetails);
    }

    public void clickViewDetails()
    {
        SeleniumTest.click(getInstance().viewDetails);
    }

    public String getFileStatus()
    {
        return SeleniumTest.getText(fileStatus);
    }
}
