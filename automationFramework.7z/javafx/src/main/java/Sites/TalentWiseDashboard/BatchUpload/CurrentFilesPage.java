package Sites.TalentWiseDashboard.BatchUpload;

import TWFramework.TableHelper;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 4/26/2017.
 */
public class CurrentFilesPage {

    @FindBy(how = How.CLASS_NAME, using = "table")
    private static WebElement currentFilesTable;

    static {
        PageFactory.initElements(Driver.getDriver(), CurrentFilesPage.class);
    }

    /**
     *
     * @param row this is the row starting top down, first file is 1.  Not the new number in the UI
     */
    public static void clickViewDetails(int row) {
        TableHelper.getCellFromTableByCardinality(currentFilesTable, row, 5).click();
    }
}
