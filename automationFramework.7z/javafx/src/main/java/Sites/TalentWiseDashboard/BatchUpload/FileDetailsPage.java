package Sites.TalentWiseDashboard.BatchUpload;

import TWFramework.BodyTextHelper;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by wogden on 4/26/2017.
 */
public class FileDetailsPage {

    static {
        PageFactory.initElements(Driver.getDriver(), FileDetailsPage.class);
    }

    public static void hideAccountSpecificFields() {
        List<WebElement> content = Driver.getDriver().findElements(
                By.className("itemContent"));
        // hide file name which is not localized and variable.
        BodyTextHelper.hideElement(content.get(0));
        // hide upload date
        BodyTextHelper.hideElement(content.get(1));
        // hide "your comments"
        BodyTextHelper.hideElement(content.get(3));
    }
}
