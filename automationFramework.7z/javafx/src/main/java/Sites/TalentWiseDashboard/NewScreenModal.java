package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchPage;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by akaiser on 6/26/2017.
 */
public class NewScreenModal {
    private WebDriverWait wait;

    @FindBy(how = How.ID, using = "divQuickLaunchModalScreen")
    private WebElement launchScreeningModal;

    public Candidate candidate;
    private final Logger instanceLogger = LoggerFactory
            .getLogger(NewScreenModal.class.getName());

    private static final ThreadLocal<NewScreenModal> threadLocalInstance;

    static {
        PageFactory.initElements(Driver.getDriver(), NewScreenModal.class);
        threadLocalInstance = ThreadLocal.withInitial(
                () -> PageFactory.initElements(Driver.getDriver(), NewScreenModal.class)
        );
    }
    private static NewScreenModal getInstance() {
        return threadLocalInstance.get();
    }

    /**
     * Constructs a new Candidate Modal page object.
     */
    public NewScreenModal(){
        this.wait = new WebDriverWait(Driver.getDriver(), 10);
    }

    public static void waitForReady() {
        SeleniumTest.waitForElementNotVisible(By.id("divQuickLaunchModalScreenLoading"));
    }

    public static WebElement getModal() {
        return getInstance().launchScreeningModal;
    }

    public static void showProductDetails(String uberFormID) {
        WebElement element = Driver.getDriver().findElement(By.id("productshowbutton_1_modal_-3"));
        JavaScriptHelper.click(element);
    }

    public static ScreeningLaunchPage launchProduct(String uberFormID) {
        WebElement element = Driver.getDriver().findElement(
                        By.xpath("//a[contains(@href,'ufid=" + uberFormID + "')]/button")
        );
        JavaScriptHelper.click(element);
        return PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
    }

    /**
     * Launch a ticket based on the uberformID
     * @param uberFormID
     */
    public static void ticketing(String uberFormID) {
        SeleniumTest.click(By.id("btnticket_" + uberFormID + "_1"));
    }
}
