package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by wogden on 9/21/2016.
 * TODO: probably would be more accurate as AddUberformModal
 */
public class AddPackageModal extends CustomerDashboardPages {

    private static final String closeLinkExpectedText = "Close";
    protected static final Logger staticlogger = LoggerFactory.getLogger("AddPackagesModal");

    @FindBy(how = How.XPATH, using = "//div[text()='Sorry, an error occurred.']")
    private static WebElement errorMessage;

    @FindBy(how = How.XPATH, using = "//*[text()='Launch']")
    private static By productListing = By.xpath("//*[text()='Launch']");


    static {
        PageFactory.initElements(Driver.getDriver(), AddPackageModal.class);
    }

    public static void clickCloseLink() {
        WebElement closeLink;
        //TODO when this is localized, add a try/catch block, in the catch fall back to en-US
        closeLink = Driver.getDriver().findElement(By.linkText(closeLinkExpectedText));
        WaitUntil.waitUntil(() -> closeLink.isDisplayed());
        closeLink.click();
        SeleniumTest.waitForElementNotVisible(By.id("modalMask"));
    }

    public static void clickLaunchForUberformId(int uberformId) {
        By by = By.id("btncustom_" + uberformId + "_1");
        SeleniumTest.waitForElementToBeClickable(by);
        SeleniumTest.clickUntilElementDisappearsNoWaiting(by);
    }

    public static void clickLaunchForUberformId(String uberformId) {
        clickLaunchForUberformId(Integer.parseInt(uberformId));
    }

    public static void clickTicketForUberformId(int uberformId) {
        By by = By.id("btnticket_" + uberformId + "_1");
        SeleniumTest.waitMs(5000);
        SeleniumTest.waitForElementNotVisible(By.id("divLaunchScreeningLoading"));
        SeleniumTest.waitForElementToBeClickable(by);
        SeleniumTest.clickUntilElementDisappearsNoWaiting(by);
    }

    public static TicketForm clickTicketForUberformIdIndex(int uberformId, int index) {
        By by = By.id("btnticket_" + uberformId + "_" + index);
        SeleniumTest.click(by);
        return PageFactory.initElements(Driver.getDriver(),TicketForm.class);
    }


    public static void clickTicketForUberformId(String uberformId) {
        clickTicketForUberformId(Integer.parseInt(uberformId));
    }

    public static boolean verifyScreening() {
        if (SeleniumTest.isElementPresent(productListing)) {
            staticlogger.info("Product Listing is visible");
            return true;
        } else {
            staticlogger.info(SeleniumTest.getText(errorMessage));
            return false;
        }
    }
}
