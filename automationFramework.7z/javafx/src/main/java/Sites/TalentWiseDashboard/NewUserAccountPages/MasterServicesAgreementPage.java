package Sites.TalentWiseDashboard.NewUserAccountPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 9/14/2016.
 */
public class MasterServicesAgreementPage {

    @FindBy(how = How.NAME, using = "accept0")
    private static WebElement acceptCheckBox;

    @FindBy(how = How.ID, using = "EULAname")
    private static WebElement nameTextBox;

    @FindBy(how = How.ID, using = "EULAemail")
    private static WebElement emailTextBox;

    @FindBy(how = How.ID, using = "EULAcompany")
    private static WebElement companyTextBox;

    @FindBy(how = How.ID, using = "EULAtitle")
    private static WebElement titleSelect;

    @FindBy(how = How.ID, using = "EULApurpose")
    private static WebElement purposeTextBox;

    @FindBy(how = How.NAME, using = "btnAccept")
    private static WebElement acceptButton;

    static {
        PageFactory.initElements(Driver.getDriver(), MasterServicesAgreementPage.class);
    }

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("EULAname"))
                && SeleniumTest.isElementVisibleNoWaiting(By.id("EULAemail"));
    }

    public static void setNameTextBox(String newName) {
        SeleniumTest.clearAndSetText(nameTextBox, newName);
    }

    public static void setEmailTextBox(String newEmail) {
        SeleniumTest.clearAndSetText(emailTextBox, newEmail);
    }

    public static void setCompanyTextBox(String companyName) {
        SeleniumTest.clearAndSetText(companyTextBox, companyName);
    }

    public static void setPurposeTextBox(String purpose) {
        SeleniumTest.clearAndSetText(purposeTextBox, purpose);
    }

    public static void clickAccept() {
        acceptButton.click();
    }

    public static void checkAcceptBox() {
        SeleniumTest.check(acceptCheckBox);
    }

    public static void setTitlebyValue(String index) {
        SeleniumTest.selectByValueFromDropDown(titleSelect, index);
    }
}
