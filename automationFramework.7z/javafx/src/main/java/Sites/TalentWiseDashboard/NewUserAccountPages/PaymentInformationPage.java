package Sites.TalentWiseDashboard.NewUserAccountPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 9/14/2016.
 */
public class PaymentInformationPage {
    @FindBy(how = How.NAME, using = "CC_Number")
    private static WebElement creditCardNumberText;

    @FindBy(how = How.NAME, using = "CC_ExpMonth")
    private static WebElement creditCardExpirationMonthSelect;

    @FindBy(how = How.NAME, using = "CC_ExpYear")
    private static WebElement creditCardExpirationYearSelect;

    @FindBy(how = How.NAME, using = "CC_SecurityCode")
    private static WebElement creditCardSecurityCodeText;

    @FindBy(how = How.NAME, using = "CC_Name")
    private static WebElement nameText;

    @FindBy(how = How.NAME, using = "CC_Country")
    private static WebElement countrySelect;

    @FindBy(how = How.NAME, using = "CC_Address")
    private static WebElement addressText;

    @FindBy(how = How.NAME, using = "CC_City")
    private static WebElement cityText;

    @FindBy(how = How.NAME, using = "CC_State")
    private static WebElement stateSelect;

    @FindBy(how = How.NAME, using = "CC_PostCode")
    private static WebElement zipText;

    @FindBy(how = How.NAME, using = "CC_FirstName")
    private static WebElement firstNameText;

    @FindBy(how = How.NAME, using = "CC_LastName")
    private static WebElement lastNameText;

    @FindBy(how = How.XPATH, using = "//*[@value=\"Save Payment Information\"]")
    private static WebElement acceptButton;

    @FindBy(how = How.XPATH, using = "/html/body/form[2]/table/tbody/tr/td/table/tbody/tr[12]/td[2]/input")
    private static WebElement saveButton;

    static {
        PageFactory.initElements(Driver.getDriver(), PaymentInformationPage.class);
    }

    public static void setCreditCardNumberText(String newCreditCardNumberText) {
        SeleniumTest.clearAndSetText(creditCardNumberText, newCreditCardNumberText);
    }

    public static void setCreditCardSecurityCodeText(String newCreditCardSecurityCodeText) {
        SeleniumTest.clearAndSetText(creditCardSecurityCodeText, newCreditCardSecurityCodeText);
    }

    public static void setNameText(String newNameText) {
        SeleniumTest.clearAndSetText(nameText, newNameText);
    }
    public static void setFirstNameText(String newNameText) {
        SeleniumTest.clearAndSetText(firstNameText, newNameText);
    }
    public static void setLastNameText(String newNameText) {
        SeleniumTest.clearAndSetText(lastNameText, newNameText);
    }

    public static void setAddressText(String newAddressText) {
        SeleniumTest.clearAndSetText(addressText, newAddressText);
    }

    public static void setCityText(String newCityText) {
        SeleniumTest.clearAndSetText(cityText, newCityText);
    }

    public static void setZipText(String newZipText) {
        SeleniumTest.clearAndSetText(zipText, newZipText);
    }

    /**
     * Sets the Credit Card expiration
     * @param monthValue january is 01
     */
    public static void setCreditCardExpirationMonthSelectByMonthValue(
            String monthValue) {
        SeleniumTest.selectByValueFromDropDown(creditCardExpirationMonthSelect, monthValue);
    }

    public static void setCreditCardExpirationYearSelectByVisibleText(
            String expiryYear) {
        SeleniumTest.selectByVisibleTextFromDropDown(creditCardExpirationYearSelect, expiryYear);
    }

    public static void setCountrySelectByValueText(String countryTwoCharacterCode) {
        SeleniumTest.selectByValueFromDropDown(countrySelect, countryTwoCharacterCode);
    }

    /**
     * Sets the state
     * @param stateTwoCharacterCode WA for Washington.  BC for British Columbia
     */
    public static void setStateSelectByValue(String stateTwoCharacterCode) {
        SeleniumTest.selectByValueFromDropDown(stateSelect, stateTwoCharacterCode);
    }

    public static void clickAcceptButton() {
        acceptButton.click();
    }
    public static void clickSaveButton() {
        saveButton.click();
    }
    public static void ClickEditCreditCard() {
        Driver.getDriver().findElement(By.xpath("//a[contains(@href, '/admin/edituser.php?ShowEditCard')]")).click();
    }
}
