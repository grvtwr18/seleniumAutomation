package Sites.TalentWiseDashboard.NewUserAccountPages;

import Workflows.User;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by jpflager on 5/10/2017.
 */
public class PaymentInformationPageHelper {

    /**
     * Fill all fields required to create a new credit card for a given user.
     *
     * @param user the user object for data
     */
    public static void setupCreditCardForUser(User user) {
        String expires = String.valueOf((Integer.parseInt(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy"))) + 1));
        PaymentInformationPage.setCreditCardNumberText("4111 1111 1111 1111");
        PaymentInformationPage.setCreditCardExpirationMonthSelectByMonthValue("01");
        PaymentInformationPage.setCreditCardExpirationYearSelectByVisibleText(expires);
        PaymentInformationPage.setCreditCardSecurityCodeText("123");
        PaymentInformationPage.setFirstNameText(user.getFirstName());
        PaymentInformationPage.setLastNameText(user.getLastName());
        PaymentInformationPage.setCountrySelectByValueText("US");
        PaymentInformationPage.setAddressText(user.getCompanyAddress() == null ? "500 108th Ave NE" : user.getCompanyAddress());
        PaymentInformationPage.setCityText(user.getCompanyCity() == null ? "Bellevue" : user.getCompanyCity());
        PaymentInformationPage.setStateSelectByValue("WA");
        PaymentInformationPage.setZipText("98000");
        PaymentInformationPage.clickSaveButton();
    }
}
