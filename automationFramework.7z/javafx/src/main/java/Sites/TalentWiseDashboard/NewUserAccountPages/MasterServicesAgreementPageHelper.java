package Sites.TalentWiseDashboard.NewUserAccountPages;

import Workflows.User;

/**
 * Created by jpflager on 5/11/2017.
 */
public class MasterServicesAgreementPageHelper {
    /**
     * For cases when name, company and email are prefilled.
     */
    public static void fillMsaTitlePurposeAndAccept() {
        //all is prefilled but title and reason
        MasterServicesAgreementPage.setTitlebyValue("1");
        MasterServicesAgreementPage.setPurposeTextBox("Testing");
        MasterServicesAgreementPage.checkAcceptBox();
        MasterServicesAgreementPage.clickAccept();
    }

    /**
     * For cases where nothing is prefilled.
     * @param user the User data object to use for name, company, and email data
     */
    public static void fillFullMsaAndAccept(User user) {
        MasterServicesAgreementPage.setNameTextBox(user.getFullName());
        MasterServicesAgreementPage.setCompanyTextBox(user.getCompanyName());
        MasterServicesAgreementPage.setEmailTextBox(user.getEmailAddress());
        fillMsaTitlePurposeAndAccept();
    }
}
