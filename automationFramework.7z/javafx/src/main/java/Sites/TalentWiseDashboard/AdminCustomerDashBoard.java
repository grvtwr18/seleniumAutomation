package Sites.TalentWiseDashboard;

import Sites.AdminConsole.Helpers.Header;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class AdminCustomerDashBoard{
    public static Header header;

    @FindBy (how = How.ID, using = "sso-username")
    public static WebElement ssoUserName;

    @FindBy (how = How.XPATH, using = "//p[text()='Sign Out']")
    public static WebElement signOutButton;

    @FindBy (how = How.ID, using = "quickLaunchNormal")
    public static WebElement quickLaunchButton;

    @FindBy (how = How.ID, using = "divQuickLaunchNewCandidate")
    public static WebElement newCandidateButton;

    @FindBy (how = How.XPATH, using = "//input[@value='Save Changes']")
    public static WebElement saveChangesButton;

    @FindBy (how = How.ID, using = "qf")
    public static WebElement firstNameField;

    @FindBy (how = How.ID, using = "17064-I9s1_1")
    public static WebElement firstnameElectronicI9;

    @FindBy (how = How.ID, using = "17064-I9s1_2")
    public static WebElement lastnameElectronicI9;

    @FindBy (how = How.ID, using = "17064-I9s1_11")
    public static WebElement ssnElectronicI9;

    @FindBy (how = How.ID, using = "17064-I9s1_10")
    public static WebElement dobElectronicI9;

    @FindBy (how = How.ID, using = "17064-I9s1_5")
    public static WebElement addressElectronicI9;

    @FindBy (how = How.ID, using = "17064-I9s1_6_1")
    public static WebElement apartmentnoElectronicI9;

    @FindBy (how = How.ID, using = "17064-addressI9s1_7-I9s1_7")
    public static WebElement citynameElectronicI9;

    @FindBy (how = How.ID, using = "17064-addressI9s1_7-I9s1_8")
    public static WebElement stateElectronicI9;

    @FindBy (how = How.ID, using = "17064-addressI9s1_7-I9s1_9")
    public static WebElement zipElectronicI9;

    @FindBy (how = How.XPATH, using = "//label[@for='17064-I9s1_14_USCITIZEN']")
    public static WebElement uscitizenElectronicI9;

    @FindBy (how = How.XPATH, using = "//label[@for='17064-qCertifySigning']")
    public static WebElement iAcknowledgeElectronicI9;

    @FindBy (how = How.ID, using = "qn")
    public static WebElement lastNameField;

    @FindBy (how = How.XPATH, using = "//input[@name='qee']")
    public static WebElement emailField;

    @FindBy (how = How.XPATH, using = "//input[@value='Create Candidate']")
    public static WebElement createCandidateButton;

    @FindBy (how = How.ID, using = "edit-profile")
    public static WebElement editProfileButton;

    @FindBy (how = How.XPATH, using = "//select[@name='qstartmonth']")
    public static WebElement startMonth;

    @FindBy (how = How.XPATH, using = "//select[@name='qstartday']")
    public static WebElement startDay;

    @FindBy (how = How.XPATH, using = "//select[@name='qstartyear']")
    public static WebElement startYear;

    @FindBy (how = How.ID, using = "dp_qduedate1")
    public static WebElement dueDate;

    @FindBy (how = How.ID, using = "btnSubmit")
    public static WebElement continueButton;

    @FindBy (how = How.ID, using = "changePasswordSubmit")
    public static WebElement changeButton;

    @FindBy (how = How.ID, using = "NewPassword")
    public static WebElement candidatePortalNewPasswordField;

    @FindBy (how = How.ID, using = "NewPassword_Confirm")
    public static WebElement candidatePortalConfirmNewPasswordField;

    static {
        PageFactory.initElements(Driver.getDriver(), AdminCustomerDashBoard.class);
    }

    public AdminCustomerDashBoard() {
        this.header = PageFactory.initElements(Driver.getDriver(), Header.class);
    }

    public static AdminCustomerDashBoard clickSignOut(){
        ssoUserName.click();
        signOutButton.click();
        return PageFactory.initElements(Driver.getDriver(), AdminCustomerDashBoard.class);
    }

    public static AdminCustomerDashBoard createCandidate(String firstName, String lastName, String eamil){
        SeleniumTest.waitMs(2000);
        quickLaunchButton.click();
        newCandidateButton.click();
        firstNameField.sendKeys(firstName);
        lastNameField.sendKeys(lastName);
        emailField.sendKeys(eamil);
        createCandidateButton.click();
        return PageFactory.initElements(Driver.getDriver(), AdminCustomerDashBoard.class);
    }

    public static AdminCustomerDashBoard clickEditProfile(){
        editProfileButton.click();
        return PageFactory.initElements(Driver.getDriver(), AdminCustomerDashBoard.class);
    }

    public static AdminCustomerDashBoard selectStartDate(String month, String day, String year){
        SeleniumTest.selectByVisibleTextFromDropDown(startMonth, month);
        SeleniumTest.selectByVisibleTextFromDropDown(startDay, day);
        SeleniumTest.selectByVisibleTextFromDropDown(startYear, year);
        saveChangesButton.click();
        return PageFactory.initElements(Driver.getDriver(), AdminCustomerDashBoard.class);
    }


    public static AdminCustomerDashBoard resetPassword(String newPassword){
        candidatePortalNewPasswordField.sendKeys(newPassword);
        candidatePortalConfirmNewPasswordField.sendKeys(newPassword);
        changeButton.click();
        return PageFactory.initElements(Driver.getDriver(), AdminCustomerDashBoard.class);
    }

    public static AdminCustomerDashBoard completeElectronicI9Section1(String firstname,String lastname,
                                                                      String ssn){
        firstnameElectronicI9.sendKeys(firstname);
        lastnameElectronicI9.sendKeys(lastname);
        ssnElectronicI9.sendKeys(ssn);
        dobElectronicI9.sendKeys("01/23/1994");
        addressElectronicI9.sendKeys("123 main road");
        apartmentnoElectronicI9.sendKeys("786");
        citynameElectronicI9.sendKeys("Los Angeles");
        SeleniumTest.selectByVisibleTextFromDropDown(stateElectronicI9, "California");
        zipElectronicI9.sendKeys("90006");
        uscitizenElectronicI9.click();
        iAcknowledgeElectronicI9.click();
        return PageFactory.initElements(Driver.getDriver(), AdminCustomerDashBoard.class);
    }

}
