package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.FluentWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public class Kendo {

    private static final By kendoBusyImageLocator = By.cssSelector("div.k-loading-image");

    private static Logger logger = LoggerFactory.getLogger(Kendo.class.getName());

    /**
     * If the kendoBusyImage indicator is present, waits for it to go away.
     *
     * The contents of this method use to be in ToolPage.waitForKendoGridRefresh(),
     * but code having nothing to do with a ToolPage kept calling ToolPage.waitForKendoGridRefresh().
     */
    public static void waitForKendoBusyImageToGoAway() {
        logger.info("Wait for Kendo busy image to go away");

        if (SeleniumTest.isElementVisibleNoWaiting(kendoBusyImageLocator)) {
            logger.debug("Found busy image");
            new FluentWait<org.openqa.selenium.WebDriver>(WebDriver.Driver.getDriver())
                    .withTimeout(60, TimeUnit.SECONDS)
                    .pollingEvery(3, TimeUnit.SECONDS)
                    .until(new Predicate<org.openqa.selenium.WebDriver>() {
                               public boolean apply(org.openqa.selenium.WebDriver driver) {
                                   if (!SeleniumTest.isElementVisibleNoWaiting(kendoBusyImageLocator)) {
                                       logger.debug("Busy image is gone");
                                       return true;
                                   }
                                   return false;
                               }
                           }
                    );
        }
    }
}
