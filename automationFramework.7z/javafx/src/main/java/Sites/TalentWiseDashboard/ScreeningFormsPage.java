package Sites.TalentWiseDashboard;

import Sites.Site;
import Sites.URL;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.net.UnknownHostException;

/**
 * Created by jgupta on 7/11/2017.
 */
public class ScreeningFormsPage {

    @FindBy(how = How.ID, using = "dbIdContentInner")
    static WebElement releaseAndFcraDocumentsSection;
    /**
     * Navigate to a Screening Forms page on customer portal for the provided customer
     * @param overrideUserId
     * @return ScreeningFormsPage
     * @throws UnknownHostException
     */
    public static ScreeningFormsPage navigateTo(int overrideUserId) throws UnknownHostException {
        SeleniumTest.navigateToUrl(URL.getURL(Site.ADMIN_CONSOLE) + "/screening/support.php?OverrideUserID=" + overrideUserId);
        return PageFactory.initElements(Driver.getDriver(), ScreeningFormsPage.class);
    }

    public static String getListOfReleaseDocuments() {
        return releaseAndFcraDocumentsSection.getText();
    }
}
