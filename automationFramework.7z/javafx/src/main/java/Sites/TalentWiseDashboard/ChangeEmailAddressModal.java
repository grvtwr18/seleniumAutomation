package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 10/19/2015.
 */
public class ChangeEmailAddressModal {
    public Sidebar sidebar;
    public Header header;
    public Footer footer;

    @FindBy(how = How.XPATH, using = "//input[contains(@value, 'Confirm Changes')]")
    WebElement confirmChangesButton;

    /**
     * Clicks on Confirm Changes Button
     * @return CandidateDetailsPage
     */
    public CandidateDetailsPage clickConfirmChanges() {
        confirmChangesButton.click();
        return PageFactory.initElements(Driver.getDriver(), CandidateDetailsPage.class);
    }
}
