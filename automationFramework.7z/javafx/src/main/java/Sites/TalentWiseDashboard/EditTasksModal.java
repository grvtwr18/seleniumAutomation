package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import Sites.TalentWiseDashboard.Tasks.OnboardingTasksPage;
import TWFramework.BasicTest;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Created by abrackett on 9/10/2015.
 */
public class EditTasksModal extends CustomerDashboardPages {
    private WebDriverWait wait;
    public Sidebar sidebar;
    public Header header;
    public Footer footer;

    private static final Logger logger =
        LoggerFactory.getLogger("Sites.TalentWiseDashboard.EditTasksModal");

    @FindBy(how = How.CSS, using = "#divSimpleDialogForm strong")
    public static WebElement modalHeaderText;

    @FindBy(how = How.CSS, using = "div.modalWindowLowerActions>input.button.buttoncancel")
    public static WebElement cancelButton;

    @FindBy(how = How.ID, using = "createNewVerifierBtnqverifierid2")
    private static WebElement createContributor2Button;

    @FindBy(how = How.ID, using = "fnqverifierid2")
    private static WebElement newContributorFirstNameBox2;

    @FindBy(how = How.ID, using = "lnqverifierid2")
    private static WebElement newContributorLastNameBox2;

    @FindBy(how = How.ID, using = "emailqverifierid2")
    private static WebElement newContributorEmailAddressBox2;

    @FindBy(how = How.ID, using = "qprepareremail")
    public static WebElement preparerAsTaskOneEmailTextBox;

    @FindBy(how = How.ID, using = "qee_1")
    public static WebElement taskOneEmailTextBox;

    @FindBy(how = How.ID, using = "qee_2")
    public static WebElement taskTwoEmailTextBox;

    @FindBy(how = How.ID, using = "dp_qstartdate1")
    public static WebElement taskOneStartDateTextBox;

    @FindBy(how = How.ID, using = "qstartdate1")
    public static WebElement taskOneStartDateTextBoxHidden;

    @FindBy(how = How.ID, using = "dp_qstartdate2")
    public static WebElement taskTwoStartDateTextBox;

    @FindBy(how = How.ID, using = "qstartdate2")
    public static WebElement taskTwoStartDateTextBoxHidden;

    @FindBy(how = How.CSS, using = "b[class='taskEditDueDate']")
    public static WebElement verifierTaskDueDate;

    @FindBy(how = How.CSS, using = "input[value='Save Changes']")
    public static WebElement saveChangesButton;

    @FindBy(how = How.CSS, using = "input[value='Confirm Changes']")
    public static WebElement confirmChangesButton;

    @FindBy(how = org.openqa.selenium.support.How.XPATH, using = "//div[@class='dbAlertColor']")
    private static WebElement errorText;

    @FindBy(how = How.ID, using = "qverifierid2")
    private static WebElement assignedReviewer;

    @FindBy(how = How.ID, using = "qverifiergroupid2")
    private static WebElement verifierGroup;

    static {
        PageFactory.initElements(Driver.getDriver(), EditTasksModal.class);
    }

    //region Title and Subtitle

    /**
     * Returns the error text found at the base of the editTasks Modal dialog
     * @return
     */
    public static String getErrorText() {
        return errorText.getText();
    }

    /**
     * Gets the individual Task Title
     *
     * @param taskNumber 1 based Task number to retrieve the title from
     * @return String representation of the Task Title or Error Message if applicable
     */
    public String getTaskTitleText(int taskNumber) {
        try {
            String locatorText =
                "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskNumber + "]/h3";
            WebElement taskTitle;
            taskTitle = Driver.getDriver().findElement(By.xpath(locatorText));
            return taskTitle.getText();
        } catch (NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
            return nse.getMessage();
        }
    }

    /**
     * Gets the individual Task SubTitle
     *
     * @param taskNumber 1 based Task number to retrieve the Subtitle from
     * @return String representation of the Subtitle or Error Message if applicable
     */
    public String getTaskSubtitleText(int taskNumber) {
        try {
            String locatorText =
                "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskNumber + "]/div/label";
            WebElement taskSubtitle;
            taskSubtitle = Driver.getDriver().findElement(By.xpath(locatorText));
            return taskSubtitle.getText();
        } catch (NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
            return nse.getMessage();
        }
    }
    //endregion

    //region Task Text

    /**
     * Retrieves the text of the given Task
     *
     * @param taskIndex A 1 based number for the task text to return
     * @return String representation of the specific Text for the Task or Error Message if the Text Field is not present
     */
    public String getTaskText(int taskIndex) {
        try {
            String locatorText =
                "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskIndex + "]/div/input";
            WebElement taskText;
            taskText = Driver.getDriver().findElement(By.xpath(locatorText));
            return taskText.getAttribute("value");
        } catch (NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
            return nse.getMessage();
        }
    }

    /**
     * Sets the text in the given Task Item
     *
     * @param taskIndex A 1 based number for the task text to set
     * @param taskText  The text to set into the text box
     */
    public void setTaskText(int taskIndex, String taskText) {
        try {
            String locatorText =
                "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskIndex + "]/div/input";
            WebElement taskTextBox;
            taskTextBox = Driver.getDriver().findElement(By.xpath(locatorText));
            SeleniumTest.clearAndSetText(taskTextBox, taskText);
        } catch (NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
        }
    }
    //endregion

    //region Task Group

    /**
     * Retrieves the specific Task Group Name
     *
     * @param taskIndex 1 based index of the Task Name to return
     * @return String representation of the Selected Group
     */
    public static String getTaskGroupName(int taskIndex) {
        try {
            String locatorText =
                "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskIndex + "]/div/select";
            Select taskGroup;
            taskGroup = new Select(Driver.getDriver().findElement(By.xpath(locatorText)));
            WebElement selectedOption = taskGroup.getFirstSelectedOption();
            return selectedOption.getText();
        } catch (NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
            return nse.getMessage();
        }
    }

    /**
     * Selects the Group from the Group Drop Down menu for the selected Task
     *
     * @param taskIndex 1 based index of the Task item
     * @param groupName The name of the group as shown in the Drop Down Menu
     */
    public static Select selectTaskGroup(int taskIndex, String groupName) {
        By selectTaskItemLocator = By.xpath(
            "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskIndex + "]/div/select");
        return selectTaskItem(groupName, selectTaskItemLocator);
    }

    private static Select selectTaskItem(String groupName, By selectTaskItemLocator) {
        Select selectItem;
        selectItem = new Select(Driver.getDriver().findElement(selectTaskItemLocator));
        List<WebElement> theSelectList = selectItem.getOptions();
        for (WebElement we : theSelectList) {
            if (we.getText().equals(groupName)) {
                selectItem.selectByVisibleText(groupName);
                return selectItem;
            }
        }
        return null;
    }
    //endregion

    //region Task User

    /**
     * Retrieves the specific task username
     *
     * @param taskIndex 1 based index of the Task item
     * @return String representation of the selected User
     */
    public static String getTaskUserName(int taskIndex) {
        try {
            String locatorText = "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskIndex
                + "]/div/div/select";
            Select taskUser;
            taskUser = new Select(Driver.getDriver().findElement(By.xpath(locatorText)));
            WebElement selectedOption = taskUser.getFirstSelectedOption();
            return selectedOption.getText();
        } catch (NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
            return nse.getMessage();
        }
    }

    /**
     * Selects the User from the User Drop Down menu for the selected Task
     *
     * @param taskIndex 1 based index of the Task item
     * @param userName  The name of the user as shown in the Drop Down menu
     */
    public static Select selectTaskUser(int taskIndex, String userName) {
        By selectTaskItemLocator = By.xpath(
            "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskIndex + "]/div/div/select");
        return selectTaskItem(userName, selectTaskItemLocator);
    }
    //endregion

    //region Combo Group and User Set Action

    /**
     * Select a reviewer from the Reviewer Drop Down menu for the selected Task
     *
     */
    public static void selectIrReviewer(String reviewerName) {
        SeleniumTest.selectByPartialVisibleTextFromDropDown(By.id("qverifierid2"), reviewerName);
    }

    /**
     * Selects the Group and associated user belonging to that group
     *
     * @param taskIndex 1 based index of the Task item
     * @param groupName Name of the group as shown in the drop down
     * @param userName  Name of the user as shown in the drop down
     */
    public static void selectTaskGroupAndUser(int taskIndex, String groupName, String userName) {
        try {
            By selectTaskItemLocator = By.xpath(
                "//div[@id='divEditProfileContent']/div[3]/div/div[" + taskIndex +
                "]/div/select");
            selectTaskItem(groupName, selectTaskItemLocator);

            selectTaskUser(taskIndex, userName);
        } catch (NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
        }
    }
    //endregion

    //region Candidate

    /**
     * returns Preparer's email input text.
     * @return
     */
    public static String getPreparerNotificationEmailTextBoxInput() {
        return preparerAsTaskOneEmailTextBox.getAttribute("value");
    }

    public static void setPreparerNotificationEmail(String email) {
        SeleniumTest.clearAndSetText(preparerAsTaskOneEmailTextBox, email);
    }

    /**
     * returns task 2 candidate's email input text if passed isPreparer is true
     * otherwise returns task 1 candidate's email input text.
     * @param isPreparer
     * @return
     */
    public static String getTaskNotificationEmailTextBoxInput(boolean isPreparer) {
        return isPreparer ? taskTwoEmailTextBox.getAttribute("value"):
                taskOneEmailTextBox.getAttribute("value");
    }

    public static void setTaskNotificationEmail(String email, boolean isPreparer) {
        SeleniumTest.clearAndSetText(isPreparer ? taskTwoEmailTextBox :
                taskOneEmailTextBox, email);
    }

    /**
     * returns task 2 candidate's start date input text if passed isPreparer is true
     * otherwise returns task 1 candidate's start date input text.
     * @param isPreparer
     * @return candidate's start date String
     */
    public static String getCandidateStartDateInput(boolean isPreparer) {
        return isPreparer ? taskTwoStartDateTextBox.getAttribute("value"):
                taskOneStartDateTextBox.getAttribute("value");
    }

    /**
     * Sets task start date for passed taskIndex.
     * @param date
     * @param taskIndex
     */
    public static void setViewReportPageEditTaskStartDate(LocalDate date, int taskIndex) {
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(date,
                taskIndex == 2 ?
                        taskTwoStartDateTextBox.getAttribute("id"):
                        taskOneStartDateTextBox.getAttribute("id"),
                taskIndex == 2 ?
                        taskTwoStartDateTextBoxHidden.getAttribute("id"):
                        taskOneStartDateTextBoxHidden.getAttribute("id"));
    }

    //endregion

    //region Task Due Date

    /**
     * Returns string representation of the displayed Verifier task due date
     * @return
     */
    public static String getVerifierTaskDueDateString() {
        return verifierTaskDueDate.getText();
    }

    /**
     * Retrieves the current Task Due Date
     * TODO refactor to use DateFieldHelper
     * @deprecated do not use until TODO is complete
     * @param taskIndex 1 based index of the Task to retrieve the due date from
     * @return String representation of the Date found in the due date box
     */
    public static LocalDate getTaskDueDate(int taskIndex) {
        String dateLocatorString = "qduedate";
        try {
            return LocalDate.parse(
                    Driver.getDriver().findElement(By.id(dateLocatorString + taskIndex))
                          .getAttribute("value"), DateTimeFormatter.ofPattern("uu-MM-dd"));
        } catch (org.openqa.selenium.NoSuchElementException nse) {
            dateLocatorString = "qstartdate";
            return LocalDate.parse(
                    Driver.getDriver().findElement(By.id(dateLocatorString + taskIndex))
                          .getAttribute("value"), DateTimeFormatter.ofPattern("uu-MM-dd"));
        }
    }

    public static Boolean setTaskDueDate(int taskIndex, LocalDate localDate) {
        String dp_dateLocatorString = "dp_qduedate";
        String dateLocatorString = "qduedate";
        try {
            Driver.getDriver().findElement(By.id(dp_dateLocatorString + taskIndex));
        } catch (org.openqa.selenium.NoSuchElementException nse) {
            dp_dateLocatorString = "dp_qstartdate";
            dateLocatorString = "qstartdate";
        }
        try {
            SeleniumTest
                    .FireFoxWorkArounds
                    .setCalendarControl_uu_Dash_MM_Dash_dd(
                            localDate,
                            dp_dateLocatorString + taskIndex,
                            dateLocatorString + taskIndex);

            return true;
        } catch (org.openqa.selenium.NoSuchElementException nse) {
            BasicTest.addErrorToCollector(nse);
            return false;
        }
    }
    //endregion

    //region Modal Buttons

    /**
     * Clicks on the Save Changes Button - dismisses the modal dialog
     *
     * @param parentPageName Parent class to be returned once Save Changes is clicked
     * @return ParentPage class
     */
    public static Object clickSaveChangesButton(String parentPageName) {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.xpath("//input[@value='Save Changes']"));

        /**
         * Waiting here explicitly for modal dialog to close so we can
         * get the current instance of the Candidate Details class - the page refreshes after clicking save
         */
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout));

        if (parentPageName.equals("ViewReportPage")) {
            return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);
        } else if (parentPageName.equals("CandidateDetailsPage")) {
            return PageFactory.initElements(Driver.getDriver(), CandidateDetailsPage.class);
        } else if (parentPageName.equals("OnboardingTasksPage")) {
            return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
        }
        return null;
    }

    /**
     * Clicks on the Save Changes Button - dismisses the modal dialog
     * @return ParentPage class
     */
    public static void clickSaveChangesButton() {
        final By saveChangesLocator = By.xpath("//input[@value='Save Changes']");
        final WebElement saveChangesButton = Driver.getDriver().findElement(saveChangesLocator);

        try {
            TWFramework.WaitUntil.waitUntil(() -> {
                if (SeleniumTest.isElementPresent(saveChangesLocator)) {
                    saveChangesButton.click();
                    return false;
                } return true; });
        } catch (org.openqa.selenium.TimeoutException toe) {
            // For some reason WaitUntil with TimeOutException is not working
            // catching it manually and throwing it away as we don't care.
        }
        /**
         * Waiting here explicitly for modal dialog to close so we can
         * get the current instance of the Candidate Details class - the page refreshes after clicking save
         */
        SeleniumTest.defaultWaitForElementWithMultiplier(1);
    }

    public static void onlyClickSaveChangesButton() {
        saveChangesButton.click();
        SeleniumTest.defaultWaitForElementWithMultiplier(2);
    }

    public static void clickConfirmChanges() {
        SeleniumTest.defaultWaitForElementWithMultiplier(1);
        confirmChangesButton.click();
        SeleniumTest.defaultWaitForElementWithMultiplier(1);
    }

    /**
     * Clicks cancel
     * @param returnedClass The page to be returned.
     * @return
     */
    public static CustomerDashboardPages clickCancelButton(Class<? extends CustomerDashboardPages> returnedClass) {
        cancelButton.click();
        // Added a forced wait here because the page does a page refresh at some point after the
        // modal dialog closes - waiting for page load DOES NOT WORK
        SeleniumTest.defaultWaitForElementWithMultiplier(.5);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks cancel
     * @return
     */
    public static void clickCancel() {
        cancelButton.click();
    }

    /**
     * Waits for the given select dropdown to get populated with the value provided
     *
     * @param dropdownId
     * @param verifierName
     */
    public void waitForTaskVerifierDropDownToGetPopulatedWithValue(String dropdownId,
        String verifierName) {
        final Select task1DropList = new Select(Driver.getDriver().findElement(By.id(dropdownId)));
        WaitUntil.waitUntil(30, 3, () -> task1DropList.getOptions().size() > 2);
    }

    /**
     * Clicks on Create New Contributor button corresponding to the task.
     *
     * @param taskNumber
     */
    public void clickCreateNewContributorButton(String taskNumber) {
        String createNewContributorLocator = "createNewVerifierBtnqverifierid" + taskNumber;
        Driver.getDriver().findElement(By.id(createNewContributorLocator)).click();
    }

    /**
     * Types first name of the verifier
     *
     * @param taskNumber
     * @param firstName
     */
    public void typeVerifierFirstName(String taskNumber, String firstName) {
        String firstNameTextboxLocator = "fnqverifierid" + taskNumber;
        WebElement verifierFirstNameTextBox =
            Driver.getDriver().findElement(By.id(firstNameTextboxLocator));
        verifierFirstNameTextBox.sendKeys(firstName);
    }

    /**
     * Types last name of the verifier
     *
     * @param taskNumber
     * @param lastName
     */
    public void typeVerifierLastName(String taskNumber, String lastName) {
        String lastNameTextboxLocator = "lnqverifierid" + taskNumber;
        WebElement verifierLastNameTextBox =
            Driver.getDriver().findElement(By.id(lastNameTextboxLocator));
        verifierLastNameTextBox.sendKeys(lastName);
    }

    /**
     * Types email address of the new verifier
     *
     * @param taskNumber
     * @param email
     */
    public void typeVerifierEmailAddress(String taskNumber, String email) {
        String emailLocator = "emailqverifierid" + taskNumber;
        WebElement emailTextBox = Driver.getDriver().findElement(By.id(emailLocator));
        SeleniumTest.clearAndSetText(emailTextBox, email);
    }

    /**
     * Clears last name field corresponding to the given task number.
     *
     * @param taskNumber
     */
    public void clearVerifierLastName(String taskNumber) {
        String lastNameTextboxLocator = "lnqverifierid" + taskNumber;
        WebElement verifierLastNameTextBox =
            Driver.getDriver().findElement(By.id(lastNameTextboxLocator));
        verifierLastNameTextBox.clear();
    }

    /**
     * Clears email field corresponding to the given task.
     *
     * @param taskNumber
     */
    public void clearVerifierEmail(String taskNumber) {
        String emailLocator = "emailqverifierid" + taskNumber;
        WebElement emailTextBox = Driver.getDriver().findElement(By.id(emailLocator));
        emailTextBox.clear();
    }

    /**
     * Click on Save changes to remain on the modal. This happens when user gets validation message.
     *
     * @return
     */
    public EditTasksModal clickSaveChangesButtonToRemainOnEditTaskModal() {
        saveChangesButton.click();
        return PageFactory.initElements(Driver.getDriver(), EditTasksModal.class);
    }

    public static void clickCreateNewContributor2() {
        createContributor2Button.click();
    }

    public static void setNewContributor2FirstName(String firstName) {
        SeleniumTest.clearAndSetText(newContributorFirstNameBox2, firstName);
    }

    public static void setNewContributor2LastName(String lastName) {
        SeleniumTest.clearAndSetText(newContributorLastNameBox2, lastName);
    }


    public static void setNewContributor2EmailAddress(String emailAddress) {
        SeleniumTest.clearAndSetText(newContributorEmailAddressBox2, emailAddress);
    }

    public static String getModalHeaderText() {
        return modalHeaderText.getText();
    }

    public static void selectVeriferGroup(String groupName){
        SeleniumTest.selectByVisibleTextFromDropDown(verifierGroup, groupName);
    }
}
