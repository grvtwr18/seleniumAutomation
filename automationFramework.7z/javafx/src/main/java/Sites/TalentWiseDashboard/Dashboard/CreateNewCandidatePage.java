package Sites.TalentWiseDashboard.Dashboard;

import TWFramework.SeleniumTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import static org.testng.AssertJUnit.assertEquals;

/**
 * Created by jgupta on 8/12/2015.
 */
public class CreateNewCandidatePage {

        /**
         * Constructs a new CreateNewCandidatePage page object.
         */
        public CreateNewCandidatePage() {

        }

        @FindBy(how = How.ID, using = "qf")
        private WebElement firstNameTextBox;


        @FindBy(how = How.ID, using = "qmi")
        private WebElement middleNameTextBox;

        @FindBy(how = How.ID, using = "qn")
        private WebElement lastNameTextBox;

        @FindBy(how = How.NAME, using = "qee")
        private WebElement emailAddressTextBox;

        @FindBy(how = How.CSS, using = "input.button.buttonwidth125")
        private WebElement createCandidateButton;

        @FindBy(how = How.CSS, using = "div.modalWindowLowerStatus > div.dbAlertColor")
        private WebElement modalWindowStatus;

        /**
         * This method types the first name in the first name textbox
         *
         * @param firstName
         */
        public void typeFirstName(String firstName)
        {
            SeleniumTest.clearAndSetText(firstNameTextBox, firstName);
        }


        /**
         * This method types the first name in the first name textbox
         *
         * @param middleName
         */
        public void typeMiddleName(String middleName)
        {
            SeleniumTest.clearAndSetText(firstNameTextBox, middleName);
        }

        /**
         * This method types the last name in the last name textbox.
         *
         * @param lastName
         */
        public void typeLastName(String lastName)
        {
            SeleniumTest.clearAndSetText(lastNameTextBox, lastName);
        }

        /**
         * This method types the email address in the email's textbox.
         *
         * @param emailAddress
         */
        public void typeEmailAddress(String emailAddress)
        {
            SeleniumTest.clearAndSetText(emailAddressTextBox, emailAddress);
        }

        /**
         * This method clicks the Create Candidate button.
         *
         * @param errorMessage
         */
        public void clickCreateCandidateButton(String errorMessage) {
            createCandidateButton.click();
            assertEquals(errorMessage, modalWindowStatus);
        }
}
