package Sites.TalentWiseDashboard.Dashboard.adminTools.userSettings.roles;

import Sites.TalentWiseDashboard.Helpers.AdminMenubar;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by MNam on 2/15/2018.
 */
public class EditRolesPage extends SeleniumTest {
    // Default Permission
    public static enum Permissions {
        DOCS_MEDIA("Manage Documents and Media"),
        EMAIL_TEMPLATES("Manage Email Templates"),
        PORTALS("Manage Portals"),
        PROFILES("Manage Profiles"),
        ROLES("Manage Roles"),
        WORKFLOWS("Manage Workflows"),
        USER_IDS("View UserIds");

        private String name;

        Permissions(String permission_name) {
            name = permission_name;
        }

        public String getName() {
            return name;
        }
    }

    @FindBy(how = How.XPATH, using = "//*[@id=\"roleForm\"]/div/div[2]/div[1]/div[1]/div/label")
    private WebElement roleNamelabel;

    @FindBy(how = How.XPATH, using = "//form[@id='roleForm']/div/div[2]/div/div[2]/div/label")
    private WebElement roleDescriptionlabel;

    @FindBy(how = How.ID, using = "roleName")
    private WebElement roleName;

    @FindBy(how = How.ID, using = "roleDescription")
    private WebElement roleDescription;

    @FindBy(how = How.XPATH, using = "//*[@id=\"roleId\"]")
    private WebElement roleId;

    @FindBy(how = How.ID, using = "addUsers")
    private WebElement addUsers;

    @FindBy(how = How.ID, using = "DeleteButton")
    private WebElement removeButton;

    @FindBy(how = How.ID, using = "deleteRole")
    private WebElement deleteRoleButton;

    @FindBy(how = How.ID, using = "RoleAssignedUsersSearchBox")
    private WebElement roleAssignedUsersSearchBox;

    @FindBy(how = How.XPATH, using = "//*[@id=\"roleDetailsForm\"]/div/div[1]/h2")
    private WebElement assignedUsersHeaderText;

    @FindBy(how = How.ID, using = "userSearch")
    private WebElement Search;

    @FindBy(how = How.XPATH, using = "//div[@id='page-wrapper']/div[1]/a")
    private WebElement backToRoleList;

    @FindBy(how = How.XPATH, using = "//*[@id='rolePermissionsForm']/div[1]/div[2]/div/table/thead/tr/th[2]")
    private WebElement noAccess;

    @FindBy(how = How.XPATH, using = "//form[@id='rolePermissionsForm']/div/div[2]/div/table/thead/tr/th[3]")
    private WebElement viewOnly;

    @FindBy(how = How.XPATH, using = "//form[@id='rolePermissionsForm']/div/div[2]/div/table/thead/tr/th[4]")
    private WebElement viewAndModify;

    @FindBy(how = How.XPATH, using = "//form[@id='rolePermissionsForm']/div/div[2]/div/table/tbody/tr[1]/td")
    private WebElement manageDocumentsAndMedia;

    @FindBy(how = How.ID, using = " //form[@id='rolePermissionsForm']/div/div[2]/div/table/tbody/tr[2]/td")
    private WebElement manageEmailTemplates;

    @FindBy(how = How.XPATH, using = "//form[@id='rolePermissionsForm']/div/div[2]/div/table/tbody/tr[3]/td")
    private WebElement managePortals;

    @FindBy(how = How.XPATH, using = "//form[@id='rolePermissionsForm']/div/div[2]/div/table/tbody/tr[4]/td")
    private WebElement manageProfiles;

    @FindBy(how = How.XPATH, using = "//form[@id='rolePermissionsForm']/div/div[2]/div/table/tbody/tr[5]/td")
    private WebElement manageRoles;

    @FindBy(how = How.XPATH, using = "//*[@id='rolePermissionsForm']/div[1]/div[2]/div/table/tbody/tr[6]/td[1]")
    private WebElement manageWorkFlows;

    @FindBy(how = How.XPATH, using = "//*[@id='rolePermissionsForm']/div[1]/div[2]/div/table/tbody/tr[7]/td[1]")
    private WebElement viewUserIds;

    //web elements in Adduser to role dialog
    @FindBy(how = How.ID, using = "selectedUsers")
    private WebElement selectedUsers;

    @FindBy(how = How.XPATH, using = "//*[@id='windowDialog_wnd_title']") //Add User(s) to Role
    private WebElement title;


    @FindBy(how = How.XPATH, using = "//*[@id='roleDetailsForm']/button[1]")
    private WebElement addButton;

    @FindBy(how = How.XPATH, using = "//*[@id='AssignUserToRole']/div[2]/table/tbody/tr/td")
    private WebElement results; // No results Found

    @FindBy(how = How.XPATH, using = "//*[@id='page-wrapper']/div[1]/div/h1")
    private WebElement headingText;

    @FindBy(how = How.XPATH, using = "//*[@id='rolePermissionsForm']/div[1]/div[1]/h2")
    private WebElement rolePermissionHeader;

    @FindBy(how = How.XPATH, using = "//*[@id='rolePermissionsForm']/div[1]/div[2]/p")
    private WebElement rolePermissionText;

    @FindBy(how = How.ID, using = "permissionsInfoTooltipdisplay")
    private WebElement permissionsTooltipText;

    @FindBy(how = How.XPATH, using = "//*[@id='RoleAssignedUsers']/table/tbody/tr/td[2]")
    private WebElement assignedUserName;

    @FindBy(how = How.XPATH, using = "//*[@id='RoleAssignedUsers']/table/tbody/tr/td[3]")
    private WebElement assignedUserEmail;

    @FindBy(how = How.XPATH, using = "//*[@id='RoleAssignedUsers']/table/tbody/tr/td[4]")
    private WebElement assignedRoles;

    @FindBy(how = How.XPATH, using = "//*[@id='RoleAssignedUsers']/div[2]/span")
    private WebElement userlist;

    @FindBy(how = How.XPATH, using = "//*[@id=\"windowDialogContent\"]/div[2]/button[1]")
    private WebElement confirmDelete;

    private String xpathPermission = "//*[@id='rolePermissionsForm']/div[1]/div[2]/div/table/tbody/tr";
    private String xpathAssignedUsers = "//*[@id=\"RoleAssignedUsers\"]/table/tbody/tr";

    public  EditRolesPage() {
        initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public RolesPage clickBackToRolesList() {
        SeleniumTest.click(backToRoleList);
        return new RolesPage();
    }

    public String getRoleId() {
        return SeleniumTest.getText(roleId);
    }

    public String getRoleName() {
        return SeleniumTest.getText(roleName);
    }

    public String getRoleDescription() {
        return SeleniumTest.getText(roleDescription);
    }

    public String getRoleHeaderText() {
        return SeleniumTest.getText(headingText);
    }

    public  String getPermissionHeader() {
        return SeleniumTest.getText(rolePermissionHeader);
    }

    public String getPermissionText() {
        return SeleniumTest.getText(rolePermissionText);
    }

    public String getPermissionToolTip() {
        SeleniumTest.mouseOverElement(permissionsTooltipText);
        return SeleniumTest.getToolTipText(permissionsTooltipText);
    }

    public int getElementRow(Permissions permission) {
        List  rows = Driver.getDriver().findElements(By.xpath (xpathPermission));
        String permissionName = permission.getName();
        for (int i =1;i<=rows.size();i++)
        {
            if(permissionName.equals(SeleniumTest.getTextByLocator(By.xpath(xpathPermission + "[" + i + "]")))) {
                return i;
            }
        }
        return 0;
    }

    public String getPermissionName(Permissions permission) {
       int index = getElementRow(permission);
       return SeleniumTest.getTextByLocator(By.xpath(xpathPermission + "[" + index + "]"));
    }

    public boolean hasNoAccessPermissions(Permissions permission) {
        int index = getElementRow(permission);
        return (1 == Driver.getDriver().findElements(By.xpath(xpathPermission + "[" + index + "]/td[2]/i")).size());
    }

    public boolean hasViewOnlyPermissions(Permissions permission) {
        int index = getElementRow(permission);
        return (1 == Driver.getDriver().findElements(By.xpath(xpathPermission + "[" + index + "]/td[3]/i")).size());
    }

    public boolean hasViewAndModifyPermissions(Permissions permission) {
        int index = getElementRow(permission);
        return (1 == Driver.getDriver().findElements(By.xpath(xpathPermission + "[" + index + "]/td[4]/i")).size());
    }

    public boolean isDeleteRoleDisabled() {
        return SeleniumTest.isElementDisabled(deleteRoleButton);
    }

    public void clickDeleteRole() {
        if ("TalentWise generated roles cannot be deleted.".equals(deleteRoleButton.getAttribute("title"))) {
            logger.info("TalentWise generated roles cannot be deleted");
        } else {
            SeleniumTest.click(deleteRoleButton);
        }
    }

    public RolesPage clickConfirmDelete() {
        if ("TalentWise generated roles cannot be deleted.".equals(deleteRoleButton.getAttribute("title"))) {
            logger.info("TalentWise generated roles cannot confirm to be deleted");
            SeleniumTest.waitForPageLoadToComplete();
            AdminMenubar.clickUserlistMenuItem();
            return new RolesPage();
        } else {
            SeleniumTest.click(confirmDelete);
            return new RolesPage();
        }
    }

    public boolean isAddUserEnabled() {
        return SeleniumTest.isElementEnabled(addUsers);
    }

    public AddUserToRoleModal clickAddUsers() {
        SeleniumTest.click(addUsers);
        return new AddUserToRoleModal();
    }

    public boolean isRemoveUserDisabled() {
        return SeleniumTest.isElementDisabled(removeButton);
    }

    public String getAssignedUsersHeaderText() {
        return SeleniumTest.getText(assignedUsersHeaderText);
    }

    public String getUserslist() {
        return SeleniumTest.getText(userlist);
    }

    public String getAssignedUsersName() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAssignedUsers + "/td[2]"));

    }

    public String getAssignedUsersEmail() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAssignedUsers + "/td[3]"));
    }

    public String getUserAssignedRoles() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAssignedUsers + "/td[4]"));
    }

    public boolean removeIconExists() {
        return SeleniumTest.isElementPresent(By.xpath(xpathAssignedUsers + "/td[5]/span/a"));
    }

    public void clickRemoveIcon() {
        SeleniumTest.click(By.xpath(xpathAssignedUsers + "/td[4]"));
    }

    public String getAssignedRolesNoResults() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAssignedUsers));
    }

    public String getRowIDFromTable(String roleName){
        return SeleniumTest.getTextByLocator(By.xpath("//tbody[@role='rowgroup']//td[2]/a[text()='"+roleName+"']/../../td[1]"));
    }
}