package Sites.TalentWiseDashboard.Dashboard.adminTools.userSettings.roles;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import static TWFramework.SeleniumTest.mouseOverElement;

/**
 * Created by MNam on 2/12/2018.
 */
public class RolesPage {

    @FindBy(how = How.ID, using = "createNew")
    private WebElement createNew;

    @FindBy(how = How.ID, using = "dbIdFooter")
    private WebElement footer;

    @FindBy(how = How.XPATH, using = "//*[@id='RoleList']/div[2]/span[2]")
    private WebElement rolelist; //1 - 3 of 3 items

    @FindBy(how = How.ID, using = "windowDialog_wnd_title")
    private WebElement addUserToRole; //Add User(s) to Role

    @FindBy(how = How.ID, using = "addUsersToRole")
    private WebElement addButton;

    @FindBy(how = How.XPATH, using = "//*[@id=\"roleDetailsForm\"]/button[2]")
    private WebElement CancelButton;

    @FindBy(how = How.ID, using = "userSearch")
    private WebElement userSearch;

    //id="id988176542" //

    @FindBy(how = How.XPATH, using = "//*[@id=\"rolePermissionsForm\"]/div[1]/div[2]/div/table/tbody/tr[1]/td[2]")
    private WebElement noAccess;

    @FindBy(how = How.XPATH, using = "//*[@id=\"rolePermissionsForm\"]/div[1]/div[2]/div/table/tbody/tr[2]/td[3]")
    private WebElement ViewOnly;

    @FindBy(how = How.XPATH, using = "//*[@id=\"RoleAssignedUsers\"]/table/tbody/tr/td[2]")
    private WebElement name;

    @FindBy(how = How.XPATH, using = "//*[@id=\"RoleAssignedUsers\"]/table/tbody/tr/td[3]")
    private WebElement email;

    @FindBy(how = How.XPATH, using = "//*[@id=\"RoleAssignedUsers\"]/table/tbody/tr/td[4]")
    private WebElement roles;

    @FindBy(how = How.CSS, using = "th[data-field='roleId']")
    private WebElement roleIdSortLink;

    @FindBy(how = How.CSS, using = "th[data-field='roleName']")
    private WebElement roleNameSortLink;

    @FindBy(how = How.CSS, using = "th[data-field='roleDescription']")
    private WebElement roleDescSortLink;

    @FindBy(how = How.ID, using = "RoleListSearchBox")
    private WebElement roleSearch;

    @FindBy(how = How.XPATH, using = "//*[@id=\"RoleList\"]/table/tbody/tr/td[1]")
    private WebElement roleId;

    @FindBy(how = How.XPATH, using = "//*[@class=\"errorRow\"]/child::td[1]")
    private WebElement noResultsFound;

    public  RolesPage() {
        initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
        SeleniumTest.waitForElement(By.xpath("//*[@id='RoleList']/table/tbody/tr[1]/td[1]")); //wait until Administrator role is loaded
    }

    public String getRoleIdAtIndex(int index) {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"RoleList\"]/table/tbody/tr[" + index + "]/td[1]"));
    }

    public String getRoleNameAtIndex(int index) {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"RoleList\"]/table/tbody/tr[" + index + "]/td[2]"));
    }

    public String getRoleDescAtIndex(int index) {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"RoleList\"]/table/tbody/tr[" + index + "]/td[3]"));
    }

    public String getRoleMembersAtIndex(int index) {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"RoleList\"]/table/tbody/tr[" + index + "]/td[4]"));
    }

    public String getRoleModifiedByAtIndex(int index) {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"RoleList\"]/table/tbody/tr[" + index + "]/td[5]"));
    }

    public String getRoleModifiedOnAtIndex(int index) {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"RoleList\"]/table/tbody/tr[" + index + "]/td[6]"));
    }

    public EditRolesPage clickEditActionsAtIndex(String roleId) {
        SeleniumTest.click(By.id("editRoleId_" + roleId));
        SeleniumTest.waitForPageLoadToComplete();
        return new EditRolesPage();
    }

    public CreateRolePage clickCreateNewRole() {
        SeleniumTest.click(createNew);
        return new CreateRolePage();
    }

    public void clickDuplicateRole(int roleId) {
        SeleniumTest.click(By.id("duplicateRoleId_" + roleId));
    }

    public String getPrivacyFooterText() {
        return SeleniumTest.getText(footer);
    }

    public String getRoleItems() {
        return SeleniumTest.getText(rolelist);
    }

    public void sortByRowId() {
        SeleniumTest.click(roleIdSortLink);
    }

    public void sortByRowName() {
        SeleniumTest.click(roleNameSortLink);
    }

    public void sortByRowDescription() {
        SeleniumTest.click(roleDescSortLink);
    }

    public void searchRole(String searchStr) {
        SeleniumTest.clearAndSetText(roleSearch, searchStr);
        SeleniumTest.waitForPageLoadToComplete();
        ToolPage.waitForKendoGridRefresh();
    }

    public String getEditTooltip(String roleId) {
       WebElement element = Driver.getDriver().findElement(By.id("editRoleId_" + roleId));
       return SeleniumTest.getToolTipText(element);
    }

    public String getDuplicateTooltip(String roleId) {
        WebElement element = Driver.getDriver().findElement(By.id("duplicateRoleId_" + roleId));
        return SeleniumTest.getToolTipText(element);
    }

    public String getRoleId() {
        return SeleniumTest.getText(roleId);
    }

    public String gotNoResultsFound() {
        try{
            return SeleniumTest.getText(noResultsFound);
        } catch (NoSuchElementException ignore){
            return "";
        }
    }

}
