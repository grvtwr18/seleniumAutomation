package Sites.TalentWiseDashboard.Dashboard;

import Sites.Site;
import Sites.TalentWiseDashboard.CustomerLoginPage;
import Sites.TalentWiseDashboard.CustomerPortalPage;
import Sites.TalentWiseDashboard.Enums.AccountType;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchPage;
import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import Sites.TalentWiseDashboard.Tasks.OnboardingTasksPage;
import Sites.TalentWiseDashboard.TicketForm;
import Sites.URL;
import TWFramework.BodyTextHelper;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import WebDriver.DriverType;
import Workflows.Candidate;
import com.google.common.base.Predicate;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static Sites.Site.CUSTOMER_DASHBOARD;

/**
 * Page object that represents the Dashboard page on the TalentWise Dashboard website
 * @author eelefson, ssmith
 */
public class DashboardPage extends CustomerPortalPage {
    private static final Logger logger = LoggerFactory.getLogger("Sites.TalentWiseDashboard.Dashboard.DashboardPage");
    private static final String DASHBOARD_URL_PATH = "/screening/dashboard.php";

    //<editor-fold desc="Move these to correct classes">
    //TODO: these belong in Sidebar, Header or Footer. See those classes (fields in parent CustomerPortalPage).
    @FindBy(how = How.ID, using = "quickLaunchNormal")
    private static WebElement quickLaunchDropDown;

    @FindBy(how = How.ID, using = "divQuickLaunchOnboard")
    private static WebElement quickLaunchOnboarding;

    @FindBy(how = How.ID, using = "HpmActivityScrollContainer")
    private static WebElement hpmAcitivtyScrollContainer;

    //TODO: add upcoming due datesHide button and show buttons
    @FindBy(how = How.ID, using = "HpmActivityHideButton")
    private static WebElement hpmActivityHideButton;
    
    @FindBy(how = How.XPATH, using =
            "//*[@id='HpmTasksWidgetRowViewMore']/a")
    private static WebElement viewMoreHpmTasks;

    @FindBy(how = How.ID, using = "HpmTasksHideButton")
    private static WebElement hpmTasksHideButton;

    @FindBy(how = How.ID, using = "HpmTasksScrollContainer")
    private static WebElement hpmTasksScrollContainer;

    @FindBy(how=How.ID, using = "HpmTasksShowButton")
    private static WebElement hpmTasksShowButton;

    @FindBy(how = How.ID, using = "HpmActivityScrollContainer")
    private static WebElement hpmActivityScrollContainer;

    @FindBy(how = How.XPATH, using = "//div[@id=\"HpmDates\"]/.//a[contains(@onclick,\"widget=HpmDates\")]")
    private static WebElement viewMoreDueDates;

    @FindBy(how = How.ID, using = "HpmDatesHideButton")
    private static WebElement hpmDatesHideButton;

    @FindBy(how = How.ID, using = "HpmDatesShowButton")
    private static WebElement hpmDatesShowButton;

    @FindBy(how = How.ID, using = "resolve")
    private static WebElement candidateFindTextbox;

    @FindBy(how = How.XPATH, using = "//*[@id='sideSearchForm']/p/span[@class='search-button']")
    private static WebElement candidateSearchButton;

    @FindBy(how = How.CSS, using = "img.pngfix")
    private WebElement candidateFindImage;

    @FindBy(how = How.ID, using = "sso-username")
    private static WebElement usernameLink;

    @FindBy(how = How.XPATH, using = "//*[@role='menuitem']/*[text()='Sign Out']")
    private static WebElement signOutLink;

    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Candidate View')]")
    private static WebElement candidateView;

    @FindBy(how = How.XPATH, using = "//input[@value='Add Screening']")
    private static WebElement addScreening;

    @FindBy(how = How.ID, using = "helpAndResources")
    private static WebElement lnkHelpAndResources;

    //</editor-fold>

    private static final By availableProductsLocator = By.id("btncustom_shell_1"); //shell Alacarte

    @FindBy(how = How.XPATH, using =
            "//div[@id='HpmTasks']/.//a[contains(@href,'/screening/tasks.php')]")
    private static WebElement myTasksLink;

    @FindBy(how = How.ID, using = "btnticket_shell_1")
    private static WebElement shellAlacarteTicket;

    @FindBy(how = How.ID, using = "HpmDatesScrollContent")
    private static WebElement dueDateContent;

    static By widgetRowLocator = By.className("widgetRow");

    private final String plusMinusButtonFrontHalf = "//div[@class='dashboardsection']/div[div[div[span[text()='Custom "
            + "Packages']]]]/div[div[@class='buttoncolumn'][div[a[contains(@href,'ufid=";
    // Rather than using local variables for the below strings - I chose to put them at the top so they would
    // be readily accessible in case of maintenance
    private final String plusButtonBackHalf =
            "')]]]]/div[@class='hideshowbuttons']/a[@class='updownarrow']/img[contains(@alt, 'show')]";
    private final String minusButtonBackHalf =
            "')]]]]/div[@class='hideshowbuttons']/a[@class='updownarrow']/img[contains(@alt, 'hide')]";
    private final String plusMinusButtonBackHalf = "')]]]]/div[@class='productcolumn']/h2/a";
    private static final String ticketButtonFrontHalf = "//a[contains(@id,'ticket_";
    private static final String ticketButtonBackHalf = "_2')]/button";


    private Boolean foundIt = false;

    //Begin password section
    //TODO remove all this password stuff and put it on a change password page where it belings
    //Should probably create a new page object, but will do that
    //later when I need to call this page via the admin tab
    @FindBy(how = How.NAME, using = "PasswordOld")
    private static WebElement oldPasswordTextBox;

    @FindBy(how = How.NAME, using = "Password")
    private static WebElement newPasswordTextBox;

    @FindBy(how = How.NAME, using = "Password2")
    private static WebElement confirmNewPasswordTextBox;

    private static final String passwordExpirationNotificationMessageLocatorPath =
            "//div[contains(@class,'passwordExpiringMessage')]";
    private static final By passwordExpirationNotificationMessageLocator =
            By.xpath(passwordExpirationNotificationMessageLocatorPath);
    @FindBy(how = How.XPATH, using = passwordExpirationNotificationMessageLocatorPath)
    private static WebElement passwordExpirationNotificationMessage;


    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    private static WebElement saveButton;

    //@FindBy(how = How.ID, using = "changePassword")
    //@FindBy(how = How.XPATH, using = "//form[@id='changePassword']/h3")
    //@FindBy(how = How.CSS, using = "input[value='Change']")
    //This is the fourth change to this button, when, if ever, will this stop being changed?
    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    private static WebElement changePasswordBtn;

    @FindBy(how = How.XPATH, using = "//*[@id='changePassword']/h3")
    private static WebElement changePasswordSuccessMsg;

    @FindBy(how = How.CSS, using = "div.dbMessage>span")
    private WebElement changePasswordErrorMsg;

    @FindBy(how = How.CSS, using = "div.errorMsg")
    private WebElement passwordErrorMsg;

    @FindBy(how = How.XPATH, using = "//input[@name='Password2']/following-sibling::div")
    private static WebElement reTypePasswordErrorInstructions;

    @FindBy(how = How.XPATH, using = "//input[@name='Password']/following-sibling::div")
    private static WebElement newPasswordErrorInstructions;

    @FindBy(how = How.CSS, using = "div.errorMsg")
    private static WebElement passwordOldErrorMsg;

    @FindBy(how = How.XPATH, using = "//*[@id='dashboardSectionScreening']/div[1]/h2")
    private static WebElement screeningLaunchHeader;

    @FindBy(how = How.ID, using="L10nLocale")
    private static WebElement localeDropdown;


    @FindBy(how = How.ID, using="tabs")
    private static WebElement dashboardTabs;

    @FindBy(how = How.XPATH, using = ".//*[@id='TxnInfoLeftCol']//td[contains(text(),'User ID:')]/../td[2]")
    private static WebElement userid;

    @FindBy(how = How.LINK_TEXT, using = "Reset Password")
    private static WebElement resetPassword;

    @FindBy(how = How.XPATH, using = ".//*[@id='ShowStatusMessage']/strong")
    private static WebElement tempPassword;

    public static String clickResetAndGetTempPassword(){
        SeleniumTest.click(resetPassword);
        SeleniumTest.acceptAlert();
        return SeleniumTest.getText(tempPassword);
    }

    static {
        PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.Dashboard.DashboardPage.class);
    }

    /**
     * check whether my tasks is collapsed on dashboard
     * @return
     */
    public static boolean isMyTasksCollapsed() {
        return SeleniumTest.isElementVisible(hpmTasksShowButton);
    }

    /**
     * make a selection on the locale dropdown to update and change user's locale
     */
    public static void changeLocale(String value) {
        SeleniumTest.selectByValueFromDropDown(localeDropdown, value);
        waitForPageReady();
    }
    public static String selectedValueinLocaleDropDown() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(localeDropdown);
    }


    /**
     * get dashboard tab text
     */
    public static WebElement getDashboardTabs() {
        return dashboardTabs;
    }

    public static void waitforRecentActivityCollapsed() {
        SeleniumTest.waitForElementNotVisible(hpmActivityScrollContainer);
    }

    public static String getScreeningLaunchHeaderText() {
        return screeningLaunchHeader.getText();
    }

    public static String getScreeningLaunchHeaderExpectedText() {
        return "[{db75} Şƈřḗḗƞīƞɠ]";
    }

    public static String getLaunchTicketButtonLabels() {
        return Driver.getDriver().findElement(
                By.xpath("//div[@class='dashboardsection']/.//a[contains(@href,"
                         + " 'screening/search.php?')]")).getText() +
               Driver.getDriver().findElement(
                By.xpath("//div[@class='dashboardsection']/.//a[contains(@href,"
                         + " 'screening/ticket.php')]")).getText();
    }

    public static String getLaunchTicketButtonExpectedLabels() {
        return "[{9506} Ŀȧŭƞƈħ][{c751} Ŧīƈķḗŧ]";
    }

    public static void hideUserName() {
        BodyTextHelper.hideElement(usernameLink);
    }

    public static void hideDueDateContent() {
        BodyTextHelper.hideElement(dueDateContent);
    }

    public static void waitForPageReady() {
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static String getPasswordOldErrorMsg() {
        return passwordOldErrorMsg.getText();
    }

    /**
     * Returns the text of the password notification expiration message if present on the Dashboard, else returns null.
     * @return The text of the password notification expiration message if present on the Dashboard, else null.
     */
    public static String getpasswordExpirationNotificationMessage() {
        if (!isPasswordExpirationNotificationMessagePresent()) {
            return null;
        }

        return SeleniumTest.getText(passwordExpirationNotificationMessage);
    }

    /**
     * Returns the number of days appearing in the password expiration notification if present, else throws a runtime
     * exception.
     * @return The number of days appearing in the password expiration notification if present.
     * @exception RuntimeException Throws a runtime exception if the message is not present doesn't contains an integer.
     */
    public static int getpasswordExpirationNotificationMessageDays() {
        // return the first numeric value in the password expiration notification message
        String[] words = getpasswordExpirationNotificationMessage().split("\\s");
        for (String word : words)
        {
            try {
                Integer.parseInt(word);
            }
            catch (NumberFormatException e) {
                continue;
            }
            return Integer.parseInt(word);
        }
        throw new RuntimeException("No numeric value found in password expiration notification message");
    }

    /**
     * Error message that is displayed when a password update fails
     * @return
     */
    public static String getPasswordErrorMsg() {
        return newPasswordErrorInstructions.getText();
    }

    public static String getUserNameText() {
        return SeleniumTest.getText(usernameLink).trim();
    }

    /**
     * Intructions given when a password update fails
     * @return
     */
    public static String getPasswordErrorInstructions() {
        return reTypePasswordErrorInstructions.getText();
    }

    /**
     * Intructions given when a new password update fails
     * @return
     */
    public String getnewPasswordFieldErrorInstructions() {
        return newPasswordErrorInstructions.getText();
    }

    /**
     * Launch alacarte via ticketing.
     */
    public static void clickTicketShellAlacarte() {
        SeleniumTest.click(shellAlacarteTicket);
    }

    /**
     * Heading on the Change Password page
     * @return
     */
    public static String getChangePasswordH3(){
        String errorMsg = SeleniumTest.getText(changePasswordSuccessMsg);
        return errorMsg;
    }

    /**
     * Light weight verification we are on the change password page
     * @param title
     * @return
     */
    public static boolean changePasswordIsLoaded(String title){
        if(Driver.getDriver().getTitle().equalsIgnoreCase(title)) {
            return oldPasswordTextBoxIsDisplayed();
        }
        return false;
    }

    /**
     * Use this to determine if the old password text box is displayed
     * @return
     */
    public static boolean oldPasswordTextBoxIsDisplayed() {
        return oldPasswordTextBox.isDisplayed();
    }

    /**
     * Change the customer password
     * @param oldPassword
     * @param newPassword
     */
    public static void changePassword(String oldPassword, String newPassword) {
        SeleniumTest.clearAndSetText(oldPasswordTextBox, oldPassword);
        SeleniumTest.clearAndSetText(newPasswordTextBox, newPassword);
        SeleniumTest.clearAndSetText(confirmNewPasswordTextBox, newPassword);
        SeleniumTest.click(changePasswordBtn);
    }

    /**
     * Change the customer password
     * @param oldPassword
     * @param newPassword1
     * @param newPassword2
     */
    public static void changePassword(String oldPassword, String newPassword1, String
            newPassword2) {
        SeleniumTest.clearAndSetText(oldPasswordTextBox, oldPassword);
        SeleniumTest.clearAndSetText(newPasswordTextBox, newPassword1);
        SeleniumTest.clearAndSetText(confirmNewPasswordTextBox, newPassword2);
        SeleniumTest.click(changePasswordBtn);
    }

    //End password section

    /**
     * Access the Quick Launch drop down on the right side bar
     */
    public static void clickQuickLaunchDropDown() {
        SeleniumTest.click(quickLaunchDropDown);
    }

    public static boolean isQuickLaunchPresent() {
        return SeleniumTest.isElementPresent(quickLaunchDropDown);
    }

    /**
     * click launch onboarding from the quick lauch drop down.
     */
    public static void quickLaunchOnboarding() {
        clickQuickLaunchDropDown();
        SeleniumTest.click(quickLaunchOnboarding);
    }

    /**
     * Override method to automate the process of getting to the dashboard page with a specific user-id
     * @param accountType The account type to be signed in under
     * @return A new dashboard page object
     */
    public static DashboardPage navigateTo(AccountType accountType, String userName, String password) {
        String urlToNavigateTo = "";
        switch(accountType) {
            case ADMIN_ACCOUNT:
                urlToNavigateTo = URL.getURL(Site.ADMIN_CONSOLE);
                break;
            default:
                urlToNavigateTo = URL.getURL(Site.CUSTOMER_DASHBOARD);
                break;
        }
        CustomerLoginPage page = CustomerLoginPage.navigateTo(urlToNavigateTo);
        page.signInAs(userName, password, accountType);
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Static method to navigate to the user dashboard either directly or as proxy with an
     * override User Id
     * @param userId Optional userId to proxy
     * @return A new dashboard page object
     */
    public static DashboardPage navigateTo(int... userId) {
        int overrideUserId = userId.length > 0 ? userId[0] : 0;
        String dashboardUrl = DASHBOARD_URL_PATH;
        if (overrideUserId > 0) {
            dashboardUrl += "?OverrideUserID=" + overrideUserId;
        }
        // warning - This next line chops the "admin" out of the URL
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + dashboardUrl);
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Static method to navigate admin to the user dashboard as proxy with an
     * override User Id
     * @param userId Optional userId to proxy
     * @return A new dashboard page object
     */
    public static DashboardPage navigateAdminTo(int... userId) {
        int overrideUserId = userId.length > 0 ? userId[0] : 0;
        String dashboardUrl = DASHBOARD_URL_PATH;
        if (overrideUserId > 0) {
            dashboardUrl += "?OverrideUserID=" + overrideUserId;
        }
        Driver.getDriver().get(URL.getURL(Site.ADMIN_CONSOLE) + dashboardUrl);
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Signs out of the Customer Dashboard
     * @return
     */
    public static CustomerLoginPage signOut() {
        SeleniumTest.waitMs(3000);
        SeleniumTest.waitForElementToBeClickable(usernameLink);
        SeleniumTest.click(usernameLink);
        SeleniumTest.waitForElementToBeClickable(signOutLink);
        SeleniumTest.click(signOutLink);
        return PageFactory.initElements(Driver.getDriver(), CustomerLoginPage.class);
    }

    /**
     * Clicks the "+" button for the specified product listing in the Custom Packages section thereby showing its
     * product details.
     * @param uberFormID The id of the product that is to be interacted with
     */
    public void showProductDetailsUsingButtonForCustomPackages(String uberFormID) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath(plusMinusButtonFrontHalf + uberFormID
                + plusButtonBackHalf)));
    }

    /**
     * Clicks the "-" button for the specified product listing in the Custom Packages section thereby hiding its
     * product details.
     * @param uberFormID The id of the product that is to be interacted with
     */
    public void hideProductDetailsUsingButtonForCustomPackages(String uberFormID) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath(plusMinusButtonFrontHalf + uberFormID
                + minusButtonBackHalf)));
    }

    public static boolean isAvailableProductsVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(availableProductsLocator);
    }

    public static void clickAvailableProducts() {
        final int MAX_ATTEMPT_COUNT = 3;

        for (int attempt = 1; attempt <= MAX_ATTEMPT_COUNT; ++attempt) {
            try {
                WaitUntil.waitUntil("Available products button",
                        ExpectedConditions.elementToBeClickable(availableProductsLocator)).click();
                // If still here we have successfully clicked on the Available Products Launch button ..
                break;
            } catch (NoSuchElementException nse) {
                logger.info("The availableProductsLocator \"{}\" Launch button appears to have flickered on attempt #{}",
                        availableProductsLocator, attempt);

                if (MAX_ATTEMPT_COUNT <= attempt) {
                    logger.warn("Absolutely failed to click on Available Products Launch button: {}", nse.getMessage());
                    nse.printStackTrace();
                    throw nse;
                }
            }
        }
        waitForPageReady();
    }

    /**
     * Clicks the text for the specified product listing in the Custom Packages section which toggles the product
     * details between shown and hidden.
     * @param uberFormID The id of the product that is to be interacted with
     */
    public void toggleProductDetailsUsingTextForCustomPackages(String uberFormID) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath(plusMinusButtonFrontHalf + uberFormID
                + plusMinusButtonBackHalf)));
    }

    /**
     * Clicks the ticket button for the specified product listing in the Custom Packages section thereby opening
     * the form to create a ticket for the uber-form
     * @param uberFormID The id of the product that is to be interacted with
     * @return The ticket page that the specified product listing corresponds to
     */
    public static TicketForm ticketProductListingForCustomPackages(String uberFormID) {
        SeleniumTest.click(By.xpath(ticketButtonFrontHalf + uberFormID + ticketButtonBackHalf));
        return PageFactory.initElements(Driver.getDriver(), TicketForm.class);
    }

    /**
     * Clicks the launch button for the specified product listing in the Custom Packages section thereby launching the
     * corresponding uber form.
     * @param uberFormID The id of the product that is to be interacted with
     * @return The uber form page that the specified product listing corresponds to
     */
    public static ScreeningLaunchPage launchProductListingForCustomPackages(String uberFormID, String num) {
        return launchPackage(By.id("btncustom_" + uberFormID + "_" + num));
    }

    public static ScreeningLaunchPage launchProductListingForCustomPackages(int uberFormID, String
            num) {
        return launchPackage(By.id("btncustom_" + uberFormID + "_" + num));
    }

    /**
     * Clicks the launch button for the specified product listing in the Custom Packages section thereby launching the
     * corresponding uber form.
     * @param uberFormId The ID of the product that is to be interacted with (either String or numeric value)
     * @return
     */
    public static ScreeningLaunchPage launchProductListingForCustomPackages(Object uberFormId) {
        return launchProductListingForCustomPackages(uberFormId.toString(), "2");
    }

    public static boolean canLaunch(int uberFormID) {
        WebElement launchButton =
                Driver.getDriver().findElement(By.xpath("//button[starts-with(@id, 'btncustom_" + uberFormID + "_')]"));
        JavaScriptHelper.scrollElementIntoView(launchButton);
        return !launchButton.getAttribute("class").contains("buttoninactive");
    }

    public static boolean canTicket(int uberFormID) {
        WebElement ticketButton =
                Driver.getDriver().findElement(By.xpath("//button[starts-with(@id, 'btnticket_" + uberFormID + "_')]"));
        JavaScriptHelper.scrollElementIntoView(ticketButton);
        return !ticketButton.getAttribute("class").contains("buttoninactive");
    }

    /**
     * Clicks the launch button for the specified product listing in the Fast Lane Screening section thereby launching
     * the corresponding uber form.
     * @param packageId The id of the product that is to be interacted with
     * @return The uber form page that the specified product listing corresponds to
     */
    public static ScreeningLaunchPage launchProductListingForFastLanePackages(String packageId) {
        return launchPackage(By.id("btndistpackage_" + packageId + "_1"));
    }

    private static ScreeningLaunchPage launchPackage(By locator) {
        SeleniumTest.waitForElementVisible(locator, 30, 2);
        WebElement packageBtn = Driver.getDriver().findElement(locator);
        SeleniumTest.clickUntilElementAppears(packageBtn, ScreeningLaunchPage.lastNameBox);
        return PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
    }

    /**
     * Finds the Upcoming Due Dates Status
     * @param taskDescription Description of the task to locate
     * @return WebElement
     */
    public WebElement findUpcomingDueDatesStatus(final String taskDescription) {

        foundIt = false;
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(9, TimeUnit.SECONDS)
                .pollingEvery(3, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        try {
                            if(d.findElements(By.xpath("//div[contains(text(), '" + taskDescription
                                    + "')]/following-sibling::div[4]")).size() > 0) {
                                foundIt = true;
                                return true;
                            }
                            else {
                                return false;
                            }
                        }
                        catch (com.gargoylesoftware.htmlunit.ElementNotFoundException e) {
                            logger.debug("Could not find Upcoming Due Date Status for {}", taskDescription);
                            return false;
                        }
                    }
                });
        if(Driver.getBrowserType() == DriverType.FIREFOX) {
            // wait an arbitrary amount of time here to see if it fixes the firefox only issue that does not reproduce
            // anywhere outside the lab.
            SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 2);
        }
        if (foundIt) {
            return Driver
                    .getDriver().findElement(By.xpath("//div[contains(text(), '" + taskDescription
                            + "')]/following-sibling::div[4]"));
        } else {
            return null;
        }
    }

    /**
     * Finds the Upcoming Due Dates Status
     * @param taskDescription Description of the task to locate
     * @param reportID ApplicantID or ReportID
     * @return WebElement
     */
    public WebElement findUpcomingDueDatesStatus(final String taskDescription, final int reportID) {
        // no idea why this keeps failing
        // adding a wait for an additioanl 5 seconds to see if I can get this problem to stop happening in the lab.
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 2);
        foundIt = false;
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(15, TimeUnit.SECONDS)
                .pollingEvery(3, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        try {
                            if (d.findElements(By.xpath("//div[contains(text(), '" + taskDescription
                                    + "')]/following-sibling::div[4]")).size() > 0) {
                                foundIt = true;
                                return true;
                            }
                            else {
                                return false;
                            }
                        }
                        catch (com.gargoylesoftware.htmlunit.ElementNotFoundException e) {
                            logger.debug("Could not find Upcoming Due Date Status for {} at index {}",
                                    taskDescription, reportID);
                            return false;
                        }
                    }
                });
        if(foundIt)
            return Driver
                    .getDriver().findElement(By.xpath("//div[contains(text(), '" + taskDescription
                            + "')]/following-sibling::div/a[contains(@href,'" + reportID
                            + "')]/../preceding-sibling::div[2]"));
        else {
            return null;
        }
    }

    /**
     * Finds the Upcoming Due Dates Status
     * @param taskDescription Description of the task to locate
     * @param statusText Description of the status to be found
     * @return WebElement
     */
    public WebElement findUpcomingDueDatesStatus(String taskDescription, String statusText) {
        WebElement statusValue = Driver
                .getDriver().findElement(By.xpath("//div[contains(text(), '" + taskDescription
                        + "')]/following-sibling::div[contains(text(), '" + statusText + "')]"));
        if(statusText.equals(statusValue.getText())) {
            return statusValue;
        }
        return null;
    }

    /**
     * Determines whether the candidate has entries in the Upcoming Due Dates widget. It will continue to
     * click 'view more' until it finds the candidate in question or there are no more due dates to view
     * @param candidate
     * @return
     */
    public static boolean canSeeUpcomingDueDatesForCandidate(Candidate candidate) {
        String name = candidate.getLastName() + ", " + candidate.getFirstName() + " "
                + candidate.getMiddleName();
        logger.info("Looking for {}", name);
        String xpath = "//div[@id='HpmDatesScrollContent']//a[text()='" + name + "']";

        while (!SeleniumTest.isElementVisibleNoWaiting(By.xpath(xpath))) {
            logger.info("Can't find name, checking for view more");
            if (isUpcomingDueDatesViewMoreAvailable()) {
                logger.info("Click View More");
                clickViewMoreHpmDates();
            } else {
                // not present, can't click view more
                logger.info("Can't find view more or candidate");
                return false;
            }
        }
        logger.info("Found Candidate");
        return true;
    }

    /**
     * Returns true if the Password Expiration Notification message is present on the Dashboard.
     * @return true if the Password Expiration Notification message is present on the Dashboard.
     */
    public static boolean isPasswordExpirationNotificationMessagePresent() {
        return SeleniumTest.isElementVisibleNoWaiting(passwordExpirationNotificationMessageLocator);
    }

    /**
     * Returns whether or not the 'view more' button is available for the Upcoming Due Dates widget
     * @return
     */
    public static boolean isUpcomingDueDatesViewMoreAvailable() {
        WebElement viewMore = getLastViewMore();
        if(viewMore != null) {
            return SeleniumTest.isElementVisible(getLastViewMore());
        } else {
            return false;
        }
    }

    private static WebElement getLastViewMore() {
        final By locator = By.xpath("//div[@id=\"HpmDates\"]/.//a[contains(@onclick,\"widget=HpmDates\")]");
        if (!SeleniumTest.isElementVisibleNoWaiting(locator)) {
            return null;
        }
        List<WebElement> viewMores = Driver.getDriver().findElements(locator);
        if(viewMores.isEmpty()){
            return null;
        }
        return viewMores.get(viewMores.size() - 1);
    }

    public static void clickHpmActivityHideButton() {
        SeleniumTest.click(hpmActivityHideButton);
    }

    public static void clickHpmTasksHideButton() {
        SeleniumTest.click(hpmTasksHideButton);
    }

    public static void waitforMyTaskCollapsed() {
        SeleniumTest.waitForElementNotVisible(hpmTasksScrollContainer);
    }

    public static void clickHpmTasksShowButton() {
        SeleniumTest.click(hpmTasksShowButton);
    }

    public static void clickHpmDatesHideButton() {
        SeleniumTest.click(hpmDatesHideButton);
        SeleniumTest.waitForElementVisible(hpmDatesShowButton);
    }

    public static void clickHpmDatesShowButton() {
        SeleniumTest.click(hpmDatesShowButton);
        SeleniumTest.waitForElementVisible(hpmDatesHideButton);
    }

    public static boolean isHpmDatesHideButtonVisible() {
        return SeleniumTest.isElementVisible(hpmDatesHideButton);
    }

    public static boolean isHpmDatesShowButtonVisible() {
        return SeleniumTest.isElementVisible(hpmDatesShowButton);
    }

    /**
     * clicks viewMore for HPM
     * assumed the element actually exists
     */
    public static void clickViewMoreHpmDates() {
        WebElement viewMore = getLastViewMore();
        if(viewMore != null){
            SeleniumTest.click(viewMore);
            waitForPageReady();
            PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
        } else{
            throw new NullPointerException("View more was not present on the page");
        }
    }

    /**
     * Wait for My Task panel loading completed
     */
    public static void waitForMyTaskContentLoadingCompleted() {
        SeleniumTest.waitForPageLoadToComplete();
        WaitUntil.waitUntil(60, 3, () -> !Driver.getDriver().findElements(By.id
                ("HpmTasksContentLoading")).get(0)
                .isDisplayed(), NoSuchElementException.class);
    }

    /**
     * Find appropriate Recent Activity Status Web Element
     * @param title The title of the Row to find
     * @param reportID ApplicantID or ReportID
     * @return the Status column Web Element
     */
    public static WebElement findRecentActivityStatus(String title, Integer reportID) {
        SeleniumTest.waitForPageLoadToComplete();
        WaitUntil.waitUntil(60, 3, () -> !Driver.getDriver().findElements(By.id
                ("HpmActivityContentLoading")).get(0)
                   .isDisplayed(), NoSuchElementException.class);
        // Using a polling waiter to determine if the widgetRows have finished populating
        // before attempting to locate specific rows within Recent Activity Window
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(15, TimeUnit.SECONDS)
                .pollingEvery(3, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {return d.findElements(By.className("widgetRow")).size() > 5;}
                });
        try {
            // Doubling the wait time - does not break at any point on desktop machine
            // Apparently only fails once in a while in the lab using arnie@tw.com
            // beyond scalable user.
            WebElement recentActivity = SeleniumTest.waitForElementToBeClickable
                    (hpmAcitivtyScrollContainer, 90);
            // Find all the rows in the container
            List<WebElement> widgetRows = recentActivity.findElements(widgetRowLocator);
            WebElement singleRow = null;
            // Loop through each row
            for (WebElement we : widgetRows) {
                try {
                    singleRow = we.findElement(By.xpath(".//div/a[contains(@href, '" + reportID
                            + "')]/../preceding-sibling::div[4]"));
                    break;
                }
                catch(NoSuchElementException nse) {
                    // we don't care
                }
            }
            return singleRow;
        }
        catch(ElementNotVisibleException env)
        {
            logger.debug(env.getMessage());
        }
        return null;
    }

    /**
     * Find appropriate Recent Activity Status Web Element
     * @param title The title of the Row to find
     * @return the Status column Web Element
     */
    public static WebElement findRecentCancelledActivityStatus(String title) {
        SeleniumTest.waitForPageLoadToComplete();
        // Using a polling waiter to determine if the widgetRows have finished populating
        // before attempting to locate specific rows within Recent Activity Window
        WaitUntil.waitUntil(60, 3, () -> !Driver.getDriver().findElements(By.id
                ("HpmActivityContentLoading")).get(0)
                                                .isDisplayed(), NoSuchElementException.class);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(15, TimeUnit.SECONDS)
                .pollingEvery(3, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {return d.findElements(By.className("widgetRow")).size() > 5;}
                });
        try {
            WebElement recentActivity = SeleniumTest.waitForElementToBeClickable(hpmAcitivtyScrollContainer, 30);
            // Find all the rows in the container
            List<WebElement> widgetRows = recentActivity.findElements(widgetRowLocator);
            WebElement singleRow = null;
            // Loop through each row
            for (WebElement we : widgetRows) {
                try {
                    WebElement rowDiv = we.findElement(By.xpath(".//div[contains(text(), '" + title + "')]/.."));
                    singleRow = rowDiv.findElement(By.xpath(".//div[contains(text(), 'Canceled')]"));
                    break;
                }
                catch(NoSuchElementException nse) {
                    // we don't care
                }
            }
            return singleRow;
        }
        catch(ElementNotVisibleException env)
        {
            logger.debug(env.getMessage());
        }
        return null;
    }

    /**
     * Returns whether or not the 'New Candidate' option is available in teh quicklaunch
     * @return
     */
    public static boolean candidateCreationIsAvailable() {
        return SeleniumTest.isElementPresent(By.id("divQuickLaunchNewCandidate"));
    }

    /**
     * Verifies that the onboarding quick launch entry is available
     * @return
     */
    public static boolean quickLaunchOnboardingAvailable() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("divQuickLaunchOnboard"));
    }

    /**
     * Verifies that the screening quick launch entry is available
     * @return
     */
    public static boolean quickLaunchScreeningAvailable() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("divQuickLaunchScreen"));
    }

    /**
     *  Click Candidate View
     */
    public static void clickCandidateView(){
        SeleniumTest.click(candidateView);
    }

    /**
     *  Click Add Screening
     */
    public static void clickAddScreening(){
        SeleniumTest.click(addScreening);
    }

    /**
     * Verifies that the screening dashboard section is available
     * @return
     */
    public static boolean dashboardScreeningSectionAvailable() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("dashboardSectionScreening"));
    }

    /**
     * verifies that the onboarding dashboard section is available
     * @return
     */
    public static boolean dashboardOnboardingSectionAvailable() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("dashboardSectionScreening"));
    }

    /**
     * Navigates to the Candidate details page
     * @param candidate
     * @return
     */
    public static CandidateDetailsPage navigateToCandidateDetails(Candidate candidate) {
        return navigateToCandidateDetails(Integer.toString(candidate.getCandidateID()));
    }

    public static CandidateDetailsPage navigateToCandidateDetailsByName(String firstName, String middleName,
            String lastName) {
        return Sidebar.submitSearch(lastName).clickCandidateDetails(firstName, middleName, lastName);
    }

    public static CandidateDetailsPage navigateToCandidateDetails(String candidateID) {
        return Sidebar.submitSearch(candidateID).clickCandidateDetails(candidateID);
    }

    public static OnboardingTasksPage clickMyTasksLink() {
        SeleniumTest.waitForElementToBeClickable(myTasksLink);
        SeleniumTest.click(myTasksLink);
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    public static abstract class DashboardWidgets {
        /**
         * Returns whether or not any matching text is found within the container
         * @param element The container to search
         * @param content The text to search for
         * @return Whether or not the text was present inside the container
         */
        protected static boolean contains(WebElement element, String content) {
            WaitUntil.waitUntil(
                    () -> element.isDisplayed(),
                    NoSuchElementException.class);
            try {
                element.findElement(
                        By.xpath(".//*[contains(text(), '" + content + "')]"));
                return true;
            } catch (NoSuchElementException nse) {
                return false;
            }
        }
    }

    public static class RecentActivity extends DashboardWidgets {
        @FindBy(how = How.ID, using = "HpmActivityScrollContent")
        private static WebElement recentActivityContent;

        @FindBy(how = How.ID, using = "HpmActivity")
        private static WebElement recentActivityContainer;

        @FindBy(how = How.ID, using = "HpmActivityHideButton")
        private static WebElement hpmActivityHideButton;

        @FindBy(how = How.ID, using = "HpmActivityShowButton")
        private static WebElement hpmActivityShowButton;

        static {
            PageFactory.initElements(Driver.getDriver(), RecentActivity.class);
        }

        /**
         * Whether or not an element exists with the given text content
         * @param content text content to look for
         * @return Bolean whether or not the content has been found.
         */
        public static boolean contains(String content) {
            return contains(recentActivityContent, content);
        }

        public static String getText(int row) {
            List<WebElement> widgetRows = recentActivityContainer.findElements(By.className("widgetRow"));
            return widgetRows.get(row).getText();
        }

        public static WebElement getContainer() {
            return recentActivityContainer;
        }

        public static void clickHpmActivityHideButton() {
            SeleniumTest.click(hpmActivityHideButton);
        }

        public static void clickHpmActivityShowButton() {
            SeleniumTest.click(hpmActivityShowButton);
        }

        public static boolean isHpmActivityHideButtonVisible() {
            return SeleniumTest.isElementVisible(hpmActivityHideButton);
        }

        public static void hideVariableElements() {
            List<WebElement> widgetRows = recentActivityContent.findElements(By.className("widgetRow"));
            for(WebElement widgetRow : widgetRows) {
                List<WebElement> widgetRowItems = widgetRow.findElements(By.className("widgetRowItem"));
                // only hide data from database
                BodyTextHelper.hideElement(widgetRowItems.get(0));
                BodyTextHelper.hideElement(widgetRowItems.get(1));
                BodyTextHelper.hideElement(widgetRowItems.get(2));
                BodyTextHelper.hideElement(widgetRowItems.get(3));
                BodyTextHelper.hideElement(widgetRowItems.get(4));
            }
        }
    }

    public static class MyTasks extends DashboardWidgets {
        @FindBy(how = How.ID, using = "HpmTasksScrollContent")
        private static WebElement myTasksScrollContent;

        @FindBy(how = How.ID, using = "HpmTasks")
        private static WebElement myTasksContainer;

        @FindBy(how = How.ID, using = "HpmTasksHideButton")
        private static WebElement hpmTasksHideButton;
        static {
            PageFactory.initElements(Driver.getDriver(), MyTasks.class);
        }

        /**
         * Whether or not an element exists with the given text content
         * @param content text content to look for
         * @return Boolean whether or not the content has been found.
         */
        public static boolean contains(String content) {
            return contains(myTasksScrollContent, content);
        }

        public static String getText(int row) {
            List<WebElement> widgetRows = myTasksContainer.findElements(By.className("widgetRow"));
            return widgetRows.get(row).getText();
        }

        public static WebElement getContainer() {
            return myTasksContainer;
        }

        public static void clickHpmTasksHideButton() {
            if (isHpmTasksHideButtonVisible()) {
                SeleniumTest.click(hpmTasksHideButton);
            }
        }

        public static boolean isHpmTasksHideButtonVisible() {
            return SeleniumTest.isElementVisible(hpmTasksHideButton);
        }

        public static void hideVariableElements() {
            List<WebElement> widgetRows = myTasksContainer.findElements(By.className("widgetRow"));
            for(WebElement widgetRow : widgetRows) {
                List<WebElement> widgetRowItems = widgetRow.findElements(By.className("widgetRowItem"));
                // only hide data from database
                BodyTextHelper.hideElement(widgetRowItems.get(0));
                BodyTextHelper.hideElement(widgetRowItems.get(3));
                BodyTextHelper.hideElement(widgetRowItems.get(4));
            }
        }
    }

    public static class UpcomingDueDates extends DashboardWidgets {

        @FindBy(how = How.ID, using = "HpmDates")
        private static WebElement upcomingDueDatesScrollContainer;

        static {
            PageFactory.initElements(Driver.getDriver(), UpcomingDueDates.class);
        }

        /**
         * Whether or not an element exists with the given text content
         * @param content the content to look for
         * @return Boolean whether or not the content has been found
         */
        public static boolean contains(String content) {
            return contains(upcomingDueDatesScrollContainer, content);
        }

        public static WebElement getUpcomingDueDatesScrollContainer() {
            return upcomingDueDatesScrollContainer;
        }

        /**
         * Hide elements populated with data from database.
         */
        public static void hideDBData() {
            BodyTextHelper.hideElement(upcomingDueDatesScrollContainer.findElement(By.id("HpmDatesCollapsibleArea")));
            BodyTextHelper.hideElement(upcomingDueDatesScrollContainer.findElement(By.id("HpmDatesSummaryContainer")));
        }

        public static String getCustomerUserID(){
            return SeleniumTest.getText(userid);
        }
    }

    /**
     * Search for a candidate in the Customer dashboard
     *
     * @param searchText
     */
    public static void findACandidate(String searchText) {
        candidateFindTextbox.sendKeys(searchText);
        candidateSearchButton.click();
        SeleniumTest.waitForPageLoad();
    }

    /**
     * Clicks on a given candidate
     *
     * @param candidate
     */
    public static void clickOnCandidate(Candidate candidate) {
        By candidateLink = By.xpath("//a[@href='/screening/records.php?CandidateID=" + candidate.getCandidateID() + "']");
        SeleniumTest.click(candidateLink);
        SeleniumTest.waitForPageLoad();
    }

    public CandidateDetailsPage navigateToCandidateViewOfReport(String candidateID, String reportId)
    {
        Driver.getDriver().get(URL.getURL(CUSTOMER_DASHBOARD) + "/screening/report.php?CandidateID="
                + candidateID + "&ApplicantID="+reportId);
        return PageFactory.initElements(Driver.getDriver(), CandidateDetailsPage.class);
    }

    public void clickHelpandResoucesLink(){
        SeleniumTest.waitForElementVisible(lnkHelpAndResources);
        JavaScriptHelper.click(lnkHelpAndResources);

    }
}
