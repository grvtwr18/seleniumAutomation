package Sites.TalentWiseDashboard.Dashboard.adminTools.userSettings.roles;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by MNam on 2/15/2018.
 */
public class CreateRolePage {
    @FindBy(how = How.ID, using = "roleName")
    private WebElement roleName;

    @FindBy(how = How.ID, using = "roleDescription")
    private WebElement roleDescription;

    @FindBy(how = How.XPATH, using = "//form[@id='roleForm']/div/div[2]/div/div[2]/div/label")
    private WebElement  roleDescriptionlabel;

    private final By createButtonLocator = By.xpath("//*[@id=\"roleForm\"]/button[1]");

    @FindBy(how = How.XPATH, using = "//*[@id=\"roleForm\"]/button[2]")
    private WebElement  cancelButton;

    @FindBy(how = How.ID, using = "roleNameCounter")
    private WebElement  nameCounter;

    @FindBy(how = How.ID, using = "roleDescriptionCounter")
    private WebElement  descCounter;

    @FindBy(how = How.XPATH, using = "//*[@id=\"page-wrapper\"]/div[1]/a")
    private WebElement  backToRolesLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"page-wrapper\"]/div[1]/div/h1")
    private WebElement  header;

    @FindBy(how = How.XPATH, using = "//*[@id=\"roleForm\"]/div/div[1]/h2")
    private WebElement  subheader;

    public  CreateRolePage() {
        initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public  void typeRoleName(String name) {
        SeleniumTest.clearAndSetText(roleName, name);
    }

    public void typeRoleDescription(String desc) {
        SeleniumTest.clearAndSetText(roleDescription, desc);
    }

    public EditRolesPage clickCreateButtonUntilDisappears() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(createButtonLocator);
        return new EditRolesPage();
    }

    public EditRolesPage clickCreateButton() {
        SeleniumTest.click(createButtonLocator);
        return new EditRolesPage();
    }

    public RolesPage clickCancel() {
        SeleniumTest.click(cancelButton);
        return new RolesPage();
    }

    public String getNameCounter() {
        return SeleniumTest.getText(nameCounter);
    }

    public String getDescriptionCounter() {
        return SeleniumTest.getText(descCounter);
    }

    public String getHeader() {
        return SeleniumTest.getText(header);
    }

    public String getSubHeader() {
        return SeleniumTest.getText(subheader);
    }

    public String remainingNameChars() {
        return SeleniumTest.getText(nameCounter);
    }

    public String remainingDescriptionChars() {
        return SeleniumTest.getText(descCounter);
    }
}
