package Sites.TalentWiseDashboard.Dashboard.adminTools.userSettings.roles;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by MNam on 3/1/2018.
 */
public class AddUserToRoleModal {
    @FindBy(how = How.ID, using = "addUsersToRole")
    private WebElement addUserButton;

    @FindBy(how = How.XPATH, using = "//*[@id='roleDetailsForm']/button[2]")
    private WebElement cancelButton;

    private String xpathAddUsersToRole = "//*[@id='AssignUserToRole']/div[2]/table/tbody/tr";

    public  AddUserToRoleModal() {
        initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public boolean isAddUserButtonEnabled() {
        return SeleniumTest.isElementEnabled(addUserButton);
    }

    public void checkUser() {
        SeleniumTest.click(By.xpath(xpathAddUsersToRole + "/td[1]/label"));
    }

    public String getUsersName() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAddUsersToRole + "/td[2]"));
    }

    public String getUsersEmail() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAddUsersToRole + "/td[3]"));
    }

    public String getUsersRole() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAddUsersToRole + "/td[4]"));
    }

    public String getAddUsersEmptyResultText() {
        return SeleniumTest.getTextByLocator(By.xpath(xpathAddUsersToRole + "/td"));
    }

    public EditRolesPage clickCancel() {
        SeleniumTest.click(cancelButton);
        return new EditRolesPage();
    }

    public EditRolesPage clickAddUserButton() {
        SeleniumTest.click(addUserButton);
        return new EditRolesPage();
    }
}
