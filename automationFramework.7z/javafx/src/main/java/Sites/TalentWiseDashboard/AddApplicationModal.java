package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.ProductFormPages.ProductFormPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 10/15/2015.
 */
public class AddApplicationModal extends AddPackageModal {

    static {
        PageFactory.initElements(Driver.getDriver(), AddApplicationModal.class);
    }

    /**
     * Clicks the onboarding uberform by name
     * @param uberFormName the name of the uberform to launch
     * @param returnedClass the Page Factory class to be returned
     * @return
     */
    public ProductFormPages clickApplicationUberForm(String uberFormName, Class<? extends ProductFormPages> returnedClass) {
        WebElement applicationUberForm = Driver.getDriver().findElement(By.xpath("//a[contains(text(), '" + uberFormName + "')]/../../following-sibling::div/div/a"));
        SeleniumTest.waitForElementVisible(applicationUberForm);
        applicationUberForm.click();
        // explicit wait to ensure whatever page is supposed to open has the time to do so before returning
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 5);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
