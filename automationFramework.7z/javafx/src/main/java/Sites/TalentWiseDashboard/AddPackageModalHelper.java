package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by wogden on 9/26/2016.
 * TODO: probably would be more accurate as AddUberformModalHelper.
 */
public class AddPackageModalHelper {

    protected static final Logger staticlogger = LoggerFactory.getLogger("AddPackagesModalHelper");

    public static boolean isPackageListed(String uberFormName) {
        try {
            WebElement launchButton = Driver.getDriver().findElement(By.xpath(
                    "//a[contains(text(), '" + uberFormName + "')]/../../following-sibling::div/div/a"));
        } catch (NoSuchElementException e) {
            return false;
        }
        return true;
    }

    public static Integer countOfPackages() {
        List<WebElement> launchButtons = Driver.getDriver().findElements(By.className("dashboardproductlisting"));
        staticlogger.info("Found {} Launch Buttons", launchButtons.size());
        int visibleButtons = (int)launchButtons.stream() // convert to stream
                .filter(x -> x.isDisplayed())  // only select Elements that are displayed
                .count(); // Count how many were found

        staticlogger.info("Found {} packages", visibleButtons);
        return visibleButtons;
    }

    /**
     * Checks if a given uberform ID's Launch Button is absent, returning false if present. Failures are collected, but
     * don't stop the test.
     *
     * @param uberFormId the uberform ID to look for
     * @return true when uberform launch button is not present, false if it is
     */
    public static boolean verifyUberformIsNotPresentById(int uberFormId) {
        return SeleniumTest.verifyElementNotPresent(By.id("btncustom_" + uberFormId + "_1"));
    }
}
