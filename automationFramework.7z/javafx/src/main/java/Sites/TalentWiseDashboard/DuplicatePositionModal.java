package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 3/30/17.
 */
public class DuplicatePositionModal {

    @FindBy(how = How.ID, using = "positionName")
    private static WebElement newPositionNameTextBox;

    @FindBy(how = How.XPATH, using = "//input[contains(@onclick,'DuplicatePositionSave')]")
    private static WebElement confirmAndContinueButton;

    static {
        PageFactory.initElements(Driver.getDriver(), DuplicatePositionModal.class);
    }
    public static void setNewPositionName(String newPositionName) {
        SeleniumTest.clearAndSetText(newPositionNameTextBox, newPositionName);
    }

    public static void clickConfirmAndContinue() {
        confirmAndContinueButton.click();
        SeleniumTest.waitForPageLoadToComplete();
    }
}
