package Sites.TalentWiseDashboard;

/**
 * Created by abrackett on 6/27/16.
 */
public class PrintPage extends CustomerDashboardPages {

    public PrintPage() {
        //TODO:  Use a known locator to verify the page is rendered
    }

}
