package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import Utility.Onboarding.OnboardingUtility;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by abrackett on 3/29/17.
 */
public class PositionModal extends OnboardingUtility{

    @FindBy(how = How.ID, using = "qpositionname")
    private static WebElement positionNameTextBox;

    @FindBy(how = How.ID, using = "qworkflowtemplate")
    private static WebElement hiringProcessDropDown;

    @FindBy(how = How.ID, using = "qsubpath")
    private static WebElement candidatePortalDropDown;

    @FindBy(how = How.ID, using = "qlocation")
    private static WebElement locationDropDown;

    @FindBy(how = How.ID, using = "qNotificationList")
    private static WebElement notificationListTextBox;

    @FindBy(how = How.XPATH, using = "//input[@type='button'][contains(@class,'buttoncancel')]")
    private static WebElement cancelButton;

    @FindBy(how = How.XPATH, using = "//input[contains(@onclick, 'SavePosition')]")
    private static WebElement createPositionButton;

    protected static final Logger staticLogger = LoggerFactory.getLogger(PositionModal.class);

    static {
        PageFactory.initElements(Driver.getDriver(), PositionModal.class);
    }

    public static void setPositionName(String name) {
        SeleniumTest.clearAndSetText(positionNameTextBox, name);
        staticLogger.info("Set position name to {}", name);
    }

    public static void selectHiringProcess(String hiringProcess) {
        SeleniumTest.selectByVisibleTextFromDropDown(hiringProcessDropDown, hiringProcess);
        staticLogger.info("Select Hiring Process of {}", hiringProcess);
    }

    public static void selectCandidatePortal(String name) {
        SeleniumTest.selectByVisibleTextFromDropDown(hiringProcessDropDown, name);
    }

    public static void selectLocation(String location) {
        SeleniumTest.selectByVisibleTextFromDropDown(locationDropDown, location);
    }

    public static void setNotificationList(String notificationList) {
        SeleniumTest.clearAndSetText(notificationListTextBox, notificationList);
    }

    public static void clickCancel() {
        cancelButton.click();
    }

    public static void clickCreateOrSavePosition() {
        createPositionButton.click();
    }

    public static String getPositionName() {
        return positionNameTextBox.getAttribute("value");
    }

    public static String getSelectedHiringProcess() {
        Select dropDown = new Select(hiringProcessDropDown);
        return dropDown.getFirstSelectedOption().getText();
    }

    public static String attachPositionToWorkFlow(String workFlowName){
        QuickLaunchPage.clickNewPosition();
        String unixTime = Long.toString(System.currentTimeMillis() / 1000L);
        String postionName = "TestPosition" + unixTime;
        PositionModal.setPositionName(postionName);
        staticLogger.info("Add Workflow to position.");
        PositionModal.selectHiringProcess(workFlowName);
        staticLogger.info("Save Position.");
        PositionModal.clickCreateOrSavePosition();
        return postionName;
    }

    public static void attachPositionToWorkFlow(String positionName,String workFlowName){
        QuickLaunchPage.clickNewPosition();
        PositionModal.setPositionName(positionName);
        staticLogger.info("Add Workflow to position.");
        PositionModal.selectHiringProcess(workFlowName);
        staticLogger.info("Save Position.");
        PositionModal.clickCreateOrSavePosition();
    }
}
