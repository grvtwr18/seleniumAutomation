package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchPage;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * Page object that represents the window the pops up when the "Quick Launch" button is pressed on the sidebar of the TalentWise Dashboard website.
 * @author eelefson
 */
public class QuickLaunchPage {

	@FindBy (how = How.ID, using = "quickLaunchNormal")
	private static WebElement quickLaunchButton;

	@FindBy(how = How.ID, using = "divQuickLaunchOnboard")
	private static WebElement launchOnboardingButton;

    @FindBy(how = How.ID, using = "divQuickLaunchNewRequisition")
    private static WebElement newPositionElement;

	@FindBy(how = How.ID, using = "divQuickLaunchScreen")
	private static WebElement quickLaunchScreening;


	static {
		PageFactory.initElements(Driver.getDriver(), QuickLaunchPage.class);
	}

	/**
	 * Constructs a new quick launch page object.
	 */
	public QuickLaunchPage() {
		SeleniumTest.waitForJQueryAjaxDone();
	}

	public static void clickQuickLaunchbutton(){
		SeleniumTest.waitForElementToBeClickable(quickLaunchButton);
		quickLaunchButton.click();
	}

	public static void clickLaunchScreeningLink() {
		SeleniumTest.waitForElementToBeClickable(quickLaunchScreening);
		quickLaunchScreening.click();
	}

	public static AddOnboardingModal clickLaunchOnboardingLink() {
		SeleniumTest.waitForElementToBeClickable(launchOnboardingButton);
        launchOnboardingButton.click();
        return PageFactory.initElements(Driver.getDriver(), AddOnboardingModal.class);
	}

    /**
     * Clicks QuickLaunch and cancels the operation
     * @return
     */
    public static boolean clickLaunchOnboardingToTestFocus() {
        waitForModalMaskToGoAway();
        SeleniumTest.waitForElementToBeClickable(launchOnboardingButton);
        launchOnboardingButton.click();
        WaitUntil.waitUntil(() -> ((EventFiringWebDriver)Driver.getDriver())
                .getWrappedDriver().findElement(
                        By.xpath("//*[contains(@onmouseover,'dashboardproductlisting')]"))
                .isDisplayed(), NoSuchElementException.class);

        boolean appropriateFocus = false;
        try {
            WaitUntil.waitUntil(() -> Driver.getDriver().switchTo().activeElement()
                                            .getAttribute("onmouseover")
                                            .contains("dashboardproductlisting"),
                                NullPointerException.class);
            appropriateFocus = true;
        } catch (TimeoutException npe) {
            appropriateFocus = false;
        }
        Driver.getDriver().switchTo().activeElement().sendKeys(Keys.ESCAPE);
        return appropriateFocus;
    }

	public static void clickNewPosition(){
		SeleniumTest.waitForElementToBeClickable(newPositionElement);
        newPositionElement.click();;
	}

    /**
     * Clicks QuickLaunch and cancels the operation
     * @return
     */
    public static boolean clickNewPositionToTestFocus() {
        waitForModalMaskToGoAway();
        clickNewPosition();
        WaitUntil.waitUntil(() -> ((EventFiringWebDriver)Driver.getDriver())
                .getWrappedDriver().findElement(By.id("qpositionname")).isDisplayed(),
                            NoSuchElementException.class);
        boolean appropriateFocus = false;
        try {
            appropriateFocus = Driver.getDriver().switchTo().activeElement()
                                     .getAttribute("id").contains("qpositionname");
        } catch (NullPointerException npe) {
            appropriateFocus = false;
        }
        Driver.getDriver().switchTo().activeElement().sendKeys(Keys.ESCAPE);
        return appropriateFocus;
    }

	/**
	 * Clicks new Candidate on the Quick Launch Button
	 * @return NewCandidateModal class
	 */
	public static NewCandidateModal clickNewCandidate(){
		WebElement newCandidateLink = Driver.getDriver().findElement(By.id("divQuickLaunchNewCandidate"));
		newCandidateLink.click();
		return PageFactory.initElements(Driver.getDriver(), NewCandidateModal.class);
	}

    /**
     * Clicks Quick Launch and cancels the operation
     * @return
     */
    public static boolean clickNewCandidateToTestFocus() {
        waitForModalMaskToGoAway();
        WebElement newCandidateLink = Driver.getDriver().findElement(By.id("divQuickLaunchNewCandidate"));
        newCandidateLink.click();
        WaitUntil.waitUntil(() -> ((EventFiringWebDriver)Driver.getDriver())
                .getWrappedDriver()
                .findElement(By.id("qf")).isDisplayed(), NoSuchElementException.class);
        boolean appropriateFocus = false;
        try {
            appropriateFocus = Driver.getDriver().switchTo().activeElement()
                                     .getAttribute("id").contains("qf");

        } catch (NullPointerException npe) {
            appropriateFocus = false;
        }
        Driver.getDriver().switchTo().activeElement().sendKeys(Keys.ESCAPE);
        return appropriateFocus;
    }

    private static void waitForModalMaskToGoAway() {
        WaitUntil.waitUntil(10, 1, () ->
                !((EventFiringWebDriver)Driver.getDriver())
                        .findElement(By.id("modalMask"))
                        .isDisplayed());
    }

	/**
	 * Clicks the close window link on the quick launch window.
	 */
	public void clickCloseWindowLink() {
		WebElement element = Driver.getDriver().findElement(By.xpath(".//*[@id='divQuickLaunchModalScreen']/div[1]/a"));
		JavaScriptHelper.click(element);
	}

	/**
	 * Clicks the close window button on the quick launch window.
	 */
	public void clickCloseWindowButton() {
		WebElement element = Driver.getDriver().findElement(By.cssSelector("img.modalWindowClose"));
		JavaScriptHelper.click(element);
	}

	/**
	 * Clicks the "+" button for the specified product listing in the Custom Packages section thereby showing its product details.
	 * @param uberFormID The id of the product that is to be interacted with
	 */
	public void showProductDetailsUsingButtonForCustomPackages(String uberFormID) {
		WebElement element = Driver.getDriver().findElement(By.xpath("//div[@class='modalWindowContent']/div[@class='scrollContainer']/div[@class='scrollContent']/div[div[@class='buttoncolumn'][div[a[contains(@href,'ufid=" + uberFormID + "')]]]]/div[@class='hideshowbuttons']/a[@class='updownarrow']/img[contains(@alt, 'show')]"));
		JavaScriptHelper.click(element);
	}

	/**
	 * Clicks the "-" button for the specified product listing in the Custom Packages section thereby hiding its product details.
	 * @param uberFormID The id of the product that is to be interacted with
	 */
	public void hideProductDetailsUsingButtonForCustomPackages(String uberFormID) {
		WebElement element = Driver.getDriver().findElement(By.xpath("//div[@class='modalWindowContent']/div[@class='scrollContainer']/div[@class='scrollContent']/div[div[@class='buttoncolumn'][div[a[contains(@href,'ufid=" + uberFormID + "')]]]]/div[@class='hideshowbuttons']/a[@class='updownarrow']/img[contains(@alt, 'hide')]"));
		JavaScriptHelper.click(element);
	}

	/**
	 * Clicks the text for the specified product listing in the Custom Packages section which toggles the product details between shown and hidden.
	 * @param uberFormID The id of the product that is to be interacted with
	 */
	public void toggleProductDetailsUsingTextForCustomPackages(String uberFormID) {
		WebElement element = Driver.getDriver().findElement(By.xpath("//div[@class='modalWindowContent']/div[@class='scrollContainer']/div[@class='scrollContent']/div[div[@class='buttoncolumn'][div[a[contains(@href,'ufid=" + uberFormID + "')]]]]/div[@class='productcolumn']/h2/a"));
		JavaScriptHelper.click(element);
	}

	/**
	 * Clicks the launch button for the specified product listing in the Custom Packages section thereby launching the corresponding uber form.
	 * @param uberFormID The id of the product that is to be interacted with
	 * @return The uber form page that the specified product listing corresponds to
	 */
	public ScreeningLaunchPage launchProductListingForCustomPackages(String uberFormID) {
		WebElement element = Driver.getDriver().findElement(By.xpath("//div[@class='modalWindowContent']/div[@class='scrollContainer']/div[@class='scrollContent']/div/div/div/a[contains(@href,'ufid=" + uberFormID + "')]/button"));
		JavaScriptHelper.click(element);
		return PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
	}
}
