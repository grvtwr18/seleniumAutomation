package Sites.TalentWiseDashboard;

import Data.locations.us.UsStateTerritory;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by btorbert on 9/8/16.
 */
public class AddOnboardingStateOfWorkModal extends CustomerDashboardPages {

    @FindBy(how = How.ID, using = "errStateOfWork")
    private static WebElement alertMessage;

    @FindBy(how = How.CSS, using = "input[onclick^='submitStateOfWork']")
    private static WebElement continueButton;

    @FindBy(how = How.CSS, using = "a[class='modalWindowClose']")
    private static WebElement closeLink;

    @FindBy(how = How.ID, using = "qStateOfWork")
    private static WebElement workStateDropDown;

    /**
     * Constructs static AddOnboardingStateOfWorkModal.
     */
    static {
        PageFactory.initElements(Driver.getDriver(), AddOnboardingStateOfWorkModal.class);
    }

    /**
     * Returns the alert message text.
     * @return
     */
    public static String getAlertMessage() {
        WaitUntil.waitUntil(() -> alertMessage.isDisplayed());
        return alertMessage.getText();
    }

    /**
     * returns true if alert message is displayed.
     * @return
     */
    public static boolean alertIsDisplayed() {
        return alertMessage.isDisplayed();
    }

    /**
     * Clicks the continue button.
     */
    public static void clickContinueButton() {
        WaitUntil.waitUntil(() -> continueButton.isEnabled());
        continueButton.click();
    }

    /**
     * Clicks the close link
     */
    public static void clickCloseLink() {
        closeLink.click();
    }

    /**
     * Selects the passed Data.locations.us.UsStateTerritory workState from the work state drop down.
     * @param workState
     */
    public static void selectWorkState(UsStateTerritory workState) {
        Select select = new Select(workStateDropDown);
        select.selectByValue(workState.getSubdivisionCode());
    }
}
