package Sites.TalentWiseDashboard.Helpers;

import Sites.TalentWiseDashboard.Reporting.ReportsListPage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.HomePage;
import Sites.TalentWiseDashboard.BatchUpload.BatchUploadTabs;
import Sites.TalentWiseDashboard.Dashboard.DashboardPage;
import Sites.TalentWiseDashboard.CustomerLoginPage;
import Sites.TalentWiseDashboard.Onboard.OnboardPage;
import Sites.TalentWiseDashboard.Reporting.SummaryReportPage;
import Sites.TalentWiseDashboard.Search.Records.CandidatesPage;
import Sites.TalentWiseDashboard.Search.Screen.ScreeningPage;
import Sites.TalentWiseDashboard.Tasks.OnboardingTasksPage;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Page object that represents the header that appears at the top of most TalentWise Dashboard webpages.
 *
 * @author eelefson
 */
/*Validations and the 
 * Create a class to determine PHP errors (PatBadStrings from IDE)*/
public class Header {

    @FindBy(how = How.XPATH, using = "//td[@class='logoCell']/a/img")
    private WebElement companyLogo;

    @FindBy(how = How.XPATH, using = "//div[@class='tabtext']")
    private WebElement resourcesTab;

    @FindBy(how = How.ID,using = "sso-username")
    private static WebElement usernameTab;

    @FindBy(how = How.XPATH, using = "//a[contains(@href,'dashboard.php')]")
    private static WebElement dashboardTab;

    @FindBy(how = How.ID, using = "tab_screen")
    private static WebElement screenTab;

    @FindBy(how = How.XPATH, using = "//a[contains(@href,'tasks.php')]")
    private static WebElement TasksTab;

    @FindBy(how = How.ID, using = "tab_dhs-screening")
    private static WebElement drugAndHealthTab;

    @FindBy(how = How.ID, using = "tab_records")
    private static WebElement recordsTab;

    @FindBy(how = How.XPATH, using = "//a[contains(@href,'billing.php')]")
    private static WebElement reportingTab;

    // Added Onboard Tab in Customer Dashboard
    @FindBy(how = How.ID, using = "tab_onboard")
    private static WebElement onboardingTab;

    @FindBy(how = How.ID, using = "tab_batch")
    private static WebElement batchUploadTab;

    @FindBy(how = How.XPATH, using = "//div[@id='menu-list-grow']//*[text()='Account Settings']")
    private static WebElement accountSettings;

    @FindBy(how = How.ID, using = "admin")
    private static WebElement adminButtonDashboard;

    @FindBy(how = How.XPATH, using = "//a[contains(@href,'screening/tools.php')]")
    private static WebElement adminButtonInAdmin;

    protected static Logger logger = LoggerFactory.getLogger("Header");

    /**
     * Constructs a new header page object.
     */
    public Header() {

    }

    static {
        PageFactory.initElements(Driver.getDriver(), Header.class);
    }

    public static boolean isLastTabVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By
                .className("single-subtab single-subtab-last"));
    }

    /**
     * Clicks the company logo in the upper left hand corner of the page.
     */
    public void clickCompanyLogo() {
        companyLogo.click();
    }

    /**
     * Clicks the resources tab in the upper right hand corner of the page.
     */
    public void clickResourcesTab() {
        resourcesTab.click();
    }

    /**
     * Clicks the tab containing the current user's account name which opens an associated drop down menu.
     */
    public static void clickUsernameTab() {
        usernameTab.click();
    }

    public static String getFullNameFromUserNameTab() {
        return SeleniumTest.getText(usernameTab).trim();
    }

    /**
     * Clicks on the account settings option for the drop down menu that is opened by using the clickUsernameTab
     * method.
     */
    public void clickAccountSettings() {
        clickUsernameTab();
        accountSettings.click();
    }

    /**
     * Clicks "Admin" in the upper right, to load the Tools (portals, workflows, etc.)
     */
    public static HomePage clickAdmin() {

        logger.info("Loading customer admin view");

        // for some insane reason, the Admin link has a different locator if you are already in
        // the admin area
        if (Driver.getDriver().getCurrentUrl().contains("tools.php")) {
            SeleniumTest.click(adminButtonInAdmin);
        } else {
            SeleniumTest.click(adminButtonDashboard);
        }
        TWFramework.SeleniumTest.waitForElementEnabled(AdminMenubar.backToDashboard);
        return PageFactory.initElements(Driver.getDriver(), HomePage.class);
    }

    public static void clickAdminWhenProxied() {
        //hide the proxylabel
        hideProxyLabel();
        SeleniumTest.waitForElementToBeClickable(adminButtonInAdmin);
        SeleniumTest.click(adminButtonInAdmin);
        hideProxyLabel();
    }

    public static void hideProxyLabel() {
        //Dismiss the proxy label
        JavaScriptHelper.runScript("(function(){var elt = document.getElementById('proxybox');"
                                   + "if(elt){elt.setAttribute('style','display:none');}})()");
    }

    /**
     * Clicks on the sign out option for the drop down menu that is opened by using the clickUsernameTab method. Signs
     * the current user out and redirects to the initial login page.
     *
     * @return A new login page object
     */
    public static CustomerLoginPage signOut() {
        // Nothing appears to be working here - forcing function changing this to call javascript and navigate to the
        // logout URL
        ((JavascriptExecutor) Driver.getDriver()).executeScript("window.location='screening/logout.php'");
        SeleniumTest.waitForPageLoadToComplete();
        Driver.getDriver().manage().deleteAllCookies();
        return PageFactory.initElements(Driver.getDriver(), CustomerLoginPage.class);
    }

    /**
     * Clicks on the "Dashboard" tab.
     *
     * @return A new dashboard page object
     */
    public static DashboardPage clickDashboardTab() {
        WaitUntil.waitUntil(30, 3, () -> dashboardTab.isDisplayed(), NoSuchElementException.class);
        dashboardTab.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Clicks on the "Screen" tab.
     *
     * @return A new screening page object
     */
    public static ScreeningPage clickScreenTab() {
        SeleniumTest.waitForElementToBeClickable(screenTab);
        screenTab.click();
        return PageFactory.initElements(Driver.getDriver(), ScreeningPage.class);
    }

    /**
     * Clicks on the "Onboard" tab
     *
     * @return A new Onboard page object
     */
    public static OnboardPage clickOnboardTab() {
        onboardingTab.click();
        return PageFactory.initElements(Driver.getDriver(), OnboardPage.class);
    }

    /**
     * Clicks on the "Tasks" tab.
     *
     * @return A new Tasks page object
     */
    public static OnboardingTasksPage clickTasksTab() {
        SeleniumTest.waitForElementToBeClickable(TasksTab);
        TasksTab.click();
        return PageFactory.initElements(Driver.getDriver(), OnboardingTasksPage.class);
    }

    public static boolean isDrugAndHealthTabVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("tab_dhs-screening"));
    }

    /**
     * Clicks on the "Records" tab.
     *
     * @return A new candidates page object
     */
    public static CandidatesPage clickRecordsTab() {
        SeleniumTest.click(recordsTab);
        return PageFactory.initElements(Driver.getDriver(), CandidatesPage.class);
    }

    public static boolean isRecordsTabVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("tab_records"));
    }

    /**
     * Clicks on the "Reporting" tab.
     * TODO: Lately this Reporting tab has been failing to populate with the expected Reports.
     * Sometimes, the page has been observed to just settle like it's done loading, without showing the expected Reports
     *
     * @return A new summary report page object
     */
    public static SummaryReportPage clickReportingTab() {
        SeleniumTest.click(reportingTab);
        return PageFactory.initElements(Driver.getDriver(), SummaryReportPage.class);
    }

    /**
     * Clicks the Batch Upload Tab
     */
    public static BatchUploadTabs clickBatchUploadTab() {
        batchUploadTab.click();
        return PageFactory.initElements(Driver.getDriver(), BatchUploadTabs.class);
    }

    /**
     * Clicks on the "Reporting" tab.
     *
     * @return A new reporting list page object
     */
    public static ReportsListPage clickReportingListTab() {
        SeleniumTest.click(reportingTab);
        return PageFactory.initElements(Driver.getDriver(), ReportsListPage.class);
    }

    //Click Sign Out button of customer portal
    @FindBy(how = How.XPATH, using = "//*[@id='menu-list-grow']//li[2]//p")
    private static WebElement signout;

    public static void clickSignOut(){
        SeleniumTest.click(signout);
    }
}
