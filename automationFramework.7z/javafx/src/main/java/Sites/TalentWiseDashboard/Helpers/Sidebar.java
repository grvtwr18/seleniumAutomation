package Sites.TalentWiseDashboard.Helpers;

import Sites.TalentWiseDashboard.Dashboard.CreateNewCandidatePage;
import Sites.TalentWiseDashboard.QuickLaunchPage;
import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import Sites.TalentWiseDashboard.Search.Records.CandidatesPage;
import TWFramework.BodyTextHelper;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import javax.swing.JOptionPane;

/**
 * Page object that represents the sidebar that appears on the left-hand side of most TalentWise Dashboard webpages.
 * @author eelefson
 */
public class Sidebar {

	@FindBy(how = How.CSS, using = "p#sidebarhide > a > i")
	private static WebElement hideSidebarButton;
	
	@FindBy(how = How.CSS, using = "p#sidebarshow > a > i")
	private static WebElement showSidebarButton;

	private static final String searchBoxLocatorString = "resolve";
	@FindBy(how = How.NAME, using = searchBoxLocatorString)
	private static WebElement searchBox;

	@FindBy(how = How.CSS, using = "i.fa.fa-search")
	private static WebElement searchButton;

	@FindBy(how = How.ID, using = "divQuickLaunchNewCandidate")
	private static WebElement createNewCandidateLink;

	@FindBy(how = How.ID, using = "quickLaunchNormal")
	private static WebElement quickLaunchDiv;

    @FindBy(how = How.ID, using = "candidateList")
    private static WebElement recentlyViewedList;

    static {
        PageFactory.initElements(Driver.getDriver(), Sidebar.class);
    }

    public static void hideRecentlyViewedList() {
        BodyTextHelper.hideElement(recentlyViewedList);
    }
	
	/**
	 * Clicks the minimize/hide sidebar button.
	 */
	public static void clickHideSidebarButton() {
		hideSidebarButton.click();
	}

	/**
	 * Hides side bar only if side bar is currently displayed.
	 */
	public static void hideSideBar() {
		if (searchButton.isDisplayed()) {
			clickHideSidebarButton();
		}
	}
	
	/**
	 * Clicks the maximize/show sidebar button.
	 */
	public static void clickShowSidebarButton() {
		showSidebarButton.click();
	}

	/**
	 * Shows side bar only if side bar is currently hidden.
	 */
	public static void showSideBar() {
		if (showSidebarButton.isDisplayed()) {
			clickShowSidebarButton();
		}
	}
	
	/**
	 * Types the specified candidate name or id into the find a candidate text box.
	 * @param name The candidate name or id to be typed
	 */
	public static Sidebar typeNameOrId(String name) {
		if(Driver.getBrowserType() == DriverType.FIREFOX) {
			SeleniumTest.FireFoxWorkArounds.setTextBox(searchBoxLocatorString, name);
		}
		else {
			SeleniumTest.clearAndSetText(searchBox, name);
		}
		return PageFactory.initElements(Driver.getDriver(), Sidebar.class);
	}
	
	/**
	 * Clicks the search button. to submit the candidate name or id that has previously been entered.
	 * @return A new candidates page object
	 */
	public static CandidatesPage submitSearch() {
		searchButton.click();
		return PageFactory.initElements(Driver.getDriver(), CandidatesPage.class);
	}

	/**
	 * Verifies that the Quick Launch div is absent, returning false if it is found to be present. Failure is collected,
	 * but doesn't stop the test.
	 *
	 * @return true when Quick Launch div is absent, false (with a collected error) if the div is present.
	 */
	public static boolean verifyQuickLaunchDivAbsent() {
		return SeleniumTest.verifyElementNotPresent(quickLaunchDiv);
	}

	/**
	 * Submits a search for a candidate without using the name or ID text field
	 * @param filter supplies the text to the search button directly
	 * @return
	 */
	public static CandidatesPage submitSearch(String filter) {
		// Original JScript
		// var resolve = jQuery.trim($("#resolve").val()); if ("" != resolve && "Name or ID" != resolve) { $("#sideSearchForm").submit(); }
		JavaScriptHelper.runScript("var resolve = $(\"#resolve\").val('" + filter + "');$(\"#sideSearchForm\").submit();");
		return PageFactory.initElements(Driver.getDriver(), CandidatesPage.class);
	}
	/**
	 * Submits a search for the specified candidate name or id.
	 * @param name The candidate name or id to be typed
	 * @return A new candidates page object
	 */
	public static CandidatesPage searchForNameOrId(String name) {
		typeNameOrId(name);
		return submitSearch();
	}
	
	/**
	 * Clicks the quick launch button.
	 * @return A new quick launch page object
	 */
	public static QuickLaunchPage clickQuickLaunchButton() {
        final WebElement quickLaunch = Driver.getDriver().findElement(By.id("quickLaunchOpen"));
        if (!quickLaunch.getAttribute("style").contains("flex")) {
            JavaScriptHelper.click(By.id("quickLaunchNormal"));
            WaitUntil.waitUntil(() -> quickLaunch.getAttribute("style").contains("flex"));
        }
		return PageFactory.initElements(Driver.getDriver(), QuickLaunchPage.class);
	}


    /**
     * @param firstName can be "First Middle" if applicable
     * @param lastName
     */
	public static void viewCandidateByLink(String firstName, String lastName) {
        Driver.getDriver().findElement(By.linkText(lastName + ", " + firstName)).click();
	}
	
	/**
	 * Clicks on the icon in the sidebar for the specified candidate.
	 * @param candidateName The candidate to be selected from the sidebar listings
	 * @return A new candidate view page object
	 */
	public CandidateDetailsPage viewCandidateByIcon(String candidateName) {
		try {
            Driver.getDriver().findElement(By.xpath("//div[@class='candidateListItemNameContainer']/a[contains(text(),'" + candidateName + "')]/../preceding-sibling::div[@class='candidateListItemIconContainer']/a[contains(@href, 'CandidateID')]")).click();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "The candidate " + candidateName + " does not correspond to any of the candidates listed on the current page.", "Invalid Argument", JOptionPane.ERROR_MESSAGE);
		}
		return PageFactory.initElements(Driver.getDriver(), CandidateDetailsPage.class);
	}
	
	/**
	 * Clicks on the link in the sidebar for the specified applicant.
	 * @param applicantName The applicant to be selected from the sidebar listings
	 */
	public void viewApplicantByLink(String applicantName) {
		try {
			Driver.getDriver().findElement(By.xpath("//div[@class='candidateListItemContainer']/div[div[@class='candidateListItemNameContainer'][a[text()='" + applicantName + "']]]/div[@class='candidateListItemNameContainer']/a[contains(@href, 'ApplicantID')]")).click();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "The candidate " + applicantName + " does not correspond to any of the candidates listed on the current page.", "Invalid Argument", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	/**
	 * Clicks on the icon in the sidebar for the specified applicant.
	 * @param applicantName The applicant to be selected from the sidebar listings
	 */
	public void viewApplicantByIcon(String applicantName) {
		try {
			Driver.getDriver().findElement(By.xpath("//div[@class='candidateListItemContainer']/div[div[@class='candidateListItemNameContainer'][a[text()='" + applicantName + "']]]/div[@class='candidateListItemIconContainer']/a[contains(@href, 'ApplicantID')]/img")).click();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "The candidate " + applicantName + " does not correspond to any of the candidates listed on the current page.", "Invalid Argument", JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Clicks on New Candidate Link and opens new candidate modal dialog.
	 */
	public CreateNewCandidatePage clickNewCandidateLink() {
		createNewCandidateLink.click();
		return PageFactory.initElements(Driver.getDriver(), CreateNewCandidatePage.class);
	}
}
