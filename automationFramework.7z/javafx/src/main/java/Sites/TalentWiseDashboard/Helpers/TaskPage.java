package Sites.TalentWiseDashboard.Helpers;

import Sites.TalentWiseDashboard.Tasks.OnboardingTasksPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by btorbert on 7/21/16.
 */
public class TaskPage {

    /**
     * Returns true only if the Assignee DropDown contains one Unassigned option.
     */
    public static boolean assigneeDropDownContainsOneUnassignedOption() {
        OnboardingTasksPage.openMultiSelectDropDown(OnboardingTasksPage.TasklistColumn.ASSIGNEE.toString());
        ArrayList<String> resultList = OnboardingTasksPage.getAssigneeSearchResultList();
        boolean oneUnassigned = false;
        for(String result : resultList) {
            if(oneUnassigned && result.equals("Unassigned")) {
                oneUnassigned = false;
                Header.logger.info("FAIL!!! More than one Unassigned was found in the Assignee Drop Down.");
                break;
            }

            if(result.equals("Unassigned")) {
                oneUnassigned = true;
            }
        }

        return oneUnassigned;
    }

    /**
     * returns a date from a dateString.
     * @param dateString
     * @return
     */
    public static Date stringToDate(String dateString) {
        // Re-Structuring dateString - For Example "Jun 30, 2016"  will become "Jun-30-2016"
        String newDateString = dateString.replace(", ", "-");
        newDateString = newDateString.replace(" ", "-");

        SimpleDateFormat formatter = new SimpleDateFormat("MMM-dd-yyyy");
        Date date = null;
        try {
            date = formatter.parse(newDateString);
        } catch (ParseException e) {
            System.out.print("Date parse has failed in OnboardingTasksPage.stringToDate(String dateString)");
            e.printStackTrace();
        }
        return date;
    }

    /**
     * Returns a date List from a Tasklist date column.
     * @param dateColumnName
     * @return
     */
    public static ArrayList<Date> getDateColumnFromTasklist(String dateColumnName) {
        ArrayList<Date> dates = new ArrayList<>();
        ArrayList<String> dateStrings = OnboardingTasksPage.getColumnFromTasklist(dateColumnName);

        for (String dateString : dateStrings) {
            dates.add(stringToDate(dateString));
        }

        return dates;
    }

    public static boolean isAscendingOrderDateColumn_OldestToNewest(String dateColumnName) {
        OnboardingTasksPage.waitForGridToLoad();
        ArrayList<Date> unsortedDateList = getDateColumnFromTasklist(dateColumnName);

        // Creates copy to sort, Sorts the copy, and Checks if both are equals.
        ArrayList<Date> sortedDateList = new ArrayList<Date>(unsortedDateList);
        Collections.sort(sortedDateList);
        return sortedDateList.equals(unsortedDateList);
    }

    public static boolean isDescendingOrderDateColumn_NewestToOldest(String dateColumnName) {
        OnboardingTasksPage.waitForGridToLoad();
        ArrayList<Date> unsortedDateList = getDateColumnFromTasklist(dateColumnName);

        // Creates copy to sort, Sorts the copy, and Checks if both are equals.
        ArrayList<Date> revSortedDateList = new ArrayList<Date>(unsortedDateList);
        Collections.sort(revSortedDateList);
        Collections.reverse(revSortedDateList);
        return revSortedDateList.equals(unsortedDateList);
    }

    /**
     * returns true if column has Ascending Carrot icon
     */
    public static boolean isCarrotIconAscending(String columnName) {
        SeleniumTest.waitForPageLoadToComplete();
        waitForLoadingMask();
        return (Driver.getDriver().findElement(
                By.xpath("//a[@class='k-link'][text()='" + columnName + "']/span")))
                .getAttribute("class").equals("k-icon k-i-sort-asc-sm");
    }

    /**
     * returns true if column has Descending Carrot icon
     */
    public static boolean isCarrotIconDescending(String columnName) {
        SeleniumTest.waitForPageLoadToComplete();
        waitForLoadingMask();
        return (Driver.getDriver().findElement(
                By.xpath("//a[@class='k-link'][text()='" + columnName + "']/span")))
                .getAttribute("class").equals("k-icon k-i-sort-desc-sm");
    }

    public static void waitForLoadingMask() {
        SeleniumTest.waitForElementNotPresent(By.className("k-loading-mask"));
    }

    /**
     * Select All available options in the Task Status dropdown. //TODO use and debug this in the Tests
     */
    public static void selectAllTaskStatusDropDownOptions() {
        OnboardingTasksPage.openMultiSelectDropDown(OnboardingTasksPage.TasklistColumn.TASK_STATUS.toString());
        //wait for value to be visible.
        SeleniumTest.waitForElementVisible(OnboardingTasksPage.taskStatusDropDownOptions);
        List<WebElement> elements = Driver.getDriver().findElements(OnboardingTasksPage.taskStatusDropDownOptionsBy);

        for (WebElement element : elements) {
            element.click();
        }
    }

    public static void clickFirstTaskNameHyperlink() {
        OnboardingTasksPage.waitForGridToLoad();
        OnboardingTasksPage.firstTaskNameHyperlink.click();
    }
}
