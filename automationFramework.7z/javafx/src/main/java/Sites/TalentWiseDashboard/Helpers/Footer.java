package Sites.TalentWiseDashboard.Helpers;

import Sites.URL;
import TWFramework.LocaleHelper;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.net.UnknownHostException;

/**
 * Page object that represents the footer that appears at the bottom of most TalentWise Dashboard webpages.
 * @author eelefson
 */
public class Footer {

    // these elements need IDs
    @FindBy(how = How.XPATH, using = "//*[@id=\"dbIdFooter\"]/a[1]")
    private static WebElement termsAndConditions;
    private static final String TERMS_ANC_CONDITIONS_LINK_TEXT_EN_US = "Terms and Conditions";
    private static final String TERMS_ANC_CONDITIONS_LINK_TEXT_QPS_PLOC = "[{2d5d} ...Ŧḗřḿş ȧƞḓ Ƈǿƞḓīŧīǿƞş...]";
    private static final String TERMS_ANC_CONDITIONS_TARGET_EN_US    =
            "/screening/support.php?view=supportterms";

    @FindBy(how = How.XPATH, using = "//*[@id=\"dbIdFooter\"]/a[1]")
    private static WebElement privacyPolicy;
    private static final String PRIVACY_POLICY_LINK_TEXT_EN_US = "Privacy Notice";
    private static final String PRIVACY_POLICY_LINK_TEXT_QPS_PLOC = "[{0986} ..Ƥřīṽȧƈẏ Ƞǿŧīƈḗ..]";
    private static final String PRIVACY_POLICY_TARGET_EN_US    =
            "https://www.sterlingtalentsolutions.com/about/privacy-clients/";

    /**
     * Constructs a new footer page object.
     */
    public Footer() {
    }

    static {
        PageFactory.initElements(Driver.getDriver(), Footer.class);
    }

    public static String getTermsAndConditionsLinkText() {
        return termsAndConditions.getText();
    }

    public static String getTermsAndConditionsExpectedLinkText(LocaleHelper.Locale locale) {
        String text = "";
        switch (locale.UrlTag()){
            case "en-US":
                text = TERMS_ANC_CONDITIONS_LINK_TEXT_EN_US;
                break;
            case "qps-PLOC":
                text = TERMS_ANC_CONDITIONS_LINK_TEXT_QPS_PLOC;
                break;
        }
        return text;
    }

    public static String getTermsAndConditionsTarget() {
        return termsAndConditions.getAttribute("href");
    }

    public static String getTermsAndConditionsExpectedTarget() throws UnknownHostException {
        return "https://" + URL.getBasicHost() + TERMS_ANC_CONDITIONS_TARGET_EN_US;
    }

    public static String getPrivacyPolicyLinkText() {
        return privacyPolicy.getText();
    }

    public static String getPrivacyPolicyExpectedLinkText(LocaleHelper.Locale locale) {
        String text = "";
        switch (locale.UrlTag()){
            case "en-US":
                text = PRIVACY_POLICY_LINK_TEXT_EN_US;
                break;
            case "qps-PLOC":
                text = PRIVACY_POLICY_LINK_TEXT_QPS_PLOC;
                break;
        }
        return text;
    }

    public static String getPrivacyPolicyTarget() {
        return privacyPolicy.getAttribute("href");
    }

    public static String getPrivacyPolicyExpectedTarget() {
        return PRIVACY_POLICY_TARGET_EN_US;
    }
}
