package Sites.TalentWiseDashboard.Helpers;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ContributorsVerifiersPage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.DocsAndMediaPage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.FormsPage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.HomePage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.UserListPage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.ContributorDetailPage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.RoleEditPage;
import Sites.TalentWiseDashboard.Dashboard.DashboardPage;
import Sites.TalentWiseDashboard.Dashboard.adminTools.userSettings.roles.RolesPage;
import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

/**
 * Created by wogden on 6/16/2015.
 */
public class AdminMenubar {

    static {
        PageFactory.initElements(Driver.getDriver(), AdminMenubar.class);
    }

    //main UI elements
    @FindBy(how = How.ID, using = "usernameLink")
    public static WebElement usernameLink;

    @FindBy(how = How.CLASS_NAME, using = "dashboard-link")
    public static WebElement backToDashboard;

    @FindBy(how = How.CSS, using = "a#sidebarToggle")
    private static WebElement toggleAdminMenu;

    //region menu
    @FindBy(how = How.ID, using = "home")
    public static WebElement homeMenuItem;

    //region my account (preferences, profile, etc)
    @FindBy(how = How.ID, using = "my")
    private static WebElement myAccountGroupExpander;

    //region my account/preferences
    @FindBy(how = How.ID, using = "my_acctprefs")
    private static WebElement myAccountPreferences;

    //region my account (preferences, profile, etc)
    @FindBy(how = How.ID, using = "my_acctprefs_status")
    private static WebElement myAccountPreferencesStatus;

    // Content management is proxy only
    @FindBy(how = How.ID, using = "landing_content")
    public static WebElement contentMenuItem;

    // preferencesGroupExpander
    // 5 items under this group

    // Profile

    @FindBy(how = How.ID, using = "my_acctpayment")
    private static WebElement creditCardMenuItem;

    @FindBy(how = How.ID, using = "my_acctprefs")
    private static WebElement preferenceMenuItem;

    @FindBy(how = How.ID, using = "my_acctprefs_notify")
    private static WebElement generalNotification;

    @FindBy(how = How.ID, using = "my_acctprefs_i9everify")
    private static WebElement i9EVerifyNotification;

    //Change Password
    @FindBy(how = How.ID, using = "my_acctpw")
    private static WebElement changePasswordMenuItem;

    //endregion

    //region Org Settings
    @FindBy(how = How.ID, using = "org_settings")
    private static WebElement orgSettingsGroupExpander;

    @FindBy(how = How.ID, using = "org_orgsettings")
    private static WebElement organizationHierarchyMenuItem;
    //endregion

    //region user settings
    @FindBy(how = How.ID, using = "user_settings")
    private static WebElement userSettingsGroupExpander;

    //region users group expander
    private static final String users = "user";
    static By usersGroupExpanderLocator = By.id(users);
    @FindBy(how = How.ID, using = users)
    private static WebElement usersGroupExpander;

    private static final String userList = "user_users";
    @FindBy(how = How.ID, using = userList)
    private static WebElement userListMenuItem;
    private static By userListMenuItemLocator = By.id(userList);
    //Report Viewing Defaults
    //endregion

    //Roles

    private static final String contributors = "user_contributors";
    static By userContributorsMenuItemLocator = By.id(contributors);

    @FindBy(how = How.ID, using = contributors)
    private static WebElement userContributorsMenuItem;

    private static final String roles = "user_roles";
    static By userRolesMenuItemLocator = By.id(roles);

    //endregion User Settings

    //region Account Configuration
    @FindBy(how = How.ID, using = "cfg")
    public static WebElement accountConfigurationGroupExpander;

    @FindBy(how = How.ID, using = "cfg_tpl_email_group")
    public static WebElement emailTemplatesMenuItem;
    private By emailTemplatesLocator = By.id("cfg_tpl_email_group");

    @FindBy(how = How.ID, using = "cfg_assets")
    public static WebElement docsAndMediaMenuItem;
    private static By docsAndMediaMenuItemLocator = By.id("cfg_assets");

    // Workflows

    @FindBy(how = How.ID, using = "cfg_wf")
    public static WebElement workflowItem;
    private static By workflowItemLocator = By.id("cfg_wf");

    @FindBy(how = How.ID, using = "cfg_profiles")
    public static WebElement companyProfilesItem;
    private static By companyProfilesItemLocator = By.id("cfg_profiles");

    @FindBy(how = How.ID, using = "cfg_pkgs")
    private static WebElement packagesMenuItem;

    @FindBy(how = How.ID, using = "cfg_prtls")
    public static WebElement portalMenuItem;
    private By portalMenuItemLocator = By.id("cfg_prtls");

    //Currently only present while proxying
    @FindBy(how = How.ID, using = "cfg_forms")
    public static WebElement formsMenuItem;
    private By formsMenuItemLocator = By.id("cfg_forms");

    // SAML SSO Settings; only present while proxying for SSO-enabled user.
    private static final String samlSsoSettingsMenuItemId = "cfg_sso";
    @FindBy(id = samlSsoSettingsMenuItemId)
    private static WebElement samlSsoSettingsMenuItem;
    public static final By samlSsoSettingsMenuItemLocator = By.id(samlSsoSettingsMenuItemId);
    //endregion
    //endregion

    public static void hideUsernameLink() {
        BodyTextHelper.hideElement(usernameLink);
    }

    public static void hideAdminMenuBar() {
        SeleniumTest.clickUntilElementDisappears(AdminMenubar.toggleAdminMenu, AdminMenubar.backToDashboard);
    }
    public static void showAdminMenuBar() {
        SeleniumTest.clickUntilElementAppears(AdminMenubar.toggleAdminMenu, AdminMenubar.backToDashboard);
    }

    public static HomePage clickHomeMenuItem() {
        homeMenuItem.click();
        return PageFactory.initElements(Driver.getDriver(), HomePage.class);
    }

    public static void clickCreditCardMenuItem() {
        expandMyAccount();
        creditCardMenuItem.click();
    }

    public static void clickEmailTemplatesMenuItem() {
        expandAccountConfiguration();
        emailTemplatesMenuItem.click();
    }

    public static void clickChangePasswordMenuItem() {
        expandMyAccount();
        changePasswordMenuItem.click();
    }

    public static void openPreferences() {
        expandMyAccount();
        preferenceMenuItem.click();
    }

    public static void clickGeneralNotifications() {
        generalNotification.click();
    }

    public static void clickI9EVerifyNotifications() {
        SeleniumTest.click(i9EVerifyNotification);
    }

    public static UserListPage clickUserListMenuItem() {
        expandUserSettings();
        userListMenuItem.click();
        return PageFactory.initElements(Driver.getDriver(), UserListPage.class);
    }

    public static ContributorsVerifiersPage clickContributorsListMenuItem() {
        expandUserSettings();
        userContributorsMenuItem.click();
        return PageFactory.initElements(Driver.getDriver(), ContributorsVerifiersPage.class);
    }

    public static void clickPackagesMenuItem() {
        SeleniumTest.click(packagesMenuItem);
    }

    public static void clickPortalMenuItem() {
        expandAccountConfiguration(portalMenuItem);
        portalMenuItem.click();
    }

    /**
     * clicks the Docs and media menu item, expanding the menu if needed
     * @return the docs and media page
     */
    public static DocsAndMediaPage clickDocsAndMediaMenuItem() {
        expandAccountConfiguration(docsAndMediaMenuItem);
        Driver.getDriver().findElement(docsAndMediaMenuItemLocator).click();
        DocsAndMediaPage docsAndMediaPage =  PageFactory.initElements(Driver.getDriver(), DocsAndMediaPage.class);
        SeleniumTest.waitForElementVisible(docsAndMediaPage.pageHeaderLocator);
        return docsAndMediaPage;
    }

    /**
     * clicks the Docs and media menu item, expanding the menu if needed and returns without waiting.
     */
    public static void clickDocsAndMediaMenuItemNoWait() {
        expandAccountConfiguration(docsAndMediaMenuItem);
        Driver.getDriver().findElement(docsAndMediaMenuItemLocator).click();
    }

    /**
     * clicks the Workflow item, expanding the menu if needed and returns without waiting.
     */
    public static void clickWorkflowItemNoWait() {
        expandAccountConfiguration(workflowItem);
        Driver.getDriver().findElement(workflowItemLocator).click();
    }

    /**
     * clicks the Company Profiles item, expanding the menu if needed and returns without waiting.
     */
    public static void clickCompanyProfilesItemNoWait() {
        expandAccountConfiguration(companyProfilesItem);
        Driver.getDriver().findElement(companyProfilesItemLocator).click();
    }

    /**
     * Opens the forms page, expanding Account configuration if needed.
     * @return FormsPage Object
     */
    public static FormsPage clickFormsPageMenuItem() {
        expandAccountConfiguration(formsMenuItem);
        formsMenuItem.click();
        return PageFactory.initElements(Driver.getDriver(), FormsPage.class);
    }

    public static boolean isFormsPageMenuItemVisible() {
        try {
            return formsMenuItem.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * opens the User list page from the menu, opening any needed menu expanders first
     * @return UserListPage Object
     */
    public static UserListPage clickUserlistMenuItem() {
        expandUsers(userListMenuItemLocator);
        Driver.getDriver().findElement(userListMenuItemLocator).click();
        UserListPage userListPage =  PageFactory.initElements(Driver.getDriver(), UserListPage.class);
        SeleniumTest.waitForElementVisible(userListPage.pageHeaderLocator);
        return userListPage;
    }

    /**
     * Opens the User list page from the menu, opening any needed menu expanders first and doesn't wait
     */
    public static void clickUserListMenuItemNoWait() {
        expandUsers(userListMenuItemLocator);
        Driver.getDriver().findElement(userListMenuItemLocator).click();
    }

    /**
     * Opens the SettingGroupExpander if needed, and then clicks the Contributors menu item
     * @return ContributorsVerifiersPage Object
     */
    public static ContributorsVerifiersPage clickContributorsMenuItem(){
        expandUserSettings(userContributorsMenuItemLocator);
        SeleniumTest.waitForElementVisible(userContributorsMenuItemLocator);
        SeleniumTest.click(userContributorsMenuItemLocator);
        ContributorsVerifiersPage contributorsVerifiersPage =  PageFactory.initElements(Driver.getDriver(), ContributorsVerifiersPage.class);
        SeleniumTest.waitForElementVisible(contributorsVerifiersPage.pageHeaderLocator);
        return contributorsVerifiersPage;
    }

    /**
     * Opens the SettingsGroupExpander if needed, and clicks the Contributors menu item.  It does not wait
     * for the page to finish loading.
     * @return
     */
    public static ContributorDetailPage clickContributorMenuItemNoWait() {
        SeleniumTest.waitForPageLoadToComplete();
        expandUserSettings(userContributorsMenuItemLocator);
        SeleniumTest.waitForElementVisible(userContributorsMenuItemLocator);
        Driver.getDriver().findElement(userContributorsMenuItemLocator).click();
        return PageFactory.initElements(Driver.getDriver(), ContributorDetailPage.class);
    }

    /**
     * Opens the SettingsGroupExpander if needed, and clicks the Roles menu item.  It does not wait
     * for the page to finish loading.
     * @return
     */
    public static RolesPage clickRolesMenuItemNoWait() {
        expandUserSettings(userRolesMenuItemLocator);
        SeleniumTest.waitForElementVisible(userRolesMenuItemLocator);
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.click(userRolesMenuItemLocator);
        return PageFactory.initElements(Driver.getDriver(), RolesPage.class);
    }

    public static RoleEditPage clickRole() {
        List<WebElement> roles = Driver.getDriver().findElements(By.xpath("//a[contains(@href, '/screening/tools.php?view=user_roles&op=edit')]"));
        roles.get(0).click();
        return PageFactory.initElements(Driver.getDriver(), RoleEditPage.class);
    }

    private static void expandMyAccount() {
        WebElement myAccountListElement = myAccountGroupExpander.findElement(By.cssSelector("ul"));
        if (myAccountListElement.getAttribute("aria-expanded").equals("true")) {
            // we're already expanded.
            return;
        } else {
            myAccountGroupExpander.click();
            WaitUntil.waitUntil(() -> myAccountListElement.getAttribute("aria-expanded")
                .equals("true"));
        }
    }

    private static void expandMyAccountPreferences() {
        while(!myAccountPreferences.getAttribute("class").contains("active")) {
            SeleniumTest.click(myAccountPreferences);
            SeleniumTest.waitForElementEnabled(myAccountPreferencesStatus, 6, 2);
        }
    }

    public static void expandOrgSettings() {
        WebElement orgSettingsListElement = orgSettingsGroupExpander.findElement(By.cssSelector("ul"));
        if (!orgSettingsListElement.getAttribute("aria-expanded").equals("true")) {
            orgSettingsGroupExpander.click();
            WaitUntil.waitUntil(() -> orgSettingsListElement.getAttribute("aria-expanded")
                    .equals("true"));
        }
    }

    public static boolean isOrgSettingsVisible() {
        return SeleniumTest.isElementVisible(orgSettingsGroupExpander);
    }

    public static boolean isOrganizationHierarchyVisible() {
        return SeleniumTest.isElementVisible(organizationHierarchyMenuItem);
    }

    /**
     * Expands the Users subgroup
     * @param by locator
     */
    public static void expandUsers(final By by) {
        expandUserSettings(usersGroupExpanderLocator);
        while(!usersGroupExpander.getAttribute("class").contains("active")) {
            SeleniumTest.click(usersGroupExpander);
            try {
                SeleniumTest.waitForElementEnabled(by, 6, 2);
            }
            catch (TimeoutException e) {
                // click again
            }

        }
    }

    /**
     * Expands the User Settings submenu
     * @param by a locator for the menu item you are tyring to get to.
     */
    public static void expandUserSettings(final By by) {
        while(!userSettingsGroupExpander.getAttribute("class").contains("active")) {
            SeleniumTest.click(userSettingsGroupExpander);
            SeleniumTest.waitForElementEnabled(by, 6, 2);
        }
    }

    /**
     * Collapses the UserSettings Heading menu item
     */
    public void collapseUserSettings() {
        if(userSettingsGroupExpander.getAttribute("class").contains("active")) {
            userSettingsGroupExpander.click();
        }
        WaitUntil.waitUntil(6,2,
                () -> null == Driver.getDriver().findElement(emailTemplatesLocator));
    }

    /**
     * Clicks the Account Configuration section to expand it.
     */
    public static void expandAccountConfiguration() {
        if(!accountConfigurationGroupExpander.getAttribute("class").contains("active")) {
            accountConfigurationGroupExpander.click();
        }
        By navSecondLevelBy = By.cssSelector("li#cfg > ul.nav-second-level");
        SeleniumTest.waitForElementAttributeValue(navSecondLevelBy, "class", "collapse in");
    }

    /**
     *
     * @param element element to verify it's open
     */
    public static void expandAccountConfiguration(final WebElement element) {
        SeleniumTest.clickUntilElementAppears(accountConfigurationGroupExpander, element);
    }

    public static void expandUserSettings() {
        SeleniumTest.clickUntilElementActive(userSettingsGroupExpander, usersGroupExpander);
        SeleniumTest.clickUntilElementActive(usersGroupExpander, userListMenuItem);

    }
    /**
     * Collapses the UserSettings Heading menu item
     */
    public void collapseAccountConfiguration() {
        if(userSettingsGroupExpander.getAttribute("class").contains("active")) {
            userSettingsGroupExpander.click();
        }
        WaitUntil.waitUntil(() -> Driver.getDriver().findElement(userContributorsMenuItemLocator) == null);
    }

    public static DashboardPage clickDashboard() {
        Driver.getDriver().findElement(By.xpath("//a[contains(@href, 'screening/dashboard.php')]")).click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public static void clickMyAccountPreferencesStatus() {
        expandMyAccount();
        myAccountPreferences.click();
        expandMyAccountPreferences();
        WaitUntil.waitUntil(() -> myAccountPreferencesStatus.isDisplayed());
        myAccountPreferencesStatus.click();
    }

    public static HomePage clickBackToDashboard() {
        SeleniumTest.click(backToDashboard, 5);
        return PageFactory.initElements(Driver.getDriver(), HomePage.class);
    }

    public static void clickEditPackage(int uberFormPackageId) {
        SeleniumTest.click(By.id("edit" + uberFormPackageId));
    }

}
