package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

import static Sites.AdminConsole.atstools.SearchHelper.staticLogger;

public class TicketFormCanadian extends TicketForm {

    @FindBy(how = How.ID, using = "qcanadaidverification_Group890-0_1")
    private static WebElement hiringMgrOrgRepIdVerifRadioButton;

    @FindBy(how = How.ID, using = "qcanadaidverification_Group890-0_1")
    private static WebElement canadaPostIdVerRadioButton;

    @FindBy(how = How.ID, using = "qisrush_10634_1")
    private static WebElement rushCrimRequestCheckBox;

    @FindBy(how = How.ID, using = "qisrush_10641_1")
    private static WebElement rushCredRequestCheckBox;

    @FindBy(how = How.ID, using = "qisrush_10643_1")
    private static WebElement rushXCheckRequestCheckBox;

    @FindBy(how = How.ID, using = "qeidfallback_Group890-0_1")
    private static WebElement selectEIV;

    @FindBy(how = How.ID, using = "qcanadaidverification_Group890-0_1")
     private static WebElement radioEIV;

    @FindBy(how = How.ID, using = "qdls_Group925-0_1")
    private static WebElement provinceSelect;

    @FindBy(how = How.ID, using = "qdls_Group1104-0_1")
    private static WebElement provinceVerSelect;

    @FindBy(how = How.ID, using = "qdl_Group925-0_1")
    private static WebElement licenseText;

    @FindBy(how = How.ID, using = "qdl_Group1104-0_1")
    private static WebElement licenseVerText;

    @FindBy(how = How.ID, using = "file_document_1_Group925-0_1")
    private static WebElement fileInput;

    @FindBy(how = How.ID, using = "qcDownload")
    private static WebElement downloadConsent;

    @FindBy(how = How.ID, using = "mbDownload")
    private static WebElement downloadConsentMtb;

    static {
        PageFactory.initElements(Driver.getDriver(), TicketFormCanadian.class);
    }

    public static boolean isHiringMgrOrgRepIdVerifRadioButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qcanadaidverification_Group890-0_1"));
    }

    public static void clickHiringMgrOrgRepIdVerifRadioButton() {
        SeleniumTest.click(hiringMgrOrgRepIdVerifRadioButton);
    }

    public static void clickCanadaPostIdVerifRadioButton() {
        SeleniumTest.click(By.xpath("//*[@id='qcanadaidverification_Group890-0_1'][@value='3']"));
    }

    public static void checkRushCrimRequest() {
        SeleniumTest.check(rushCrimRequestCheckBox);
    }

    public static void unCheckRushCrimRequest() {
        SeleniumTest.unCheck(rushCrimRequestCheckBox);
    }

    public static boolean isRushCrimRequestCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qirush_10634_1"));
    }

    public static void checkRushCredRequest() {
        SeleniumTest.check(rushCredRequestCheckBox);
    }

    public static void unCheckRushCredRequest() {
        SeleniumTest.unCheck(rushCredRequestCheckBox);
    }

    public static boolean isRushCredRequestCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qirush_10641_1"));
    }

    public static void checkRushXCheckRequest() {
        SeleniumTest.check(rushXCheckRequestCheckBox);
    }

    public static void unCheckRushXCheckRequest() {
        SeleniumTest.unCheck(rushXCheckRequestCheckBox);
    }

    public static boolean isRushXCheckRequestCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qirush_10643_1"));
    }

    public static void selectEIVOption(String value) {
        Driver.getDriver().findElements(By.id("qcanadaidverification_Group890-0_1")).get(1).click();//two elements with same id
        SeleniumTest.selectByValueFromDropDown(selectEIV, value);
    }

    public void selectProvince(String province) {
        SeleniumTest.selectByVisibleTextFromDropDown(provinceSelect, province);
    }

    public void setLicenseText(String licenseNo) {
        SeleniumTest.setTextValue(licenseText, licenseNo);
    }

    public void setClassText(String strClass) {
        SeleniumTest.clearAndSetText(By.id("qdlclass_Group925-0_1"), strClass);
    }

    /**
     * This method fills the Driving record information.
     * @param province Name of the state
     * @param license license number of the candidate
     */
    public  void enterCanadianDrivingRecordInformation(String province, String license){
        //check if the licence input is for drivers license abstract or drivers license verification
        if ( SeleniumTest.isElementVisibleNoWaiting(By.id("qdl_Group925-0_1"))) {
            selectProvince(province);
            setLicenseText(license);
            if (province.contains("Alberta")) {
                setClassText(province);
            }
        } else {
            SeleniumTest.selectByVisibleTextFromDropDown(provinceVerSelect, province);
            SeleniumTest.setTextValue(licenseVerText, license);
        }
    }
    public void downloadConsent(String Province) {

        if(Province == "Quebec") {
            SeleniumTest.click(downloadConsent);
        }
        else if(Province == "Manitoba") {
            SeleniumTest.click(downloadConsentMtb);
        }
        SeleniumTest.waitMs(5000);//safe to wait for file to download.
    }

    public void checkReleaseDA(boolean check) {
        if(check) {
            SeleniumTest.check(By.xpath("//input[@id='qcanadantconsent_Group925-0_11'][@type='radio'][@value='1']")); //value=1 for yes
        } else {
            SeleniumTest.check(By.xpath("//input[@id='qcanadantconsent_Group925-0_11'][@type='radio'][@value='0']")); //value=0 for No
        }
    }

    public  void uploadDriverLicNWT() {
        try {
            checkReleaseDA(true);
            WebElement fileChooser = Driver.getDriver().findElement(By.xpath("//div[@id='NT']/descendant::input[@id='file_document_1_Group925-0_1']"));
            fileChooser.sendKeys(SeleniumTest.createTempFileToUpload("consent", "pdf").getCanonicalPath());
            SeleniumTest.waitMs(3000);
        }
        catch (IOException ex) {
            staticLogger.warn("IOException: {}", ex.getMessage());
        }
    }

    public  void uploadDriverLic(String filePath, String province) {
        WebElement fileChooser = Driver.getDriver().findElement(By.xpath("//div[@id='" + province
                                                                         + "']/descendant::input[@id='file_document_1_Group925-0_1']"));
        fileChooser.sendKeys(filePath);
    }
}
