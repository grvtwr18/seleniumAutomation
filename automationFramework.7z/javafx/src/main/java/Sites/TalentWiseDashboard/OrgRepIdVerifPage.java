package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class OrgRepIdVerifPage {

    @FindBy(how = How.ID, using = "signatureVerified")
    private static WebElement candIdSignatureVerifiedCheckBox;

    @FindBy(how = How.ID, using = "qf")
    private static WebElement firstNameTextBox;

    @FindBy(how = How.ID, using = "qm")
    private static WebElement middleNameTextBox;

    @FindBy(how = How.ID, using = "qn")
    private static WebElement lastNameTextBox;

    @FindBy(how = How.ID, using = "qfalias")
    private static WebElement altFirstNameTextBox;

    @FindBy(how = How.ID, using = "qmalias")
    private static WebElement altMiddleNameTextBox;

    @FindBy(how = How.ID, using = "qnalias")
    private static WebElement altLastNameTextBox;

    @FindBy(how = How.ID, using = "qmm")
    private static WebElement dobMonthDropDown;

    @FindBy(how = How.ID, using = "qdd")
    private static WebElement dobDayDropDown;

    @FindBy(how = How.ID, using = "qyy")
    private static WebElement dobYearDropDown;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement submitButton;

    static {
        PageFactory.initElements(Driver.getDriver(), OrgRepIdVerifPage.class);
    }

    public static void checkCandIdSignatureVerified() {
        SeleniumTest.check(candIdSignatureVerifiedCheckBox);
    }

    public static void unCheckCandIdSignatureVerified() {
        SeleniumTest.unCheck(candIdSignatureVerifiedCheckBox);
    }

    public static void setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameTextBox, firstName);
    }

    public static void setMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameTextBox, middleName);
    }

    public static void setLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameTextBox, lastName);
    }

    public static void setAltFirstName(String altFirstName) {
        SeleniumTest.clearAndSetText(altFirstNameTextBox, altFirstName);
    }

    public static void setAltMiddleName(String altMiddleName) {
        SeleniumTest.clearAndSetText(altMiddleNameTextBox, altMiddleName);
    }

    public static void setAltLastName(String altLastName) {
        SeleniumTest.clearAndSetText(altLastNameTextBox, altLastName);
    }

    public static void setDateOfBirth(LocalDate dob) {
        String month = dob.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);
        String day = (Integer.toString(dob.getDayOfMonth()));
        String year = (Integer.toString(dob.getYear()));

        SeleniumTest.selectShortMonthByVisibleText(dobMonthDropDown, month);
        SeleniumTest.selectByVisibleTextFromDropDown(dobDayDropDown, day);
        SeleniumTest.selectByVisibleTextFromDropDown(dobYearDropDown, year);
    }

    public static void clickSubmit() {
        SeleniumTest.click(submitButton);
    }

    public static void fillAndSubmit(Candidate candidate) {
        setFirstName(candidate.getFirstName());
        setMiddleName(candidate.getMiddleName());
        setLastName(candidate.getLastName());
        setAltFirstName(candidate.getAlternateFirstName());
        setAltMiddleName(candidate.getAlternateLastName());
        setAltLastName(candidate.getAlternateLastName());
        setDateOfBirth(candidate.getDOB());
        clickSubmit();
    }
}
