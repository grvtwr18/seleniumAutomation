package Sites.TalentWiseDashboard;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 10/26/2016.
 */
public class MultipleAccountsFoundPage extends ForgotPasswordPage{

    @FindBy(how = How.XPATH, using = "//input[@value='1']")
    private static WebElement adminAccountRadioButton;

    @FindBy(how = How.XPATH, using = "//input[@value='227']")
    private static WebElement customerAccountRadioButton;

    @FindBy(how = How.XPATH, using = "//input[@value='Select']")
    private static WebElement selectButton;

    @FindBy(how = How.XPATH, using = "//h1[text()='Multiple Accounts Found']")
    private static WebElement multipleAccountsFoundHeader;

    static {
        PageFactory.initElements(Driver.getDriver(), MultipleAccountsFoundPage.class);
    }

    public static boolean onPage() {
        return Driver.getDriver().getPageSource().contains("Multiple Accounts Found");
    }

    public static void waitForPageToLoad() {
        SeleniumTest.isElementVisible(multipleAccountsFoundHeader);
    }

    public static void selectAdminRadio(){
        adminAccountRadioButton.click();
    }

    public static void selectCustomerRadio(){
        customerAccountRadioButton.click();
    }

    public static void clickSelectButton(){
        selectButton.click();
    }
}
