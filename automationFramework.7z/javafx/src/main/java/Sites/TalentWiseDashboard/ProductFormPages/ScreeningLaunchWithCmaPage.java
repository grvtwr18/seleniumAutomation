package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.AdverseActionHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.List;

/**
 * Page object is to handle initiating Adverse Action with individualized review
 */
public class ScreeningLaunchWithCmaPage extends ScreeningLaunchPage {

    private static final Logger logger = LoggerFactory.getLogger("Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchWithCmaPage");

    @FindBy(how = How.CLASS_NAME, using = "eligibility-note")
    private static WebElement eligibilityNote;

    @FindBy(how = How.ID, using = "btnEligibilityEditSubmit")
    private static WebElement changeEligibilityButton;

    @FindBy(how = How.CSS, using = "table[class='reporttoc flushTop'] > tbody > tr > td[id='status_1'] > span")
    private static WebElement cmaSummaryStatus;

    @FindBy(how = How.CSS, using = "table[class='eligibility'] > tbody > tr > td > div[class='unknown']")
    private static WebElement cmaMessage;

    /**
     * Initialize WebElements
     */
    static {
        PageFactory.initElements(Driver.getDriver(), ScreeningLaunchWithCmaPage.class);
    }

    /**
     * Change the note for the CMA status change
     *
     * @param comment - the comment in the modal
     * @return
     */
    public static String editEligibilityComment(String comment) {
        SeleniumTest.setTextValue(eligibilityNote, comment);
        return SeleniumTest.getText(eligibilityNote);
    }

    /**
     * The status in the report summary
     *
     * @return
     */
    public static String getCmaSummaryStatus() {
        return SeleniumTest.getText(cmaSummaryStatus);
    }

    /**
     * The note added from the modal in the request in the report.
     *
     * @return
     */
    public static String getCmaMessage() {
        return SeleniumTest.getText(cmaMessage);
    }

    /**
     * Commit/Submit the changes for the change in the eligibility - CMA
     *
     * @return
     */
    public static ViewReportPage clickChangeEligibility() {
        SeleniumTest.click(changeEligibilityButton);
        SeleniumTest.waitForElementNotPresent(By.id("btnEligilibityEditSubmit"));
        return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);
    }
}
