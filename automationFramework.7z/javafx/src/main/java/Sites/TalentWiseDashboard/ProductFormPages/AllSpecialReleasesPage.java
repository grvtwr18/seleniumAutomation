package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.CandidatePortal.Enums.Month;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class AllSpecialReleasesPage extends ProductFormPages {
    private static Map<String, String> data;
    private static WebDriver driver;
    private static int timeout = 15;

    static final org.slf4j.Logger staticLogger = LoggerFactory.getLogger(AllSpecialReleasesPage.class);

    @FindBy(xpath = "//span[@id='spanAdd_Group114']/../../a[1]")
    private static WebElement addDotDrugAndAlcoholVerification1;

    @FindBy(xpath = "//span[@id='spanAdd_Group114']/..")
    private static WebElement addDotDrugAndAlcoholVerification2;

    @FindBy(xpath = "//span[@id='spanAdd_Group242']/../../a[1]")
    private static WebElement addReferenceCheck1;

    @FindBy(xpath = "//span[@id='spanAdd_Group242']/..")
    private static WebElement addReferenceCheck2;

    @FindBy(xpath = "//span[@id='spanAdd_Group64']/../../a[1]")
    private static WebElement addWorkersCompensation1;

    @FindBy(xpath = "//span[@id='spanAdd_Group64']/..")
    private static WebElement addWorkersCompensation2;

    @FindBy(name = "qaddinf_Group260-0_1")
    private static WebElement additionalInformation1;

    @FindBy(id = "qshow_Group64-0_1")
    private static WebElement additionalInformation2;

    @FindBy(id = "qaddinf_Group64-0_1")
    private static WebElement additionalInformation3;

    @FindBy(id = "qa")
    private static WebElement address1;

    @FindBy(name = "qca_Group114-0_1")
    private static WebElement address2;

    @FindBy(name = "qinf_Group13-0_1")
    private static WebElement checkTheBoxIfThisIs1;

    @FindBy(name = "qinf_Group24-0_1")
    private static WebElement checkTheBoxIfThisIs2;

    @FindBy(name = "qinf_Group36-0_1")
    private static WebElement checkTheBoxIfThisIs3;

    @FindBy(name = "qinf_Group261-0_1")
    private static WebElement checkTheBoxIfThisIs4;

    @FindBy(id = "qc")
    private static WebElement city1;

    @FindBy(name = "qcc_Group114-0_1")
    private static WebElement city2;

    @FindBy(name = "qcc_Group260-0_1")
    private static WebElement city3;

    @FindBy(css = "#divQuickLaunchModalScreen div:nth-of-type(1) a.modalWindowClose")
    private static WebElement close1;

    @FindBy(css = "#divQuickLaunchModalOnboard div:nth-of-type(1) a.modalWindowClose")
    private static WebElement close2;

    @FindBy(id = "qrefcn_242_1")
    private static WebElement companyName;

    @FindBy(id = "btnSubmit")
    private static WebElement continueButton;

    @FindBy(id = "qo_Group24-0_1")
    private static WebElement country;

    @FindBy(css = "a[class='single-tab single-tab-active']")
    private static WebElement dashboard;

    @FindBy(id = "qmm")
    private static WebElement dateOfBirth1;

    @FindBy(id = "qdd")
    private static WebElement dateOfBirth2;

    @FindBy(id = "qyy")
    private static WebElement dateOfBirth3;

    @FindBy(id = "qjrfl_Group260-0_1")
    private static WebElement reasonForLeaving;

    @FindBy(id = "qnocontact_Group260-0_1")
    private static WebElement doNotContactEmployer;

    @FindBy(id = "qdl_Group13-0_1")
    private static WebElement driversLicense1;

    @FindBy(id = "qdl_Group24-0_1")
    private static WebElement driversLicense2;

    @FindBy(id = "qdl_Group36-0_1")
    private static WebElement driversLicense3;

    @FindBy(id = "qdl_Group261-0_1")
    private static WebElement driversLicense4;

    @FindBy(id = "qee")
    private static WebElement emailAddress1;

    @FindBy(id = "qrefee_242_1")
    private static WebElement emailAddress2;

    @FindBy(id = "qcn_Group114-0_1")
    private static WebElement employerName1;

    @FindBy(id = "qcn_Group260-0_1")
    private static WebElement employerName2;

    @FindBy(id = "qjendmm_Group114-0_1")
    private static WebElement endDate1;

    @FindBy(id = "qjendyy_Group114-0_1")
    private static WebElement endDate2;

    @FindBy(id = "qjendmm_Group260-0_1")
    private static WebElement endDate3;

    @FindBy(id = "qjendyy_Group260-0_1")
    private static WebElement endDate4;

    @FindBy(css = "#uberform div:nth-of-type(2) div.contents div:nth-of-type(1) div:nth-of-type(2) p.flushTop a")
    private static WebElement fairCreditReportingAct1;

    @FindBy(css = "#uberform div:nth-of-type(2) div.contents div:nth-of-type(2) div:nth-of-type(2) p.flushTop a")
    private static WebElement fairCreditReportingAct2;

    @FindBy(id = "qf")
    private static WebElement firstName1;

    @FindBy(id = "qfempalias_Group114-0_1")
    private static WebElement firstName2;

    @FindBy(id = "qfempalias_Group260-0_1")
    private static WebElement firstName3;

    @FindBy(id = "qmf")
    private static WebElement gender;

    @FindBy(id = "qfcramanualagree")
    private static WebElement iHaveProvidedTheIndividualA;

    @FindBy(id = "qshow_Group229-0_1")
    private static WebElement includeConsentbasedSsnVerificationForThe;

    @FindBy(id = "qshow_296_1")
    private static WebElement includeManualProcessingForTheApplicant;

    @FindBy(id = "qshow_Group64-0_1")
    private static WebElement includeWorkersCompensationForTheApplicant;

    @FindBy(name = "qjt_Group114-0_1")
    private static WebElement jobTitle1;

    @FindBy(name = "qjt_Group260-0_1")
    private static WebElement jobTitle2;

    @FindBy(id = "qn")
    private static WebElement lastName1;

    @FindBy(id = "qshow_Group114-0_1")
    private static WebElement lastName2;

    @FindBy(id = "qnempalias_Group114-0_1")
    private static WebElement lastName3;

    @FindBy(id = "qshow_Group260-0_1")
    private static WebElement lastName4;

    @FindBy(id = "qnempalias_Group260-0_1")
    private static WebElement lastName5;

    @FindBy(id = "proxyBoxToggle")
    private static WebElement maximizebtn;

    @FindBy(id = "qmi")
    private static WebElement middleName;

    @FindBy(id = "qrefn_242_1")
    private static WebElement nameOfReference;

    @FindBy(id = "qp")
    private static WebElement phoneNumber1;

    @FindBy(name = "qcp_Group114-0_1")
    private static WebElement phoneNumber2;

    @FindBy(name = "qcp_Group260-0_1")
    private static WebElement phoneNumber3;

    @FindBy(id = "qrefp_242_1")
    private static WebElement phoneNumber4;

    @FindBy(id = "qrefrel_242_1")
    private static WebElement relationshipToCandidate;

    @FindBy(id = "sameascurrent_Group114-0_1")
    private static WebElement sameAsCurrent1;

    @FindBy(id = "sameascurrent_Group260-0_1")
    private static WebElement sameAsCurrent2;

    @FindBy(id = "qfcraedagree")
    private static WebElement sendElectronicDisclosureAndAuthorizationForms;

    @FindBy(css = "#proxybox div.innerbox div:nth-of-type(2) p:nth-of-type(2) a")
    private static WebElement signOut1;

    @FindBy(css = "#userMenu li:nth-of-type(2) a")
    private static WebElement signOut2;

    @FindBy(id = "govtId-value-text")
    private static WebElement socialSecurityNumber;

    @FindBy(id = "usernameLink")
    private static WebElement specialReleases;

    @FindBy(id = "qjstmm_Group114-0_1")
    private static WebElement startDate1;

    @FindBy(id = "qjstyy_Group114-0_1")
    private static WebElement startDate2;

    @FindBy(id = "qjstmm_Group260-0_1")
    private static WebElement startDate3;

    @FindBy(id = "qjstyy_Group260-0_1")
    private static WebElement startDate4;

    @FindBy(id = "qs_Group64-0_1")
    private static WebElement state;

    @FindBy(id = "qs_Group24-0_1_US")
    private static WebElement stateprovince1;

    @FindBy(id = "qs_Group24-0_1_CA")
    private static WebElement stateprovince2;

    @FindBy(id = "qs")
    private static WebElement stateterritory1;

    @FindBy(id = "qs_Group13-0_1")
    private static WebElement stateterritory2;

    @FindBy(id = "qs_Group36-0_1")
    private static WebElement stateterritory3;

    @FindBy(id = "qcs_Group114-0_1")
    private static WebElement stateterritory4;

    @FindBy(id = "qcs_Group260-0_1")
    private static WebElement stateterritory5;

    @FindBy(id = "qs_Group261-0_1")
    private static WebElement stateterritory6;

    @FindBy(id = "qsuffix")
    private static WebElement suffix;

    @FindBy(id = "qshow_Group13-0_1")
    private static WebElement years1;

    @FindBy(id = "qdly_Group13-0_1")
    private static WebElement years2;

    @FindBy(id = "qshow_Group24-0_1")
    private static WebElement years3;

    @FindBy(id = "qdly_Group24-0_1")
    private static WebElement years4;

    @FindBy(id = "qshow_Group36-0_1")
    private static WebElement years5;

    @FindBy(id = "qdly_Group36-0_1")
    private static WebElement years6;

    @FindBy(css = "#divForm_Group261_1 div.contents div:nth-of-type(1) div input[type='checkbox']")
    private static WebElement years7;

    @FindBy(id = "qdly_Group261-0_1")
    private static WebElement years8;

    @FindBy(id = "qz")
    private static WebElement zipCode;

    //Additional Required Information

    @FindBy(id = "qfcramanualagree")
    private static WebElement checkBoxAuthorization;

    @FindBy(id = "qshow_Group41-0_1")
    private static WebElement employerVerificiationCheckbox;

    @FindBy(id = "qcn_Group41-0_1")
    private static WebElement employerNameInputBox;

    @FindBy(id = "qshow_Group39-0_1")
    public WebElement Reportapiemployercheckbox;

    @FindBy(xpath = "//input[@id='qcn_Group39-0_1']")
    private WebElement ReportApiemployerNameInputBox;


    @FindBy(xpath = "//input[@id='qcn_Group41-0_1']")
    private WebElement CombinationofNonAndReportApiemployerNameInputBox;

    @FindBy(id = "qcp_Group39-0_1")
    private WebElement ReportApiemployerphoneNumberInputBox;

    @FindBy(id = "qcp_Group41-0_1")
    private WebElement ReportandNOnReportApiemployerphoneNumberInputBox;

    @FindBy(id = "qcc_Group39-0_1")
    private WebElement ReportApiemployercitydropdown;

    @FindBy(id = "qcc_Group41-0_1")
    private WebElement ReportApiandNonReportApiemployercitydropdown;

    @FindBy(id = "qcs_Group39-0_1")
    private WebElement ReportApiemployerstatedropdown;

    @FindBy(id = "qcs_Group41-0_1")
    private WebElement ReportApiandNonReportApiemployerstatedropdown;

    @FindBy(id = "qjrfl_Group39-0_1")
    private WebElement ReportApiemployerReasonforleaving;

    @FindBy(id = "qjrfl_Group41-0_1")
    private WebElement ReportApiandNonReportApiemployerReasonforleaving;

    @FindBy(id = "qcp_Group41-0_1")
    private WebElement employeePhoneNumberInputBox;

    @FindBy(css = "a#ui-id-2")
    private static WebElement employerSuggestionBox;

    @FindBy(xpath = "//select[@id='qo_Group41-0_1']")
    private static WebElement countryORRegionDropbox;

    @FindBy(id = "qcc_Group41-0_1")
    private static WebElement employeeCityInputBox;

    @FindBy(id = "qcs_Group41-0_1")
    private static WebElement employeeStateDropBox;

    @FindBy(id = "qjt_Group41-0_1")
    private static WebElement jobTitle;

    @FindBy(id = "qjt_Group39-0_1")
    private WebElement ReportApijobTitle;

    @FindBy(id = "qjt_Group41-0_1")
    private WebElement ReportApiandNonReportjobTitle;

    @FindBy(id = "qjstmm_Group41-0_1")
    private WebElement ReportApiandNonReportApistartMonthEmployment;

    @FindBy(id = "qjstyy_Group41-0_1")
    private WebElement ReportApiandNonReportApistartYearEmployment;


    @FindBy(id = "qjstmm_Group39-0_1")
    private WebElement ReportApistartMonthEmployment;

    @FindBy(id = "qjstyy_Group39-0_1")
    private WebElement ReportApistartYearEmployment;

    @FindBy(xpath = "//select[@id='qjendmm_Group39-0_1']")
    private WebElement ReportApiendMonthEmployment;

    @FindBy(xpath = "//select[@id='qjendyy_Group39-0_1']")
    private WebElement ReportAPIendYearEmployment;

    @FindBy(xpath = "//select[@id='qjendmm_Group41-0_1']")
    private WebElement ReportApiandNonReportApiendMonthEmployment;

    @FindBy(xpath = "//select[@id='qjendyy_Group41-0_1']")
    private WebElement ReportAPIandNonReportApiendYearEmployment;

    @FindBy(xpath = "//select[@id='qjrfl_Group41-0_1']")
    private WebElement reasonforLeavingPreviousEmployer;

    @FindBy(id = "qjstmm_Group41-0_1")
    private static WebElement startMonthEmployment;

    @FindBy(id = "qjstyy_Group41-0_1")
    private static WebElement startYearEmployment;

    @FindBy(xpath = "//select[@id='qjendmm_Group41-0_1']")
    private static WebElement endMonthEmployment;

    @FindBy(xpath = "//select[@id='qjendyy_Group41-0_1']")
    private static WebElement endYearEmployment;

    @FindBy(id = "addProduct]")
    private static WebElement addProductBtn;

    @FindBy(xpath = "//span[@class='k-icon k-i-close']]")
    private static WebElement closeIcon;

    //Additional Required Information for Employement for Group17
    @FindBy(id = "qshow_Group17-0_1")
    private static WebElement employerVerificiationCheckboxG17;

    @FindBy(id = "qcn_Group17-0_1")
    private static WebElement employerNameInputBoxG17;

    @FindBy(id = "qcp_Group17-0_1")
    private static WebElement employeePhoneNumberInputBoxG17;

    @FindBy(css = "a#ui-id-1")
    private static WebElement employerSuggestionBoxG17;

    @FindBy(xpath = "//select[@id='qo_Group17-0_1']")
    private static WebElement countryORRegionDropboxG17;

    @FindBy(id = "qcc_Group17-0_1")
    private static WebElement employeeCityInputBoxG17;

    @FindBy(id = "qcs_Group17-0_1")
    private static WebElement employeeStateDropBoxG17;

    @FindBy(id = "qjt_Group17-0_1")
    private static WebElement jobTitleG17;

    @FindBy(xpath = "//select[@id='qjrfl_Group17-0_1']")
    private static WebElement reasonforLeavingPreviousEmployerG17;

    @FindBy(id = "qjstmm_Group17-0_1")
    private static WebElement startMonthEmploymentG17;

    @FindBy(id = "qjstyy_Group17-0_1")
    private static WebElement startYearEmploymentG17;

    @FindBy(xpath = "//select[@id='qjendmm_Group17-0_1']")
    private static WebElement endMonthEmploymentG17;

    @FindBy(xpath = "//select[@id='qjendyy_Group17-0_1']")
    private static WebElement endYearEmploymentG17;

    @FindBy(id = "qsalary_Group41-0_1")
    private static WebElement salaryInputBox;

    @FindBy(id = "qnocontact_Group41-0_1")
    private static WebElement doNotContactEmployerG41;

    @FindBy(id = "sameascurrent_Group41-0_1")
    private static WebElement sameAsCurrentG41;

    static {
        PageFactory.initElements(Driver.getDriver(), AllSpecialReleasesPage.class);
    }

    /**
     * Click on Add Dot Drug And Alcohol Verification Link.
     *
     */
    public static void clickAddDotDrugAndAlcoholVerification1Link() {
        addDotDrugAndAlcoholVerification1.click();
    }

    /**
     * Click on Add Dot Drug And Alcohol Verification Link.
     *
     */
    public static void clickAddDotDrugAndAlcoholVerification2Link() {
        addDotDrugAndAlcoholVerification2.click();
    }


    /**
     * Click on Add Reference Check Link.
     *
     */
    public static void clickAddReferenceCheck1Link() {
        addReferenceCheck1.click();
    }

    /**
     * Click on Add Reference Check Link.
     *
     */
    public static void clickAddReferenceCheck2Link() {
        addReferenceCheck2.click();
    }

    /**
     * Click on Add Workers Compensation Link.
     *
     */
    public static void clickAddWorkersCompensation1Link() {
        addWorkersCompensation1.click();
    }

    /**
     * Click on Add Workers Compensation Link.
     *
     */
    public static void clickAddWorkersCompensation2Link() {
        addWorkersCompensation2.click();
    }

    /**
     * Click on Close Link.
     *
     */
    public static void clickClose1Link() {
        close1.click();
    }

    /**
     * Click on Close Link.
     *
     */
    public static void clickClose2Link() {
        close2.click();
    }

    /**
     * Click on Continue Button.
     *
     */
    public static void clickContinueButton() {
        continueButton.click();
        PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        //return this;
    }

    /**
     * Click on Dashboard Link.
     *
     */
    public static void clickDashboardLink() {
        dashboard.click();
    }

    /**
     * Click on Fair Credit Reporting Act Link.
     *
     */
    public static void clickFairCreditReportingAct1Link() {
        fairCreditReportingAct1.click();
    }

    /**
     * Click on Fair Credit Reporting Act Link.
     *
     */
    public static void clickFairCreditReportingAct2Link() {
        fairCreditReportingAct2.click();
    }

    /**
     * Click on Maximizebtn Link.
     *
     */
    public static void clickMaximizebtnLink() {
        maximizebtn.click();
    }

    /**
     * Fill every fields in the page.
     *
     */
    public static void fill() {
        setIHaveProvidedTheIndividualACheckboxField();
        setSendElectronicDisclosureAndAuthorizationFormsCheckboxField();
        setFirstName1TextField();
        setMiddleNameTextField();
        setLastName1CheckboxField();
        setSuffixTextField();
        setSocialSecurityNumberTextField();
        setDateOfBirth1DropDownListField();
        setDateOfBirth2DropDownListField();
        setDateOfBirth3DropDownListField();
        setGenderDropDownListField();
        setPhoneNumber1TextField();
        setEmailAddress1TextField();
        setAddress1TextField();
        setCity1TextField();
        setStateterritory1DropDownListField();
        setZipCodeTextField();
        setIncludeConsentbasedSsnVerificationForTheCheckboxField();
        setYears1DropDownListField();
        setStateterritory2DropDownListField();
        setDriversLicense1TextField();
        setYears2DropDownListField();
        setCheckTheBoxIfThisIs1CheckboxField();
        setYears3CheckboxField();
        setCountryDropDownListField();
        setStateprovince1DropDownListField();
        setStateprovince2DropDownListField();
        setDriversLicense2TextField();
        setYears4DropDownListField();
        setCheckTheBoxIfThisIs2CheckboxField();
        setYears5CheckboxField();
        setStateterritory3DropDownListField();
        setDriversLicense3TextField();
        setYears6DropDownListField();
        setCheckTheBoxIfThisIs3CheckboxField();
        setLastName2CheckboxField();
        setEmployerName1TextField();
        setPhoneNumber2TextField();
        setAddress2TextField();
        setCity2TextField();
        setStateterritory4DropDownListField();
        setJobTitle1TextField();
        setStartDate1DropDownListField();
        setStartDate2DropDownListField();
        setEndDate1DropDownListField();
        setEndDate2DropDownListField();
        setSameAsCurrent1CheckboxField();
        setFirstName2TextField();
        setLastName3TextField();
        setIncludeManualProcessingForTheApplicantCheckboxField();
        setLastName4CheckboxField();
        setEmployerName2TextField();
        setPhoneNumber3TextField();
        setCity3TextField();
        setStateterritory5DropDownListField();
        setJobTitle2TextField();
        setDoNotContactEmployerCheckboxField();
        setStartDate3DropDownListField();
        setStartDate4DropDownListField();
        setEndDate3DropDownListField();
        setEndDate4DropDownListField();
        setAdditionalInformation1CheckboxField();
        setSameAsCurrent2CheckboxField();
        setFirstName3TextField();
        setLastName5TextField();
        setYears7CheckboxField();
        setStateterritory6DropDownListField();
        setDriversLicense4TextField();
        setYears8DropDownListField();
        setCheckTheBoxIfThisIs4CheckboxField();
        setRelationshipToCandidateTextField();
        setNameOfReferenceTextField();
        setPhoneNumber4TextField();
        setEmailAddress2TextField();
        setCompanyNameTextField();
        setAdditionalInformation2CheckboxField();
        setStateDropDownListField();
        setAdditionalInformation3TextField();
    }

    /**
     * Fill every fields in the page and submit it to target page.
     *
     */
    public static void fillAndSubmit() {
        fill();
        submit();
    }

    /**
     * Set default value to Additional Information Text field.
     *
     */
    public static void setAdditionalInformation1CheckboxField() {
        setAdditionalInformation1CheckboxField(data.get("ADDITIONAL_INFORMATION"));
    }

    /**
     * Set Additional Information Checkbox field.
     *
     */
    public static void setAdditionalInformation1CheckboxField(String additionalInformationValue) {
        additionalInformation1.sendKeys(additionalInformationValue);
    }

    /**
     * Set Additional Information Checkbox field.
     *
     */
    public static void setAdditionalInformation2CheckboxField() {
        SeleniumTest.check(additionalInformation2);
    }

    /**
     * Set default value to Additional Information Text field.
     *
     */
    public static void setAdditionalInformation3TextField() {
        setAdditionalInformation3TextField(data.get("ADDITIONAL_INFORMATION_3"));
    }

    /**
     * Set value to Additional Information Text field.
     *
     */
    public static void setAdditionalInformation3TextField(String additionalInformation3Value) {
        additionalInformation3.sendKeys(additionalInformation3Value);
    }

    /**
     * Set default value to Address Text field.
     *
     */
    public static void setAddress1TextField() {
        setAddress1TextField(data.get("ADDRESS_1"));
    }

    /**
     * Set value to Address Text field.
     *
     */
    public static void setAddress1TextField(String address1Value) {
        address1.sendKeys(address1Value);
    }

    /**
     * Set default value to Address Text field.
     *
     */
    public static void setAddress2TextField() {
        setAddress2TextField(data.get("ADDRESS_2"));
    }

    /**
     * Set value to Address Text field.
     *
     */
    public static void setAddress2TextField(String address2Value) {
        address2.sendKeys(address2Value);
    }

    /**
     * Set Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void setCheckTheBoxIfThisIs1CheckboxField() {
        SeleniumTest.check(checkTheBoxIfThisIs1);
    }

    /**
     * Set Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void setCheckTheBoxIfThisIs2CheckboxField() {
        SeleniumTest.check(checkTheBoxIfThisIs2);
    }

    /**
     * Set Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void setCheckTheBoxIfThisIs3CheckboxField() {
        SeleniumTest.check(checkTheBoxIfThisIs3);
    }

    /**
     * Set Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void setCheckTheBoxIfThisIs4CheckboxField() {
        SeleniumTest.check(checkTheBoxIfThisIs4);
    }

    /**
     * Set default value to City Text field.
     *
     */
    public static void setCity1TextField() {
        setCity1TextField(data.get("CITY_1"));
    }

    /**
     * Set value to City Text field.
     *
     */
    public static void setCity1TextField(String city1Value) {
        city1.sendKeys(city1Value);
    }

    /**
     * Set default value to City Text field.
     *
     */
    public static void setCity2TextField() {
        setCity2TextField(data.get("CITY_2"));
    }

    /**
     * Set value to City Text field.
     *
     */
    public static void setCity2TextField(String city2Value) {
        city2.sendKeys(city2Value);
    }

    /**
     * Set default value to City Text field.
     *
     */
    public static void setCity3TextField() {
        setCity3TextField(data.get("CITY_3"));
    }

    /**
     * Set value to City Text field.
     *
     */
    public static void setCity3TextField(String city3Value) {
        city3.sendKeys(city3Value);
    }

    /**
     * Set default value to Company Name Text field.
     *
     */
    public static void setCompanyNameTextField() {
        setCompanyNameTextField(data.get("COMPANY_NAME"));
    }

    /**
     * Set value to Company Name Text field.
     *
     */
    public static void setCompanyNameTextField(String companyNameValue) {
        companyName.sendKeys(companyNameValue);
    }

    /**
     * Set default value to Country Drop Down List field.
     *
     */
    public static void setCountryDropDownListField() {
        setCountryDropDownListField(data.get("COUNTRY"));
    }

    /**
     * Set value to Country Drop Down List field.
     *
     */
    public static void setCountryDropDownListField(String countryValue) {
        new Select(country).selectByVisibleText(countryValue);
    }

    /**
     * Set default value to Date Of Birth Drop Down List field.
     *
     */
    public static void setDateOfBirth1DropDownListField() {
        setDateOfBirth1DropDownListField(data.get("DATE_OF_BIRTH_1"));
    }

    /**
     * Set value to Date Of Birth Drop Down List field.
     *
     */
    public static void setDateOfBirth1DropDownListField(String dateOfBirth1Value) {
        // The following converts strings like "Sep" to "Sept" ...
        dateOfBirth1Value = Month.parse(dateOfBirth1Value).abbreviation();
        SeleniumTest.selectByVisibleTextFromDropDown(dateOfBirth1, dateOfBirth1Value);
    }

    /**
     * Set default value to Date Of Birth Drop Down List field.
     *
     */
    public static void setDateOfBirth2DropDownListField() {
        setDateOfBirth2DropDownListField(data.get("DATE_OF_BIRTH_2"));
    }

    /**
     * Set value to Date Of Birth Drop Down List field.
     *
     */
    public static void setDateOfBirth2DropDownListField(String dateOfBirth2Value) {
        new Select(dateOfBirth2).selectByVisibleText(dateOfBirth2Value);
    }

    /**
     * Set default value to Date Of Birth Drop Down List field.
     *
     */
    public static void setDateOfBirth3DropDownListField() {
        setDateOfBirth3DropDownListField(data.get("DATE_OF_BIRTH_3"));
    }

    /**
     * Set value to Date Of Birth Drop Down List field.
     *
     */
    public static void setDateOfBirth3DropDownListField(String dateOfBirth3Value) {
        new Select(dateOfBirth3).selectByVisibleText(dateOfBirth3Value);
    }

    /**
     * Set default value to Reason For Leaving Drop Down List field.
     *
     */
    public static void setReasonForLeaving(String reasonForLeavingValue) {
        new Select(reasonForLeaving).selectByVisibleText(reasonForLeavingValue);
    }

    /**
     * Set Do Not Contact Employer Checkbox field.
     *
     */
    public static void setDoNotContactEmployer1CheckboxField(String doNotContactEmployerValue) {
        new Select(doNotContactEmployer).selectByVisibleText(doNotContactEmployerValue);
    }

    /**
     * Set Do Not Contact Employer Checkbox field.
     *
     */
    public static void setDoNotContactEmployerCheckboxField() {
        SeleniumTest.check(doNotContactEmployer);
    }

    /**
     * Set default value to Drivers License Text field.
     *
     */
    public static void setDriversLicense1TextField() {
        setDriversLicense1TextField(data.get("DRIVERS_LICENSE_1"));
    }

    /**
     * Set value to Drivers License Text field.
     *
     */
    public static void setDriversLicense1TextField(String driversLicense1Value) {
        driversLicense1.sendKeys(driversLicense1Value);
    }

    /**
     * Set default value to Drivers License Text field.
     *
     */
    public static void setDriversLicense2TextField() {
        setDriversLicense2TextField(data.get("DRIVERS_LICENSE_2"));
    }

    /**
     * Set value to Drivers License Text field.
     *
     */
    public static void setDriversLicense2TextField(String driversLicense2Value) {
        SeleniumTest.clearAndSetText(driversLicense2, driversLicense2Value);
    }

    /**
     * Set default value to Drivers License Text field.
     *
     */
    public static void setDriversLicense3TextField() {
        setDriversLicense3TextField(data.get("DRIVERS_LICENSE_3"));
    }

    /**
     * Set value to Drivers License Text field.
     *
     */
    public static void setDriversLicense3TextField(String driversLicense3Value) {
        driversLicense3.sendKeys(driversLicense3Value);
    }

    /**
     * Set default value to Drivers License Text field.
     *
     */
    public static void setDriversLicense4TextField() {
        setDriversLicense4TextField(data.get("DRIVERS_LICENSE_4"));
    }

    /**
     * Set value to Drivers License Text field.
     *
     */
    public static void setDriversLicense4TextField(String driversLicense4Value) {
        driversLicense4.sendKeys(driversLicense4Value);
    }

    /**
     * Set default value to Email Address Text field.
     *
     */
    public static void setEmailAddress1TextField() {
        setEmailAddress1TextField(data.get("EMAIL_ADDRESS_1"));
    }

    /**
     * Set value to Email Address Text field.
     *
     */
    public static void setEmailAddress1TextField(String emailAddress1Value) {
        emailAddress1.sendKeys(emailAddress1Value);
    }

    /**
     * Set default value to Email Address Text field.
     *
     */
    public static void setEmailAddress2TextField() {
        setEmailAddress2TextField(data.get("EMAIL_ADDRESS_2"));
    }

    /**
     * Set value to Email Address Text field.
     *
     */
    public static void setEmailAddress2TextField(String emailAddress2Value) {
        emailAddress2.sendKeys(emailAddress2Value);
    }

    /**
     * Set default value to Employer Name Text field.
     *
     */
    public static void setEmployerName1TextField() {
        setEmployerName1TextField(data.get("EMPLOYER_NAME_1"));
    }

    /**
     * Set value to Employer Name Text field.
     *
     */
    public static void setEmployerName1TextField(String employerName1Value) {
        employerName1.sendKeys(employerName1Value);
    }

    /**
     * Set default value to Employer Name Text field.
     *
     */
    public static void setEmployerName2TextField() {
        setEmployerName2TextField(data.get("EMPLOYER_NAME_2"));
    }

    /**
     * Set value to Employer Name Text field.
     *
     */
    public static void setEmployerName2TextField(String employerName2Value) {
        employerName2.sendKeys(employerName2Value);
    }

    /**
     * Set default value to End Date Drop Down List field.
     *
     */
    public static void setEndDate1DropDownListField() {
        setEndDate1DropDownListField(data.get("END_DATE_1"));
    }

    /**
     * Set value to End Date Drop Down List field.
     *
     */
    public static void setEndDate1DropDownListField(String endDate1Value) {
        new Select(endDate1).selectByVisibleText(endDate1Value);
    }

    /**
     * Set default value to End Date Drop Down List field.
     *
     */
    public static void setEndDate2DropDownListField() {
        setEndDate2DropDownListField(data.get("END_DATE_2"));
    }

    /**
     * Set value to End Date Drop Down List field.
     *
     */
    public static void setEndDate2DropDownListField(String endDate2Value) {
        new Select(endDate2).selectByVisibleText(endDate2Value);
    }

    /**
     * Set default value to End Date Drop Down List field.
     *
     */
    public static void setEndDate3DropDownListField() {
        setEndDate3DropDownListField(data.get("END_DATE_3"));
    }

    /**
     * Set value to End Date Drop Down List field.
     *
     */
    public static void setEndDate3DropDownListField(String endDate3Value) {
        new Select(endDate3).selectByVisibleText(endDate3Value);
    }

    /**
     * Set default value to End Date Drop Down List field.
     *
     */
    public static void setEndDate4DropDownListField() {
        setEndDate4DropDownListField(data.get("END_DATE_4"));
    }

    /**
     * Set value to End Date Drop Down List field.
     *
     */
    public static void setEndDate4DropDownListField(String endDate4Value) {
        new Select(endDate4).selectByVisibleText(endDate4Value);
    }

    /**
     * Set default value to First Name Text field.
     *
     */
    public static void setFirstName1TextField() {
        setFirstName1TextField(data.get("FIRST_NAME_1"));
    }

    /**
     * Set value to First Name Text field.
     *
     */
    public static void setFirstName1TextField(String firstName1Value) {
        firstName1.sendKeys(firstName1Value);
    }

    /**
     * Set default value to First Name Text field.
     *
     */
    public static void setFirstName2TextField() {
        setFirstName2TextField(data.get("FIRST_NAME_2"));
    }

    /**
     * Set value to First Name Text field.
     *
     */
    public static void setFirstName2TextField(String firstName2Value) {
        firstName2.sendKeys(firstName2Value);
    }

    /**
     * Set default value to First Name Text field.
     *
     */
    public static void setFirstName3TextField() {
        setFirstName3TextField(data.get("FIRST_NAME_3"));
    }

    /**
     * Set value to First Name Text field.
     *
     */
    public static void setFirstName3TextField(String firstName3Value) {
        firstName3.sendKeys(firstName3Value);
    }

    /**
     * Set default value to Gender Drop Down List field.
     *
     */
    public static void setGenderDropDownListField() {
        setGenderDropDownListField(data.get("GENDER"));
    }

    /**
     * Set value to Gender Drop Down List field.
     *
     */
    public static void setGenderDropDownListField(String genderValue) {
        new Select(gender).selectByVisibleText(genderValue);
    }

    /**
     * Set I Have Provided The Individual A Disclosure And Received The Individuals Written Authorization For The Report I Certify That 1 A Clear And Conspicuous Disclosure Was Made To The Consumer In A Document Consisting Solely Of The Disclosure 2 The Disclosure Satisfied All Fair Credit Reporting Act And Other Legal Requirements 3 The Report Will Not Be Used In Violation Of Any Applicable Federal Or State Equal Employment Opportunity Law Or Regulation And Its Use Will Comply With All Applicable Laws And 4 I Understand My Obligations Have Complied With And Will Comply With All Applicable Laws Pertaining To Consumer Reportsinvestigative Consumer Reports As Defined In The Fair Credit Reporting Act As Amended Checkbox field.
     *
     */
    public static void setIHaveProvidedTheIndividualACheckboxField() {
        SeleniumTest.check(iHaveProvidedTheIndividualA);
    }

    /**
     * Set Include Consentbased Ssn Verification For The Applicant Profiled Above Not Included Check The Box To Include Checkbox field.
     *
     */
    public static void setIncludeConsentbasedSsnVerificationForTheCheckboxField() {
        SeleniumTest.check(includeConsentbasedSsnVerificationForThe);
    }

    /**
     * Set Include Manual Processing For The Applicant Profiled Above Not Included Check The Box To Include Checkbox field.
     *
     */
    public static void setIncludeManualProcessingForTheApplicantCheckboxField() {
        SeleniumTest.check(includeManualProcessingForTheApplicant);
    }

    /**
     * Set Include Workers Compensation For The Applicant Profiled Above Not Included Check The Box To Include Checkbox field.
     *
     */
    public static void setIncludeWorkersCompensationForTheApplicantCheckboxField() {
        SeleniumTest.check(includeWorkersCompensationForTheApplicant);
    }

    /**
     * Set default value to Job Title Text field.
     *
     */
    public static void setJobTitle1TextField() {
        setJobTitle1TextField(data.get("JOB_TITLE_1"));
    }

    /**
     * Set value to Job Title Text field.
     *
     */
    public static void setJobTitle1TextField(String jobTitle1Value) {
        jobTitle1.sendKeys(jobTitle1Value);
    }

    /**
     * Set default value to Job Title Text field.
     *
     */
    public static void setJobTitle2TextField() {
        setJobTitle2TextField(data.get("JOB_TITLE_2"));
    }

    /**
     * Set value to Job Title Text field.
     *
     */
    public static void setJobTitle2TextField(String jobTitle2Value) {
        jobTitle2.sendKeys(jobTitle2Value);
    }

    /**
     * Set default value to Last Name Text field.
     *
     */
    public static void setLastName1CheckboxField() {
        setLastName1CheckboxField(data.get("LAST_NAME"));
    }

    /**
     * Set Last Name Checkbox field.
     *
     */
    public static void setLastName1CheckboxField(String lastNameValue) {
        lastName1.sendKeys(lastNameValue);
    }

    /**
     * Set Last Name Checkbox field.
     *
     */
    public static void setLastName2CheckboxField() {
        SeleniumTest.check(lastName2);
    }

    /**
     * Set default value to Last Name Text field.
     *
     */
    public static void setLastName3TextField() {
        setLastName3TextField(data.get("LAST_NAME_3"));
    }

    /**
     * Set value to Last Name Text field.
     *
     */
    public static void setLastName3TextField(String lastName3Value) {
        lastName3.sendKeys(lastName3Value);
    }

    /**
     * Set Last Name Checkbox field.
     *
     */
    public static void setLastName4CheckboxField() {
        SeleniumTest.check(lastName4);
    }

    /**
     * Set default value to Last Name Text field.
     *
     */
    public static void setLastName5TextField() {
        setLastName5TextField(data.get("LAST_NAME_5"));
    }

    /**
     * Set value to Last Name Text field.
     *
     */
    public static void setLastName5TextField(String lastName5Value) {
        lastName5.sendKeys(lastName5Value);
    }

    /**
     * Set default value to Middle Name Text field.
     *
     */
    public static void setMiddleNameTextField() {
        setMiddleNameTextField(data.get("MIDDLE_NAME"));
    }

    /**
     * Set value to Middle Name Text field.
     *
     */
    public static void setMiddleNameTextField(String middleNameValue) {
        middleName.sendKeys(middleNameValue);
    }

    /**
     * Set default value to Name Of Reference Text field.
     *
     */
    public static void setNameOfReferenceTextField() {
        setNameOfReferenceTextField(data.get("NAME_OF_REFERENCE"));
    }

    /**
     * Set value to Name Of Reference Text field.
     *
     */
    public static void setNameOfReferenceTextField(String nameOfReferenceValue) {
        nameOfReference.sendKeys(nameOfReferenceValue);
    }

    /**
     * Set default value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber1TextField() {
        setPhoneNumber1TextField(data.get("PHONE_NUMBER_1"));
    }

    /**
     * Set value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber1TextField(String phoneNumber1Value) {
        phoneNumber1.sendKeys(phoneNumber1Value);
    }

    /**
     * Set default value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber2TextField() {
        setPhoneNumber2TextField(data.get("PHONE_NUMBER_2"));
    }

    /**
     * Set value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber2TextField(String phoneNumber2Value) {
        phoneNumber2.sendKeys(phoneNumber2Value);
    }

    /**
     * Set default value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber3TextField() {
        setPhoneNumber3TextField(data.get("PHONE_NUMBER_3"));
    }

    /**
     * Set value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber3TextField(String phoneNumber3Value) {
        phoneNumber3.sendKeys(phoneNumber3Value);
    }

    /**
     * Set default value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber4TextField() {
        setPhoneNumber4TextField(data.get("PHONE_NUMBER_4"));
    }

    /**
     * Set value to Phone Number Text field.
     *
     */
    public static void setPhoneNumber4TextField(String phoneNumber4Value) {
        phoneNumber4.sendKeys(phoneNumber4Value);
    }

    /**
     * Set default value to Relationship To Candidate Text field.
     *
     */
    public static void setRelationshipToCandidateTextField() {
        setRelationshipToCandidateTextField(data.get("RELATIONSHIP_TO_CANDIDATE"));
    }

    /**
     * Set value to Relationship To Candidate Text field.
     *
     */
    public static void setRelationshipToCandidateTextField(String relationshipToCandidateValue) {
        relationshipToCandidate.sendKeys(relationshipToCandidateValue);
    }

    /**
     * Set Same As Current Checkbox field.
     *
     */
    public static void setSameAsCurrent1CheckboxField() {
        SeleniumTest.check(sameAsCurrent1);
    }

    /**
     * Set Same As Current Checkbox field.
     *
     */
    public static void setSameAsCurrent2CheckboxField() {
        SeleniumTest.check(sameAsCurrent2);
    }

    /**
     * Set Send Electronic Disclosure And Authorization Forms To This Individual At The Email Given Below I Certify That 1 The Disclosure And Authorization Forms Have Been Reviewed By My Company And Legal Counsel And They Satisfy All Fair Credit Reporting Act And Other Legal Requirements Including A Clear And Conspicuous Disclosure In A Document That Consists Solely Of The Disclosure 2 My Order Should Not Be Processed Before This Written Disclosure Has Been Made To The Consumer And His Or Her Authorization Obtained In Writing 3 The Report Will Not Be Used In Violation Of Any Applicable Federal Or State Equal Employment Opportunity Law Or Regulation And Its Use Will Comply With All Applicable Laws And 4 I Understand My Obligations Have Complied With And Will Comply With All Applicable Laws Pertaining To Consumer Reportsinvestigative Consumer Reports As Defined In The Fair Credit Reporting Act As Amended Checkbox field.
     *
     */
    public static void setSendElectronicDisclosureAndAuthorizationFormsCheckboxField() {
        SeleniumTest.check(sendElectronicDisclosureAndAuthorizationForms);
    }

    /**
     * Set default value to Social Security Number Text field.
     *
     */
    public static void setSocialSecurityNumberTextField() {
        setSocialSecurityNumberTextField(data.get("SOCIAL_SECURITY_NUMBER"));
    }

    /**
     * Set value to Social Security Number Text field.
     *
     */
    public static void setSocialSecurityNumberTextField(String socialSecurityNumberValue) {
        socialSecurityNumber.sendKeys(socialSecurityNumberValue);
    }

    /**
     * Set default value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate1DropDownListField() {
        setStartDate1DropDownListField(data.get("START_DATE_1"));
    }

    /**
     * Set value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate1DropDownListField(String startDate1Value) {
        new Select(startDate1).selectByVisibleText(startDate1Value);
    }

    /**
     * Set default value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate2DropDownListField() {
        setStartDate2DropDownListField(data.get("START_DATE_2"));
    }

    /**
     * Set value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate2DropDownListField(String startDate2Value) {
        new Select(startDate2).selectByVisibleText(startDate2Value);
    }

    /**
     * Set default value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate3DropDownListField() {
        setStartDate3DropDownListField(data.get("START_DATE_3"));
    }

    /**
     * Set value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate3DropDownListField(String startDate3Value) {
        new Select(startDate3).selectByVisibleText(startDate3Value);
    }

    /**
     * Set default value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate4DropDownListField() {
        setStartDate4DropDownListField(data.get("START_DATE_4"));
    }

    /**
     * Set value to Start Date Drop Down List field.
     *
     */
    public static void setStartDate4DropDownListField(String startDate4Value) {
        new Select(startDate4).selectByVisibleText(startDate4Value);
    }

    /**
     * Set default value to State Drop Down List field.
     *
     */
    public static void setStateDropDownListField() {
        setStateDropDownListField(data.get("STATE"));
    }

    /**
     * Set value to State Drop Down List field.
     *
     */
    public static void setStateDropDownListField(String stateValue) {
        new Select(state).selectByVisibleText(stateValue);
    }

    /**
     * Set default value to Stateprovince Drop Down List field.
     *
     */
    public static void setStateprovince1DropDownListField() {
        setStateprovince1DropDownListField(data.get("STATEPROVINCE_1"));
    }

    /**
     * Set value to Stateprovince Drop Down List field.
     *
     */
    public static void setStateprovince1DropDownListField(String stateprovince1Value) {
        new Select(stateprovince1).selectByVisibleText(stateprovince1Value);
    }

    /**
     * Set default value to Stateprovince Drop Down List field.
     *
     */
    public static void setStateprovince2DropDownListField() {
        setStateprovince2DropDownListField(data.get("STATEPROVINCE_2"));
    }

    /**
     * Set value to Stateprovince Drop Down List field.
     *
     */
    public static void setStateprovince2DropDownListField(String stateprovince2Value) {
        new Select(stateprovince2).selectByVisibleText(stateprovince2Value);
    }

    /**
     * Set default value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory1DropDownListField() {
        setStateterritory1DropDownListField(data.get("STATETERRITORY_1"));
    }

    /**
     * Set value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory1DropDownListField(String stateterritory1Value) {
        new Select(stateterritory1).selectByVisibleText(stateterritory1Value);
    }

    /**
     * Set default value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory2DropDownListField() {
        setStateterritory2DropDownListField(data.get("STATETERRITORY_2"));
    }

    /**
     * Set value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory2DropDownListField(String stateterritory2Value) {
        new Select(stateterritory2).selectByVisibleText(stateterritory2Value);
    }

    /**
     * Set default value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory3DropDownListField() {
        setStateterritory3DropDownListField(data.get("STATETERRITORY_3"));
    }

    /**
     * Set value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory3DropDownListField(String stateterritory3Value) {
        new Select(stateterritory3).selectByVisibleText(stateterritory3Value);
    }

    /**
     * Set default value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory4DropDownListField() {
        setStateterritory4DropDownListField(data.get("STATETERRITORY_4"));
    }

    /**
     * Set value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory4DropDownListField(String stateterritory4Value) {
        new Select(stateterritory4).selectByVisibleText(stateterritory4Value);
    }

    /**
     * Set default value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory5DropDownListField() {
        setStateterritory5DropDownListField(data.get("STATETERRITORY_5"));
    }

    /**
     * Set value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory5DropDownListField(String stateterritory5Value) {
        new Select(stateterritory5).selectByVisibleText(stateterritory5Value);
    }

    /**
     * Set default value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory6DropDownListField() {
        setStateterritory6DropDownListField(data.get("STATETERRITORY_6"));
    }

    /**
     * Set value to Stateterritory Drop Down List field.
     *
     */
    public static void setStateterritory6DropDownListField(String stateterritory6Value) {
        new Select(stateterritory6).selectByVisibleText(stateterritory6Value);
    }

    /**
     * Set default value to Suffix Text field.
     *
     */
    public static void setSuffixTextField() {
        setSuffixTextField(data.get("SUFFIX"));
    }

    /**
     * Set value to Suffix Text field.
     *
     */
    public static void setSuffixTextField(String suffixValue) {
        suffix.sendKeys(suffixValue);
    }

    /**
     * Set default value to Years Drop Down List field.
     *
     */
    public static void setYears1DropDownListField() {
        setYears1DropDownListField(data.get("YEARS_1"));
    }

    /**
     * Set value to Years Drop Down List field.
     *
     */
    public static void setYears1DropDownListField(String years1Value) {
        new Select(years1).selectByVisibleText(years1Value);
    }

    /**
     * Set default value to Years Drop Down List field.
     *
     */
    public static void setYears2DropDownListField() {
        setYears2DropDownListField(data.get("YEARS_2"));
    }

    /**
     * Set value to Years Drop Down List field.
     *
     */
    public static void setYears2DropDownListField(String years2Value) {
        new Select(years2).selectByVisibleText(years2Value);
    }

    /**
     * Set Years Checkbox field.
     *
     */
    public static void setYears3CheckboxField() {
        SeleniumTest.check(years3);
    }

    /**
     * Set default value to Years Drop Down List field.
     *
     */
    public static void setYears4DropDownListField() {
        setYears4DropDownListField(data.get("YEARS_4"));
    }

    /**
     * Set value to Years Drop Down List field.
     *
     */
    public static void setYears4DropDownListField(String years4Value) {
        new Select(years4).selectByVisibleText(years4Value);
    }

    /**
     * Set Years Checkbox field.
     *
     */
    public static void setYears5CheckboxField() {
        SeleniumTest.check(years5);
    }

    /**
     * Set default value to Years Drop Down List field.
     *
     */
    public static void setYears6DropDownListField() {
        setYears6DropDownListField(data.get("YEARS_6"));
    }

    /**
     * Set value to Years Drop Down List field.
     *
     */
    public static void setYears6DropDownListField(String years6Value) {
        new Select(years6).selectByVisibleText(years6Value);
    }

    /**
     * Set Years Checkbox field.
     *
     */
    public static void setYears7CheckboxField() {
        SeleniumTest.check(years7);
    }

    /**
     * Set default value to Years Drop Down List field.
     *
     */
    public static void setYears8DropDownListField() {
        setYears8DropDownListField(data.get("YEARS_8"));
    }

    /**
     * Set value to Years Drop Down List field.
     *
     */
    public static void setYears8DropDownListField(String years8Value) {
        new Select(years8).selectByVisibleText(years8Value);
    }

    /**
     * Set default value to Zip Code Text field.
     *
     */
    public static void setZipCodeTextField() {
        setZipCodeTextField(data.get("ZIP_CODE"));
    }

    /**
     * Set value to Zip Code Text field.
     *
     */
    public static void setZipCodeTextField(String zipCodeValue) {
        zipCode.sendKeys(zipCodeValue);
    }

    public static void submit() {
        clickContinueButton();
    }

    /**
     * Unset Additional Information Checkbox field.
     *
     */
    public static void unsetAdditionalInformation2CheckboxField() {
        SeleniumTest.unCheck(additionalInformation2);
    }

    /**
     * Unset Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void unsetCheckTheBoxIfThisIs1CheckboxField() {
        SeleniumTest.unCheck(checkTheBoxIfThisIs1);
    }

    /**
     * Unset Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void unsetCheckTheBoxIfThisIs2CheckboxField() {
        SeleniumTest.unCheck(checkTheBoxIfThisIs2);
    }

    /**
     * Unset Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void unsetCheckTheBoxIfThisIs3CheckboxField() {
        SeleniumTest.unCheck(checkTheBoxIfThisIs3);
    }

    /**
     * Unset Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     */
    public static void unsetCheckTheBoxIfThisIs4CheckboxField() {
        SeleniumTest.unCheck(checkTheBoxIfThisIs4);
    }

    /**
     * Unset default value from Country Drop Down List field.
     *
     */
    public static void unsetCountryDropDownListField() {
        unsetCountryDropDownListField(data.get("COUNTRY"));
    }

    /**
     * Unset value from Country Drop Down List field.
     *
     */
    public static void unsetCountryDropDownListField(String countryValue) {
        new Select(country).deselectByVisibleText(countryValue);
    }

    /**
     * Unset default value from Date Of Birth Drop Down List field.
     *
     */
    public static void unsetDateOfBirth1DropDownListField() {
        unsetDateOfBirth1DropDownListField(data.get("DATE_OF_BIRTH_1"));
    }

    /**
     * Unset value from Date Of Birth Drop Down List field.
     *
     */
    public static void unsetDateOfBirth1DropDownListField(String dateOfBirth1Value) {
        new Select(dateOfBirth1).deselectByVisibleText(dateOfBirth1Value);
    }

    /**
     * Unset default value from Date Of Birth Drop Down List field.
     *
     */
    public static void unsetDateOfBirth2DropDownListField() {
        unsetDateOfBirth2DropDownListField(data.get("DATE_OF_BIRTH_2"));
    }

    /**
     * Unset value from Date Of Birth Drop Down List field.
     *
     */
    public static void unsetDateOfBirth2DropDownListField(String dateOfBirth2Value) {
        new Select(dateOfBirth2).deselectByVisibleText(dateOfBirth2Value);
    }

    /**
     * Unset default value from Date Of Birth Drop Down List field.
     *
     */
    public static void unsetDateOfBirth3DropDownListField() {
        unsetDateOfBirth3DropDownListField(data.get("DATE_OF_BIRTH_3"));
    }

    /**
     * Unset value from Date Of Birth Drop Down List field.
     *
     */
    public static void unsetDateOfBirth3DropDownListField(String dateOfBirth3Value) {
        new Select(dateOfBirth3).deselectByVisibleText(dateOfBirth3Value);
    }

    /**
     *
     */
    public static void unsetDoNotContactEmployer1CheckboxField(String doNotContactEmployerValue) {
        new Select(doNotContactEmployer).deselectByVisibleText(doNotContactEmployerValue);
    }

    /**
     * Unset default value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate1DropDownListField() {
        unsetEndDate1DropDownListField(data.get("END_DATE_1"));
    }

    /**
     * Unset value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate1DropDownListField(String endDate1Value) {
        new Select(endDate1).deselectByVisibleText(endDate1Value);
    }

    /**
     * Unset default value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate2DropDownListField() {
        unsetEndDate2DropDownListField(data.get("END_DATE_2"));
    }

    /**
     * Unset value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate2DropDownListField(String endDate2Value) {
        new Select(endDate2).deselectByVisibleText(endDate2Value);
    }

    /**
     * Unset default value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate3DropDownListField() {
        unsetEndDate3DropDownListField(data.get("END_DATE_3"));
    }

    /**
     * Unset value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate3DropDownListField(String endDate3Value) {
        new Select(endDate3).deselectByVisibleText(endDate3Value);
    }

    /**
     * Unset default value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate4DropDownListField() {
        unsetEndDate4DropDownListField(data.get("END_DATE_4"));
    }

    /**
     * Unset value from End Date Drop Down List field.
     *
     */
    public static void unsetEndDate4DropDownListField(String endDate4Value) {
        new Select(endDate4).deselectByVisibleText(endDate4Value);
    }

    /**
     * Unset default value from Gender Drop Down List field.
     *
     */
    public static void unsetGenderDropDownListField() {
        unsetGenderDropDownListField(data.get("GENDER"));
    }

    /**
     * Unset value from Gender Drop Down List field.
     *
     */
    public static void unsetGenderDropDownListField(String genderValue) {
        new Select(gender).deselectByVisibleText(genderValue);
    }

    /**
     * Unset I Have Provided The Individual A Disclosure And Received The Individuals Written Authorization For The Report I Certify That 1 A Clear And Conspicuous Disclosure Was Made To The Consumer In A Document Consisting Solely Of The Disclosure 2 The Disclosure Satisfied All Fair Credit Reporting Act And Other Legal Requirements 3 The Report Will Not Be Used In Violation Of Any Applicable Federal Or State Equal Employment Opportunity Law Or Regulation And Its Use Will Comply With All Applicable Laws And 4 I Understand My Obligations Have Complied With And Will Comply With All Applicable Laws Pertaining To Consumer Reportsinvestigative Consumer Reports As Defined In The Fair Credit Reporting Act As Amended Checkbox field.
     *
     */
    public static void unsetIHaveProvidedTheIndividualACheckboxField() {
        SeleniumTest.unCheck(iHaveProvidedTheIndividualA);
    }

    /**
     * Unset Include Consentbased Ssn Verification For The Applicant Profiled Above Not Included Check The Box To Include Checkbox field.
     *
     */
    public static void unsetIncludeConsentbasedSsnVerificationForTheCheckboxField() {
        SeleniumTest.unCheck(includeConsentbasedSsnVerificationForThe);
    }

    /**
     * Unset Include Manual Processing For The Applicant Profiled Above Not Included Check The Box To Include Checkbox field.
     *
     */
    public static void unsetIncludeManualProcessingForTheApplicantCheckboxField() {
        SeleniumTest.unCheck(includeManualProcessingForTheApplicant);
    }

    /**
     * Unset Include Workers Compensation For The Applicant Profiled Above Not Included Check The Box To Include Checkbox field.
     *
     */
    public static void unsetIncludeWorkersCompensationForTheApplicantCheckboxField() {
        SeleniumTest.unCheck(includeWorkersCompensationForTheApplicant);
    }

    /**
     * Unset Last Name Checkbox field.
     *
     */
    public static void unsetLastName2CheckboxField() {
        SeleniumTest.unCheck(lastName2);
    }

    /**
     * Unset Last Name Checkbox field.
     *
     */
    public static void unsetLastName4CheckboxField() {
        SeleniumTest.unCheck(lastName4);
    }

    /**
     * Unset Same As Current Checkbox field.
     *
     */
    public static void unsetSameAsCurrent1CheckboxField() {
        SeleniumTest.unCheck(sameAsCurrent1);
    }

    /**
     * Unset Same As Current Checkbox field.
     *
     */
    public static void unsetSameAsCurrent2CheckboxField() {
        SeleniumTest.unCheck(sameAsCurrent2);
    }

    /**
     * Unset Send Electronic Disclosure And Authorization Forms To This Individual At The Email Given Below I Certify That 1 The Disclosure And Authorization Forms Have Been Reviewed By My Company And Legal Counsel And They Satisfy All Fair Credit Reporting Act And Other Legal Requirements Including A Clear And Conspicuous Disclosure In A Document That Consists Solely Of The Disclosure 2 My Order Should Not Be Processed Before This Written Disclosure Has Been Made To The Consumer And His Or Her Authorization Obtained In Writing 3 The Report Will Not Be Used In Violation Of Any Applicable Federal Or State Equal Employment Opportunity Law Or Regulation And Its Use Will Comply With All Applicable Laws And 4 I Understand My Obligations Have Complied With And Will Comply With All Applicable Laws Pertaining To Consumer Reportsinvestigative Consumer Reports As Defined In The Fair Credit Reporting Act As Amended Checkbox field.
     *
     */
    public static void unsetSendElectronicDisclosureAndAuthorizationFormsCheckboxField() {
        SeleniumTest.unCheck(sendElectronicDisclosureAndAuthorizationForms);
    }

    /**
     * Unset default value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate1DropDownListField() {
        unsetStartDate1DropDownListField(data.get("START_DATE_1"));
    }

    /**
     * Unset value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate1DropDownListField(String startDate1Value) {
        new Select(startDate1).deselectByVisibleText(startDate1Value);
    }

    /**
     * Unset default value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate2DropDownListField() {
        unsetStartDate2DropDownListField(data.get("START_DATE_2"));
    }

    /**
     * Unset value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate2DropDownListField(String startDate2Value) {
        new Select(startDate2).deselectByVisibleText(startDate2Value);
    }

    /**
     * Unset default value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate3DropDownListField() {
        unsetStartDate3DropDownListField(data.get("START_DATE_3"));
    }

    /**
     * Unset value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate3DropDownListField(String startDate3Value) {
        new Select(startDate3).deselectByVisibleText(startDate3Value);
    }

    /**
     * Unset default value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate4DropDownListField() {
        unsetStartDate4DropDownListField(data.get("START_DATE_4"));
    }

    /**
     * Unset value from Start Date Drop Down List field.
     *
     */
    public static void unsetStartDate4DropDownListField(String startDate4Value) {
        new Select(startDate4).deselectByVisibleText(startDate4Value);
    }

    /**
     * Unset default value from State Drop Down List field.
     *
     */
    public static void unsetStateDropDownListField() {
        unsetStateDropDownListField(data.get("STATE"));
    }

    /**
     * Unset value from State Drop Down List field.
     *
     */
    public static void unsetStateDropDownListField(String stateValue) {
        new Select(state).deselectByVisibleText(stateValue);
    }

    /**
     * Unset default value from Stateprovince Drop Down List field.
     *
     */
    public static void unsetStateprovince1DropDownListField() {
        unsetStateprovince1DropDownListField(data.get("STATEPROVINCE_1"));
    }

    /**
     * Unset value from Stateprovince Drop Down List field.
     *
     */
    public static void unsetStateprovince1DropDownListField(String stateprovince1Value) {
        new Select(stateprovince1).deselectByVisibleText(stateprovince1Value);
    }

    /**
     * Unset default value from Stateprovince Drop Down List field.
     *
     */
    public static void unsetStateprovince2DropDownListField() {
        unsetStateprovince2DropDownListField(data.get("STATEPROVINCE_2"));
    }

    /**
     * Unset value from Stateprovince Drop Down List field.
     *
     */
    public static void unsetStateprovince2DropDownListField(String stateprovince2Value) {
        new Select(stateprovince2).deselectByVisibleText(stateprovince2Value);
    }

    /**
     * Unset default value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory1DropDownListField() {
        unsetStateterritory1DropDownListField(data.get("STATETERRITORY_1"));
    }

    /**
     * Unset value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory1DropDownListField(String stateterritory1Value) {
        new Select(stateterritory1).deselectByVisibleText(stateterritory1Value);
    }

    /**
     * Unset default value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory2DropDownListField() {
        unsetStateterritory2DropDownListField(data.get("STATETERRITORY_2"));
    }

    /**
     * Unset value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory2DropDownListField(String stateterritory2Value) {
        new Select(stateterritory2).deselectByVisibleText(stateterritory2Value);
    }

    /**
     * Unset default value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory3DropDownListField() {
        unsetStateterritory3DropDownListField(data.get("STATETERRITORY_3"));
    }

    /**
     * Unset value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory3DropDownListField(String stateterritory3Value) {
        new Select(stateterritory3).deselectByVisibleText(stateterritory3Value);
    }

    /**
     * Unset default value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory4DropDownListField() {
        unsetStateterritory4DropDownListField(data.get("STATETERRITORY_4"));
    }

    /**
     * Unset value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory4DropDownListField(String stateterritory4Value) {
        new Select(stateterritory4).deselectByVisibleText(stateterritory4Value);
    }

    /**
     * Unset default value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory5DropDownListField() {
        unsetStateterritory5DropDownListField(data.get("STATETERRITORY_5"));
    }

    /**
     * Unset value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory5DropDownListField(String stateterritory5Value) {
        new Select(stateterritory5).deselectByVisibleText(stateterritory5Value);
    }

    /**
     * Unset default value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory6DropDownListField() {
        unsetStateterritory6DropDownListField(data.get("STATETERRITORY_6"));
    }

    /**
     * Unset value from Stateterritory Drop Down List field.
     *
     */
    public static void unsetStateterritory6DropDownListField(String stateterritory6Value) {
        new Select(stateterritory6).deselectByVisibleText(stateterritory6Value);
    }

    /**
     * Unset default value from Years Drop Down List field.
     *
     */
    public static void unsetYears1DropDownListField() {
        unsetYears1DropDownListField(data.get("YEARS_1"));
    }

    /**
     * Unset value from Years Drop Down List field.
     *
     */
    public static void unsetYears1DropDownListField(String years1Value) {
        SeleniumTest.unCheck(years1);
    }

    /**
     * Unset default value from Years Drop Down List field.
     *
     */
    public static void unsetYears2DropDownListField() {
        unsetYears2DropDownListField(data.get("YEARS_2"));
    }

    /**
     * Unset value from Years Drop Down List field.
     *
     */
    public static void unsetYears2DropDownListField(String years2Value) {
        new Select(years2).deselectByVisibleText(years2Value);
    }

    /**
     * Unset Years Checkbox field.
     *
     */
    public static void unsetYears3CheckboxField() {
        SeleniumTest.unCheck(years3);
    }

    /**
     * Unset default value from Years Drop Down List field.
     *
     */
    public static void unsetYears4DropDownListField() {
        unsetYears4DropDownListField(data.get("YEARS_4"));
    }

    /**
     * Unset value from Years Drop Down List field.
     *
     */
    public static void unsetYears4DropDownListField(String years4Value) {
        new Select(years4).deselectByVisibleText(years4Value);
    }

    /**
     * Unset Years Checkbox field.
     *
     */
    public static void unsetYears5CheckboxField() {
        SeleniumTest.unCheck(years5);
    }

    /**
     * Unset default value from Years Drop Down List field.
     *
     */
    public static void unsetYears6DropDownListField() {
        unsetYears6DropDownListField(data.get("YEARS_6"));
    }

    /**
     * Unset value from Years Drop Down List field.
     *
     */
    public static void unsetYears6DropDownListField(String years6Value) {
        new Select(years6).deselectByVisibleText(years6Value);
    }

    /**
     * Unset Years Checkbox field.
     *
     */
    public static void unsetYears7CheckboxField() {
        SeleniumTest.unCheck(years7);
    }

    /**
     * Unset default value from Years Drop Down List field.
     *
     */
    public static void unsetYears8DropDownListField() {
        unsetYears8DropDownListField(data.get("YEARS_8"));
    }

    /**
     * Unset value from Years Drop Down List field.
     *
     */
    public static void unsetYears8DropDownListField(String years8Value) {
        new Select(years8).deselectByVisibleText(years8Value);
    }

    public static void completeCandidateProfile(Candidate candidate){
        SeleniumTest.clearAndSetText(firstName1,candidate.getFirstName());
        SeleniumTest.clearAndSetText(middleName,candidate.getMiddleName());
        SeleniumTest.clearAndSetText(lastName1,candidate.getLastName());
        SeleniumTest.clearAndSetText(socialSecurityNumber,candidate.getSocialSecurityNumber());
        SeleniumTest.clearAndSetText(emailAddress1,candidate.getEmailAddress());
        SeleniumTest.clearAndSetText(phoneNumber1,candidate.getCandidatePhone());

    }
    public static boolean canEmployerBeFoundInSuggestionBox(String employerAbbreviation, String employerName){
        staticLogger.info("Enter the employer abbreviation");
        SeleniumTest.clearAndSetText(employerNameInputBox,employerAbbreviation);
        SeleniumTest.waitForElementVisible(employerSuggestionBox);
        if(employerName.equals(SeleniumTest.getText(employerSuggestionBox))){
            staticLogger.info("Employer name is matched");
            return  true;
        }
        else{
            staticLogger.info("Employer name didn't matched");
            return  false;
        }
    }

    public void enterEmployerName(String employerName){
        staticLogger.info("Enter employername as "+employerName);
        SeleniumTest.clearAndSetText(employerNameInputBox,employerName);
    }

    public void selectcheckBox(String employerName){
        staticLogger.info("Enter employername as "+employerName);
        SeleniumTest.clearAndSetText(employerNameInputBox,employerName);
    }

    public void enterReportApiEmployerName(String employerName){
        staticLogger.info("Enter employername as "+employerName);
        SeleniumTest.clearAndSetText(ReportApiemployerNameInputBox ,employerName);
    }

    public void enterReportApiandNonReportApiEmployerName(String employerName){
        staticLogger.info("Enter employername as "+employerName);
        SeleniumTest.clearAndSetText(CombinationofNonAndReportApiemployerNameInputBox ,employerName);
    }

    public void enterReportApiPhoneNumber(Candidate candidate){
        staticLogger.info("Enter phone number "+candidate.getCandidatePhone());
        SeleniumTest.clearAndSetText(ReportApiemployerphoneNumberInputBox,candidate.getCandidatePhone());
    }


    public void enterReportApiandNonPhoneNumber(Candidate candidate){
        staticLogger.info("Enter phone number "+candidate.getCandidatePhone());
        SeleniumTest.clearAndSetText(ReportandNOnReportApiemployerphoneNumberInputBox,candidate.getCandidatePhone());
    }



    public void enterReportApiCountryOrRegion(Candidate candidate){
        staticLogger.info("Select country as "+candidate.getCountryOrRegion());
        SeleniumTest.selectByVisibleTextFromDropDown(countryORRegionDropbox,candidate.getCountryOrRegion());
    }

    public void enterReportApiState(){
        staticLogger.info("Select candidate state "+"Alabama");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiemployerstatedropdown,"Alabama");
    }

    public void enterReportApiandNonReportApiState(){
        staticLogger.info("Select candidate state "+"Alabama");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiandNonReportApiemployerstatedropdown,"Alabama");
    }

    public void enterPhoneNumber(Candidate candidate){
        staticLogger.info("Enter phone number "+candidate.getCandidatePhone());
        SeleniumTest.clearAndSetText(employeePhoneNumberInputBox,candidate.getCandidatePhone());
    }

    public void enterCountryOrRegion(Candidate candidate){
        staticLogger.info("Select country as "+candidate.getCountryOrRegion());
        SeleniumTest.selectByVisibleTextFromDropDown(countryORRegionDropbox,candidate.getCountryOrRegion());
    }

    public void enterCity(Candidate candidate){
        staticLogger.info("Enter city as "+candidate.getCity());
        SeleniumTest.clearAndSetText(employeeCityInputBox,candidate.getCity());
    }

    public void enterState(Candidate candidate){
        staticLogger.info("Select candidate state "+candidate.getState());
        SeleniumTest.selectByVisibleTextFromDropDown(employeeStateDropBox,candidate.getState());
    }

    public void enterJobTitle(Candidate candidate){
        staticLogger.info("Enter job title "+candidate.setCandidatePosition("Tester"));
        SeleniumTest.clearAndSetText(jobTitle,candidate.getCandidatePosition());
    }

    public void selectReasonToLeave(){
        staticLogger.info("Select reason for leaving "+"Resigned");
        SeleniumTest.selectByVisibleTextFromDropDown(reasonforLeavingPreviousEmployer,"Resigned");
    }

    public void selectReportApiReasonToLeave(){
        staticLogger.info("Select reason for leaving "+"Resigned");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiemployerReasonforleaving,"Resigned");
    }

    public void selectReportApiandNonReportApiReasonToLeave(){
        staticLogger.info("Select reason for leaving "+"Resigned");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiandNonReportApiemployerReasonforleaving,"Resigned");
    }

    public void selectEmploymentStartDate(){
        staticLogger.info("Select employment start date ");
        SeleniumTest.selectByVisibleTextFromDropDown(startMonthEmployment,"Jan");
        SeleniumTest.selectByVisibleTextFromDropDown(startYearEmployment,"2012");
    }

    public void selectReportApiEmploymentStartDate(){
        staticLogger.info("Select employment start date ");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApistartMonthEmployment,"Jan");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApistartYearEmployment,"2012");
    }

    public void selectReportApiandNonReportApiEmploymentStartDate(){
        staticLogger.info("Select employment start date ");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiandNonReportApistartMonthEmployment,"Jan");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiandNonReportApistartYearEmployment,"2012");
    }

    public void selectReportApiEmploymentEndDate(){
        staticLogger.info("Select employment end date");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiendMonthEmployment,"Dec");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportAPIendYearEmployment,"2016");
    }


    public void selectReportApiandNonReportApiEmploymentEndDate(){
        staticLogger.info("Select employment end date");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportApiandNonReportApiendMonthEmployment,"Dec");
        SeleniumTest.selectByVisibleTextFromDropDown(ReportAPIandNonReportApiendYearEmployment,"2016");
    }

    public void selectEmploymentEndDate(){
        staticLogger.info("Select employment end date");
        SeleniumTest.selectByVisibleTextFromDropDown(endMonthEmployment,"Dec");
        SeleniumTest.selectByVisibleTextFromDropDown(endYearEmployment,"2016");
    }


    public boolean isAddbtnVisible(){
        return SeleniumTest.isElementVisibleNoWaiting(By.id("addProductBtn"));
    }

    public void clickCloseIcon() {
        SeleniumTest.click(closeIcon);
    }

    public void enterEmployerNameG17(String employerName){
        staticLogger.info("Enter employername as "+employerName);
        SeleniumTest.clearAndSetText(employerNameInputBoxG17,employerName);
    }

    public void enterPhoneNumberG17(Candidate candidate){
        staticLogger.info("Enter phone number "+candidate.getCandidatePhone());
        SeleniumTest.clearAndSetText(employeePhoneNumberInputBoxG17,candidate.getCandidatePhone());
    }

    public void enterCountryOrRegionG17(Candidate candidate){
        staticLogger.info("Select country as "+candidate.getCountryOrRegion());
        SeleniumTest.selectByVisibleTextFromDropDown(countryORRegionDropboxG17,candidate.getCountryOrRegion());
    }

    public void enterCityG17(Candidate candidate){
        staticLogger.info("Enter city as "+candidate.getCity());
        SeleniumTest.clearAndSetText(employeeCityInputBoxG17,candidate.getCity());
    }

    public void enterStateG17(Candidate candidate){
        staticLogger.info("Select candidate state "+candidate.getState());
        SeleniumTest.selectByVisibleTextFromDropDown(employeeStateDropBoxG17,candidate.getState());
    }

    public void enterJobTitleG17(Candidate candidate){
        staticLogger.info("Enter job title "+candidate.setCandidatePosition("Tester"));
        SeleniumTest.clearAndSetText(jobTitleG17,candidate.getCandidatePosition());
    }

    public void selectReasonToLeaveG17(){
        staticLogger.info("Select reason for leaving "+"Resigned");
        SeleniumTest.selectByVisibleTextFromDropDown(reasonforLeavingPreviousEmployerG17,"Resigned");
    }

    public void selectEmploymentStartDateG17(){
        staticLogger.info("Select employment start date ");
        SeleniumTest.selectByVisibleTextFromDropDown(startMonthEmploymentG17,"Jan");
        SeleniumTest.selectByVisibleTextFromDropDown(startYearEmploymentG17,"2012");
    }

    public void selectEmploymentEndDateG17(){
        staticLogger.info("Select employment end date");
        SeleniumTest.selectByVisibleTextFromDropDown(endMonthEmploymentG17,"Dec");
        SeleniumTest.selectByVisibleTextFromDropDown(endYearEmploymentG17,"2016");
    }

    public void clickCheckBoxAuthorization(){
        SeleniumTest.check(checkBoxAuthorization);
    }

    public static void enterCandidatePhoneAndDob(Candidate candidate){
        SeleniumTest.clearAndSetText(phoneNumber1,candidate.getCandidatePhone());
        SeleniumTest.selectByVisibleTextFromDropDown(dateOfBirth1,candidate.getDobMonth());
        SeleniumTest.selectByVisibleTextFromDropDown(dateOfBirth2,candidate.getDobDay());
        SeleniumTest.selectByVisibleTextFromDropDown(dateOfBirth3,candidate.getDobYear());

    }

    public void selectReasonToLeave(String reasonToLeave){
        staticLogger.info("Select reason for leaving "+reasonToLeave);
        SeleniumTest.selectByVisibleTextFromDropDown(reasonforLeavingPreviousEmployer,reasonToLeave);
    }

    /* To check if EMPLOYMENT VERIFICATION checkbox is checked or not */
    public boolean isEmploymentVerificationCheckBoxChecked(){
        return SeleniumTest.isCheckboxChecked(employerVerificiationCheckbox);
    }
    /* To check EMPLOYMENT VERIFICATION checkbox */
    public void checkEmploymentVerificationCheckBox(){
        SeleniumTest.check(employerVerificiationCheckbox);
    }

    /* To enter salary */
    public void enterSalary(String salary){
        SeleniumTest.clearAndSetText(salaryInputBox,salary);
    }

    public void setDoNotContactEmployerCheckboxFieldG41() {
        SeleniumTest.check(doNotContactEmployerG41);
    }

    public void setSameASCurrentG41() {
        SeleniumTest.check(sameAsCurrentG41);
    }

    public void enterPhoneNumber(String phoneNumber){
        SeleniumTest.clearAndSetText(employeePhoneNumberInputBox,phoneNumber);
    }

    public void enterCity(String city){
        SeleniumTest.clearAndSetText(employeeCityInputBox,city);
    }

    public void enterReportAPICity(String city){
        SeleniumTest.clearAndSetText(ReportApiemployercitydropdown,city);
    }


    public void enterReportAPIandNonReportCity(String city){
        SeleniumTest.clearAndSetText(ReportApiandNonReportApiemployercitydropdown,city);
    }

    public void enterState(String state){
        SeleniumTest.selectByVisibleTextFromDropDown(employeeStateDropBox,state);
    }

    public void enterJobTitle(String jobTitleValue){
        SeleniumTest.clearAndSetText(jobTitle,jobTitleValue);
    }

    public void enterReportApiJobTitle(String jobTitleValue){
        SeleniumTest.clearAndSetText(ReportApijobTitle,jobTitleValue);
    }


    public void enterReportApiandNonReportApiJobTitle(String jobTitleValue){
        SeleniumTest.clearAndSetText(ReportApiandNonReportjobTitle,jobTitleValue);
    }

    public void selectReportAPIEmploymentStartDate(String month, String year){
        staticLogger.info("Select employment start date ");
        SeleniumTest.selectByVisibleTextFromDropDown(startMonthEmployment,month);
        SeleniumTest.selectByVisibleTextFromDropDown(startYearEmployment,year);
    }

    public void selectEmploymentStartDate(String month, String year){
        staticLogger.info("Select employment start date ");
        SeleniumTest.selectByVisibleTextFromDropDown(startMonthEmployment,month);
        SeleniumTest.selectByVisibleTextFromDropDown(startYearEmployment,year);
    }
}
