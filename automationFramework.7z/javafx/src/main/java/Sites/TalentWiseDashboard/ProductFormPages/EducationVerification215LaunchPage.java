package Sites.TalentWiseDashboard.ProductFormPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by jgupta on 4/20/2016.
 */
public class EducationVerification215LaunchPage extends ScreeningLaunchPage {
    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    /**
     * Fills the education Verification section.
     * @param widget Widget number
     * @param degree Bachelors, Masters etc
     * @param major Subject of study
     * @param school Name of college
     * @param country Country of college
     * @param city City where college is located
     * @param state State where college is located
     * @param didCandidateGraduate If the candidate successfully graduated
     * @param sameAsCurrent If the candidate has an alternate name
     */
    public static EducationVerification215LaunchPage fillEducationVerificationSection(String widget, String degree, String major, String school,
                                                                                      String country, String city, String state, String didCandidateGraduate, LocalDate graduationDate, boolean sameAsCurrent) {
        return fillEducationVerificationSection(widget, degree, major, school, country, city, state, didCandidateGraduate, graduationDate, sameAsCurrent, "0");
    }

    /**
     * Fills the education Verification section.
     * @param widget Widget number
     * @param degree Bachelors, Masters etc
     * @param major Subject of study
     * @param school Name of college
     * @param country Country of college
     * @param city City where college is located
     * @param state State where college is located
     * @param didCandidateGraduate If the candidate successfully graduated
     * @param sameAsCurrent If the candidate has an alternate name
     * @param indexStr If more of the same packages are added, pass index
     */
    public static EducationVerification215LaunchPage fillEducationVerificationSection(
            String widget, String degree, String major, String school,
            String country, String city, String state, String didCandidateGraduate,
            LocalDate graduationDate, boolean sameAsCurrent, String indexStr) {
        String groupWidget = "-" + indexStr + "_" +  widget;
        //With multiple same additional packages in screening page, the 1st form has index 0 the id looks like qcert_Group40-0_2 else qcert_Group40_1 (or _2)
        WebElement degreeDD = Driver.getDriver().findElement(By.id("qcert_Group38" + groupWidget));
        Select degreeDropDown = new Select(degreeDD);
        degreeDropDown.selectByVisibleText(degree);

        WebElement majorTextBox = Driver.getDriver().findElement(By.name("qdgre_Group38" + groupWidget));
        majorTextBox.sendKeys(major);

        WebElement schoolTextBox = Driver.getDriver().findElement(By.id("qschn_Group38" + groupWidget));
        schoolTextBox.sendKeys(school);
        WebElement cityTextBox = Driver.getDriver().findElement(By.name("qschc_Group38" + groupWidget));
        cityTextBox.sendKeys(city);
        WebElement stateDD = Driver.getDriver().findElement(By.id("qschs_Group38" + groupWidget));
        Select stateDropDown = new Select(stateDD);
        stateDropDown.selectByVisibleText(state);
        WebElement didCandidateGraduateDD = Driver.getDriver().findElement(By.id("qdidgraduate_Group38" + groupWidget));
        Select didCandidateGraduateDropDown = new Select(didCandidateGraduateDD);
        didCandidateGraduateDropDown.selectByVisibleText(didCandidateGraduate);

        if (didCandidateGraduate.equals("Yes")){
            String gradMonth = graduationDate.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);
            String gradYear = (Integer.toString(graduationDate.getYear()));

            WebElement monthDD = Driver.getDriver().findElement(By.id("qgraddtmm_Group38" + groupWidget));
            SeleniumTest.selectShortMonthByVisibleText(monthDD, gradMonth);

            WebElement yearDD = Driver.getDriver().findElement(By.id("qgraddtyy_Group38" + groupWidget));
            Select yearDropDown = new Select(yearDD);
            yearDropDown.selectByVisibleText(gradYear);
        }

        if (sameAsCurrent) {
            WebElement sameAsCurrentCheckBox = Driver.getDriver().findElement(By.id("sameascurrent_Group38" + groupWidget));
            SeleniumTest.check(sameAsCurrentCheckBox);
        }
        return PageFactory.initElements(Driver.getDriver(), EducationVerification215LaunchPage.class);
    }

    /**
     * Clicks on Continue button
     * @param returnedClass Returns a launch page
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Fills the education Verification section.
     * @param widget
     * @param degree
     * @param major
     * @param school
     * @param country
     * @param city
     * @param state
     * @param didCandidateGraduate
     * @param graduationDate
     * @param sameAsCurrent
     * @param indexStr
     * @return
     */
    public EducationVerification215LaunchPage fillEducationVerificationSection1(
            String widget, String degree, String major, String school,
            String country, String city, String state, String didCandidateGraduate,
            LocalDate graduationDate, boolean sameAsCurrent, String indexStr) {
        String groupWidget = "-" + indexStr + "_" +  widget;
        //With multiple same additional packages in screening page, the 1st form has index 0 the id looks like qcert_Group40-0_2 else qcert_Group40_1 (or _2)
        WebElement degreeDD = Driver.getDriver().findElement(By.id("qcert_Group40" + groupWidget));
        Select degreeDropDown = new Select(degreeDD);
        degreeDropDown.selectByVisibleText(degree);

        WebElement majorTextBox = Driver.getDriver().findElement(By.name("qdgre_Group40" + groupWidget));
        majorTextBox.sendKeys(major);

        WebElement schoolTextBox = Driver.getDriver().findElement(By.id("qschn_Group40" + groupWidget));
        schoolTextBox.sendKeys(school);
        WebElement cityTextBox = Driver.getDriver().findElement(By.name("qschc_Group40" + groupWidget));
        cityTextBox.sendKeys(city);
        WebElement stateDD = Driver.getDriver().findElement(By.id("qschs_Group40" + groupWidget));
        Select stateDropDown = new Select(stateDD);
        stateDropDown.selectByVisibleText(state);
        WebElement didCandidateGraduateDD = Driver.getDriver().findElement(By.id("qdidgraduate_Group40" + groupWidget));
        Select didCandidateGraduateDropDown = new Select(didCandidateGraduateDD);
        didCandidateGraduateDropDown.selectByVisibleText(didCandidateGraduate);

        if (didCandidateGraduate.equals("Yes")){
            String gradMonth = graduationDate.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);
            String gradYear = (Integer.toString(graduationDate.getYear()));

            WebElement monthDD = Driver.getDriver().findElement(By.id("qgraddtmm_Group40" + groupWidget));
            SeleniumTest.selectShortMonthByVisibleText(monthDD, gradMonth);

            WebElement yearDD = Driver.getDriver().findElement(By.id("qgraddtyy_Group40" + groupWidget));
            Select yearDropDown = new Select(yearDD);
            yearDropDown.selectByVisibleText(gradYear);
        }

        if (sameAsCurrent) {
            WebElement sameAsCurrentCheckBox = Driver.getDriver().findElement(By.id("sameascurrent_Group40" + groupWidget));
            SeleniumTest.check(sameAsCurrentCheckBox);
        }
        return PageFactory.initElements(Driver.getDriver(), EducationVerification215LaunchPage.class);
    }

    public EducationVerification215LaunchPage fillEduSchoolDetails(
            String widget, String school, String country, String city, String state, String indexStr) {
        String groupWidget = "-" + indexStr + "_" +  widget;
        WebElement schoolTextBox = Driver.getDriver().findElement(By.id("qschn_Group40" + groupWidget));
        SeleniumTest.clearAndSetText(schoolTextBox, school);

        WebElement cityTextBox = Driver.getDriver().findElement(By.name("qschc_Group40" + groupWidget));
        SeleniumTest.clearAndSetText(cityTextBox, city);
        WebElement stateDD = Driver.getDriver().findElement(By.id("qschs_Group40" + groupWidget));
        SeleniumTest.selectByVisibleTextFromDropDown(stateDD,state);
        return PageFactory.initElements(Driver.getDriver(), EducationVerification215LaunchPage.class);
    }


}