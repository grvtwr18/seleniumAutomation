package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Created by qli on 10/20/16.
 */
public class EmploymentLaunchForm {
    public enum EmploymentFormQvars {
        EMPLOYER_NAME("input", "id", "qcn_"),
        PHONE_NUMBER("input", "name", "qcp_"),
        COUNTRY_NAME("select", "name", "qo_"),
        CITY_NAME("input", "name", "qcc_"),
        STATE_NAME("select", "id", "qcs_"),
        JOB_TITLE("input", "name", "qjt_"),
        LEAVE_REASON("select", "id", "qjrfl_"),
        START_DATE_MONTH("select", "id", "qjstmm_"),
        START_DATE_YEAR("select", "id", "qjstyy_"),
        END_DATE_MONTH("select", "id", "qjendmm_"),
        END_DATE_YEAR("select", "id", "qjendyy_"),
        ADDITIONAL_INFO("input", "name", "qaddinf_"),
        EMPLOYED_FIRST_NAME("input", "id", "qfempalias_"),
        EMPLOYED_LAST_NAME("input", "id", "qnempalias_"),
        EMPLOYER_ADDRESS("input", "name", "qca_"),
        EMPLOYER_FAX_NUMBER("input", "name", "qcfax_"),
        EMPLOYER_EMAIL("input", "name", "qcee_"),
        BRANCH("input", "name", "qcbranch_"),
        PERMISSION_TO_CONTACT_EMPLOYER("input", "name", "qnocontact_");

        private final String prefix;
        private final String attribute;
        private final String tagName;

        EmploymentFormQvars(String tagName, String attribute, String prefix) {
            this.tagName = tagName;
            this.attribute = attribute;
            this.prefix = prefix;
        }
        public String getTagName() {
            return tagName;
        }

        public String getAttribute() {
            return attribute;
        }

        public String getPrefix() {
            return prefix;
        }
    }

    public static WebElement getElement(EmploymentFormQvars qvar, int index) {
        return Driver.getDriver().findElement(By.cssSelector(qvar.getTagName() + "[" + qvar.getAttribute() + "^='" + qvar.getPrefix() + "'][" + qvar.getAttribute() + "$='" + String.valueOf(index) + "']"));
    }

    /**
     * retrieve text value of webelements
     */
    public static String getEmployerName(int index) {
        return getElement(EmploymentFormQvars.EMPLOYER_NAME, index).getAttribute("value");
    }

    public static String getPhoneNumber(int index) {
        return getElement(EmploymentFormQvars.PHONE_NUMBER, index).getAttribute("value");
    }

    public static String getCountryName(int index) {
        return getElement(EmploymentFormQvars.COUNTRY_NAME, index).getAttribute("value");
    }

    public static String getCityName(int index) {
        return getElement(EmploymentFormQvars.CITY_NAME, index).getAttribute("value");
    }

    public static String getStateName(int index) {
        return  getElement(EmploymentFormQvars.STATE_NAME, index).getAttribute("value");
    }

    public static String getJobTitle(int index) {
        return getElement(EmploymentFormQvars.JOB_TITLE, index).getAttribute("value");
    }

    public static String getLeaveReson(int index) {
        return getElement(EmploymentFormQvars.LEAVE_REASON, index).getAttribute("value");
    }

    public static String getStartDateMonth(int index) {
        return getElement(EmploymentFormQvars.START_DATE_MONTH, index).getAttribute("value");
    }

    public static String getStartDateYear(int index) {
        return getElement(EmploymentFormQvars.START_DATE_YEAR, index).getAttribute("value");
    }

    public static String getEndDateMonth(int index) {
        return getElement(EmploymentFormQvars.END_DATE_MONTH, index).getAttribute("value");
    }

    public static String getEndDateYear(int index) {
        return getElement(EmploymentFormQvars.END_DATE_YEAR, index).getAttribute("value");
    }

    public static String getAdditionalInfo(int index) {
        return getElement(EmploymentFormQvars.ADDITIONAL_INFO, index).getAttribute("value");
    }

    public static String getEmployedFirstName(int index) {
        return getElement(EmploymentFormQvars.EMPLOYED_FIRST_NAME, index).getText();
    }

    public static String getEmployedLastName(int index) {
        return getElement(EmploymentFormQvars.EMPLOYED_LAST_NAME, index).getText();
    }

    public static String getEmployerAddress(int index) {
        return getElement(EmploymentFormQvars.EMPLOYER_ADDRESS, index).getText();
    }

    public static String getEmployerFaxNumberPrefix(int index) {
        return getElement(EmploymentFormQvars.EMPLOYER_FAX_NUMBER, index).getText();
    }

    public static String getEmployerEmailPrefix(int index) {
        return getElement(EmploymentFormQvars.EMPLOYER_EMAIL, index).getText();
    }

    public static String getBranchPrefix(int index) {
        return getElement(EmploymentFormQvars.BRANCH, index).getText();
    }

    public static String getPermissionToContactEmployer(int index) {
        return getElement(EmploymentFormQvars.PERMISSION_TO_CONTACT_EMPLOYER, index).getAttribute("checked");
    }

    public static void fillEmploymentVerificationSection_alacart(EmployeeVerificationInfo empInfo)
    {
        fillEmploymentVerificationSection_alacart(empInfo.Name, empInfo.PhoneNumber, empInfo.JobTitle, empInfo.Reason, empInfo.City, empInfo.State,  empInfo.StartMonth, empInfo.StartYear);
    }

    public static void fillEmploymentVerificationSection_alacart(String name, String pnNo, String jobTitle,
                                                                                              String reason, String city,  String state, String startMonth, String startYear) {
        WebElement EmpName = Driver.getDriver().findElement(By.id("qcn_216_1"));
        SeleniumTest.clearAndSetText(EmpName, name);

        WebElement phone = Driver.getDriver().findElement(By.name("qcp_216_1"));
        SeleniumTest.clearAndSetText(phone, pnNo);

        WebElement jTitle = Driver.getDriver().findElement(By.name("qjt_216_1"));
        SeleniumTest.clearAndSetText(jTitle, jobTitle);

        WebElement cityName = Driver.getDriver().findElement(By.name("qcc_216_1"));
        SeleniumTest.clearAndSetText(cityName, city);

        WebElement stateName = Driver.getDriver().findElement(By.name("qcs_216_1"));
        SeleniumTest.selectByValueFromDropDown(stateName, state);

        WebElement sMonth = Driver.getDriver().findElement(By.name("qjstmm_216_1"));
        SeleniumTest.selectByValueFromDropDown(sMonth, startMonth);

        WebElement startyear = Driver.getDriver().findElement(By.name("qjstyy_216_1"));
        SeleniumTest.selectByValueFromDropDown(startyear, startYear);

        // todo add support for endyear.
        WebElement reasonForLeaving = Driver.getDriver().findElement(By.name("qjrfl_216_1"));//reason == Still Employed skips enddate
        SeleniumTest.selectByValueFromDropDown(reasonForLeaving, reason);

    }

    @FindBy(how = How.ID, using = "qf")
    private WebElement employeeFirstName;

    @FindBy(how = How.ID, using = "qn")
    private WebElement employeeLastName;

    @FindBy(how = How.NAME,using = "qssn")
    private WebElement employeeSSN;

    @FindBy(how = How.ID,using = "qcn")
    private WebElement employerName;

    @FindBy(how = How.ID,using = "qcp")
    private WebElement employerPhoneNo;

    @FindBy(how = How.ID,using = "qcc")
    private WebElement employerCity;

    @FindBy(how = How.ID,using = "qcs")
    private WebElement employerState;

    @FindBy(how = How.ID, using = "qjt")
    private WebElement jobTitle;

    @FindBy(how = How.ID,using = "qjrfl")
    private WebElement reasonForLeaving;

    @FindBy(how = How.ID,using = "qjstmm")
    private WebElement startDateMonth;

    @FindBy(how = How.ID,using = "qjstyy")
    private WebElement startDateYear;

    @FindBy(how = How.ID,using = "qjendmm")
    private WebElement endDateMonth;

    @FindBy(how = How.ID,using = "qjendyy")
    private WebElement endDateYear;

    @FindBy(how = How.NAME,using = "qfcraagree")
    private WebElement iCertify;

    @FindBy(how = How.XPATH,using = "//input[@value='Run Verification']")
    private WebElement runVerification;

    public void enterEmployeeFirstName(String fName){
        SeleniumTest.clearAndSetText(employeeFirstName,fName);
    }

    public void enterEmployeeLastName(String lName){
        SeleniumTest.clearAndSetText(employeeLastName,lName);
    }

    public void enterEmployeeSSN(String ssn){
        SeleniumTest.clearAndSetText(employeeSSN,ssn);
    }

    public void enterEmployerName(String compName){
        SeleniumTest.clearAndSetText(employerName,compName);
    }

    public void enterEmployerPhoneNo(String num){
        SeleniumTest.clearAndSetText(employerPhoneNo,num);
    }

    public void enterEmployerCity(String city){
        SeleniumTest.clearAndSetText(employerCity,city);
    }

    public void selectEmployerState(String state){
        SeleniumTest.selectByVisibleTextFromDropDown(employerState,state);
    }

    public void enterJobTitle(String title){
        SeleniumTest.clearAndSetText(jobTitle,title);
    }

    public void selectReasonForLeaving(String reason){
        SeleniumTest.selectByVisibleTextFromDropDown(reasonForLeaving,reason);
    }

    public void selectStartDateMonth(String month){
        SeleniumTest.selectByVisibleTextFromDropDown(startDateMonth,month);
    }

    public void selectStartDateYear(String year){
        SeleniumTest.selectByVisibleTextFromDropDown(startDateYear,year);
    }

    public void selectEndDateMonth(String month){
        SeleniumTest.selectByVisibleTextFromDropDown(endDateMonth,month);
    }

    public void selectEndDateYear(String year){
        SeleniumTest.selectByVisibleTextFromDropDown(endDateYear,year);
    }

    public void clickICertify(){
        SeleniumTest.check(iCertify);
    }

    public <T> T clickRunVerification(Class<T> type){
        SeleniumTest.click(runVerification);
        return PageFactory.initElements(Driver.getDriver(),type);
    }
}

