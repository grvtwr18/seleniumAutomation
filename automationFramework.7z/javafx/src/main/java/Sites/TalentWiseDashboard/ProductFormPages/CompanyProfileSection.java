package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by abrackett on 5/10/17.
 * LaunchForm / Uberform Company Profile Section
 */
public class CompanyProfileSection extends CompanyInformationSection {

    @FindBy(how = How.ID, using = "profileList")
    private WebElement profileDropdown;

    private static ThreadLocal<CompanyProfileSection> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(
                Driver.getDriver(), CompanyProfileSection.class));
    }

    private static CompanyProfileSection getInstance() {
        return threadLocalInstance.get();
    }

    /**
     * Selects the Company Profile from the drop down
     * @param profileName Name of the profile to select
     */
    public static void selectCompanyProfile(String profileName) {
        SeleniumTest.waitForElementVisible(getInstance().profileDropdown);
        SeleniumTest.waitForElementToBeClickable(getInstance().profileDropdown,5000);
        SeleniumTest.selectByVisibleTextFromDropDown(getInstance().profileDropdown, profileName);
    }

    /**
     * Gets the selected Company Profile
     * @return The selected Company Profile
     */
    public static String getCompanyProfile() {
        try {

            WebElement profileElement =
                    ((EventFiringWebDriver)Driver.getDriver())
                            .getWrappedDriver().findElement(By.id("profileList"));

            Select profile = new Select(profileElement);
            return profile.getFirstSelectedOption().getText();
        } catch (NoSuchElementException nse) {
            return "";
        }
    }
}
