package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;

/**
 * Created by wogden on 6/1/2016.
 * TODO: consolidate with FS532LaunchPage/StandardCandidateQuestionnaireLaunchPage
 */
public class GenericLaunchForm extends ProductFormPages {
    @FindBy(how = How.ID, using = "dp_qduedate1")
    private static WebElement task1DueDateBox;

    @FindBy(how = How.ID, using = "qduedate1")
    private static WebElement hiddenTask1DueDateBox;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    public static void setDueDate(LocalDate date) {
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date,
                task1DueDateBox.getAttribute("ID"),
                hiddenTask1DueDateBox.getAttribute("ID"));
    }

    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
