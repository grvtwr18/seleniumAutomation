package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import org.openqa.selenium.By;

/***
 * Not to be confused with the CandidateReviewInformationPage, this
 * page is just like the ReviewOrderPage (it has a Purchase button),
 * But for some reason its titleBar says, "Review Information".
 */
public class ReviewInformationPage extends ReviewOrderPage {

    public static boolean onPage() {
        return Navigation.isPurchaseVisible()
                && SeleniumTest.isElementVisibleNoWaiting(By.className("titleBar"))
                && "Review Information".equals(SeleniumTest.getTextByLocator(By.className("titleBar")));
    }
}
