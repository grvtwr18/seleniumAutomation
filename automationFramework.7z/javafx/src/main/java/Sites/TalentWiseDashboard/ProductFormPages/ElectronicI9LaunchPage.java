package Sites.TalentWiseDashboard.ProductFormPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by jgupta on 12/5/2015.
 */
public class ElectronicI9LaunchPage extends I9LaunchPages {

    @FindBy(how = How.XPATH, using = "//*[@id=\"divMethod1\"]/div[1]/input")
    private static WebElement employeeEmailAddress;

    @FindBy(how = How.ID, using = "btnSubmit")
    public static WebElement continueButton;

    @FindBy(how = How.CSS, using = "div.title>h1")
    public static WebElement pageHeaderLabel;

    static {
        PageFactory.initElements(Driver.getDriver(), ElectronicI9LaunchPage.class);
    }

    //TODO: GOV/ONB should update the other type... to be set...
    public static void typeEmployeeEmailAddress(String email){
        SeleniumTest.clearAndSetText(employeeEmailAddress, email);
    }

    /**
     * Clicks on Continue button to go to next page.
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

}
