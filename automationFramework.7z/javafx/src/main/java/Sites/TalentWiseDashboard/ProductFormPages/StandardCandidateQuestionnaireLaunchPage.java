package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;

/**
 * Created by abrackett on 11/13/2015.
 * TODO: fix line endings
 * TODO: rename this class since it works for any single-task launch form.
 */
public class StandardCandidateQuestionnaireLaunchPage extends ProductFormPages {
    @FindBy(how = How.ID, using = "dp_qduedate1")
    private static WebElement dueDateBox;

    private static String hiddenDueDateBox = "qduedate1";

    @FindBy(how = How.CSS, using = "#btnSubmit[value='Continue']")
    private static WebElement continueButton;

    static {
        PageFactory.initElements(Driver.getDriver(), StandardCandidateQuestionnaireLaunchPage.class);
    }

    public static void waitForPageReady() {
        SeleniumTest.waitForElement(continueButton);
    }

    /**
     * Set the due Date for this Launch Form
     * @param lDate Date to use
     * @return
     */
    public static void setDueDate(LocalDate lDate) {
        if(Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(lDate, "dp_qduedate1", "qduedate1");
        }
        else {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(lDate, dueDateBox.getAttribute("id"), hiddenDueDateBox);
        }
    }

    /**
     * Click Continue
     * @param advancePage whether or not to advance to the next page
     * @return
     */
    public static ProductFormPages clickContinue(Boolean advancePage) {
        clickContinue();
        if(advancePage)
            return PageFactory.initElements(Driver.getDriver(), StandardCandidateQuestionnaireFormZero.class);
        else
            return PageFactory.initElements(Driver.getDriver(), StandardCandidateQuestionnaireLaunchPage.class);
    }

    public static void clickContinue() {
        continueButton.click();
    }
}
