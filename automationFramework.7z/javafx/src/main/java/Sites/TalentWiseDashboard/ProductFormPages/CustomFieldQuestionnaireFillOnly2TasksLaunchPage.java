package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;

/**
 * Created by jgupta on 11/03/2015.
 */
public class CustomFieldQuestionnaireFillOnly2TasksLaunchPage extends LaunchFormPages {
    public Header header;
    public Footer footer;

    public final String candidateDueDateLocatorString = "qduedate1";
    @FindBy(how = How.ID, using = "dp_" + candidateDueDateLocatorString)
    public WebElement candidateDueDate;

    @FindBy(how = How.CSS, using = "table.taskstable tbody tr td select#qverifiergroupid2")
    public WebElement verifierGroupDropDown;

    @FindBy(how = How.ID, using = "qverifierid2")
    public WebElement verifierDropDown;

    public final String reviewFormDataTestDueDateLocatorString = "qduedate2";
    @FindBy(how = How.ID, using = "dp_" + reviewFormDataTestDueDateLocatorString)
    public WebElement reviewFormDataTestDueDate;

    @FindBy(how = How.CSS, using = "div.title>h1")
    public WebElement pageHeaderLabel;

    @FindBy(how = How.XPATH, using = "//input[@value='Confirm and Launch']")
    public  WebElement confirmAndLaunchButton;

    /*
     * Constructs a new Form Review Formset 87253999 Page page object.
     * @param driver The WebDriver currently being used
     */
    public CustomFieldQuestionnaireFillOnly2TasksLaunchPage() {
        //The title of this page is "Custom Package - TalentWise"
        this.header = PageFactory.initElements(Driver.getDriver(), Header.class);
        this.footer = PageFactory.initElements(Driver.getDriver(), Footer.class);
    }

    /**
     * This method fills the Custom Field Questionnaire Fill Only 2 Tasks launch form
     * @param candidateDuedate
     * @param verifierGroup
     * @param verifier
     * @param verifierDueDate
     * @return
     */
    public ProductFormPages fillCustomFieldQuestionnaireFillOnly2Taskslaunchform(LocalDate candidateDuedate, String verifierGroup, String verifier, LocalDate verifierDueDate, Class<? extends ProductFormPages> returnClass) {

        //Type Due date candidate
        setCandidateDueDate(candidateDuedate);

        //Select reviewer group
        Select reviewFormDataTestGroupDropDown = new Select(verifierGroupDropDown);
        reviewFormDataTestGroupDropDown.selectByVisibleText(verifierGroup);

        //Select reviewer
        Select reviewFormDataTestReviewerDropDown = new Select(verifierDropDown);
        reviewFormDataTestReviewerDropDown.selectByVisibleText(verifier);

        //Type due date for Reviewer
        setReviewFormDataTestDueDate(verifierDueDate);

        //Click on Continue button to go to next page.
        continueButton.click();

        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Sets the Candidate Due Date
     * @param candidateDuedate
     * @return
     */
    public CustomFieldQuestionnaireFillOnly2TasksLaunchPage setCandidateDueDate(LocalDate candidateDuedate) {
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(candidateDuedate, "dp_" + candidateDueDateLocatorString, candidateDueDateLocatorString);
        return this;
    }

    /**
     * Sets the Verifier Due Date
     * @param verifierDueDate
     * @return
     */
    public CustomFieldQuestionnaireFillOnly2TasksLaunchPage setReviewFormDataTestDueDate(LocalDate verifierDueDate) {
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(verifierDueDate, "dp_" + reviewFormDataTestDueDateLocatorString, reviewFormDataTestDueDateLocatorString);
        return this;
    }

    public CustomFieldQuestionnaireFillOnly2TasksLaunchPage setDuedateClickContinue(String candidateDuedate){
        LocalDate localDate = LocalDate.parse(candidateDuedate, LocaleHelper.getDateFormatShortDateSlash_uuuu());
        setCandidateDueDate(localDate);
        continueButton.click();
        return this;
    }

    public CustomFieldQuestionnaireFillOnly2TasksLaunchPage clickConfirmAndLaunch(){
        SeleniumTest.waitForPageLoadToComplete();
        confirmAndLaunchButton.click();
        return this;
    }
}
