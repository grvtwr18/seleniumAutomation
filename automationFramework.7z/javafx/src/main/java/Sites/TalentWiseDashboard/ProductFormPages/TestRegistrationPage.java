package Sites.TalentWiseDashboard.ProductFormPages;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import Data.locations.countrycode.CountryCode;
import Data.locations.us.UsStateTerritory;
import Sites.TalentWiseDashboard.Dashboard.DashboardPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TestRegistrationPage extends ProductFormPages {

    public List<String> bccrecipients = new ArrayList<>();

    public enum PhoneType {
        UNSELECTED("Phone Type"),
        MOBILE("Mobile"),
        HOME("Home"),
        OFFICE("Office");

        private final String value;

        PhoneType(String value) {
            this.value = value;
        }

        public static PhoneType parse(String input) {
            if (null == input) {
                throw new IllegalArgumentException("Cannot parse() PhoneType for input null.");
            }

            input = input.trim();

            for (PhoneType phoneType : values()) {
                if (phoneType.value.equalsIgnoreCase(input)) {
                    return phoneType;
                }
            }
            // If we get here, no PhoneType value was implemented for the given string ...
            throw new IllegalArgumentException("No valid PhoneType found for input: " + input);
        }

        @Override
        public String toString() {
            return value;
        }
    }


    public enum RegistrationType {
        PRE_REGISTER_CANDIDATE("Pre-register Candidate online via Sterling Talent Solutions"),
        PAPER_CHAIN_OF_CUSTODY_FORM("I will give the Candidate our paper chain of custody form");

        private final String value;

        RegistrationType(String value) {
            this.value = value;
        }

        public static RegistrationType parse(String input) {
            if (null == input) {
                throw new IllegalArgumentException("Cannot parse() RegistrationType for input null.");
            }

            input = input.trim();

            for (RegistrationType registrationType : values()) {
                if (registrationType.value.equalsIgnoreCase(input)) {
                    return registrationType;
                }
            }
            // If we get here, no RegistrationType value was implemented for the given string ...
            throw new IllegalArgumentException("No valid RegistrationType found for input: " + input);
        }

        @Override
        public String toString() {
            return value;
        }
    }

    public RegistrationType registrationType;
    public void setRegistrationType(RegistrationType registrationType){ this.registrationType = registrationType; }
    public RegistrationType getRegistrationType(){ return this.registrationType; }

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @FindBy(id = "qlname")
    private WebElement lastNameTextBox;

    @FindBy(id = "qfname")
    private WebElement firstNameTextBox;

    @FindBy(id = "qmname")
    private WebElement middleNameTextBox;

    @FindBy(id = "qssn")
    private WebElement ssnTextBox;

    @FindBy(id = "dp_scheduleqdob")
    private WebElement dateOfBirthBox;

    @FindBy(id = "qaddress")
    private WebElement address1TextBox;

    @FindBy(id = "qaddress2")
    private WebElement address2TextBox;

    @FindBy(id = "qcity")
    private WebElement cityTextBox;

    @FindBy(id = "qstate")
    private WebElement stateDropDown;

    @FindBy(id = "qzip")
    private WebElement zipTextBox;

    @FindBy(id = "qcountry")
    private WebElement countryDropDown;

    @FindBy(id = "qphonetype")
    private WebElement phoneTypeDropDown;

    @FindBy(id = "qphonenumber")
    private WebElement phoneTextBox;

    @FindBy(id = "qphoneext")
    private WebElement phoneExtTextBox;

    @FindBy(name = "candidateinstructions")
    private List<WebElement> wantToReceiveInstRadioButtons;

    @FindBy(id = "qemail")
    private WebElement emailAddressTextBox;

    @FindBy(id = "qemailbcc")
    private WebElement bccemailAddressTextBox;

    @FindBy(name = "changecollectionsite")
    private List<WebElement> canChangeCollectionSiteRadioButtons;

    @FindBy(name = "registrationinstructions")
    private List<WebElement> dlemailRadioButtons;

    @FindBy(id = "qregistertype")
    private WebElement registerTypeDropDown;

    @FindBy(id = "qregexpiration")
    private WebElement registryExpDayCountTextBox;

    @FindBy(id = "btnBack")
    private WebElement backButton;

    @FindBy(id = "btnNext")
    private WebElement nextButton;

    @FindBy(id = "chaincustodynumber")
    private WebElement chaincustodynumberInput;

    @FindBy(id = "printReport")
    private WebElement printReportButton;

    @FindBy(id = "portalContent")
    private WebElement portalContent;

    @FindBy(id = "formErrorMessage")
    private WebElement formErrorMessage;

    @FindBy(id = "siteSelectionBack")
    private WebElement backonceButton;

    public boolean onPage2() {
        return SeleniumTest.isElementVisibleNoWaiting(By.className("drugPanel"));
    }

    public boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.name("candidateinstructions"))
                && SeleniumTest.isElementVisibleNoWaiting(By.className("drugPanel"));
    }

    public String getLastName() {
        return SeleniumTest.getText(lastNameTextBox);
    }

    public void typeLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameTextBox, lastName);
    }

    public void setChainOfCustodyNumber(String number) {
        SeleniumTest.clearAndSetText(chaincustodynumberInput, number);
    }

    public String getChainOfCustodyNumber() {
        return SeleniumTest.getText(chaincustodynumberInput);
    }

    public boolean isLastNameEnabled() {
        String disabled = lastNameTextBox.getAttribute("disabled");
        return (null == disabled) || !disabled.equals("true");
    }

    public String getformErrorMessage() {
        return SeleniumTest.getText(formErrorMessage);
    }

    public String getFirstName() {
        return SeleniumTest.getText(firstNameTextBox);
    }

    public void typeFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameTextBox, firstName);
    }

    public boolean isFirstNameEnabled() {
        String disabled = firstNameTextBox.getAttribute("disabled");
        return (null == disabled) || !disabled.equals("true");
    }

    public String getMiddleName() {
        return SeleniumTest.getText(middleNameTextBox);
    }

    public void typeMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameTextBox, middleName);
    }

    public boolean isMiddleNameEnabled() {
        String disabled = middleNameTextBox.getAttribute("disabled");
        return (null == disabled) || !disabled.equals("true");
    }

    public String getSsn() {
        return SeleniumTest.getText(ssnTextBox);
    }

    public String getPortalContent() {
        return SeleniumTest.getText(portalContent);
    }

    public void typeSsn(String ssn) {
        SeleniumTest.clearAndSetText(ssnTextBox, ssn);
    }

    public boolean isSsnEnabled() {
        String disabled = ssnTextBox.getAttribute("disabled");
        return (null == disabled) || !disabled.equals("true");
    }

    public LocalDate getDateOfBirth() {
        String dobText = SeleniumTest.getText(dateOfBirthBox);
        return LocalDate.parse(dobText, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    }

    public void typeDateOfBirth(LocalDate dob) {
        String dobText = dob.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        SeleniumTest.clearAndSetText(dateOfBirthBox, dobText);
        // Do the following to get rid of the pesky Date Picker drop-down ...
        SeleniumTest.click(address1TextBox);
    }

    public boolean isDateOfBirthEnabled() {
        String disabled = dateOfBirthBox.getAttribute("disabled");
        return (null == disabled) || !disabled.equals("true");
    }

    public String getAddress1() {
        return SeleniumTest.getText(address1TextBox);
    }

    public void typeAddress1(String address1) {
        SeleniumTest.clearAndSetText(address1TextBox, address1);
    }

    public String getAddress2() {
        return SeleniumTest.getText(address2TextBox);
    }

    public void typeAddress2(String address2) {
        SeleniumTest.clearAndSetText(address2TextBox, address2);
    }

    public String getCity() {
        return SeleniumTest.getText(cityTextBox);
    }

    public void typeCity(String city) {
        SeleniumTest.clearAndSetText(cityTextBox, city);
    }

    public UsStateTerritory getState() {
        String state = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(stateDropDown);
        return UsStateTerritory.parse(state);
    }

    public void selectState(UsStateTerritory state) {
        SeleniumTest.selectByVisibleTextFromDropDown(stateDropDown, state.getFullName());
    }

    public String getZip() {
        return SeleniumTest.getText(zipTextBox);
    }

    public void typeZip(String zipCode) {
        SeleniumTest.clearAndSetText(zipTextBox, zipCode);
    }

    public CountryCode getCountry() {
        String country = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(countryDropDown);
        return CountryCode.findByName(country).get(0);
    }

    public void selectCountry(CountryCode country) {
        SeleniumTest.selectByVisibleTextFromDropDown(countryDropDown, country.getName());
    }

    public boolean isCountryDropDownEnabled() {
        return SeleniumTest.isElementEnabled(countryDropDown);
    }

    public PhoneType getPhoneType() {
        String phoneType = SeleniumTest.getText(phoneTypeDropDown);
        return PhoneType.parse(phoneType);
    }

    public void selectPhoneType(PhoneType phoneType) {
        SeleniumTest.selectByVisibleTextFromDropDown(phoneTypeDropDown, phoneType.toString());
    }

    public String getPhoneNumber() {
        return SeleniumTest.getText(phoneTextBox);
    }

    public void typePhoneNumber(String phone) {
        final String numericPhone = "1" + phone.replaceAll("[^\\d]", "");
        SeleniumTest.clearAndSetText(phoneTextBox, numericPhone);

        // Because this phone number text box has an obnoxious mind of its own, try repeatedly
        // to set it to the desired value!
        WaitUntil.waitUntil(30, 2, () -> {
            SeleniumTest.clearAndSetText(phoneTextBox, numericPhone);
            String whatGotSet = SeleniumTest.getText(phoneTextBox);
            whatGotSet = whatGotSet.replaceAll("[^\\d]", "");
            return whatGotSet.equals(numericPhone);
        });
    }

    public void typePhoneNumberAny(String phone) {
        SeleniumTest.clearAndSetText(phoneTextBox, phone);
    }

    public void typePhoneNumber2(String phone) {
        final String numericPhone = "1" + phone.replaceAll("[^0-9()-]", "");
        SeleniumTest.clearAndSetText(phoneTextBox, numericPhone);

        // Because this phone number text box has an obnoxious mind of its own, try repeatedly
        // to set it to the desired value!
        WaitUntil.waitUntil(30, 2, () -> {
            SeleniumTest.clearAndSetText(phoneTextBox, numericPhone);
            String whatGotSet = SeleniumTest.getText(phoneTextBox);
            whatGotSet = whatGotSet.replaceAll("[^0-9()-]", "");
            return whatGotSet.equals(numericPhone);
        });
    }
    public String getPhoneExt() {
        return SeleniumTest.getText(phoneExtTextBox);
    }

    public void typePhoneExt(String phoneExt) {
        SeleniumTest.clearAndSetText(phoneExtTextBox, phoneExt);
    }


    public boolean wantsToReceiveInstructions() {
        return wantToReceiveInstRadioButtons.get(0).isSelected();
    }

    public void setWantsToReceiveInstructions(boolean wantsTo) {
        int index = (wantsTo ? 0 : 1);
        SeleniumTest.clickUntilConditionMet(wantToReceiveInstRadioButtons.get(index),
                () -> wantToReceiveInstRadioButtons.get(index).isSelected());
    }

    public String getEmailAddress() {
        return SeleniumTest.getText(emailAddressTextBox);
    }

    public void typeEmailAddress(String emailAddress) {
        SeleniumTest.clearAndSetText(emailAddressTextBox, emailAddress);
    }

    public String getbccEmailAddress() {
        return SeleniumTest.getText(bccemailAddressTextBox);
    }

    public void typebccEmailAddress(String emailAddress) {
        SeleniumTest.clearAndSetText(bccemailAddressTextBox, emailAddress);
    }

    public DashboardPage clickBackButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id("btnBack"));
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public DhsSelectCollectionSitePage clickBackOnceButton() {
        SeleniumTest.click(By.id("siteSelectionBack"));
        return PageFactory.initElements(Driver.getDriver(), DhsSelectCollectionSitePage.class);
    }

    public DhsSelectCollectionSitePage clickNextOnceButton() {
        SeleniumTest.click(By.id("btnNext"));
        return PageFactory.initElements(Driver.getDriver(), DhsSelectCollectionSitePage.class);
    }

    public DhsSelectCollectionSitePage clickNextButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id("btnNext"));

        WaitUntil.waitUntil(() -> DhsSelectCollectionSitePage.onPage());
        return PageFactory.initElements(Driver.getDriver(), DhsSelectCollectionSitePage.class);
    }

    public boolean setCandidateData(Candidate candidate) {
        boolean allIsWell = true;

        if (isLastNameEnabled()) {
            typeLastName(candidate.getLastName());
        } else {
            if (!getLastName().equals(candidate.getLastName())) {
                logger.warn("Disabled last name \"{}\" does not match \"{}\"", getLastName(), candidate.getLastName());
                allIsWell = false;
            }
        }

        if (isFirstNameEnabled()) {
            typeFirstName(candidate.getFirstName());
        } else {
            if (!getFirstName().equals(candidate.getFirstName())) {
                logger.warn("Disabled first name \"{}\" does not match \"{}\"", getFirstName(), candidate.getFirstName());
                allIsWell = false;
            }
        }

        if (isMiddleNameEnabled()) {
            typeMiddleName(candidate.getMiddleName());
        } else {
            if (!getMiddleName().equals(candidate.getMiddleName())) {
                logger.warn("Disabled middle name \"{}\" does not match \"{}\"", getMiddleName(), candidate.getMiddleName());
                allIsWell = false;
            }
        }

        if (isSsnEnabled()) {
            typeSsn(candidate.getSocialSecurityNumber());
        } else {
            if (!getSsn().equals(candidate.getSocialSecurityNumber())) {
                logger.warn("Disabled SSN \"{}\" does not match \"{}\"", getSsn(), candidate.getSocialSecurityNumber());
                allIsWell = false;
            }
        }

        if (isDateOfBirthEnabled()) {
            typeDateOfBirth(candidate.getDOB());
        } else {
            if (!getDateOfBirth().equals(candidate.getDOB())) {
                logger.warn("Disabled Date of Birth \"{}\" does not match \"{}\"",
                        getDateOfBirth().toString(), candidate.getDOB().toString());
                allIsWell = false;
            }
        }

        typeAddress1(candidate.getAddressLine1());
        typeAddress2(""); // TODO: Test Address2 line better!
        typeCity(candidate.getCity());
        selectState(UsStateTerritory.parse(candidate.getState()));
        typeZip(candidate.getZip());

        if (isCountryDropDownEnabled()) {
            selectCountry(CountryCode.findByName(candidate.getCountryOrRegion()).get(0));
        } else {
            if (!getCountry().equals(CountryCode.findByName(candidate.getCountryOrRegion()).get(0))) {
                logger.warn("Disabled Country \"{}\" does not match \"{}\"", getCountry().getName(), candidate.getCountryOrRegion());
                allIsWell = false;
            }
        }

        // TODO: Test setting other types of phone numbers ...
        selectPhoneType(PhoneType.HOME);
        typePhoneNumber(candidate.getCandidatePhone());

        setWantsToReceiveInstructions(false);
        typeEmailAddress(candidate.getEmailAddress());

        return allIsWell;
    }

    public boolean setCandidateData2(Candidate candidate) {
        boolean allIsWell = true;

        if (isLastNameEnabled()) {
            typeLastName(candidate.getLastName());
        } else {
            if (!getLastName().equals(candidate.getLastName())) {
                logger.warn("Disabled last name \"{}\" does not match \"{}\"", getLastName(), candidate.getLastName());
                allIsWell = false;
            }
        }

        if (isFirstNameEnabled()) {
            typeFirstName(candidate.getFirstName());
        } else {
            if (!getFirstName().equals(candidate.getFirstName())) {
                logger.warn("Disabled first name \"{}\" does not match \"{}\"", getFirstName(), candidate.getFirstName());
                allIsWell = false;
            }
        }

        if (isMiddleNameEnabled()) {
            typeMiddleName(candidate.getMiddleName());
        } else {
            if (!getMiddleName().equals(candidate.getMiddleName())) {
                logger.warn("Disabled middle name \"{}\" does not match \"{}\"", getMiddleName(), candidate.getMiddleName());
                allIsWell = false;
            }
        }

        if (isSsnEnabled()) {
            typeSsn(candidate.getSocialSecurityNumber());
        } else {
            if (!getSsn().equals(candidate.getSocialSecurityNumber())) {
                logger.warn("Disabled SSN \"{}\" does not match \"{}\"", getSsn(), candidate.getSocialSecurityNumber());
                allIsWell = false;
            }
        }

        if (isDateOfBirthEnabled()) {
            typeDateOfBirth(candidate.getDOB());
        } else {
            if (!getDateOfBirth().equals(candidate.getDOB())) {
                logger.warn("Disabled Date of Birth \"{}\" does not match \"{}\"",
                        getDateOfBirth().toString(), candidate.getDOB().toString());
                allIsWell = false;
            }
        }

        typeAddress1(candidate.getAddressLine1());
        typeAddress2(""); // TODO: Test Address2 line better!
        typeCity(candidate.getCity());
        selectState(UsStateTerritory.parse(candidate.getState()));
        typeZip(candidate.getZip());

        if (isCountryDropDownEnabled()) {
            selectCountry(CountryCode.findByName(candidate.getCountryOrRegion()).get(0));
        } else {
            if (!getCountry().equals(CountryCode.findByName(candidate.getCountryOrRegion()).get(0))) {
                logger.warn("Disabled Country \"{}\" does not match \"{}\"", getCountry().getName(), candidate.getCountryOrRegion());
                allIsWell = false;
            }
        }

        // TODO: Test setting other types of phone numbers ...
        selectPhoneType(PhoneType.HOME);
        typePhoneNumber2(candidate.getCandidatePhone());
        typeEmailAddress(candidate.getEmailAddress());

        return allIsWell;
    }

    public boolean canChangeCollectionSite() {
        return canChangeCollectionSiteRadioButtons.get(0).isSelected();
    }

    public void setCanChangeCollectionSite(boolean canChange) {
        int index = (canChange ? 0 : 1);
        SeleniumTest.clickUntilConditionMet(canChangeCollectionSiteRadioButtons.get(index),
                () -> canChangeCollectionSiteRadioButtons.get(index).isSelected());
    }

    public boolean canChangeDLEmail() {
        return dlemailRadioButtons.get(0).isSelected();
    }

    public int getEmailbccRadioButtonCount()
    {
        return dlemailRadioButtons.size();
    }

    public void setCanChangeDLEmail(int index) {
        SeleniumTest.clickUntilConditionMet(dlemailRadioButtons.get(index),
                () -> dlemailRadioButtons.get(index).isSelected());
    }

    public void selectRegistrationType(RegistrationType registrationType) {
        SeleniumTest.selectByVisibleTextFromDropDown(registerTypeDropDown, registrationType.toString());
    }

    public void typeRegistryExpDayCount(int dayCount) {
        SeleniumTest.clearAndSetText(registryExpDayCountTextBox, "" + dayCount);
    }

    public void typeRegistryExpDayCount2(String dayCount) {
        SeleniumTest.clearAndSetText(registryExpDayCountTextBox, "" + dayCount);
    }

    public void typebccEmail(String email) {
        SeleniumTest.clearAndSetText(bccemailAddressTextBox, "" + email);
    }

    public String getRegistryExpDayCount() {
        return SeleniumTest.getText(registryExpDayCountTextBox);
    }

    public void clickPrintReportButton() {
        SeleniumTest.click(printReportButton);
    }

    public void paperChainOfCustody(String custodyNo) {
        selectRegistrationType(TestRegistrationPage.RegistrationType.PAPER_CHAIN_OF_CUSTODY_FORM);
        setChainOfCustodyNumber("12345");
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id("btnNext"));
    }

    public void fillpaperChainOfCustody(String custodyNo) {
        selectRegistrationType(TestRegistrationPage.RegistrationType.PAPER_CHAIN_OF_CUSTODY_FORM);
        setChainOfCustodyNumber("12345");
    }

    public void clickAddbccEmailLink(int row, String email) {
        try {
            logger.info("TestRegistrationPage - Click Tab");
            Driver.getDriver().findElement(By.xpath("//div[@id='addEmailBcc']")).sendKeys(Keys.TAB);
        } catch (Exception nse) {
            // skip this because there is no parent container on this uberform
        }

        logger.info("TestRegistrationPage - Add an additional email addresses");
        SeleniumTest.click(By.xpath("//*[@id=\"addEmailBcc\"]/span[2]"));

        List<WebElement> e = Driver.getDriver().findElements(By.name("qemailbcc[]"));
        e.get(row + 1).sendKeys(email);
    }

    public boolean fillbccEmail(){
        if (getEmailbccRadioButtonCount() >= 3 ) {// Yes , No , Bcc
            logger.info("TestRegistration - Select bcc to email address I specify ");
            setCanChangeDLEmail(2);

            logger.info("Type bcc email address");
            typebccEmailAddress("screeningadminuser@sterlingts.com");

            List<String> bccrecipients = new ArrayList<>();
            for (int i = 0; i < 4; i++) { //max limit due to DHSUP-2133
                bccrecipients.add("screeningadminuser" + i + "@sterlingts.com");

                logger.info("Add " + String.valueOf(i) + " bcc address");
                clickAddbccEmailLink(i, bccrecipients.get(i));
            }
            return true;
        }
        else
            return false;
    }

    public void clickNext()
    {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id("btnNext"));
    }

    public void preRegisterTask(boolean canChangeCollectionSite, int daystoExpire) {
        setCanChangeCollectionSite(canChangeCollectionSite);
        selectRegistrationType(TestRegistrationPage.RegistrationType.PRE_REGISTER_CANDIDATE);
        typeRegistryExpDayCount(daystoExpire);
    }

    public void preRegisterTask2(boolean canChangeCollectionSite, String daystoExpire) {
        setCanChangeCollectionSite(canChangeCollectionSite);
        selectRegistrationType(TestRegistrationPage.RegistrationType.PRE_REGISTER_CANDIDATE);
        typeRegistryExpDayCount2(daystoExpire);
    }
}
