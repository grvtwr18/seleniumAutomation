package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ThreeStepFormZero {

    static {
        PageFactory.initElements(Driver.getDriver(), ThreeStepFormZero.class);
    }

    @FindBy(how = How.ID, using = "FormZero-11407_10")
    private static WebElement entityDropdown;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    public static void setEntity(String entity) {
        SeleniumTest.selectByVisibleTextFromDropDown(entityDropdown, entity);
    }


    public static void clickContinue() {
        continueButton.click();
    }
}
