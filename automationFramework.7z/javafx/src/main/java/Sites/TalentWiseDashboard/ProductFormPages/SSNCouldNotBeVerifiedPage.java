package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SSNCouldNotBeVerifiedPage extends ProductFormPages{
    @FindBy(how = How.ID, using = "btnEditSearch")
    private static WebElement editSearchButton;

    @FindBy(how = How.ID, using = "btnContinue")
    private static WebElement continueButton;

    @FindBy(how = How.CSS, using = ".head")
    public static WebElement warningText;

    @FindBy(how = How.CSS, using = ".smalltext>div")
    public static WebElement ssnMatchResultText;

    @FindBy(how = How.CSS, using = ".confirmBox")
    public static WebElement certifyText;

    @FindBy(how = How.ID, using = "confirmContinue")
    private static WebElement confirmContinueCheckbox;

    @FindBy(how = How.XPATH, using = "//div[@class='searchErrorBox']/div[@class='head' "
            + "and contains(.,'Warning — SSN Could Not Be Verified')]")
    private static WebElement searchErrorText;

    private static final By ssnMatchResultLabelLocator =
            By.xpath("//span[contains(@class, 'dbAlertColor') or contains(@class, 'dbWarningColor')]");

    static {
        PageFactory.initElements(Driver.getDriver(), SSNCouldNotBeVerifiedPage.class);
    }

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//div[@class='searchErrorBox']/div[@class='head' "
                + "and contains(.,'Warning — SSN Could Not Be Verified')]"))
                || SeleniumTest.isElementVisibleNoWaiting(ssnMatchResultLabelLocator);
    }

    /**
     * Clicks on Edit Search button to go back to the Screening Launch Page
     */
    public static void clickEditSearch() {
        SeleniumTest.click(editSearchButton);
    }

    /**
     * Clicks on Continue button to go to Review order page.
     * @return
     */
    public static ReviewOrderPage clickContinue() {
        // Too many callers to clickContinue() to force all to rename ...
        return clickContinueForReviewOrderPage();
    }

    /**
     * Clicks on Continue button to go to Review order page.
     * @return
     */
    public static ReviewOrderPage clickContinueForReviewOrderPage() {
        SeleniumTest.clickUntilConditionMet(continueButton, () -> ReviewOrderPage.onPage());
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Clicks on Continue button to go to Review Information page.
     * @return
     */
    public static ReviewInformationPage clickContinueForReviewInformationPage() {
        SeleniumTest.clickUntilConditionMet(continueButton, () -> ReviewInformationPage.onPage());
        return PageFactory.initElements(Driver.getDriver(), ReviewInformationPage.class);
    }

    /**
     * Use this with a waitUntil to bypass this interstitial if it comes up.
     * @return True if we are not on the interstitial page
     */
    public static boolean bypassedSsnVerification() {
        if (SSNCouldNotBeVerifiedPage.onPage()) {
            // To move forward to the ReviewOrderPage ...
            SSNCouldNotBeVerifiedPage.clickContinue();
            return false;
        } else {
            return true;
        }
    }

    /**
     * Checks confirm check box if the checkbox is present on the page.
     */
    public static void clickIConfirmThatIHaveReviewNameAndSSNCheckbox() {
        SeleniumTest.check(confirmContinueCheckbox);
    }

    public static boolean isConfirmContinueCheckboxPresented() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("confirmContinue"));
    }

    /**
     * Clicks on Continue button
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        SeleniumTest.click(continueButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks on Continue button
     * @return
     */
    public static SelectAKAsToSearchPage clickContinueToSelectAkaPage() {
        SeleniumTest.click(continueButton);
        return PageFactory.initElements(Driver.getDriver(), SelectAKAsToSearchPage.class);
    }

    public static String getSsnMatchResult() {
        return SeleniumTest.getTextByLocator(ssnMatchResultLabelLocator);
    }
}
