package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Created by jgupta on 4/20/2016.
 */
public class DMVDrivingRecords50StatesPlusDCAndPRFees267LaunchPage extends ProductFormPages {
    @FindBy(how = How.ID, using = "qs_Group13-0_1")
    private static WebElement stateDropDown;

    @FindBy(how = How.ID, using = "qfcramanualagree")
    private static WebElement iHaveProvidedTheDisclosureCheckBox;

    @FindBy(how = How.ID, using = "qmm")
    private static WebElement monthDD;

    @FindBy(how = How.ID, using = "qdd")
    private static WebElement dayDD;

    @FindBy(how = How.ID, using = "qyy")
    private static WebElement yearDD;

    @FindBy(how = How.ID, using = "qdl_Group13-0_1")
    private static WebElement licenseTextBox;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    static {
        PageFactory.initElements(Driver.getDriver(), DMVDrivingRecords50StatesPlusDCAndPRFees267LaunchPage.class);
    }

    /**
     * Checks I have provided disclosure checkbox.
     */
    public static void checkIHaveProvidedTheDisclosure() {
        SeleniumTest.check(iHaveProvidedTheDisclosureCheckBox);
    }

    public static boolean isDmvDrivingRecordsSectionVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qs_Group13-0_1"))
               && SeleniumTest.isElementVisibleNoWaiting(By.id("qdl_Group13-0_1"));
    }

    /**
     * Fill DMV Driving Records section.
     * @param state Province where driving license was obtained.
     * @param license License number corresponding to the province.
     */
    public static void fillDMVDrivingRecordsSection(String state, String license) {
        Select stateDD = new Select(stateDropDown);
        stateDD.selectByVisibleText(state);

        SeleniumTest.clearAndSetText(licenseTextBox, license);
    }

    /**
     * Clicks on Continue button
     * @param returnedClass Should belong to a page extending ProductFormPages
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Selects date of birth.
     * @param dob Date of birth
     */
    public static void selectDateOfBirth(LocalDate dob) {
        String month = dob.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);
        String day = (Integer.toString(dob.getDayOfMonth()));
        String year = (Integer.toString(dob.getYear()));

        Select monthDropDown = new Select(monthDD);
        monthDropDown.selectByVisibleText(month);

        Select dayDropDown = new Select(dayDD);
        dayDropDown.selectByVisibleText(day);

        Select yearDropDown = new Select(yearDD);
        yearDropDown.selectByVisibleText(year);
    }
}
