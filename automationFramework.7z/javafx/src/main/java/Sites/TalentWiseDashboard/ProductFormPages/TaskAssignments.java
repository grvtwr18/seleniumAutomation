package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import static WebDriver.Driver.getDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by abrackett on 10/19/16.
 */
public class TaskAssignments {

    private static final Logger staticLogger = LoggerFactory
            .getLogger(TaskAssignments.class);

    static {
        PageFactory.initElements(getDriver(), TaskAssignments.class);
    }

    /**
     * Sets the task due date
     * @param lDate Date to set
     * @param number 1 based task number of the due date to set.
     */
    public static void setTaskDueDate(LocalDate lDate, int number) {
        WebElement taskDueDateBox = getDriver().findElement(By.id("dp_qduedate" + number));
        taskDueDateBox.clear();
        SeleniumTest.FireFoxWorkArounds
                .setCalendarControl_uu_Dash_MM_Dash_dd(lDate, "dp_qduedate" + number,
                                                       "qduedate" + number);
        staticLogger.info("Task {} Due Date set to {}",
                          number,
                          lDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
    }

    /**
     * Selects the task group
     * @param groupName group Name
     * @param groupNumber 1 based number of the task you are trying to set.
     */
    public static void selectTaskGroup(String groupName, int groupNumber) {
        WebElement groupDropDown = getDriver().findElement(By.id("qverifiergroupid" +
                                                                        groupNumber));
        SeleniumTest.selectByVisibleTextFromDropDown(groupDropDown, groupName);
    }

    /**
     * Selects the verifier
     * @param verifier Verifier to select
     * @param verifierNumber 1 based task number of the verifier to select
     */
    public static void selectTaskVerifier(String verifier, int verifierNumber) {
        WebElement verifierDropDown = Driver.getDriver().findElement(By.id("qverifierid" +
                                                                    verifierNumber));
        SeleniumTest.selectByVisibleTextFromDropDown(verifierDropDown, verifier);
    }

    public static void clickCreateNewContributorVerifier(int taskNumber) {
        WebElement createContributorButton = Driver.getDriver().findElement(By.id
                ("createNewVerifierBtnqverifierid" + taskNumber));
        createContributorButton.click();
        WaitUntil.waitUntil(
                () -> getDriver().findElement(By.id("fnqverifierid" + taskNumber)).isDisplayed());
    }

    public static void setNewVerifierFirstName(String firstName, int verifierNumber) {
        WebElement newVerifierFirstNameBox = Driver.getDriver().findElement(By.id("fnqverifierid"
                                                                                  +
                                                                                  verifierNumber));
        SeleniumTest.clearAndSetText(newVerifierFirstNameBox, firstName);
    }

    public static void setNewVerifierLastName(String lastName, int verifierNumber) {
        WebElement newVerifierLastNameBox = Driver.getDriver().findElement(By.id("lnqverifierid"
                                                                                 + verifierNumber));
        SeleniumTest.clearAndSetText(newVerifierLastNameBox, lastName);
    }

    public static void setNewVerifierEmailAddress(String emailAddress, int verifierNumber) {
        WebElement newVerifierEmailAddress = Driver.getDriver().findElement(By.id
                ("emailqverifierid" + verifierNumber));
        SeleniumTest.clearAndSetText(newVerifierEmailAddress, emailAddress);
    }

    public static class Navigation extends Sites.TalentWiseDashboard.ProductFormPages.Navigation {

    }
}
