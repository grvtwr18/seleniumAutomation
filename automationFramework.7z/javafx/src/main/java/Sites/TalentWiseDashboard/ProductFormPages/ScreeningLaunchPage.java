package Sites.TalentWiseDashboard.ProductFormPages;

import Data.locations.us.UsStateTerritory;
import Sites.AdminConsole.CustomerSupport.ScreeningSupport.Reports.Enums.City;
import Sites.AdminConsole.CustomerSupport.ScreeningSupport.Reports.Enums.State;
import Sites.TalentWiseDashboard.CustomerLoginPage;
import Sites.CandidatePortal.Enums.Country;
import Sites.CandidatePortal.Forms.CandidateReviewInformationPage;
import Sites.Site;
import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.TicketForm;
import Sites.URL;
import TWFramework.BodyTextHelper;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import Data.Utf8StringCreator;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import Sites.TalentWiseDashboard.EditProfileModal;
import static Utility.Onboarding.OnboardingUtility.Verbs.selectByVisibleTextFromDropDown;
import Sites.TalentWiseDashboard.CustomerDashboardPages;
/**
 * Page object that represents the Product Form page on the TalentWise Dashboard website that is reached at the
 * beginning of the product launching process and provides a variety of fields to be filled out.
 *
 * @author eelefson
 */
public class ScreeningLaunchPage extends ProductFormPages {
    public static void selectLocationOfEmployment(Country country) {
        SeleniumTest.selectByValueFromDropDown(locationOfEmploymentCountry, country.abbreviation());
    }

    public enum InitiateSearchOption {
        VIA_UBERFORM_LAUNCH,
        VIA_TICKET
    }


    public Header header;
    public Footer footer;

    private static final Logger logger =
            LoggerFactory.getLogger("Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchPage");

    @FindBy(how = How.CLASS_NAME, using = "dbContentWrapper")
    private static WebElement launchContent;

    @FindBy(how = How.ID, using = "packageDescription")
    private static WebElement packageDescription;

    @FindBy(how = How.ID, using = "productsAdded")
    private static WebElement productsAdded;

    @FindBy(how = How.XPATH, using = "//select[@id='specifyqs_Group1331-0_2']")
    private WebElement AdditionalCriminalStateDropdown;

    @FindBy(how = How.XPATH, using = "//select[@id='specifyqs_Group1331-0_1']")
    private WebElement AdditionalCriminalStateDropdownfirstproduct;

    @FindBy(how = How.XPATH, using = "//select[@id='qfips_Group1331-0_1']")
    private WebElement AdditionalCriminalCountyDropdownfirstproduct;

    @FindBy(how = How.XPATH, using = "//select[@id='qfips_Group1331-0_2']")
    private WebElement AdditionalCriminalCountyDropdown;

    private static final String CSS_SEARCH_ERROR_LOCATOR =
            "#UberSearch > div > div.dbContainer.searchContainer > div.searchColumnLeft.uberColumnLeft > div" + ".searchErrorBox > div.body";

    @FindBy(how = How.CSS, using = CSS_SEARCH_ERROR_LOCATOR)
    private static WebElement searchErrorBox;

    @FindBy(how = How.ID, using = "qrescountry")
    private static WebElement currentCountryOfResidenceDropDown;

    private static final By reuseDisclosureCheckboxLocator = By.id("reuseDisclosure");

    @FindBy(how = How.ID, using = "qfcramanualagree")
    public static WebElement fcraManualAgreeCheckBox;

    @FindBy(how = How.ID, using = "qfcrareuseagree")
    private static WebElement reuseDisclosureCheckbox;

    @FindBy(how = How.XPATH, using = "//a[@href='/fcra/files/FCRA_Summary_of_Rights.pdf']")
    private static WebElement fcraDocumentLink;

    @FindBy(how = How.ID, using = "qfcraedagree")
    public static WebElement fcraElectronicDisclosureAgreeCheckBox;

    //this is used on the launch form for County Criminal Fast Lane.  possibly elsewhere as well
    @FindBy(how = How.NAME, using = "qfcraagree")
    public static WebElement fcraWrittenAuthorization;

    @FindBy(how = How.ID_OR_NAME, using = "qf")
    public static WebElement firstNameBox;

    @FindBy(how = How.ID_OR_NAME, using = "qmi")
    private static WebElement middleNameBox;

    @FindBy(how = How.ID, using = "qnomico")
    private static WebElement middleNameNotAvailableCheckBox;

    private static final String confirmNoMiddleNameCheckBoxLocatorById = "qnomi";

    @FindBy(how = How.ID, using = confirmNoMiddleNameCheckBoxLocatorById)
    private static WebElement confirmNoMiddleNameCheckBox;

    private static final String pleaseProvideMiddleNameFieldLocatorByCss =
            "#uberform > div:nth-child(4) > div > div.subformerror";

    @FindBy(how = How.CSS, using = pleaseProvideMiddleNameFieldLocatorByCss)
    private static WebElement pleaseProvideMiddleNameField;

    @FindBy(how = How.ID_OR_NAME, using = "qn")
    public static WebElement lastNameBox;

    @FindBy(how = How.NAME, using = "qfalias0")
    public static WebElement alternateFirstNameBox;

    @FindBy(how = How.NAME, using = "qnalias0")
    public static WebElement alternateLastNameBox;

    @FindBy(how = How.ID_OR_NAME, using = "qssn")
    public static WebElement ssnBox;

    @FindBy(how = How.ID_OR_NAME, using = "qmm")
    public static WebElement monthDropDownBox;

    @FindBy(how = How.ID_OR_NAME, using = "qdd")
    public static WebElement dayDropDownBox;

    @FindBy(how = How.ID_OR_NAME, using = "qyy")
    public static WebElement yearDropDownBox;

    @FindBy(how = How.NAME, using = "qp")
    public static WebElement phoneNumberBox;

    @FindBy(how = How.NAME, using = "qee")
    public static WebElement emailBox;

    public static final By addAdditionalProductsButtonLocator = By.id("AddProductButton");
    @FindBy(how = How.ID, using = "AddProductButton")
    public static WebElement addAdditionalProductsButton;

    @FindBy(how = How.NAME, using = "reshist")
    public static WebElement resHist;

    @FindBy(how = How.NAME, using = "qresfrommonth")
    public static WebElement fromFirstMonth;

    @FindBy(how = How.NAME, using = "qresfrommonthprev0")
    public static WebElement fromSecondMonth;

    @FindBy(how = How.NAME, using = "qresfrommonthprev1")
    public static WebElement fromThirdMonth;

    @FindBy(how = How.NAME, using = "qresfromyear")
    public static WebElement fromFirstYear;

    @FindBy(how = How.NAME, using = "qresfromyearprev0")
    public static WebElement fromSecondYear;

    @FindBy(how = How.NAME, using = "qresfromyearprev1")
    public static WebElement fromThirdYear;

    @FindBy(how = How.NAME, using = "qa")
    public static WebElement addressBox;

    @FindBy(how = How.NAME, using = "qaprev0")
    public static WebElement addressBox2;

    @FindBy(how = How.NAME, using = "qaprev1")
    public static WebElement addressBox3;

    @FindBy(how = How.ID_OR_NAME, using = "qc")
    public static WebElement cityBox;

    @FindBy(how = How.ID, using = "qs")
    public static WebElement stateDropDownBox;

    @FindBy(how = How.ID, using = "qz")
    public static WebElement zipCodeBox;

    @FindBy(how = How.ID, using = "qempstate")
    public static WebElement locationOfEmploymentDropDown;

    @FindBy(how = How.ID, using = "qempcity")
    public static WebElement locationOfEmploymentCity;

    @FindBy(how = How.ID, using = "qempcountry")
    public static WebElement locationOfEmploymentCountry;

    @FindBy(how = How.ID, using = "btnSubmit")
    public static WebElement continueSubmitButton;

    @FindBy(how = How.ID, using = "btnContinue")
    public static WebElement continueContinueButton;

    //this has an ID, but it varies
    private static final String ADD_EMPLOYMENT_VERIFICATION_EXPECTED_LINK = "Add Employment Verification";
    private static final String ADD_EDUCATION_VERIFICATION_EXPECTED_LINK = "Add Education Verification";

    @FindBy(how = How.CSS, using = "input#qcprev0")
    public static WebElement previousResidenceCityTextBox;

    @FindBy(how = How.CSS, using = "select#qsprev0")
    public static WebElement previousResidenceStateDropDown;

    @FindBy(how = How.CSS, using = "input#qzprev0[maxlength='10']")
    public static WebElement previousResidenceZipTextBox;

    @FindBy(how = How.CSS, using = "input#qcprev1")
    public static WebElement previousResidenceCityTextBox1;

    @FindBy(how = How.CSS, using = "select#qsprev1")
    public static WebElement previousResidenceStateDropDown1;

    @FindBy(how = How.CSS, using = "input#qzprev1[maxlength='10']")
    public static WebElement previousResidenceZipTextBox1;

    @FindBy(name = "billingcode")
    private static WebElement selectBillingcode;

    @FindBy(name = "specifyqs_Group72-0_1")
    private static WebElement selectAdditionalStateWideSearch;

    @FindBy(id = "specifyloc_Group28-0_1_1")
    private static WebElement specifyJurisdiction;

    @FindBy(id = "specifyloc_Group313-0_1_1")
    private static WebElement specifyJurisdictionRadioButton;

    @FindBy(id = "specifyqs_Group313-0_1")
    private static WebElement selectSpecifyJurisdictionStateDropdown;

    @FindBy(id = "qfips_Group28-0_1")
    private static WebElement jurisdictionCounty;

    @FindBy(id = "govtId-value-text")
    private static WebElement govtIdValueText;

    @FindBy(xpath = "//input[@id[starts-with(., 'qshow_Group')]]")
    private static WebElement checkboxEnableDisable;

    @FindBy(xpath = "//select[@id[starts-with(., 'qcert_Group')]]")
    private static WebElement certificationDegree;

    @FindBy(xpath = "//input[@name[starts-with(., 'qdgre_Group')]]")
    private static WebElement fieldOfStudyMajor;

    @FindBy(xpath = "//input[@id[starts-with(., 'qschn_Group')]]")
    private static WebElement schoolName;

    @FindBy(xpath = "//input[@id[starts-with(., 'qschc_Group')]]")
    private static WebElement schoolCity;

    @FindBy(xpath = "//select[@id[starts-with(., 'qschs_Group')]]")
    private static WebElement schoolStateTerritory;

    @FindBy(xpath = "//select[@id[starts-with(., 'qdidgraduate_Group')]]")
    private static WebElement selectorDidYouGraduate;

    @FindBy(xpath = "//input[@id[starts-with(., 'sameascurrent_Group')]]")
    private static WebElement checkboxSameAsCurrent;

    @FindBy(xpath = "//input[@id[starts-with(., 'qfedalias_Group')]]")
    private static WebElement firstName;

    @FindBy(xpath = "//input[@id[starts-with(., 'qnedalias_Group')]]")
    private static WebElement lastName;

    @FindBy(xpath = "//select[@id='qo_Group25-0_1']")
    private static WebElement internationalCrimCountrySelect;

    @FindBy(xpath = "//select[@id='specifyqs_Group520-0_1']")
    private static WebElement sexOffenderSelectStateSelect;

    @FindBy(xpath = "//input[@id='specifyloc_Group520-0_1_1']")
    private static WebElement specifyJurisdictionRadialButton;

    @FindBy(xpath = "//div[@class='searchErrorBox']/div[2]/ul/li")
    private static WebElement screeningLaunchPageErrorInformation;

    @FindBy(xpath = "//div[@class='searchErrorBox']")
    private static WebElement screeningLaunchPageCompleteErrorInformation;
    private static final By screeningLaunchPageCompleteError = By.xpath("//div[@class='searchErrorBox']");

    @FindBy(id = "refcode")
    private static WebElement refCodeDropDown;

    @FindBy(id = "qshow_147_1")
    private static WebElement creditCheckbox;

    @FindBy(id = "qnpi_10840_1")
    private static WebElement npiTextBox;

    @FindBy(how = How.XPATH, using = ".//*[@id=\"qfcramanualagree\"]/../following-sibling::div/p")
    private static WebElement selfDislosureText;

    @FindBy(how = How.XPATH, using = ".//*[@id=\"qfcraedagree\"]/../following-sibling::div/p")
    private static WebElement electronicDislosureAndAuthorizationText;

    @FindBy(id = "qdl_Group24-0_1")
    private static WebElement driverLicensebox;

    @FindBy(id = "qshow_Group899-0_1_1")
    private static WebElement criminalSelfDisclosure_Yes;

    @FindBy(id = "qaddinf_Group899-0_1")
    private static WebElement addDisclosureInfo;

    @FindBy(id = "qshow_Group47-0_1")
    private static WebElement cbCriminalCheckByJurisdiction;

    @FindBy(id = "specifyqs_Group47-0_1")
    private static WebElement state;

    @FindBy(id = "qfips_Group47-0_1")
    private static WebElement county;

    @FindBy(id = "product_777")
    private WebElement Empcheckbox;

    @FindBy(id = "product_774")
    private WebElement Educheckbox;

    @FindBy(id = "product_775")
    private WebElement Refcheckbox;

    @FindBy(id = "product_773")
    private WebElement Crimcheckbox;

    @FindBy(id = "product_776")
    private   WebElement Credcheckbox;

    @FindBy(id = "issuer_document_1")
    private static WebElement stateDriverLicenseDropDown;

    @FindBy(id = "id_document_1")
    private static WebElement stateDriverLicensebox;

    private static final String reasonForTestDropDownLocatorPath = "//*[starts-with(@id, \"qtestreason_Group\")]";

    private static final By     reasonForTestDropDownLocator     = By.xpath(reasonForTestDropDownLocatorPath);
    @FindBy(how = How.XPATH, using = reasonForTestDropDownLocatorPath)

    private static WebElement reasonForTestDropDown;

    private static final String reasonForTestErrorMessageLocatorPath =
            "//*[starts-with(@id, \"div_Group\")]/div[@class=\"subformerror\"]";
    private static final By     reasonForTestErrorMessageLocator     = By.xpath(reasonForTestErrorMessageLocatorPath);
    @FindBy(how = How.XPATH, using = reasonForTestErrorMessageLocatorPath)
    private static WebElement reasonForTestErrorMessage;

    @FindBy(xpath = "//select[contains(@class,'country')]")
    private static WebElement schoolCountry;

    @FindBy(id = "qmf")
    private static WebElement gender;

    @FindBy(id = "qshow_Group229-0_1")
    private static WebElement includeConsentBasedSsnVerificationForTheCandidate;

    @FindBy(xpath = "//input[@id='generalSearch']")
    private WebElement SearchtextboxAddproducts;

    @FindBy(className = "dbAlertColor")
    private static WebElement alertMessage;

    @FindBy(id = "spanAdd_Group351-0" )
    private static WebElement addEmploymentVerification;

    @FindBy(id = "qshow_388_1_1")
    private WebElement criminalHistorySelfDisclosure_Yes;

    @FindBy(id = "qaddinf_388_1")
    private static WebElement addCrimHistoryDisclosureInfo;

    @FindBy(name = "qlicn_Group63-0_1")
    private WebElement FACIS_LicenseID;

    @FindBy(name = "qs_Group63-0_1")
    private WebElement FACIS_State;

    @FindBy(how = How.LINK_TEXT, using = "Add Name")
    public WebElement addNamesLink;

    @FindBy(how = How.CSS, using = "a#ui-id-4")
    private WebElement schoolSuggestionBox;

    @FindBy(how = How.ID, using = "qschn_Group40-0_1")
    private WebElement schoolBox;

    // Poland Specific elements

    @FindBy(xpath = "//div[@class='stripe'][4]/div[@class='_uploadFileFormField'][3]/div[@class='searchField "
            + "searchFieldWide']/p/a")
    private static WebElement polandCriminalSearchApplicationFormandLetterofAuthorityDownloadLink;

    private final By licenseCountryDropdownLocator = By.name("qo_Group24-0_1");
    private final By licenseStateUSDropdownLocator = By.id("qs_Group24-0_1_US");
    private final By licenseStateCADropdownLocator = By.id("qs_Group24-0_1_CA");

    /**
     * Initialize WebElements
     */
    static {
        PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
    }

    /**
     * Constructs a new Product Form page object.
     */
    public ScreeningLaunchPage() {
        this.header = PageFactory.initElements(Driver.getDriver(), Header.class);
        this.footer = PageFactory.initElements(Driver.getDriver(), Footer.class);
    }

    public static String getPackageDescriptions() {
        return packageDescription.getText();
    }

    public static String getAlacartePackageDescriptions() {
        return productsAdded.getText();
    }

    public static boolean isAddAdditionalProductsButtonPresent() {
        return SeleniumTest.isElementPresent(addAdditionalProductsButton);
    }

    public static void clickAddAdditionalProductsButton() {
        addAdditionalProductsButton.click();
    }

    public static String getTitleAdditionalPackage(String productId) {
        return Driver.getDriver().findElement(By.xpath("//*[@name=\"" + productId + "_1\"]/following-sibling::div"))
                .getText();
    }

    public static boolean isSearchErrorVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector(CSS_SEARCH_ERROR_LOCATOR));
    }

    public static String getSearchErrorText() {
        return SeleniumTest.getText(searchErrorBox);
    }

    /**
     * @return the uberform titles added in screening launch page
     */
    public static List<String> getAddedFormsTitle() {
        List<WebElement> formTitleElements = Driver.getDriver().findElements(By.xpath("//div[@class='head']/h3"));
        List<String>     formTitles        = new ArrayList<String>();
        for (int i = 0; i < formTitleElements.size(); i++) {
            formTitles.add(formTitleElements.get(i).getText());
        }
        return formTitles;
    }

    public static boolean isFcraDocLinkPresent() {
        return fcraDocumentLink.isDisplayed();
    }

    /**
     * @deprecated this is redundant with the new locator
     */
    public static boolean isFcraDocLinkTargetCorrect() {
        return fcraDocumentLink.getAttribute("HREF")
                .contains(URL.getBasicHost() + "/fcra/files/FCRA_Summary_of_Rights.pdf");
    }

    public static void selectCurrentCountryOfResidence(String country) {
        SeleniumTest.waitForElementEnabled(currentCountryOfResidenceDropDown);
        SeleniumTest.selectByVisibleTextFromDropDown(currentCountryOfResidenceDropDown, country);
        SeleniumTest.waitForElementEnabled(currentCountryOfResidenceDropDown);
    }

    public static void clickaddEmploymentVerification() {
        addEmploymentVerification.click();
    }

    public  void selectAdditionalStateDropdown(String country) {
        SeleniumTest.waitForElementEnabled(AdditionalCriminalStateDropdown);
        SeleniumTest.selectByVisibleTextFromDropDown(AdditionalCriminalStateDropdown, country);
        SeleniumTest.waitForElementEnabled(AdditionalCriminalStateDropdown);
    }

    public void selectAdditionalCountyDropdown(String county) {
        SeleniumTest.waitForElementEnabled(AdditionalCriminalCountyDropdown);
        SeleniumTest.selectByVisibleTextFromDropDown(AdditionalCriminalCountyDropdown, county);
        SeleniumTest.waitForElementEnabled(AdditionalCriminalCountyDropdown);
    }

    public void selectAdditionalStateDropdownfirstproduct(String country) {
        SeleniumTest.waitForElementEnabled(AdditionalCriminalStateDropdownfirstproduct);
        SeleniumTest.selectByVisibleTextFromDropDown(AdditionalCriminalStateDropdownfirstproduct, country);
        SeleniumTest.waitForElementEnabled(AdditionalCriminalStateDropdownfirstproduct);
    }

    public void selectAdditionalCountyDropdownfirstproduct(String county) {
        SeleniumTest.waitForElementEnabled(AdditionalCriminalCountyDropdownfirstproduct);
        SeleniumTest.selectByVisibleTextFromDropDown(AdditionalCriminalCountyDropdownfirstproduct, county);
        SeleniumTest.waitForElementEnabled(AdditionalCriminalCountyDropdownfirstproduct);
    }

    public static void selectCurrentCountryOfResidenceByCountryCode(String countryCode) {
        // Observed how code calling this routine actually waited for the WebElement to be enabled after selection
        // was made ...
        SeleniumTest.waitForElementEnabled(currentCountryOfResidenceDropDown);
        SeleniumTest.selectByValueFromDropDown(currentCountryOfResidenceDropDown, countryCode);
        SeleniumTest.waitForElementEnabled(currentCountryOfResidenceDropDown);
    }

    public static boolean isFcraManualAgreeCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qfcramanualagree"));
    }

    /**
     * Checks the FCRA Manual Agreement checkbox.
     */
    public static void clickFCRAManualAgreeCheckBox() {
        try {
            Thread.sleep(3000);
            SeleniumTest.check(fcraManualAgreeCheckBox);
        } catch (Exception e) {
        }

    }

    public static void unCheckFCRAManualAgreeCheckBox() {
        SeleniumTest.unCheck(fcraManualAgreeCheckBox);
    }

    /**
     * Clicks the FCRA Electronic Disclosure Agreement checkbox.
     */
    public static void clickFCRAElectronicDisclosureAgreeCheckBox() {
        SeleniumTest.check(fcraElectronicDisclosureAgreeCheckBox);
    }

    /**
     * Checks checkbox for reusing EDA
     */
    public static void checkReuseDisclosureCheckbox() {
        SeleniumTest.check(reuseDisclosureCheckbox);
    }


    public static void checkFcraWrittenAuthorizationCheckBox() {
        SeleniumTest.check(fcraWrittenAuthorization);
    }

    public static void typeDriverLicense(String license) {
        SeleniumTest.clearAndSetText(driverLicensebox, license);
    }

    /**
     * Types the specified first name into the first name text box.
     *
     * @param firstName The first name to be typed
     */
    public static void typeFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
    }

    public static String getFirstName() {
        return firstNameBox.getAttribute("value");
    }

    /**
     * Types the specified middle name into the middle name text box.
     *
     * @param middleName The middle name to be typed
     */
    public static void typeMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameBox, middleName);
    }

    public static String getMiddleName() {
        return SeleniumTest.getText(middleNameBox);
    }

    public static void checkMiddleNameNotAvailableCheckBox() {
        SeleniumTest.check(middleNameNotAvailableCheckBox);
    }

    public static void uncheckMiddleNameNotAvailableCheckBox() {
        SeleniumTest.unCheck(middleNameNotAvailableCheckBox);
    }

    public static boolean isMiddleNameNotAvailableChecked() {
        return SeleniumTest.isCheckboxChecked(middleNameNotAvailableCheckBox);
    }

    /**
     * Checks the "... have confirmed ... does not have a middle name" checkbox.
     */
    public static void checkConfirmNoMiddleNameCheckBox() {
        SeleniumTest.check(confirmNoMiddleNameCheckBox);
    }

    /**
     * Unhecks the "... have confirmed ... does not have a middle name" checkbox.
     */
    public static void uncheckConfirmNoMiddleNameCheckBox() {
        SeleniumTest.unCheck(confirmNoMiddleNameCheckBox);
    }

    /**
     * Is the "... have confirmed ... does not have a middle name" checkbox checked?
     *
     * @return true if "confirm no middle name" is checked
     */
    public static boolean isConfirmNoMiddleNameChecked() {
        return SeleniumTest.isCheckboxChecked(confirmNoMiddleNameCheckBox);
    }

    /**
     * Is the "... have confirmed ... does not have a middle name" checkbox displayed?
     *
     * @return true if "confirm no middle name" checkbox is displayed
     */
    public static boolean isConfirmNoMiddleNameCheckboxDisplayed() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(confirmNoMiddleNameCheckBoxLocatorById));
    }

    /**
     * Validates whether checkbox for reusing EDA is visible
     */
    public static boolean isReuseDisclosureCheckboxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(reuseDisclosureCheckboxLocator);
    }

    public static boolean isIssuingCountryRegionForDocumentVisible(String num) {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("country_document_" + num));
    }

    public static boolean isIDDocumentVisible(String num) {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("id_document_" + num));
    }

    public static boolean isUploadIdDocumentVisible(String num) {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("file_document_" + num));
    }

    public static boolean isPolandLetterDownloadLinkVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath(
                "//div[@class='stripe'][4]/div[@class='_uploadFileFormField'][3]/div[@class='searchField "
                        + "searchFieldWide']/p/a"));
    }

    public static void typeidDocument(String num, String documentNumber) {
        SeleniumTest.clearAndSetText(By.id("id_document_" + num), documentNumber);
    }

    public static void clearidDocument(String num) {
        SeleniumTest.clearAndSetText(By.id("id_document_" + num), "");
    }

    public static void uploadPolandDocument(String filePath, String num) {
        WebElement fileChooser = Driver.getDriver().findElement(By.id("file_document_" + num));
        fileChooser.sendKeys(filePath);
    }

    public static void clickPolandLetterDownloadLink() {
        SeleniumTest.click(polandCriminalSearchApplicationFormandLetterofAuthorityDownloadLink);
    }

    public static boolean isIDDocumentsErrorMessageVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(
                By.xpath("//div[@class='stripe'][4]/div[@class='_uploadFileFormField'][1]/div[@class='subformerror']"));
    }

    public static String getIDDocumentsErrorMessageText() {
        return SeleniumTest.getTextByLocator(
                By.xpath("//div[@class='stripe'][4]/div[@class='_uploadFileFormField'][1]/div[@class='subformerror']"));
    }

    public static void clickContinue() {
        SeleniumTest.click(By.id("btnSubmit"));
    }

    /**
     * Is the message field "Please provide a middle name ..." displayed?
     *
     * @return true if the "Please provide a middle name" field is displayed
     */
    public static boolean isPleaseProvideMiddleNameFieldDisplayed() {
        final By locator = By.cssSelector(pleaseProvideMiddleNameFieldLocatorByCss);

        return SeleniumTest.isElementVisibleNoWaiting(locator) && !SeleniumTest
                .isNullOrEmpty(SeleniumTest.getTextByLocator(locator));
    }

    /**
     * Types the specified last name into the last name text box.
     *
     * @param lastName The last name to be typed
     */
    public static void typeLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
    }

    public static String getLastName() {
        return lastNameBox.getAttribute("value");
    }

    /**
     * Types the specified alternate first name into the alternate first name text box.
     *
     * @param alternateFirstName The alternate first name to be typed
     */
    public static void typeAlternateFirstName(String alternateFirstName) {
        SeleniumTest.clearAndSetText(alternateFirstNameBox, alternateFirstName);
    }

    /**
     * Types the specified alternate last name into the alternate last name text box.
     *
     * @param alternateLastName The alternate last name to be typed
     */
    public static void typeAlternateLastName(String alternateLastName) {
        SeleniumTest.clearAndSetText(alternateLastNameBox, alternateLastName);
    }

    /**
     * Types the specified SSN into the SSN text box.
     *
     * @param ssn The SSN to be typed
     */
    public static void typeSSN(String ssn) {
        SeleniumTest.clearAndSetText(ssnBox, ssn);
    }

    public static String getSSN() {
        return ssnBox.getAttribute("value");
    }

    public static boolean isSsnTextBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.name("qssn")) || SeleniumTest
                .isElementVisibleNoWaiting(By.id("qssn"));
    }

    public static String getLocationOfEmploymentState() {
        Select stateSelect = new Select(locationOfEmploymentDropDown);
        return stateSelect.getFirstSelectedOption().getText();
    }

    public static String getLocationOfEmploymentCity() {
        return locationOfEmploymentCity.getAttribute("value");
    }

    public static void navigateToSearchForm(String uberformId, String candidateId) {
        Driver.getDriver().navigate()
                .to(URL.getURL(Site.CUSTOMER_DASHBOARD) + "/screening/search" + ".php?searchform=uber&ufid="
                        + uberformId + "&CandidateID=" + candidateId);
    }

    public static void navigateToSearchForm(String uberformId) {
        navigateToSearchForm(uberformId, "");
    }

    public static boolean getCreditReportIncludedCheckboxValue() {
        return SeleniumTest.isCheckboxChecked(creditCheckbox);
    }

    /**
     * Selects a month from the month drop down box based on the date provided.
     *
     * @param month The month to be used
     */
    public void selectMonth(String month) {
        SeleniumTest.selectShortMonthByVisibleText(monthDropDownBox, month);
    }

    public String getMonth() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(monthDropDownBox);
    }

    /**
     * Selects a day from the day drop down box based on the date provided.
     *
     * @param day The day to be used
     */
    public void selectDay(String day) {
        SeleniumTest.selectByVisibleTextFromDropDown(dayDropDownBox, day);
    }

    public String getDay() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(dayDropDownBox);
    }

    /**
     * Selects a year from the year drop down box based on the date provided.
     *
     * @param year The year to be used
     */
    public void selectYear(String year) {
        SeleniumTest.selectByVisibleTextFromDropDown(yearDropDownBox, year);
    }

    public String getYear() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(yearDropDownBox);
    }

    /**
     * Types the specified phone number into the phone number text box.
     *
     * @param phoneNumber The phone number to be typed
     */
    public static void typePhoneNumber(String phoneNumber) {
        SeleniumTest.clearAndSetText(phoneNumberBox, phoneNumber);
    }

    /**
     * Types the specified email into the email text box.
     *
     * @param email The email to be typed
     */
    public static void typeEmail(String email) {
        SeleniumTest.clearAndSetText(emailBox, email);
    }

    public static String getEmail() {
        return emailBox.getAttribute("value");
    }

    public static boolean isEmailTextBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.name("qee"));
    }

    public static boolean isAddAdditionalProductsButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(addAdditionalProductsButtonLocator);
    }

    /**
     * Verify "Residence History" label is present
     */
    public static void verifyResidenceHistoryLabel() {
        SeleniumTest.verifyElementPresent(resHist);
    }

    /**
     * Types the specified address into the address text box.
     *
     * @param address The address to be typed
     */
    public static void typeAddress(String address) {
        SeleniumTest.clearAndSetText(addressBox, address);
    }

    public static String getAddress() {
        return addressBox.getAttribute("value");
    }

    /**
     * Types the specified address into the Previous address1 text box.
     *
     * @param address The address to be typed
     */
    public static void typeAddress2(String address) {
        SeleniumTest.clearAndSetText(addressBox2, address);
    }

    /**
     * Types the specified address into the Previous address2 text box.
     *
     * @param address The address to be typed
     */
    public static void typeAddress3(String address) {
        SeleniumTest.clearAndSetText(addressBox3, address);
    }

    /**
     * Types the specified city into the city text box.
     *
     * @param city The city to be typed
     */
    public static void typeCity(String city) {
        SeleniumTest.clearAndSetText(cityBox, city);
    }

    public static String getCity() {
        return cityBox.getAttribute("value");
    }

    /**
     * Types the specified ZIP code into the ZIP code text box.
     *
     * @param zipCode The ZIP code to be typed
     */
    public static void typeZipCode(String zipCode) {
        SeleniumTest.clearAndSetText(zipCodeBox, zipCode);
    }

    public static String getZipCode() {
        return zipCodeBox.getAttribute("value");
    }

    /**
     * Selects the from month of first address at Address History
     *
     * @param month The From Month to be typed
     */

    public static void selectFirstMonth(String month) {
        SeleniumTest.selectShortMonthByVisibleText(fromFirstMonth, month);
    }

    /**
     * Selects the from month of second address at Address History
     *
     * @param monthTwo The From Month to be typed
     */

    public static void selectSecondMonth(String monthTwo) {
        SeleniumTest.selectShortMonthByVisibleText(fromSecondMonth, monthTwo);
    }

    /**
     * Selects the from month of third address at Address History
     *
     * @param monthThree The From Month to be typed
     */

    public static void selectThirdMonth(String monthThree) {
        SeleniumTest.selectShortMonthByVisibleText(fromThirdMonth, monthThree);
    }

    /**
     * Selects the from year of first address at Address History
     *
     * @param year The From year to be typed
     */

    public static void selectFirstYear(String year) {
        Select fromFirstYearSelector = new Select(fromFirstYear);
        fromFirstYearSelector.selectByVisibleText(year);
    }

    /**
     * Selects the from year of second address at Address History
     *
     * @param yearTwo The From Month to be typed
     */

    public static void selectSecondYear(String yearTwo) {
        Select fromSecondYearSelector = new Select(fromSecondYear);
        fromSecondYearSelector.selectByVisibleText(yearTwo);
    }

    /**
     * Selects the from year of third address at Address History
     *
     * @param yearThree The From Month to be typed
     */

    public static void selectThirdYear(String yearThree) {
        Select fromSecondYearSelector = new Select(fromThirdYear);
        fromSecondYearSelector.selectByVisibleText(yearThree);
    }

    /**
     * Selects the specified state from the location of employment drop down box.
     *
     * @param state The state to be selected
     **/

    public static void selectLocationOfEmployment(State state) {
        SeleniumTest.selectByVisibleTextFromDropDown(locationOfEmploymentDropDown, state.toString());
    }

    public static void selectLocationOfEmployment(String state) {
        SeleniumTest.selectByVisibleTextFromDropDown(locationOfEmploymentDropDown, state);
    }

    public static void typeLocationOfEmploymentCity(String city) {
        SeleniumTest.clearAndSetText(locationOfEmploymentCity, city);
    }

    public static void typeLocationOfEmploymentCityAdamantly(String city) {
        SeleniumTest.clearAndSetTextAdamantly(locationOfEmploymentCity, city);
        // Then click on the email box to make sure the mouse over city goes away ...
        SeleniumTest.click(By.name("qee"));
    }

    public static void typeLocationOfEmploymentCity(City city) {
        SeleniumTest.clearAndSetText(locationOfEmploymentCity, city.toString());
    }

    /**
     * Clicks on control with id=btnContinue
     */
    public static void clickContinueButton() {
        continueContinueButton.click();
    }

    /**
     * Click on the control with id=btnSubmit
     */
    public static void clickSubmitButton() {
        try {
            SeleniumTest.click(continueSubmitButton);
        } catch (WebDriverException e) {
            // Lately Selenium has been occasionally complaining that the parent HTML tag would receive the click,
            // "Other element would receive the click: <div class="stripe buttonstripe">...</div>".
            // Because Selenium is seemingly being stupid, we'll just JavaScript click it ...
            JavaScriptHelper.click(continueSubmitButton);
        }

        SeleniumTest.waitForPageLoad();
    }

    /**
     * Click on the control with id=btnSubmit until it disappears
     */
    public static void clickSubmitButtonUntilDisappears() {
        WaitUntil.waitUntil(() -> {
            clickSubmitButton();
            return !SeleniumTest.isElementVisibleNoWaiting(By.id("btnSubmit"));
        });
    }

    /**
     * Clicks the "Continue" button under the assumption that no errors or warnings will occur.
     *
     * @return A new Review Order page object
     */
    public static ReviewOrderPage clickContinueButtonForReviewOrderPage() {
        // Will wait longer since this times out too quickly in docker
        WaitUntil.waitUntil(60, 2, () -> {
            clickSubmitButton();
            return ReviewOrderPage.onPage();
        });
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Clicks the "Continue" button under the assumption that no errors or warnings will occur.
     *
     * @return A new Review Information page object, not to be confused with the CandidateReviewInformationPage
     */
    public static ReviewInformationPage clickContinueButtonForReviewInformationPage() {
        WaitUntil.waitUntil(() -> {
            clickSubmitButton();
            return ReviewInformationPage.onPage();
        });
        return PageFactory.initElements(Driver.getDriver(), ReviewInformationPage.class);
    }

    /**
     * Clicks the "Continue" button under the assumption that no errors or warnings will occur.
     *
     * @return A new Candidate Review Information page object
     */
    public static CandidateReviewInformationPage clickContinueButtonForCandidateReviewInformationPage() {
        WaitUntil.waitUntil(() -> {
            clickSubmitButton();
            return CandidateReviewInformationPage.onPage();
        });
        return PageFactory.initElements(Driver.getDriver(), CandidateReviewInformationPage.class);
    }

    /**
     * Clicks the "Continue" button under the assumption that no errors or warnings will occur.
     *
     * @return A new Existing Candidates page object
     */
    public static ExistingCandidatesPage clickContinueButtonForExistingCandidatesPage() {
        WaitUntil.waitUntil(() -> {
            clickSubmitButton();
            return ExistingCandidatesPage.onPage();
        });
        return PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
    }

    /**
     * Clicks the "Continue" button under the assumption that an error or warning will occur.
     *
     * @return A new Product Form Error page object
     */
    public static ProductFormErrorPage clickContinueButtonExpectingError() {
        clickSubmitButton();
        return PageFactory.initElements(Driver.getDriver(), ProductFormErrorPage.class);
    }

    /**
     * Clicks the "Continue" button under the assumption that no errors or warnings will occur.
     *
     * @return A new SSN Could Not Be Verified page object
     */
    public static SSNCouldNotBeVerifiedPage clickContinueButtonForSsnCouldNotBeVerifiedPage() {
        WaitUntil.waitUntil(() -> {
            clickSubmitButton();
            return SSNCouldNotBeVerifiedPage.onPage();
        });
        return PageFactory.initElements(Driver.getDriver(), SSNCouldNotBeVerifiedPage.class);
    }

    public static void clickContinueButtonForEitherSsnNotVerifiedOrExistingCandidatesPage() {
        WaitUntil.waitUntil(() -> {
            clickSubmitButton();
            return SSNCouldNotBeVerifiedPage.onPage() || ExistingCandidatesPage.onPage();
        });
    }

    /**
     * Types employer name
     */
    public static void typeEmployerName(String employerNumber, String employerName, String groupNumber) {
        WebElement employerNameTxtBox =
                Driver.getDriver().findElement(By.id("qcn_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(employerNameTxtBox, employerName);
    }
    //function to identify Employer Name field with Locator as 'NAME' .
    public void setEmployerName(String employerNumber, String employerName, String groupNumber) {
        WebElement employerNameTxtBox =
                Driver.getDriver().findElement(By.name("qcn_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(employerNameTxtBox, employerName);
    }
    //function to identify Employer Branch field with Locator as 'NAME' .
    public void setEmployerBranch(String employerNumber, String employerBranch, String groupNumber) {
        WebElement employerBranchTxtBox =
                Driver.getDriver().findElement(By.name("qcbranch_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(employerBranchTxtBox, employerBranch);
    }
    //function to identify Employer Address field with Locator as 'NAME' .
    public void setEmployerAddress(String employerNumber, String employerAddress, String groupNumber) {
        WebElement employerAddressTxtBox =
                Driver.getDriver().findElement(By.name("qca_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(employerAddressTxtBox, employerAddress);
    }
    //function to identify Employer City field with Locator as 'NAME' .
    public void setEmployerCity(String employerNumber, String employerCity, String groupNumber) {
        WebElement employerCityTxtBox =
                Driver.getDriver().findElement(By.name("qcc_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(employerCityTxtBox, employerCity);
    }





    /**
     * Types phone number
     */
    public static void typeEmployerPhoneNumber(String employerNumber, String phoneNumber, String groupNumber) {
        WebElement phoneTextBox =
                Driver.getDriver().findElement(By.name("qcp_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(phoneTextBox, phoneNumber);
    }

    /**
     * Types Employer City
     */
    public static void typeEmployerCity(String employerNumber, String employerCity, String groupNumber) {
        WebElement employerCityTextBox =
                Driver.getDriver().findElement(By.name("qcc_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(employerCityTextBox, employerCity);
    }

    /**
     * Selects Employer state
     */
    public static void selectEmployerState(String employerNumber, String state, String groupNumber) {
        Select employeeStateDropDown =
                new Select(Driver.getDriver().findElement(By.name("qcs_Group" + groupNumber + "-0_" + employerNumber)));
        employeeStateDropDown.selectByVisibleText(state);
    }

    /**
     * Types job title
     */
    public static void typeJobTitle(String employerNumber, String jobTitle, String groupNumber) {
        WebElement jobTitleTextBox =
                Driver.getDriver().findElement(By.name("qjt_Group" + groupNumber + "-0_" + employerNumber));
        SeleniumTest.clearAndSetText(jobTitleTextBox, jobTitle);
    }

    /**
     * Selects reason for leaving
     */
    public static void selectReasonForLeaving(String employerNumber, String reasonForLeaving, String groupNumber) {
        Select reasonFroLeavingDropDown =
                new Select(Driver.getDriver().findElement(By.id("qjrfl_Group" + groupNumber + "-0_" + employerNumber)));
        reasonFroLeavingDropDown.selectByVisibleText(reasonForLeaving);
    }

    /**
     * Selects start date month
     */
    public static void selectStartDateMonth(String employerNumber, String startDateMonth, String groupNumber) {
        Select startMonthDropDown = new Select(
                Driver.getDriver().findElement(By.id("qjstmm_Group" + groupNumber + "-0_" + employerNumber)));
        startMonthDropDown.selectByVisibleText(startDateMonth);
    }

    /**
     * Selects start date year
     */
    public static void selectStartDateYear(String employerNumber, String startDateYear, String groupNumber) {
        Select startYearDropDown = new Select(
                Driver.getDriver().findElement(By.id("qjstyy_Group" + groupNumber + "-0_" + employerNumber)));
        startYearDropDown.selectByVisibleText(startDateYear);
    }
    public  void selectStateDriverLicense(String state) {
        selectByVisibleTextFromDropDown(stateDriverLicenseDropDown,state);
    }
    public  void typeStateDriverLicense(String DrivingLicense) {
        SeleniumTest.clearAndSetText(stateDriverLicensebox,DrivingLicense);
    }

    /**
     * Return true if endDateMonth is Visible
     *
     * @return boolean: true, if Visible
     */
    public static boolean endDateDropdownIsVisible(String employerNumber, String groupNumber) {
        return Driver.getDriver().findElement(By.id("div_qjend_Group" + groupNumber + "-0_" + employerNumber))
                .isDisplayed();
    }

    public static boolean sameAsCurrentCheckboxIsVisible(String employerOrEducationNumber, String groupNumber) {
        return Driver.getDriver().findElement(By.id("sameascurrent_Group" + groupNumber + "-0_" + employerOrEducationNumber))
                .isDisplayed();
    }

    /**
     * Select end date month
     */
    public static void selectEndDateMonth(String employerNumber, String endDateMonth, String groupNumber) {
        Select endMonthDropDown = new Select(
                Driver.getDriver().findElement(By.id("qjendmm_Group" + groupNumber + "-0_" + employerNumber)));
        endMonthDropDown.selectByVisibleText(endDateMonth);
    }

    /**
     * Select end date year
     */
    public static void selectEndDateYear(String employerNumber, String endDateYear, String groupNumber) {
        Select endYearDropDown = new Select(
                Driver.getDriver().findElement(By.id("qjendyy_Group" + groupNumber + "-0_" + employerNumber)));
        endYearDropDown.selectByVisibleText(endDateYear);
    }

    /**
     * Check checkbox for Employment Verification
     *
     * @param employerNumber, groupNumber
     */
    public static void checkEmploymentVerificationCheckBox(String employerNumber, String groupNumber) {
        SeleniumTest.click(By.id("qshow_Group" + groupNumber + "-0_" + employerNumber));
    }

    /**
     * Check checkbox for Education Verification
     */
    public static void checkEducationVerificationCheckBox(String educationNumber, String groupNumber) {
        Driver.getDriver().findElement(By.id("qshow_Group" + groupNumber + "-0_" + educationNumber)).click();
    }

    /**
     * Check checkbox for Same as current
     */
    public static void checkSameAsCurrentCheckbox(String employerOrEducationNumber, String groupNumber) {
        WebElement sameAsCurrentCheckBox = Driver.getDriver()
                .findElement(By.id("sameascurrent_Group" + groupNumber + "_" + employerOrEducationNumber));
        SeleniumTest.click(sameAsCurrentCheckBox);
    }

    /**
     * Clicks on Continue button
     */
    public static ProductFormPages clickContinueButton(Class<? extends ProductFormPages> returnedClass) {
        SeleniumTest.click(continueSubmitButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static ProductFormPages clickContinueinEdictButton(Class<? extends ProductFormPages> returnedClass) {
        SeleniumTest.click(continueContinueButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Fills candidate Profile Section
     */
    public static void fillCandidateProfileSection(String firstName, String middleName, String lastName, String ssn,
                                                   String phone) {
        typeFirstName(firstName);
        typeMiddleName(middleName);
        typeLastName(lastName);
        typeSSN(ssn);
        typePhoneNumber(phone);
    }
    /**
     * Fills candidate Profile Section
     */
    public static void fillCandidateProfileSectionforReference(String firstName, String middleName, String lastName,
                                                               String phone) {
        typeFirstName(firstName);
        typeMiddleName(middleName);
        typeLastName(lastName);
        typePhoneNumber(phone);
    }

    /**
     * Fills candidate 1st Address Section
     */
    public static void fillFirstAddressSection(String addressBox, String cityBox, String stateDropDownBox,
                                               String zipCodeBox) {
        typeAddress(addressBox);
        typeCity(cityBox);
        selectCandidateState(stateDropDownBox);
        typeZipCode(zipCodeBox);
    }

    public static Candidate fillCandidateDetailSection(Candidate candidate) {
        fillCandidateProfileSection_NoAddress(candidate);
        candidate.setCity("Mobile");
        candidate.setState(UsStateTerritory.ALABAMA.getFullName());
        candidate.setSocialSecurityNumber(Candidate.ssnFaker());
        candidate.setZip("36601");
        typeCity(candidate.getCity());
        selectCandidateState(candidate.getState());
        typeSSN(candidate.getSocialSecurityNumber());
        typeZipCode(candidate.getZip());
        typeAddress(candidate.getAddressLine1());
        selectLocationOfEmployment(candidate.getState());
        typeLocationOfEmploymentCity(candidate.getCity());

        return candidate;
    }

    /**
     * Clicks on Add Employment Verification link.
     */
    public static void clickAddEmploymentVerificationLink() {
        Driver.getDriver().findElement(By.linkText(ADD_EMPLOYMENT_VERIFICATION_EXPECTED_LINK)).click();
    }

    /**
     * Return the GroupId used in each SKU
     */
    public static String discoverGroupId() {
        return Driver.getDriver().findElement(By.xpath("//div[@id[starts-with(., 'divForm_Group')]]"))
                .getAttribute("id").split("_")[1].substring(5);
    }

    /**
     * Set Checkbox for Education Verification
     */
    public static void checkEducationVerification() {
        SeleniumTest.check(checkboxEnableDisable);
    }

    /**
     * Unset Checkbox for Education Verification
     */
    public static void uncheckboxEducationVerification() {
        SeleniumTest.unCheck(checkboxEnableDisable);
    }

    /**
     * Set Checkbox for INTERNATIONAL CRIMINAL SEARCH
     */
    public static void checkInternationalCrimSearch() {
        SeleniumTest.check(checkboxEnableDisable);
        try {
            SeleniumTest.check(checkboxEnableDisable);
        } catch (WebDriverException e) {
            WaitUntil.waitUntil(() -> {
                if (!SeleniumTest.isCheckboxChecked(checkboxEnableDisable)) {
                    JavaScriptHelper.click(checkboxEnableDisable);
                }
                return SeleniumTest.isCheckboxChecked(checkboxEnableDisable);
            });
        }
    }

    /**
     * Unset Checkbox for INTERNATIONAL CRIMINAL SEARCH
     */
    public static void unCheckInternationalCrimSearch() {
        try {
            SeleniumTest.unCheck(checkboxEnableDisable);
        } catch (WebDriverException e) {
            WaitUntil.waitUntil(() -> {
                if (SeleniumTest.isCheckboxChecked(checkboxEnableDisable)) {
                    JavaScriptHelper.click(checkboxEnableDisable);
                }
                return !SeleniumTest.isCheckboxChecked(checkboxEnableDisable);
            });
        }
    }

    /**
     * Type School Field of Study or Major
     */
    public static void typeSchoolFieldStudyOrMajor(String fieldOfStudyOrMajor) {
        SeleniumTest.clearAndSetText(fieldOfStudyMajor, fieldOfStudyOrMajor);
    }

    /**
     * Select dropdown option for Cert or Degree
     */
    public static void selectCertificationOrDegree(String certificationOrDegreeOption) {
        certificationDegree.sendKeys(certificationOrDegreeOption);
    }

    /**
     * Type School Name
     */
    public static void typeSchoolName(String schoolNameText) {
        schoolName.sendKeys(schoolNameText);
    }

    /**
     * Type School City
     */
    public static void typeSchoolCity(String schoolCityText) {
        schoolCity.sendKeys(schoolCityText);
    }

    /**
     * Type School Name
     */
    public void enterProductsinputstring(String InputString) {
        SeleniumTest.clearAndSetText(SearchtextboxAddproducts,InputString);
    }

    /**
     * Select dropdown option for School State
     */
    public static void selectSchoolState(String schoolStateOption) {
        new Select(schoolStateTerritory).selectByVisibleText(schoolStateOption);
    }

    /**
     * Select dropdown option for Did Candidate Graduate?
     */
    public static void selectDidCandidateGraduate(String didCandidateGraduateOption) {
        new Select(selectorDidYouGraduate).selectByVisibleText(didCandidateGraduateOption);
    }

    /**
     * Select Date of Graduation (Month)
     */
    public static void selectDateEndedSchoolMonth(String dateEndedSchoolMonthOption, String educationNumber,
                                                  String groupID) {
        Select dropDown = new Select(
                Driver.getDriver().findElement(By.name("qgraddtmm_Group" + groupID + "_" + educationNumber)));
        dropDown.selectByVisibleText(dateEndedSchoolMonthOption);
    }

    /**
     * Select Date of Graduation (Year)
     */
    public static void selectDateEndedSchoolYear(String dateEndedSchoolYearOption, String educationNumber,
                                                 String groupID) {
        Select dropDown = new Select(
                Driver.getDriver().findElement(By.name("qgraddtyy_Group" + groupID + "_" + educationNumber)));
        dropDown.selectByVisibleText(dateEndedSchoolYearOption);
    }

    /**
     * Set Checkbox Name While Attending School
     */
    public static void setCheckboxNameWhileAttendingSchool() {
        if (!checkboxSameAsCurrent.isSelected()) {
            checkboxSameAsCurrent.click();
        }
    }

    /**
     * Unset Checkbox Name While Attending School
     */
    public static void unsetCheckboxNameWhileAttendingSchool() {
        if (checkboxSameAsCurrent.isSelected()) {
            checkboxSameAsCurrent.click();
        }
    }

    /**
     * Type First Name While attending School
     */
    public static void typeFirstNameWhileAttendingSchool(String firstNameText) {
        firstName.sendKeys(firstNameText);
    }

    /**
     * Type Last Name While attending School
     */
    public static void typeLastNameWhileAttendingSchool(String lastNameText) {
        lastName.sendKeys(lastNameText);
    }

    /**
     * Fills the address section in candidate profile.
     */
    public static void fillAddressSection(String addressLine1, String city, String state, String zip) {
        typeAddress(addressLine1);
        typeCity(city);
        selectCandidateState(state);
        typeZipCode(zip);
    }

    public static void fillCrimSection(String statecrim, String countyCrim) {
        WebElement crimState = Driver.getDriver().findElement(By.xpath("//select[@id='specifyqs_Group172-0_1']"));
        Select stateDropDown = new Select(crimState);
        stateDropDown.selectByVisibleText(statecrim);
    }

    /**
     * Fills the Additional address section in candidate profile.
     */
    public static void fillAdditionalAddressSection(String city, String state) {
        //typeAddress(addressLine1);
        typeCity(city);
        selectCandidateState(state);

    }
    /**
     * Selects state from state drop down.
     */
    public static void selectCandidateState(String state) {
        try {
            SeleniumTest.selectByVisibleTextFromDropDown(stateDropDownBox, state);
        } catch (UnexpectedTagNameException e) {
            SeleniumTest.clearAndSetText(stateDropDownBox, state);
        }
    }

    /**
     * Selects request country.
     */
    public static void selectRequestCountry(String country) {
        try {
            SeleniumTest.selectByVisibleTextFromDropDown(currentCountryOfResidenceDropDown, country);
        } catch (UnexpectedTagNameException e) {
            SeleniumTest.clearAndSetText(currentCountryOfResidenceDropDown, country);
        }
    }

    public static String getCandidateState() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(stateDropDownBox);
    }

    public static void selectCandidateState(State state) {
        selectCandidateState(state.toString());
    }

    /**
     * Fills candidate date of birth on the form.
     */
    public static void fillCandidateDateOfBirth(String month, String day, String year) {
        selectDOBMonth(month);
        selectDOBDay(day);
        selectDOBYear(year);
    }

    /**
     * Selects DOB Month
     */
    public static void selectDOBMonth(String month) {
        Select monthDropDown = new Select(Driver.getDriver().findElement(By.id("qmm")));
        monthDropDown.selectByVisibleText(month);
    }

    /**
     * Selects DOB Day
     */
    public static void selectDOBDay(String day) {
        Select dayDropDown = new Select(Driver.getDriver().findElement(By.id("qdd")));
        dayDropDown.selectByVisibleText(day);
    }

    /**
     * Selects DOB Year
     */
    public static void selectDOBYear(String year) {
        Select yearDropDown = new Select(Driver.getDriver().findElement(By.id("qyy")));
        yearDropDown.selectByVisibleText(year);
    }

    public static void clickAddIcon() {
        Driver.getDriver().findElement(By.xpath("//img[contains(@src, 'addicon.png')]")).click();
    }

    /**
     * Sets profile info from a candidate object
     *
     * @param candidate fill profile info, skip address
     */
    public static void fillCandidateProfileSection_NoAddress(Candidate candidate) {
        typeFirstName(candidate.getFirstName());
        typeMiddleName(candidate.getMiddleName());
        typeLastName(candidate.getLastName());
        if (isSsnTextBoxVisible()) {
            typeSSN(candidate.getSocialSecurityNumber());
        }
        typePhoneNumber(candidate.getCandidatePhone());
        selectDOBDay(candidate.getDobDay());
        selectDOBMonth(candidate.getDobMonth());
        selectDOBYear(candidate.getDobYear());

        if (isEmailTextBoxVisible()) {
            typeEmail(candidate.getEmailAddress());
        }
    }
    public static void fillCandidateProfileSection_NoAddress_NoFirstName_NoLastName_NoMiddleName(Candidate candidate) {
        if (isSsnTextBoxVisible()) {
            typeSSN(candidate.getSocialSecurityNumber());
        }
        typePhoneNumber(candidate.getCandidatePhone());
        selectDOBDay(candidate.getDobDay());
        selectDOBMonth(candidate.getDobMonth());
        selectDOBYear(candidate.getDobYear());

        if (isEmailTextBoxVisible()) {
            typeEmail(candidate.getEmailAddress());
        }
    }

    /**
     * Sets profile info from a candidate object
     */
    public static void fillCandidateProfileSection(Candidate candidate) {
        fillCandidateProfileSection_NoAddress(candidate);
        // Now just fill the address ...
        // Unfortunately there are 2 current country regions that can show on this page,
        // one in the section, "Candidate's Current Country of Residence," with id=qrescountry,
        // and one in the section, "Residence History, CURRENT RESIDENCE," with id="qo"
        final By countryRegionLocator = By.id("qo");
        if (SeleniumTest.isElementVisibleNoWaiting(countryRegionLocator)) {
            SeleniumTest.selectByVisibleTextFromDropDown(countryRegionLocator, candidate.getCountryOrRegion());
        }

        WaitUntil.waitUntil(() -> {
            // This might not be ready if another country has been selected just above ...
            typeAddress(candidate.getAddressLine1());
            return true;
        }, InvalidElementStateException.class);

        typeCity(candidate.getCity());
        selectCandidateState(candidate.getState());
        typeZipCode(candidate.getZip());

        if (SeleniumTest.isElementVisibleNoWaiting(By.id("qempcity"))) {
            TicketForm.fillLocationOfEmploymentSection(candidate.getState(), candidate.getCity());
        }
    }

    /**
     * Select date of birth
     *
     * @param dob Date of birth
     */
    public static void selectDateOfBirth(LocalDate dob) {
        String month = dob.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);

        String day  = (Integer.toString(dob.getDayOfMonth()));
        String year = (Integer.toString(dob.getYear()));

        SeleniumTest.selectShortMonthByVisibleText(monthDropDownBox, dob);

        Select dayDropDown = new Select(dayDropDownBox);
        dayDropDown.selectByVisibleText(day);

        Select yearDropDown = new Select(yearDropDownBox);
        yearDropDown.selectByVisibleText(year);
    }

    /**
     * Fills the section for first previous residence history of the candidate
     *
     * @param city  City where candidate lived before living in current city
     * @param state State where candidate lived before living in current State
     * @param zip   Zip code of the city state combination
     */
    public static ScreeningLaunchPage typePreviousResidence(String city, String state, String zip) {
        previousResidenceCityTextBox.sendKeys(city);

        Select stateDropDown = new Select(previousResidenceStateDropDown);
        stateDropDown.selectByVisibleText(state);

        previousResidenceZipTextBox.sendKeys(zip);
        return PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
    }

    /**
     * Fills the section for second previous residence history of the candidate
     *
     * @param city  City where candidate lived before living in current city
     * @param state State where candidate lived before living in current State
     * @param zip   Zip code of the city state combination
     */
    public static ScreeningLaunchPage typePreviousResidence2(String city, String state, String zip) {
        previousResidenceCityTextBox1.sendKeys(city);

        Select stateDropDown = new Select(previousResidenceStateDropDown1);
        stateDropDown.selectByVisibleText(state);

        previousResidenceZipTextBox1.sendKeys(zip);
        return PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
    }


    /**
     * Select Billing code from order tracking
     */
    public static void selectBillingCode(String billingCode) {
        new Select(selectBillingcode).selectByValue(billingCode);
    }

    /**
     * Select additional criminal statewide search
     */
    public static void setSelectAdditionalStateWideSearch(String state) {
        new Select(selectAdditionalStateWideSearch).selectByVisibleText(state);
    }

    /**
     * @return all available statewide searches in the "Search to Perform*" drop-down
     */
    public static String getAllAdditionalStateWideSearchOptions() {
        return selectAdditionalStateWideSearch.getText();
    }

    public static String getAllStatewideCriminalAuditStatesFromDropDown() {
        return SeleniumTest.getText(Driver.getDriver().findElement(
                By.id("specifyqs_Group" + ScreeningLaunchPage.discoverGroupId() + "_1")));
    }

    /**
     * Click the Specify Jurisdiction Button
     */
    public static void clickSpecifyJurisdiction() {
        SeleniumTest.check(specifyJurisdiction);
    }

    public static void clickSpecifyJurisdictionRadioBtn() {
        SeleniumTest.click(specifyJurisdictionRadioButton);
    }

    /**
     * Select the jurisdiction state
     */
    public static void selectJurisdictionState(String state) {
        SeleniumTest.selectByVisibleTextFromDropDown(
                By.id("specifyqs_Group" + ScreeningLaunchPage.discoverGroupId() + "_1"), state);
    }

    /**
     * Select the jurisdiction state
     */
    public static void selectJurisdictionState(String state, String group) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("specifyqs_Group" + group + "_1"), state);
    }

    /**
     * Select the jurisdiction county
     */
    public static void selectJurisdictionCounty(String county, String group) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qfips_Group" + group + "_1"), county);
    }

    /**
     * Select the jurisdiction county
     */
    public static void selectJurisdictionCounty(String county) {
        SeleniumTest.selectByVisibleTextFromDropDown(jurisdictionCounty, county);
    }

    /**
     * Select the State jurisdiction selection list
     */
    public static void chooseSpecifyJurisdictionRadioButton() {
        SeleniumTest.click(specifyJurisdictionRadioButton);
    }

    /**
     * Select the State jurisdiction selection list
     */
    public static void chooseSpecifyJurisdictionRadioButton(String group) {
        Driver.getDriver().findElement(By.id("specifyloc_Group" + group + "_1_1")).click();
    }

    /**
     * return the State jurisdiction selection list
     */
    public static List<WebElement> getOptionsFromSelectSpecifyJurisdictionStateDropdown() {
        Select selector = new Select(selectSpecifyJurisdictionStateDropdown);
        return selector.getOptions();
    }

    /**
     * Select the State jurisdiction option from selectSpecifyJurisdictionStateDropdown
     */
    public static void selectSpecifyJurisdictionOption(String state) {
        new Select(selectSpecifyJurisdictionStateDropdown).selectByVisibleText(state);
    }

    /**
     * @return all Select State* options available from the selectSpecifyJurisdictionStateDropdown
     */
    public static String getAllSpecifyJurisdictionStateOptions() {
        return SeleniumTest.getTextByLocator(By.id("specifyqs_Group" + ScreeningLaunchPage.discoverGroupId() + "_1"));
    }

    /**
     * @return get selected state from dropdown
     */
    public static String getSelectedStateFromCountySearch() {
        return Driver.getDriver()
                .findElement(By.xpath("//select[@id='specifyqs_Group172-0_1']/option[@selected = 'selected']"))
                .getAttribute("value");
    }

    /**
     * @return get selected county from dropdown
     */
    public static String getSelectedCountyFromCountySearch() {
        return Driver.getDriver()
                .findElement(By.xpath("//select[@id='qfips_Group172-0_1']/option[@selected = 'selected']")).getText();
    }

    /**
     * @return get selected state from dropdown
     */
    public static String getSelectedStateFromStateSearch() {
        return Driver.getDriver()
                .findElement(By.xpath("//select[@id='specifyqs_Group73-0_1']/option[@selected = 'selected']"))
                .getAttribute("value");
    }

    /**
     * Unchecks first checkbox corresponding to the mentioned title
     */
    public static void uncheckFirstCheckbox(String title) {
        String group = Driver.getDriver().findElement(By.xpath(
                "//div[@class='contentContainer']/div[@class='subformtitle' and contains(.,'" + title
                        + "')]/preceding-sibling::a")).getAttribute("name");
        // At this point group looks something like "Group172_1"
        SeleniumTest.unCheck(Driver.getDriver().findElement(By.id("qshow_" + group)));
    }

    public static String getScreeningLaunchPageErrorInformation() {
        return screeningLaunchPageErrorInformation.getText();
    }

    public static String getScreeningLaunchPageAllErrorInformation() {
        return SeleniumTest.getText(screeningLaunchPageCompleteErrorInformation);
    }


    public static WebElement getCountrySelect() {
        return internationalCrimCountrySelect;
    }
    public  void selectIntCrimCountry(String country) {
        Select selector = new Select(internationalCrimCountrySelect);
        selector.selectByVisibleText(country);
    }


    public static void checkSpecifyJurisdictionRadial() {
        SeleniumTest.check(specifyJurisdictionRadialButton);
    }

    public static void setValueForSexOffenderSelectStateSelect(String state) {
        SeleniumTest.selectByValueFromDropDown(sexOffenderSelectStateSelect, state);
    }

    public static void selectRefCode(String refCode) {
        Select selector = new Select(refCodeDropDown);
        selector.selectByVisibleText(refCode);
    }

    public static void fillCandidateProfileSectionWithoutSsn(String fName, String mName, String lName, String phone,
                                                             LocalDate dob, String email) {
        typeFirstName(fName);
        typeMiddleName(mName);
        typeLastName(lName);
        typePhoneNumber(phone);
        selectDateOfBirth(dob);
        typeEmail(email);
    }

    /**
     * Fill profile section for ticketing  name and email
     */
    public static void fillCandidateProfileSectionTicketing(Candidate candidate) {
        typeFirstName(candidate.getFirstName());
        typeMiddleName(candidate.getMiddleName());
        typeLastName(candidate.getLastName());
        typeEmail(candidate.getEmailAddress());
        selectLocationOfEmployment("Alabama");
        typeLocationOfEmploymentCity("Mobile");
    }

    /**
     * Hides username and email from pages that display it. Deals with the randomizatoin of username and email
     */
    public static void hideUserNameAndEmail() {
        List<WebElement> usernames = Driver.getDriver().findElements(By.xpath("//*[contains(text(), 'Moogle')]"));
        for (WebElement name : usernames) {
            BodyTextHelper.hideElement(name);
        }
        WebElement emailAddress = Driver.getDriver().findElement(By.xpath("//*[contains(text(), 'example.com')]"));
        BodyTextHelper.hideElement(emailAddress);
    }

    /**
     * Inserts test data relevant to the uberform 8391465 - on account gl-newlaunch@sterlingts.com
     */
    public static void fillAdditionalDocumentPackageFields() {
        //Fill initial test data
        ScreeningLaunchPage.fillWithTestDataJs();
        //Add a second worker's comp and wait for the page to reload
        WebElement addComp = Driver.getDriver().findElement(By.id("spanAdd_Group64-0"));
        addComp.click();
        SeleniumTest.waitForPageLoadToComplete();

        //Fill in data to trigger additional notes
        Select stateDropdown      = new Select(Driver.getDriver().findElement(By.id("qs_Group36-0_1")));
        Select puertoRicoDropdown = new Select(Driver.getDriver().findElement(By.id("qs_Group13-0_1")));
        Select canadaDropdown     = new Select(Driver.getDriver().findElement(By.id("qo_Group24-0_1")));
        Select provinceDropdown   = new Select(Driver.getDriver().findElement(By.id("qs_Group24-0_1_CA")));

        stateDropdown.selectByValue("WA");
        puertoRicoDropdown.selectByValue("PR");
        canadaDropdown.selectByValue("CA");
        provinceDropdown.selectByValue("QC");

        WebElement stateLicense      = Driver.getDriver().findElement(By.id("qdl_Group36-0_1"));
        WebElement puertoRicoLicense = Driver.getDriver().findElement(By.id("qdl_Group13-0_1"));
        WebElement provinceLicense   = Driver.getDriver().findElement(By.id("qdl_Group24-0_1"));

        SeleniumTest.clearAndSetText(stateLicense, "MOOGLSP50-1BA");
        SeleniumTest.clearAndSetText(puertoRicoLicense, "1234567");
        SeleniumTest.clearAndSetText(provinceLicense, "A1010-101010-10");

        Select     workCompDropdown1 = new Select(Driver.getDriver().findElement(By.id("qs_Group64-0_1")));
        Select     workCompDropdown2 = new Select(Driver.getDriver().findElement(By.id("qs_Group64-0_2")));
        WebElement iowaDate          = Driver.getDriver().findElement(By.id("qaddinf_Group64-0_1"));

        workCompDropdown1.selectByValue("IA");
        workCompDropdown2.selectByValue("LA");
        SeleniumTest.clearAndSetText(iowaDate, "5/5/15");
    }

    /**
     * Get just the content for the launch screen.  No header, side bar or footer.
     */
    public static WebElement getLaunchContent() {
        return launchContent;
    }

    /**
     * Returns a web element dropdown for Workers compensation section.
     *
     * @return Web element dropdown
     */
    public static WebElement getWorkersCompStateDropdownElement(int index) {
        String groupId = ScreeningLaunchPage.discoverGroupId();
        return Driver.getDriver().findElement(By.id("qs_Group" + groupId + "_" + index));
    }

    /**
     * Types NPI number in launch form for NPI sku.
     */
    public static void typeNpiNumber(String npiNumber) {
        SeleniumTest.clearAndSetText(npiTextBox, npiNumber);
    }

    public static String getSelfDisclosureText() {
        SeleniumTest.waitForPageLoadToComplete();
        return SeleniumTest.getText(selfDislosureText);
    }

    public static String getElectronicDisclosureAndAuthorizationText() {
        SeleniumTest.waitForPageLoadToComplete();
        return SeleniumTest.getText(electronicDislosureAndAuthorizationText);
    }

    public static String getBillingDropDownOptions() {
        return SeleniumTest.getText(selectBillingcode).trim();
    }

    /**
     * This method returns true if the specify jurisdiction dropdown menu contains the passing state
     */
    public static boolean isStateListed(UsStateTerritory state) {
        List<String> strOptions = SeleniumTest.getSelectOptionStrings(selectSpecifyJurisdictionStateDropdown);
        return strOptions.contains(state.getFullName());
    }

    public static String getSingleSelectedVisibleTextFromReasonForTestDropDown() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(reasonForTestDropDown);
    }

    public static void chooseReasonForTestOption(String option) {
        SeleniumTest.selectByVisibleTextFromDropDown(reasonForTestDropDown, option);
    }

    public static boolean isReasonForTestDropDownVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(reasonForTestDropDownLocator);
    }

    /**
     * Validates whether error message for Reason for test is present
     */
    public static boolean isReasonForTestErrorMessageVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(reasonForTestErrorMessageLocator);
    }


    public static void selectSchoolCountry(String schoolCountryOption) {
        new Select(schoolCountry).selectByVisibleText(schoolCountryOption);
    }

    public static void selectDateEndedSchoolMonth1(String dateEndedSchoolMonthOption, String educationNumber,
                                                   String groupID) {
        Select dropDown = new Select(
                Driver.getDriver().findElement(By.name("qgraddtmm_Group" + groupID + "-0_" + educationNumber)));
        dropDown.selectByVisibleText(dateEndedSchoolMonthOption);
    }

    /**
     * Select Date of Graduation (Year)
     */
    public static void selectDateEndedSchoolYear1(String dateEndedSchoolYearOption, String educationNumber,
                                                  String groupID) {
        Select dropDown = new Select(
                Driver.getDriver().findElement(By.name("qgraddtyy_Group" + groupID + "-0_" + educationNumber)));
        dropDown.selectByVisibleText(dateEndedSchoolYearOption);
    }

    public Candidate fillCandidateDetailsForBOSUser() {
        Candidate candidate = new Candidate();
        fillCandidateProfileSection_NoAddress(candidate);
        candidate.setCity("Mobile");
        candidate.setState(UsStateTerritory.ALABAMA.getFullName());
        candidate.setSocialSecurityNumber(Candidate.ssnFaker());
        candidate.setZip("36601");
        typeCity(candidate.getCity());
        selectCandidateState(candidate.getState());
        typeSSN(candidate.getSocialSecurityNumber());
        typeZipCode(candidate.getZip());
        typeAddress(candidate.getAddressLine1());
        checkEmploymentVerificationCheckBox("1", "40");
        selectCertificationOrDegree("GED");
        typeSchoolFieldStudyOrMajor("Degree");
        typeSchoolName("SchoolName");
        selectSchoolState(candidate.getState());
        typeSchoolCity(candidate.getCity());
        selectSchoolCountry("United States");
        selectDidCandidateGraduate("Yes");
        selectDateEndedSchoolMonth1("Jan", "1", "40");
        selectDateEndedSchoolYear1("2000", "1", "40");
        setCheckboxNameWhileAttendingSchool();
        return candidate;
    }

    public void fillCandidateProfileSectionTicketingForBOSUser(Candidate candidate) {
        typeFirstName(candidate.getFirstName());
        typeMiddleName(candidate.getMiddleName());
        typeLastName(candidate.getLastName());
        typeEmail(candidate.getEmailAddress());
    }

    public static void fillCriminalSelfDisclosure() {
        SeleniumTest.check(criminalSelfDisclosure_Yes);
        SeleniumTest.clearAndSetText(addDisclosureInfo, "Self Disclosure");
    }

    public static void fillCriminalCheckByJurisdiction(Candidate candidate, String countyName) {
        SeleniumTest.check(cbCriminalCheckByJurisdiction);
        SeleniumTest.selectByVisibleTextFromDropDown(state, candidate.getState());
        SeleniumTest.selectByVisibleTextFromDropDown(county, countyName);
    }

    public static void setGenderDropDownListField(String genderValue) {
        SeleniumTest.selectByVisibleTextFromDropDown(gender, genderValue);
    }

    /*
   Getter for the include SSN based verification check box
   */
    public boolean isIncludeConsentbasedSsnVerificationForTheSelected() {
        return includeConsentBasedSsnVerificationForTheCandidate.isSelected();
    }

    public void clickContinueButtonOnScreeningPage() {
        JavaScriptHelper.click(continueSubmitButton);

    }

    public static boolean isErrorVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(screeningLaunchPageCompleteError);
    }

    public static String getAlertText(){
        return SeleniumTest.getText(alertMessage);
    }

    public boolean isLicenseCountryDropDownVisible(){
        return SeleniumTest.isElementVisibleNoWaiting(licenseCountryDropdownLocator);
    }
    public void fillDrivingDetails(String country,String state,String licenseNo) {

        SeleniumTest.selectByVisibleTextFromDropDown(licenseCountryDropdownLocator,country);
        if(SeleniumTest.isElementVisibleNoWaiting(licenseStateUSDropdownLocator)) {
            SeleniumTest.selectByVisibleTextFromDropDown(licenseStateUSDropdownLocator,state);

        }
        else {
            SeleniumTest.selectByVisibleTextFromDropDown(licenseStateCADropdownLocator,state);
        }

        SeleniumTest.clearAndSetText(driverLicensebox,licenseNo);

    }

    public static void checkDoNotContactEmployerBox(String employerNumber,String groupNumber) {
        SeleniumTest.click(By.id("qnocontact_Group" + groupNumber + "-0_" + employerNumber));
    }

    public static OrderConfirmationPage clickPurchase() {
       SeleniumTest.click(By.id("btnPurchase"));
       return PageFactory.initElements(Driver.getDriver(), OrderConfirmationPage.class);
    }

    public void selectEmploymentCheckBox() {
        try {
            Thread.sleep(5000);
        } catch(InterruptedException e) {
            System.out.println("got interrupted!");
        }
        SeleniumTest.click(Empcheckbox);
    }

    public void selectEducationCheckBox() {
        try {
            Thread.sleep(5000);
        } catch(InterruptedException e) {
            System.out.println("got interrupted!");
        }
        SeleniumTest.click(Educheckbox);
    }

    public void selectCredentialsCheckBox() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
        SeleniumTest.click(Credcheckbox);
    }

    public void selectReferenceCheckBox() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
        SeleniumTest.click(Refcheckbox);
    }

    public void selectCrimCheckBox() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
        SeleniumTest.click(Crimcheckbox);
    }


    public String getAlternateFirstName() { return SeleniumTest.getText(alternateFirstNameBox); }

    public String getAlternateLastName() { return SeleniumTest.getText(alternateLastNameBox); }

    public String getPhoneNumber() { return SeleniumTest.getText(phoneNumberBox); }

    public void fillCriminalHistorySelfDisclosure(String disclosure) {
        SeleniumTest.check(criminalHistorySelfDisclosure_Yes);
        SeleniumTest.clearAndSetText(addCrimHistoryDisclosureInfo, disclosure);
    }

    public static void clickSearchInAddProducts() {
        SeleniumTest.click(By.id("generalSearchButton"));
    }

    public static void ClickAddProductsButton() {
        SeleniumTest.click(By.id("AddProductButton"));
    }

    public static void clickAddInAddProducts() {
        try {
            Thread.sleep(3000);
            SeleniumTest.click(By.id("addProduct"));
        } catch (Exception e) {
        }
    }

    public void fillFACISDetails(String state,String licenseNo) {
        SeleniumTest.selectByVisibleTextFromDropDown(FACIS_State,state);
        SeleniumTest.clearAndSetText(FACIS_LicenseID,licenseNo);
    }

    public String getSelectedCountryInDropdown(){
        JavaScriptHelper.scrollElementIntoView(currentCountryOfResidenceDropDown);
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(currentCountryOfResidenceDropDown);
    }

    public boolean isCountryDisabled() {
        return SeleniumTest.isElementDisabled(currentCountryOfResidenceDropDown);
    }

    public boolean isCPFNumberFieldVisible() {
        return SeleniumTest.isElementVisible(govtIdValueText);
    }

    public List<String> getCountriesList(){
        JavaScriptHelper.scrollElementIntoView(internationalCrimCountrySelect);
        return SeleniumTest.getSelectOptionStrings(internationalCrimCountrySelect);
    }
    public boolean verifyOptionInCountriesDropDown(String country){
        List<String> countries =  getCountriesList();
        if(countries.contains(country)){
            return true;
        }
        else {
            return false;
        }
    }

    public void clickAddNamesLink() {
        SeleniumTest.click ( addNamesLink );
    }

    public String fillMultipleAlternateNames(int num){
        ScreeningLaunchPage.typeAlternateFirstName(Utf8StringCreator.getAlphaRand().toLowerCase());
        ScreeningLaunchPage.typeAlternateLastName(Utf8StringCreator.getAlphaRand().toLowerCase());
        for(int i=1;i<num;i++){
            clickAddNamesLink();
            EditProfileModal.typeAlternateFirstName(i, Utf8StringCreator.getAlphaRand().toLowerCase());
            EditProfileModal.typeAlternateLastName(i, Utf8StringCreator.getAlphaRand().toLowerCase());

        }
        ScreeningLaunchPage.clickSubmitButton();
        ScreeningLaunchPage.clickContinueButton();
        ScreeningLaunchPage.clickSubmitButton();
        ReviewOrderPage.clickPurchaseButton();
        String reportId = OrderConfirmationPage.getReportID();
        return reportId;
    }

    public static void clickNextInAddProducts() {
        SeleniumTest.click(By.id("nextBtn"));
    }

    public void clickAddEducationVerificationLink() {
        Driver.getDriver().findElement(By.linkText(ADD_EDUCATION_VERIFICATION_EXPECTED_LINK)).click();
    }
    public  void selectEmployerCounty(String employerNumber, String county, String groupNumber) {
        Select employerCountyDropDown =
                new Select(Driver.getDriver().findElement(By.name("qo_Group" + groupNumber + "-0_" + employerNumber)));
        employerCountyDropDown.selectByVisibleText(county);
    }

    public String launchWithTestDataAndGenerateReport(String customerEmail, String customerPass, String uberForm){
        logger.info("Login to Dashboard");
        CustomerLoginPage.navigateToAndLoginToCustomerDashboard(customerEmail, customerPass);
        logger.info("Launch UberForm "+ uberForm);
        CustomerDashboardPages.clickforScreening(uberForm, "Launch");
        TicketForm.fillWithTestDataJs();
        ScreeningLaunchPage.clickSubmitButton();
        ScreeningLaunchPage.clickContinueButton();
        ReviewOrderPage.clickPurchaseButton();
        String reportId = OrderConfirmationPage.getReportID();
        logger.info ( "Report Id is "+reportId);
        OrderConfirmationPage.clickViewReportInProgressButton();
        return reportId;
    }

    public boolean selectSchoolFoundInSuggestionBox(String schoolAbbreviation, String schoolName){
        logger.info("Enter the School abbreviation");

        logger.info("Enter the School abbreviation");
        SeleniumTest.clearAndSetText(schoolBox,schoolAbbreviation);
        SeleniumTest.waitForElementVisible(schoolSuggestionBox);
        if(schoolName.equals(SeleniumTest.getText(schoolSuggestionBox))){
            logger.info("School name is matched");
            return  true;
        }
        else{
            logger.info("School name didn't matched");
            return  false;
        }
    }

}
