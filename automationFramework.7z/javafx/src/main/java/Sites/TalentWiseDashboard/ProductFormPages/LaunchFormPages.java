package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Onboard.EverifyNameCheckModal;
import Sites.TalentWiseDashboard.Search.Records.EverifyViewReportPage;
import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by abrackett on 9/13/16.
 */
public class LaunchFormPages extends ProductFormPages {

    @FindBy(how = How.ID, using = "btnSubmit")
    public static WebElement continueButton;

    public static void  clickContinuebtn(){
        continueButton.click();
    }

    public static boolean compareLaunchFormTitle(String title) {
        try {
            TWFramework.WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.xpath
                    ("//div[@class='title']/*[contains(text(), '" + title + "')]")).isDisplayed()
                    , org.openqa.selenium.NoSuchElementException.class);
            return true;
        } catch (org.openqa.selenium.TimeoutException toe) {
            return false;
        }
    }

    /**
     * @return Does page contain "View existing report".
     */
    public static boolean isViewExistingReportText() {
        return Driver.getDriver().getPageSource().contains("View existing report.");
    }

    /**
     * @return Does page contain "Cancel existing report".
     */
    public static boolean isExistingI9TaskInProgress() {
        return Driver.getDriver().getPageSource().contains("Cancel existing report.");
    }

    public static void cancelExistingI9InProgress(CancelFormI9Page.CancelReasons candidateNoShow,
                                                  String cancelText) {
        WindowManagement.setMainWindow();
        WindowManagement.clickElementToOpenNewWindow(Driver.getDriver().findElement(By.linkText
                ("Cancel existing report.")), false);
        WindowManagement.switchToAlternateWindow();
        CancelFormI9Page.cancelI9InProgress(candidateNoShow, cancelText);
        WindowManagement.switchToMainWindow();
    }

    /**
     * Clicks View Existing Report Link and then Manages Case from the Candidate View Page.
     */
    public static void clickViewExistingReportLinkAndManageCase() {
        Driver.getDriver().findElement(By.linkText("View existing report.")).click();
        EverifyViewReportPage.manageCase();
        EverifyNameCheckModal.closeCase();
        EverifyNameCheckModal.clickYesBecauseEmploymentAuth();
        EverifyNameCheckModal.clickClose();
    }
}
