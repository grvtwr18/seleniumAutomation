package Sites.TalentWiseDashboard.ProductFormPages;

import Data.locations.canada.CanadianProvinceTerritory;
import Data.locations.countrycode.CountryCode;
import Data.locations.us.UsStateTerritory;
import TWFramework.BasicTest;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import Sites.CandidatePortal.Enums.Month;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by djoe on 3/16/2017.
 *
 * Additional webElements and methods for Canadian Criminal Record Checks (CPIC/CCRC)
 * and Canadian Credit Inquiries.
 */
public class CanadaCriminRecordCheckLaunchPage extends ScreeningLaunchPage {

    @FindBy(how = How.ID, using = "qobirth")
    private static WebElement placeOfBirthCountryDropdown;

    @FindBy(how = How.ID, using = "qcbirth")
    private static WebElement placeOfBirthCityTextbox;

    @FindBy(how = How.ID, using = "qsbirth")
    private static WebElement placeOfBirthTerritoryDropdown;

    @FindBy(how = How.ID, using= "qjobposition")
    private static WebElement jobPositionTextBox;

    @FindBy(how = How.XPATH, using = "//*[@id='qcanadaidverification_Group890_1'][@value='1']" )
    private static  WebElement hiringManagerRadioButton;

    @FindBy(how = How.XPATH, using = "//*[@id='qcanadaidverification_Group890_1'][@value='2']" )
    private static  WebElement electronicIdRadioButton;

    @FindBy(how = How.XPATH, using = "//*[@id='qcanadaidverification_Group890_1'][@value='3']" )
    private static  WebElement canadaPostIdRadioButton;

    @FindBy(how = How.ID, using = "qeidfallback_Group890_1")
    private static WebElement offrampOptionDropdown;

    @FindBy(how = How.NAME, using = "qhaveconviction_Group890-0_1")
    private static WebElement haveConvictionDropDown;

    @FindBy(how = How.ID, using = "spanAdd_Group890-0_1")
    private static WebElement declareAdditionalOffenceLink;

    @FindBy(how = How.ID, using = "qisrush_10634_1")
    private static WebElement rushCrimRequestCheckBox;

    @FindBy(how = How.ID, using = "qisrush_10641_1")
    private static WebElement rushCredRequestCheckBox;

    @FindBy(how = How.ID, using = "qisrush_10643_1")
    private static WebElement rushXCheckRequestCheckBox;

    @FindBy(how = How.ID, using = "qshow_Group1079-0_1")
    private static WebElement lpiCheckbox;

    @FindBy(how = How.ID, using = "qshow_Group1080-0_1")
    private static WebElement slpiCheckbox;

    @FindBy(how = How.NAME, using = "qa_Group")
    private static WebElement canadianResidenceAddressTextBox;

    @FindBy(how = How.ID, using = "qc_Group")
    private static WebElement canadianResidenceCityTextBox;

    @FindBy(how = How.NAME, using = "qs_Group")
    private static WebElement canadianResidenceProvinceTerritoryDropDown;

    @FindBy(how = How.ID, using = "qz_Group")
    private static WebElement canadianResidenceZipCodeTextBox;

    @FindBy(how = How.ID, using = "qresfrommonth_Group")
    private static WebElement canadianResidenceFromMonthDropDown;

    @FindBy(how = How.ID, using = "qresfromyear_Group")
    private static WebElement canadianResidenceFromYearDropDown;

    @FindBy(how = How.NAME, using = "qrestomonth_Group")
    private static WebElement canadianResidenceToMonthDropDown;

    @FindBy(how = How.NAME, using = "qrestoyear_Group")
    private static WebElement canadianResidenceToYearDropDown;

    @FindBy(how = How.NAME, using = "qnocanada_Group")
    private static WebElement neverLivedInCanadaCheckBox;

    public static enum Verification_Id_Type {
        HIRING_MANAGER,
        ELECTRONIC_ID,
        CANADA_POST;
    }

    /**
     * Enums for offramp options. Also associates the dropdown text with the enum
     */
    public static enum Offramp_Option {
        CANADA_POST("Canada Post ID Verification"),
        HIRING_MANAGER("Hiring Manager / Organizational Representative ID Verification");

        private String option;

        Offramp_Option(String option) {
            this.option = option;
        }

        public String getOption() {
            return this.option;
        }
    }

    public static enum HaveConvictionOption {
        YES_HAVE_BEEN_CONVICTED("Yes"),
        NO_NEVER_CONVICTED("No");

        private String option;

        HaveConvictionOption(String option) {
            this.option = option;
        }

        public String getOption() {
            return this.option;
        }
    }

    public static class ConvictionOffenceAndDate {
        public String convictedOffence;
        public LocalDate dateOfConviction;

        public ConvictionOffenceAndDate(String convictedOffence, LocalDate dateOfConviction) {
            this.convictedOffence = convictedOffence;
            this.dateOfConviction = dateOfConviction;
        }

        @Override
        public String toString() {
            return String.format("Offence: \"%s\" on %s",
                    convictedOffence,
                    dateOfConviction.format(DateTimeFormatter.ofPattern("yyyy/M/d")));
        }
    }

    public static class ResidenceHistory {

        public static final int YEAR_NOT_SET = -1;

        public CountryCode countryRegion;
        public String streetAddress;
        public String city;
        public CanadianProvinceTerritory provinceTerritory;
        public UsStateTerritory stateTerritory;
        public String zipCode;
        public Month fromMonth;
        public int fromYear;
        public Month toMonth;
        public int toYear;

        public ResidenceHistory(String streetAddress, String city,
                                CanadianProvinceTerritory provinceTerritory, String zipCode) {

            this.countryRegion = CountryCode.CA;
            this.streetAddress = streetAddress;
            this.city = city;
            this.provinceTerritory = provinceTerritory;
            this.stateTerritory = null;
            this.zipCode = zipCode;
            this.fromMonth = null;
            this.fromYear = YEAR_NOT_SET;
            this.toMonth = null;
            this.toYear = YEAR_NOT_SET;
        }

        public ResidenceHistory(String streetAddress, String city,
                                UsStateTerritory stateTerritory, String zipCode) {

            this.countryRegion = CountryCode.US;
            this.streetAddress = streetAddress;
            this.city = city;
            this.provinceTerritory = null;
            this.stateTerritory = stateTerritory;
            this.zipCode = zipCode;
            this.fromMonth = null;
            this.fromYear = YEAR_NOT_SET;
            this.toMonth = null;
            this.toYear = YEAR_NOT_SET;
        }

        public boolean isCurrentResidence() {
            return (null == toMonth) || (YEAR_NOT_SET == toYear);
        }

        public boolean isCanadian() {
            return (null != provinceTerritory) && (CanadianProvinceTerritory.UNSET != provinceTerritory);
        }

        public boolean isUsAmerican() {
            return (null != stateTerritory) && (UsStateTerritory.UNSET != stateTerritory);
        }

        private static LocalDate shortMonthYearToLocalDate(Month month, int year) {
            return LocalDate.of(year, month.numeric(), 1);
        }

        public LocalDate getFromDate() {
            return shortMonthYearToLocalDate(fromMonth, fromYear);
        }

        public LocalDate getToDate() {
            if (this.isCurrentResidence()) {
                final LocalDate NOW = LocalDate.now();
                return LocalDate.of(NOW.getYear(), NOW.getMonth(), 1);
            } else {
                return shortMonthYearToLocalDate(toMonth, toYear);
            }
        }

        public ResidenceHistory setCurrentLivedHereFrom(Month fromMonth, int fromYear) {
            this.fromMonth = fromMonth;
            this.fromYear = fromYear;

            return this;
        }

        public ResidenceHistory setPreviousLivedHereFromTo(Month fromMonth, int fromYear,
                                                           Month toMonth, int toYear) {
            this.fromMonth = fromMonth;
            this.fromYear = fromYear;
            this.toMonth = toMonth;
            this.toYear = toYear;

            return this;
        }

        public static boolean areAnyResidencesInCanada(ResidenceHistory... residenceHistories) {
            if (0 == residenceHistories.length) {
                throw new IllegalArgumentException("Must supply residenceHistories to areAnyResidencesInCanada() routine");
            }

            for (ResidenceHistory residenceHistory : residenceHistories) {
                if (residenceHistory.isCanadian()) {
                    return true;
                }
            }

            return false;
        }

        /**
         * If the given residenceHistories begin with 5 years of non-Canadian residence(s)
         * then an extra CANADIAN RESIDENCE section will pop up.
         * @param residenceHistories assumed to be in current/newest to oldest chronological order.
         * @return true if the given residenceHistories will require a CANADIAN RESIDENCE section.
         */
        public static boolean willRequireExtraCanadianResidence(ResidenceHistory... residenceHistories) {
            final LocalDate NOW = LocalDate.now();
            final LocalDate FIVE_YEARS_AGO = LocalDate.of(NOW.getYear() - 5, NOW.getMonth(), 1);

            if (0 == residenceHistories.length) {
                throw new IllegalArgumentException("Must supply residenceHistories to willRequireExtraCanadianResidence() routine");
            }

            for (ResidenceHistory residenceHistory : residenceHistories) {
                // If the residence histories show that someone lived in Canada within the last 5 years
                // then no extra CANADIAN RESIDENCE will be required ...
                if (residenceHistory.isCanadian()) {
                    if (FIVE_YEARS_AGO.isBefore(residenceHistory.getToDate())
                            || FIVE_YEARS_AGO.equals(residenceHistory.getToDate())) {
                        // No extra CANADIAN RESIDENCE will be required if the candidate has lived
                        // in Canada within the last 5 years ...
                        return false;
                    }
                }
            }

            // If still here, the residenceHistories indicate that the
            // Candidate didn't live in Canada within the last 5 years,
            // so an extra CANADIAN RESIDENCE will be required ...
            return true;
        }

        @Override
        public String toString() {
            String stateOrProvince = (CountryCode.CA == countryRegion) ?
                    provinceTerritory.getSubdivisionCode() : stateTerritory.getSubdivisionCode();

            return String.format("%s %s, %s %s from %s %d to %s", streetAddress, city, stateOrProvince, zipCode,
                    fromMonth.toString(), fromYear, (null != toMonth) ? toMonth.toString() + " " + toYear : "present");
        }
    }

    ///////////////////////////
    // Methods

    static {
        PageFactory.initElements(Driver.getDriver(), CanadaCriminRecordCheckLaunchPage.class);
    }

    /**
     * Select Place of Birth country/region by text.
     *
     * @param country (String) Name of country/region to select
     */
    public static void setPlaceOfBirthCountry(String country) {
        SeleniumTest.selectByVisibleTextFromDropDown(placeOfBirthCountryDropdown, country);
    }
     //Select Conviction from dropdown
    public  void selectConviction(String con) {
        SeleniumTest.selectByVisibleTextFromDropDown(haveConvictionDropDown, con);
    }
    /**
     * Type text into the Place of Birth City text box.
     *
     * @param city (String) Name of city
     */
    public static void setPlaceOfBirthCity(String city) {
        SeleniumTest.clearAndSetText(placeOfBirthCityTextbox, city);
    }

    /**
     * Select Place of Birth State/Territory by text
     *
     * @param territory
     */
    public static void setPlaceOfBirthTerritory(String territory) {
        SeleniumTest.selectByVisibleTextFromDropDown(placeOfBirthTerritoryDropdown, territory);
    }

    public static void typeJobPosition(String jobPosition) {
        SeleniumTest.clearAndSetText(jobPositionTextBox, jobPosition);
    }

    /**
     * Method just clicks on the radio button. Does not validate that the button is actually
     * selected
     * 
     * @param idType
     */
    public static void chooseIDVerificationRadioButton(Verification_Id_Type idType) {
        switch(idType) {
            case HIRING_MANAGER:
                SeleniumTest.click(hiringManagerRadioButton);
                break;
            case ELECTRONIC_ID:
                SeleniumTest.click(electronicIdRadioButton);
                break;
            case CANADA_POST:
                SeleniumTest.click(canadaPostIdRadioButton);
                break;
        }
    }

    /**
     * Selects option by visible text from the Offramp Option dropdown
     *
     * @param option (OFFRAMP_OPTION) Enum of offramp options
     */
    public static void selectOfframpOption(Offramp_Option option) {
        SeleniumTest.selectByVisibleTextFromDropDown(offrampOptionDropdown, option.getOption());
    }

    public static CountryCode getCurrentResidenceCountryRegion() {
        String countryRegion = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qo"));
        return CountryCode.findByName(countryRegion).get(0);
    }

    public static void setCurrentResidenceCountryRegion(CountryCode countryRegion) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qo"), countryRegion.getName());
    }

    public static String getCurrentStreetAddress() {
        return SeleniumTest.getTextByLocator(By.name("qa"));
    }

    public static void setCurrentStreetAddress(final String streetAddress) {
        SeleniumTest.clearAndSetTextAdamantly(By.name("qa"), streetAddress);
    }

    public static String getCurrentCity() {
        return SeleniumTest.getTextByLocator(By.id("qc"));
    }

    public static void setCurrentCity(String city) {
        SeleniumTest.clearAndSetTextAdamantly(By.id("qc"), city);
    }

    public static CanadianProvinceTerritory getCurrentProvinceTerritory() {
        String provinceTerritory = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qs"));
        return CanadianProvinceTerritory.parse(provinceTerritory);
    }

    public static void setCurrentProvinceTerritory(CanadianProvinceTerritory provinceTerritory) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qs"), provinceTerritory.getFullName());
    }

    public static UsStateTerritory getCurrentStateTerritory() {
        String stateTerritory = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qs"));
        return UsStateTerritory.parse(stateTerritory);
    }

    public static void setCurrentStateTerritory(UsStateTerritory stateTerritory) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qs"), stateTerritory.getFullName());
    }

    public static String getCurrentResidenceZipCode() {
        return SeleniumTest.getTextByLocator(By.id("qz"));
    }

    public static void setCurrentResidenceZipCode(String zipCode) {
        SeleniumTest.clearAndSetTextAdamantly(By.id("qz"), zipCode);
    }

    public static String getCurrentLivedHereFromShortMonth() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qresfrommonth"));
    }

    public static void setCurrentLivedHereFromShortMonth(Month fromMonth) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qresfrommonth"), fromMonth.abbreviation());
    }

    public static String getCurrentLivedHereFromYear() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qresfromyear"));
    }

    public static void setCurrentLivedHereFromYear(int fromYear) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qresfromyear"), Integer.toString(fromYear));
    }

    public static CountryCode getPreviousResidenceCountryRegion(int index) {
        String countryRegion = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qoprev" + index));
        return CountryCode.findByName(countryRegion).get(0);
    }

    public static void setPreviousResidenceCountryRegion(int index, CountryCode countryRegion) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qoprev" + index), countryRegion.getName());
    }

    public static String getPreviousStreetAddress(int index) {
        return SeleniumTest.getTextByLocator(By.name("qaprev" + index));
    }

    public static void setPreviousStreetAddress(int index, String streetAddress) {
        SeleniumTest.clearAndSetTextAdamantly(By.name("qaprev" + index), streetAddress);
    }

    public static String getPreviousCity(int index) {
        return SeleniumTest.getTextByLocator(By.id("qcprev" + index));
    }

    public static void setPreviousCity(int index, String city) {
        SeleniumTest.clearAndSetTextAdamantly(By.id("qcprev" + index), city);
    }

    public static CanadianProvinceTerritory getPreviousProvinceTerritory(int index) {
        String provinceTerritory = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qsprev" + index));
        return CanadianProvinceTerritory.parse(provinceTerritory);
    }

    public static void setPreviousProvinceTerritory(int index, CanadianProvinceTerritory provinceTerritory) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qsprev" + index), provinceTerritory.getFullName());
    }

    public static UsStateTerritory getPreviousStateTerritory(int index) {
        String stateTerritory = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qsprev" + index));
        return UsStateTerritory.parse(stateTerritory);
    }

    public static void setPreviousStateTerritory(int index, UsStateTerritory stateTerritory) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qsprev" + index), stateTerritory.getFullName());
    }

    public static String getPreviousResidenceZipCode(int index) {
        return SeleniumTest.getTextByLocator(By.id("qzprev" + index));
    }

    public static void setPreviousResidenceZipCode(int index, String zipCode) {
        SeleniumTest.clearAndSetTextAdamantly(By.id("qzprev" + index), zipCode);
    }

    public static Month getPreviousLivedHereFromShortMonth(int index) {
        return Month.parse(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qresfrommonthprev" + index)));
    }

    public static void setPreviousLivedHereFromShortMonth(int index, Month fromMonth) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qresfrommonthprev" + index), fromMonth.abbreviation());
    }

    public static int getPreviousLivedHereFromYear(int index) {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qresfromyearprev" + index)));
    }

    public static void setPreviousLivedHereFromYear(int index, int fromYear) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qresfromyearprev" + index), Integer.toString(fromYear));
    }

    public static Month getPreviousLivedToShortMonth(int index) {
        return Month.parse(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.name("qrestomonthprev" + index)));
    }

    public static void setPreviousLivedHereToShortMonth(int index, Month toMonth) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.name("qrestomonthprev" + index), toMonth.abbreviation());
    }

    public static int getPreviousLivedHereToYear(int index) {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.name("qrestoyearprev" + index)));
    }

    public static void setPreviousLivedHereToYear(int index, int toYear) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.name("qrestoyearprev" + index), Integer.toString(toYear));
    }

    public static String getCdnResidenceStreetAddress() {
        return SeleniumTest.getText(canadianResidenceAddressTextBox);
    }

    public static void setCdnResidenceStreetAddress(String streetAddress) {
        SeleniumTest.clearAndSetTextAdamantly(canadianResidenceAddressTextBox, streetAddress);
    }

    public static String getCdnResidenceCity() {
        return SeleniumTest.getText(canadianResidenceCityTextBox);
    }

    public static void setCdnResidenceCity(String city) {
        SeleniumTest.clearAndSetTextAdamantly(canadianResidenceCityTextBox, city);
    }

    public static CanadianProvinceTerritory getCdnResidenceProvinceTerritory() {
        String provinceTerritory = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(canadianResidenceProvinceTerritoryDropDown);
        return CanadianProvinceTerritory.parse(provinceTerritory);
    }

    public static void setCdnResidenceProvinceTerritory(CanadianProvinceTerritory provinceTerritory) {
        SeleniumTest.selectByVisibleTextFromDropDown(canadianResidenceProvinceTerritoryDropDown, provinceTerritory.getFullName());
    }

    public static String getCdnResidenceZipCode() {
        return SeleniumTest.getText(canadianResidenceZipCodeTextBox);
    }

    public static void setCdnResidenceZipCode(String zipCode) {
        SeleniumTest.clearAndSetTextAdamantly(canadianResidenceZipCodeTextBox, zipCode);
    }

    public static Month getCdnResidenceLivedHereFromShortMonth() {
        return Month.parse(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(canadianResidenceFromMonthDropDown));
    }

    public static void setCdnResidenceLivedHereFromShortMonth(Month fromMonth) {
        SeleniumTest.selectByVisibleTextFromDropDown(canadianResidenceFromMonthDropDown, fromMonth.abbreviation());
    }

    public static int getCdnResidenceLivedHereFromYear() {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(canadianResidenceFromYearDropDown));
    }

    public static void setCdnResidenceLivedHereFromYear(int fromYear) {
        SeleniumTest.selectByVisibleTextFromDropDown(canadianResidenceFromYearDropDown, Integer.toString(fromYear));
    }

    public static Month getCdnResidenceLivedToShortMonth() {
        return Month.parse(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(canadianResidenceToMonthDropDown));
    }

    public static void setCdnResidenceLivedHereToShortMonth(Month toMonth) {
        SeleniumTest.selectByVisibleTextFromDropDown(canadianResidenceToMonthDropDown, toMonth.abbreviation());
    }

    public static int getCdnResidenceLivedHereToYear() {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(canadianResidenceToYearDropDown));
    }

    public static void setCdnResidenceLivedHereToYear(int toYear) {
        SeleniumTest.selectByVisibleTextFromDropDown(canadianResidenceToYearDropDown, Integer.toString(toYear));
    }

    public static ResidenceHistory getCurrentResidence() {
        ResidenceHistory currentResidence = null;
        CountryCode countryRegion = getCurrentResidenceCountryRegion();

        switch (countryRegion) {
            case CA:
                currentResidence = new ResidenceHistory(
                        getCurrentStreetAddress(),
                        getCurrentCity(),
                        getCurrentProvinceTerritory(),
                        getCurrentResidenceZipCode());
                break;
            case US:
                currentResidence = new ResidenceHistory(
                        getCurrentStreetAddress(),
                        getCurrentCity(),
                        getCurrentStateTerritory(),
                        getCurrentResidenceZipCode());
                break;
            default:
                throw new InvalidElementStateException("getCurrentResidence() not equipped to handle country: "
                        + countryRegion.getName());
        }

        currentResidence.setCurrentLivedHereFrom(
                Month.parse(getCurrentLivedHereFromShortMonth()),
                Integer.parseInt(getCurrentLivedHereFromYear()));

        return currentResidence;
    }

    public static void setCurrentResidence(ResidenceHistory currentResidence) {
        setCurrentResidenceCountryRegion(currentResidence.countryRegion);

        // Intentionally unset the State/Province/Territory to keep the frustrating validation from sporadically
        // disabling other elements of the residence as automation tries to enter data ...
        switch (currentResidence.countryRegion) {
            case CA:
                WaitUntil.waitUntil(() -> {
                    // Takes a little while for the provinces to fill up after selecting Country/Region = Canada ...
                    setCurrentProvinceTerritory(CanadianProvinceTerritory.UNSET);
                    return true;
                }, StaleElementReferenceException.class);
                break;
            case US:
                WaitUntil.waitUntil(() -> {
                    // Takes a little while for the states to fill up after selecting Country/Region = United States ...
                    setCurrentStateTerritory(UsStateTerritory.UNSET);
                    return true;
                }, StaleElementReferenceException.class);
                break;
            default:
                throw new IllegalArgumentException("setCurrentResidence() not equipped to handle country: "
                        + currentResidence.countryRegion.getName());
        }

        setCurrentStreetAddress(currentResidence.streetAddress);
        setCurrentCity(currentResidence.city);
        setCurrentResidenceZipCode(currentResidence.zipCode);

        switch (currentResidence.countryRegion) {
            case CA:
                setCurrentProvinceTerritory(currentResidence.provinceTerritory);
                break;
            case US:
                setCurrentStateTerritory(currentResidence.stateTerritory);
                break;
        }

        setCurrentLivedHereFromShortMonth(currentResidence.fromMonth);
        setCurrentLivedHereFromYear(currentResidence.fromYear);
    }

    public static ResidenceHistory getPreviousResidence(int index) {
        ResidenceHistory previousResidence = null;
        CountryCode countryRegion = getPreviousResidenceCountryRegion(index);

        switch (countryRegion) {
            case CA:
                previousResidence = new ResidenceHistory(
                        getPreviousStreetAddress(index),
                        getPreviousCity(index),
                        getPreviousProvinceTerritory(index),
                        getPreviousResidenceZipCode(index));
                break;
            case US:
                previousResidence = new ResidenceHistory(
                        getPreviousStreetAddress(index),
                        getPreviousCity(index),
                        getPreviousStateTerritory(index),
                        getPreviousResidenceZipCode(index));
                break;
            default:
                throw new InvalidElementStateException("getPreviousResidence(" + index
                        + ") not equipped to handle country: "
                        + countryRegion.getName());
        }

        previousResidence.setPreviousLivedHereFromTo(
                getPreviousLivedHereFromShortMonth(index),
                getPreviousLivedHereFromYear(index),
                getPreviousLivedToShortMonth(index),
                getPreviousLivedHereToYear(index));

        return previousResidence;
    }

    public static void setPreviousResidence(int index, ResidenceHistory previousResidence) {
        // TODO: Figure out why setting the From/To dates after the address gives rise to doubled up residence history problems.
        setPreviousLivedHereFromShortMonth(index, previousResidence.fromMonth);
        setPreviousLivedHereFromYear(index, previousResidence.fromYear);
        setPreviousLivedHereToShortMonth(index, previousResidence.toMonth);
        setPreviousLivedHereToYear(index, previousResidence.toYear);

        setPreviousResidenceCountryRegion(index, previousResidence.countryRegion);

        // Intentionally unset the State/Province/Territory to keep the frustrating validation from sporadically
        // disabling other elements of the residence as automation tries to enter data ...
        switch (previousResidence.countryRegion) {
            case CA:
                WaitUntil.waitUntil(() -> {
                    // Takes a little while for the provinces to fill up after selecting Country/Region = Canada ...
                    setPreviousProvinceTerritory(index, CanadianProvinceTerritory.UNSET);
                    return true;
                }, StaleElementReferenceException.class);
                break;
            case US:
                WaitUntil.waitUntil(() -> {
                    // Takes a little while for the states to fill up after selecting Country/Region = United States ...
                    setPreviousStateTerritory(index, UsStateTerritory.UNSET);
                    return true;
                }, StaleElementReferenceException.class);
                break;
            default:
                throw new IllegalArgumentException("setCurrentResidence() not equipped to handle country: "
                        + previousResidence.countryRegion.getName());
        }

        setPreviousStreetAddress(index, previousResidence.streetAddress);
        setPreviousCity(index, previousResidence.city);
        setPreviousResidenceZipCode(index, previousResidence.zipCode);

        switch (previousResidence.countryRegion) {
            case CA:
                setPreviousProvinceTerritory(index, previousResidence.provinceTerritory);
                break;
            case US:
                setPreviousStateTerritory(index, previousResidence.stateTerritory);
                break;
        }

        // TODO: Figure out why setting From/To dates here gave rise to doubled up residence history problems.
    }

    /**
     * @return the CANADIAN RESIDENCE which only shows if the last 5 years of address history never appear in Canada.
     */
    public static ResidenceHistory getExtraCanadianResidence() {
        ResidenceHistory canadianResidence = new ResidenceHistory(
                getCdnResidenceStreetAddress(),
                getCdnResidenceCity(),
                getCdnResidenceProvinceTerritory(),
                getCdnResidenceZipCode());

        canadianResidence.setPreviousLivedHereFromTo(
                getCdnResidenceLivedHereFromShortMonth(),
                getCdnResidenceLivedHereFromYear(),
                getCdnResidenceLivedToShortMonth(),
                getCdnResidenceLivedHereToYear());

        return canadianResidence;
    }

    /**
     * Set the CANADIAN RESIDENCE which only shows if the last 5 years of address history never appear in Canada.
     * @param canadianResidence
     */
    public static void setExtraCanadianResidence(ResidenceHistory canadianResidence) {
        if (CountryCode.CA != canadianResidence.countryRegion) {
            throw new IllegalArgumentException("Can't set CANADIAN RESIDENCE to non-Canadian address: " + canadianResidence);
        }

        // Intentionally unset the State/Province/Territory to keep the frustrating validation from sporadically
        // disabling other elements of the residence as automation tries to enter data ...
        setCdnResidenceProvinceTerritory(CanadianProvinceTerritory.UNSET);
        setCdnResidenceStreetAddress(canadianResidence.streetAddress);
        setCdnResidenceCity(canadianResidence.city);
        setCdnResidenceZipCode(canadianResidence.zipCode);
        setCdnResidenceProvinceTerritory(canadianResidence.provinceTerritory);
        setCdnResidenceLivedHereFromShortMonth(canadianResidence.fromMonth);
        setCdnResidenceLivedHereFromYear(canadianResidence.fromYear);
        setCdnResidenceLivedHereToShortMonth(canadianResidence.toMonth);
        setCdnResidenceLivedHereToYear(canadianResidence.toYear);
    }

    /**
     * The CANADIAN RESIDENCE is only supposed to show if the last 5 years of address history never appear in Canada.
     * @return true if the CANADIAN RESIDENCE entry section is showing.
     */
    public static boolean isExtraCanadianResidenceVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.name("qa_Group"))
                && SeleniumTest.isElementVisibleNoWaiting(By.id("qc_Group"))
                && SeleniumTest.isElementVisibleNoWaiting(By.name("qs_Group"))
                && SeleniumTest.isElementVisibleNoWaiting(By.id("qz_Group"))
                && SeleniumTest.isElementVisibleNoWaiting(By.id("qresfrommonth_Group"))
                && SeleniumTest.isElementVisibleNoWaiting(By.id("qresfromyear_Group"))
                && SeleniumTest.isElementVisibleNoWaiting(By.name("qrestomonth_Group"))
                && SeleniumTest.isElementVisibleNoWaiting(By.name("qrestoyear_Group"));
    }

    /**
     * @return the number of Residence History sections visible on the page.
     */
    public static int getResidenceHistoryCount() {
        int count = 0;

        // Check how many Country/Region drop-downs are showing ...
        if (SeleniumTest.isElementVisibleNoWaiting(By.id("qo"))) {
            ++count; // Current Country/Region is showing.

            while (SeleniumTest.isElementVisibleNoWaiting(By.id("qoprev" + (count - 1)))) {
                ++count;
            }
        }

        if (isExtraCanadianResidenceVisible()) {
            ++count;
        }

        return count;
    }

    public static ResidenceHistory[] getAllResidenceHistory() {
        int count = getResidenceHistoryCount();

        ResidenceHistory[] residenceHistory = new ResidenceHistory[count];

        if (0 < count) {
            residenceHistory[0] = getCurrentResidence();

            int previousResidenceCount = count - 1;
            if (isExtraCanadianResidenceVisible()) {
                // Simply copy the CANADIAN RESIDENCE to the end of the array ...
                residenceHistory[count - 1] = getExtraCanadianResidence();
                --previousResidenceCount;
            }

            for (int i = 0; i < previousResidenceCount; ++i) {
                // Put the rest of the previous residences after the current residence,
                // but before the CANADIAN RESIDENCE, per chance CANADIAN RESIDENCE is showing ...
                residenceHistory[i + 1] = getPreviousResidence(i);
            }
        }

        return residenceHistory;
    }

    public static void setAllResidenceHistory(ResidenceHistory... residenceHistories) {
        if (0 < residenceHistories.length) {
            setCurrentResidence(residenceHistories[0]);

            int previousResidenceCount = residenceHistories.length - 1;
            boolean hasExtraCanadianResidence = false;

            if (ResidenceHistory.willRequireExtraCanadianResidence(residenceHistories)) {
                if (residenceHistories[residenceHistories.length - 1].isCanadian()) {
                    hasExtraCanadianResidence = true;
                    --previousResidenceCount;
                }
            }

            for (int i = 0; i < previousResidenceCount; ++i) {
                setPreviousResidence(i, residenceHistories[i + 1]);
            }

            if (hasExtraCanadianResidence) {
                WaitUntil.waitUntil("Extra CANADIAN RESIDENCE section for more than 5 years should be visible, "
                        + "not being visible probably means this search doesn't require CANADIAN RESIDENCE.",
                        () -> isExtraCanadianResidenceVisible());

                setExtraCanadianResidence(residenceHistories[residenceHistories.length - 1]);
            }
        }
    }

    public static void selectHaveConvictionDropDown(HaveConvictionOption haveConvictionOption) {
        SeleniumTest.selectByVisibleTextFromDropDown(haveConvictionDropDown, haveConvictionOption.getOption());
    }

    public static void checkConviction(int base1Index) {
        SeleniumTest.check(By.id("qshowoffence_Group890-0_" + base1Index));
    }

    public static void unCheckConviction(int base1Index) {
        SeleniumTest.unCheck(By.id("qshowoffence_Group890-0_" + base1Index));
    }

    public static boolean isConvictionCheckBoxVisible(int base1Index) {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qshowoffence_Group890-0_" + base1Index));
    }

    public static boolean isConvictionChecked(int base1Index) {
        return SeleniumTest.isCheckboxChecked(By.id("qshowoffence_Group890-0_" + base1Index));
    }

    public static String getConvictedOffence(int base1Index) {
        return SeleniumTest.getTextByLocator(By.name("qconvictedoffence_Group890-0_" + base1Index));
    }

    public static void typeConvictedOffence(int base1Index, String convictedOffence) {
        SeleniumTest.clearAndSetText(By.name("qconvictedoffence_Group890-0_" + base1Index), convictedOffence);
    }

    public static LocalDate getDateOfConviction(int base1Index) {
        String date = SeleniumTest.getTextByLocator(By.id("qdateconviction_Group890-0_" + base1Index));
        LocalDate localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy/M/d"));
        return localDate;
    }

    public static void typeDateOfConviction(int base1Index, LocalDate localDate) {
        String date = localDate.format(DateTimeFormatter.ofPattern("yyyy/M/d"));
        SeleniumTest.clearAndSetTextAdamantly(By.id("qdateconviction_Group890-0_" + base1Index), date);
        // Then click on the Convicted Offence to make sure the date drop-down goes away ...
        SeleniumTest.click(By.name("qconvictedoffence_Group890-0_" + base1Index));
    }

    public static ConvictionOffenceAndDate[] getConvictionOffensesAndDates() {
        List<ConvictionOffenceAndDate> convictionOffencesAndDates = new ArrayList<ConvictionOffenceAndDate>();

        for(int base1Index = 1; isConvictionCheckBoxVisible(base1Index); ++base1Index) {
            if (isConvictionChecked(base1Index)) {
                String convictedOffence = getConvictedOffence(base1Index);
                LocalDate dateOfConviction = getDateOfConviction(base1Index);
                convictionOffencesAndDates.add(new ConvictionOffenceAndDate(convictedOffence, dateOfConviction));
            }
        }

        return convictionOffencesAndDates.toArray(new ConvictionOffenceAndDate[convictionOffencesAndDates.size()]);
    }

    public static void typeConvictionOffensesAndDates(ConvictionOffenceAndDate... convictionOffencesAndDates) {
        int base1Index = 1;
        for (ConvictionOffenceAndDate convictionOffenceAndDate : convictionOffencesAndDates) {
            if (!isConvictionCheckBoxVisible(base1Index)) {
                clickDeclareAdditionalOffenceLink();
            }

            checkConviction(base1Index);
            typeConvictedOffence(base1Index, convictionOffenceAndDate.convictedOffence);
            typeDateOfConviction(base1Index, convictionOffenceAndDate.dateOfConviction);
            ++base1Index;
        }

        while (isConvictionCheckBoxVisible(base1Index)) {
            unCheckConviction(base1Index++);
        }
    }

    public static void clickDeclareAdditionalOffenceLink() {
        SeleniumTest.click(declareAdditionalOffenceLink);
    }

    //////////////////////////////////////////////////////////////
    // LPI checkbox displayed only if CCRC+LPI uberform is created
    public static void checkLPI() { SeleniumTest.check(lpiCheckbox); }

    public static void unCheckLPI() { SeleniumTest.unCheck(lpiCheckbox); }
    // LPI end
    //////////////////////////////////////////////////////////////

    ////////////////////////////////////////////////////////////////
    // SLPI checkbox displayed only if CCRC+SLPI uberform is created
    public static void checkSLPI() { SeleniumTest.check(slpiCheckbox); }

    public static void unCheckSLPI() { SeleniumTest.unCheck(slpiCheckbox); }
    // SLPI end
    //////////////////////////////////////////////////////////////

    public static void checkRushCrimRequest() {
        SeleniumTest.check(rushCrimRequestCheckBox);
    }

    public static void unCheckRushCrimRequest() {
        SeleniumTest.unCheck(rushCrimRequestCheckBox);
    }

    public static boolean isRushCrimRequestChecked() {
        return SeleniumTest.isCheckboxChecked(rushCrimRequestCheckBox);
    }

    public static boolean isRushCrimRequestCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qisrush_10634_1"));
    }

    public static void checkRushCredRequest() {
        SeleniumTest.check(rushCredRequestCheckBox);
    }

    public static void unCheckRushCredRequest() {
        SeleniumTest.unCheck(rushCredRequestCheckBox);
    }

    public static boolean isRushCredRequestChecked() {
        return SeleniumTest.isCheckboxChecked(rushCredRequestCheckBox);
    }

    public static boolean isRushCredRequestCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qisrush_10641_1"));
    }

    public static void checkRushXCheckRequest() {
        SeleniumTest.check(rushXCheckRequestCheckBox);
    }

    public static void unCheckRushXCheckRequest() {
        SeleniumTest.unCheck(rushXCheckRequestCheckBox);
    }

    public static boolean isRushXCheckRequestChecked() {
        return SeleniumTest.isCheckboxChecked(rushXCheckRequestCheckBox);
    }

    public static boolean isRushXCheckRequestCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qisrush_10643_1"));
    }

    public static void checkNeverLivedInCanada() {
        SeleniumTest.check(neverLivedInCanadaCheckBox);
    }

    public static void unCheckNeverLivedInCanada() {
        SeleniumTest.unCheck(neverLivedInCanadaCheckBox);
    }

    public static boolean isNeverLivedInCanadaChecked() {
        return SeleniumTest.isCheckboxChecked(neverLivedInCanadaCheckBox);
    }

    public static boolean isNeverLivedInCanadaCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qnocanada_Group"));
    }
}
