package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URISyntaxException;
import java.util.List;

public class ExistingCandidatesPage extends ProductFormPages{

	public Header header;
	public Footer footer;

    private static final Logger staticLogger = LoggerFactory
            .getLogger(ExistingCandidatesPage.class.getName());

	@FindBy(how = How.ID, using = "btnContinue")
	private static WebElement continueButton;
	
	@FindBy(how = How.ID, using = "btnCancel")
	private static WebElement cancelButton;

	@FindBy(how = How.XPATH, using = "//div[@class='searchErrorBox']/div[@class='head' "
			+ "and contains(.,'Existing Reports Found for Candidate')]")
	private static WebElement searchErrorBoxText;

	@FindBy(how = How.CSS, using = "input.button")
	private static WebElement confirmAndLaunchButton;
	static {
		PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
	}

	public static boolean onPage() {
        boolean foundError = false;
        boolean foundSearchForm = false;
        try {
            List<NameValuePair> queryParams =
                    new URIBuilder(Driver.getDriver().getCurrentUrl()).getQueryParams();

            for(NameValuePair nvp : queryParams) {
                if (nvp.getName().equals("error")) {
                    foundError = true;
                }
                if (nvp.getName().equals("searchform")) {
                    foundSearchForm = true;
                }
            }
        } catch (URISyntaxException e) {
            // Hoping this never gets hit based on being on a valid URL
            // when calling this method.  Opted to throw RuntimeException to avoid
            // making the whole world add a new exception to their tests.
            throw new RuntimeException(e.getMessage());
        }
        return (foundError && foundSearchForm);
	}

    /**
     * Temporary until I can figure out how to speed up onPage
     * @param source what to look for
     * @return True or false
     */
    public static boolean sourceContains(String source) {
        return Driver.getDriver().getPageSource().contains(source);
    }

	/**
	 * Clicks the "Continue" button.
	 * @return A new Review Order Page page object
	 */
	public static ReviewOrderPage clickContinueButton() {
		WaitUntil.waitUntil(()->continueButton.isDisplayed());
		SeleniumTest.waitForElementToBeClickable(continueButton);
		continueButton.click();
		SeleniumTest.waitForElementVisible(confirmAndLaunchButton);
        staticLogger.info("Existing Reports Page - Click Continue");
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
	}

	/**
	 * Clicks the "Continue" button.
	 * @return A new Review Order Page page object
	 */
	public static ProductFormPages clickContinueButton(Class<? extends ProductFormPages> returnedClass) {
		continueButton.click();
		return PageFactory.initElements(Driver.getDriver(), returnedClass);
	}

	/**
	 * Clicks the "Continue" button assuming at least one further error/warning page
	 * will present itself.
	 * @return A new Product Form Error page object
	 */
	public static ProductFormErrorPage clickContinueButtonExpectingError() {
		continueButton.click();
		return PageFactory.initElements(Driver.getDriver(), ProductFormErrorPage.class);
	}
	
	/**
	 * Clicks the "Cancel" button.
	 * @return A new Product Form Page page object
	 */
	public ScreeningLaunchPage clickCancelButton() {
		continueButton.click();
		return PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPage.class);
	}
}
