package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;

/**
 * Created by abrackett on 3/7/2016.
 */
public class FS532LaunchPage extends ProductFormPages {

    @FindBy(how = How.CSS, using = "div.title>h1")
    public WebElement pageHeaderLabel;

    private static final String visibleDate1 = "dp_qduedate1";
    private static final String hiddenDate1 = "qduedate1";

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    @FindBy(how = How.ID, using = "FormZero-6883_52")
    private static WebElement formW4Checkbox;

    @FindBy(how = How.ID, using = "FormZero-6883_51")
    private static WebElement stateTaxWithHoldingCheckbox;

    @FindBy(how = How.ID, using = "refcode")
    private static WebElement refrenceCodeCheckbox;

    @FindBy(how = How.ID, using = "FormZero-1971_1")
    private static WebElement stateTaxDropDown;

    @FindBy(how = How.ID, using = "FormZero-6883_57")
    private static WebElement directDepositMandCheckbox;

    @FindBy(how = How.XPATH, using = "//input[@value='Confirm and Launch']")
    private static WebElement confirmAndLaunchButton;

    public FS532LaunchPage() {
        // Waiting for the Due Date box to be clickable before returning from the constructor
        SeleniumTest.waitForElementToBeClickable(By.id(visibleDate1), SeleniumTest.waitForElementTimeout);
    }
    /**
     * Sets the due date for the Launch Form
     * @param dueDate
     */
    public static FS532LaunchPage setDueDate1(LocalDate dueDate) {
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(dueDate, visibleDate1, hiddenDate1);
        return PageFactory.initElements(Driver.getDriver(), FS532LaunchPage.class);
    }

    /**
     * Clicks continue and returns the appropriate page class
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        clickContinueButton();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static void setForm532DueDateClickContinue(String dueDate) {
        LocalDate localDate = LocalDate.parse(dueDate, LocaleHelper.getDateFormatShortDateSlash_uuuu());
        setDueDate1(localDate);
        clickContinueButton();
    }

    public static void clickContinueButton() {
        continueButton.click();
    }

    public static void selectFormW4Checkbox() {
        formW4Checkbox.click();
    }

    public Object fillFormReviewFormSet532(String dueDate)
    {
        setForm532DueDateClickContinue(dueDate);
        //Get the page on which customer is and return it.
        String pageHeader = pageHeaderLabel.getText();
        if(pageHeader.equals("onboarding new hire forms")) {
            return PageFactory.initElements(Driver.getDriver(), NewHireSelectionFormPage.class);
        } else {
            return PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
        }
    }

    public void fillNewHireFormFS532(String RefrnceCode,String stateName){
        SeleniumTest.selectByVisibleTextFromDropDown(refrenceCodeCheckbox,RefrnceCode);
        stateTaxWithHoldingCheckbox.click();
        SeleniumTest.selectByVisibleTextFromDropDown(stateTaxDropDown,stateName);
        directDepositMandCheckbox.click();
        clickContinueButton();
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(confirmAndLaunchButton);
        confirmAndLaunchButton.click();
    }

}
