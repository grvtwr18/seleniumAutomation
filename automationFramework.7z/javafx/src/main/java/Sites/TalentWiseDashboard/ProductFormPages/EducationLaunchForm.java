package Sites.TalentWiseDashboard.ProductFormPages;

import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by qli on 10/20/16.
 */
public class EducationLaunchForm {
    public enum EducationFormQvars {
        CERTIFICATE_DEGREE("select", "name", "qcert_"),
        MAJOR("input", "name", "qdgre_"),
        SCHOOL_NAME("input", "name", "qschn_"),
        COUNTRY("select", "name", "qo_"),
        SCHOOL_STATE("select", "name", "qschs_"),
        SCHOOL_CITY("input", "name","qschc_"),
        GRADUATE("select", "name", "qdidgraduate_"),
        FIRST_NAME("input", "name", "qfedalias_"),
        LAST_NAME("input", "name", "qnedalias_"),
        SCHOOL_ADDRESS("input", "name", "qscha_"),
        SCHOOL_PHONE_NUMBER("input", "name", "qschph_"),
        SCHOOL_FAX_NUMBER("input", "name", "qschfax_"),
        SCHOOL_EMAIL("input", "name", "qschee_"),
        SCHOOL_DEPARTMENT("input", "name", "qschdept_"),
        STUDENT_ID("input", "name", "qschstudentid_"),
        GRADUATE_DATE_MONTH("select", "name", "qgraddtmm_"),
        GRADUATE_DATE_YEAR("select", "name", "qgraddtyy_"),
        ATTENDANCE_START_DATE_MONTH("select", "name", "qatndstmm_"),
        ATTENDANCE_START_DATE_YEAR("select", "name", "qatndendyy_"),
        ATTENDANCE_END_DATE_YEAR("select", "name", "qatndendyy_"),
        ATTENDANCE_END_DATE_MONTH("select", "name", "qatndendmm_");

        private final String tagName;
        private final String attribute;
        private final String prefix;

        public String getTagName() {
            return tagName;
        }

        public String getAttribute() {
            return attribute;
        }

        public String getPrefix() {
            return prefix;
        }

        EducationFormQvars(String tagName, String attribute, String prefix) {
            this.tagName = tagName;
            this.attribute = attribute;
            this.prefix = prefix;
        }
    }
    
    public static WebElement getElement(EducationFormQvars qvar, int index) {
        return Driver.getDriver().findElement(By.cssSelector(qvar.getTagName() + "[" + qvar.getAttribute() + "^='" + qvar.getPrefix() + "'][" + qvar.getAttribute() + "$='" + String.valueOf(index) + "']"));
    }

    /**
     * to retrieve the text value of web elements
     */
    public static String getCertificateDegree(int index) {
        return getElement(EducationFormQvars.CERTIFICATE_DEGREE, index).getAttribute("value");
    }

    public static String getMajor(int index) {
        return getElement(EducationFormQvars.MAJOR, index).getAttribute("value");
    }

    public static String getSchoolName(int index) {
        return getElement(EducationFormQvars.SCHOOL_NAME, index).getAttribute("value");
    }

    public static String getCountryName(int index) {
        return getElement(EducationFormQvars.COUNTRY, index).getAttribute("value");
    }

    public static String getSchoolState(int index) {
        return getElement(EducationFormQvars.SCHOOL_STATE, index).getAttribute("value");
    }

    public static String getSchoolCity(int index) {
        return getElement(EducationFormQvars.SCHOOL_CITY, index).getAttribute("value");
    }

    public static String getGraduate(int index) {
        return getElement(EducationFormQvars.GRADUATE, index).getAttribute("value");
    }

    public static String getFirstName(int index) {
        return getElement(EducationFormQvars.FIRST_NAME, index).getText();
    }

    public static String getLastName(int index) {
        return getElement(EducationFormQvars.LAST_NAME, index).getText();
    }

    public static String getDepartment(int index) {
        return getElement(EducationFormQvars.SCHOOL_DEPARTMENT, index).getText();
    }

    public static String getSchoolAddress(int index) {
        return getElement(EducationFormQvars.SCHOOL_ADDRESS, index).getText();
    }

    public static String getSchoolPhoneNumber(int index) {
        return getElement(EducationFormQvars.SCHOOL_PHONE_NUMBER, index).getText();
    }

    public static String getSchoolEmail(int index) {
        return getElement(EducationFormQvars.SCHOOL_EMAIL, index).getText();
    }

    public static String getSchoolFaxNumber(int index) {
        return getElement(EducationFormQvars.SCHOOL_FAX_NUMBER, index).getText();
    }

    public static String getStudentId(int index) {
        return getElement(EducationFormQvars.STUDENT_ID, index).getText();
    }

    public static String getGraduateDateMonth(int index) {
        return getElement(EducationFormQvars.GRADUATE_DATE_MONTH, index).getAttribute("value");
    }

    public static String getGradudateDateYear(int index) {
        return getElement(EducationFormQvars.GRADUATE_DATE_YEAR, index).getAttribute("value");
    }

    public static String getAttendanceStartDateMonth(int index) {
        return getElement(EducationFormQvars.ATTENDANCE_START_DATE_MONTH, index).getAttribute("value");
    }

    public static String getAttendanceStartDateYear(int index) {
        return getElement(EducationFormQvars.ATTENDANCE_START_DATE_YEAR, index).getAttribute("value");
    }

    public static String getAttendanceEndDateYear(int index) {
        return getElement(EducationFormQvars.ATTENDANCE_START_DATE_YEAR, index).getAttribute("value");
    }

    public static String getAttendanceEndDateMonth(int index) {
        return getElement(EducationFormQvars.ATTENDANCE_END_DATE_MONTH, index).getAttribute("value");
    }
}
