package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.AdminConsole.CustomerSupport.ScreeningSupport.RequestQueue.RequestDetailPage;
import Sites.AdminConsole.CustomerSupport.ScreeningSupport.RequestQueue.RequestQueuePage;
import Sites.AdminConsole.Login.ExistingAccountLoginPage;
import Sites.CandidatePortal.Eda.ElectronicDisclosurePage;
import Sites.CandidatePortal.PortalSignInPage;
import Sites.TalentWiseDashboard.CustomerPortalPage;
import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;


/**
 * Page object that represents the Order Confirmation page on the TalentWise Dashboard website
 * that is reached at the end of the product launching process.
 *
 * @author eelefson
 */
public class OrderConfirmationPage extends CustomerPortalPage {

    public Header header;
    public Sidebar sidebar;
    public Footer footer;
    private static final Logger logger = LoggerFactory.getLogger("OrderConfirmationPage");

    @FindBy(how = How.CLASS_NAME, using = "contentSection")
    private static WebElement messageBody;

    @FindBy(how = How.XPATH, using =
            "//div[@id='dbIdContentInner']/div[contains(.,'DEV: Password sent to the candidate')]")
    private static WebElement devPasswordSentToCandidate;

    @FindBy(how = How.XPATH, using = "//*[@id='report_view_button']/../preceding-sibling::div[1]")
    private static WebElement packageTitleText;

    @FindBy(how = How.ID, using = "report_view_button")
    private static WebElement ViewReportProgress;

    @FindBy(how = How.CLASS_NAME, using = "recordDetail")
    private static WebElement fullMessageBody;

    @FindBy(how = How.ID, using = "ticketLinkSentToCandidate")
    private static WebElement ticketLinkSentToCandidate;

    @FindBy(how = How.ID, using = "candidate_view_button")
    private static WebElement goToCandidateViewButton;

    @FindBy(how = How.ID, using = "report_view_button")
    private static WebElement viewReportInProgressButton;

    @FindBy(how = How.XPATH, using = "//div[@class='contentRow']/div[contains(strong,\"Candidate\")]/following-sibling::div[1]")
    private static WebElement candidateNameAndIdText;

    @FindBy(how = How.XPATH, using = "//div[@class='boxContent']/p/strong[contains(.,'Report ID')]")
    private static WebElement reportIDText;

    @FindBy(how =  How.XPATH, using = "//td[contains(@id,'DevEnvReqID')]//a")
    private static WebElement verifyREquestID;

    //TODO: replace this with a WebElement located based on @href
    private static final String AUTOMATIC_REQUEST_ACTION_CLEAR_EXPECTED_LINK = "Clear";

    private static final String AUTOMATIC_REQUEST_ACTION_HIT_EXPECTED_LINK = "Hit";

    private static final String AUTOMATIC_REQUEST_ACTION_NOSHOW_EXPECTED_LINK = "No Show";

    private static final String AUTOMATIC_REQUEST_ACTION_NOBILL_EXPECTED_LINK = "No Bill";

    @FindBy(how = How.CSS, using = "div[id^=\"divDevProcessStatus\"] > strong")
    private static WebElement automaticRequestActionResponse;

    // Additional Action Required Section - BGS Special Releases
    @FindBy(how = How.ID, using = ".//*[@id='dbIdContentInner']/div[4]/div[2]/div/div[2]/div/ul/li[1]/span")
    private WebElement consentBasedSSNVerification;

    @FindBy(how = How.ID, using = ".//*[@id='dbIdContentInner']/div[4]/div[2]/div/div[2]/div/ul/li[2]/span")
    private WebElement alaskaDmvRecords;

    @FindBy(how = How.ID, using = ".//*[@id='dbIdContentInner']/div[4]/div[2]/div/div[2]/div/ul/li[3]/span")
    private WebElement priaRecordsRequest;

    @FindBy(how = How.ID, using = ".//*[@id='dbIdContentInner']/div[4]/div[2]/div/div[2]/div/ul/li[4]/span")
    private WebElement fmcsa3YearDrug;

    @FindBy(how = How.XPATH, using = "//h3[contains(text(),'Reverification Complete')]")
    private static WebElement reverificationCompleteMessage;

    @FindBy(how = How.XPATH, using = "//a[contains(@href, 'screening/tickets.php')]")
    private static WebElement viewAllTickets;

    @FindBy(how = How.CSS, using = "input[value='Continue']")
    private static WebElement continueButton;

    private static final String FOR_AUTOMATION_EXPECTED_LINK = "For Automation";

    @FindBy(how = How.CSS, using = "#dbIdContentInner > div.candidateContextPage > div.recordDetail > div:nth-child(2) > div > div.contentBox > div")
    private static WebElement pleaseNoteMessage;

    @FindBy(how = How.CSS, using = "li > span")
    private static WebElement specialReleaseMessage;

    @FindBy(how = How.ID, using = "portalContent")
    private static WebElement portalContent;

    @FindBy(how = How.XPATH, using = "//a[contains(@href, '/screening/dhs-screening.php')]")
    private static WebElement registerButton;

    @FindBy(how = How.XPATH, using = "//form//div[@class='uploadFileBrowse' or @id='uploadFileBrowse']//input[@name='userfile' and @type='file']")
    private static WebElement chooseFileButton;

    @FindBy(how = How.XPATH, using = "//*[@id='userfile']")
    private static WebElement BrowseFileButton;

    @FindBy(how = How.CSS, using = "input[type='submit']")
    private static WebElement attachFileButton;

    @FindBy(how = How.CLASS_NAME, using = "contentAlertTitle")
    private static WebElement additionalActionRequired;

    @FindBy(how = How.ID, using = "sso-username")
    private static WebElement userNameLink;

    @FindBy(how = How.XPATH, using = "//*[@id='menu-list-grow']/ul/li[2]")
    private static WebElement signoutButton;

    @FindBy(how = How.NAME, using = "btnedit")
    private static WebElement editBtn;

    @FindBy(how = How.XPATH, using = "//td[contains(@id,'EnvReqType_0')]")
    private static WebElement requestType;

    @FindBy(how = How.XPATH, using = "//td[contains(@id,'EnvMode_0')]")
    private static WebElement mode;

    @FindBy(how = How.XPATH, using = "//td[contains(@id,'EnvProvider_0')]")
    private static WebElement provider;

    @FindBy(how = How.XPATH, using = "//td[contains(@id,'EnvReqID_0')]")
    private static WebElement requestID;

    @FindBy(how = How.XPATH, using = "//*[contains(@src,'ajax-loader-small-horiz2.gif')]")
    private static WebElement progressIndicator;

    private static final Logger staticLogger = LoggerFactory.getLogger(OrderConfirmationPage.class);
    /**
     * Constructor static.
     */
    static {
        PageFactory.initElements(Driver.getDriver(), OrderConfirmationPage.class);
    }

    public static boolean isProgressIndicatorShowing() {
        try {
            return progressIndicator.isDisplayed();
        } catch(NoSuchElementException nse) {
            return false;
        }

    }

    public static WebElement getMessageBody() {
        return messageBody;
    }

    public static ExistingAccountLoginPage clickSignout(){

        userNameLink.click();
        SeleniumTest.waitForElementVisible(signoutButton);
        signoutButton.click();
        return PageFactory.initElements(Driver.getDriver(), ExistingAccountLoginPage.class);
    }

    public static RequestDetailPage clickEditBtn(){
        SeleniumTest.click(editBtn);
        return PageFactory.initElements(Driver.getDriver(),RequestDetailPage.class);
    }
    public static String getPackageTitleText() {
        return packageTitleText.getText();
    }

    public static WebElement getFullMessageBody() {
        return fullMessageBody;
    }

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("report_view_button"));
    }

    public static boolean pageSourceContains(String content) {
        return Driver.getDriver().getPageSource().contains(content);
    }
    /**
     * you must be in proxy mode to use this
     * @return the newly created candidate's password
     */
    public static String getPasswordFromForAutomationLink() {
        //TODO consider a check to confirm you are in proxy mode
        WebElement forAutomationLink = Driver.getDriver().findElement(By.linkText
                (FOR_AUTOMATION_EXPECTED_LINK));
        logger.info("For Automation URL: {}", forAutomationLink.getAttribute("href"));
        logger.info(forAutomationLink.getAttribute("href").substring(forAutomationLink.getAttribute("href").indexOf("Password=")+9));
        return forAutomationLink.getAttribute("href").substring(forAutomationLink.getAttribute("href").indexOf("Password=")+9);
    }



    /**
     * Return the request ID
     * @return
     */
    public static String getRequestID(int rowNumber) {
        return Driver.getDriver().findElement(By.cssSelector("td#DevEnvReqID_" + rowNumber + ">a")).getText();
    }

    public static WebElement requestIDLink(int rowNumber) {
        return Driver.getDriver().findElement(By.cssSelector("td#DevEnvReqID_" + rowNumber + ">a"));
    }

    /**
     * Returns the provider name for for the given row
     * @param row The row number of the request - Starts with index 0
     * @return String The provider mentioned on the page
     */
    public static String getProviderName(int row) {
        return Driver.getDriver().findElement(By.id("DevEnvProvider_" + row)).getText();
    }

    public static void clickViewAllTickets() {
        viewAllTickets.click();
    }

    /**
     * Clicks the "Ticket link sent to candidate" link.
     * @return A new Portal Sign In page object
     */
    public static PortalSignInPage clickTicketLinkSentToCandidate() {
        SeleniumTest.click(ticketLinkSentToCandidate);
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Returns the password, displayed in the dev environment.
     */
    public static String getPasswordToPortalSignIn() {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"dbIdContentInner\"]/div[1]")).split(": ")[2].split("\\n")[0];
    }

    /**
     * Returns the URL from the "Ticket link sent to candidate", displayed in the dev environment.
     * @return The link (href) as a String
     */
    public static String getTicketLinkSentToCandidate() {
        return ticketLinkSentToCandidate.getAttribute("href");
    }

    public static String getPasswordSentToCandidate() {
        return SeleniumTest.getText(devPasswordSentToCandidate).split(":")[2].trim();
    }

    /**
     * Return the request ID
     * @return
     */
    public static String getRequestID() {
        return Driver.getDriver().findElement(By.cssSelector("table.B6>tbody tr td.B1>a")).getText();
    }

    /**
     * Checks if reverification is complete
     *
     * @return
     */
    public static Boolean isReverificationComplete() {
        return SeleniumTest.verifyElementPresent(reverificationCompleteMessage);
    }

    public static boolean isRegisterButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//a[contains(@href, '/screening/dhs-screening.php')])"));
    }

    /**
     * Clicks the "Ticket link sent to candidate" link.
     *
     * @return A new Electronic Disclosure page object
     */
    public ElectronicDisclosurePage clickTicketLinkSentToCandidateNoLogin() {
        SeleniumTest.click(ticketLinkSentToCandidate);
        return PageFactory.initElements(Driver.getDriver(), ElectronicDisclosurePage.class);
    }

    /**
     * Clicks the "Go to Candidate View" button.
     *
     * @return A new Candidate Details page object
     */
    public static CandidateDetailsPage clickGoToCandidateViewButton() {
        SeleniumTest.waitForElementToBeClickable(goToCandidateViewButton,
                SeleniumTest.waitForElementTimeout);
        goToCandidateViewButton.click();
        return PageFactory.initElements(Driver.getDriver(), CandidateDetailsPage.class);
    }

    /**
     * Clicks the "View Report in Progress" button.
     *
     * @return A new View Report page object
     */
    public static ViewReportPage clickViewReportInProgressButton() {
        logger.info("Click View Report In Progress Button");
        SeleniumTest.waitForElementVisible(viewReportInProgressButton);
        WaitUntil.clickable(viewReportInProgressButton).click();
        logger.info("Initialize ViewReportPage");
        return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);
    }

    /**
     * Clicks on Continue Case Radio Button.
     */
    public static void clickContinueCase() {
        Driver.getDriver().findElement(By.id("duplicateCase1")).click();
    }

    /**
     * Clicks on Continue button in case of duplicate case
     */
    public static void clickContinueButton() {
        continueButton.click();
    }

    public static String getCandidateName() {
        return candidateNameAndIdText.getText().replaceAll(" \\(\\d+\\).*", "");
    }

    /**
     * Gets the candidate ID from the page.
     *
     * @return The candidate ID
     */
    public static String getCandidateID() {
        return candidateNameAndIdText.getText().replaceAll(".*\\(", "").replaceAll("\\)", "");
    }

    /**
     * Gets the report ID from the page
     *
     * @return The report ID
     */
    public static String getReportID() {
        WaitUntil.waitUntil(() -> onPage(), NoSuchElementException.class);
        return reportIDText.getText().replaceAll("Report ID ", "");
    }

    /**
     * Clicks the "Clear" link in the "Automatic Request Actions" box shown in dev, and returns the response text.
     *
     * @return
     */
    public static String clickAutomaticRequestActionClear() {
        Driver.getDriver().findElement(By.linkText(AUTOMATIC_REQUEST_ACTION_CLEAR_EXPECTED_LINK)).click();
        return getAutomaticRequestActionResponse();
    }

    /**
     * Clicks the "Hit" link in the "Automatic Request Actions" box shown in dev, and returns the response text.
     *
     * @return
     */
    public static String clickAutomaticRequestActionHit() {
        Driver.getDriver().findElement(By.linkText(AUTOMATIC_REQUEST_ACTION_HIT_EXPECTED_LINK)).click();
        return getAutomaticRequestActionResponse();
    }

    /**
     * Clicks the "Hit" link in the "Automatic Request Actions" box shown in dev, and returns the response text.
     *
     * @return
     */
    public static String clickAutomaticRequestActionNoShow() {
        Driver.getDriver().findElement(By.linkText(AUTOMATIC_REQUEST_ACTION_NOSHOW_EXPECTED_LINK)).click();
        return getAutomaticRequestActionResponse();
    }

    /**
     * Clicks the "Hit" link in the "Automatic Request Actions" box shown in dev, and returns the response text.
     *
     * @return
     */
    public static String clickAutomaticRequestActionNoBill() {
        Driver.getDriver().findElement(By.linkText(AUTOMATIC_REQUEST_ACTION_NOBILL_EXPECTED_LINK)).click();
        return getAutomaticRequestActionResponse();
    }

    /**
     * Gets the text content of the bold response shown after an action is chosen from the "Automatic Request Actions"
     *
     * @return
     */
    public static String getAutomaticRequestActionResponse() {
        SeleniumTest.waitForElement(automaticRequestActionResponse);
        return automaticRequestActionResponse.getText();
    }

    /**
     * Clicks on request ID link
     * @param requestID
     * @return
     */
    public static RequestQueuePage clickRequestID(String requestID) {
        WebElement requestIdLink = Driver.getDriver().findElement(By.linkText(requestID));
        SeleniumTest.waitForElementToBeClickable(requestIdLink);
        WindowManagement.clickElementToOpenNewWindow(requestIdLink);
        return PageFactory.initElements(Driver.getDriver(), RequestQueuePage.class);
    }

    /**
     * @return the text "PLEASE NOTE: ..." that appears just above the SpecialReleaseMessage() when applicable
     *
     */
    public static String getPleaseNoteMessage() {
        SeleniumTest.waitForElement(pleaseNoteMessage);
        return pleaseNoteMessage.getText();
    }

    /**
     * Returns the text of the corresponding locator
     * @return
     */
    public static String getSpecialReleaseMessage() {
        SeleniumTest.waitForElement(specialReleaseMessage);
        return specialReleaseMessage.getText();
    }

    /**
     * Returns the text for special release requirements: Additional Action Required alert.
     * @return Additional Action Required Text.
     */
    public static String getAdditionalActionRequiredMessage(){
        return SeleniumTest.getText(additionalActionRequired);
    }

    /**
     * Returns the request type. Eg: Criminal Check by Jurisdiction
     * @param row Row number of the request
     * @return String Returns the type of request mentioned in the table.
     */
    public static String getRequestType(int row) {
        return Driver.getDriver().findElement(By.id("DevEnvReqType_" + row)).getText();
    }

    /**
     * Returns the text displayed in Special releases sent box.
     * @param row Row number
     * @return String Text in the row for Special Releases pdfs
     */
    public static String getSpecialReleasePdfMsgs(int  row) {
        return SeleniumTest.getTextByLocator(By.xpath("//div[@id='dbIdContentInner']/div[3]/div[2]/div/div[2]/div/ul/li[" + row + "]/span"));
    }

    /**
     * Starting text of the Special Release content box
     * @return String Returns the first line
     */
    public static String getSpecialReleaseIntroText() {
        return Driver.getDriver().findElement(By.xpath("//div[@class='boxContent']/span")).getText();
    }

    public static void hideNameAndReportId() {
        List<WebElement> usernames = Driver.getDriver().findElements(By.xpath("//*[contains(text(), 'Moogle')]"));
        for(WebElement name : usernames) {
            BodyTextHelper.hideElement(name);
        }
        WebElement dateSubmitted = Driver.getDriver().findElement(By.xpath("//div[@id='dbIdContentInner']/div[1]/div[1]/div[2]/div[3]/div[2]"));
        BodyTextHelper.hideElement(dateSubmitted);
        WebElement primaryReportId = Driver.getDriver().findElement(By.xpath("//*[@id='processingBox']/p[2]/strong[2]"));
        BodyTextHelper.hideElement(primaryReportId);
        WebElement secondaryReportId = Driver.getDriver().findElement(By.xpath("//*[@class='recordDetail']/div[2]/div[1]/div[2]/div[1]/p[1]/span[4]/strong[1]"));
        BodyTextHelper.hideElement(secondaryReportId);
    }

    public static WebElement getPortalContent() {
        return portalContent;
    }

    public static TestRegistrationPage clickRegisterButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(
                By.xpath("//a[@class='button dhsbutton']"));
        TestRegistrationPage testRegistrationPage = PageFactory.initElements(Driver.getDriver(), TestRegistrationPage.class);
        WaitUntil.waitUntil(() -> testRegistrationPage.onPage());
        return testRegistrationPage;
    }

    public static void clickViewReportProgressButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id("report_view_button"));
    }

    public static void clickUploadFile() {
        SeleniumTest.click(By.cssSelector("div.contentSection:last-of-type>div>div.contentRow>div.rightColumn>div>button"));
    }

    public static void uploadDocument(String filePath)
    {
        if(!org.apache.commons.lang.SystemUtils.IS_OS_WINDOWS) {
            if(!filePath.startsWith("/")) {
                filePath = "/" + filePath;
            }
        }
        SeleniumTest.clearAndSetText(chooseFileButton,filePath);
    }

    public static void uploadDocument2(String filePath)
    {
        if(!org.apache.commons.lang.SystemUtils.IS_OS_WINDOWS) {
            if(!filePath.startsWith("/")) {
                filePath = "/" + filePath;
            }
        }
        SeleniumTest.clearAndSetText(BrowseFileButton,filePath);
    }

    public static OrderConfirmationPage clickAttachFile(String fileName) {
        SeleniumTest.click(attachFileButton);
        logger.info("Upload File Button Pressed");
        SeleniumTest.click(By.cssSelector("form>div.uploadFileAttach>input"));
        WaitUntil.waitUntil(90, 3, () ->
                SeleniumTest.getTextByLocator(By.cssSelector("ul")).contains(fileName));
        logger.info("Upload File Button Action Complete");
        return PageFactory.initElements(Driver.getDriver(), OrderConfirmationPage.class);
    }

    public static void uploadReleaseForm(String filePath, String fileName) {
        logger.info("Click upload file button to open a new window");
        WindowManagement.runMethodToOpenNewWindow( () -> clickUploadFile(), false);

        logger.info("Upload the document and attach it");
        uploadDocument(filePath);
        OrderConfirmationPage.clickAttachFile(fileName);
        logger.info("Switch to main window and close other windows");
        WindowManagement.switchToMainWindow();
        WindowManagement.closeAllOtherWindows();
    }

    /* get the Request Type from the first row */
    public String getRequestType(){
        return SeleniumTest.getText(requestType);
    }

    /*Get the Mode from first row*/
    public String getMode(){
        return SeleniumTest.getText(mode);
    }

    /* get the Provider Name from first row */
    public String getProvider(){
        return SeleniumTest.getText(provider);
    }

    /* get the RequestID from the first row data */
    public String getRequestIDByXpath(){
        return  SeleniumTest.getText(requestID);
    }

    public void clickOnLinkByPackageNameAndAction(String packageName, String Action){
        SeleniumTest.click(By.xpath("//td[text()='"+packageName+"']/../td[4]//a[text()='"+Action+"']"));
    }

    public String statusPostAction(String packageName){
        return SeleniumTest.getTextByLocator(By.xpath("//td[text()='"+packageName+"']/../td[4]//strong"));
    }

    public void clickRequestIDLink(String requestID) {
        WebElement requestIdLink = Driver.getDriver().findElement(By.linkText(requestID));
        SeleniumTest.waitForElementToBeClickable(requestIdLink);
        WindowManagement.clickElementToOpenNewWindow(requestIdLink);
    }

    public String getTicketIdFromTicketLinkSentToCandidate()
    {
        return ticketLinkSentToCandidate.getAttribute("href").split("ticket=")[1];
    }

}