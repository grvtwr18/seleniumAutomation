package Sites.TalentWiseDashboard.ProductFormPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by jgupta on 4/21/2016.
 */
public class CanadaCreditReport423LaunchPage extends ProductFormPages {
    @FindBy(how = How.ID, using = "qmm")
    private static WebElement monthDD;

    @FindBy(how = How.ID, using = "qdd")
    private static WebElement dayDD;

    @FindBy(how = How.ID, using = "qyy")
    private static WebElement yearDD;

    @FindBy(how = How.ID, using = "qfcramanualagree")
    private static WebElement iHaveProvidedTheDisclosureCheckBox;

    @FindBy(how = How.ID, using = "qsin_423_1")
    private static WebElement socialInsuranceNumberTextBox;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    /**
     * Checks I have provided disclosure checkbox.
     */
    public static CanadaCreditReport423LaunchPage checkIHaveProvidedTheDisclosure() {
        SeleniumTest.check(iHaveProvidedTheDisclosureCheckBox);
        return PageFactory.initElements(Driver.getDriver(), CanadaCreditReport423LaunchPage.class);
    }

    /**
     * Types in Social Insurance Number text box
     */
    public static CanadaCreditReport423LaunchPage typeSocialInsuranceNumber(String number) {
        SeleniumTest.clearAndSetText(socialInsuranceNumberTextBox, number);
        return PageFactory.initElements(Driver.getDriver(), CanadaCreditReport423LaunchPage.class);
    }

    /**
     * Clicks Continue Button
     * @return ReviewOrderPage
     */
    public static ReviewOrderPage clickContinue() {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Select date of birth
     * @param dob Date of birth
     * @return CanadaCreditReport423LaunchPage
     */
    public CanadaCreditReport423LaunchPage selectDateOfBirth(LocalDate dob) {
        String month = dob.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);
        String day = (Integer.toString(dob.getDayOfMonth()));
        String year = (Integer.toString(dob.getYear()));

        SeleniumTest.selectShortMonthByVisibleText(monthDD, month);

        Select dayDropDown = new Select(dayDD);
        dayDropDown.selectByVisibleText(day);

        Select yearDropDown = new Select(yearDD);
        yearDropDown.selectByVisibleText(year);

        return PageFactory.initElements(Driver.getDriver(), CanadaCreditReport423LaunchPage.class);
    }
}
