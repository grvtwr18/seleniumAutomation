package Sites.TalentWiseDashboard.ProductFormPages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;

import WebDriver.Driver;

/**
 * Created by jgupta on 11/28/2015.
 */
public class ElectronicI9ReverifyLaunchPage extends I9ReverifyLaunchPages {

    @FindBy(how = How.CSS, using = "div.title>h1")
    public static WebElement pageHeaderLabel;

    /**
     * Fills the employee profile section.
     * @param fName
     * @param mName
     * @param lName
     * @param ssn
     * @param expiration
     * @param previousReportID
     */
    public void fillEmployeeProfileSection(LocalDate dueDate, String fName, String mName, String lName, String ssn, LocalDate expiration, String previousReportID) {
        EmployeeProfile.setFirstName(fName);
        EmployeeProfile.setMiddleInitialOrName(mName);
        EmployeeProfile.setLastName(lName);
        I9LaunchPages.EmployeeProfile.setSocialSecurityNumber(ssn);
        EmployeeProfile.setReverificationDueDate(dueDate);
    }

    /**
     * Clicks on Continue button
     * @return
     */
    public static Object clickContinue() {
         //Click on Continue button to go to next page.
        continueButton.click();

        //Get the page on which customer is and return it.
        String pageHeader = pageHeaderLabel.getText();
        if(pageHeader.equals("Review Your Order"))
            return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        else if(pageHeader.equals("Electronic I9 (Re-Verify)         "))
            return  PageFactory.initElements(Driver.getDriver(), ElectronicI9ReverifyLaunchPage.class);
        else {
            return PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
            }
        }
}