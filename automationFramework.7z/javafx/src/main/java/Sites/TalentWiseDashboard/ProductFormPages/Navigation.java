package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by abrackett on 10/19/16.
 */
public class Navigation {

    private static final Logger staticLogger = LoggerFactory
            .getLogger(Navigation.class.getName());

    static {
        PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.ProductFormPages
                .Navigation.class);
    }

    @FindBy(how = How.XPATH, using = "//input[@type='submit'][@value='Continue']")
    private static WebElement continueButton;

    @FindBy(how = How.XPATH, using = "//*[@class='price']")
    private static List<WebElement> displayedCurrencyList;

    /**
     * Clicks the continue button
     */
    public static void clickContinue() {
        SeleniumTest.waitForPageLoadToComplete();
        WaitUntil.waitUntil(() -> continueButton.isDisplayed(), NoSuchElementException.class);
        continueButton.click();
        SeleniumTest.waitForPageLoadToComplete();
        staticLogger.info("Click Continue");
    }

    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        clickContinue();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    private static final String confirmAndLaunchbuttonLocator = "input[type='submit']";
    @FindBy(how = How.CSS, using = confirmAndLaunchbuttonLocator)
    private static WebElement confirmAndLaunchButton;

    public static boolean isConfirmAndLaunchVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector(confirmAndLaunchbuttonLocator));
    }

    public static void clickConfirmAndLaunch() {
        confirmAndLaunchButton.click();
    }
    public static void clickConfirmAndSubmit() {
        clickConfirmAndLaunch();
    }

    private static final String purchaseButtonLocator = "//input[contains(@id, 'btn')][@class='button']";
    @FindBy(how = How.XPATH, using = purchaseButtonLocator)
    private static WebElement purchaseButton;

    public static boolean isPurchaseVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath(purchaseButtonLocator));
    }

    public static void clickPurchase() {
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(purchaseButton);
        staticLogger.info("Click Purchase");
        purchaseButton.click();
        SeleniumTest.waitMs(1000);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static void clickPurchaseUntilDisappears() {
        // Because sometimes the site just doesn't respond to the first click of the Purchase button ...
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.xpath(purchaseButtonLocator));
        staticLogger.info("Finally the purchase button is clicked and disappeared");
    }

    public static void clickSubmit() {
        clickPurchaseUntilDisappears();
    }


    public static ViewReportPage ClickViewApplicantReport(String reportID) {
        SeleniumTest.click(By.xpath("//*[@id='View_Applicant_Report_" + reportID + "']"));
        return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);

    }
    public static boolean validateCurrencyBeforePurchaseOrder(String userCurrency)
    {
        boolean sFlag=false;
        for(int i=0; i<displayedCurrencyList.size();i++)
        {
            if(userCurrency.contains("USD"))
            {
                if(displayedCurrencyList.get(i).getText().contains("$"))
                {
                    sFlag=true;
                    staticLogger.info("user currency is same as displayed currency on purchase order page");
                    return sFlag;
                }
                else
                {
                    sFlag=false;
                    staticLogger.warn("user currency is not same as displayed currency on purchase order page");
                }
            }
            else if(userCurrency.contains("CAD"))
            {
                if(displayedCurrencyList.get(i).getText().contains("CA$"))
                {
                    sFlag=true;
                    staticLogger.info("user currency is same as displayed currency on purchase order page");
                    return sFlag;
                }
                else
                {
                    sFlag=false;
                    staticLogger.warn("user currency is not same as displayed currency on purchase order page");
                }
            }
        }
        return sFlag;

    }
}
