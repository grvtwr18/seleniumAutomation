package Sites.TalentWiseDashboard.ProductFormPages;

import org.openqa.selenium.support.PageFactory;

import WebDriver.Driver;

/**
 * Created by jgupta on 4/13/2016.
 */
public class StandaloneElectronicI9Rehire788LaunchPage extends I9LaunchPages {

    /**
     * Click on continue button
     * @return the right page
     */
    public static ProductFormPages clickContinueButton(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);

    }
}
