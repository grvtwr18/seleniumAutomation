package Sites.TalentWiseDashboard.ProductFormPages;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by qli on 10/20/16.
 */
public class DmvLaunchForm {
    @FindBy(how = How.ID, using = "qo_Group24-0_1")
    private static WebElement countrySelect;

    @FindBy(how = How.ID, using = "qs_Group24-0_1_US")
    private static WebElement provinceSelect;

    @FindBy(how = How.ID, using = "qdl_Group24-0_1")
    private static WebElement driverLicenseInput;

    static {
        PageFactory.initElements(Driver.getDriver(), DmvLaunchForm.class);
    }

    /**
     * Return country name
     * @return
     */
    public static String getCountryName() {
        return countrySelect.getAttribute("value");
    }

    /**
     * Return province Name
     * @return
     */
    public static String getProvinceName() {
        return provinceSelect.getAttribute("value");
    }

    /**
     * Return  driver license
     * @return
     */
    public static String getDriverLicense() {
        return driverLicenseInput.getAttribute("value");
    }
}
