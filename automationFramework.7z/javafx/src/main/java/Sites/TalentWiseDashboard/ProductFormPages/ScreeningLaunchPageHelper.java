package Sites.TalentWiseDashboard.ProductFormPages;

import static Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchPage.*;

import Sites.TalentWiseDashboard.ProductFormPages.ReviewOrderPageForms.SsnCouldNotBeVerifiedPageHelper;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by kgochsner on 9/7/2016.
 */
public class ScreeningLaunchPageHelper {

    public static void fillFieldsIncludingSsnDob(Candidate candidate) {
        ScreeningLaunchPage.typeFirstName(candidate.getFirstName());
        ScreeningLaunchPage.typeLastName(candidate.getLastName());
        if (candidate.getMiddleName() != null) {
            ScreeningLaunchPage.typeMiddleName(candidate.getMiddleName());
        } else {
            ScreeningLaunchPage.checkConfirmNoMiddleNameCheckBox();
        }
        ScreeningLaunchPage.typeSSN(candidate.getSocialSecurityNumber());
        ScreeningLaunchPage.selectDateOfBirth(candidate.getDOB());
        ScreeningLaunchPage.typeEmail(candidate.getEmailAddress());
        ScreeningLaunchPage.typePhoneNumber(candidate.getCandidatePhone());
        ScreeningLaunchPage.typeAddress(candidate.getAddressLine1());
        ScreeningLaunchPage.typeCity(candidate.getCity());
        ScreeningLaunchPage.selectCandidateState(candidate.getState());
        ScreeningLaunchPage.typeZipCode(candidate.getZip());
    }

    /**
     * Fills Employment Verification Details
     *
     * @param employerNumber
     * @param employerName
     * @param employerPhoneNumber
     * @param employerCity
     * @param employerState
     * @param jobTitle
     * @param reasonForLeaving
     * @param startDateMonth
     * @param startDateYear
     * @param endDateMonth
     * @param endDateYear
     */
    public static void fillEmploymentVerificationDetails(String employerNumber, String groupNumber, String employerName, String employerPhoneNumber, String employerCity, String employerState, String jobTitle,
                                                         String reasonForLeaving, String startDateMonth, String startDateYear, String endDateMonth, String endDateYear, boolean checkSameAsCurrentFlag) {

        String groupId = discoverGroupId();

        typeEmployerName(employerNumber, employerName, groupNumber);
        typeEmployerPhoneNumber(employerNumber, employerPhoneNumber, groupNumber);
        typeEmployerCity(employerNumber, employerCity, groupNumber);
        selectEmployerState(employerNumber, employerState, groupNumber);
        typeJobTitle(employerNumber, jobTitle, groupNumber);
        selectReasonForLeaving(employerNumber, reasonForLeaving, groupNumber);
        selectStartDateMonth(employerNumber, startDateMonth, groupNumber);
        selectStartDateYear(employerNumber, startDateYear, groupNumber);

        if (endDateDropdownIsVisible(employerNumber, groupNumber)) {
            selectEndDateMonth(employerNumber, endDateMonth, groupNumber);
            selectEndDateYear(employerNumber, endDateYear, groupNumber);
        }

        if(checkSameAsCurrentFlag)
        checkSameAsCurrentCheckbox(employerNumber, groupNumber);
    }

    /**
     * Fills Education Verification Details
     *
     */
    public static void fillEducationVerificationDetails(String schoolName, String schoolCity, String schoolState, String fieldOfStudyOrMajor, String certificationOrDegreeOption, String didCandidateGraduateOption,
                                                        String dateEndedSchoolMonthOption, String dateEndedSchoolYearOption, String firstNameWhileAttendingSchool, String lastNameWhileAttendingSchool,
                                                        String educationGroupNumber) {
        String groupId = discoverGroupId();

        checkEducationVerification();
        typeSchoolFieldStudyOrMajor(fieldOfStudyOrMajor);
        selectCertificationOrDegree(certificationOrDegreeOption);
        typeSchoolName(schoolName);
        typeSchoolCity(schoolCity);
        selectSchoolState(schoolState);
        selectDidCandidateGraduate(didCandidateGraduateOption);
        selectDateEndedSchoolMonth(dateEndedSchoolMonthOption, educationGroupNumber, groupId);
        selectDateEndedSchoolYear(dateEndedSchoolYearOption, educationGroupNumber, groupId);
        setCheckboxNameWhileAttendingSchool();
        typeFirstNameWhileAttendingSchool(firstNameWhileAttendingSchool);
        typeLastNameWhileAttendingSchool(lastNameWhileAttendingSchool);
        checkSameAsCurrentCheckbox(educationGroupNumber, groupId);
    }

    /**
     * Fills Employment Verification Details
     *
     * @param employerNumber
     * @param employerName
     * @param employerPhoneNumber
     * @param employerCity
     * @param employerState
     * @param jobTitle
     * @param reasonForLeaving
     * @param startDateMonth
     * @param startDateYear
     */
    public static void fillEmploymentVerificationDetails(String employerNumber, String groupNumber, String employerName, String employerPhoneNumber, String employerCity, String employerState, String jobTitle,
                                                         String reasonForLeaving, String startDateMonth, String startDateYear) {
        fillEmploymentVerificationDetails(employerNumber, groupNumber, employerName, employerPhoneNumber, employerCity, employerState, jobTitle,
                reasonForLeaving, startDateMonth, startDateYear, null, null, true);
    }

    public static void fillAndSubmit(String ssn) {
        ScreeningLaunchPage.fillWithTestDataJs();
        ScreeningLaunchPage.typeSSN(ssn);
        ScreeningLaunchPage.clickSubmitButton();
    }

    /**
     * Fills the Screening launch page with a specific address and navigates to Review order page
     * @param currentAddress
     * @param city
     * @param state
     * @param zip
     */
    public static void fillAndSubmit(String currentAddress, String city, String state, String zip) {
        ScreeningLaunchPage.fillWithTestDataJs();
        ScreeningLaunchPage.fillAddressSection(currentAddress, city, state, zip);
        ScreeningLaunchPage.typeSSN("888-55-0014");
        ScreeningLaunchPage.clickSubmitButton();
        // 1 of the following 2 pages should eventually be loaded, but never both ...
        WaitUntil.waitUntil(() -> (SSNCouldNotBeVerifiedPage.onPage() != ReviewOrderPage.onPage()));
        if (SSNCouldNotBeVerifiedPage.onPage()) {
            // To move forward to the ReviewOrderPage ...
            SsnCouldNotBeVerifiedPageHelper.handleSsnCouldNotBeVerifiedCase();
        }
    }

    public static void fillAndSubmit() {
        ScreeningLaunchPage.fillWithTestDataJs();
        ScreeningLaunchPage.clickSubmitButton();
        WaitUntil.waitUntil(15, 2, () -> SSNCouldNotBeVerifiedPage.bypassedSsnVerification());
    }

    public static void typeFinancialInstitutions(String financialInstitutions) {
        String group = ScreeningLaunchPage.discoverGroupId();
        WebElement financialInstTextArea = Driver.getDriver()
                .findElement(By.id("qaddinf_Group" + group + "_1"));
        financialInstTextArea.sendKeys(financialInstitutions);
    }
}
