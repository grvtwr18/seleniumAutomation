package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;

/**
 * Created by jgupta on 2/22/2016.
 */
public class FormSet1621LaunchPage extends ProductFormPages{
    @FindBy(how = How.CSS, using = "input[fieldname='Company Name']")
    private static WebElement companyNameTextBox;

    @FindBy(how = How.ID, using = "FormZero-6003_61-6003_61")
    private static WebElement offerDateTextBox;

    @FindBy(how = How.ID, using = "FormZero-6003_62-6003_62")
    private static WebElement startDateTextBox;

    @FindBy(how = How.CSS, using = "input[fieldname='Job Title']")
    private static WebElement jobTitleTextBox;

    @FindBy(how = How.CSS, using = "input[fieldname='Manager Name or Manager Title']")
    private static WebElement managerNameTextBox;

    @FindBy(how = How.CSS, using = "select[fieldname='Position Time']")
    private static WebElement positionTimeDropDown;

    @FindBy(how = How.CSS, using = "input[value='exempt']")
    private static WebElement exemptRadioButton;

    @FindBy(how = How.CSS, using = "input[value='non-exempt']")
    private static WebElement nonExemptRadioButton;

    @FindBy(how = How.CSS, using = "input[value='salaried non-exempt']")
    private static WebElement salariedNonExemptRadioButton;

    @FindBy(how = How.CSS, using = "input[fieldname='Annual Salary Amount']")
    private static WebElement annualSalaryAmountTextBox;

    @FindBy(how = How.CSS, using = "select[fieldname='Payroll Schedule']")
    private static WebElement payrollScheduleDropDown;

    @FindBy(how = How.CSS, using = "input[fieldname='Offer Letter Signer Name']")
    private static WebElement offerLetterSignerNameTextBox;

    @FindBy(how = How.CSS, using = "input[fieldname='Offer Letter Signer Title']")
    private static WebElement offerLetterSignerTitleTextBox;

    @FindBy(how = How.CSS, using = "input[value='Yes']")
    private static WebElement yesRadioButton;

    @FindBy(how = How.CSS, using = "input[value='No']")
    private static WebElement noRadioButton;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;


    /**
     * Types company name in company name text box.
     * @param companyName
     */
    public static void typeCompanyName(String companyName) {
        SeleniumTest.clearAndSetText(companyNameTextBox, companyName, true);
    }

    /**
     * Types offer date in offer date text box.
     */
    public static void typeOfferDate(LocalDate offerDate) {
        if(Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(offerDate, "FormZero-6003_61-6003_61", "FormZero-6003_61");
        }
        else {
            String date = offerDate.format(LocaleHelper.getDateFormatShortDateSlash());
            SeleniumTest.clearAndSetText(offerDateTextBox, date, true);
        }
        offerDateTextBox.sendKeys(Keys.TAB);
    }

    /**
     * Types start date in start date text box
     * @param startDate
     */
    public static void typeStartDate(LocalDate startDate) {
        if(Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(startDate, "FormZero-6003_62-6003_62", "FormZero-6003_62");
        }
        else {
            String date = startDate.format(LocaleHelper.getDateFormatShortDateSlash());
            SeleniumTest.clearAndSetText(startDateTextBox, date, true);
        }
        startDateTextBox.sendKeys(Keys.TAB);
    }

    /**
     * Types job title in Job Title text box
     * @param jobTitle
     */
    public static void typeJobTitle(String jobTitle) {
        SeleniumTest.clearAndSetText(jobTitleTextBox, jobTitle, true);
    }

    /**
     * Types manager name or title
     * @param managerNameOrTitle
     */
    public static void typeManagerNameOrManagerTitle(String managerNameOrTitle) {
        SeleniumTest.clearAndSetText(managerNameTextBox, managerNameOrTitle, true);
    }

    /**
     * Selects position from Position Time dropdown.
     * @param positionTimeOption
     */
    public static void selectPositionTime(String positionTimeOption) {
        Select positionTimeDD = new Select(positionTimeDropDown);
        positionTimeDD.selectByVisibleText(positionTimeOption);
    }

    /**
     * Types in annual salary amount text box.
     * @param annualSalaryAmount
     */
    public static void typeAnnualSalaryAmount(String annualSalaryAmount) {
        SeleniumTest.clearAndSetText(annualSalaryAmountTextBox, annualSalaryAmount, true);
    }

    /**
     * Select payroll schedule
     * @param payrollScheduleOption
     */
    public static void selectPayrollSchedule(String payrollScheduleOption) {
        Select payrollScheduleDD = new Select(payrollScheduleDropDown);
        payrollScheduleDD.selectByVisibleText(payrollScheduleOption);
    }

    /**
     * Types offer letter signer name in Offer letter signer name text box
     * @param offerLetterSignerName
     */
    public static void typeOfferLetterSignerName(String offerLetterSignerName) {
        SeleniumTest.clearAndSetText(offerLetterSignerNameTextBox, offerLetterSignerName, true);
    }

    /**
     * Type offer letter signer title in Offer Letter Signer Title text box
     * @param offerLetterSignerTitle
     */
    public static void typeOfferLetterSignerTitle(String offerLetterSignerTitle) {
        SeleniumTest.clearAndSetText(offerLetterSignerTitleTextBox, offerLetterSignerTitle, true);
    }

    /**
     * Select add at will option
     * @param option
     */
    public static void selectAddAtWillClauseOption(String option) {
        if(option.equals("Yes")) {
            yesRadioButton.click();
        }
        else {
            noRadioButton.click();
        }
    }

    /**
     * Clicks on Exempt radio button.
     */
    public static void clickExemptRadioButton() {
        exemptRadioButton.click();
    }

    /**
     * Clicks on Exempt radio button.
     */
    public static void clickPositionStatusExempt() {
        exemptRadioButton.click();
    }

    /**
     * Clicks on Salaried non exempt radio button.
     */
    public static void clickSalariedNonExemptRadioButton() {
        salariedNonExemptRadioButton.click();
    }

    /**
     * Click on continue button to go to review order page
     * @return
     */
    public ReviewOrderPage clickContinue() {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }
}
