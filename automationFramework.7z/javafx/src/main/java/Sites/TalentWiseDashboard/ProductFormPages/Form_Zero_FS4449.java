package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 10/19/16.
 */
public class Form_Zero_FS4449 {

    static {
        PageFactory.initElements(Driver.getDriver(), Form_Zero_FS4449.class);
    }

    public static class EmployeeInformation {

        static {
            PageFactory.initElements(Driver.getDriver(), EmployeeInformation.class);
        }

        @FindBy(how = How.CLASS_NAME, using = "searchConfirmSummaryContainer")
        private static WebElement confirmSummaryContainer;

        public static String getEmailSubject() {
            return confirmSummaryContainer.findElements(By.className("item")).get(0).getText();
        }

        public static String getEmailSalutation() {
            return confirmSummaryContainer.findElements(By.className("item")).get(1).getText();
        }

        public static String getEmailText() {
            return confirmSummaryContainer.findElements(By.className("item")).get(2).getText();
        }

    }

    public static class I9RequiredInformation {

        static {
            PageFactory.initElements(Driver.getDriver(), I9RequiredInformation.class);
        }

        @FindBy(how = How.ID, using = "FormZero-11407_10")
        private static WebElement entityNameDropDown;

        public static void selectEntityName(EntityName name) {
            SeleniumTest.selectByVisibleTextFromDropDown(entityNameDropDown, name.text);
        }

        public enum EntityName {
            ROBERT_HALF_INTERNATIONAL("Robert Half International"),
            PROTIVITY_GOVERNMENT_SERVICES("Protivity Government Services");

            private final String text;

            EntityName(String text) {
                this.text = text;
            }

            @Override
            public String toString() {
                return text;
            }
        }
    }

    public class Navigation extends Sites.TalentWiseDashboard.ProductFormPages.Navigation {

    }
}
