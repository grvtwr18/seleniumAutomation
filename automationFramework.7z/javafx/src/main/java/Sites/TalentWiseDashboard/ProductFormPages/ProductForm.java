package Sites.TalentWiseDashboard.ProductFormPages;

import Utility.XMLResources.Element;

import java.util.List;

/**
 * Object to represent a product form.
 * @author eelefson
 */
public class ProductForm {
	private List<Element> elements;

	/**
	 * Fills the product form with data.
	 */
	public void fillProductForm() {
		for(Element i : elements) {
			i.createElement();
		}
	}
}