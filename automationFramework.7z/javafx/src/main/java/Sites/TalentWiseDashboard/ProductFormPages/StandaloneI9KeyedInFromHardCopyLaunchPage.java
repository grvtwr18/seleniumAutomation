package Sites.TalentWiseDashboard.ProductFormPages;


import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;


/**
 * Created by jgupta on 4/7/2016.
 */
public class StandaloneI9KeyedInFromHardCopyLaunchPage extends I9PaperLaunchPages {

    @FindBy(how = How.ID, using = "btnSubmit")
    public static WebElement continueButton;

    @FindBy(how = How.ID, using = "qLawfulPermanentResidentAlienID")
    private static WebElement lawfulPermanentResidentAlienNumberTextBox;

    @FindBy(how = How.ID, using = "nossnChk")
    public static WebElement noSSNCheckbox;

    @FindBy(how = How.ID, using = "qOverdueReason")
    private static WebElement overdueReasonDropDown;

    @FindBy(how = How.ID, using = "lblSSN")
    private static WebElement ssnLabel;

    static {
        PageFactory.initElements(Driver.getDriver(), StandaloneI9KeyedInFromHardCopyLaunchPage.class);
    }

    public static boolean isSSNRequired() {
        WaitUntil.waitUntil(() -> ssnLabel.isDisplayed(), NoSuchElementException.class);
        return ssnLabel.getText().endsWith("*");
    }

    /**
     * Fills the launch form.
     *
     * @param candidate the candidate
     * @param value     EmploymentEligibility
     * @param hireDate  date of Hire
     * @param reason    why
     */
    public static StandaloneI9KeyedInFromHardCopyLaunchPage fillLaunchForm(Candidate candidate,
                                                                           EmploymentEligibility value, LocalDate hireDate, String reason) {
        return fillLaunchForm(candidate, value, AlienAuthorizedToWork.USCIS, hireDate, reason);
    }

    public static StandaloneI9KeyedInFromHardCopyLaunchPage fillLaunchForm(Candidate candidate,
                                                                           EmploymentEligibility value, AlienAuthorizedToWork aawType, LocalDate hireDate, String reason) {

        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setAddressLine1(
                candidate.getAddressLine1().isEmpty() ? "12345 NE 15th place" : candidate.getAddressLine1());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1
                .setApartmentNumber(candidate.getApartmentNumber().isEmpty() ? "3456" : candidate.getApartmentNumber());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1
                .setCity(candidate.getCity().isEmpty() ? "Bellevue" : candidate.getCity());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1
                .selectState(candidate.getState().isEmpty() ? "Washington" : candidate.getState());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1
                .setZipCode(candidate.getZip().isEmpty() ? "98007" : candidate.getZip());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setDOB(candidate.getDOB());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setSocialSecurityNumber(
                candidate.getSocialSecurityNumber().isEmpty() ? "888888888" : candidate.getSocialSecurityNumber());

        switch (value) {
            case NON_CITIZEN:
                StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseNonCitizenOfUnitedStates();
                break;
            case LAWFUL_RESIDENT:
                StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseLawfulPermanentResident();
                StandaloneI9KeyedInFromHardCopyLaunchPage.Section1
                        .setLprAlienNumber(candidate.getLawfulPermanentResidentAlienNumber());
                break;
            case ALIEN_AUTHORIZED_TO_WORK:
                StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseAlienAuthorizedToWork();
                switch (aawType) {
                    case I94:
                        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseAawByI94();
                        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setI94Number(candidate.getI94Number());
                        break;
                    case FOREIGNPASSPORT:
                        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseAawByForeignPassport();
                        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1
                                .setForeignPassportNumber(candidate.getForeignPassportNumber());
                        break;
                    case USCIS:
                    default:
                        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseAawByAlienNumber();
                        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1
                                .setAlienNumber(candidate.getLawfulPermanentResidentAlienNumber());
                        break;
                }
                break;
            case CITIZEN:
            default:
                StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseCitizenOfUnitedStates();
                break;
        }

        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setStartDateViaMonthDayYearDropDown(hireDate);
        SeleniumTest.waitMs(2000);
        if (LocalDate.now().isAfter(hireDate.plusDays(3))) {
            selectOverdueReason(reason);
        }
        return PageFactory.initElements(Driver.getDriver(), StandaloneI9KeyedInFromHardCopyLaunchPage.class);
    }


    /**
     * Select value from overdue reason drop down.
     *
     * @param reason the reason
     */
    //TODO:  Add an enumerator for the possible reasons
    public static void selectOverdueReason(String reason) {
        Select overdueReasonDD = new Select(overdueReasonDropDown);
        overdueReasonDD.selectByVisibleText(reason);
    }

    /**
     * Clicks on Continue button
     *
     * @param returnedClass Page object to return
     * @return Page Object
     */
    public static ProductFormPages clickContinueBtn(Class<? extends ProductFormPages> returnedClass) {
        WebElement theContinueButton = SeleniumTest.waitForElementToBeClickable(continueButton, 32);
        //Click on Continue button to go to next page.
        theContinueButton.click();

        return PageFactory.initElements(Driver.getDriver(), returnedClass);

    }

    /**
     * Fills the employee profile section
     *
     * @param candidate the candidate
     * @param hireDate  date of hire
     */
    public static void fillEmployeeProfileSection(Candidate candidate, LocalDate hireDate) {
        StandaloneI9KeyedInFromHardCopyLaunchPage.EmployeeProfile.setLastName(candidate.getLastName());
        StandaloneI9KeyedInFromHardCopyLaunchPage.EmployeeProfile.setFirstName(candidate.getFirstName());
        StandaloneI9KeyedInFromHardCopyLaunchPage.EmployeeProfile
                .setMiddleInitialOrName(candidate.getMiddleName().substring(0, 1));
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setAddressLine1(candidate.getAddressLine1());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setApartmentNumber(candidate.getApartmentNumber());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setCity(candidate.getCity());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.selectState(candidate.getState());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setZipCode(candidate.getZip());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setDOB(candidate.getDOB());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.setSocialSecurityNumber(candidate.getSocialSecurityNumber());
        StandaloneI9KeyedInFromHardCopyLaunchPage.Section1.chooseCitizenOfUnitedStates();

        I9LaunchPages.EmployeeProfile.setStartDateViaMonthDayYearDropDown(hireDate);
    }

    /**
     * Enum for Employment Eligibility
     */
    public enum EmploymentEligibility {
        CITIZEN, NON_CITIZEN, LAWFUL_RESIDENT, ALIEN_AUTHORIZED_TO_WORK
    }

    public enum AlienAuthorizedToWork {
        USCIS, FOREIGNPASSPORT, I94
    }
}
