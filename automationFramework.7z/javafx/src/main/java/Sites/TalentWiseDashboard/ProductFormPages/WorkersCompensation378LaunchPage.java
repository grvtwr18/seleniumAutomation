package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 4/21/2016.
 */
public class WorkersCompensation378LaunchPage extends ScreeningLaunchPage {
    /**
     * Selects workers' compensation state.
     * @param state State where the candidate worked
     * @return WorkersCompensation378LaunchPage
     */
    public static WorkersCompensation378LaunchPage selectState(String state) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.name("qs_Group64-0_1"), state);
        return PageFactory.initElements(Driver.getDriver(), WorkersCompensation378LaunchPage.class);
    }
}
