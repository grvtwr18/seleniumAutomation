package Sites.TalentWiseDashboard.ProductFormPages;

/**
 * Created by MNam on 2/23/2017.
 */
public class EmployeeVerificationInfo {
    public String Name;
    public String JobTitle;
    public String PhoneNumber;
    public String City;
    public String State;
    public String StartMonth;
    public String StartYear;
    public String EndMonth;
    public String EndYear;
    public String Reason;
    public EmployeeVerificationInfo(String name, String title, String phNo, String city, String state, String reason, String startMonth, String startYear) {
        Name = name;
        JobTitle = title;
        PhoneNumber = phNo;
        City = city;
        State = state;
        Reason = reason;
        StartMonth = startMonth;
        StartYear = startYear;
    }
}