package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.CustomerDashboardPages;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by abrackett on 1/16/17.
 */
public class CancelFormI9Page extends CustomerDashboardPages {

    @FindBy(how = How.ID, using = "cancelcategory")
    private static WebElement cancelDropDown;

    @FindBy(how = How.ID, using = "cancelEVerifyNote")
    private static WebElement cancelNoteBox;

    @FindBy(how = How.ID, using = "btnCancelEVerify")
    private static WebElement cancelFormI9Button;

    @FindBy(how = How.ID, using = "linkCloseCancelEVerify")
    private static WebElement closeButton;

    @FindBy(how = How.ID, using = "canceltechissue")
    private static WebElement technicalWhyDropDown;

    @FindBy(how = How.ID, using = "dp_terminationDate")
    private static WebElement terminationDate;

    static {
        PageFactory.initElements(Driver.getDriver(), CancelFormI9Page.class);
    }

    public static boolean onPage() {
        try {
            return ((EventFiringWebDriver)Driver.getDriver()).getWrappedDriver()
                    .findElement(By.id("linkCloseCancelEVerify")).isDisplayed();
        } catch (NoSuchElementException nse) {
            return false;
        }
    }

    public static void selectCancelReason(CancelReasons cancelReason) {
        SeleniumTest.selectByVisibleTextFromDropDown(cancelDropDown, cancelReason.toString());
        if (cancelReason == CancelReasons.TECHNICAL_PROBLEMS) {
            SeleniumTest.selectByVisibleTextFromDropDown(technicalWhyDropDown, "Other");
        }
    }

    public static void setCancelText(String text) {
        SeleniumTest.clearAndSetText(cancelNoteBox, text);
    }

    public static void clickCancelFormI9() {
        cancelFormI9Button.click();
        WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("divCancelEVerifyResult"))
                .isDisplayed(), NoSuchElementException.class);
    }

    public static void clickClose() {
        closeButton.click();
        // Works around the close button not closing the window in automation
        // This happens sometimes - not all the time.
        WindowManagement.switchToMainWindow();
        WindowManagement.closeAllOtherWindows();
    }

    public static void cancelI9InProgress(CancelReasons cancelChoice, String cancelText, LocalDate... terminationDate) {
        selectCancelReason(cancelChoice);
        setCancelText(cancelText);

        if (terminationDate != null && terminationDate.length == 1) {
            setTerminationDate(terminationDate[0]);
        }
        clickCancelFormI9();
        WaitUntil.waitUntil(()->
                        ((EventFiringWebDriver)Driver.getDriver())
                                .getWrappedDriver()
                                .findElement(
                                        By.xpath("//*[contains(text(),'Form I-9 successfully')]"))
                                .isDisplayed(),
                NoSuchElementException.class);
        clickClose();

    }
    
    public static void setTerminationDate(LocalDate terminationDate) {
        ((JavascriptExecutor) Driver.getDriver()).executeScript(
                "document.getElementById('dp_terminationDate').value = '"
                        + terminationDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))
                        + "';");
        ((JavascriptExecutor) Driver.getDriver()).executeScript(
                "document.getElementById('terminationDate').value = '"
                        + terminationDate.format(DateTimeFormatter.ofPattern("MM/dd/yy"))
                        + "';");
        ((JavascriptExecutor) Driver.getDriver()).executeScript(
                "showCancelI9Button(17);");

    }

    public enum CancelReasons {
        //TODO:  Add (Did not work for pay)
        CANDIDATE_NO_SHOW ("Candidate withdrew or no show (Did not work for pay) - Cancel"), //  (Did not work for pay)
        CANDIDATE_NO_SHOW_NO_PREFERENCE ("Candidate withdrew or no show (Did not work for pay)"),
        //TODO:  Add (Did work for pay)
        CANDIDATE_TERMINATED ("Candidate terminated (Did work for pay) - Close"), //  (Did work for pay)
        CANDIDATE_TERMINATED_NO_PREFERENCE ("Candidate terminated (Did work for pay)"),
        DUPLICATE_CANDIDATE ("Duplicate candidate or request. An I-9 already exists for this candidate."),
        INVALID_REQUEST ("Invalid request was created with incorrect workflow or invalid data. A new request will be assigned."),
        OTHER ("Other"),
        TECHNICAL_PROBLEMS ("Technical Problems");

        private final String text;

        CancelReasons(final String text) {
            this.text = text;
        }
        @Override
        public String toString() {
            return text;
        }
    }
}
