package Sites.TalentWiseDashboard.ProductFormPages;

/**
 * Created by abrackett on 5/10/17.
 * Launchform / Uberform Company Information Section
 */
public class CompanyInformationSection extends LaunchFormPages {

    /**
     * This class is a place holder for any elements that may appear
     * directly inside Company Information on Launch Pages
     * Sections which fall inside Company Information on Launch pages
     * Should extend this class
     */

}
