package Sites.TalentWiseDashboard.ProductFormPages;

/**
 * Created by abrackett on 4/9/2016.
 */
public class PaperI9LaunchPage extends ProductFormPages {
}
