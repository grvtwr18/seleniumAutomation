package Sites.TalentWiseDashboard.ProductFormPages;

import Data.locations.canada.CanadianProvinceTerritory;
import Data.locations.us.UsStateTerritory;
import Sites.CandidatePortal.Enums.Country;
import Sites.CandidatePortal.Enums.Month;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScreeningLaunchPageWithEmpVerif extends ScreeningLaunchPage {

    public enum TypeOfEmp {
        UNSELECTED("Select"),
        SELF_EMPLOYED("Self-employed"),
        EMPLOYED_SEASONALLY("Employed seasonally"),
        MILITARY("Military"),
        TEMP_OR_CONTRACTOR("Temp or contractor, assigned through an agency"),
        POLICTICAL_CAMPAIGN("Political campaign"),
        FAST_FOOD_CHAIN("Fast food/chain restaurant or franchise entity"),
        EMPLOYED_WITHIN_PERSONS_RESIDENCE("Employed within a person's residence"),
        EMPLOYEE_FOR_EMPLOYER_APPLYING_WITH("Employee for the employer I am applying with"),
        NONE_OF_THESE("None of these");

        private String value;

        TypeOfEmp(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static TypeOfEmp parse(String input) {
            for(TypeOfEmp typeOfEmp : values()) {
                if (typeOfEmp.getValue().equalsIgnoreCase(input)) {
                    return typeOfEmp;
                }
            }

            throw new IllegalArgumentException("No such Type of Employment exists for \"" + input + "\"");
        }
    }

    public enum ReasonForLeaving {
        STILL_EMPLOYED("Still Employed"),
        RESIGNED("Resigned"),
        TERMINATED("Terminated"),
        LAID_OFF("Laid Off"),
        OTHER("Other");

        private String value;

        ReasonForLeaving(String value) {
            this.value = value;
        }

        String getValue() {
            return value;
        }

        public static ReasonForLeaving parse(String input) {
            for(ReasonForLeaving reasonForLeaving : values()) {
                if (reasonForLeaving.getValue().equalsIgnoreCase(input)) {
                    return reasonForLeaving;
                }
            }

            throw new IllegalArgumentException("No such Reason For Leaving exists for \"" + input + "\"");
        }
    }

    public enum PermitContactEmployer {
        DO_NOT_CONTACT_EMPLOYER,
        YES_MAY_CONTACT_EMPLOYER;
    }

    public static class EmpVerifEntry {

        public static final int YEAR_NOT_SET = -1;

        public TypeOfEmp typeOfEmp;
        public String employerName;
        public String branchOrDivision;
        public String phoneNumber;
        public String address;
        public String city;
        public String county;
        public UsStateTerritory stateTerritory;
        public CanadianProvinceTerritory provinceTerritory;
        public String stateOrProvince;
        public Country country;
        public String jobTitle;
        public ReasonForLeaving reasonForLeaving;
        public PermitContactEmployer permitContactEmployer;
        public Month startMonth;
        public int startYear;
        public Month endMonth;
        public int endYear;
        public String additionalInfo;
        public boolean wasNameSameAsCurrent;
        public String firstName;
        public String lastName;
        public String salary;
        public String additionalCompensation;
        public String ssn;

        private EmpVerifEntry() {
            this.typeOfEmp = TypeOfEmp.UNSELECTED;
            this.employerName = "";
            this.branchOrDivision = "";
            this.phoneNumber = "";
            this.address = "";
            this.city = "";
            this.county = "";
            this.country = Country.SELECT_COUNTRY;
            this.stateTerritory = null;
            this.provinceTerritory = null;
            this.stateOrProvince = "";
            this.jobTitle = "";
            this.additionalInfo = "";
            this.permitContactEmployer = PermitContactEmployer.YES_MAY_CONTACT_EMPLOYER;
            this.salary = "";
            this.additionalCompensation = "";
        }

        public EmpVerifEntry(String employerName, String phoneNumber,
                             String city, String county, UsStateTerritory stateTerritory,
                             String jobTitle, String additionalInfo) {
            this();
            this.employerName = employerName;
            this.phoneNumber = phoneNumber;
            this.city = city;
            this.county = county;
            this.stateTerritory = stateTerritory;
            this.stateOrProvince = this.stateTerritory.getFullName();
            this.country = Country.UNITED_STATES;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }

        public EmpVerifEntry(String employerName, String phoneNumber,
                             String city, String county, CanadianProvinceTerritory provinceTerritory,
                             String jobTitle, String additionalInfo) {

            this();
            this.employerName = employerName;
            this.phoneNumber = phoneNumber;
            this.city = city;
            this.county = county;
            this.provinceTerritory = provinceTerritory;
            this.stateOrProvince = this.provinceTerritory.getFullName();
            this.country = Country.CANADA;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }
        public EmpVerifEntry(String employerName,String branchOrDivision,String address, String phoneNumber,
                             String city, String county, CanadianProvinceTerritory provinceTerritory,
                             String jobTitle, String additionalInfo) {
            this();
            this.employerName = employerName;
            this.branchOrDivision = branchOrDivision;
            this.address = address;
            this.phoneNumber = phoneNumber;
            this.city = city;
            this.county = county;
            this.provinceTerritory = provinceTerritory;
            this.stateOrProvince = this.provinceTerritory.getFullName();
            this.country = Country.CANADA;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }
        public EmpVerifEntry(String employerName,String branchOrDivision, String phoneNumber,CanadianProvinceTerritory provinceTerritory,String address,
                             String city,
                             String jobTitle){
            this();
            this.employerName = employerName;
            this.branchOrDivision = branchOrDivision;
            this.phoneNumber = phoneNumber;
            this.provinceTerritory = provinceTerritory;
            this.stateOrProvince = this.provinceTerritory.getFullName();
            this.address = address;
            this.city = city;
            this.jobTitle = jobTitle;
        }

        public EmpVerifEntry(String employerName, String phoneNumber,
                             String city, String stateOrProvince, Country country,
                             String jobTitle, String additionalInfo) {

            this();
            this.employerName = employerName;
            this.phoneNumber = phoneNumber;
            this.city = city;
            this.stateOrProvince = stateOrProvince;
            this.country = country;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }
        public EmpVerifEntry(String employerName, String branchOrDivision ,String phoneNumber,String address,
                             String city, String stateOrProvince, Country country,
                             String jobTitle, String additionalInfo) {

            this();
            this.employerName = employerName;
            this.branchOrDivision = branchOrDivision;
            this.phoneNumber = phoneNumber;
            this.address = address;
            this.city = city;
            this.stateOrProvince = stateOrProvince;
            this.country = country;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }
        public EmpVerifEntry(String employerName, String branchOrDivision ,String phoneNumber,String address,
                             String city,String stateOrProvince,  Country country,
                             String jobTitle) {
            this();
            this.employerName = employerName;
            this.branchOrDivision = branchOrDivision;
            this.phoneNumber = phoneNumber;
            this.address = address;
            this.city = city;
            this.stateOrProvince = stateOrProvince;
            this.country = country;
            this.jobTitle = jobTitle;
        }
        public EmpVerifEntry(String employerName ,Country country ,String address,
                             String city, String stateOrProvince,String phoneNumber,
                             String jobTitle, String additionalInfo) {

            this();
            this.employerName = employerName;
            this.country = country;
            this.address = address;
            this.city = city;
            this.stateOrProvince = stateOrProvince;
            this.phoneNumber = phoneNumber;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }
        public EmpVerifEntry(String employerName, String branchOrDivision ,Country country ,String address,
                             String city, String stateOrProvince,String phoneNumber,
                             String jobTitle, String additionalInfo) {

            this();
            this.employerName = employerName;
            this.branchOrDivision = branchOrDivision;
            this.country = country;
            this.address = address;
            this.city = city;
            this.stateOrProvince = stateOrProvince;
            this.phoneNumber = phoneNumber;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }
        public EmpVerifEntry(String employerName,String phoneNumber, Country country,String city,String stateOrProvince,String jobTitle) {

            this();
            this.employerName = employerName;
            this.phoneNumber = phoneNumber;
            this.country = country;
            this.city = city;
            this.stateOrProvince = stateOrProvince;
            this.jobTitle = jobTitle;

        }
        public EmpVerifEntry(String employerName,String phoneNumber,Country country ,String city,String stateOrProvince,
                             String jobTitle, String additionalInfo) {

            this();
            this.employerName = employerName;
            this.phoneNumber = phoneNumber;
            this.country = country;
            this.city = city;
            this.stateOrProvince = stateOrProvince;
            this.jobTitle = jobTitle;
            this.additionalInfo = additionalInfo;
        }

        public EmpVerifEntry(String employerName) {
            this();
            this.employerName = employerName;
        }

        public EmpVerifEntry setTypeOfEmp(TypeOfEmp typeOfEmp) {
            this.typeOfEmp = typeOfEmp;
            return this;
        }

        public EmpVerifEntry setStillEmployed(PermitContactEmployer permitContactEmployer,
                                              Month startMonth, int startYear) {

            this.reasonForLeaving = ReasonForLeaving.STILL_EMPLOYED;
            this.permitContactEmployer = permitContactEmployer;
            this.startMonth = startMonth;
            this.startYear = startYear;
            this.endMonth = null;
            this.endYear = YEAR_NOT_SET;

            return this;
        }

        public EmpVerifEntry setStillEmployed(PermitContactEmployer permitContactEmployer,
                                              LocalDate startDate) {

            return setStillEmployed(permitContactEmployer, Month.from(startDate.getMonth()), startDate.getYear());
        }

        public EmpVerifEntry setReasonForLeaving(ReasonForLeaving reasonForLeaving,
                                                 Month startMonth, int startYear,
                                                 Month endMonth, int endYear) {

            // Should call setStillEmployed instead of setReasonForLeaving in the following case ...
            assert(ReasonForLeaving.STILL_EMPLOYED != reasonForLeaving);
            this.reasonForLeaving = reasonForLeaving;
            this.startMonth = startMonth;
            this.startYear = startYear;
            this.endMonth = endMonth;
            this.endYear = endYear;

            return this;
        }

        public EmpVerifEntry setReasonForLeaving(ReasonForLeaving reasonForLeaving,
                                                 LocalDate startDate, LocalDate endDate) {

            return setReasonForLeaving(reasonForLeaving,
                    Month.from(startDate.getMonth()), startDate.getYear(),
                    Month.from(endDate.getMonth()), endDate.getYear());
        }

        public EmpVerifEntry setSalaryAndAdditionalCompensation(String salary, String additionalCompensation) {
            this.salary = salary;
            this.additionalCompensation = additionalCompensation;
            return this;
        }

        public LocalDate getStartDate() {
            return LocalDate.of(startYear, startMonth.numeric(), 1);
        }

        public LocalDate getEndDate() {
            return LocalDate.of(endYear, endMonth.numeric(), 1);
        }

        public EmpVerifEntry setSameAsCurrentNameWhileEmployed() {
            this.wasNameSameAsCurrent = true;
            this.firstName = null;
            this.lastName = null;

            return this;
        }

        public EmpVerifEntry setDifferentNameWhileEmployed(String firstName, String lastName) {
            this.wasNameSameAsCurrent = false;
            this.firstName = firstName;
            this.lastName = lastName;

            return this;
        }

        public EmpVerifEntry setAddress(String address) {
            this.address = address;
            return this;
        }

        public EmpVerifEntry setBranchOrDivision(String branchOrDivision) {
            this.branchOrDivision = branchOrDivision;
            return this;
        }

        @Override
        public String toString() {
            if (ReasonForLeaving.STILL_EMPLOYED == reasonForLeaving) {
                return String.format("Employed at \"%s\" from \"%s, %d\" to Current", employerName,
                        startMonth.toString(), startYear);
            } else {
                return String.format("Employed at \"%s\" from \"%s, %d\" to \"%s, %d\"", employerName,
                        startMonth.toString(), startYear, endMonth.toString(), endYear);
            }
        }
    }

    static {
        PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPageWithEmpVerif.class);
    }

    // This number seems to change from one Screening Launch Page to the next.
    private static int groupId = 0; // Call discoverAndSetEmpGroupId() to set this when the page shows.

    public static int discoverAndSetEmpGroupId() {
        List<WebElement> employerNameElements = Driver.getDriver().findElements(
                By.xpath("//input[(@id[starts-with(., 'qcn_Group')]) or (@name[starts-with(., 'qcn_Group')])]"));

        if (1 != employerNameElements.size()) {
            throw new InvalidElementStateException("ScreeningLaunchPage appears to have " + employerNameElements.size()
                    + " Employer Name text-boxes, when only 1 should show as discoverAndSetEmpGroupId() is called.");
        }

        String hasGroupId = employerNameElements.get(0).getAttribute("id");

        if ((null == hasGroupId) || hasGroupId.isEmpty()) {
            hasGroupId = employerNameElements.get(0).getAttribute("name");
        }

        Pattern pattern = Pattern.compile("qcn_Group(\\d+)");
        Matcher matcher = pattern.matcher(hasGroupId);
        if(!matcher.find()) {
            throw new InvalidSelectorException("Control with ID/name didn't follow expected regex pattern \"qcn_Group(\\d+)\" : " + hasGroupId);
        }
        hasGroupId = matcher.group(1);
        ScreeningLaunchPageWithEmpVerif.groupId = Integer.parseInt(hasGroupId);

        return ScreeningLaunchPageWithEmpVerif.groupId;
    }

    public static boolean isAddEmpVerifLinkVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("spanAdd_Group" + groupId + "-0"));
    }


    public static void clickAddEmpVerifLink() {
        SeleniumTest.click(By.id("spanAdd_Group" + groupId + "-0"));
    }

    private static By getEmpVerifLocator(String preName, int index) {
        final String idOrName = preName + "_Group" + groupId + "-0_" + index;
        return By.xpath("//*[(@id='" + idOrName + "') or (@name = '" + idOrName + "')]");
    }

    public static boolean isTypeOfEmpDropDownVisible(int index) {
        return SeleniumTest.isElementVisibleNoWaiting(getEmpVerifLocator("qemptype", index));
    }

    public static void selectTypeOfEmpFromDropDown(int index, TypeOfEmp typeOfEmp) {
        SeleniumTest.selectByVisibleTextFromDropDown(
                getEmpVerifLocator("qemptype", index),
                typeOfEmp.getValue());
    }

    public static TypeOfEmp getTypeOfEmpFromDropDown(int index) {
        String typeOfEmp = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qemptype", index));
        return TypeOfEmp.parse(typeOfEmp);
    }

    public static void setEmployerName(int index, String employerName) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qcn", index), employerName);
    }

    public static String getEmployerName(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qcn", index));
    }

    public static boolean isBranchOrDivisionVisible(int index) {
        return SeleniumTest.isElementVisibleNoWaiting(getEmpVerifLocator("qcbranch", index));
    }

    public static void setBranchOrDivision(int index, String branchOrDivision) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qcbranch", index), branchOrDivision);
    }

    public static String getBranchOrDivision(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qcbranch", index));
    }

    public static void setPhoneNumber(int index, String phoneNumber) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qcp", index), phoneNumber);
    }

    public static String getPhoneNumber(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qcp", index));
    }

    public static void setCountryRegion(int index, Country country) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qo", index), country.toString());
    }

    public static Country getCountryRegion(int index) {
        String country = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qo", index));
        return Country.parse(country);
    }

    public static boolean isCountryRegionVisible(int index) {
        return SeleniumTest.isElementVisibleNoWaiting(getEmpVerifLocator("qo", index));
    }

    public static boolean isAddressVisible(int index) {
        return SeleniumTest.isElementVisibleNoWaiting(getEmpVerifLocator("qca", index));
    }

    public static void setAddress(int index, String address) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qca", index), address);
    }

    public static String getAddress(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qca", index));
    }

    public static void setCity(int index, String city) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qcc", index), city);
    }

    public static String getCity(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qcc", index));
    }

    public static void selectStateTerritoryDropDown(int index, UsStateTerritory stateTerritory) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qcs", index), stateTerritory.getFullName());
    }

    public static UsStateTerritory getStateTerritoryFromDropDown(int index) {
        String stateTerritory = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qcs", index));
        return UsStateTerritory.parse(stateTerritory);
    }

    public static void selectProvinceTerritoryDropDown(int index, CanadianProvinceTerritory provinceTerritory) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qcs", index), provinceTerritory.getFullName());
    }

    public static CanadianProvinceTerritory getProvinceTerritoryFromDropDown(int index) {
        String provinceTerritory = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qcs", index));
        return CanadianProvinceTerritory.parse(provinceTerritory);
    }

    public static void selectStateOrProvinceFromDropDown(int index, String stateProvinceOrRegion) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qcs", index), stateProvinceOrRegion);
    }

    public static String getStateOrProvinceFromDropDown(int index) {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qcs", index));
    }

    public static void setJobTitle(int index, String jobTitle) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qjt", index), jobTitle);
    }

    public static String getJobTitle(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qjt", index));
    }

    public static void selectReasonForLeavingDropDown(int index, ReasonForLeaving reasonForLeaving) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qjrfl", index), reasonForLeaving.getValue());
    }

    public static ReasonForLeaving getReasonForLeavingFromDropDown(int index) {
        String reasonForLeaving = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qjrfl", index));
        return ReasonForLeaving.parse(reasonForLeaving);
    }

    public static void checkDoNotContactEmployer(int index) {
        SeleniumTest.check(getEmpVerifLocator("qnocontact", index));
    }

    public static void unCheckDoNotContactEmployer(int index) {
        SeleniumTest.unCheck(getEmpVerifLocator("qnocontact", index));
    }

    public static boolean isDoNotContactEmployerChecked(int index) {
        return SeleniumTest.isCheckboxChecked(getEmpVerifLocator("qnocontact", index));
    }

    public static void selectStartMonthDropDown(int index, Month shortMonth) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qjstmm", index),
                shortMonth.abbreviation());
    }

    public static Month getStartMonthFromDropDown(int index) {
        return Month.parse(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qjstmm", index)));
    }

    public static void selectStartYearDropDown(int index, int year) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qjstyy", index), "" + year);
    }

    public static int getStartYearFromDropDown(int index) {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qjstyy", index)));
    }

    public static void selectEndMonthDropDown(int index, Month month) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qjendmm", index), month.abbreviation());
    }

    public static Month getEndMonthFromDropDown(int index) {
        return Month.parse(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qjendmm", index)));
    }

    public static void selectEndYearDropDown(int index, int year) {
        SeleniumTest.selectByVisibleTextFromDropDown(getEmpVerifLocator("qjendyy", index),"" + year);
    }

    public static int getEndYearFromDropDown(int index) {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(getEmpVerifLocator("qjendyy", index)));
    }

    public static void setAdditionalInfo(int index, String additionalInfo) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qaddinf", index), additionalInfo);
    }

    public static String getAdditionalInfo(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qaddinf", index));
    }

    public static void checkNameSameAsCurrent(int index) {
        SeleniumTest.check(getEmpVerifLocator("sameascurrent", index));
    }

    public static void unCheckNameSameAsCurrent(int index) {
        SeleniumTest.unCheck(getEmpVerifLocator("sameascurrent", index));
    }

    public static boolean isNameSameAsCurrentChecked(int index) {
        return SeleniumTest.isCheckboxChecked(getEmpVerifLocator("sameascurrent", index));
    }

    public static void setFirstName(int index, String firstName) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qfempalias", index), firstName);
    }

    public static String getFirstName(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qfempalias", index));
    }

    public static void setLastName(int index, String lastName) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qnempalias", index), lastName);
    }

    public static String getLastName(int index) {
        return SeleniumTest.getTextByLocator(getEmpVerifLocator("qnempalias", index));
    }

    public static boolean isNoMoreEmpHistCheckBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("nomore_Group" + groupId + "-0"));
    }

    public static void checkNoMoreEmpHistCheckBox() {
        SeleniumTest.check(By.id("nomore_Group" + groupId + "-0"));
    }

    public static void unCheckNoMoreEmpHistCheckBox() {
        SeleniumTest.unCheck(By.id("nomore_Group" + groupId + "-0"));
    }

    public static void setEmpVerif(int index, EmpVerifEntry empVerifEntry) {

        if ((null != empVerifEntry.typeOfEmp) && isTypeOfEmpDropDownVisible(index)) {
            selectTypeOfEmpFromDropDown(index, empVerifEntry.typeOfEmp);
        }

        setEmployerName(index, empVerifEntry.employerName);

        if ((null != empVerifEntry.branchOrDivision) && isBranchOrDivisionVisible(index)) {
            setBranchOrDivision(index, empVerifEntry.branchOrDivision);
        }

        setPhoneNumber(index, empVerifEntry.phoneNumber);

        if (null != empVerifEntry.stateTerritory) {
            if (isCountryRegionVisible(index)) {
                setCountryRegion(index, Country.UNITED_STATES);
            }
            selectStateTerritoryDropDown(index, empVerifEntry.stateTerritory);
            if (null != empVerifEntry.ssn) {
                setSSN(index, empVerifEntry.ssn);
            }
        } else if (null != empVerifEntry.provinceTerritory) {
            setCountryRegion(index, Country.CANADA);
            WaitUntil.waitUntil(() -> {
                // Takes a little while for the provinces to fill up after selecting Country/Region = Canada ...
                selectProvinceTerritoryDropDown(index, empVerifEntry.provinceTerritory);
                return true;
            }, StaleElementReferenceException.class);
        } else {
            setCountryRegion(index, empVerifEntry.country);
            WaitUntil.waitUntil(() -> {
                // May take a little while for province/territory fill up after selecting Country/Region.
                selectStateOrProvinceFromDropDown(index, empVerifEntry.stateOrProvince);
                return true;
            }, StaleElementReferenceException.class);
        }

        if ((null != empVerifEntry.address) && isAddressVisible(index)) {
            setAddress(index, empVerifEntry.address);
        }

        setCity(index, empVerifEntry.city);
        setJobTitle(index, empVerifEntry.jobTitle);

        if ((null != empVerifEntry.salary) && isBaseSalaryInputVisible(index)) {
            setBaseSalary(index, empVerifEntry.salary);
        }
        if ((null != empVerifEntry.additionalCompensation) && isAdditionalCompensationInputVisible(index)) {
            setAdditionalCompensation(index, empVerifEntry.additionalCompensation);
        }

        selectReasonForLeavingDropDown(index, empVerifEntry.reasonForLeaving);
        selectStartMonthDropDown(index, empVerifEntry.startMonth);
        selectStartYearDropDown(index, empVerifEntry.startYear);

        if (ReasonForLeaving.STILL_EMPLOYED == empVerifEntry.reasonForLeaving) {
            if (PermitContactEmployer.DO_NOT_CONTACT_EMPLOYER == empVerifEntry.permitContactEmployer) {
                checkDoNotContactEmployer(index);
            } else {
                unCheckDoNotContactEmployer(index);
            }
        } else {
            selectEndMonthDropDown(index, empVerifEntry.endMonth);
            selectEndYearDropDown(index, empVerifEntry.endYear);
        }

        setAdditionalInfo(index, empVerifEntry.additionalInfo);

        if (empVerifEntry.wasNameSameAsCurrent) {
            checkNameSameAsCurrent(index);
        } else {
            unCheckNameSameAsCurrent(index);
            setFirstName(index, empVerifEntry.firstName);
            setLastName(index, empVerifEntry.lastName);
        }
    }

    public static EmpVerifEntry getEmpVerifEntry(int index) {
        EmpVerifEntry empVerifEntry = null;

        UsStateTerritory stateTerritory = getStateTerritoryFromDropDown(index);

        if (null != stateTerritory) {
            empVerifEntry = new EmpVerifEntry(
                    getEmployerName(index),
                    getPhoneNumber(index),
                    getCity(index),
                    null,
                    getStateTerritoryFromDropDown(index),
                    getJobTitle(index),
                    getAdditionalInfo(index));
        } else {

            Country country = getCountryRegion(index);
            if (Country.CANADA == country) {
                empVerifEntry = new EmpVerifEntry(
                        getEmployerName(index),
                        getPhoneNumber(index),
                        getCity(index),
                        null,
                        getProvinceTerritoryFromDropDown(index),
                        getJobTitle(index),
                        getAdditionalInfo(index));
            } else {
                empVerifEntry = new EmpVerifEntry(
                        getEmployerName(index),
                        getPhoneNumber(index),
                        getCity(index),
                        getStateOrProvinceFromDropDown(index),
                        getCountryRegion(index),
                        getJobTitle(index),
                        getAdditionalInfo(index));
            }
        }

        if (isTypeOfEmpDropDownVisible(index)) {
            empVerifEntry.setTypeOfEmp(getTypeOfEmpFromDropDown(index));
        }

        if (isBranchOrDivisionVisible(index)) {
            empVerifEntry.setBranchOrDivision(getBranchOrDivision(index));
        }

        if (isAddressVisible(index)) {
            empVerifEntry.setAddress(getAddress(index));
        }

        ReasonForLeaving reasonForLeaving = getReasonForLeavingFromDropDown(index);

        switch (reasonForLeaving) {
            case STILL_EMPLOYED:
                empVerifEntry.setStillEmployed(
                        isDoNotContactEmployerChecked(index) ?
                                PermitContactEmployer.DO_NOT_CONTACT_EMPLOYER : PermitContactEmployer.YES_MAY_CONTACT_EMPLOYER,
                        getStartMonthFromDropDown(index),
                        getStartYearFromDropDown(index));
                break;
            case RESIGNED:
            case TERMINATED:
            case LAID_OFF:
            case OTHER:
                empVerifEntry.setReasonForLeaving(
                        reasonForLeaving,
                        getStartMonthFromDropDown(index),
                        getStartYearFromDropDown(index),
                        getEndMonthFromDropDown(index),
                        getEndYearFromDropDown(index));
                break;
            default:
                throw new IllegalArgumentException("Unexpected Reason for Leaving: " + reasonForLeaving);
        }

        empVerifEntry.wasNameSameAsCurrent = isNameSameAsCurrentChecked(index);
        empVerifEntry.firstName = getFirstName(index);
        empVerifEntry.lastName = getLastName(index);

        return empVerifEntry;
    }

    public static void setBaseSalary(int index, String baseSalary) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qsalary", index), baseSalary);
    }

    public static boolean isBaseSalaryInputVisible(int index) {
        return SeleniumTest.isElementVisibleNoWaiting(getEmpVerifLocator("qsalary", index));
    }

    public static void setAdditionalCompensation(int index, String baseSalary) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qsalaryadd", index), baseSalary);
    }

    public static boolean isAdditionalCompensationInputVisible(int index) {
        return SeleniumTest.isElementVisibleNoWaiting(getEmpVerifLocator("qsalaryadd", index));
    }

    public static void setSSN(int index, String ssn) {
        SeleniumTest.clearAndSetText(getEmpVerifLocator("qssn", index), ssn);
    }

    public static String getFormError(int index) {
        return SeleniumTest.getText(Driver.getDriver().findElement(getEmpVerifLocator("div", index)).findElement(By.className("subformerror")));
    }
}
