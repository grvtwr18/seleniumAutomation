package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import static TWFramework.SeleniumTest.check;
import static TWFramework.SeleniumTest.clearAndSetText;
import static TWFramework.SeleniumTest.waitForElement;
import TWFramework.WaitUntil;
import Utility.Onboarding.OnboardingUtility;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.time.LocalDate;

/**
 * Created by jgupta on 4/8/2016.
 */
public class StandaloneI9_788_ReverifyLaunchPage extends I9ReverifyLaunchPages {

    @FindBy(how = How.ID, using = "nossnChk") private static WebElement noSSNCheckbox;

    @FindBy(how = How.NAME, using = "qOrigApplicantID") private static WebElement previousReportID;

    @FindBy(how = How.NAME, using = "qnewlastname") private static WebElement newLastNameTextBox;

    @FindBy(how = How.NAME, using = "qnewfirstname") private static WebElement newFirstNameTextBox;

    @FindBy(how = How.ID, using = "qverifiergroupid") private static WebElement verifierGroupBox;

    @FindBy(how = How.ID, using = "qverifierid") private static WebElement verifierBox;

    @FindBy(how = How.ID, using = "qnewmi") private static WebElement newMiddleInitialTextBox;

    @FindBy(how = How.ID, using = "qrehiremonth") private static WebElement rehireMonthDropdown;

    @FindBy(how = How.ID, using = "qrehireday") private static WebElement rehireDayDropdown;

    @FindBy(how = How.ID, using = "qrehireyear") private static WebElement rehireYearDropdown;

    @FindBy(how = How.ID, using = "qdoctype") private static WebElement documentDropdown;

    @FindBy(how = How.NAME, using = "qdocno") private static WebElement documentNumberTextBox;

    @FindBy(how = How.NAME, using = "qexpmonth") private static WebElement expiryDateMonthDropdown;

    @FindBy(how = How.NAME, using = "qexpday") private static WebElement expiryDateDateDropdown;

    @FindBy(how = How.NAME, using = "qexpyear") private static WebElement expiryDateYearDropdown;

    @FindBy(how = How.NAME, using = "fI9") private static WebElement browseButton;

    @FindBy(how = How.CSS, using = "input[type='file']") private static WebElement filePathBox;

    @FindBy(how = How.ID, using = "qcertify") private static WebElement affirmationCheckBox;

    @FindBy(how = How.XPATH, using = "//textarea[@id='qAdditionalInformation']")
    private static WebElement additionalInformationTextArea;

    private static final Logger logger = LoggerFactory.getLogger("788_ReverifyLaunchPage");


    /**
     * Constructor
     */
    public StandaloneI9_788_ReverifyLaunchPage() {
        WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("qworkflow1"))
            .isDisplayed(), NoSuchElementException.class);
    }

    public static void selectVerifierGroup(String groupName) {
        SeleniumTest.selectByVisibleTextFromDropDown(verifierGroupBox, groupName);
    }

    /**
     * Select the assignee by visible text
     * @param assignee The visible text to select
     */
    public static void selectAssignee(String assignee) {
        SeleniumTest.selectByVisibleTextFromDropDown(verifierBox, assignee);
    }

    /**
     * Clicks on radio button corresponding to Reverification option.
     */
    public static StandaloneI9_788_ReverifyLaunchPage clickReverificationRadioButton() {
        logger.info("Click Reverify");
        WorkFlows.chooseReverificationRadioButton();
        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Click Update form
     *
     * @return
     */
    public static StandaloneI9_788_ReverifyLaunchPage clickUpdateFormI9RadioButton() {
        logger.info("Click Update Form I9");
        WorkFlows.chooseUpdateFormI9RadioButton();
        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Fill Update Form I9
     *
     * @param existingReports
     * @param fName
     * @param mName
     * @param lName
     * @param dDate
     * @param vGroup
     * @param verifier
     */
    public static void fillUpdateFormI9_Electronic_NameChange(Boolean existingReports, String fName,
        String mName, String lName, LocalDate dDate, String vGroup, String verifier) {

        clearAndSetText(EmployeeProfile.firstNameTextBox, fName);
        clearAndSetText(EmployeeProfile.middleInitialOrNameTextBox, mName);
        clearAndSetText(EmployeeProfile.lastNameTextBox, lName);

        EmployeeProfile.setReverificationDueDate(dDate);

        SeleniumTest
            .selectByVisibleTextFromDropDown(verifierGroupBox, vGroup);
        SeleniumTest
            .selectByVisibleTextFromDropDown(verifierBox, verifier);

        if (existingReports) {
            clickContinue(ProductFormErrorPage.class);
            ProductFormErrorPage.clickContinueButton(ReviewOrderPage.class);
        } else {
            clickContinue(ReviewOrderPage.class);
        }
    }

    /**
     * Fill Update I9 for Name Change
     *
     * @param existingReports
     * @param fName
     * @param mName
     * @param lName
     * @param newFirstName
     * @param newLastName
     * @param newMiddleInitial
     * @param file
     */
    public static void fillUpdateFormI9_Paper_NameChange(Boolean existingReports, String fName,
        String mName, String lName, String newFirstName, String newLastName,
        String newMiddleInitial, File file) {

        clearAndSetText(EmployeeProfile.firstNameTextBox, fName);
        clearAndSetText(EmployeeProfile.middleInitialOrNameTextBox, mName);
        clearAndSetText(EmployeeProfile.lastNameTextBox, lName);

        clearAndSetText(newFirstNameTextBox, newFirstName);
        clearAndSetText(newLastNameTextBox, newLastName);
        clearAndSetText(newMiddleInitialTextBox, newMiddleInitial);
        StandaloneI9_788_ReverifyLaunchPage.checkAffirmationCheckbox();
        uploadFile(file.getAbsolutePath());

        if (existingReports) {
            clickContinue(ProductFormErrorPage.class);
            ProductFormErrorPage.clickContinueButton(ReviewOrderPage.class);
        } else {
            clickContinue(ReviewOrderPage.class);
        }
    }

    /**
     * Fill Form I9 Section 1 Reverification
     *
     * @param candidate
     * @return
     */
    public static StandaloneI9_788_ReverifyLaunchPage fillFormI9Section1Reverification(
        Candidate candidate) {
        logger.info("Fill in Form I9 Section 1 Reverification");
        if (EmployeeProfile.lastNameTextBox.getText().isEmpty()) {
            clearAndSetText(EmployeeProfile.lastNameTextBox, candidate.getLastName());
        }
        if (EmployeeProfile.firstNameTextBox.getText().isEmpty()) {
            clearAndSetText(EmployeeProfile.firstNameTextBox, candidate.getFirstName());
        }
        if (EmployeeProfile.middleInitialOrNameTextBox.getText().isEmpty()) {
            clearAndSetText(EmployeeProfile.middleInitialOrNameTextBox, Character.toString(candidate.getMiddleName().charAt(0)));
        }
        if (I9LaunchPages.EmployeeProfile.ssnTextBox.getText().isEmpty()) {
            if (candidate.getSocialSecurityNumber().isEmpty()) {
                check(noSSNCheckbox);
            } else {
                clearAndSetText(I9LaunchPages.EmployeeProfile.ssnTextBox, candidate.getSocialSecurityNumber());
            }
        }
        if (previousReportID.getText().isEmpty()) {
            clearAndSetText(previousReportID, candidate.getReports().size() > 0 ?
                Integer.toString(candidate.getReports().get(0)) :
                "");
        }
        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Fills in Section 3 for Reverification ONLY
     *
     * @param document           The Document to choose from the list of documents that have expired
     * @param documentNumber     The document number of the corresponding document
     * @param documentExpiration The expiration date of the corresponding document
     * @param file               a File Object of the I9.pdf you intend to include.
     * @return
     */
    public static StandaloneI9_788_ReverifyLaunchPage fillFormI9Section3_PartC_Reverification(
        String document, String documentNumber, LocalDate documentExpiration, File file) {
        logger.info("Fill Form I9 Section 3 Part C Reverification");

        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(documentDropdown, document);
        SeleniumTest.waitForElementToBeClickable(documentNumberTextBox);
        clearAndSetText(documentNumberTextBox, documentNumber);

        check(affirmationCheckBox);

        SeleniumTest.selectShortMonthByVisibleText(expiryDateMonthDropdown, documentExpiration);

        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(expiryDateDateDropdown,
            Integer.toString(documentExpiration.getDayOfMonth())
        );

        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(expiryDateYearDropdown,
            Integer.toString(documentExpiration.getYear()));

        uploadFile(file.getAbsolutePath());

        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Fill Form I9 Section 3 Part A Name Change
     *
     * @param newLastName
     * @param newFirstName
     * @param newMiddleInitial
     * @return
     */
    public static StandaloneI9_788_ReverifyLaunchPage fillFormI9Section3_PartA_NameChange(
        String newLastName, String newFirstName, String newMiddleInitial) {
        logger.info("Fill Form I9 Section 3 Part A Name Change");
        clearAndSetText(newLastNameTextBox, newLastName);
        clearAndSetText(newMiddleInitialTextBox, newMiddleInitial);
        clearAndSetText(newFirstNameTextBox, newFirstName);
        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Fill Section 3 Part B Rehire
     *
     * @param date
     * @return
     */
    public static StandaloneI9_788_ReverifyLaunchPage fillFormI9Section3_PartB_ReHireDate(
        LocalDate date) {
        logger.info("Fill Form I9 Section 3 Part B Rehire");

        SeleniumTest.selectShortMonthByVisibleText(rehireMonthDropdown, date);
        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(rehireDayDropdown, Integer.toString
                (date
                                                                                              .getDayOfMonth())
        );
        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(rehireYearDropdown, Integer.toString
                (date
                                                                                              .getYear())
        );
        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Fill Section 3 Updating and Reverification
     *
     * @param newLastName
     * @param newFirstName
     * @param newMiddleInitial
     * @param rehireDateMonth
     * @param rehireDateDay
     * @param rehireDateYear
     * @param documentTitle
     * @param documentNumber
     * @param expirationMonth
     * @param expirationDay
     * @param expirationYear
     * @return
     */
    public static StandaloneI9_788_ReverifyLaunchPage fillFormI9Section3UpdatingAndReverification(
        String newLastName, String newFirstName, String newMiddleInitial, String rehireDateMonth,
        String rehireDateDay, String rehireDateYear, String documentTitle, String documentNumber,
        String expirationMonth, String expirationDay, String expirationYear) {
        logger.info("Fill Form I9 Section 3 Updating and Reverification");

        clearAndSetText(newLastNameTextBox, newLastName);
        clearAndSetText(newFirstNameTextBox, newFirstName);
        clearAndSetText(newMiddleInitialTextBox, newMiddleInitial);

        logger.info("Select rehire date");
        selectRehireDate(rehireDateMonth, rehireDateDay, rehireDateYear);

        logger.info("Select the document");
        selectDocumentTitle(documentTitle);
        SeleniumTest.waitForElementToBeClickable(documentNumberTextBox);
        waitForElement(expiryDateMonthDropdown);
        waitForElement(expiryDateDateDropdown);
        waitForElement(expiryDateYearDropdown);
        clearAndSetText(documentNumberTextBox, documentNumber);

        logger.info("Select document expiry date");
        selectExpirationDate(expirationMonth, expirationDay, expirationYear);

        logger.info("Check affirmation checkbox");
        checkAffirmationCheckbox();
        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Selects rehire date
     *
     * @param rehireDateMonth
     * @param rehireDateDay
     * @param rehireDateYear
     */
    private static void selectRehireDate(String rehireDateMonth, String rehireDateDay,
        String rehireDateYear) {

        SeleniumTest.selectShortMonthByVisibleText(rehireMonthDropdown, rehireDateMonth);

        Select dayDD = new Select(rehireDayDropdown);
        dayDD.selectByVisibleText(rehireDateDay);

        Select yearDD = new Select(rehireYearDropdown);
        yearDD.selectByVisibleText(rehireDateYear);
    }

    /**
     * Selects expiration date
     *
     * @param expiryDateMonth
     * @param expiryDateDay
     * @param expiryDateYear
     */
    private static void selectExpirationDate(String expiryDateMonth, String expiryDateDay,
        String expiryDateYear) {

        SeleniumTest.selectShortMonthByVisibleText(expiryDateMonthDropdown, expiryDateMonth);

        Select dayDD = new Select(expiryDateDateDropdown);
        dayDD.selectByVisibleText(expiryDateDay);

        Select yearDD = new Select(expiryDateYearDropdown);
        yearDD.selectByVisibleText(expiryDateYear);
    }

    /**
     * Select document title.
     *
     * @param title
     */
    private static void selectDocumentTitle(String title) {
        Select documentTitleDD = new Select(documentDropdown);
        documentTitleDD.selectByVisibleText(title);
    }

    /**
     * Uploads file.
     *
     * @param filePath
     * @return
     */
    public static StandaloneI9_788_ReverifyLaunchPage uploadFile(String filePath) {
        logger.info("File Path Supplied for Upload file:  {}", filePath);

        Driver.getDriver().findElement(By.id("qcertify")).sendKeys(Keys.TAB);
        // removing problematic affirmationCheckbox reference for now.
        //affirmationCheckBox.sendKeys(Keys.TAB);
        Driver.getDriver().switchTo().activeElement().sendKeys(filePath);
        Driver.getDriver().switchTo().defaultContent();
        return PageFactory
            .initElements(Driver.getDriver(), StandaloneI9_788_ReverifyLaunchPage.class);
    }

    /**
     * Checks the affirmation checkbox
     */
    public static void checkAffirmationCheckbox() {
        // repeatedly tried to use the @FindBy to use affirmationcheckbox directly but it simply
        // wasn't working - reverted to a direct find element to make sure the box gets checked.
        check(Driver.getDriver().findElement(By.id("qcertify")));
    }

    /**
     * Click continue
     *
     * @param returnedClass
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static String getAdditionalInformation() {
        return additionalInformationTextArea.getAttribute("value");
    }

    public static void setAdditionalInformationTextArea(String text) {
        SeleniumTest.clearAndSetText(additionalInformationTextArea, text);
    }

    public static boolean isAdditionalInformationLocationAboveICertify() {
        return additionalInformationTextArea.getLocation().getY() <
                Driver.getDriver().findElement(By.id("qcertify")).getLocation().getY();
    }
    /**
     * Enum of List A Documents
     */
    public enum DocumentTitle {
        USPASSPORT("U.S. Passport"),
        USPASSPORTCARD("U.S. Passport Card"),
        PERMANENTRESIDENTCARD("Permanent Resident Card (Form I-551)"),
        ALIENREGISTRATIONRECEIPTCARD("Alien Registration Receipt Card (Form I-551)"),
        EMPLOYMENTAUTHORIZATIONDOCUMENT("Employment Authorization Document (Form I-766)"),
        FOREIGNPASSPORTWITHI_94_AFORM("Unexpired Foreign Passport with Form I-94 or Form I-94A"),
        FSMPASSPORTWITHI_94_AFORM("FSM Passport with Form I-94 or Form I-94A"),
        RMIPASSPORTWITHI_94_AFORM("RMI Passport with Form I-94 or Form I-94A"),
        I_94_AFORMWITHREFUGEESTAMP("Form I-94 or Form I-94A with Unexpired Refugee Stamp"),
        I_20("I-20"),
        DS_2019("DS-2019");

        private final String text;

        DocumentTitle(final String text) {
            this.text = text;
        }

        @Override public String toString() {
            return text;
        }
    }
}
