package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by jgupta on 4/27/2016.
 */
public class SelectAKAsPage extends ProductFormPages {
    @FindBy(how = How.ID, using = "btnSubmit")
    public static WebElement continueButton;

    public static final String akaCheckboxesList = ".//*[contains(@class, 'B1')]/input[@name='aka[]']";

    private static String checkboxXpath = ".//*[@class='B1']/input[@name='aka[]']";

    static {
        PageFactory.initElements(Driver.getDriver(), SelectAKAsPage.class);
    }

    /**
     * Clicks on Continue button
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     *
     * @param index
     */
    public static void checkAKACheckbox(int index) {
        List<WebElement> elements = SeleniumTest.getAllElementsByXpath(checkboxXpath);

        WebElement element = elements.get(index);
        SeleniumTest.click(element);
    }

    /**
     * The passed bool is the expected, the return bool is pass or fail of expectation. All or nothing.
     *
     * @param checked: (boolean) true all are checked || false all are unchecked
     * @return: (boolean) true if expected passes || false if expected fails
     */
    public static boolean validateAllAutoAKAChecked(boolean checked) {
        List<WebElement> elements;

        elements = Driver.getDriver().findElements(By.xpath(akaCheckboxesList));

        for (WebElement myElement : elements) {
            if (checked) {
                if (!myElement.isSelected()) {
                    return false;
                }
            }
            else {
                if (myElement.isSelected()) {
                    return false;
                }
            }
        }

        // Didn't find any unexpected isSelected() return success.
        return true;
    }
}
