package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

/**
 * Created by abrackett on 12/17/2015.
 */
public class FS440LaunchPage extends ProductFormPages{
    private final String task1DueDateBoxLocatorString = "qduedate1";
    @FindBy(how = How.ID, using = "dp_" + task1DueDateBoxLocatorString)
    private WebElement task1DueDateBox;

    private final String task2DueDateBoxLocatorString = "qduedate2";
    @FindBy(how = How.ID, using = "dp_" + task2DueDateBoxLocatorString)
    private WebElement task2DueDateBox;

    private final String task1GroupID = "qverifiergroupid1";
    By task1GroupLocator = By.id(task1GroupID);
    @FindBy(how = How.ID, using = task1GroupID)
    private WebElement task1GroupDropdown;

    private final String task1VerifierID = "qverifierid1";
    By task1VerifierLocator = By.id(task1VerifierID);
    @FindBy(how = How.ID, using = task1VerifierID)
    private WebElement task1VerifierDropdown;

    @FindBy(how = How.ID, using = "btnSubmit")
    private WebElement continueButton;

    /**
     * Sets the Task 1 Due Date
     * @param lDate
     * @return
     */
    public FS440LaunchPage setTask1DueDate(LocalDate lDate) {
        if(Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds
                    .setCalendarControl_uu_Dash_MM_Dash_dd(lDate, "dp_" + task1DueDateBoxLocatorString, task1DueDateBoxLocatorString);
        }
        else {
            SeleniumTest.clearAndSetText(task1DueDateBox, lDate.format(LocaleHelper.getDateFormatShortDateSlash_uuuu()));
        }
        return this;
    }

    /**
     * Sets the Task 2 Due Date
     * @param lDate
     * @return
     */
    public FS440LaunchPage setTask2DueDate(LocalDate lDate) {
        if(Driver.getBrowserType() == DriverType.FIREFOX) {

            SeleniumTest.FireFoxWorkArounds
                    .setCalendarControl_uu_Dash_MM_Dash_dd(lDate, "dp_" + task2DueDateBoxLocatorString, task2DueDateBoxLocatorString);
        }
        else {
            SeleniumTest.clearAndSetText(task2DueDateBox, lDate.format(LocaleHelper.getDateFormatShortDateSlash_uuuu()));
        }
        return this;
    }

    /**
     * Selects the Task 2 Group
     * @param groupName
     * @return
     */
    public FS440LaunchPage selectTask1Group(String groupName) {
        Select groupSelect = new Select(task1GroupDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task1GroupLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        groupSelect.selectByVisibleText(groupName);
        return this;
    }

    /**
     * Selects the Task 2 Verifier
     * @param verifier
     * @return
     */
    public FS440LaunchPage selectTask1Verifier(String verifier) {
        Select verifierSelect = new Select(task1VerifierDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task1VerifierLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        verifierSelect.selectByVisibleText(verifier);
        return this;
    }

    /**
     * Clicks the continue button
     * @param advancePage
     * @return
     */
    public ProductFormPages clickContinue(Boolean advancePage) {
        continueButton.click();
        if(advancePage)
            return PageFactory.initElements(Driver.getDriver(), FS440FormZero.class);
        else
            return PageFactory.initElements(Driver.getDriver(), FS440LaunchPage.class);
    }
}
