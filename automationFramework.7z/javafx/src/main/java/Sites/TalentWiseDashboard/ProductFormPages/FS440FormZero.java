package Sites.TalentWiseDashboard.ProductFormPages;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/17/2015.
 */
public class FS440FormZero extends ProductFormPages{

    @FindBy(how = How.ID, using = "btnSubmit")
    private WebElement continueButton;

    /**
     * Clicks Continue Button
     * @return
     */
    public ReviewOrderPage clickContinue() {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }
}
