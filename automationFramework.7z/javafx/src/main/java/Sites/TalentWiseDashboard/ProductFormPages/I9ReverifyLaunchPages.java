package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;

/**
 * Created by abrackett on 10/11/16.
 */
public class I9ReverifyLaunchPages extends I9LaunchPages {

    public static class WorkFlows {

        public static void chooseReverificationRadioButton() {
            I9LaunchPages.WorkFlows.chooseRemoteRadioButton();
        }

        public static void chooseUpdateFormI9RadioButton() {

            I9LaunchPages.WorkFlows.chooseUpdateFormI9();
        }
    }

    public static class EmployeeProfile extends I9LaunchPages.EmployeeProfile {

        @FindBy(how = How.ID, using = "dp_qi9duedate")
        private static WebElement reverificationDueDateControl;

        @FindBy(how = How.ID, using = "qi9duedate")
        private static WebElement hiddenReverificationDueDateControl;

        static {
            PageFactory.initElements(Driver.getDriver(), EmployeeProfile.class);
        }

        /**
         * Sets the reverification due date
         * @param dueDate LocalDate representation of the date to set
         */
        public static void setReverificationDueDate(LocalDate dueDate) {
            SeleniumTest
                    .FireFoxWorkArounds
                    .setCalendarControl_MM_Slash_dd_Slash_yyyy(
                            dueDate, reverificationDueDateControl.getAttribute("id"),
                            hiddenReverificationDueDateControl.getAttribute("id"));
        }
    }

    public static class Verifier extends I9LaunchPages.Verifier {
        //TODO:  Implement
    }
}
