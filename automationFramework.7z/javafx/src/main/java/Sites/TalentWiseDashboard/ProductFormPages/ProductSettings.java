package Sites.TalentWiseDashboard.ProductFormPages;

import Exceptions.UnexpectedFieldTextException;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class ProductSettings {

    @FindBy(how = How.ID, using = "all_AdverseAction")
    private WebElement allAdverseActionLink;

    @FindBy(how = How.ID, using = "all_DOTDrugandAlcoholVerification")
    private WebElement allDOTDrugandAlcoholVerificationLink;

    @FindBy(how = How.ID, using = "all_DOTQuestionnaire")
    private WebElement allDOTQuestionnaireLink;

    @FindBy(how = How.ID, using = "all_DrugScreeningsandPhysicals")
    private WebElement allDrugScreeningsandPhysicalsLink;

    @FindBy(how = How.ID, using = "all_eScreenDrugScreening")
    private WebElement alleScreenDrugScreeningLink;

    @FindBy(how = How.ID, using = "all_LabDirect(LabDirect)")
    private WebElement allLabDirectLink;

    @FindBy(how = How.ID, using = "all_Onboarding")
    private WebElement allOnboardingLink;

    @FindBy(how = How.ID, using = "all_ReferenceCheck")
    private WebElement allReferenceCheckLink;

    @FindBy(how = How.ID, using = "all_ReferenceCheck-Enhanced")
    private WebElement allReferenceCheckEnhancedLink;

    @FindBy(how = How.ID, using = "all_ReferenceCheck-Enhanced+ClientContact")
    private WebElement allReferenceCheckEnhancedClientContactLink;

    @FindBy(how = How.ID, using = "all_ReferenceCheck-Standard")
    private WebElement allReferenceCheckStandardLink;

    @FindBy(how = How.ID, using = "all_ReferenceCheck-Standard+ClientContact")
    private WebElement allReferenceCheckStandardClientContactLink;

    @FindBy(how = How.ID, using = "all_Skills/BehavioralAssessment")
    private WebElement allSkillsBehavioralAssessmentLink;

    @FindBy(how = How.ID, using = "all_TicketingandSelf-Screening")
    private WebElement allTicketingandSelfScreeningLink;

    @FindBy(how = How.ID, using = "edit_AdverseAction")
    private WebElement editAdverseActionLink;

    @FindBy(how = How.ID, using = "edit_DOTDrugandAlcoholVerification")
    private WebElement editDOTDrugandAlcoholVerificationLink;

    @FindBy(how = How.ID, using = "edit_DOTQuestionnaire")
    private WebElement editDOTQuestionnaireLink;

    @FindBy(how = How.ID, using = "edit_DrugScreeningsandPhysicals")
    private WebElement editDrugScreeningsandPhysicalsLink;

    @FindBy(how = How.ID, using = "edit_eScreenDrugScreening")
    private WebElement editeScreenDrugScreeningLink;

    @FindBy(how = How.ID, using = "edit_LabDirect(LabDirect)")
    private WebElement editLabDirectLink;

    @FindBy(how = How.ID, using = "edit_Onboarding")
    private WebElement editOnboardingLink;

    @FindBy(how = How.ID, using = "edit_ReferenceCheck")
    private WebElement editReferenceCheckLink;

    @FindBy(how = How.ID, using = "edit_ReferenceCheck-Enhanced")
    private WebElement editReferenceCheckEnhancedLink;

    @FindBy(how = How.ID, using = "edit_ReferenceCheck-Enhanced+ClientContact")
    private WebElement editReferenceCheckEnhancedClientContactLink;

    @FindBy(how = How.ID, using = "edit_ReferenceCheck-Standard")
    private WebElement editReferenceCheckStandardLink;

    @FindBy(how = How.ID, using = "edit_ReferenceCheck-Standard+ClientContact")
    private WebElement editReferenceCheckStandardClientContactLink;

    @FindBy(how = How.ID, using = "edit_Skills/BehavioralAssessment")
    private WebElement editSkillsBehavioralAssessmentLink;

    @FindBy(how = How.ID, using = "edit_TicketingandSelf-Screening")
    private WebElement editTicketingandSelfScreeningLink;

    @FindBy(how = How.ID, using = "autoDaysInput")
    private WebElement regExpirationWindowDaysText;

    @FindBy(how = How.ID, using = "scheduleWindowSave")
    private WebElement saveRegExpirationWindowDaysButton;

    @FindBy(how = How.ID, using = "proximitypreference")
    private WebElement proximityPreferenceLabel;

    @FindBy(how = How.ID, using = "btnProvisionCustomer")
    private WebElement provisionCustomerButton;

    @FindBy(how = How.ID, using = "customerId")
    private WebElement labDirectCustomerIdField;

    @FindBy(how = How.ID, using = "panelsEnabled")
    private WebElement configuredPanelsTable;


    public void clickAllAdverseActionLink() {
        SeleniumTest.click(allAdverseActionLink);
    }

    public void clickAllDOTDrugandAlcoholVerificationLink() {
        SeleniumTest.click(allDOTDrugandAlcoholVerificationLink);
    }

    public void clickAllDOTQuestionnaireLink() {
        SeleniumTest.click(allDOTQuestionnaireLink);
    }

    public void clickAllDrugScreeningsandPhysicalsLink() {
        SeleniumTest.click(allDrugScreeningsandPhysicalsLink);
    }

    public void clickAlleScreenDrugScreeningLink() {
        SeleniumTest.click(alleScreenDrugScreeningLink);
    }

    public void clickAllLabDirectLink() {
        SeleniumTest.click(allLabDirectLink);
    }

    public void clickAllOnboardingLink() {
        SeleniumTest.click(allOnboardingLink);
    }

    public void clickAllReferenceCheckLink() {
        SeleniumTest.click(allReferenceCheckLink);
    }

    public void clickAllReferenceCheckEnhancedLink() {
        SeleniumTest.click(allReferenceCheckEnhancedLink);
    }

    public void clickAllReferenceCheckEnhancedClientContactLink() {
        SeleniumTest.click(allReferenceCheckEnhancedClientContactLink);
    }

    public void clickAllReferenceCheckStandardLink() {
        SeleniumTest.click(allReferenceCheckStandardLink);
    }

    public void clickAllReferenceCheckStandardClientContactLink() {
        SeleniumTest.click(allReferenceCheckStandardClientContactLink);
    }

    public void clickAllSkillsBehavioralAssessmentLink() {
        SeleniumTest.click(allSkillsBehavioralAssessmentLink);
    }

    public void clickAllTicketingandSelfScreeningLink() {
        SeleniumTest.click(allTicketingandSelfScreeningLink);
    }


    public void clickEditAdverseActionLink() {
        SeleniumTest.click(editAdverseActionLink);
    }

    public void clickEditDOTDrugandAlcoholVerificationLink() {
        SeleniumTest.click(editDOTDrugandAlcoholVerificationLink);
    }

    public void clickEditDOTQuestionnaireLink() {
        SeleniumTest.click(editDOTQuestionnaireLink);
    }

    public void clickEditDrugScreeningsandPhysicalsLink() {
        SeleniumTest.click(editDrugScreeningsandPhysicalsLink);
    }

    public void clickEditeScreenDrugScreeningLink() {
        SeleniumTest.click(editeScreenDrugScreeningLink);
    }

    public void clickEditLabDirectLink() {
        SeleniumTest.click(editLabDirectLink);
    }

    public void clickEditOnboardingLink() {
        SeleniumTest.click(editOnboardingLink);
    }

    public void clickEditReferenceCheckLink() {
        SeleniumTest.click(editReferenceCheckLink);
    }

    public void clickEditReferenceCheckEnhancedLink() {
        SeleniumTest.click(editReferenceCheckEnhancedLink);
    }

    public void clickEditReferenceCheckEnhancedClientContactLink() {
        SeleniumTest.click(editReferenceCheckEnhancedClientContactLink);
    }

    public void clickEditReferenceCheckStandardLink() {
        SeleniumTest.click(editReferenceCheckStandardLink);
    }

    public void clickEditReferenceCheckStandardClientContactLink() {
        SeleniumTest.click(editReferenceCheckStandardClientContactLink);
    }

    public void clickEditSkillsBehavioralAssessmentLink() {
        SeleniumTest.click(editSkillsBehavioralAssessmentLink);
    }

    public void clickEditTicketingAndSelfScreeningLink() {
        SeleniumTest.click(editTicketingandSelfScreeningLink);
    }


    public boolean isAdverseActionAttachmentActive(String fileId) throws UnexpectedFieldTextException {
        WebElement isActiveField = Driver.getDriver().findElement(
                By.xpath("//table[@class='B0']/tbody/tr/following-sibling::tr[contains(.,'" + fileId + "')]/td[8]")
        );

        if (isActiveField.getText().equals("Active")) {
            return true;
        } else if (isActiveField.getText().equals("Inactive")) {
            return false;
        } else {
            throw new UnexpectedFieldTextException("Unexpected Active? field: " + isActiveField.getText());
        }
    }


    public void activateAdverseActionAttachment(String fileId, boolean activate) throws UnexpectedFieldTextException {
        if (isAdverseActionAttachmentActive(fileId) != activate) {
            WebElement activateOrDeactivateLink = Driver.getDriver().findElement(
                    By.xpath("//table[@class='B0']/tbody/tr/following-sibling::tr[contains(.,'" + fileId + "')]/td[10]/div/a")
            );

            SeleniumTest.click(activateOrDeactivateLink);
            SeleniumTest.waitForAlert();
            SeleniumTest.acceptAlert();
            SeleniumTest.waitForAlertToGoAway();
        }
    }

    public String getRegExpirationWindowDaysText() {
        return SeleniumTest.getText(regExpirationWindowDaysText);
    }

    public void typeRegExpirationWindowDaysText(String text) {
        SeleniumTest.clearAndSetTextAdamantly(regExpirationWindowDaysText, text);
    }

    public boolean isSaveRegExpirationWindowDaysEnabled() {
        return !saveRegExpirationWindowDaysButton.getAttribute("class").contains("buttoninactive");
    }

    public void clickSaveRegExpirationWindowDays() {
        SeleniumTest.clickUntilConditionMet(saveRegExpirationWindowDaysButton,
                () -> !isSaveRegExpirationWindowDaysEnabled());
    }

    public String getProximityPreference() {
        return SeleniumTest.getText(proximityPreferenceLabel);
    }

    public boolean isProvisionCustomerButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("btnProvisionCustomer"));
    }

    public void clickProvisionCustomerButton() {
        SeleniumTest.click(provisionCustomerButton);
    }

    public boolean isProvisionCustomerButtonEnabled() {
        return !provisionCustomerButton.getAttribute("class").contains("buttoninactive");
    }

    public boolean isLabDirectCustomerIdFieldVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("customerId"));
    }

    public int getLabDirectCustomerId() {
        return Integer.parseInt(SeleniumTest.getText(labDirectCustomerIdField));
    }

    public boolean isConfiguredPanelsTableShowing() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("panelsEnabled"));
    }

    public String getConfiguredPanelsTableText() {
        return SeleniumTest.getText(configuredPanelsTable);
    }
}
