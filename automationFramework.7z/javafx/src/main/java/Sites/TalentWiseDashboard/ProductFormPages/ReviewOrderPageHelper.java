package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import static Sites.TalentWiseDashboard.ProductFormPages.ReviewOrderPage.logger;

/**
 * Created by Vivek.Rai on 6/1/2018.
 */
public class ReviewOrderPageHelper {

    public static Map<String,String> candidateEmploymentVerificationData(Candidate candidate, String employerName, String employmentDuration, String jobTitle, String reasonForJobChange){
        Map<String,String> hMap= new HashMap<>();
        hMap.put("Name",candidate.getFirstName()+" "+candidate.getMiddleName()+" "+candidate.getLastName());
        hMap.put("Employer Phone",candidate.getCandidatePhone());
        hMap.put("Social Security Number",candidate.getSocialSecurityNumber().substring(7));
        hMap.put("Employer Name",employerName);hMap.put("Email Address",candidate.getEmailAddress());
        hMap.put("Dates of Employment",employmentDuration);hMap.put("Job Title",jobTitle);
        hMap.put("Reason for Leaving",reasonForJobChange);
        return hMap;
    }
    public static boolean doesReviewOrderPageContentMatch(Map<String,String> candidateEmploymentData) {

        Set<String> set=candidateEmploymentData.keySet();
        Iterator<String > it=set.iterator();
        while (it.hasNext()) {
            String keyName=it.next();
            String keyValue = SeleniumTest.getTextByLocator(By.xpath("//div[starts-with(text(),'"+keyName+"')]/following-sibling::div[1]"));
            if (keyValue.contains(candidateEmploymentData.get(keyName))) {
                logger.info(keyName+ " is "+keyValue);
            }
            else
            {
                logger.info(candidateEmploymentData.get(keyName)+ " didnt match with "+keyValue);
                return false;
            }
        }
        return true;
    }
}
