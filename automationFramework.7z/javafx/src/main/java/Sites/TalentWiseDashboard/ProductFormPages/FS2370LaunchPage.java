package Sites.TalentWiseDashboard.ProductFormPages;

import com.google.common.base.Predicate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;

/**
 * Created by abrackett on 12/17/2015.
 */
public class FS2370LaunchPage extends LaunchFormPages {
    private static final String task2GroupID = "qverifiergroupid2";
    private static final String task2VerifierID = "qverifierid2";
    private static final String task3GroupID = "qverifiergroupid3";
    private static final String task3VerifierID = "qverifierid3";
    static By task2GroupLocator = By.id(task2GroupID);
    static By task2VerifierLocator = By.id(task2VerifierID);
    static By task3GroupLocator = By.id(task3GroupID);
    static By task3VerifierLocator = By.id(task3VerifierID);
    @FindBy(how = How.ID, using = "dp_qduedate1")

    private static WebElement task1DueDateBox;
    @FindBy(how = How.ID, using = "qduedate1")
    private static WebElement hiddenTask1DueDateBox;
    @FindBy(how = How.ID, using = "dp_qduedate2")
    private static WebElement task2DueDateBox;
    @FindBy(how = How.ID, using = "qduedate2")
    private static WebElement hiddenTask2DueDateBox;
    @FindBy(how = How.ID, using = "dp_qduedate3")
    private static WebElement task3DueDateBox;
    @FindBy(how = How.ID, using = "qduedate3")
    private static WebElement hiddenTask3DueDateBox;
    @FindBy(how = How.ID, using = task2GroupID)
    private static WebElement task2GroupDropdown;
    @FindBy(how = How.ID, using = task2VerifierID)
    private static WebElement task2VerifierDropdown;
    @FindBy(how = How.ID, using = task3GroupID)
    private static WebElement task3GroupDropdown;
    @FindBy(how = How.ID, using = task3VerifierID)
    private static WebElement task3VerifierDropdown;

    @FindBy(how = How.ID, using = "createNewVerifierBtnqverifierid2")
    private static WebElement createNewContributorButtonVerifier2;

    @FindBy(how = How.ID, using = "fnqverifierid2")
    private static WebElement newVerifier2FirstNameBox;

    @FindBy(how = How.ID, using = "lnqverifierid2")
    private static WebElement newVerifier2LastNameBox;

    @FindBy(how = How.ID, using = "emailqverifierid2")
    private static WebElement newVerifier2EmailAddressBox;

    /**
     * Sets the Task 1 Due Date uses default of Today
     * @return
     */
    public static FS2370LaunchPage setTask1DueDate() {
        return setTask1DueDate(LocalDate.now());
    }
    /**
     * Sets the Task 1 Due Date
     */
    public static FS2370LaunchPage setTask1DueDate(LocalDate lDate) {
        task1DueDateBox.clear();
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(lDate,
                task1DueDateBox.getAttribute("id"), hiddenTask1DueDateBox.getAttribute("id"));
        return PageFactory.initElements(Driver.getDriver(), FS2370LaunchPage.class);
    }

    /**
     * Sets the Task 2 Due Date uses default of Today
     * @return
     */
    public static FS2370LaunchPage setTask2DueDate() {
        return setTask2DueDate(LocalDate.now());
    }

    /**
     * Sets the Task 2 Due Date
     */
    public static FS2370LaunchPage setTask2DueDate(LocalDate lDate) {
        task2DueDateBox.clear();
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(lDate,
                task2DueDateBox.getAttribute("id"), hiddenTask2DueDateBox.getAttribute("id"));
        return PageFactory.initElements(Driver.getDriver(), FS2370LaunchPage.class);
    }

    /**
     * Sets the Task 3 Due Date uses default of Today
     * @return
     */
    public static FS2370LaunchPage setTask3DueDate() {
        return setTask3DueDate(LocalDate.now());
    }

    /**
     * Sets the Task 3 Due date
     */
    public static FS2370LaunchPage setTask3DueDate(LocalDate lDate) {
        task3DueDateBox.clear();
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(lDate,
                task3DueDateBox.getAttribute("id"), hiddenTask3DueDateBox.getAttribute("id"));
        return PageFactory.initElements(Driver.getDriver(), FS2370LaunchPage.class);
    }

    /**
     * Selects the Task 2 Group
     */
    public static FS2370LaunchPage selectTask2Group(String groupName) {
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        return new Select(d.findElement(task2GroupLocator)).getOptions().size() > 1;
                    }
                });
        Select groupSelect = new Select(task2GroupDropdown);
        groupSelect.selectByVisibleText(groupName);
        return PageFactory.initElements(Driver.getDriver(), FS2370LaunchPage.class);
    }

    /**
     * Selects the Task 2 Verifier
     */
    public static FS2370LaunchPage selectTask2Verifier(String verifier) {
        Select verifierSelect = new Select(task2VerifierDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        return new Select(d.findElement(task2VerifierLocator)).getOptions().size() >
                                1;
                    }
                });
        verifierSelect.selectByVisibleText(verifier);
        return PageFactory.initElements(Driver.getDriver(), FS2370LaunchPage.class);
    }

    /**
     * Selects the Task 3 Group
     */
    public static FS2370LaunchPage selectTask3Group(String groupName) {
        Select groupSelect = new Select(task3GroupDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        return new Select(d.findElement(task3GroupLocator)).getOptions().size() > 1;
                    }
                });
        groupSelect.selectByVisibleText(groupName);
        return PageFactory.initElements(Driver.getDriver(), FS2370LaunchPage.class);
    }

    /**
     * Selects the Task 3 Verifier
     */
    public static FS2370LaunchPage selectTask3Verifier(String verifier) {
        Select verifierSelect = new Select(task3VerifierDropdown);
        WaitUntil.waitUntil(() -> {
            if (new Select(Driver.getDriver().findElement(task3VerifierLocator)).getOptions().size() >
                    1) {
                return true;
            }
            return false;
        });
        verifierSelect.selectByVisibleText(verifier);
        return PageFactory.initElements(Driver.getDriver(), FS2370LaunchPage.class);
    }

    /**
     * Clicks the continue button
     *
     * @return ProductFormPages
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    public static void clickCreateNewContributorVerifier2() {
        createNewContributorButtonVerifier2.click();
        WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("fnqverifierid2")).isDisplayed());
    }

    public static void setNewVerifier2FirstName(String firstName) {
        SeleniumTest.clearAndSetText(newVerifier2FirstNameBox, firstName);
    }

    public static void setNewVerifier2LastName(String lastName) {
        SeleniumTest.clearAndSetText(newVerifier2LastNameBox, lastName);
    }

    public static void setNewVerifier2EmailAddress(String emailAddress) {
        SeleniumTest.clearAndSetText(newVerifier2EmailAddressBox, emailAddress);
    }
}
