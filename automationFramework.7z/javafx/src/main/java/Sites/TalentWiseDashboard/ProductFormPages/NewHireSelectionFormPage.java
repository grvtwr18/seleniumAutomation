package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.AdminConsole.Login.CreateAccountPage;
import Sites.TalentWiseDashboard.PositionModal;
import TWFramework.LocaleHelper;
import static TWFramework.SeleniumTest.waitForElementVisible;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import com.thoughtworks.selenium.Selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;

/**
 * Created by tjoshi on 11/19/2015.
 */
public class NewHireSelectionFormPage extends ProductFormPages
{

    private static String visibleId = "dp_qduedate1";
    private static String hiddenId = "qduedate1";

    @FindBy(how = How.ID, using = "dp_qduedate1")
    private static WebElement candidateDueDate;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement submitButton;

    @FindBy(how = How.XPATH, using = "//input[@fieldname='Department']")
    private static WebElement department;

    @FindBy(how = How.XPATH, using = "//input[@fieldname='Manager']")
    private static WebElement manager;


    private WebElement newHireForm;

    private String[] newHireFormSelections;

    protected static final Logger staticLogger = LoggerFactory.getLogger(NewHireSelectionFormPage.class);

    static {
         PageFactory.initElements(Driver.getDriver(), NewHireSelectionFormPage.class);
    }

    /**
     * Click the submit button on the page
     * @return
     */
    public static ReviewOrderPage clickSubmitButton()
    {
        SeleniumTest.click(submitButton);
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Sets the forms that need to be filled by candidate from given list of forms for customer
     * @param newHireFormSelections
     */
    public void setNewHireFormsSelection(String[] newHireFormSelections)
    {
        this.newHireFormSelections = newHireFormSelections;
    }

    /**
     * Based on the newHireFormSelection array, the check boxes on the review page are checked
     */
    public void checkNewHireFormsSelection()
    {
        if (newHireFormSelections.length > 0) {
            int length = newHireFormSelections.length;
            for(length--; length >= 0; length--) {
                waitForElementVisible(By.id("btnSubmit"));
                newHireForm = Driver.getDriver().findElement(By.id(newHireFormSelections[length]));
                if ( !newHireForm.isSelected() ) {
                    newHireForm.click();
                }
            }
        }
    }

    /**
     * Sets a date on the candidates 'Due Date' field.
     * @param date
     */
    public static void setCandidateDueDate(LocalDate date)
    {
        if(Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date, visibleId, hiddenId);
        }
        else {
            String strDate = date.format(LocaleHelper.getDateFormatShortDateSlash_uuuu());
            candidateDueDate.sendKeys(strDate);
        }
    }

    /**
     * Selects a dropdown in the review order page
     * @param elementId
     * @param value
     */
    public void selectValueFromDropDown(String elementId, String value)
    {
        WebElement element = Driver.getDriver().findElement(By.id(elementId));
        SeleniumTest.selectByVisibleTextFromDropDown(element, value);
    }

    public static void newHireFormsSelection(String[] formids){
        for(int i=0; i<formids.length;i++) {
            SeleniumTest.click(By.id(formids[i]));
        }
    }

    public static void fillAndConfirmForm(String[] ids, String drpDownString, String location){
        staticLogger.info("Setting Candidate Due Date to now");
        NewHireSelectionFormPage.setCandidateDueDate(LocalDate.now());
        staticLogger.info("Clicking Continue");
        NewHireSelectionFormPage.clickSubmitButton();
        NewHireSelectionFormPage.newHireFormsSelection(ids);
        staticLogger.info("Clicking Continue");
        NewHireSelectionFormPage.clickSubmitButton();
        staticLogger.info("Select location from dropdown");
        new NewHireSelectionFormPage().selectValueFromDropDown(drpDownString,location);
        NewHireSelectionFormPage.clickSubmitButton();
        staticLogger.info("Clicking 'Confirm and Launch'");
        ReviewOrderPage.clickConfirmAndLaunchButton();
    }
    public static void fillNewHireElectronicApplication67251001(){
        staticLogger.info("Setting Candidate Due Date to now");
        NewHireSelectionFormPage.setCandidateDueDate(LocalDate.now());
        staticLogger.info("Click continue so that Department and manager field displays in staging env");
        NewHireSelectionFormPage.clickSubmitButton();
        if(SeleniumTest.isElementVisibleNoWaiting(By.xpath("//input[@fieldname='Department']"))) {
            staticLogger.info("Fill 2 mandatory fields for form 67251001 for Staging env");
            SeleniumTest.clearAndSetText(department, "onboarding");
            SeleniumTest.clearAndSetText(manager,"TestManager");
            staticLogger.info("Clicking Continue");
            NewHireSelectionFormPage.clickSubmitButton();
        }

        staticLogger.info("Clicking 'Confirm and Launch'");
        ReviewOrderPage.clickConfirmAndLaunchButton();

    }

    public static void fillNewHireElectronicApplication531(){
        staticLogger.info("Setting Candidate Due Date to now");
        NewHireSelectionFormPage.setCandidateDueDate(LocalDate.now());
        staticLogger.info("Clicking Continue");
        NewHireSelectionFormPage.clickSubmitButton();
        if(SeleniumTest.isElementVisible(submitButton)) {
            staticLogger.info("Clicking Continue Candidate Questionnaire Selection");
            NewHireSelectionFormPage.clickSubmitButton();
        }
        staticLogger.info("Clicking 'Confirm and Launch'");
        ReviewOrderPage.clickConfirmAndLaunchButton();
    }
}
