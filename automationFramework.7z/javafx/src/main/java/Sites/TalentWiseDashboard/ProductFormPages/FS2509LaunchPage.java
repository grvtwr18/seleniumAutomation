package Sites.TalentWiseDashboard.ProductFormPages;

import WebDriver.Driver;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

/**
 * Created by abrackett on 1/25/2016.
 * TODO: I suspect this is a duplicate of FS2370LaunchPage, as a three-task due date form page.
 */
public class FS2509LaunchPage extends ProductFormPages {

    @FindBy(how = How.ID, using = "dp_qduedate1")
    private WebElement task1DueDateBox;

    @FindBy(how = How.ID, using = "dp_qduedate2")
    private WebElement task2DueDateBox;

    @FindBy(how = How.ID, using = "dp_qduedate3")
    private WebElement task3DueDateBox;

    private final String task2GroupID = "qverifiergroupid2";
    By task2GroupLocator = By.id(task2GroupID);
    @FindBy(how = How.ID, using = task2GroupID)
    private WebElement task2GroupDropdown;

    private final String task2VerifierID = "qverifierid2";
    By task2VerifierLocator = By.id(task2VerifierID);
    @FindBy(how = How.ID, using = task2VerifierID)
    private WebElement task2VerifierDropdown;

    private final String task3GroupID = "qverifiergroupid3";
    By task3GroupLocator = By.id(task3GroupID);
    @FindBy(how = How.ID, using = task3GroupID)
    private WebElement task3GroupDropdown;

    private final String task3VerifierID = "qverifierid3";
    By task3VerifierLocator = By.id(task3VerifierID);
    @FindBy(how = How.ID, using = task3VerifierID)
    private WebElement task3VerifierDropdown;

    @FindBy(how = How.ID, using = "btnSubmit")
    private WebElement continueButton;

    /**
     * Sets the Task 1 Due Date
     * @param lDate
     * @return
     */
    public FS2509LaunchPage setTask1DueDate(LocalDate lDate) {
        task1DueDateBox.clear();
        task1DueDateBox.sendKeys(getMMDDYYYY(lDate));
        return this;
    }

    /**
     * Sets the Task 2 Due Date
     * @param lDate
     * @return
     */
    public FS2509LaunchPage setTask2DueDate(LocalDate lDate) {
        task2DueDateBox.clear();
        task2DueDateBox.sendKeys(getMMDDYYYY(lDate));
        return this;
    }

    /**
     * Sets the Task 3 Due date
     * @param lDate
     * @return
     */
    public FS2509LaunchPage setTask3DueDate(LocalDate lDate) {
        task3DueDateBox.clear();
        task3DueDateBox.sendKeys(getMMDDYYYY(lDate));
        return this;
    }

    /**
     * Selects the Task 2 Group
     * @param groupName
     * @return
     */
    public FS2509LaunchPage selectTask2Group(String groupName) {
        Select groupSelect = new Select(task2GroupDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task2GroupLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        groupSelect.selectByVisibleText(groupName);
        return this;
    }

    /**
     * Selects the Task 2 Verifier
     * @param verifier
     * @return
     */
    public FS2509LaunchPage selectTask2Verifier(String verifier) {
        Select verifierSelect = new Select(task2VerifierDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task2VerifierLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        verifierSelect.selectByVisibleText(verifier);
        return this;
    }

    /**
     * Selects the Task 3 Group
     * @param groupName
     * @return
     */
    public FS2509LaunchPage selectTask3Group(String groupName) {
        Select groupSelect = new Select(task3GroupDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task3GroupLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        groupSelect.selectByVisibleText(groupName);
        return this;
    }

    /**
     * Selects the Task 3 Verifier
     * @param verifier
     * @return
     */
    public FS2509LaunchPage selectTask3Verifier(String verifier) {
        Select verifierSelect = new Select(task3VerifierDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task3VerifierLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        verifierSelect.selectByVisibleText(verifier);
        return this;
    }

    /**
     * Clicks the continue button
     * @param advancePage
     * @return
     */
    public ProductFormPages clickContinue(Boolean advancePage) {
        continueButton.click();
        if(advancePage)
            return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        else
            return PageFactory.initElements(Driver.getDriver(), FS2509LaunchPage.class);
    }

    private String getMMDDYYYY(LocalDate localDate) {
        //TODO:  Find the way to do this using the date functions rather than manually assembling the date.
        String twoDigitMonth = Integer.toString(localDate.getMonthValue());
        if(twoDigitMonth.length() < 2)
            twoDigitMonth = "0" + twoDigitMonth;

        String twoDigitDayOfMonth = Integer.toString(localDate.getDayOfMonth());
        if(twoDigitDayOfMonth.length() < 2)
            twoDigitDayOfMonth = "0" + twoDigitDayOfMonth;

        return twoDigitMonth + "/" + twoDigitDayOfMonth + "/" + Integer.toString(localDate.getYear());
    }
}
