package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ScreeningLaunchPageWithRtw {

    public static void clickLegalRightWorkInUkYes() {
        SeleniumTest.click(By.xpath("//input[(@name='qright_Group1105-0_1') and (@value='1')]"));
    }

    public static void clickLegalRightWorkInUkNo() {
        SeleniumTest.click(By.xpath("//input[(@name='qright_Group1105-0_1') and (@value=0)]"));
    }

    public static void clickDoYouHaveAUkOrEeaPassportYes() {
        SeleniumTest.click(By.xpath("//input[(@name='qpassport_Group1105-0_1') and (@value=1)]"));
    }

    public static void clickDoYouHaveAUkOrEeaPassportNo() {
        SeleniumTest.click(By.xpath("//input[(@name='qpassport_Group1105-0_1') and (@value=0)]"));
    }

    public static void attachRightToWorkFileIdDocumentOne(String canonicalPath) {
        WebElement fileChooser = Driver.getDriver().findElement(By.id("file_document_2_Group1105-0_1"));
        fileChooser.sendKeys(canonicalPath);
    }

    public static void attachRightToWorkFileIdDocumentTwo(String canonicalPath) {
        WebElement fileChooser = Driver.getDriver().findElement(By.id("file_document_3_Group1105-0_1"));
        fileChooser.sendKeys(canonicalPath);
    }

    public static void selectRightToWorkFileFileTypeAttachFileIdDocumentOne(String fileTypeName) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.name("label_document_2_Group1105-0_1"), "" + fileTypeName);
    }

    public static void selectRightToWorkFileFileTypeAttachFileIdDocumentTwo(String fileTypeName) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.name("label_document_3_Group1105-0_1"), "" + fileTypeName);
    }

    public static void clickContinue() {
        SeleniumTest.click(By.id("btnSubmit"));
    }
}
