package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import WebDriver.Driver;

public class SelectAKAsToSearchPage extends ProductFormPages {
    private WebDriver driver;

    @FindBy(xpath = ".//*[@id='uberform']/div[2]/table/tbody/tr[2]/td[2]/input")
    // @CacheLookup - Don't use because it greatly increases your chances of
    // seeing StaleElementReferenceExceptions, and the like.  See multiple
    // warnings against its use on the Internet.
    private static WebElement akasFoundForThisSsn1;

    @FindBy(xpath = ".//*[@id='uberform']/div[2]/table/tbody/tr[3]/td/input")
    private static WebElement akasFoundForThisSsn2;

    @FindBy(xpath = ".//*[@id='uberform']/div[2]/table/tbody/tr[4]/td/input")
    private static WebElement akasFoundForThisSsn3;

    @FindBy(xpath = ".//*[@id='uberform']/div[2]/table/tbody/tr[5]/td/input")
    private static WebElement akasFoundForThisSsn4;

    @FindBy(xpath = ".//*[@id='uberform']/div[2]/table/tbody/tr[6]/td/input")
    private static WebElement akasFoundForThisSsn5;

    @FindBy(id = "btnSubmit")
    private static WebElement continueButton;

    @FindBy(name = "edit")
    private static WebElement editSearch;

    static {
        PageFactory.initElements(Driver.getDriver(), SelectAKAsToSearchPage.class);
    }

    /**
     * Click on Continue Button.
     */
    public static void clickContinueButton() {
        SeleniumTest.click(continueButton);
    }

    /**
     * Click on Edit Search Button.
     */
    public static void clickEditSearchButton() {
        editSearch.click();
    }

    /**
     * Set Akas Found For This Ssn Checkbox field.
     */
    public static void setAkasFoundForThisSsn1CheckboxField() {
        if (!akasFoundForThisSsn1.isSelected()) {
            akasFoundForThisSsn1.click();
        }
    }

    /**
     * Set Akas Found For This Ssn Checkbox field.
     */
    public static void setAkasFoundForThisSsn2CheckboxField() {
        if (!akasFoundForThisSsn2.isSelected()) {
            akasFoundForThisSsn2.click();
        }
    }

    /**
     * Set Akas Found For This Ssn Checkbox field.
     */
    public static void setAkasFoundForThisSsn3CheckboxField() {
        if (!akasFoundForThisSsn3.isSelected()) {
            akasFoundForThisSsn3.click();
        }
    }

    /**
     * Set Akas Found For This Ssn Checkbox field.
     */
    public static void setAkasFoundForThisSsn4CheckboxField() {
        if (!akasFoundForThisSsn4.isSelected()) {
            akasFoundForThisSsn4.click();
        }
    }

    /**
     * Set Akas Found For This Ssn Checkbox field.
     */
    public static void setAkasFoundForThisSsn5CheckboxField() {
        if (!akasFoundForThisSsn5.isSelected()) {
            akasFoundForThisSsn5.click();
        }
    }

    /**
     * Submit the form to target page.
     */
    public static void submit() {
        clickContinueButton();
    }

    /**
     * Unset Akas Found For This Ssn Checkbox field.
     */
    public static void unsetAkasFoundForThisSsn1CheckboxField() {
        if (akasFoundForThisSsn1.isSelected()) {
            akasFoundForThisSsn1.click();
        }
    }

    /**
     * Unset Akas Found For This Ssn Checkbox field.
     */
    public static void unsetAkasFoundForThisSsn2CheckboxField() {
        if (akasFoundForThisSsn2.isSelected()) {
            akasFoundForThisSsn2.click();
        }
    }

    /**
     * Unset Akas Found For This Ssn Checkbox field.
     */
    public static void unsetAkasFoundForThisSsn3CheckboxField() {
        if (akasFoundForThisSsn3.isSelected()) {
            akasFoundForThisSsn3.click();
        }
    }

    /**
     * Unset Akas Found For This Ssn Checkbox field.
     */
    public static void unsetAkasFoundForThisSsn4CheckboxField() {
        if (akasFoundForThisSsn4.isSelected()) {
            akasFoundForThisSsn4.click();
        }
    }

    /**
     * Unset Akas Found For This Ssn Checkbox field.
     */
    public static void unsetAkasFoundForThisSsn5CheckboxField() {
        if (akasFoundForThisSsn5.isSelected()) {
            akasFoundForThisSsn5.click();
        }
    }
}
