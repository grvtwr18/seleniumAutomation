package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class DhsSelectCollectionSitePage extends ProductFormPages {

    @FindBy(className = "drugPanel")
    private WebElement drugPanelTitleLabel;

    @FindBy(xpath = "//div[@class='siteInfo']")
    private List<WebElement> dhsCollectionSiteInfoLabels;

    @FindBy(xpath = "//input[@class='dhsCollectionSite']")
    private List<WebElement> dhsCollectionSiteRadioButtons;

    @FindBy(id = "dhsSiteSearchZipButton")
    private WebElement zipRadioButton;

    @FindBy(id = "altSiteSearchZip")
    private WebElement zipTextBox;

    @FindBy(id = "altSiteSearchZipSubmit")
    private WebElement searchZipButton;

    @FindBy(id = "siteSelectionBack")
    private WebElement backButton;

    @FindBy(id = "siteSelectionCancel")
    private WebElement cancelButton;

    @FindBy(id = "siteSelectionSchedule")
    private WebElement registerButton;

    @FindBy(id = "dhsSiteList")
    private WebElement dhsSiteList;

    @FindBy(id = "dhsSiteSearchCoCButton")
    private WebElement dhsSiteSearchCoCButton;

    @FindBy(id = "altSiteSearchCoC")
    private WebElement altSiteSearchCoCInput;

    @FindBy(id = "altSiteSearchCoCSubmit")
    private WebElement dhsSiteSearchCoCsubmitButton;

    @FindBy(id = "customerServiceContact")
    private WebElement dhsCustomerServiceLink;

    @FindBy(id = "customerServiceText")
    private WebElement dhsPhoneMessage;

    @FindBy(id = "errorNositesCustSrv")
    private WebElement dhsErrorMessage;

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("siteSelectionCancel"));// cancel is the only option seen if test expects collection sites or error messages
    }

    public String getDrugPanelTitle() {
        return SeleniumTest.getText(drugPanelTitleLabel);
    }

    public int getCollectionSiteCount() {
        return dhsCollectionSiteRadioButtons.size();
    }

    public String getCollectionSiteInfo(int index) {
        return SeleniumTest.getText(dhsCollectionSiteInfoLabels.get(index));
    }

    /**
     * Click on the Collection Site at the given index.
     *
     * @param index of the Collection Site to be clicked on.
     */
    public void clickCollectionSite(int index) {
        SeleniumTest.check(dhsCollectionSiteRadioButtons.get(index));
    }

    public void clickDifferentZipCode(String zip) {
        SeleniumTest.click(zipRadioButton);
        SeleniumTest.click(zipTextBox);
        SeleniumTest.clearAndSetText(zipTextBox, zip);
        SeleniumTest.click(searchZipButton);
    }

    /**
     * Click on the Collection Site that contains the given sub-text.
     * throws a NotFoundException if no Collection Site can be found containing
     * the given sub-text.
     *
     * @param containingSubText sub-text expected to be found within one of the Collection Sites.
     * @return the zero based index of the Collection Site in which the containingSubText may be found.
     */
    public int clickCollectionSite(String containingSubText) {
        for (int i = 0; i < getCollectionSiteCount(); ++i) {
            if (getCollectionSiteInfo(i).contains(containingSubText)) {
                clickCollectionSite(i);
                return i;
            }
        }

        throw new NotFoundException("Can't find a Collection Site containing text: " + containingSubText);
    }

    public void typeZip(String zip) {
        SeleniumTest.clearAndSetText(zipTextBox, zip);
    }

    public void clickSearchZipButton() {
        SeleniumTest.click(searchZipButton);
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public void clickCustomerServiceLink() {
        SeleniumTest.click(dhsCustomerServiceLink);
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public void clickBackButton() {
        SeleniumTest.click(backButton);
    }

    public void clickCancelButton() {
        SeleniumTest.click(cancelButton);
    }

    public void checkPaperChainOfCustodyOption() {
        SeleniumTest.check(dhsSiteSearchCoCButton);
    }

    public void typeCustodyNumber(String num) {
        SeleniumTest.clearAndSetText(altSiteSearchCoCInput, num);
    }

    public RegisteredForDrugScreenPage clickRegisterButton() {
        SeleniumTest.clickUntilConditionMet(registerButton, () -> RegisteredForDrugScreenPage.onPage());
        return PageFactory.initElements(Driver.getDriver(), RegisteredForDrugScreenPage.class);
    }

    public RegisteredForDrugScreenPage clickSearch2Button() {
        SeleniumTest.clickUntilConditionMet(dhsSiteSearchCoCsubmitButton, () -> RegisteredForDrugScreenPage.onPage());
        return PageFactory.initElements(Driver.getDriver(), RegisteredForDrugScreenPage.class);
    }

    public String getSiteListMessage() {
        return SeleniumTest.getText(dhsSiteList);
    }

    public String getSiteErrorMessage() {
        return SeleniumTest.getText(dhsErrorMessage);
    }

    public String getSitePhoneMessage() {
        return SeleniumTest.getText(dhsPhoneMessage);
    }

    public int searchDifferentZipcode(String zip) {
        typeZip(zip);
        SeleniumTest.click(searchZipButton);
        SeleniumTest.waitForJQueryAjaxDone();
        return getCollectionSiteCount();
    }
}
