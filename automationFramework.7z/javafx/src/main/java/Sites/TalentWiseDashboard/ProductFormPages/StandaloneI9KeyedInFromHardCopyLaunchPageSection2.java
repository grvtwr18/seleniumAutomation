package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import Utility.Onboarding.OnboardingUtility;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;


/**
 * Created by jgupta on 4/7/2016.
 */
public class StandaloneI9KeyedInFromHardCopyLaunchPageSection2 extends ProductFormPages {

    // TODO improve for second and third documents when needed

    @FindBy(how = How.ID, using = "qSection2DocumentType2") public static WebElement
        listBandListCDocumentsRadio;

    @FindBy(how = How.ID, using = "qListBReceipt") public static WebElement listBReceiptCheckBox;

    @FindBy(how = How.ID, using = "qListBIssuingAuthority_USDriverLicense") public static WebElement
        listBIssuingAuthority;

    @FindBy(how = How.NAME, using = "qListBDocumentNumber") public static WebElement
        listBlicenseNumberTextBox;

    @FindBy(how = How.NAME, using = "qListBReceiptIssuingAuthority") public static WebElement
        listBIssuingAuthorityTextBox;

    @FindBy(how = How.NAME, using = "qListCIssuingAuthority") public static WebElement
        listCIssuingAuthorityTextBox;

    @FindBy(how = How.ID, using = "btnSubmit") public static WebElement continueButton;

    @FindBy(how = How.ID, using = "qListAIssuingAuthorityText") public static WebElement
        issuingAuthorityTextBox;

    @FindBy(how = How.ID, using = "qListAIssuingAuthority2Text") public static WebElement
            issuingAuthorityTextBox2;

    @FindBy(how = How.NAME, using = "qListADocumentNumber1") public static WebElement
        documentNumberTextBox;

    @FindBy(how = How.ID, using = "qListADocumentType") public static WebElement
        documentTitleADropdown;

    @FindBy(how = How.ID, using = "qListBDocumentType") public static WebElement
        documentTitleBDropdown;

    @FindBy(how = How.ID, using = "qListCDocumentType") public static WebElement
        documentTitleCDropdown;

    @FindBy(how = How.ID, using = "qcertify") public static WebElement affirmationCheckBox;

    @FindBy(how = How.CSS, using = "input[type='file']") private static WebElement filePathBox;

    @FindBy(how = How.NAME, using = "qListAExpDateMonth1") public static WebElement
        expirationMonthDropdown;

    @FindBy(how = How.NAME, using = "qListAExpDateDay1") public static WebElement
        expirationDateDropdown;

    @FindBy(how = How.NAME, using = "qListAExpDateYear1") public static WebElement
        expirationYearDropdown;

    @FindBy(how = How.CSS, using = "#divListAExpDate1 > div[class='errorBelow']") public static WebElement
            dateAlertMessage;

    @FindBy(how = How.CSS, using = "div[class='searchErrorBox'] > div[class='body']") public static WebElement
            headerAlertMessage;

    @FindBy(how = How.NAME, using = "qListAExpDateMonth2") public static WebElement
            expirationMonthDropdown2;

    @FindBy(how = How.NAME, using = "qListAExpDateDay2") public static WebElement
            expirationDateDropdown2;

    @FindBy(how = How.NAME, using = "qListAExpDateYear2") public static WebElement
            expirationYearDropdown2;

    @FindBy(how = How.ID, using = "qSection2DocumentType1") public static WebElement
        listADocumentRadio;

    @FindBy(how = How.ID, using = "qSection2DocumentType2") private static WebElement
        listBAndCDocumentRadiobutton;


    /**
     * Fills the Form I-9 Section 2: Employer Review and Verification
     *
     * @param document
     * @param issuingAuthority
     * @param documentNumber
     * @param documentExpiration
     */
    public static void fillEmployerReviewAndVerificationSectionWithListA(
        ListADocumentTitle document, String issuingAuthority, String documentNumber,
        LocalDate documentExpiration) {
        SeleniumTest.waitForElement(listADocumentRadio);
        clickListADocumentRadioBtn();
        SeleniumTest.waitForElement(documentTitleADropdown);
        selectDocumentTitleA(document.toString());
        SeleniumTest
            .waitForElementToBeClickable(issuingAuthorityTextBox, SeleniumTest.FLUENTWAIT_TIMEOUT);
        SeleniumTest.clearAndSetText(issuingAuthorityTextBox, issuingAuthority);
        SeleniumTest.clearAndSetText(documentNumberTextBox, documentNumber);
        selectExpirationDate(documentExpiration);

        if (document.equals(ListADocumentTitle.UNEXPIRED_FORIEGN_PASSPORT_WITH_I551)) {
            SeleniumTest.clearAndSetText(issuingAuthorityTextBox2, issuingAuthority);
            selectExpirationDate2(documentExpiration);
        }
    }

    /**
     * Fills Employer Review and Verification Section2 with List B and C Data
     *
     * @param bDocument           List B Document
     * @param bIssuingAuthority   List B Issuing Authority
     * @param bDocumentNumber     List B Document Number
     * @param bDocumentExpiration List B Document Expiration
     * @param cDocument           List C Document
     * @param cIssuingAuthority   List C Issuing Authority
     * @param cDocumentNumber     List C Document Number
     * @param cDocumentExpiration List C Document Expiration
     */
    public static void fillEmployerReviewAndVerificationSectionWithListBAndC(
        ListBDocumentTitle bDocument, String bIssuingAuthority, String bDocumentNumber,
        LocalDate bDocumentExpiration, ListCDocumentTitle cDocument, String cIssuingAuthority,
        String cDocumentNumber, LocalDate cDocumentExpiration) {

        SeleniumTest.waitForElement(listBAndCDocumentRadiobutton);
        StandaloneI9KeyedInFromHardCopyLaunchPageSection2.clickListBandCDocumentRadioButton();
        WaitUntil.waitUntil(() -> {
            return documentTitleBDropdown.isDisplayed();
        }, NoSuchElementException.class);
        WaitUntil.waitUntil(() -> {
            return documentTitleCDropdown.isDisplayed();
        }, NoSuchElementException.class);
        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(
                Driver.getDriver().findElement(By.id("qListBDocumentType")),
            bDocument.toString());

        if (bDocument.equals(ListBDocumentTitle.DRIVERS_LICENSE)) {
            OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(
                Driver.getDriver().findElement(By.id("qListBIssuingAuthority_USDriverLicense")),
                bIssuingAuthority);
        } else {
            SeleniumTest
                    .clearAndSetText(Driver.getDriver().findElement(By.id("qListBIssuingAuthority")),
                                     bIssuingAuthority);
        }
        SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.name("qListBDocumentNumber")),
                                     bDocumentNumber);
        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By
                                                                                                       .name
                ("qListBExpDateMonth")),
            bDocumentExpiration.getMonth().getDisplayName(TextStyle.SHORT, Locale.US)
        );
        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By
                                                                                                       .name
                ("qListBExpDateDay")),
            Integer.toString(bDocumentExpiration.getDayOfMonth())
        );
        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By
                                                                                                       .name
                ("qListBExpDateYear")),
            Integer.toString(bDocumentExpiration.getYear())
        );

        OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By.id
                ("qListCDocumentType")),
            cDocument.toString());
        Driver.getDriver().switchTo().activeElement().sendKeys(Keys.TAB);
        // Hard coded add of "Other" for list C#7 Documents using this method
        if (cDocument.toString().contains("#7")) {
            OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By.id
                    ("qListCDhsDocumentType")), "Other");
            SeleniumTest.clearAndSetText(By.id("qListCOtherDhsDocumentType"), "Other Type");
        }
        SeleniumTest.waitForElementToBeClickable(By.name("qListCIssuingAuthority"));
        SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.name("qListCIssuingAuthority")),
                                     cIssuingAuthority);

        switch (cDocument) {
            case NATIVE_AMERICAN:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.name("qListCDocumentNumber")),
                                             cDocumentNumber);
                OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(
                    Driver.getDriver().findElement(By.name("qListCExpDateMonth")),
                    cDocumentExpiration.getMonth().getDisplayName(TextStyle.SHORT, Locale.US)
                );
                OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(Driver.getDriver()
                                                                              .findElement
                        (By.name
                        ("qListCExpDateDay")),
                    Integer.toString(cDocumentExpiration.getDayOfMonth())
                );
                OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(
                    Driver.getDriver().findElement(By.name("qListCExpDateYear")),
                    Integer.toString(cDocumentExpiration.getYear())
                );
                break;
            case EMPLOYMENT_AUTHORIZATION:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.name("qListCDocumentNumber")),
                                             cDocumentNumber);
                OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(
                    Driver.getDriver().findElement(By.name("qListCExpDateMonth")),
                    cDocumentExpiration.getMonth().getDisplayName(TextStyle.SHORT, Locale.US)
                );
                OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(Driver.getDriver()
                                                                              .findElement
                        (By.name
                        ("qListCExpDateDay")),
                    Integer.toString(cDocumentExpiration.getDayOfMonth())
                );
                OnboardingUtility.Verbs.selectByVisibleTextFromDropDown(
                    Driver.getDriver().findElement(By.name("qListCExpDateYear")),
                    Integer.toString(cDocumentExpiration.getYear())
                );
                break;
            default:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.name("qListCDocumentNumber")),
                                             cDocumentNumber);
                break;
        }

    }

    /**
     * Clicks on List A Document radio button.
     */
    private static void clickListADocumentRadioBtn() {
        listADocumentRadio.click();
    }


    /**
     * Clicks on List A Document radio button.
     */
    private static void clickListBandCDocumentRadioButton() {
        listBAndCDocumentRadiobutton.click();
    }

    /**
     * Selects value from Drop down A
     *
     * @param documentTitle
     */
    public static void selectDocumentTitleA(String documentTitle) {
        Select documentListADropDown = new Select(documentTitleADropdown);
        documentListADropDown.selectByVisibleText(documentTitle);
    }

    /**
     * Selects value from Drop down B
     *
     * @param documentTitle
     */
    public static void selectDocumentTitleB(String documentTitle) {
        Select documentListBDropDown = new Select(documentTitleBDropdown);
        documentListBDropDown.selectByVisibleText(documentTitle);
    }

    /**
     * Clicks on Continue button
     *
     * @param returnedClass
     * @return
     */
    public static ProductFormPages clickContinueBtn(
        Class<? extends ProductFormPages> returnedClass) {
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 5);
        WebElement theContinueButton = SeleniumTest.waitForElementToBeClickable(continueButton, 30);
        //Click on Continue button to go to next page.
        theContinueButton.click();

        return PageFactory.initElements(Driver.getDriver(), returnedClass);

    }

    /**
     * Checks the affirmation checkbox
     */
    public static void checkAffirmationCheckbox() {
        SeleniumTest.check(affirmationCheckBox);
    }


    /**
     * Selects the document expiration date
     *
     * @param date LocalDate representation of the date to pick
     */
    public static void selectExpirationDate(LocalDate date) {
        SeleniumTest.selectShortMonthByVisibleText(expirationMonthDropdown, date);

        Select dayDD = new Select(expirationDateDropdown);
        dayDD.selectByVisibleText(Integer.toString(date.getDayOfMonth()));

        Select yearDD = new Select(expirationYearDropdown);
        yearDD.selectByVisibleText(Integer.toString(date.getYear()));
    }

    /**
     * Selects the document expiration date number 2. This second expiration date selector only shows up when List A document
     * 'Unexpired Foreign Passport with I-551 stamp or temporary I-551 printed notation on a MRIV' is selcted.
     *
     * @param date LocalDate representation of the date to pick
     */
    public static void selectExpirationDate2(LocalDate date) {
        SeleniumTest.selectShortMonthByVisibleText(expirationMonthDropdown2, date);

        Select dayDD = new Select(expirationDateDropdown2);
        dayDD.selectByVisibleText(Integer.toString(date.getDayOfMonth()));

        Select yearDD = new Select(expirationYearDropdown2);
        yearDD.selectByVisibleText(Integer.toString(date.getYear()));
    }

    /**
     * returns alert message text below expiration date drop down.
     * @return
     */
    public static String getDateAlertMessageText() {
        return dateAlertMessage.getText();
    }

    /**
     * returns alert message text in header box.
     * @return
     */
    public static String getHeaderAlertMessageText() {
        return headerAlertMessage.getText();
    }

    /**
     * Enum for List a Documents
     */
    public enum ListADocumentTitle {
        USPASSPORT("U.S. Passport"),
        UNEXPIRED_FORIEGN_PASSPORT_WITH_I551("Foreign Passport containing a temp. I-551 MRIV");

        private final String text;

        ListADocumentTitle(final String text) {
            this.text = text;
        }

        @Override public String toString() {

            return text;
        }
    }


    /**
     * Enum for List B Documents
     */
    public enum ListBDocumentTitle {
        DRIVERS_LICENSE("Driver's license"),
        GOVERNMENT_ID("ID card issued by federal, state, or local government"),
        SCHOOL_ID("School ID card with a photograph"),
        VOTERS_REGISTRATION("Voter's registration card"),
        US_MILITARY_CARD("U.S. Military card or draft record"),
        MILITARY_DEPENDENT_ID("Military dependent's ID card"),
        US_COAST_GUARD("U.S. Coast Guard Merchant Mariner Card"),
        NATIVE_AMERICAN("Native American tribal document"),
        DRIVERS_LICENSE_CANADA("Driver's license issued by a Canadian government authority");

        private final String text;

        ListBDocumentTitle(final String text) {
            this.text = text;
        }

        @Override public String toString() {
            return text;
        }
    }


    /**
     * Enum for List C Documents
     */
    public enum ListCDocumentTitle {
        SSN_CARD("Social Security Card without restrictions"),
        BIRTH_ABROAD_CERT(
            "Certification of Birth Abroad issued by the Department of State (Form FS-545)"),
        REPORT_OF_BIRTH(
            "Certification of Report of Birth issued by the Department of State (Form DS-1350)"),
        BIRTH_CERTIFICATE(
            "Original or certified copy of birth certificate bearing an official seal"),
        NATIVE_AMERICAN("Native American tribal document"),
        US_CITIZEN_ID("U.S. Citizen ID Card (Form I-197)"),
        RESIDENT_CITIZEN(
            "Identification Card for Use of Resident Citizen in the United States (Form I-179)"),
        EMPLOYMENT_AUTHORIZATION(
            "Employment Auth. Doc. issued (DHS) List C #7");

        private final String text;

        ListCDocumentTitle(final String text) {
            this.text = text;
        }

        @Override public String toString() {
            return text;
        }
    }

    /**
     * Fills the Form I-9 Section 2: Employer Review and Verification
     *
     * @param document
     * @param issuingAuthority
     * @param documentNumber
     */
    public static void fillEmployerReviewAndVerificationSectionWithListA(String document,
        String issuingAuthority, String documentNumber, String docExpirationMonth,
        String docExpirationDay, String docExpirationYear) {
        SeleniumTest.waitForElement(listADocumentRadio);
        clickListADocumentRadioBtn();
        SeleniumTest.waitForElement(documentTitleADropdown);
        selectDocumentTitleA(document);
        SeleniumTest
            .waitForElementToBeClickable(issuingAuthorityTextBox, SeleniumTest.FLUENTWAIT_TIMEOUT);
        SeleniumTest.clearAndSetText(issuingAuthorityTextBox, issuingAuthority);
        SeleniumTest.clearAndSetText(documentNumberTextBox, documentNumber);
        selectExpirationDateForListA(docExpirationMonth, docExpirationDay, docExpirationYear);
    }

    /**
     * Selects documents from drop down C
     *
     * @param documentTitle
     */
    public static void selectDocumentTitleC(String documentTitle) {
        Select documentListCDropDown = new Select(documentTitleCDropdown);
        documentListCDropDown.selectByVisibleText(documentTitle);
    }

    /**
     * Selects the document expiry date.
     *
     * @param docExpirationMonth
     * @param docExpirationDay
     * @param docExpirationYear
     */
    public static void selectExpirationDateForListA(String docExpirationMonth,
        String docExpirationDay, String docExpirationYear) {

        SeleniumTest.selectShortMonthByVisibleText(expirationMonthDropdown, docExpirationMonth);

        Select dayDD = new Select(expirationDateDropdown);
        dayDD.selectByVisibleText(docExpirationDay);

        Select yearDD = new Select(expirationYearDropdown);
        yearDD.selectByVisibleText(docExpirationYear);
    }

    /**
     * Uploads file
     *
     * @param filePath
     * @return
     */
    public static StandaloneI9KeyedInFromHardCopyLaunchPageSection2 uploadFile(String filePath) {
        affirmationCheckBox.sendKeys(Keys.TAB);
        if(!org.apache.commons.lang.SystemUtils.IS_OS_WINDOWS) {
            if(!filePath.startsWith("/")) {
                filePath = "/" + filePath;
            }
        } else {
            String path = filePath.replace("/C:", "C:");
            filePath = path.replace("/", "\\\\");
        }

        Driver.getDriver().switchTo().activeElement().sendKeys(filePath);
        Driver.getDriver().switchTo().defaultContent();
        return PageFactory.initElements(Driver.getDriver(),
            StandaloneI9KeyedInFromHardCopyLaunchPageSection2.class);
    }

    /**
     * Clicks on the B radio button
     */
    public static void clickEmployerReviewAndVerificationSectionWithListBAndC() {
        listBandListCDocumentsRadio.click();
    }

    /**
     * Selects document from List B
     *
     * @param listBTitle
     */
    public static void selectListBDocumentTitle(String listBTitle) {
        Select listBDropdown = new Select(documentTitleBDropdown);
        listBDropdown.selectByVisibleText(listBTitle);
    }

    /**
     * Select document name from C list
     *
     * @param listCTitle
     */
    public static void selectListCDocumentTitle(String listCTitle) {
        Select listCDropdown = new Select(documentTitleCDropdown);
        listCDropdown.selectByVisibleText(listCTitle);
    }

    /**
     * Specify information for List B document
     */
    public static void selectListBDocumentDriversLicenseOrIDCard(Boolean isReceiptStolen,
        String issuingAuthorityState, String licenseNumber, LocalDate expirationDate) {
        selectListCDocumentTitle("Driver's license or ID card");
        if (isReceiptStolen) {
            SeleniumTest.check(listBReceiptCheckBox);
            listBIssuingAuthorityTextBox.sendKeys(issuingAuthorityState);
            //listBDocumentNumberTextBox.sendKeys(licenseNumber);
        } else {
            Select issuingAuthorityDD = new Select(listBIssuingAuthority);
            issuingAuthorityDD.selectByVisibleText(issuingAuthorityState);

            SeleniumTest.clearAndSetText(listBlicenseNumberTextBox, licenseNumber);
        }
        selectExpirationDate("B", expirationDate);
    }

    /**
     * Specify information for List B document
     */
    public static void selectListCDocumentSocialSecurityAccountNumberCard(Boolean isReceiptStolen,
        String issuingAuthorityState, String documentNumber, LocalDate expirationDate) {
        selectListCDocumentTitle(
            "Social Security Account Number card not specifying employment not authorized");
        if (isReceiptStolen) {
            SeleniumTest.check(listBReceiptCheckBox);
            typeIssuingAuthority("CReceipt", issuingAuthorityState);
            typeDocumentNumber("BReceipt", documentNumber);
            selectExpirationDate("CReceipt", expirationDate);
        } else {
            typeIssuingAuthority("C", issuingAuthorityState);
        }
    }

    /**
     * Types on any Issuing authority text box on screen.
     *
     * @param caseB_C_or_Receipt
     * @param issuingAuthority
     */
    public static void typeIssuingAuthority(String caseB_C_or_Receipt, String issuingAuthority) {
        WebElement issuingAuthorityTextBox = Driver.getDriver()
            .findElement(By.name("qList" + caseB_C_or_Receipt + "IssuingAuthority"));
        SeleniumTest.clearAndSetText(issuingAuthorityTextBox, issuingAuthority);
    }

    /**
     * Types on any document number text box.
     *
     * @param caseB_C_or_Receipt
     * @param docNumber
     */
    public static void typeDocumentNumber(String caseB_C_or_Receipt, String docNumber) {
        WebElement docNumberTextBox =
            Driver.getDriver().findElement(By.name("qList" + caseB_C_or_Receipt + "Number"));
        SeleniumTest.clearAndSetText(docNumberTextBox, docNumber);
    }

    /**
     * Selects the document expiry date.
     *
     * @param docExpiryDate
     */
    public static void selectExpirationDate(String caseB_C_or_Receipt, LocalDate docExpiryDate) {
        String docExpirationDay = (Integer.toString(docExpiryDate.getDayOfMonth()));
        String docExpirationYear = (Integer.toString(docExpiryDate.getYear()));

        WebElement monthDropDown =
            Driver.getDriver().findElement(By.name("qList" + caseB_C_or_Receipt + "ExpDateMonth"));
        SeleniumTest.selectShortMonthByVisibleText(monthDropDown, docExpiryDate);

        WebElement dayDropDown =
            Driver.getDriver().findElement(By.name("qList" + caseB_C_or_Receipt + "ExpDateDay"));
        Select dayDD = new Select(dayDropDown);
        dayDD.selectByVisibleText(docExpirationDay);

        WebElement yearDropDown =
            Driver.getDriver().findElement(By.name("qList" + caseB_C_or_Receipt + "ExpDateYear"));
        Select yearDD = new Select(yearDropDown);
        yearDD.selectByVisibleText(docExpirationYear);
    }
}
