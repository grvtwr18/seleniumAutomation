package Sites.TalentWiseDashboard.ProductFormPages;

import java.time.LocalDate;

/**
 * A helper for a single task launch form.
 *
 * Created by jpflager on 9/22/16.
 */
public abstract class SingleTaskLaunchFormHelper {
    public static void clickThroughUsingCurrentDate() {
        StandardCandidateQuestionnaireLaunchPage.waitForPageReady();
        StandardCandidateQuestionnaireLaunchPage.setDueDate(LocalDate.now());
        StandardCandidateQuestionnaireLaunchPage.clickContinue();
    }
}
