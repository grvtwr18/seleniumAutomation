package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by jpflager on 9/19/16.
 */
public class StandardCandidateQuestionnaireFormZeroHelper {
    // TODO: these two methods may have some use for other formzeros, but I don't know from that. If so, they should
    // be moved to ProductFormPages or some other similar parent class, and have their javadocs note that the examples
    // are specific to the StandardCanddiateQuestionnaireFormZero form.

    /**
     * Verifies that the formzero input with the given field ID has the "checked" attribute. Examples include the SSN
     * and DOB checkbox/
     *
     * @param fieldId the "Field ID" for the input to verify
     * @return true if "checked" is present, otherwise false
     */
    public static boolean isInputCheckboxForFieldIdChecked(String fieldId) {
        WebElement input = Driver.getDriver().findElement(By.id("FormZero-" + fieldId));
        return SeleniumTest.isCheckboxChecked(input);
    }

    /**
     * Gets the string "value" attribute of the checked radio button for an input name for the supplied field ID. This
     * is designed based on the Education History radio button.
     *
     * @param fieldId the "Field ID" for the radio button to examine
     * @return the String "value" attribute of the checked radio button for the matching input
     */
    public static String getValueofCheckedRadioButtonForFieldId(String fieldId) {
        WebElement checkedRadioButton = Driver.getDriver().findElement(By.cssSelector("input[name='FormZero-" + fieldId + "']:checked"));
        return checkedRadioButton.getAttribute("value");
    }
}
