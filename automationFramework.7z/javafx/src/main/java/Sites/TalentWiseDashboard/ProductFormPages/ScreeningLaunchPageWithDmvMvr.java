package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ScreeningLaunchPageWithDmvMvr extends ScreeningLaunchPage {

    static {
        PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPageWithDmvMvr.class);
    }

    /**
     * Select the DMV Country and State/Province
     */
    public static void selectDmvCountryStateOrProvince(String country, String stateOrProvince, String group) {
        WebElement dmvCountry = Driver.getDriver().findElement(By.id("qo_Group" + group + "_1"));
        new Select(dmvCountry).selectByVisibleText(country);

        String stateCountryTagId = "qs_Group" + group + "_1_";

        switch (country) {
            case "United States":
                stateCountryTagId += "US";
                break;
            case "Canada":
                stateCountryTagId += "CA";
                break;
            default:
                throw new IllegalArgumentException("Unexpected country: " + country);
        }

        WebElement dmvStateOrProvince = Driver.getDriver().findElement(By.id(stateCountryTagId));
        SeleniumTest.selectByVisibleTextFromDropDown(dmvStateOrProvince, stateOrProvince);
    }

    public static boolean isSelectDmvStateVisible(String group) {
        return SeleniumTest.isElementVisible(By.id("qs_Group" + group + "_1"));
    }

    /**
     * Select the DMV Driving Records State when US is assumed to be the country.
     */
    public static void selectDmvState(String state, String group) {
        WebElement dmvState = Driver.getDriver().findElement(By.id("qs_Group" + group + "_1"));
        SeleniumTest.selectByVisibleTextFromDropDown(dmvState, state);
    }

    /**
     * Type the DMV Driving Record's Driver's License
     */
    public static void typeDmvDriversLicense(String license, String group) {
        WebElement dmvDriversLicenseTextBox = Driver.getDriver().findElement(By.id("qdl_Group" + group + "_1"));
        SeleniumTest.clearAndSetText(dmvDriversLicenseTextBox, license);
    }

    /**
     * Is, "Check the box if this is a commercial driver's license (CDL)," displayed ?
     */
    public static boolean isDmvCdlCheckBoxDisplayed(String group) {
        // Same locator used again below ...
        WebElement dmvCheckBoxForCdl = Driver.getDriver().findElement(By.name("qinf_Group" + group + "_1"));
        return dmvCheckBoxForCdl.isDisplayed();
    }

    /**
     * Check the checkbox, "Check the box if this is a commercial driver's license (CDL)."
     */
    public static void checkDmvCdlCheckBox(String group, boolean check) {
        // Same locator used again above ...
        WebElement dmvCheckBoxForCdl = Driver.getDriver().findElement(By.name("qinf_Group" + group + "_1"));

        if (check)
            SeleniumTest.check(dmvCheckBoxForCdl);
        else
            SeleniumTest.unCheck(dmvCheckBoxForCdl);
    }

    public static void fillDriversLicenseInformation(String state, String license) {
        selectDmvState(state, discoverGroupId());
        typeDmvDriversLicense(license, discoverGroupId());
    }
}
