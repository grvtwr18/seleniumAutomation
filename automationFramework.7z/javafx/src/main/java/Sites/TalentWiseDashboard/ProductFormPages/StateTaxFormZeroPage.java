package Sites.TalentWiseDashboard.ProductFormPages;

import Data.locations.us.UsStateTerritory;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A page object for the state tax formzero (1971).
 *
 * Created by jpflager on 9/22/16.
 */
public class StateTaxFormZeroPage {
    private static Logger staticLogger = LoggerFactory.getLogger(StateTaxFormZeroPage.class);

    @FindBy(how = How.ID, using = "FormZero-1971_1")
    private static WebElement location1Select;

    static {
        PageFactory.initElements(Driver.getDriver(), StateTaxFormZeroPage.class);
    }

    public static String getSelectedLocation1Value() {
        return new Select(location1Select)
                .getFirstSelectedOption()
                .getAttribute("value");
    }
}
