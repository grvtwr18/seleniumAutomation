package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Contributor;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


/**
 * Created by abrackett on 11/13/2015.
 */
public class ProductFormPages extends CustomerPortalPage{

    private final static String CANDIDATE_VIEW_EXPECTED_LINK = "Candidate View";

    @FindBy(how = How.ID, using = "aClearForm")
    private static WebElement clearAllLink;

    @FindBy(how = How.XPATH, using = "//input[@value='Search']")
    private static WebElement searchButton;

    @FindBy(how = How.CLASS_NAME, using = "count")
    private static WebElement countString;

    @FindBy(how = How.XPATH, using = "//a[contains(@onclick,'fillWithTestData')]")
    private static WebElement fillWithTestDataLink;

    public static int getItemCount() {
        try {
            return Integer.parseInt(countString.getText().split("of ")[1]);
        } catch (NoSuchElementException e) {
            return 0;
        }
    }

    /**
     * Clicks the Candidate View link. Note that this link is not always present, only if an uberform is launched from
     * an existing candidate. But that covers most if not all the uses of this ProductFormPages class (since mostly it's
     * for custom HPM/ONB forms, which can't be launched from the dashboard).
     */
    public static void clickCandidateViewLink() {
        Driver.getDriver().findElement(By.linkText(CANDIDATE_VIEW_EXPECTED_LINK)).click();
        SeleniumTest.waitForElementNotPresent(By.linkText(CANDIDATE_VIEW_EXPECTED_LINK));
    }

    static {
        PageFactory.initElements(Driver.getDriver(), ProductFormPages.class);
    }

    /**
     * Runs the javascript behind the fill with test data link
     * default data.
     */
    public static void fillWithTestDataJs() {
        if (!SeleniumTest.isElementVisibleNoWaiting(By.xpath("//a[contains(@onclick,'fillWithTestData')]"))) {

            String url = SeleniumTest.getCurrentUrl();

            if (!url.contains("&prefill=1")) {
                url += "&prefill=1";
                SeleniumTest.navigateToUrl(url);
                SeleniumTest.waitForPageLoad();
            }
        }

        SeleniumTest.waitForElementToBeClickable(fillWithTestDataLink);
        JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
        // TODO: Find out which exceptions are thrown by this, and catch all that are reasonably expected ...
        js.executeScript("fillWithTestData(); return false;");
    }

    /** this is on the tabs under Screen
     *
     */
    public static void clickClearAll() {
        clearAllLink.click();
    }

    public static void clickSearchButton() {
        searchButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static void clickSearchButtonAdvancedSearchOptions() {
        Driver.getDriver().findElements(By.xpath("//input[@value='Search']")).get(1).click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    // TODO: this stuff doesn't belong here.
    public static class Contributors {

        // region Constants

        private static final String BUTTON_NOT_VISIBLE = "Button is not visible";
        private static final String FIRST_SELECT = ", you must first select ";
        private static final String CONTRIBUTOR_BUTTON_SELECTED =
                "Create new Contributor button must be selected before you can set the contributor";
        private static final String DISABLED = "Disabled";
        private static final String CLASS = "class";
        private static final String HIDDEN = "hidden";

        private static final org.slf4j.Logger staticLogger = org.slf4j.LoggerFactory.getLogger("ProductFormPages.Contributors");
        // endregion

        // region Locator Strings

        private static final String CREATE_NEW_CONTRIBUTOR_BUTTON = "//input[contains(@id, " +
                "'createNewVerifierBtnqverifierid";
        private static final String VERIFIER_GROUP = "//select[contains(@id, 'qverifiergroupid";
        private static final String VERIFIER_FIRST_LAST_EMAIL = "//select[contains(@id, " +
                "'qverifierid";
        private static final String CONTRIBUTOR_FIRST_NAME = "//input[contains(@id, 'fnqverifierid";
        private static final String CONTRIBUTOR_LAST_NAME = "//input[contains(@id, 'lnqverifierid";
        private static final String CONTRIBUTOR_EMAIL = "//input[contains(@id, 'emailqverifierid";

        // endregion

        // region Contributor selection supporting methods

        /**
         * Clicks on the Create new Contributor Button
         * @param taskNumber taskNumber of the contributor to set
         *                   Where there are NOT multiples on the page choose 1
         */
        public static void clickCreateNewContributorButton(int taskNumber) {
            WebElement element = null;

            switch(taskNumber) {
                case 1:
                    element = Driver.getDriver().findElement(By.xpath(CREATE_NEW_CONTRIBUTOR_BUTTON + "')]"));
                    break;
                default:
                    element = Driver.getDriver().findElement(By.xpath(CREATE_NEW_CONTRIBUTOR_BUTTON + taskNumber + "')]"));
                    break;
            }

            if (!element.getAttribute(CLASS).contains(DISABLED)) {
                element.click();
            } else {
                throw new RuntimeException("Create Contributor " + BUTTON_NOT_VISIBLE +
                        FIRST_SELECT + "a group");
            }
        }

        /**
         * Clicks on the Select Existing contributor button
         * @param taskNumber taskNumber of the contributor to set
         *                   Where there are NOT multiples on the page choose 1
         */
        public static void clickSelectExistingContributorButton(int taskNumber) {
            WebElement element = null;

            switch(taskNumber) {
                case 1:
                    element = Driver.getDriver().findElement(
                            By.xpath(CREATE_NEW_CONTRIBUTOR_BUTTON + "')]"));
                    break;
                default:
                    element = Driver.getDriver().findElement(
                            By.xpath(CREATE_NEW_CONTRIBUTOR_BUTTON +
                                    taskNumber +
                                    "')]"));
                    break;
            }

            if(!element.getAttribute(CLASS).contains(DISABLED)
                    && element.getText().contains("Select")) {
                element.click();
            } else {
                throw new RuntimeException("Select Existing " + BUTTON_NOT_VISIBLE +
                        FIRST_SELECT + "Create New Contributor");
            }
        }

        /**
         * Select the Contributor group
         * @param taskNumber taskNumber of the contributor group to set
         *                   Where there are NOT multiples on the page choose 1
         * @param groupName The name as shown in the drop down
         */
        public static void selectContributorGroup(int taskNumber, String groupName) {
            WebElement element = null;

            switch(taskNumber) {
                case 1:
                    element = Driver.getDriver().findElement(By.xpath(VERIFIER_GROUP + "')]"));
                    break;
                default:
                    element = Driver.getDriver().findElement(
                            By.xpath(VERIFIER_GROUP +
                                    taskNumber +
                                    "')]"));
                    break;
            }

            TWFramework.SeleniumTest.selectByVisibleTextFromDropDown(
                    element, groupName);
        }

        /**
         * Select the Contributor
         * @param taskNumber taskNumber of the contributor to set
         *                   Where there are NOT multiples on the page choose 1
         * @param contributorFirstLastAndEmail Contributor first, last and email
         *                                     Follow this pattern: first last (email@email.com)
         */
        public static void selectContributor(int taskNumber, String contributorFirstLastAndEmail) {
            WebElement element = null;

            switch(taskNumber) {
                case 1:
                    element = Driver.getDriver().findElement(By.xpath(VERIFIER_FIRST_LAST_EMAIL + "')]"));
                    break;
                default:
                    element = Driver.getDriver().findElement(By.xpath(
                            VERIFIER_FIRST_LAST_EMAIL +
                                    taskNumber +
                                    "')]"));
                    break;
            }
            TWFramework.SeleniumTest.selectByVisibleTextFromDropDown(
                    element, contributorFirstLastAndEmail);
        }

        /**
         * Set the Contributor's first name
         * @param taskNumber taskNumber of the contributor first name to set
         *                   Where there are NOT multiples on the page choose 1
         * @param contributorFirstName first name of the contributor
         */
        public static void setContributorFirstName(int taskNumber, String contributorFirstName) {
            WebElement element = null;

            switch(taskNumber) {
                case 1:
                    element = Driver.getDriver().findElement(By.xpath(CONTRIBUTOR_FIRST_NAME + "')]"));
                    break;
                default:
                    element = Driver.getDriver().findElement(By.xpath(CONTRIBUTOR_FIRST_NAME + taskNumber + "')]"));
                    break;
            }

            if (!element.getAttribute(CLASS).contains(HIDDEN)) {
                TWFramework.SeleniumTest.clearAndSetText(
                        element, contributorFirstName);
            } else {
                throw new RuntimeException(CONTRIBUTOR_BUTTON_SELECTED + " first name");
            }
        }

        /**
         * Set the Contributor's last name
         * @param taskNumber taskNumber of the contributor last name to set
         *                   Where there are NOT multiples on the page choose 1
         * @param contributorLastName last name of the contributor
         */
        public static void setContributorLastName(int taskNumber, String contributorLastName) {
            WebElement element = null;

            switch(taskNumber) {
                case 1:
                    element = Driver.getDriver().findElement(By.xpath(CONTRIBUTOR_LAST_NAME + "')]"));
                    break;
                default:
                    element = Driver.getDriver().findElement(By.xpath(
                            CONTRIBUTOR_LAST_NAME +
                                    taskNumber +
                                    "')]"));
                    break;
            }
            if (!element.getAttribute(CLASS).contains(HIDDEN)) {
                TWFramework.SeleniumTest.clearAndSetText(
                        element, contributorLastName);
            } else {
                throw new RuntimeException(CONTRIBUTOR_BUTTON_SELECTED + " last name");
            }
        }

        /**
         * Set the Contributor's email address
         * @param taskNumber taskNumber of the contributor email address to set
         *                   Where there are NOT multiples on the page choose 1
         * @param contributorEmailAddress contributor complete email address
         *                                email@email.com
         */
        public static void setContributorEmailAddress(int taskNumber, String contributorEmailAddress) {
            WebElement element = null;

            switch(taskNumber) {
                case 1:
                    element = Driver.getDriver().findElement(By.xpath(CONTRIBUTOR_EMAIL + "')]"));
                    break;
                default:
                    element = Driver.getDriver().findElement(By.xpath(
                            CONTRIBUTOR_EMAIL +
                                    taskNumber +
                                    "')]"));
                    break;
            }
            if (!element.getAttribute(CLASS).contains(HIDDEN)) {
                TWFramework.SeleniumTest.clearAndSetText(
                        element, contributorEmailAddress);
            } else {
                throw new RuntimeException(CONTRIBUTOR_BUTTON_SELECTED + " email address");
            }
        }

        // endregion

        // region Create Contributor on-the-fly Workflows

        /**
         * Creates a new Contributor on-the-fly
         * @param taskNumber taskNumber of the Contributor to create
         *                   Where there are NOT multiples on the page choose 1
         * @param contributor Workflows.Contributor Object
         */
        public static void createNewContributorOnTheFly(int taskNumber, Contributor contributor) {

            StringBuilder errorStrings = new StringBuilder();

            if (contributor.getLoginGroups().length < 1) {
                errorStrings.append(
                        "Contributor must be a member of a valid login group\n");
            } else {
                try {
                    selectContributorGroup(taskNumber, contributor.getLoginGroups()[0]);
                } catch (org.openqa.selenium.NoSuchElementException nse) {
                    errorStrings.append("Contributor first login Group must already exist in available groups.\n");
                }
            }
            final int minimumLength = 3;
            if (contributor.getFirstName().length() < minimumLength) {
                errorStrings.append("Contributor first name " +
                        contributor.getFirstName() +
                        "is too short or not valid\n");
            }
            if (contributor.getLastName().length() < minimumLength) {
                errorStrings.append("Contributor last name " +
                        contributor.getLastName() +
                        "is too short or not valid\n");
            }
            if (contributor.getEmailAddress().length() < minimumLength) {
                errorStrings.append("Contributor email address " +
                        contributor.getEmailAddress() +
                        "is too short or not valid");
            }
            if(errorStrings.length() != 0) {
                throw new RuntimeException(errorStrings.toString());
            }
            staticLogger.info("Click Create Contributor");
            clickCreateNewContributorButton(taskNumber);
            staticLogger.info("Set Contributor first name: {}", contributor.getFirstName());
            setContributorFirstName(taskNumber, contributor.getFirstName());
            staticLogger.info("Set Contributor last name: {}", contributor.getLastName());
            setContributorLastName(taskNumber, contributor.getLastName());
            staticLogger.info("Set Contributor email: {}", contributor.getEmailAddress());
            setContributorEmailAddress(taskNumber, contributor.getEmailAddress());
        }

        // endregion

    }
}
