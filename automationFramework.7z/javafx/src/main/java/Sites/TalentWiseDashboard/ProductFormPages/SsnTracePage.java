package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import static TWFramework.SeleniumTest.check;
import static TWFramework.SeleniumTest.isElementPresent;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class SsnTracePage extends ProductFormPages {
    private static Candidate candidate;

    @FindBy(id = "qa")
    @CacheLookup
    private static WebElement address;

    @FindBy(id = "qfalias0")
    @CacheLookup
    private static WebElement alternateFirstName;

    @FindBy(id = "qnalias0")
    @CacheLookup
    private static WebElement alternatemaidenLastName;

    @FindBy(id = "qc")
    @CacheLookup
    private static WebElement city;

    @FindBy(id = "btnSubmit")
    @CacheLookup
    private static WebElement continueButton;

    @FindBy(id = "qee")
    @CacheLookup
    private static WebElement emailAddress;

    @FindBy(id = "qf")
    @CacheLookup
    private static WebElement firstName;

    @FindBy(id = "qn")
    @CacheLookup
    private static WebElement lastName;

    @FindBy(id = "qmi")
    @CacheLookup
    private static WebElement middleName;

    @FindBy(id = "qnomi")
    @CacheLookup
    private static WebElement noMiddleNameCheckbox;

    @FindBy(id = "qp")
    @CacheLookup
    private static WebElement phoneNumber;

    @FindBy(id = "qfcramanualagree")
    @CacheLookup
    private static WebElement manualAgree;

    @FindBy(id = "qfcraedagree")
    @CacheLookup
    private static WebElement sendElectronicDisclosureAndAuthorizationForms;

    @FindBy(id = "qempstate")
    @CacheLookup
    private static WebElement locationOfEmployment;

    @FindBy(id = "qempcity")
    @CacheLookup
    private static WebElement locationOfEmploymentCity;

    @FindBy(id = "qs")
    @CacheLookup
    private static WebElement stateterritory;

    @FindBy(id = "qsuffix")
    @CacheLookup
    private static WebElement suffix;

    @FindBy(id = "qz")
    @CacheLookup
    private static WebElement zipCode;

    @FindBy(id = "govtId-value-text")
    @CacheLookup
    private static WebElement socialSecurityNumber;

    @FindBy(id = "qmm")
    @CacheLookup
    private static WebElement dobMonth;

    @FindBy(id = "qdd")
    @CacheLookup
    private static WebElement dobDay;

    @FindBy(id = "qyy")
    @CacheLookup
    private static WebElement dobYear;

    /**
     * Fill every field in the page.
     */
    public static void fill() {
        setFirstNameTextField();
        setMiddleNameTextField();
        setLastNameTextField();
        setSuffixTextField();
        setAlternateFirstNameTextField();
        setAlternatemaidenLastNameTextField();
        setPhoneNumberTextField();
        setEmailAddressTextField();
        setAddressTextField();
        setCityTextField();
        setStateTerritoryDropDownListField();
        setZipCodeTextField();
        if (isElementPresent(locationOfEmployment)) {
            setLocationOfEmploymentDropDownListField();
            setLocationOfEmploymentCityField();
        }
        setSocialSecurityNumberTextField();
        setDobMonthDropDownListField();
        setDobDayDropDownListField();
        setDobYearDropDownListField();
    }

    /**
     * Fill every field in the page.
     */
    public static void fillTicket() {
        setFirstNameTextField();
        setMiddleNameTextField();
        setLastNameTextField();
        setSuffixTextField();
        setEmailAddressTextField();
    }

    /**
     * Fill every field in the page.
     */
    public static void fillCriminalCountySearchLaunch() {
        setFirstNameTextField();
        setMiddleNameTextField();
        setLastNameTextField();
        setSuffixTextField();
        setPhoneNumberTextField();
        setEmailAddressTextField();
        setAddressTextField();
        setCityTextField();
        setStateTerritoryDropDownListField();
        setZipCodeTextField();
        setLocationOfEmploymentDropDownListField();
        setLocationOfEmploymentCityField();
        setSocialSecurityNumberTextField();
        setDobMonthDropDownListField();
        setDobDayDropDownListField();
        setDobYearDropDownListField();
    }

    /**
     * Set default value to Address Text field.
     */
    public static void setAddressTextField() {
        setAddressTextField(candidate.getAddressLine1());
    }

    /**
     * Set value to Address Text field.
     */
    public static void setAddressTextField(String addressValue) {
        SeleniumTest.clearAndSetText(address, addressValue);
    }

    /**
     * Set default value to Alternate First Name Text field.
     */
    public static void setAlternateFirstNameTextField() {
        setAlternateFirstNameTextField(candidate.getAlternateFirstName());
    }

    /**
     * Set value to Alternate First Name Text field.
     */
    public static void setAlternateFirstNameTextField(String alternateFirstNameValue) {
        SeleniumTest.clearAndSetText(alternateFirstName, alternateFirstNameValue);
    }

    /**
     * Set default value to Alternatemaiden Last Name Text field.
     */
    public static void setAlternatemaidenLastNameTextField() {
        setAlternatemaidenLastNameTextField(candidate.getAlternateLastName());
    }

    /**
     * Set value to Alternatemaiden Last Name Text field.
     */
    public static void setAlternatemaidenLastNameTextField(String alternatemaidenLastNameValue) {
        SeleniumTest.clearAndSetText(alternatemaidenLastName, alternatemaidenLastNameValue);
    }

    /**
     * Set default value to City Text field.
     */
    public static void setCityTextField() {
        setCityTextField(candidate.getCity());
    }

    /**
     * Set value to City Text field.
     */
    public static void setCityTextField(String cityValue) {
        SeleniumTest.clearAndSetText(city, cityValue);
    }

    /**
     * Set default value to City Text field.
     */
    public static void setLocationOfEmploymentCityField() {
        setLocationOfEmploymentCityField(candidate.getCity());
    }

    /**
     * Set value to the City of Employment text field
     *
     * @param cityValue: (String) Name of city
     */
    public static void setLocationOfEmploymentCityField(String cityValue) {
        SeleniumTest.setTextValue(locationOfEmploymentCity, cityValue);
    }

    /**
     * Set default value to Email Address Text field.
     */
    public static void setEmailAddressTextField() {
        setEmailAddressTextField(candidate.getEmailAddress());
    }

    /**
     * Set value to Email Address Text field.
     */
    public static void setEmailAddressTextField(String emailAddressValue) {
        SeleniumTest.clearAndSetText(emailAddress, candidate.getEmailAddress());
    }

    /**
     * Set default value to First Name Text field.
     */
    public static void setFirstNameTextField() {
        setFirstNameTextField(candidate.getFirstName());
    }

    /**
     * Set value to First Name Text field.
     */
    public static void setFirstNameTextField(String firstNameValue) {
        SeleniumTest.clearAndSetText(firstName, firstNameValue);
    }

    /**
     * Set default value to Last Name Text field.
     */
    public static void setLastNameTextField() {
        setLastNameTextField(candidate.getLastName());
    }

    /**
     * Set value to Last Name Text field.
     */
    public static void setLastNameTextField(String lastNameValue) {
        SeleniumTest.clearAndSetText(lastName, lastNameValue);
    }

    /**
     * Set default value to Middle Name Text field.
     */
    public static void setMiddleNameTextField() {
        setMiddleNameTextField(candidate.getMiddleName());
    }

    /**
     * Set value to Middle Name Text field.
     */
    public static void setMiddleNameTextField(String middleNameValue) {
        SeleniumTest.clearAndSetText(middleName, middleNameValue);
    }

    /**
     * Check the noMiddleNameCheckbox
     */
    public static void checkNoMiddleNameCheckbox() {
        check(noMiddleNameCheckbox);
    }

    /**
     * Set default value to Phone Number Text field.
     */
    public static void setPhoneNumberTextField() {
        setPhoneNumberTextField(candidate.getCandidatePhone());
    }

    /**
     * Set value to Phone Number Text field.
     */
    public static void setPhoneNumberTextField(String phoneNumberValue) {
        SeleniumTest.clearAndSetText(phoneNumber, phoneNumberValue);
    }

    /**
     * Set frcamanualagree checkbox.
     */
    public static void setManualAgree() {
        if (!manualAgree.isSelected()) {
            manualAgree.click();
        }
    }

    /**
     * Set Send Electronic Disclosure And Authorization Forms To This Individual At The Email Given Below Checkbox field.
     */
    public static void setSendElectronicDisclosureAndAuthorizationFormsCheckboxField() {
        if (!sendElectronicDisclosureAndAuthorizationForms.isSelected()) {
            sendElectronicDisclosureAndAuthorizationForms.click();
        }
    }

    /**
     * Set default value to State Drop Down List field.
     */
    public static void setLocationOfEmploymentDropDownListField() {
        setLocationOfEmploymentDropDownListField(candidate.getState());
    }

    /**
     * Set value to Location Of Employment Drop Down List field.
     */
    public static void setLocationOfEmploymentDropDownListField(String locationOfEmploymentValue) {
        new Select(locationOfEmployment).selectByVisibleText(locationOfEmploymentValue);
    }

    /**
     * Set default value to StateTerritory Drop Down List field.
     */
    public static void setStateTerritoryDropDownListField() {
        setStateTerritoryDropDownListField(candidate.getState());
    }

    /**
     * Set value to StateTerritory Drop Down List field.
     */
    public static void setStateTerritoryDropDownListField(String stateterritoryValue) {
        new Select(stateterritory).selectByVisibleText(stateterritoryValue);
    }

    /**
     * Set default value to Suffix Text field.
     */
    public static void setSuffixTextField() {
        setSuffixTextField(candidate.getSuffix());
    }

    /**
     * Set value to Suffix Text field.
     */
    public static void setSuffixTextField(String suffixValue) {
        SeleniumTest.clearAndSetText(suffix, suffixValue);
    }

    /**
     * Set default value to Zip Code Text field.
     */
    public static void setZipCodeTextField() {
        setZipCodeTextField(candidate.getZip());
    }

    /**
     * Set value to Zip Code Text field.
     */
    public static void setZipCodeTextField(String zipCodeValue) {
        SeleniumTest.clearAndSetText(zipCode, zipCodeValue);
    }

    /**
     * Set default value to SSN Text field.
     */
    public static void setSocialSecurityNumberTextField() {
        setSocialSecurityNumberTextField(candidate.getSocialSecurityNumber());
    }

    /**
     * Set value to SSN Text field.
     */
    public static void setSocialSecurityNumberTextField(String socialSecurityNumberValue) {
        SeleniumTest.clearAndSetText(socialSecurityNumber, socialSecurityNumberValue);
    }

    public static void submit() {
        clickContinueButton();
    }

    /**
     * Unset manualAgree checkbox.
     */
    public static void unsetManualAgree() {
        if (manualAgree.isSelected()) {
            manualAgree.click();
        }
    }

    /**
     * Unset Send Electronic Disclosure And Authorization Forms To This Individual At The Email Given Below Checkbox field.
     */
    public static void unsetSendElectronicDisclosureAndAuthorizationFormsCheckboxField() {
        if (sendElectronicDisclosureAndAuthorizationForms.isSelected()) {
            sendElectronicDisclosureAndAuthorizationForms.click();
        }
    }

    /**
     * Unset default value from Location Of Employment Drop Down List field.
     */
    public static void unsetLocationOfEmploymentDropDownListField() {
        unsetStateDropDownListField(candidate.getState());
    }

    /**
     * Unset value from State Drop Down List field.
     */
    public static void unsetStateDropDownListField(String stateValue) {
        new Select(locationOfEmployment).deselectByVisibleText(stateValue);
    }

    /**
     * Unset default value from StateTerritory Drop Down List field.
     */
    public static void unsetStateTerritoryDropDownListField() {
        unsetStateTerritoryDropDownListField(candidate.getState());
    }

    /**
     * Unset value from StateTerritory Drop Down List field.
     */
    public static void unsetStateTerritoryDropDownListField(String stateterritoryValue) {
        new Select(stateterritory).deselectByVisibleText(stateterritoryValue);
    }

    /**
     * Click on Continue Button.
     */
    public static void clickContinueButton() {
        continueButton.click();
        PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Set default value to Date Of Birth Month Drop Down List field.
     */
    public static void setDobMonthDropDownListField() {
        setDobMonthDropDownListField(candidate.getDobMonth());
    }

    /**
     * Set value to Date Of Birth Month Drop Down List field.
     */
    public static void setDobMonthDropDownListField(String dobMonthValue) {
        SeleniumTest.selectShortMonthByVisibleText(dobMonth, dobMonthValue);
    }

    /**
     * Set default value to Date Of Birth Day Drop Down List field.
     */
    public static void setDobDayDropDownListField() {
        setDobDayDropDownListField(candidate.getDobDay());
    }

    /**
     * Set value to Date Of Birth Drop Down List field.
     */
    public static void setDobDayDropDownListField(String dobDayValue) {
        new Select(dobDay).selectByVisibleText(dobDayValue);
    }

    /**
     * Set default value to Date Of Birth Year Drop Down List field.
     */
    public static void setDobYearDropDownListField() {
        setDobYearDropDownListField(candidate.getDobYear());
    }

    /**
     * Set value to Date Of Birth Year Drop Down List field.
     */
    public static void setDobYearDropDownListField(String dobYearValue) {
        new Select(dobYear).selectByVisibleText(dobYearValue);
    }

    public static void setCandidate(Candidate candidateValue ) {
        candidate = candidateValue;
    }
}
