package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the error/warning pages on the TalentWise Dashboard website
 * that are reached when various issues arise with the information provided at the beginning
 * of the product launching process.
 *
 * @author eelefson
 */
public class ProductFormErrorPage extends ProductFormPages {

    public Header header;
    public Footer footer;

    @FindBy(how = How.XPATH, using = "//input[@value='Cancel']")
    private static WebElement cancelButton;

    @FindBy(how = How.XPATH, using = "//input[@value='Continue']")
    private static WebElement continueButton;

    /**
     * Constructs a new Product Form Error page object.
     */
    public ProductFormErrorPage() {

        this.header = PageFactory.initElements(Driver.getDriver(), Header.class);
        this.footer = PageFactory.initElements(Driver.getDriver(), Footer.class);
    }

    /**
     * Clicks the "Continue" button assuming no further error/warning pages
     * will present themselves.
     *
     * @return A new Review Order page object
     */
    public static ReviewOrderPage clickContinueButton() {
        WaitUntil.clickable(continueButton).click();
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Clicks the "Continue" button initializing the expected page being returned
     *
     * @return A ProductFormPage
     */
    public static ProductFormPages clickContinueButton(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks the "Continue" button assuming at least one further error/warning page
     * will present itself.
     *
     * @return A new Product Form Error page object
     */
    public static ProductFormErrorPage clickContinueButtonExpectingError() {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), ProductFormErrorPage.class);
    }

    /**
     * Clicks the "Cancel" button assuming no further error/warning pages
     * will present themselves.
     *
     * @return A new ProductFormPage
     */
    public static ProductFormPages clickCancelButton(Class<? extends ProductFormPages> returnedClass) {
        cancelButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks the "Continue" button assuming the SSNCouldNotBeVerifiedPage
     * will present itself.
     *
     * @return SSNCouldNotBeVerifiedPage
     */
    public static SSNCouldNotBeVerifiedPage clickContinueButtonExpectingSSNCouldNotBeVerifiedPage() {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), SSNCouldNotBeVerifiedPage.class);
    }
}
