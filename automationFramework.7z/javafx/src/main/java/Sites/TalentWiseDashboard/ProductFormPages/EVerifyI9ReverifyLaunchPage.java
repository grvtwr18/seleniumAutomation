package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Set;

/**
 * Created by jgupta on 11/28/2015.
 */
public class EVerifyI9ReverifyLaunchPage extends I9ReverifyLaunchPages {

    @FindBy(how = How.NAME, using = "qexpmonth")
    public static WebElement monthDropDown;

    @FindBy(how = How.NAME, using = "qexpday")
    public static WebElement dayDropDown;

    @FindBy(how = How.NAME, using = "qexpyear")
    public static WebElement yearDropDown;

    @FindBy(how = How.NAME, using = "qOrigApplicantID")
    public static WebElement previousReportIDTextbox;

    @FindBy(how = How.ID, using = "qverifiergroupid")
    public static WebElement assignedGroup;

    @FindBy(how = How.ID, using = "createNewVerifierBtnqverifierid")
    public static WebElement createNewVerifierButton;

    @FindBy(how = How.ID, using = "fnqverifierid")
    public static WebElement newVerifierFirstNameTextBox;

    @FindBy(how = How.ID, using = "lnqverifierid")
    public static WebElement newVerifierLastNameTextBox;

    @FindBy(how = How.ID, using = "emailqverifierid")
    public static WebElement newVerifierEmailTextBox;

    @FindBy(how = How.CSS, using = "div.title>h1")
    public static WebElement pageHeaderLabel;

    @FindBy(how = How.CSS, using = "div.twentyBelow")
    private static WebElement errorMessage;

    @FindBy(how = How.ID, using = "qverifierid")
    public static WebElement assigneeDropDownLocator;

    @FindBy(how = How.CLASS_NAME, using = "errorBelow")
    private static WebElement errorBelow;

    @FindBy(how = How.CLASS_NAME, using = "twentyBelow")
    private static WebElement existingReportTextElement;
    private static String existingReportText = "There is currently an existing Form I-9 task in progress for this candidate. The existing task(s) must be completed or canceled before you may launch a new Form I-9 task.";

    @FindBy(how = How.XPATH, using = "//a[text()='View existing report.']")
    private static WebElement viewExistinReportLink;

    @FindBy(how = How.XPATH, using = "//a[text()='Cancel existing report.']")
    private static WebElement cancelExistingReportLink;

    @FindBy(how = How.ID, using = "qnewlastname")
    private static WebElement newLastNameBox;

    @FindBy(how = How.ID, using = "qnewfirstname")
    private static WebElement newFirstNameBox;

    @FindBy(how = How.ID, using = "qnewmi")
    private static WebElement newMiddleInitialBox;

    @FindBy(how = How.ID, using = "qrehiremonth")
    private static WebElement rehireMonth;

    @FindBy(how = How.ID, using = "qrehireday")
    private static WebElement rehireDay;

    @FindBy(how = How.ID, using = "qrehireyear")
    private static WebElement rehireYear;

    @FindBy(how = How.ID, using = "qdoctype")
    private static WebElement documentTypeDropdown;

    @FindBy(how = How.NAME, using = "qdocno")
    private static WebElement documentNumberBox;

    @FindBy(how = How.NAME, using = "qexpmonth")
    private static WebElement expirationMonthDropdown;

    @FindBy(how = How.NAME, using = "qexpday")
    private static WebElement expirationDayDropdown;

    @FindBy(how = How.NAME, using = "qexpyear")
    private static WebElement expirationYearDropdown;

    @FindBy(how = How.ID, using = "qcertify")
    private static WebElement iAffirmCheckbox;

    static {
        PageFactory.initElements(Driver.getDriver(), EVerifyI9ReverifyLaunchPage.class);
    }

    /**
     * Verifies the existing report message
     * @return
     */
    public static Boolean verifyExistingReportMessage() {
        return existingReportTextElement.getText().equals(existingReportText);
    }

    /**
     * Checks I Affirm
     */
    public static void checkIAffirm() {
        SeleniumTest.check(iAffirmCheckbox);
    }

    /**
     * Cancels an existing report
     */
    public static void cancelExistingReport() {
        // Store current window handle.
        String windowHandle = Driver.getDriver().getWindowHandle();
        // Click button to open the popup.
        cancelExistingReportLink.click();
        // Switch to the new window.
        WaitUntil.waitUntil(() -> {
            return Driver.getDriver().getWindowHandles().size() > 1;
        });

        Set<String> windowHandles = Driver.getDriver().getWindowHandles();
        for (String newWindowHandle : windowHandles) {
            if (!newWindowHandle.equals(windowHandle)) {
                Driver.getDriver().switchTo().window(newWindowHandle);
            }
        }

        SeleniumTest.waitForElementVisible(By.xpath("//h1[text()='Cancel Form I-9']"));
        WebElement reasonElement = Driver.getDriver().findElement(By.id("cancelcategory"));
        reasonElement.click();
        Select reasonDropDown = new Select(reasonElement);
        reasonDropDown.selectByVisibleText("Other");
        SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id("cancelEVerifyNote")), "Cancelling");
        SeleniumTest.waitForElementToBeClickable(By.id("btnCancelEVerify"));
        Driver.getDriver().findElement(By.id("btnCancelEVerify")).click();

        SeleniumTest.waitForElementToBeClickable(By.id("linkCloseCancelEVerify"));
        Driver.getDriver().findElement(By.id("linkCloseCancelEVerify")).click();

        Driver.getDriver().switchTo().window(windowHandle);
    }

    /**
     * Fills the employee profile section.
     * @param fName
     * @param mName
     * @param lName
     * @param ssn
     * @param month
     * @param day
     * @param year
     * @param previousReportID
     */
    public static void fillEmployeeProfileSection(String fName, String mName, String lName, String ssn, String month, String day, String year, String previousReportID) {
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setFirstName(fName);
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setMiddleInitialOrName(mName);
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setLastName(lName);
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setSocialSecurityNumber(ssn);
    }

    /**
     * Checks for error text
     * @param errorText
     * @return
     */
    public static Boolean checkForErrorText(String errorText) {
        try {
            for(WebElement we : Driver.getDriver().findElements(By.className("errorBelow"))) {
                if(we.getText().equals(errorText)) {
                    return true;
                }
            }
        }
        catch(NoSuchElementException nse) {
            return false;
        }
        return false;
    }

    /**
     * Fills in the Launch Form
     * @param candidate
     * @param date
     */
    public static void fillLaunchForm(Candidate candidate, LocalDate date, String group, String assignee) {
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setFirstName(candidate.getFirstName());
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setMiddleInitialOrName(candidate.getMiddleName());
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setLastName(candidate.getLastName());
        EVerifyI9ReverifyLaunchPage.EmployeeProfile.setSocialSecurityNumber(candidate.getSocialSecurityNumber());
        if(null != date) {
            EmployeeProfile.setReverificationDueDate(date);
        }
        if(null != group) {
            EVerifyI9ReverifyLaunchPage.Verifier.selectAssignedGroup(group);
        }
        if(null != assignee) {
            EVerifyI9ReverifyLaunchPage.Verifier.selectAssignee(assignee);
        }
    }

    /**
     * Fills in the Launch Form with an Expired Document
     * @param candidate candidate to use
     * @param dueDate due Date if any or null if Paper
     * @param previousDocumentExpireDate Previous document expire date
     * @param previousReportID previous report ID
     * @param group the group to assign the task to if NOT Paper null if Paper
     * @param assignee the assignee to assign the task to if NOT Paper null if Paper
     */
    public static void fillLaunchFormWithExpiredDocument(Candidate candidate, LocalDate dueDate, LocalDate previousDocumentExpireDate, Integer previousReportID, String group, String assignee) {

        fillLaunchForm(candidate, dueDate, group, assignee);
    }

    /**
     * Fills in the Launch Form with an Expired Document
     * @param candidate candidate to use
     * @param dueDate due Date if any or null if Paper
     * @param previousReportID previous report ID
     * @param group the group to assign the task to if NOT Paper null if Paper
     * @param assignee the assignee to assign the task to if NOT Paper null if Paper
     */
    public static void fillLaunchFormWithExpiredDocumentPaper(Candidate candidate, LocalDate
            dueDate, Integer previousReportID, String group, String assignee) {

        fillLaunchForm(candidate, dueDate, group, assignee);
    }

    /**
     * Fills the launch form Section 3 for Name Change
     * @param newFirstName
     * @param newLastName
     * @param newMiddleName
     */
    public static void fillLaunchFormSection3PaperPartANameChange(String newFirstName, String newLastName, String newMiddleName) {
        SeleniumTest.clearAndSetText(newFirstNameBox, newFirstName);
        SeleniumTest.clearAndSetText(newLastNameBox, newLastName);
        SeleniumTest.clearAndSetText(newMiddleInitialBox, newMiddleName.substring(0, 1));
    }

    /**
     * Fills the launch form Section 3 Part B for Rehire
     * @param date
     */
    public static void fillLaunchFormSection3PaperPartBRehireDate(LocalDate date) {
        SeleniumTest.selectShortMonthByVisibleText(rehireMonth, date.getMonth().getDisplayName(TextStyle.SHORT, Locale.US));
        SeleniumTest.selectByVisibleTextFromDropDown(rehireDay, Integer.toString(date.getDayOfMonth()));
        SeleniumTest.selectByVisibleTextFromDropDown(rehireYear, Integer.toString(date.getYear()));
    }

    /**
     * Fills the launch form Section 3 Part C
     * @param document
     * @param documentnumber
     * @param date
     */
    public static void fillLaunchFormSection3PaperPartCDocument(DocumentList document, String documentnumber, LocalDate date) {
        SeleniumTest.selectByVisibleTextFromDropDown(documentTypeDropdown, document.toString());
        SeleniumTest.clearAndSetText(documentNumberBox, documentnumber);
        if(null != date) {
            SeleniumTest.selectShortMonthByVisibleText(expirationMonthDropdown, date.getMonth().getDisplayName(TextStyle.SHORT, Locale.US));
            SeleniumTest.selectByVisibleTextFromDropDown(expirationDayDropdown, Integer.toString(date.getDayOfMonth()));
            SeleniumTest.selectByVisibleTextFromDropDown(expirationYearDropdown, Integer.toString(date.getYear()));
        }
    }

    /**
     * Uploads file
     * @param filePath
     * @return
     */
    public static EVerifyI9ReverifyLaunchPage uploadFile(String filePath) {
        iAffirmCheckbox.sendKeys(Keys.TAB);
        Driver.getDriver().switchTo().activeElement().sendKeys(filePath);
        Driver.getDriver().switchTo().defaultContent();
        return PageFactory.initElements(Driver.getDriver(), EVerifyI9ReverifyLaunchPage.class);
    }

    /**
     * Clicks on Continue button
     * @return
     */
    public static ProductFormPages clickContinue() {
         //Click on Continue button to go to next page.
        continueButton.click();

        //Get the page on which customer is and return it.
        String pageHeader = pageHeaderLabel.getText();
        if(pageHeader.equals("Review Your Order"))
            return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        else if(pageHeader.equals("Electronic I9 (Re-Verify)         "))
            return  PageFactory.initElements(Driver.getDriver(), EVerifyI9ReverifyLaunchPage.class);
        else {
            return PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
            }
        }

    /**
     * Clicks on Continue button to go to next page.
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Returns the error message on the page
     * @return
     */
    public static String getErrorMessage() {
        return errorMessage.getText();
    }

    /**
     * Selects value from Assignee drop down
     * @param assigneeName
     */
    public static EVerifyI9ReverifyLaunchPage selectExistingAssignee(String assigneeName) {
        Select assigneeDropDown = new Select(assigneeDropDownLocator);
        assigneeDropDown.selectByVisibleText(assigneeName);
        return PageFactory.initElements(Driver.getDriver(), EVerifyI9ReverifyLaunchPage.class);
    }

    /**
     * enum of List C Documents
     */
    public enum DocumentList {
        USPASSPORT("U.S. Passport"),
        USPASSPORTCARD("U.S. Passport Card"),
        PERMANENTRESIDENTCARD_551("Permanent Resident Card (Form I-551)"),
        ALIENREGISTRATIONCARD_551("Alien Registration Receipt Card (Form I-551)"),
        FPP_551("Unexpired Foreign Passport with I-551 stamp or temporary I-551 printed notation on a MRIV"),
        EMPAUTH_766("Employment Authorization Document (Form I-766)"),
        FPP_I_94("Unexpired Foreign Passport with Form I-94 or Form I-94A"),
        FSM_PASSPORT_I_94("FSM Passport with Form I-94 or Form I-94A"),
        RMI_PASSPORT_I_94("RMI Passport with Form I-94 or Form I-94A"),
        REFUGEESTAMP_I_94("Form I-94 or Form I-94A with Unexpired Refugee Stamp"),
        SOCIALSECURITY_NOTEMPAUTH("Social Security Account Number card not specifying employment not authorized"),
        EMPAUTH_DHS("Employment authorization document issued by the Department of Homeland Security");

        private final String text;

        DocumentList(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
