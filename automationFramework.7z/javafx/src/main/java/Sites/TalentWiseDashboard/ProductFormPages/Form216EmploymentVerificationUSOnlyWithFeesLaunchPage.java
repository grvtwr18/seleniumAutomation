package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.WaitUntil;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by jgupta on 2/16/2016.
 */
public class Form216EmploymentVerificationUSOnlyWithFeesLaunchPage extends ProductFormPages {
    @FindBy(how = How.ID, using = "qfcramanualagree")
    private WebElement iHaveProvidedIndividualDisclosureCheckbox;

    @FindBy(how = How.ID, using = "qfcraedagree")
    private WebElement sendElectronicDisclosureAtEmailCheckbox;

    @FindBy(how = How.ID, using = "qf")
    private WebElement firstNameTextBox;

    @FindBy(how = How.ID, using = "qmi")
    private WebElement middleNameTextBox;

    @FindBy(how = How.ID, using = "qn")
    private WebElement lastNameTextBox;

    @FindBy(how = How.ID, using = "govtId-value-text")
    private WebElement ssnTextBox;

    @FindBy(how = How.ID, using = "qp")
    private WebElement phoneTextBox;

    @FindBy(how = How.ID, using = "btnSubmit")
    private WebElement continueButton;

    @FindBy(how = How.ID, using = "spanAdd_Group39")
    private WebElement addEmploymentVerificationLink;

    /**
     * Checks the checkbox for "I have provided the individual a disclosure and received the individual’s written authorization for the report." option
     */
    public void checkIHaveProvidedTheIndividualDisclosureCheckbox() {
        iHaveProvidedIndividualDisclosureCheckbox.click();
    }

    /**
     * Types first name of candidate
     *
     * @param firstName
     */
    public void typeFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameTextBox, firstName);
    }

    /**
     * Types middle name of candidate
     *
     * @param middleName
     */
    public void typeMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameTextBox, middleName);
    }

    /**
     * Types last name of candidate
     *
     * @param lastName
     */
    public void typeLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameTextBox, lastName);
    }

    /**
     * Types ssn of candidate
     *
     * @param socialSecurityNumber
     */
    public void typeSSN(String socialSecurityNumber) {
        SeleniumTest.clearAndSetText(ssnTextBox, socialSecurityNumber);
    }

    /**
     * Types phone number of the candidate
     *
     * @param candidatePhone
     */
    public void typePhoneNumber(String candidatePhone) {
        phoneTextBox.click();
        phoneTextBox.sendKeys(candidatePhone);
    }

    /**
     * Types employer name
     *
     * @param employerNumber
     * @param employerName
     */
    public void typeEmployerName(String employerNumber, String employerName) {
        WebElement employerNameTxtBox = Driver.getDriver().findElement(By.id("qcn_Group39_" +
                                                                             employerNumber));
        SeleniumTest.clearAndSetText(employerNameTxtBox, employerName);
    }

    /**
     * Types phone number
     *
     * @param employerNumber
     * @param phoneNumber
     */
    public void typeEmployerPhoneNumber(String employerNumber, String phoneNumber) {
        WebElement phoneTextBox = Driver.getDriver().findElement(By.name("qcp_Group39_" + employerNumber));
        SeleniumTest.clearAndSetText(phoneTextBox, phoneNumber);
    }

    /**
     * Types Employer City
     *
     * @param employerNumber
     * @param employerCity
     */
    public void typeEmployerCity(String employerNumber, String employerCity) {
        WebElement employerCityTextBox = Driver.getDriver().findElement(By.name("qcc_Group39_" + employerNumber));
        SeleniumTest.clearAndSetText(employerCityTextBox, employerCity);
    }

    /**
     * Selects Employee state
     *
     * @param employerNumber
     * @param state
     */
    public void selectEmployerState(String employerNumber, String state) {
        Select employeeStateDropDown = new Select(Driver.getDriver().findElement(By.name("qcs_Group39_" + employerNumber)));
        employeeStateDropDown.selectByVisibleText(state);
    }

    /**
     * Types job title
     *
     * @param employerNumber
     * @param jobTitle
     */
    public void typeJobTitle(String employerNumber, String jobTitle) {
        WebElement jobTitleTextBox = Driver.getDriver().findElement(By.name("qjt_Group39_" + employerNumber));
        SeleniumTest.clearAndSetText(jobTitleTextBox, jobTitle);
    }

    /**
     * Selects reason for leaving
     *
     * @param employerNumber
     * @param reasonForLeaving
     */
    public void selectReasonForLeaving(String employerNumber, String reasonForLeaving) {
        Select reasonForLeavingDropDown = new Select(Driver.getDriver().findElement(By.id("qjrfl_Group39_" + employerNumber)));
        reasonForLeavingDropDown.selectByVisibleText(reasonForLeaving);
    }

    /**
     * Selects start date month
     *
     * @param employerNumber
     * @param startDateMonth
     */
    public void selectStartDateMonth(String employerNumber, String startDateMonth) {
        SeleniumTest.selectShortMonthByVisibleText(
                Driver.getDriver().findElement(By.id("qjstmm_Group39_" + employerNumber)),
                startDateMonth);
    }

    /**
     * Selects start date year
     *
     * @param employerNumber
     * @param startDateYear
     */
    public void selectStartDateYear(String employerNumber, String startDateYear) {
        Select startYearDropDown = new Select(Driver.getDriver().findElement(By.id("qjstyy_Group39_" + employerNumber)));
        startYearDropDown.selectByVisibleText(startDateYear);
    }

    /**
     * Select end date month
     *
     * @param employerNumber
     * @param endDateMonth
     */
    public void selectEndDateMonth(String employerNumber, String endDateMonth) {
        SeleniumTest.selectShortMonthByVisibleText(
                Driver.getDriver().findElement(By.id("qjendmm_Group39_" + employerNumber)),
                endDateMonth);
    }

    /**
     * Select end date year
     *
     * @param employerNumber
     * @param endDateYear
     */
    public void selectEndDateYear(String employerNumber, String endDateYear) {
        Select endYearDropDown = new Select(Driver.getDriver().findElement(By.id("qjendyy_Group39_" + employerNumber)));
        endYearDropDown.selectByVisibleText(endDateYear);
    }

    /**
     * Check checkbox for Employment Verification
     *
     * @param employerNumber
     */
    public void checkEmploymentVerificationCheckBox(String employerNumber) {
        WebElement employmentVerificationCheckBox = Driver.getDriver().findElement(By.id
                ("qshow_Group39_" + employerNumber));
        WaitUntil.waitUntil(() -> employmentVerificationCheckBox.isEnabled());
        SeleniumTest.waitForPageLoadToComplete();
        employmentVerificationCheckBox.click();
    }

    /**
     * Check checkbox for Same as current
     *
     * @param employerNumber
     */
    public void checkSameAsCurrentCheckbox(String employerNumber) {
        WebElement sameAsCurrentCheckBox = Driver.getDriver().findElement(By.id("sameascurrent_Group39_" + employerNumber));
        sameAsCurrentCheckBox.click();
    }

    /**
     * Clicks on Continue button
     *
     * @return
     */
    public ReviewOrderPage clickContinueButton() {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Fills candidate Profile Section
     *
     * @param firstName
     * @param middleName
     * @param lastName
     * @param ssn
     * @param phone
     */
    public void fillCandidateProfileSection(String firstName, String middleName, String lastName, String ssn, String phone) {
        typeFirstName(firstName);
        typeMiddleName(middleName);
        typeLastName(lastName);
        typeSSN(ssn);
        typePhoneNumber(phone);
    }

    /**
     * Fills Employment Verification Details
     *
     * @param employerNumber
     * @param employerName
     * @param employerPhoneNumber
     * @param employerCity
     * @param employerState
     * @param jobTitle
     * @param reasonFroLeaving
     * @param startDateMonth
     * @param startDateYear
     * @param endDateMonth
     * @param endDateYear
     */
    public void fillEmploymentVerificationDetails(String employerNumber, String employerName, String employerPhoneNumber, String employerCity, String employerState, String jobTitle,
                                                  String reasonFroLeaving, String startDateMonth, String startDateYear, String endDateMonth, String endDateYear) {
        typeEmployerName(employerNumber, employerName);
        typeEmployerPhoneNumber(employerNumber, employerPhoneNumber);
        typeEmployerCity(employerNumber, employerCity);
        selectEmployerState(employerNumber, employerState);
        typeJobTitle(employerNumber, jobTitle);
        selectReasonForLeaving(employerNumber, reasonFroLeaving);
        selectStartDateMonth(employerNumber, startDateMonth);
        selectStartDateYear(employerNumber, startDateYear);
        selectEndDateMonth(employerNumber, endDateMonth);
        selectEndDateYear(employerNumber, endDateYear);
        checkSameAsCurrentCheckbox(employerNumber);
    }

    /**
     * Clicks on Add Employment Verification link.
     * uses a specific group number; if other numbers are needed they will
     * have to be passed in
     */
    public void clickAddEmploymentVerificationLink() {
      addEmploymentVerificationLink.click();
    }
}
