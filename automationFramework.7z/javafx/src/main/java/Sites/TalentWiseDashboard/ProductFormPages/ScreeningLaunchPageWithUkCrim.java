package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.CandidatePortal.Enums.Country;
import Sites.CandidatePortal.Enums.Month;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;


public class ScreeningLaunchPageWithUkCrim extends ScreeningLaunchPage {

    public enum CandidateTitle {
        BARON("Baron"),
        BARONESS("Baroness"),
        BRIGADIER("Brigadier"),
        CANON("Canon"),
        CAPTAIN("Captain"),
        DR("DR"),
        DUCHESS("Duchess"),
        DUKE("Duke"),
        ESQ("Esq."),
        FATHER("Father"),
        HON("Hon"),
        INSPECTOR("Inspector"),
        LADY("Lady"),
        LORD("Lord"),
        LTCOL("Lt. Col."),
        MAJOR("Major"),
        MASTER("Master"),
        MISS("MISS"),
        MOSTREVEREND("Most Reverend"),
        MR("MR"),
        MRS("Mrs."),
        MX("Mx."),
        PASTOR("Pastor"),
        PROFESSPR("Professor"),
        RABBI("Rabbi"),
        REVDR("Rev Dr"),
        REVEREND("Reverend"),
        RIGHTREVEREND("Right Reverend"),
        SIR("Sir"),
        SISTER("Sister"),
        SQUADRONLDR("Squadron Ldr"),
        WGCGR("Wg Cgr"),
        OTHER("Other");

        private String value;

        CandidateTitle(String value) {
            this.value = value;
        }

        String getValue() {
            return value;
        }

        public static CandidateTitle parse(String input) {
            for(CandidateTitle candidateTitle : values()) {
                if (candidateTitle.getValue().equalsIgnoreCase(input)) {
                    return candidateTitle;
                }
            }

            return null;
        }
    }

    static {
        PageFactory.initElements(Driver.getDriver(), ScreeningLaunchPageWithEduVerif.class);
    }

    // This number seems to change from one Screening Launch Page to the next.
    private static int groupId = 0; // Call discoverAndSetEduGroupId() to set this when the page shows.

    /**
     * Fills candidate Profile Section
     *
     * @param firstName
     * @param middleName
     * @param lastName
     * @param phone
     */
    public static void fillCandidateProfileSection(String firstName, String middleName, String lastName, String phone) {
        typeFirstName(firstName);
        typeMiddleName(middleName);
        typeLastName(lastName);
        typePhoneNumber(phone);
    }

    // Get & Set Methods:

    public static void selectCandidateTitleDropDown(CandidateTitle candidateTitle) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qtitle"), candidateTitle.getValue());
    }

    public static void setResidenceHistoryAddressLine1(String address) {
        SeleniumTest.clearAndSetText(By.name("qa"), address);
    }

    public static String getResidenceHistoryAddressLine1() {
        return SeleniumTest.getTextByLocator(By.name("qa"));
    }

    public static void setResidenceHistoryAddressLine2(String address) {
        SeleniumTest.clearAndSetText(By.name("qa2"), address);
    }

    public static String getResidenceHistoryAddressLine2() {
        return SeleniumTest.getTextByLocator(By.name("qa2"));
    }

    public static void setResidenceHistoryCity(String city) {
        SeleniumTest.clearAndSetText(By.id("qc"), city);
    }

    public static String getResidenceHistoryCity() {
        return Driver.getDriver().findElement(By.id("qs")).getAttribute("value");
    }

    public static void setResidenceHistoryCounty(String county) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qs"), "" + county);
    }

    public static String getResidenceHistoryCounty() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qs"));
    }

    public static void setResidenceHistoryPostalCode(String postal) {
        SeleniumTest.clearAndSetText(By.id("qz"), postal);
    }

    public static String getResidenceHistoryPostalCode() {
        return Driver.getDriver().findElement(By.id("qz")).getAttribute("value");
    }

    public static Month getLivedHereMonthFromDropDown() {
        return Month.parse(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qresfrommonth")));
    }

    public static void selectLivedHereMonthDropDown(Month month) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qresfrommonth"), "" + month.abbreviation());
    }

    public static int getLivedHereYearFromDropDown() {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qresfrommonth")));
    }

    public static void selectLivedHereYearDropDown(int year) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qresfromyear"), "" + year);
    }

    public static void setIdVerificationsTownCityBirth(String townCityBirth) {
        SeleniumTest.clearAndSetText(By.id("qcbirth_Group1095-0_1"), townCityBirth);
    }

    public static String getIDVerificationsTownCityBirth() {
        return Driver.getDriver().findElement(By.id("qcbirth_Group1095-0_1")).getAttribute("value");
    }

    public static void selectHaveNationalInsuranceNumber(String text) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.name("qhasnin_Group1095-0_1"), text);
    }

    public static void setIdVerificationsNin(String text) {
        SeleniumTest.clearAndSetText(By.name("qnin_Group1095-0_1"), text);
    }

    public static String getIDVerificationsNin() {
        return Driver.getDriver().findElement(By.name("qnin_Group1095-0_1")).getAttribute("value");
    }

    public static void selectKnowDbsProfileId(String text) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.name("qhasdbs_Group1095-0_1"), text);
    }

    public static void setDbsProfileId(String text) {
        SeleniumTest.clearAndSetText(By.name("qdbsn_Group1095-0_1"), text);
    }

    public static void attachUkEnhancedDisclosureFileIdDocumentOne(String canonicalPath) {
        WebElement fileChooser = Driver.getDriver().findElement(By.id("file_document_1_Group1095-0_1"));
        fileChooser.sendKeys(canonicalPath);
    }

    public static int getIdVerGenderDropDown() {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qgender_Group1095-0_1")));
    }

    public static void selectIdVerGenderDropDown(String gender) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qgender_Group1095-0_1"), gender);
    }

    public static int getIdVerCurrentNationalityDropDown() {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qcurrnational_Group1095-0_1")));
    }

    public static void selectIdVerCurrentNationalityDropDown(Country nationality) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qcurrnational_Group1095-0_1"), nationality.toString());
    }

    public static int getIdVerCountryOfBirthDropDown() {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qobirth_Group1095-0_1")));
    }

    public static void selectIdVerCountryOfBirthDropDown(Country country) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qobirth_Group1095-0_1"), country.toString());
    }

    public static int getIdVerCandidateHasChangedNationalityDropDown() {
        return Integer.parseInt(SeleniumTest.getSingleSelectedVisibleTextFromDropDown(By.id("qnationalchange_Group1095-0_1")));
    }

    public static void selectIdVerCandidateHasChangedNationalityDropDown(boolean nationalityChange) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qnationalchange_Group1095-0_1"), nationalityChange ? "1" : "0");
    }

    public static void clickContinue() {
        SeleniumTest.click(By.id("btnSubmit"));
    }

    public static void setCountryRegion(Country country) {
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("qo"), country.toString());
    }

    public static Country getCountryRegion(int index) {
        WebElement element = Driver.getDriver().findElement(By.id("qo_Group" + groupId + "-0_" + index));
        String country = SeleniumTest.getSingleSelectedVisibleTextFromDropDown(element);
        return Country.parse(country);
    }

    // Verifiers:

    public static void verifyDbsErrorBelowMessage(String text) {
        SeleniumTest.verifyAttributePresent(Driver.getDriver().findElement(By.xpath("//div[@id='dbsNumberInput']/div/span[@class='errorBelow']")),text);
    }

}
