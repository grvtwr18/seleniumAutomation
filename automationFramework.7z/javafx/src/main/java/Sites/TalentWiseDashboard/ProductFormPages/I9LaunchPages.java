package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import Workflows.CoreI9.StandardI9Workflows;
import Workflows.HelperObjects.I9;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by abrackett on 8/9/16.
 */
public class I9LaunchPages extends LaunchFormPages {

    private static final Logger staticLogger = LoggerFactory
            .getLogger(I9LaunchPages.class.getName());

    @FindBy(how = How.ID_OR_NAME, using = "qee")
    protected static WebElement emailAddressTextBox;

    static {
        PageFactory.initElements(Driver.getDriver(), I9LaunchPages.class);
    }

    public static class WorkFlows {

        static {
            PageFactory.initElements(Driver.getDriver(), I9LaunchPages.WorkFlows.class);
        }


        public static final String WORKFLOW_TYPE_NAME_CHANGE = "namechange";
        public static final String WORKFLOW_TYPE_REVERIFICATION = "docreverification";

        /**
         * Chooses the Remote Radio Button
         */
        public static void chooseRemoteRadioButton() {
            WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("qworkflow1")).isDisplayed());
            Driver.getDriver().findElement(By.id("qworkflow1")).click();
            staticLogger.info("Launch Page Remote Radio Button Chosen");
        }

        /**
         * Chooses the In Person Radio Button
         */
        public static void chooseInPersonRadioButton() {
            WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("qworkflow2")).isDisplayed());
            Driver.getDriver().findElement(By.id("qworkflow2")).click();
            staticLogger.info("Launch Page in Person Radio Button Chosen");
        }

        public static void clickPreparerClickHereLink() {
            chooseRemoteRadioButton();
            //TODO replace this.  It's currently only being used in a disabled test case
            WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.linkText("click here")).isDisplayed());
            Driver.getDriver().findElement(By.linkText("click here")).click();
            staticLogger.info("Launch Page preparer link clicked");
        }

        public static void chooseReverification() {
            WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("qworkflow1")).isDisplayed());
            Driver.getDriver().findElement(By.id("qworkflow1")).click();
            staticLogger.info("Launch Page Reverification Option Chosen");
        }

        public static void chooseUpdateFormI9() {
            WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("qworkflow2")).isDisplayed());
            Driver.getDriver().findElement(By.id("qworkflow2")).click();
            staticLogger.info("Launch Page Update Form I-9 Option Chosen");
        }

        public static void waitForRemoteRadioIsDisaplyed() {
            WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("qworkflow1")).isDisplayed());
        }
    }

    public static class Preparer {

        @FindBy(how = How.ID, using = "qpreparerfn")
        protected static WebElement preparerFirstNameTextBox;

        @FindBy(how = How.ID, using = "qpreparerln")
        protected static WebElement preparerLastNameTextBox;

        @FindBy(how = How.ID, using = "qprepareremail")
        protected static WebElement preparerEmailTextBox;

        static {
            PageFactory.initElements(Driver.getDriver(), Preparer.class);
        }

        /**
         * Retrieves the preparer last name as shown in the text box
         * @return String representation of the preparer last name
         */
        public static String getPreparerLastName() {
            return preparerLastNameTextBox.getText();
        }

        /**
         * Sets the preparer last name
         * @param preparerLastName preparer last name to set
         */
        public static void setPreparerLastName(String preparerLastName) {
            SeleniumTest.clearAndSetText(preparerLastNameTextBox, preparerLastName);
        }

        /**
         * Retrieves the preparer first name as shown in the text box
         * @return String representation of the preparer first name
         */
        public static String getPreparerFirstName() {
            return preparerFirstNameTextBox.getText();
        }

        /**
         * Sets the preparer first name
         * @param preparerFirstName preparer first name to set
         */
        public static void setPreparerFirstName(String preparerFirstName) {
            SeleniumTest.clearAndSetText(preparerFirstNameTextBox, preparerFirstName);
        }

        /**
         * Retrieves the preparer email as shown in the text box
         * @return String representation of the preparer email
         */
        public static String getPreparerEmail() {
            return preparerEmailTextBox.getText();
        }

        /**
         * Sets the preparer email
         * @param preparerEmail preparer email to set
         */
        public static void setPreparerEmail(String preparerEmail) {
            SeleniumTest.clearAndSetText(preparerEmailTextBox, preparerEmail);
        }
    }

    public static class EmployeeProfile {

        @FindBy(how = How.NAME, using = "qn")
        protected static WebElement lastNameTextBox;

        @FindBy(how = How.ID, using = "qf")
        protected static WebElement firstNameTextBox;

        @FindBy(how = How.CSS, using = "input[id^='qmi']")
        protected static WebElement middleInitialOrNameTextBox;

        @FindBy(how = How.NAME, using = "qstartmonth")
        protected static WebElement startMonthDropDown;

        @FindBy(how = How.NAME, using = "qstartday")
        protected static WebElement startDayDropDown;

        @FindBy(how = How.NAME, using = "qstartyear")
        protected static WebElement startYearDropDown;

        @FindBy(how = How.ID_OR_NAME, using = "qssn")
        protected static WebElement ssnTextBox;

        @FindBy(how = How.ID_OR_NAME, using = "dp_qi9duedate")
        protected static WebElement dueDateVisibleBox;

        @FindBy(how = How.ID_OR_NAME, using = "qi9duedate")
        protected static WebElement dueDateHiddenBox;

        @FindBy(how = How.ID_OR_NAME, using = "dp_qexpdate")
        protected static WebElement prevDocExpVisibleDate;

        @FindBy(how = How.ID_OR_NAME, using = "qexpdate")
        protected static WebElement prevDocExpHiddenDate;

        static {
            PageFactory.initElements(Driver.getDriver(), EmployeeProfile.class);
        }

        /**
         * Retrieves the last name as shown in the text box
         * @return String representation of the last name
         */
        public static String getLastName() {
            return lastNameTextBox.getText();
        }

        /**
         * Sets the last name
         * @param lastName last name to set
         */
        public static void setLastName(String lastName) {
            if(!lastNameTextBox.getText().equals(lastName)) {
                SeleniumTest.clearAndSetText(lastNameTextBox, lastName);
            }
        }

        /**
         * Retrieves the first name as shown in the text box
         * @return String representation of the first name
         */
        public static String getFirstName() {
            return firstNameTextBox.getText();
        }

        /**
         * Sets the first name
         * @param firstName first name to set
         */
        public static void setFirstName(String firstName) {
            if(!firstNameTextBox.getText().equals(firstName)) {
                SeleniumTest.clearAndSetText(firstNameTextBox, firstName);
            }
        }

        /**
         * Retrieves the middle initial or name as shown in the text box
         * @return String representation of the middle initial or name
         */
        public static String getMiddleInitialOrName() {
            return middleInitialOrNameTextBox.getText();
        }

        /**
         * Sets the middle initial or name
         * @param middleInitialOrName middle initial or name to set
         */
        public static void setMiddleInitialOrName(String middleInitialOrName) {
            if(!middleInitialOrNameTextBox.getAttribute("value").equals(middleInitialOrName)) {
                SeleniumTest.clearAndSetText(middleInitialOrNameTextBox, middleInitialOrName);
            }
        }

        /**
         * Selects the month from the drop down
         * @param date LocalDate of the Month to set
         */
        public static void selectStartMonth(LocalDate date) {
            SeleniumTest.selectShortMonthByVisibleText(startMonthDropDown, date);
        }

        /**
         * Selects the month from the drop down
         * @param month String of the Month to set
         */
        public static void selectStartMonth(String month) {
            SeleniumTest.selectShortMonthByVisibleText(startMonthDropDown, month);
        }

        /**
         * Selects the day of month from the drop down
         * @param date LocalDate of the Day to set
         */
        public static void selectStartDay(LocalDate date) {
            SeleniumTest.selectByVisibleTextFromDropDown(startDayDropDown, Integer.toString(date.getDayOfMonth()));
        }

        /**
         * Selects the day of month from the drop down
         * @param day String of the Day to set
         */
        public static void selectStartDay(String day) {
            SeleniumTest.selectByVisibleTextFromDropDown(startDayDropDown, day);
        }

        /**
         * Selects the year from the drop down
         * @param date LocalDate of the Year to set
         */
        public static void selectStartYear(LocalDate date) {
            SeleniumTest.selectByVisibleTextFromDropDown(startYearDropDown, Integer.toString(date.getYear()));
        }

        public static WebElement getStartYearElement() {
            return startYearDropDown;
        }

        /**
         *
         * @param dropDown
         * @return
         */
        public static String getLastOptionInDropDown(WebElement dropDown) {
            SeleniumTest.defaultWaitForElementWithMultiplier(1);
            return dropDown.findElement(By.cssSelector(":last-child")).getText();
        }

        /**
         * Selects the year from the drop down
         * @param year String of the Year to set
         */
        public static void selectStartYear(String year) {
            SeleniumTest.selectByVisibleTextFromDropDown(startYearDropDown, year);
        }

        /**
         * Retrieves the Start date as shown in the Start Date drop downs
         * @return LocalDate representation of the Start Date
         */
        public static LocalDate getStartDateViaMonthDayYearDropDown() {
            Select monthDD = new Select(startMonthDropDown);
            String month = monthDD.getFirstSelectedOption().getText();

            Select dayDD = new Select(startDayDropDown);
            String day = dayDD.getFirstSelectedOption().getText();

            Select yearDD = new Select(startYearDropDown);
            String year = yearDD.getFirstSelectedOption().getText();

            return LocalDate.of(
                    Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
        }

        /**
         * Sets the Start Date
         * @param date LocalDate representation of ths start date to set
         */
        public static void setStartDateViaMonthDayYearDropDown(LocalDate date) {
            selectStartMonth(date);
            selectStartDay(date);
            selectStartYear(date);
        }

        /**
         * Fills the entire employee profile section
         * @param candidate Candidate object to use for setting all values
         */
        public static void fillEmployeeProfileSection(Candidate candidate) {
            fillEmployeeProfileSectionUsingCustomI9Object(candidate, candidate.getStartDate());
        }

        public static void fillDueDate(LocalDate dueDate) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                    dueDate, dueDateVisibleBox.getAttribute("id"),
                    dueDateHiddenBox.getAttribute("id"));
            staticLogger.info("Due Date set to  {}",
                              dueDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        }

        public static void fillPreviousDocExpDate(LocalDate prevExpDate)
        {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                    prevExpDate, prevDocExpVisibleDate.getAttribute("id"),
                    prevDocExpHiddenDate.getAttribute("id"));
            staticLogger.info("Due Date set to  {}", prevExpDate.format(
                    DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        }

        /**
         * Fills the entire employee profile section
         * @param firstName First Name
         * @param middleInitialOrName Middle name or Initial
         * @param lastName Last Name
         * @param month Month
         * @param day day
         * @param year year
         */
        public static void fillEmployeeProfileSection(String firstName, String middleInitialOrName, String lastName, String month, String day, String year) {
            setFirstName(firstName);
            setMiddleInitialOrName(middleInitialOrName);
            setLastName(lastName);
            selectStartMonth(month);
            selectStartDay(day);
            selectStartYear(year);
        }

        public static void fillEmployeeProfileSectionUsingCustomI9Object(Candidate candidate, LocalDate startDate) {
            I9 i9 = new  I9(
                    StandardI9Workflows.I9FormType
                            .EVERIFY_ELECTRONIC_I_9_REHIRE_650.toString(),
                    StandardI9Workflows.I9FormType
                            .EVERIFY_ELECTRONIC_I_9_REHIRE_650.getReturnedClass())
                    .setStartDate(startDate);
            fillEmployeeProfileSection(candidate, i9);
        }

        /**
         * Fills the employee profile section on I9 Launch page.
         * @param candidate
         * @param i9
         */
        public static void fillEmployeeProfileSection(Candidate candidate, I9 i9) {
            setFirstName(candidate.getFirstName());
            setMiddleInitialOrName(candidate.getMiddleName());
            setLastName(candidate.getLastName());
            if (!i9.location.equals(I9.Location.REVERIFY)
                    && !i9.location.equals(I9.Location.REHIRE)) {
                setStartDateViaMonthDayYearDropDown(i9.startDate);
            } else {
                if (!i9.location.equals(I9.Location.REHIRE)) {
                    I9ReverifyLaunchPages.EmployeeProfile.setReverificationDueDate(i9.startDate);
                }
            }
        }


        /**
         * Sets the SSN
         * @param ssn SSN to set
         */
        public static void setSocialSecurityNumber(String ssn) {
            SeleniumTest.clearAndSetText(ssnTextBox, ssn);
        }
    }

    public static class OrderTracking {

        @FindBy(how = How.ID, using = "billingcode")
        private static WebElement billingCodeDropDown;

        @FindBy(how = How.ID, using = "refcode")
        private static WebElement refCodeDropDown;

        @FindBy(how = How.ID, using = "refcodehierarchy_1")
        private static WebElement refCodeHierarchy1DropDown;

        @FindBy(how = How.ID, using = "refcodehierarchy_2")
        private static WebElement refCodeHierarchy2DropDown;

        @FindBy(how = How.ID, using = "refcodehierarchy_3")
        private static WebElement refCodeHierarchy3DropDown;

        static {
            PageFactory.initElements(Driver.getDriver(), OrderTracking.class);
        }

        public static void selectBillingCode(String billCode) {
            Select select = new Select(billingCodeDropDown);
            select.selectByVisibleText(billCode);
        }

        public static void selectRefCode(String refCode) {
            Select select = new Select(refCodeDropDown);
            select.selectByVisibleText(refCode);
        }

        public static void selectRefCodeHierarchy1(String option) {
            Select select = new Select(refCodeHierarchy1DropDown);
            select.selectByVisibleText(option);
        }

        public static void selectRefCodeHierarchy2(String option) {
            Select select = new Select(refCodeHierarchy2DropDown);
            select.selectByVisibleText(option);
        }

        public static void selectRefCodeHierarchy3(String option) {
            Select select = new Select(refCodeHierarchy3DropDown);
            select.selectByVisibleText(option);
        }
    }

    public static class Verifier {

        @FindBy(how = How.ID, using = "qverifiergroupid")
        protected static WebElement assignedGroupDropDown;

        @FindBy(how = How.ID, using = "qverifiergroupid2")
        protected static WebElement assignedGroupDropDown1;

        @FindBy(how = How.ID, using = "qverifierid")
        protected static WebElement assigneeDropDown;

        @FindBy(how = How.ID, using = "qverifierid2")
        protected static WebElement assigneeDropDown1;

        @FindBy(how = How.ID, using = "createNewVerifierBtnqverifierid")
        protected static WebElement createNewVerifierButton;

        @FindBy(how = How.ID, using = "fnqverifierid")
        protected static WebElement newVerifierFirstNameTextBox;

        @FindBy(how = How.ID, using = "lnqverifierid")
        protected static WebElement newVerifierLastNameTextBox;

        @FindBy(how = How.ID, using = "emailqverifierid")
        protected static WebElement newVerifierEmailTextBox;

        @FindBy(how = How.XPATH, using = "//input[@value='Save Changes']")
        protected static  WebElement btnSaveChanges;

        static {
            PageFactory.initElements(Driver.getDriver(), Verifier.class);
        }

        /**
         * Selects the Assigned Group from the drop down
         * @param groupName The group to select
         */
        public static void selectAssignedGroup(String groupName) {
            Select assignedGroupDropDown = new Select(Verifier.assignedGroupDropDown);
            assignedGroupDropDown.selectByVisibleText(groupName);
            staticLogger.info("Assigned Group is {}", groupName);
        }

        public static void selectAssignedGroup1(String groupName) {
            Select assignedGroupDropDown = new Select(Verifier.assignedGroupDropDown1);
            assignedGroupDropDown.selectByVisibleText(groupName);
            staticLogger.info("Assigned Group is {}", groupName);
        }

        /**
         * Selects the Assignee from the drop down
         * @param assigneeNameAndEmail The assignee name and email to select
         */
        public static void selectAssignee(String assigneeNameAndEmail) {
            SeleniumTest.selectByVisibleTextFromDropDown(assigneeDropDown, assigneeNameAndEmail);
            staticLogger.info("Assignee is {}", assigneeNameAndEmail);
        }

        public static void selectAssignee1(String assigneeNameAndEmail) {
            SeleniumTest.selectByVisibleTextFromDropDown(assigneeDropDown1, assigneeNameAndEmail);
            staticLogger.info("Assignee is {}", assigneeNameAndEmail);
        }

        /**
         * Selects the Assignee from the drop down
         * @param assigneeName Assignee name
         * @param assigneeEmail Assignee email
         */
        public static void selectAssignee(String assigneeName, String assigneeEmail) {
            SeleniumTest.selectByVisibleTextFromDropDown(assigneeDropDown, assigneeName + " (" + assigneeEmail + ")");
        }

        /**
         * Clicks on the Create New Contributor Button
         */
        public static void clickCreateNewVerifierButton() {
            createNewVerifierButton.click();
        }

        /**
         * Sets the new Assignee First Name
         * @param verifierFirstName First name to set
         */
        public static void setAssigneeFirstName(String verifierFirstName) {
            newVerifierFirstNameTextBox.sendKeys(verifierFirstName);
        }

        /**
         * Sets the new Assignee Last Name
         * @param verifierLastName Last Name to set
         */
        public static void setAssigneeLastName(String verifierLastName) {
            newVerifierLastNameTextBox.sendKeys(verifierLastName);
        }

        /**
         * Sets the new Assignee email Address
         * @param verifierEmailAddress email Address to set
         */
        public static void setAssigneeEmailAddress(String verifierEmailAddress) {
            newVerifierEmailTextBox.sendKeys(verifierEmailAddress);
            newVerifierEmailTextBox.sendKeys(Keys.TAB);
        }

        public static  void clickSaveChangesButton(){
            btnSaveChanges.click();
            SeleniumTest.waitMs(3000);
        }

        public static boolean assigneeListHavingUser(String assigneeNameAndEmail) {
            boolean flag = false;
            if(SeleniumTest.isElementWithContainingTextInDropDown(assigneeDropDown, assigneeNameAndEmail)){
                staticLogger.info("Assignee is {}", assigneeNameAndEmail);
                return flag = true;
            }
            staticLogger.info("Assignee is {}", assigneeNameAndEmail);
            return flag;
        }
    }

    public static class Navigation extends Sites.TalentWiseDashboard.ProductFormPages.Navigation {

    }


}
