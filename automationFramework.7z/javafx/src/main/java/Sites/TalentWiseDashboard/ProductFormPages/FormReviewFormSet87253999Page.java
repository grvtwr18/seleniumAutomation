package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.List;

/**
 * Created by jgupta on 8/29/2015.
 */
public class FormReviewFormSet87253999Page extends LaunchFormPages {

    public Header header;
    public Footer footer;

    public static final String fillAndSignFormDataTestLocatorString = "qduedate1";
    @FindBy(how = How.ID, using = "dp_" + fillAndSignFormDataTestLocatorString)
    public static WebElement fillAndSignFormDataTestDueDate;

    @FindBy(how = How.CSS, using = "table.taskstable tbody tr td select#qverifiergroupid2")
    public static WebElement reviewFormDataTestGroup;

    @FindBy(how = How.ID, using = "qverifierid2")
    public static WebElement reviewFormDataTestReviewer;

    public static final String reviewFormDataTestDueDateLocatorString = "qduedate2";
    @FindBy(how = How.ID, using = "dp_" + reviewFormDataTestDueDateLocatorString)
    public static WebElement reviewFormDataTestDueDate;

    @FindBy(how = How.ID, using = "qverifiergroupid3")
    public static WebElement reviewReviewersFormDataTestGroup;

    @FindBy(how = How.ID, using = "qverifierid3")
    public static WebElement reviewReviewersFormDataTestReviewer;

    public static final String reviewReviewersFormDataTestDueDateLocatorString = "qduedate3";
    @FindBy(how = How.ID, using = "dp_" + reviewReviewersFormDataTestDueDateLocatorString)
    public static WebElement reviewReviewersFormDataTestDueDate;

    @FindBy(how = How.CSS, using = "div.title>h1")
    public static WebElement pageHeaderLabel;

    @FindBy(how = How.ID, using = "showEmail")
    private WebElement showEmail;

    By errorBelowLocator = By.xpath("//div[contains(text(), 'roup')]");
    By qmailNoSendLocator = By.id("qmailnosend");

    /**
     * Constructs a new Form Review Formset 87253999 Page page object.
     */
    public FormReviewFormSet87253999Page() {
        //The title of this page is "Custom Package - TalentWise"

        this.header = PageFactory.initElements(Driver.getDriver(), Header.class);
        this.footer = PageFactory.initElements(Driver.getDriver(), Footer.class);
    }

    /**
     * This method fills the form review form set 87253999
     *
     * @param localDate
     * @param verifier1Group
     * @param verifier1
     * @param verifier1DueDate
     * @param verifier2Group
     * @param verifier2
     * @param verifier2DueDate
     * @return page
     */
    public static ProductFormPages fillFormReviewFormSet87253999(LocalDate localDate, String verifier1Group, String verifier1, LocalDate verifier1DueDate, String verifier2Group, String verifier2, LocalDate verifier2DueDate) {

        //Type Due date for Fill and Sign Form Data Test
        setFillAndSignFormDataTestDueDate(localDate);

        //Select reviewer group 1
        Select reviewFormDataTestGroupDropDown = new Select(reviewFormDataTestGroup);
        reviewFormDataTestGroupDropDown.selectByValue(verifier1Group);

        //Select reviewer 1
        Select reviewFormDataTestReviewerDropDown = new Select(reviewFormDataTestReviewer);
        reviewFormDataTestReviewerDropDown.selectByValue(verifier1);

        //Type due date for Reviewer 1
        setReviewFormDataTestDueDate(verifier1DueDate);

        //Select Reviewer 2 group (Second Assignee)
        Select reviewReviewersFormDataTestGroupDropDown = new Select(reviewReviewersFormDataTestGroup);
        reviewReviewersFormDataTestGroupDropDown.selectByValue(verifier2Group);

        //Select assingee 2 name
        Select reviewReviewersFormDataTestReviewerDropDown = new Select(reviewReviewersFormDataTestReviewer);
        reviewReviewersFormDataTestReviewerDropDown.selectByValue(verifier2);

        //Type due date for Review Reviewers form data test (second assignee)
        setReviewReviewersFormDataTestDueDate(verifier2DueDate);

        //Click on Continue button to go to next page.
        continueButton.click();

        //Get the page on which customer is and return it.
        String pageHeader = pageHeaderLabel.getText();
        if (pageHeader.equals("Review Your Order"))
            return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        else {
            return PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
        }
    }

    /**
     * fillFormReviewFormSet87253999 may return a review page, or an existing candidate page. If your test doesnt care which one you get, this moves to the review page.
     * @param productFormPage
     * @return
     */
    public static ReviewOrderPage continuePastReviewPage(ProductFormPages productFormPage)
    {
        ReviewOrderPage reviewOrderPage;
        if (productFormPage instanceof ExistingCandidatesPage) {
            reviewOrderPage = ((ExistingCandidatesPage) productFormPage).clickContinueButton();
        } else {
            reviewOrderPage = (ReviewOrderPage) productFormPage;
        }
        return reviewOrderPage;
    }

    /**
     * Sets the 2nd Task Owner's Due Date
     * @param verifier1DueDate
     * @return
     */
    public static void setReviewFormDataTestDueDate(LocalDate verifier1DueDate) {
        setDueDate(verifier1DueDate, "dp_" + reviewFormDataTestDueDateLocatorString, reviewFormDataTestDueDateLocatorString, reviewFormDataTestDueDate);
    }

    /**
     * Sets the 1st task owner's due date
     * @param localDate
     * @return
     */
    public static void setFillAndSignFormDataTestDueDate(LocalDate localDate) {
        setDueDate(localDate, "dp_" + fillAndSignFormDataTestLocatorString, fillAndSignFormDataTestLocatorString, fillAndSignFormDataTestDueDate);
    }

    private static void setDueDate(LocalDate verifier1DueDate, String visibleID, String hiddenID, WebElement element) {
        if(Driver.getBrowserType() == DriverType.FIREFOX || Driver.getBrowserType() == DriverType.CHROME) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(verifier1DueDate, visibleID, hiddenID);
        }
        else {
            String date = verifier1DueDate.format(LocaleHelper.getDateFormatShortDateSlash_uuuu());
            element.sendKeys(date);
        }
    }

    public Object fillFormReviewFormSet87253999(LocalDate localDate, String verifier1Group, LocalDate verifier1DueDate, String verifier2Group, LocalDate verifier2DueDate) {

        //Type Due date for Fill and Sign Form Data Test
        setFillAndSignFormDataTestDueDate(localDate);

        //Select reviewer group 1
        Select reviewFormDataTestGroupDropDown = new Select(reviewFormDataTestGroup);
        reviewFormDataTestGroupDropDown.selectByVisibleText(verifier1Group);

        //Type due date for Reviewer 1
        setReviewFormDataTestDueDate(verifier1DueDate);

        //Select Reviewer 2 group (Second Assignee)
        Select reviewReviewersFormDataTestGroupDropDown = new Select(reviewReviewersFormDataTestGroup);
        reviewReviewersFormDataTestGroupDropDown.selectByVisibleText(verifier2Group);

        //Type due date for Review Reviewers form data test (second assignee)
        setReviewReviewersFormDataTestDueDate(verifier2DueDate);

        //Click on Continue button to go to next page.
        continueButton.click();

        //Get the page on which customer is and return it.
        String pageHeader = pageHeaderLabel.getText();
        if (pageHeader.equals("Review Your Order"))
            return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        else {
            return PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
        }
    }

    /**
     * Sets the 3rd Task Owner's Due Date
     * @param verifier2DueDate
     * @return
     */
    public static void setReviewReviewersFormDataTestDueDate(LocalDate verifier2DueDate) {
        setDueDate(verifier2DueDate, "dp_" + reviewReviewersFormDataTestDueDateLocatorString, reviewReviewersFormDataTestDueDateLocatorString, reviewReviewersFormDataTestDueDate);
    }

    public static ProductFormPages clickContinue() {
        // Explicitly waiting for 2 seconds to give the dymamic page change a chance to finish
        // before we try to click the button.
        // moving too fast attempts to click the button in a location that is still moving
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 5);
        WebElement theContinueButton = SeleniumTest.waitForElementToBeClickable(continueButton, 30);
        //Click on Continue button to go to next page.
        theContinueButton.click();

        //Get the page on which customer is and return it.
        SeleniumTest.waitForElementVisible(By.cssSelector("div.title>h1"));
        String pageHeader = pageHeaderLabel.getText();
        if (pageHeader.equals("Review Your Order")) {
            return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        }
        else {
            if (pageHeader.equals("Form Review FormSet 87253999")) {
                List<WebElement> link = Driver.getDriver().findElements(By.tagName("a"));
                boolean flag=false;
                for(WebElement ele:link)
                {
                    if (ele.getText().equals("View Report"))
                        flag=true;
                }
                if (flag)
                    return PageFactory.initElements(Driver.getDriver(), ExistingCandidatesPage.class);
                else
                    return PageFactory.initElements(Driver.getDriver(), FormReviewFormSet87253999Page.class);
            }
        }
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Clicks on Continue button
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        // Explicitly waiting for 2 seconds to give the dymamic page change a chance to finish
        // before we try to click the button.
        // moving too fast attempts to click the button in a location that is still moving
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 5);
        WebElement theContinueButton = SeleniumTest.waitForElementToBeClickable(continueButton, 30);
        //Click on Continue button to go to next page.
        theContinueButton.click();

        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Determines whether or not the Group Error has been shown
     * @return True or False
     */
    public Boolean isGroupErrorShown(){
        List<WebElement> groupErrors = Driver.getDriver().findElements(errorBelowLocator);
        Boolean foundIt = false;
        Integer countOfErrors = 0;
        if(groupErrors.size() > 0){
            for(WebElement we : groupErrors){
                if(we.getText().equals("Group Required") || we.getText().equals("Assignee Required")){
                    foundIt = true;
                    countOfErrors ++;
                }
            }
            if(countOfErrors.equals(groupErrors.size()) && foundIt == true){
                return true;
            }
        }
        return false;
    }

    /**
     * Expands and collapses Email Settings Link
     */
    public void clickEmailSettings() {
        showEmail.click();
    }

    /**
     * Clicks on the "Do not send mail" checkbox
     * @return True or false
     */
    public Boolean clickDoNotSendInitialNotificationEmail() {
        WebElement checkBoxDoNotSend = SeleniumTest.waitForElementToBeClickable(qmailNoSendLocator, 30);

        checkBoxDoNotSend.click();
        return checkBoxDoNotSend.isSelected();
    }

    /**
     * Selects Review Form Data Test Group
     * @param verifierGroup Group to select
     */
    public static void selectReviewFormDataTestGroup(String verifierGroup) {
        Select reviewFormDataTestGroupDropDown = new Select(reviewFormDataTestGroup);
        reviewFormDataTestGroupDropDown.selectByVisibleText(verifierGroup);
    }

    /**
     * Selects Review Form Data Test Verifier
     * @param verifier Verifier to select
     */
    public static void selectReviewFormDataTestVerifier(String verifier) {
        Select reviewFormDataTestVerifierDropDown = new Select(reviewFormDataTestReviewer);
        reviewFormDataTestVerifierDropDown.selectByVisibleText(verifier);
    }

    /**
     * Selects Review Reviewers Form Data Test Group
     * @param verifierGroup The Group to select
     */
    public static void selectReviewReviewersFormDataTestGroup(String verifierGroup) {
        Select reviewReviewersFormDataTestGroupDropDown = new Select(reviewReviewersFormDataTestGroup);
        reviewReviewersFormDataTestGroupDropDown.selectByVisibleText(verifierGroup);
    }

    /**
     * Selects Review Reviewers Form Data Test Verifier
     * @param verifier The verifier to select
     */
    public static void selectReviewReviewersFormDataTestVerifier(String verifier) {
        Select reviewReviewersFormDataTestVerifierDropDown = new Select(reviewReviewersFormDataTestReviewer);
        reviewReviewersFormDataTestVerifierDropDown.selectByVisibleText(verifier);
    }

    /**
     * Types due date in Date field for Task 1
     * @param date
     */
    public static void typeDueDate(String taskNumber, String date) {
        String dueDateLocator = "dp_qduedate" + taskNumber;
        WebElement dueDateField = Driver.getDriver().findElement(By.id(dueDateLocator));
        SeleniumTest.clearAndSetText(dueDateField, date);
    }

    /**
     * Types due date in Date field for Task 1
     * @param date
     */
    public static void typeDueDate(String taskNumber, LocalDate date) {
        if (Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date, "dp_qduedate" + taskNumber, "qduedate" + taskNumber);
        } else {
            String dueDateLocator = "dp_qduedate" + taskNumber;
            WebElement dueDateField = Driver.getDriver().findElement(By.id(dueDateLocator));
            SeleniumTest.clearAndSetText(dueDateField, date.format(LocaleHelper.getDateFormatShortDateSlash_uuuu()));
        }
    }

    /**
     * Click on the "Create New Verifier" button for the corresponding task number
     * @param taskNumber
     */
    public void clickCreateNewVerifierButton(String taskNumber) {
        String createNewVerifierButtonLocator = "createNewVerifierBtnqverifierid" + taskNumber;
        WebElement createNewVerifierButton = Driver.getDriver().findElement(By.id(createNewVerifierButtonLocator));
        createNewVerifierButton.click();
    }

    /**
     * Types first name of the verifier
     * @param taskNumber
     * @param firstName
     */
    public void typeVerifierFirstName(String taskNumber, String firstName) {
        String firstNameTextboxLocator = "fnqverifierid" + taskNumber;
        WebElement verifierFirstNameTextBox = Driver.getDriver().findElement(By.id(firstNameTextboxLocator));
        verifierFirstNameTextBox.sendKeys(firstName);
    }

    /**
     * Types last name of the verifier
     * @param taskNumber
     * @param lastName
     */
    public void typeVerifierLastName(String taskNumber, String lastName) {
        String lastNameTextboxLocator = "lnqverifierid" + taskNumber;
        WebElement verifierLastNameTextBox = Driver.getDriver().findElement(By.id(lastNameTextboxLocator));
        verifierLastNameTextBox.sendKeys(lastName);
    }

    /**
     * Types email address of the new verifier
     * @param taskNumber
     * @param email
     */
    public void typeVerifierEmailAddress(String taskNumber, String email) {
        String emailLocator = "emailqverifierid" + taskNumber;
        WebElement emailTextBox = Driver.getDriver().findElement(By.id(emailLocator));
        SeleniumTest.clearAndSetText(emailTextBox, email, true);
    }

    /**
     * Clears last name field corresponding to the given task number.
     * @param taskNumber
     */
    public void clearVerifierLastName(String taskNumber) {
        String lastNameTextboxLocator = "lnqverifierid" + taskNumber;
        WebElement verifierLastNameTextBox = Driver.getDriver().findElement(By.id(lastNameTextboxLocator));
        verifierLastNameTextBox.clear();
    }

    /**
     * Clears email field corresponding to the given task.
     * @param taskNumber
     */
    public void clearVerifierEmail(String taskNumber) {
        String emailLocator = "emailqverifierid" + taskNumber;
        WebElement emailTextBox = Driver.getDriver().findElement(By.id(emailLocator));
        emailTextBox.clear();
    }

    /**
     * Selects Verifier
     * @param taskNumber
     * @param group
     */
    public static void selectGroup(int taskNumber, String group) {
        WebElement groupDropDown = Driver.getDriver().findElement(By.id("qverifiergroupid" + taskNumber));
        Select groupDD = new Select(groupDropDown);
        groupDD.selectByVisibleText(group);
    }

    /**
     * Select verifier from drop down
     * @param taskNumber
     * @param verifier
     */
    public static void selectVerifier(int taskNumber, String verifier) {
        WebElement verifierDropDown = Driver.getDriver().findElement(By.id("qverifierid" + taskNumber));
        Select verifierDD = new Select(verifierDropDown);
        verifierDD.selectByVisibleText(verifier);
    }
}
