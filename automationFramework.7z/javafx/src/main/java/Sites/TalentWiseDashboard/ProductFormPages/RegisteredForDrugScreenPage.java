package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisteredForDrugScreenPage extends ProductFormPages {

    private static final String SCHEDULE_ANOTHER_CANDIDATE_ID = "scheduleAnotherCandidate";
    // YES, the following is really the same button.  The same button ID either contains the text,
    // "Schedule Another Candidate" or "Return To My Dashboard"
    private static final String RETURN_TO_MY_DASHBOARD_ID = SCHEDULE_ANOTHER_CANDIDATE_ID;
    private static final String PRINT_REPORT_ID = "printReport";

    @FindBy(id = SCHEDULE_ANOTHER_CANDIDATE_ID)
    private WebElement scheduleAnotherCandidateButton;

    @FindBy(id = RETURN_TO_MY_DASHBOARD_ID)
    private WebElement returnToMyDashboardButton;

    @FindBy(id = PRINT_REPORT_ID)
    private WebElement printReportButton;


    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(SCHEDULE_ANOTHER_CANDIDATE_ID))
                && SeleniumTest.isElementVisibleNoWaiting(By.className("dhsCongratsSalutation"));
    }

    public void clickScheduleAnotherCandidateButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id(SCHEDULE_ANOTHER_CANDIDATE_ID));
    }

    public void clickReturnToMyDashboardButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id(RETURN_TO_MY_DASHBOARD_ID));
    }

    public void clickPrintReportButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.id(PRINT_REPORT_ID));
    }

}
