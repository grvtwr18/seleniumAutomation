package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.CandidatePortal.DashboardPage;
import Sites.CandidatePortal.Enums.Month;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Map;

public class CanadaDMVPage extends ProductFormPages{
    private static Map<String, String> data;
    private WebDriver driver;
    private int timeout = 15;

    @FindBy(name = "qinf_Group24-0_1")
    private static WebElement checkTheBoxIfThisIs;

    @FindBy(css = "#divQuickLaunchModalScreen div:nth-of-type(1) a.modalWindowClose")
    private static WebElement close1;

    @FindBy(css = "#divQuickLaunchModalOnboard div:nth-of-type(1) a.modalWindowClose")
    private static WebElement close2;

    @FindBy(id = "btnSubmit")
    private static WebElement continueButton;

    @FindBy(id = "qo_Group24-0_1")
    private static WebElement country;

    @FindBy(css = "a[class='single-tab single-tab-active']")
    private static WebElement dashboard;

    @FindBy(id = "qmm")
    private static WebElement dateOfBirth1;

    @FindBy(id = "qdd")
    private static WebElement dateOfBirth2;

    @FindBy(id = "qyy")
    private static WebElement dateOfBirth3;

    @FindBy(id = "qdl_Group24-0_1")
    private static WebElement driversLicense;

    @FindBy(id = "qee")
    private static WebElement emailAddress;

    @FindBy(css = "#uberform div:nth-of-type(2) div.contents div:nth-of-type(1) div:nth-of-type(2) p.flushTop a")
    private static WebElement fairCreditReportingAct1;

    @FindBy(css = "#uberform div:nth-of-type(2) div.contents div:nth-of-type(2) div:nth-of-type(2) p.flushTop a")
    private static WebElement fairCreditReportingAct2;

    @FindBy(id = "qf")
    private static WebElement firstName;

    @FindBy(id = "qfcramanualagree")
    private static WebElement iHaveProvidedTheIndividualA;

    @FindBy(id = "qn")
    private static WebElement lastName;

    @FindBy(id = "proxyBoxToggle")
    private static WebElement maximizebtn;

    @FindBy(id = "qmi")
    private static WebElement middleName;

    @FindBy(id = "qp")
    private static WebElement phoneNumber;

    @FindBy(id = "qfcraedagree")
    private static WebElement sendElectronicDisclosureAndAuthorizationForms;

    @FindBy(css = "#proxybox div.innerbox div:nth-of-type(2) p:nth-of-type(2) a")
    private static WebElement signOut1;

    @FindBy(css = "#userMenu li:nth-of-type(2) a")
    private static WebElement signOut2;

    @FindBy(id = "usernameLink")
    private static WebElement specialReleases;

    @FindBy(id = "qs_Group24-0_1_US")
    private static WebElement stateprovince1;

    @FindBy(id = "qs_Group24-0_1_CA")
    private static WebElement stateprovince2;

    @FindBy(id = "qsuffix")
    private static WebElement suffix;

    @FindBy(css = "a[href='screening/support.php?view=supportterms']")
    private static WebElement termsAndConditions;

    @FindBy(id = "qshow_Group24-0_1")
    private static WebElement years1;

    @FindBy(id = "qdly_Group24-0_1")
    private static WebElement years2;

    static {
        PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    public CanadaDMVPage() {
    }

    public CanadaDMVPage(WebDriver driver) {
        this();
        this.driver = driver;
    }

    public CanadaDMVPage(WebDriver driver, Map<String, String> data) {
        this(driver);
        this.data = data;
    }

    public CanadaDMVPage(WebDriver driver, Map<String, String> data, int timeout) {
        this(driver, data);
        this.timeout = timeout;
    }

    /**
     * Click on Close Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickClose1Link() {
        close1.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Click on Close Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickClose2Link() {
        close2.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Click on Continue Button.
     *
     * @return the ReviewOrderPage class instance.
     */
    public static ReviewOrderPage clickContinueButton() {
        SeleniumTest.clickUntilConditionMet(continueButton, () -> ReviewOrderPage.onPage());
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * verify license format error is presented
     *
     * @param errorType the type of error to look for.
     * @return verification of the error being shown
     */
    public static boolean isLicenseFormatErrorVisible(String errorType) {

       return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//*[contains(text(), '" + errorType + "')]"));
    }

    /**
     * Click on Continue Button.
     *
     * @return the ReviewOrderPage class instance.
     */
    public static ReviewOrderPage clickContinueButtonForError() {
        SeleniumTest.click(continueButton);
        return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
    }

    /**
     * Click on Dashboard Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static DashboardPage clickDashboardLink() {
        dashboard.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Click on Fair Credit Reporting Act Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickFairCreditReportingAct1Link() {
        fairCreditReportingAct1.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Click on Fair Credit Reporting Act Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickFairCreditReportingAct2Link() {
        fairCreditReportingAct2.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Click on Maximizebtn Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickMaximizebtnLink() {
        maximizebtn.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Click on Sign Out Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickSignOut1Link() {
        signOut1.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Click on Sign Out Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickSignOut2Link() {
        signOut2.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Click on Special Releases Link.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage clickSpecialReleasesLink() {
        specialReleases.click();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Fill every fields in the page.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage fill() {
        setIHaveProvidedTheIndividualACheckboxField();
        setSendElectronicDisclosureAndAuthorizationFormsCheckboxField();
        setFirstNameTextField();
        setMiddleNameTextField();
        setLastNameTextField();
        setSuffixTextField();
        setDateOfBirth1DropDownListField();
        setDateOfBirth2DropDownListField();
        setDateOfBirth3DropDownListField();
        setPhoneNumberTextField();
        setEmailAddressTextField();
        setYears1DropDownListField();
        setCountryDropDownListField();
        setStateprovince1DropDownListField();
        setStateprovince2DropDownListField();
        setDriversLicenseTextField();
        setYears2DropDownListField();
        setCheckTheBoxIfThisIsCheckboxField();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setCheckTheBoxIfThisIsCheckboxField() {
        if (!checkTheBoxIfThisIs.isSelected()) {
            checkTheBoxIfThisIs.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Country Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setCountryDropDownListField() {
        return setCountryDropDownListField(data.get("COUNTRY"));
    }

    /**
     * Set value to Country Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setCountryDropDownListField(String countryValue) {
        new Select(country).selectByVisibleText(countryValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDateOfBirth1DropDownListField() {
        return setDateOfBirth1DropDownListField(data.get("DATE_OF_BIRTH_1"));
    }

    /**
     * Set value to Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDateOfBirth1DropDownListField(String dateOfBirth1Value) {
        Month month = Month.parse(dateOfBirth1Value);
        SeleniumTest.selectByVisibleTextFromDropDown(dateOfBirth1, month.abbreviation());
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDateOfBirth2DropDownListField() {
        return setDateOfBirth2DropDownListField(data.get("DATE_OF_BIRTH_2"));
    }

    /**
     * Set value to Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDateOfBirth2DropDownListField(String dateOfBirth2Value) {
        new Select(dateOfBirth2).selectByVisibleText(dateOfBirth2Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDateOfBirth3DropDownListField() {
        return setDateOfBirth3DropDownListField(data.get("DATE_OF_BIRTH_3"));
    }

    /**
     * Set value to Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDateOfBirth3DropDownListField(String dateOfBirth3Value) {
        new Select(dateOfBirth3).selectByVisibleText(dateOfBirth3Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Drivers License Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDriversLicenseTextField() {
        return setDriversLicenseTextField(data.get("DRIVERS_LICENSE"));
    }

    /**
     * Set value to Drivers License Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setDriversLicenseTextField(String driversLicenseValue) {
        driversLicense.sendKeys(driversLicenseValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    public static CanadaDMVPage clearDriversLicenseTextField() {
        driversLicense.clear();
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Email Address Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setEmailAddressTextField() {
        return setEmailAddressTextField(data.get("EMAIL_ADDRESS"));
    }

    /**
     * Set value to Email Address Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setEmailAddressTextField(String emailAddressValue) {
        emailAddress.sendKeys(emailAddressValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to First Name Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setFirstNameTextField() {
        return setFirstNameTextField(data.get("FIRST_NAME"));
    }

    /**
     * Set value to First Name Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setFirstNameTextField(String firstNameValue) {
        firstName.sendKeys(firstNameValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set I Have Provided The Individual A Disclosure And Received The Individuals Written Checkbox field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setIHaveProvidedTheIndividualACheckboxField() {
        if (!iHaveProvidedTheIndividualA.isSelected()) {
            iHaveProvidedTheIndividualA.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Last Name Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setLastNameTextField() {
        return setLastNameTextField(data.get("LAST_NAME"));
    }

    /**
     * Set value to Last Name Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setLastNameTextField(String lastNameValue) {
        lastName.sendKeys(lastNameValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Middle Name Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setMiddleNameTextField() {
        return setMiddleNameTextField(data.get("MIDDLE_NAME"));
    }

    /**
     * Set value to Middle Name Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setMiddleNameTextField(String middleNameValue) {
        middleName.sendKeys(middleNameValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Phone Number Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setPhoneNumberTextField() {
        return setPhoneNumberTextField(data.get("PHONE_NUMBER"));
    }

    /**
     * Set value to Phone Number Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setPhoneNumberTextField(String phoneNumberValue) {
        phoneNumber.sendKeys(phoneNumberValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set Send Electronic Disclosure And Authorization Forms To This Individual At The Email Given Below Checkbox field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setSendElectronicDisclosureAndAuthorizationFormsCheckboxField() {
        if (!sendElectronicDisclosureAndAuthorizationForms.isSelected()) {
            sendElectronicDisclosureAndAuthorizationForms.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setStateprovince1DropDownListField() {
        return setStateprovince1DropDownListField(data.get("STATEPROVINCE_1"));
    }

    /**
     * Set value to Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setStateprovince1DropDownListField(String stateprovince1Value) {
        new Select(stateprovince1).selectByVisibleText(stateprovince1Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setStateprovince2DropDownListField() {
        return setStateprovince2DropDownListField(data.get("STATEPROVINCE_2"));
    }

    /**
     * Set value to Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setStateprovince2DropDownListField(String stateprovince2Value) {
        new Select(stateprovince2).selectByVisibleText(stateprovince2Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Suffix Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setSuffixTextField() {
        return setSuffixTextField(data.get("SUFFIX"));
    }

    /**
     * Set value to Suffix Text field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setSuffixTextField(String suffixValue) {
        suffix.sendKeys(suffixValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setYears1DropDownListField() {
        return setYears1DropDownListField(data.get("YEARS_1"));
    }

    /**
     * Set value to Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setYears1DropDownListField(String years1Value) {
        if (!years1.isSelected()) {
            years1.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Set default value to Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setYears2DropDownListField() {
        return setYears2DropDownListField(data.get("YEARS_2"));
    }

    /**
     * Set value to Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage setYears2DropDownListField(String years2Value) {
        new Select(years2).selectByVisibleText(years2Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset Check The Box If This Is A Commercial Drivers License Cdl Checkbox field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetCheckTheBoxIfThisIsCheckboxField() {
        if (checkTheBoxIfThisIs.isSelected()) {
            checkTheBoxIfThisIs.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Country Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetCountryDropDownListField() {
        return unsetCountryDropDownListField(data.get("COUNTRY"));
    }

    /**
     * Unset value from Country Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetCountryDropDownListField(String countryValue) {
        new Select(country).deselectByVisibleText(countryValue);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetDateOfBirth1DropDownListField() {
        return unsetDateOfBirth1DropDownListField(data.get("DATE_OF_BIRTH_1"));
    }

    /**
     * Unset value from Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetDateOfBirth1DropDownListField(String dateOfBirth1Value) {
        new Select(dateOfBirth1).deselectByVisibleText(dateOfBirth1Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetDateOfBirth2DropDownListField() {
        return unsetDateOfBirth2DropDownListField(data.get("DATE_OF_BIRTH_2"));
    }

    /**
     * Unset value from Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetDateOfBirth2DropDownListField(String dateOfBirth2Value) {
        new Select(dateOfBirth2).deselectByVisibleText(dateOfBirth2Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetDateOfBirth3DropDownListField() {
        return unsetDateOfBirth3DropDownListField(data.get("DATE_OF_BIRTH_3"));
    }

    /**
     * Unset value from Date Of Birth Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetDateOfBirth3DropDownListField(String dateOfBirth3Value) {
        new Select(dateOfBirth3).deselectByVisibleText(dateOfBirth3Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset I Have Provided The Individual A Disclosure And Received The Individuals Written Checkbox field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetIHaveProvidedTheIndividualACheckboxField() {
        if (iHaveProvidedTheIndividualA.isSelected()) {
            iHaveProvidedTheIndividualA.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset Send Electronic Disclosure And Authorization Forms To This Individual At The Email Given Below Checkbox field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetSendElectronicDisclosureAndAuthorizationFormsCheckboxField() {
        if (sendElectronicDisclosureAndAuthorizationForms.isSelected()) {
            sendElectronicDisclosureAndAuthorizationForms.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetStateprovince1DropDownListField() {
        return unsetStateprovince1DropDownListField(data.get("STATEPROVINCE_1"));
    }

    /**
     * Unset value from Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetStateprovince1DropDownListField(String stateprovince1Value) {
        new Select(stateprovince1).deselectByVisibleText(stateprovince1Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetStateprovince2DropDownListField() {
        return unsetStateprovince2DropDownListField(data.get("STATEPROVINCE_2"));
    }

    /**
     * Unset value from Stateprovince Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetStateprovince2DropDownListField(String stateprovince2Value) {
        new Select(stateprovince2).deselectByVisibleText(stateprovince2Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetYears1DropDownListField() {
        return unsetYears1DropDownListField(data.get("YEARS_1"));
    }

    /**
     * Unset value from Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetYears1DropDownListField(String years1Value) {
        if (years1.isSelected()) {
            years1.click();
        }
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Unset default value from Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetYears2DropDownListField() {
        return unsetYears2DropDownListField(data.get("YEARS_2"));
    }

    /**
     * Unset value from Years Drop Down List field.
     *
     * @return the CanadaDMVPage class instance.
     */
    public static CanadaDMVPage unsetYears2DropDownListField(String years2Value) {
        new Select(years2).deselectByVisibleText(years2Value);
        return PageFactory.initElements(Driver.getDriver(), CanadaDMVPage.class);
    }

    /**
     * Selects date of birth
     * @param dob Date of birth
     */
    public static void selectDateOfBirth(LocalDate dob) {
        String dobMonth = dob.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);
        String dobDay = (Integer.toString(dob.getDayOfMonth()));
        String dobYear = (Integer.toString(dob.getYear()));

        setDateOfBirth1DropDownListField(dobMonth);
        setDateOfBirth2DropDownListField(dobDay);
        setDateOfBirth3DropDownListField(dobYear);
    }
}
