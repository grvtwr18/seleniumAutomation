package Sites.TalentWiseDashboard.ProductFormPages;

import WebDriver.Driver;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

/**
 * TODO: I suspect this is a duplicate of FS2370LaunchPage, as a three-task due date form page.
 * TODO Refactor this, copy and pasted from FS2509LaunchPage
 */
public class ThreeStepLaunchPage extends ProductFormPages {

    @FindBy(how = How.ID, using = "dp_qduedate1")
    private static WebElement task1DueDateBox;

    @FindBy(how = How.ID, using = "dp_qduedate2")
    private static WebElement task2DueDateBox;

    @FindBy(how = How.ID, using = "dp_qduedate3")
    private static WebElement task3DueDateBox;

    private static final String task2GroupID = "qverifiergroupid2";
    static By task2GroupLocator = By.id(task2GroupID);
    @FindBy(how = How.ID, using = task2GroupID)
    private static WebElement task2GroupDropdown;

    private static final String task2VerifierID = "qverifierid2";
    static By task2VerifierLocator = By.id(task2VerifierID);
    @FindBy(how = How.ID, using = task2VerifierID)
    private static WebElement task2VerifierDropdown;

    private static final String task3GroupID = "qverifiergroupid3";
    static By task3GroupLocator = By.id(task3GroupID);
    @FindBy(how = How.ID, using = task3GroupID)
    private static WebElement task3GroupDropdown;

    private static final String task3VerifierID = "qverifierid3";
    static By task3VerifierLocator = By.id(task3VerifierID);
    @FindBy(how = How.ID, using = task3VerifierID)
    private static WebElement task3VerifierDropdown;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    static {
        PageFactory.initElements(Driver.getDriver(), ThreeStepLaunchPage.class);
    }

    /**
     * Sets the Task 1 Due Date
     * @param lDate
     * @return
     */
    public static void setTask1DueDate(LocalDate lDate) {
        task1DueDateBox.clear();
        task1DueDateBox.sendKeys(getMMDDYYYY(lDate));

    }

    /**
     * Sets the Task 2 Due Date
     * @param lDate
     * @return
     */
    public static void setTask2DueDate(LocalDate lDate) {
        task2DueDateBox.clear();
        task2DueDateBox.sendKeys(getMMDDYYYY(lDate));

    }

    /**
     * Sets the Task 3 Due date
     * @param lDate
     * @return
     */
    public static void setTask3DueDate(LocalDate lDate) {
        task3DueDateBox.clear();
        task3DueDateBox.sendKeys(getMMDDYYYY(lDate));

    }

    /**
     * Selects the Task 2 Group
     * @param groupName
     * @return
     */
    public static void selectTask2Group(String groupName) {
        Select groupSelect = new Select(task2GroupDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task2GroupLocator)).getOptions().size() > 1) {
                            return true;
                        }
                        return false;
                    }
                });
        groupSelect.selectByVisibleText(groupName);

    }

    /**
     * Selects the Task 2 Verifier
     * @param verifier
     * @return
     */
    public static void selectTask2Verifier(String verifier) {
        Select verifierSelect = new Select(task2VerifierDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task2VerifierLocator)).getOptions().size() > 1) {
                            return true;
                        }
                        return false;
                    }
                });
        verifierSelect.selectByVisibleText(verifier);

    }

    /**
     * Selects the Task 3 Group
     * @param groupName
     * @return
     */
    public static void selectTask3Group(String groupName) {
        Select groupSelect = new Select(task3GroupDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task3GroupLocator)).getOptions().size() > 1) {
                            return true;
                        }
                        return false;
                    }
                });
        groupSelect.selectByVisibleText(groupName);

    }

    /**
     * Selects the Task 3 Verifier
     * @param verifier
     * @return
     */
    public static void selectTask3Verifier(String verifier) {
        Select verifierSelect = new Select(task3VerifierDropdown);

        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(task3VerifierLocator)).getOptions().size() > 1) {
                            return true;
                        }
                        return false;
                    }
                });
        verifierSelect.selectByVisibleText(verifier);

    }

    /**
     * Clicks the continue button
     * @return
     */
    public static void clickContinue() {
        continueButton.click();
    }

    private static String getMMDDYYYY(LocalDate localDate) {
        //TODO:  Find the way to do this using the date functions rather than manually assembling the date.
        String twoDigitMonth = Integer.toString(localDate.getMonthValue());
        if(twoDigitMonth.length() < 2)
            twoDigitMonth = "0" + twoDigitMonth;

        String twoDigitDayOfMonth = Integer.toString(localDate.getDayOfMonth());
        if(twoDigitDayOfMonth.length() < 2)
            twoDigitDayOfMonth = "0" + twoDigitDayOfMonth;

        return twoDigitMonth + "/" + twoDigitDayOfMonth + "/" + Integer.toString(localDate.getYear());
    }
}
