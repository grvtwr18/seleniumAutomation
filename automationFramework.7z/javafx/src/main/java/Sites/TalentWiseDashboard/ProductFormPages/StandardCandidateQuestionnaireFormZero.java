package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 11/13/2015.
 * TODO: fix line endings
 */
public class StandardCandidateQuestionnaireFormZero extends ProductFormPages {
    @FindBy(how = How.ID, using = "FormZero-11050_4")
    private static WebElement socialSecurityCheckbox;

    @FindBy(how = How.ID, using = "FormZero-11050_5")
    private static WebElement dobCheckbox;

    @FindBy(how = How.ID, using = "FormZero-11050_8_Highest Degree Only")
    private static WebElement highestDegreeRadiobutton;

    @FindBy(how = How.ID, using = "FormZero-11050_8_All Education History")
    private static WebElement allEducationHistoryRadiobutton;

    @FindBy(how = How.ID, using = "FormZero-11050_8_None")
    private static WebElement noneRadiobutton;

    @FindBy(how = How.ID, using = "FormZero-11050_11")
    private static WebElement employmentHistoryCheckbox;

    @FindBy(how = How.ID, using = "FormZero-11050_13")
    private static WebElement referencesCheckbox;

    @FindBy(how = How.ID, using = "FormZero-11050_15")
    private static WebElement additionalInformationCheckbox;

    @FindBy(how = How.ID, using = "FormZero-11050_19")
    private static WebElement electronicDisclosureCheckbox;

    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement continueButton;

    static {
        PageFactory.initElements(Driver.getDriver(), StandardCandidateQuestionnaireFormZero.class);
    }

    public static void waitForPageReady() {
        SeleniumTest.waitForElement(socialSecurityCheckbox);
    }

    /**
     * Check Social Security Number Checkbox
     * @return this
     */
    public StandardCandidateQuestionnaireFormZero checkSocialSecurityNumber() {
        if(!socialSecurityCheckbox.isSelected())
            socialSecurityCheckbox.click();
        return this;
    }

    /**
     * Check Date of Birth Checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero checkDateOfBirth() {
        if(!dobCheckbox.isSelected())
            dobCheckbox.click();
        return this;
    }

    /**
     * Choose Highest Degree Only Radiobutton
     * @return
     */
    public StandardCandidateQuestionnaireFormZero chooseHighestDegreeOnly() {
        if(!highestDegreeRadiobutton.isSelected())
            highestDegreeRadiobutton.click();
        return this;
    }

    /**
     * Choose All Education Radiobutton
     * @return
     */
    public StandardCandidateQuestionnaireFormZero chooseAllEducationHistory() {
        if(!allEducationHistoryRadiobutton.isSelected())
            allEducationHistoryRadiobutton.click();
        return this;
    }

    /**
     * Choose None Radiobutton
     * @return
     */
    public StandardCandidateQuestionnaireFormZero chooseNone() {
        if(!noneRadiobutton.isSelected())
            noneRadiobutton.click();
        return this;
    }

    /**
     * Check Employment History Checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero checkEmploymentHistory() {
        if(!employmentHistoryCheckbox.isSelected())
            employmentHistoryCheckbox.click();
        return this;
    }

    /**
     * Check References Checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero checkReferences() {
        if(!referencesCheckbox.isSelected())
            referencesCheckbox.click();
        return this;
    }

    /**
     * Check Additional Information Checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero checkAdditionalInformation() {
        if(!additionalInformationCheckbox.isSelected())
            additionalInformationCheckbox.click();
        return this;
    }

    /**
     * Check Electronic Disclosure checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero checkElectronicDisclosure() {
        if(!electronicDisclosureCheckbox.isSelected())
            electronicDisclosureCheckbox.click();
        return this;
    }

    /**
     * Uncheck Social Security Number checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero uncheckSocialSecurityNumber() {
        if(socialSecurityCheckbox.isSelected())
            socialSecurityCheckbox.click();
        return this;
    }

    /**
     * uncheck Date of Birth Checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero uncheckDateOfBirth() {
        if(dobCheckbox.isSelected())
            dobCheckbox.click();
        return this;
    }

    /**
     * uncheck Employment History checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero uncheckEmploymentHistory() {
        if(employmentHistoryCheckbox.isSelected())
            employmentHistoryCheckbox.click();
        return this;
    }

    /**
     * uncheck References Checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero uncheckReferences() {
        if(referencesCheckbox.isSelected())
            referencesCheckbox.click();
        return this;
    }

    /**
     * uncheck Additional Information checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero uncheckAdditionalInformation() {
        if(additionalInformationCheckbox.isSelected())
            additionalInformationCheckbox.click();
        return this;
    }

    /**
     * uncheck Electronic Disclosure checkbox
     * @return
     */
    public StandardCandidateQuestionnaireFormZero uncheckElectronicDisclosure() {
        if(electronicDisclosureCheckbox.isSelected())
            electronicDisclosureCheckbox.click();
        return this;
    }

    /**
     * Click Continue
     * @param advancePage Boolean to determine if the page advances to the next page or not.
     * @return Appropriate page based on Boolean Value
     */
    public ProductFormPages clickContinue(Boolean advancePage) {
        continueButton.click();
        if(advancePage) {
            return PageFactory.initElements(Driver.getDriver(), ReviewOrderPage.class);
        }
        else {
            return PageFactory.initElements(Driver.getDriver(), StandardCandidateQuestionnaireFormZero.class);
        }
    }
}
