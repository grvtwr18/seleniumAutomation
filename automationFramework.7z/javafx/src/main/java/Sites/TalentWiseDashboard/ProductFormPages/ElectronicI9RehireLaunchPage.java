package Sites.TalentWiseDashboard.ProductFormPages;

import org.openqa.selenium.support.PageFactory;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;

/**
 * Created by jgupta on 4/4/2016.
 */
public class ElectronicI9RehireLaunchPage extends I9LaunchPages {

    /**
     * The following method fills the rehire launch form for Everify Electronic I9
     * @param firstName
     * @param middleName
     * @param lastName
     * @param emailAddress
     */
    public static ElectronicI9RehireLaunchPage fillForm(String firstName, String middleName, String lastName, String emailAddress, String verifierGroup, String verifierName) {
        SeleniumTest.clearAndSetText(EmployeeProfile.firstNameTextBox, firstName);
        SeleniumTest.clearAndSetText(EmployeeProfile.middleInitialOrNameTextBox, middleName);
        EmployeeProfile.setLastName(lastName);
        SeleniumTest.clearAndSetText(emailAddressTextBox, emailAddress);
        I9LaunchPages.Verifier.selectAssignedGroup(verifierGroup);
        I9LaunchPages.Verifier.selectAssignee(verifierName);
        return PageFactory.initElements(Driver.getDriver(), ElectronicI9RehireLaunchPage.class);
    }

    /**
     * Fills the rehire launch form for E-Verify Electronic I9 Rehire 650
     * @param candidate
     * @param verifierGroup
     * @param verifierName
     * @return
     */
    public static ElectronicI9RehireLaunchPage fillForm(Candidate candidate, String verifierGroup, String verifierName) {
        SeleniumTest.clearAndSetText(EmployeeProfile.firstNameTextBox, candidate.getFirstName());
        SeleniumTest.clearAndSetText(EmployeeProfile.middleInitialOrNameTextBox, candidate.getMiddleName());
        EmployeeProfile.setLastName(candidate.getLastName());
        I9LaunchPages.Verifier.selectAssignedGroup(verifierGroup);
        I9LaunchPages.Verifier.selectAssignee(verifierName);
        return PageFactory.initElements(Driver.getDriver(), ElectronicI9RehireLaunchPage.class);
    }

    /**
     * Clicks on Continue button to go to next page.
     * @return
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

}
