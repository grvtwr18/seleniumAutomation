package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.AdverseActionHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Page object is to handle initiating Adverse Action with individualized review
 * @author sbashar
 */

public class ScreeningLaunchWithEaaIrPage extends ScreeningLaunchPage {

    private static final Logger logger = LoggerFactory.getLogger("Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchWithEaaIrPage");

    @FindBy(how = How.CSS, using = "input[value=0]")
    private static WebElement doNotIncludeFairChanceRadio;

    @FindBy(how = How.ID, using = "qverifierid2")
    private static WebElement assignedReviewer;

    @FindBy(how = How.XPATH, using = "//a[@name='individualizedassessment']/../../../following-sibling::div")
    private static WebElement irReviewSection;

    @FindBy(how = How.XPATH, using = "//a[@name='irreviewer']/../../following-sibling::div[2]")
    private static WebElement reviewerSection;

    @FindBy(how = How.XPATH, using = "//a[@name='individualizedassessment']/../../../following-sibling::div")
    private static WebElement fairChanceSection;

    @FindBy(how = How.CSS, using = "input[name='qirinclude'][value='1']")
    public static WebElement irInclude;

    @FindBy(how = How.CSS, using = "input[name='qirinclude'][value='0']")
    public static WebElement irDoNotInclude;

    @FindBy(how = How.LINK_TEXT, using = "edit")
    private static WebElement editLink;

    @FindBy(how = How.ID, using = "reasons")
    private static WebElement aaReasonsForPotentialDisqualification;

    @FindBy(how = How.CSS, using = "input[value='Initiate Adverse Action']")
    private static WebElement adverseActionButton;

    @FindBy(how = How.CSS, using = "input[value='Cancel']")
    private static WebElement cancelButton;

    @FindBy(how = How.ID, using = "adverse-modal-errors")
    private static WebElement adverseModalErrors;

    @FindBy(how = How.CLASS_NAME, using = "searchErrorBox")
    private static WebElement aAErrors;

    private static String pageUrl = "/screening/search.php?searchform=uber&ufid";

    /**
     * Initialize WebElements
     */
    static {
        PageFactory.initElements(Driver.getDriver(), ScreeningLaunchWithEaaIrPage.class);
    }

    public static boolean isReviewerSectionErrorDisplayed() {
            return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("div.stripe.select-reviewer  > div.subformerror"));
    }

    public static void selectReviewer(String reviewerName) {
        SeleniumTest.selectByVisibleTextFromDropDown(assignedReviewer, reviewerName);
    }

    /**
     * This method returns the reviewer that is selected.
     * @return
     */
    public static String getSelectedReviewer() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(assignedReviewer).trim();
    }

    public static String getViewSectionIndividualizedText() {
        return irReviewSection.getText();
    }

    public static String getViewSectionReviewerText() {
        return reviewerSection.getText();
    }

    public static boolean isReviewerDisplayed() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("div.stripe.select-reviewer"));
    }

    public static boolean isIndividualizedAssessmentIncluded() {
        final String expectedIrHeader = "Individualized Assessment";

        logger.info("Find the header: {}", expectedIrHeader);
        // find the div element which has
        // - class "contents"
        // - and has a descendant element of any type which has class "searchConfirmHead" and text
        WebElement irContent = Driver.getDriver().findElement(By.xpath(String.format(
                "//div[contains(@class, 'contents')]"
                + "[.//*[contains(@class, 'adverse-compliance-title')][normalize-space(text())='%s']]",
                expectedIrHeader
        )));

        logger.info("Find the value");
        // find the div element which has
        // - ancestor element irContent
        // - parent div with class "searchConfirmSummaryContainer"
        // - class "itemNoLabel" and text
        WebElement irValue = irContent.findElement(By.xpath(String.format(
                "div[contains(@class, 'searchConfirmSummaryContainer')]"
                + "/div[contains(@class, 'itemNoLabel')]"
        )));

        String irValueText = SeleniumTest.getText(irValue);

        if (irValueText.equals("Included")) {
            return true;
        } else if (irValueText.equals("Not Included")) {
            return false;
        } else {
            throw new InvalidElementStateException("Unexpected irValue: " + irValueText);
        }

    }

    public static void selectIncludeIndividualizedReview() {
        SeleniumTest.click(irInclude);
    }

    public static void selectDoNotIncludeIndividualizedReview() {
        SeleniumTest.click(irDoNotInclude);
    }

    public static void clickEdit() {
        SeleniumTest.click(editLink);
    }

    /**
     * This method returns true if Individualized review section is visible.
     * @return
     */
    public static boolean isIaOrFcSectionVisible() {
        return  SeleniumTest.isElementVisibleNoWaiting(By.xpath("//a[@name='individualizedassessment']"));
    }

    public static boolean isRfdSectionVisible() {
        return  SeleniumTest.isElementVisibleNoWaiting(By.xpath("//a[@name='disqualreason']"));
    }

    public static void waitForRfdToDisappear() {
        SeleniumTest.waitForElementNotVisible(By.xpath("//a[@name='disqualreason']"));
    }

    /**
     * This method returns true if "do not include ir" option is visible
     * @return
     */
    public static boolean isDoNotIncludeIrButtonVisible() {
        return  SeleniumTest.isElementVisibleNoWaiting(By.name("qirinclude"));
    }

    /**
     * This method returns true if the purchase button is visible
     * @return
     */
    public static boolean isPurchaseButtonVisible() {
        return  SeleniumTest.isElementVisibleNoWaiting(By.id("btnPurchase"));
    }

    /**
     * This method returns true if the reviewer dropdown menu lists out the reviewers only who are enabled for IR
     */
    public static boolean areReviewersListed(List<String> reviewerNames){
        List<String> strOptions = SeleniumTest.getSelectOptionStrings(assignedReviewer);
        return strOptions.containsAll(reviewerNames);
    }

    /**
     * This method returns true if the reviewer dropdown menu lists contains the passing reviewer
     */
    public static boolean isReviewerListed(String reviewerName){
        List<String> strOptions = SeleniumTest.getSelectOptionStrings(assignedReviewer);
        return strOptions.contains(reviewerName);
    }

    /**
     * Verify whether the user is on AA page
     */
    public static boolean onPage() {
        boolean onPage = false;
        if (Driver.getDriver().getCurrentUrl().contains(pageUrl)){
            onPage = isReviewerDisplayed();
        }
        return onPage;
    }

    /**
     * Reasons for potential disqualification are checkboxes included in a label.
     * This method allows us to tell whether all checkboxes are unselected.  This is good to have for
     * ascertaining that the state of the checkboxes is as expected.
     *
     * @return boolean - true if there are no check boxes selected, false otherwise.
     */
    public static boolean areAllReasonsUnselected() {
        for (WebElement e : aaReasonsForPotentialDisqualification.findElements(By.xpath("//input[@type='checkbox' and @class='disqualreasons crim-reason']"))) {
            if (SeleniumTest.isCheckboxChecked(e)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Reasons for potential disqualification are checkboxes included in a label.
     * This method allows us to select a given reason for potential disqualification based on its index.
     *
     * @param i - The zero based index to the reason as displayed on this Screening Launch Page.
     * @return - the containing Label string that surrounds the checkbox at the given index, "i"
     */
    public static String selectReasonForPotentialDisqualificationByIndex(int i) {
        List<WebElement> webElementList = aaReasonsForPotentialDisqualification.findElements(By.xpath("//input[@type='checkbox' and @class='disqualreasons crim-reason']"));
        WebElement e = webElementList.get(i);
        if (!SeleniumTest.isCheckboxChecked(e)) {
            SeleniumTest.check(e);
        }

        // The Disqualification Reason text for this CheckBox is contained in the parent HTML tag ...
        return SeleniumTest.getText(e.findElement(By.xpath("..")));
    }

    public static String selectRfdByRequestId(String requestId) {
        WebElement checkbox = Driver.getDriver().findElement(By.cssSelector
                    ("input[value='" + requestId + "']"));
        if (!SeleniumTest.isCheckboxChecked(checkbox)) {
            SeleniumTest.check(checkbox);
        }
        // The Disqualification Reason text for this CheckBox is contained in the parent HTML tag ...
        return SeleniumTest.getText(checkbox.findElement(By.xpath("..")));
    }

    /**
     * @param i - The index to the reason as displayed in the modal dialog.
     *
     * This is used in conjuction with the AdverseActionHelper class.  This allows us to save the Reason(s) for
     * Potential Disqualification that are presented to the user on this modal dialog for future retrieval.
     * Currently, the reasons can only be saved one at the time, referring to them by index in the element collection.
     */
    public static void saveAdverseActionReasonByIndex(int i) {
        List<WebElement> webElementList = aaReasonsForPotentialDisqualification.findElements(By.xpath("//input[@type='checkbox' and @class='disqualreasons crim-reason']"));
        WebElement e = webElementList.get(i);
        String reason = e.getText();

        AdverseActionHelper.addAdverseActionReason(reason);
    }

    /**
     * Returns the text in Fair chance section on Adverse Action launch page.
     * @return
     */
    public static String getFairChanceSectionText() {
        return SeleniumTest.getText(fairChanceSection);
    }

    public static boolean isFcSectionLoaded() {
        return SeleniumTest.getText(fairChanceSection).contains("Include Fair Chance");
    }

    public static boolean isIaSectionLoaded() {
        return SeleniumTest.getText(irReviewSection).contains("Include Individualized Assessment");
    }

    public static boolean isAdverseActionButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("input[value='Initiate Adverse Action']"));
    }

    public static boolean isCancelButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("input[value='Cancel']"));
    }

    public static ViewReportPage clickInitiateAdverseActionButton() {
        SeleniumTest.click(adverseActionButton);
        return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);
    }

    public static boolean isAdverseModalErrorMessageVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("adverse-modal-errors"));
    }

    public static String getAdverseModalErrorMessage() {
        String errorMessage;
        if (WaitUntil.waitUntil(() -> isAdverseModalErrorMessageVisible())){
            errorMessage =  SeleniumTest.getText(adverseModalErrors).trim();
        }
        else {
            errorMessage = "Error Message is not displayed";
        }
        return errorMessage;
    }

    public static boolean isAaErrorMessageVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.className("searchErrorBox"));
    }

    public static String getAaErrorMessage() {
        String errorMessage;
        if (WaitUntil.waitUntil(() -> isAaErrorMessageVisible())){
            errorMessage =  SeleniumTest.getText(aAErrors).trim();
        }
        else {
            errorMessage = "Error Message is not displayed";
        }
        return errorMessage;
    }

}
