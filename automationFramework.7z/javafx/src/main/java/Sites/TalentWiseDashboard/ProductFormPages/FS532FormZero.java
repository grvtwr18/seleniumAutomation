package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 3/7/2016.
 */
public class FS532FormZero extends ProductFormPages {

    private static final String continueButtonID = "btnSubmit";
    @FindBy(how = How.ID, using = continueButtonID)
    private static WebElement continueButton;

    public FS532FormZero() {
        // Wait for the continue Button to be clickable before returning from the constructor
        SeleniumTest.waitForElementToBeClickable(By.id(continueButtonID), SeleniumTest.waitForElementTimeout);
    }
    /**
     * Clicks continue and returns the expected Page object
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        continueButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}

