package Sites.TalentWiseDashboard.ProductFormPages;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import static Sites.AdminConsole.atstools.SearchHelper.staticLogger;

/**
 * Created by Vivek.Rai on 6/1/2018.
 */
public class OrderConfirmationPageHelper {

    /*On Admin portal candidate information is verified on report details page once edit button is clicked*/
    public static boolean isCandidateInfoMatchedAfterEditButtonClicked(Map<String,String> candidateInformation ){

        Set<String> set=candidateInformation.keySet();
        Iterator<String > it=set.iterator();
        while (it.hasNext()) {
            String keyName=it.next();
            String keyValue = Driver.getDriver().findElement(By.xpath("//div[contains(text(),'"+keyName+"')]/../../../..//td/strong[contains(text(),'"+candidateInformation.get(keyName)+"')]/../following-sibling::td/input")).getAttribute("value").trim();
            if (keyValue.equals(candidateInformation.get(keyName))){
                staticLogger.info("Expected and actual matched "+keyName+ " is "+keyValue);
            }
            else if(candidateInformation.get(keyName).equals("Resigned"))
            {
                String reasonForJobChange= Driver.getDriver().findElement(By.xpath("//div[contains(text(),'"+keyName+"')]/../../../..//td/strong[text()='"+candidateInformation.get(keyName)+"']/../following-sibling::td/select")).getAttribute("value");
                staticLogger.info(reasonForJobChange+" "+candidateInformation.get(keyName));
                return reasonForJobChange.equals(candidateInformation.get(keyName));

            }
            else
            {  staticLogger.info(candidateInformation.get(keyName)+" didn't match with "+keyValue);
                return false;
            }

        }
        return true;
    }

    public static boolean isPreviewReportTableInfoMatchForProvidedEmployment(Map<String,String> candidateInformation){

        return isCandidateInfoOnPreviewReportPage(candidateInformation,"empReportTable3");
    }

    public static boolean isPreviewReportTableInfoMatchForVerifiedEmployment(Map<String,String> candidateInformation){

        return isCandidateInfoOnPreviewReportPage(candidateInformation,"empReportTable4");
    }
    public static boolean isPreviewReportTableInfoMatchForProvidedEducation(Map<String,String> candidateInformation){

        return isCandidateInfoOnPreviewReportPage(candidateInformation,"eduReportTable3");
    }
    public static boolean isPreviewReportTableInfoMatchForVerifiedEducation(Map<String,String> candidateInformation){

        return isCandidateInfoOnPreviewReportPage(candidateInformation,"eduReportTable4");
    }


    public static boolean isCandidateInfoOnPreviewReportPage(Map<String,String> candidateInformation,String ID ){

        Set<String> set=candidateInformation.keySet();
        Iterator<String > it=set.iterator();
        while (it.hasNext()) {
            String keyName=it.next();
            String keyValue = SeleniumTest.getTextByLocator(By.xpath("//*[@id='"+ID+"']//td[contains(text(),'"+keyName+"')]/following-sibling::td")).trim();
            if (keyValue.equalsIgnoreCase(candidateInformation.get(keyName))) {
                staticLogger.info(keyName+ " is "+keyValue);
            }
            else
            {
                staticLogger.info(candidateInformation.get(keyName)+ " didn't match with "+keyValue);
                return false;
            }

        }
        return true;
    }

    public static Map<String,String> getCandidateInformation(Candidate candidate, String employerName, String jobTitle, String employmentDuration, String reasonForJobChange){

        Map<String,String> candidateInformation = new HashMap<String,String>();
        candidateInformation.put("Employer Name",employerName);candidateInformation.put("Location",candidate.getCity()+", "+candidate.getDriversLicenseState());
        candidateInformation.put("Employee Name",candidate.getFirstName()+" "+candidate.getLastName());candidateInformation.put("Job Title",jobTitle);
        candidateInformation.put("Dates Employed",employmentDuration); candidateInformation.put("Reason for Leaving",reasonForJobChange);
        return candidateInformation;
    }

    public static Map<String,String> getCandidateInformationForEditPage(Candidate candidate, String employerName, String jobTitle, String startDate,String endDate, String reasonForJobChange){

        Map<String,String> candidateInformation = new HashMap<String,String>();
        candidateInformation.put("Employer Name",employerName);candidateInformation.put("Location",candidate.getCity()+", "+candidate.getDriversLicenseState());
        candidateInformation.put("Employee Name",candidate.getFirstName()+" "+candidate.getLastName());candidateInformation.put("Job Title",jobTitle);
        candidateInformation.put("Start Date",startDate);candidateInformation.put("End Date",endDate); candidateInformation.put("Reason for Leaving",reasonForJobChange);
        return candidateInformation;
    }
}
