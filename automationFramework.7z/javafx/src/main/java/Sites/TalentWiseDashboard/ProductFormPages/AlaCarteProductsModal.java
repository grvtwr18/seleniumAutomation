package Sites.TalentWiseDashboard.ProductFormPages;

import Sites.Site;
import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import Sites.URL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by wogden on 9/15/2016.
 */
public class AlaCarteProductsModal {
    @FindBy(how = How.ID, using = "addProduct")
    private WebElement addButton;

    @FindBy(how = How.CLASS_NAME, using = "k-link k-pager-nav k-pager-last")
    private WebElement lastPage;

    @FindBy(how = How.XPATH, using = "//a[@role='button']")
    private WebElement closeModaldialog;

    @FindBy(how = How.ID, using = "generalSearchButton")
    private WebElement searchButton;

    @FindBy(how = How.ID, using = "nextBtn")
    private WebElement nextBtn;

    @FindBy(how = How.ID, using = "generalSearch")
    private WebElement searchText;

    @FindBy(how = How.XPATH, using = "//span[@class='k-icon k-i-filter']")
    private List<WebElement> filterByProductName;

    @FindBy(how = How.XPATH, using = "//button[@class='k-button k-primary']")
    private List<WebElement> filterProductNameButton;

    @FindBy(how = How.XPATH, using = "/html/body/div[9]/form/div[1]/input")
    private WebElement filterProductNameText;

    @FindBy(how = How.ID, using = "generalSearch")
    private WebElement inpSearchProduct;


    private static final Logger staticLogger = LoggerFactory.getLogger(AlaCarteProductsModal.class);

    //Alacarate row in product List
    private String productType;
    private String productPrice;
    private String productName;
    private String productDescription;

    private static ThreadLocal<AlaCarteProductsModal> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                Sites.TalentWiseDashboard.ProductFormPages.AlaCarteProductsModal.class));
    }

    private static AlaCarteProductsModal getInstance() {
        return threadLocalInstance.get();
    }

    public String GetProductType() {
        return productType;
    }

    public String GetProductPrice() {
        return productPrice;
    }

    public String GetProductName() {
        return productName;
    }

    public static String GetProductType(Integer row) {
        return getAlaCarteProductType(row);
    }

    public static String GetProductPrice(Integer row) {
        return getAlaCarteProductPrice(row);
    }

    public static String GetProductName(Integer row) {
        return getAlaCarteProductName(row);
    }

    public static void clickAddButton() {
        SeleniumTest.click(getInstance().addButton);
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static void selectProductFromList(int row) {
        SeleniumTest.check(
                WaitUntil.waitUntil(
                        ExpectedConditions.elementToBeClickable(By.xpath(
                                "//tr[@role='row'][" + row + "]/td[1]/input"
                        ))));
    }

    public static void selectFirstProductFromList() {
        selectProductFromList(1);
    }

    public static String getPriceForProduct(int row) {
        return Driver.getDriver().findElement(By.xpath("//tr[@role='row'][" + row + "]/td[4]")).getText();
    }

    public static void closeProductListModal() {
        SeleniumTest.click(getInstance().closeModaldialog);
    }

    /**
     * Searches Alacarte uberform from in product list model
     */
    public static void searchProductByName(String name) {
        staticLogger.info("Choose {} from A La Carte modal", name);
        waitUntilModalIsLoaded();
        SeleniumTest.clearAndSetText(getInstance().searchText, name);
        SeleniumTest.click(getInstance().searchButton);
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static void addAlacarteUberForm(String product_name) {
        SeleniumTest.waitForPageLoadToComplete();
        ToolPage.waitForKendoGridRefresh();
        searchProductByName(product_name);
        addAlacarteUberForm(1); //Add the first matching uberform
    }

    private static void waitForLoadingSpinnerToBeHidden() {
        SeleniumTest.waitForElementNotPresentNoWaiting(By.className("k-loading-image"));
    }

    /**
     * Search products by name and add Alacarte uberforms from product list Modal
     */
    public void addAlacarteUberForms(String... product_names) {
        SeleniumTest.waitForPageLoadToComplete();
        waitForLoadingSpinnerToBeHidden();
        for (String productName : product_names) {
            searchProductByName(productName);
            selectProductFromList(1); //Add the first matching uberform
        }
        while (getInstance().nextBtn.isDisplayed()) {
            getInstance().nextBtn.click();
            SeleniumTest.waitForJQueryAjaxDone();
        }
        clickAddButton();
    }

    /**
     * Adds Alacarte uberform from product list
     */
    public static void addAlacarteUberForm(int row) {
        SeleniumTest.waitForPageLoadToComplete();
        waitForLoadingSpinnerToBeHidden();
        selectProductFromList(row);

        //Please remove while block after FFDN-2236 is resolved
        while (getInstance().nextBtn.isDisplayed()) {
            getInstance().nextBtn.click();
            SeleniumTest.waitForJQueryAjaxDone();
        }
    }

    public static void GoToLastPage() {
        waitForLoadingSpinnerToBeHidden();
        SeleniumTest.click(getInstance().lastPage);
        WaitUntil.waitUntil(() -> getInstance().lastPage.isDisplayed());
    }

    public static void GoToNextPage(int pageNo) {
        waitForLoadingSpinnerToBeHidden();
        Driver.getDriver().findElement(By.xpath("//a[contains(\"data-page=\"" + pageNo + "\""));
    }

    //Find product from productlist modal
    public AlaCarteProductsModal GetProductItemDetails(int row) {
        productName = getAlaCarteProductName(row);
        productDescription = getAlaCarteProductPrice(row);
        productType = getAlaCarteProductType(row);
        productPrice = getAlaCarteProductPrice(row);

        return this;
    }

    public static String getAlaCarteProductName(int row) {
        return Driver.getDriver().findElement(By.xpath("//tr[@role='row'][" + row + "]/td[2]")).getText();
    }

    public static String getAlaCarteProductPrice(int row) {
        return WaitUntil.waitUntil(
                ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[@role='row'][" + row + "]/td[4]")))
                .getText();
    }

    public static String getAlaCarteProductType(int row) {
        return Driver.getDriver().findElement(By.xpath("//tr[@role='row'][" + row + "]/td[1]")).getText();
    }

    public static String getAlaCarteProductDescription(int row) {
        return Driver.getDriver().findElement(By.xpath("//tr[@role='row'][" + row + "]/td[2]/div")).getText();
    }

    public static String getShowingProductsDisplayText() {
        return WebDriver.Driver.getDriver().findElement(By.xpath("//*[@id='producttable']/div[3]/span")).getText();
    }

    public static void setFilterTextProductName(String searchStr) {
        WaitUntil.waitUntil(() -> getInstance().filterProductNameText.isDisplayed());
        SeleniumTest.clearAndSetText(getInstance().filterProductNameText, searchStr);
        SeleniumTest.waitMs(1000);
    }

    public static void clickFilterProductName() {
        WaitUntil.waitUntil(() -> getInstance().filterProductNameText.isDisplayed());
        SeleniumTest.click(getInstance().filterProductNameButton.get(0));
    }

    public static void clickFilterByProductName() {
        WaitUntil.waitUntil(() -> getInstance().filterByProductName.get(0).isDisplayed());
        SeleniumTest.click(getInstance().filterByProductName.get(0));
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static void filterByProductName(String searchStr) {
        SeleniumTest.waitMs(1000);
        clickFilterByProductName();
        SeleniumTest.waitMs(1000);
        setFilterTextProductName(searchStr);
        clickFilterProductName();
        SeleniumTest.waitMs(500);
    }

    public static void navigateTo(Integer userId) {
        staticLogger.info("Navigate to customer dashboard.");
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + "/screening/search.php?searchform=uber&availableProducts=1&OverrideUserID=" + userId);
    }

    public static void waitUntilModalIsLoaded() {
        SeleniumTest.waitForPageLoadToComplete();
        waitForLoadingSpinnerToBeHidden();
    }

    /**
     * Adds Alacarte uberform from product list
     */
    public static void addAlacarteUberForm1(int row) {
        SeleniumTest.waitForPageLoadToComplete();
        waitForLoadingSpinnerToBeHidden();
        selectProductFromList(row);
        WebElement btnnextbtn = Driver.getDriver().findElement(By.xpath("//tr[@role='row'][" + row + "]/td[2]"));
        //Please remove while block after FFDN-2236 is resolved

        btnnextbtn.click();

        SeleniumTest.waitForJQueryAjaxDone();

    }

    /**
     * Searches Alacarte uberform from in product list model
     */
    public void searchProductByName1(String name) {
        staticLogger.info("Choose {} from A La Carte modal", name);
        waitUntilModalIsLoaded();
        WebElement inpSearchWE = Driver.getDriver().findElement(By.id("generalSearch"));
        WebElement btnSearch = Driver.getDriver().findElement(By.id("generalSearchButton"));
        SeleniumTest.clearAndSetText(inpSearchWE, name);
        SeleniumTest.click(btnSearch);
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public void addAlacarteUberForm1(String product_name) {
        SeleniumTest.waitForPageLoadToComplete();
        ToolPage.waitForKendoGridRefresh();
        searchProductByName1(product_name);
    }

}