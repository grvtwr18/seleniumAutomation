package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TaskReminderPage extends TaskNotificationPage {
    static {
        PageFactory.initElements(Driver.getDriver(), TaskReminderPage.class);
    }

    @FindBy(how=How.ID, using="ReminderText")
    private static WebElement reminderText;

    public static String getReminderText() {
        return reminderText.getText();
    }

}
