package Sites.TalentWiseDashboard.SterlingOneAdmin.Workflows;

import Sites.Site;
import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import Sites.URL;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.net.URISyntaxException;

/**
 * Created by ali on 7/12/2017.
 *
 * Selenium page class for 'Admin Tools | Workflows'.
 */
public class WorkflowsPage extends ToolPage {

    private String homepageUrl = "/screening/tools.php?view=cfg_wf";

    @FindBy(how = How.ID, using = "createNew")
    private WebElement createNewButton;

    @FindBy(how = How.CLASS_NAME, using = "k-grid-header")
    private WebElement headers;

    @FindBy(how = How.CSS, using = "pageHeader")
    private WebElement pageHeader;

    @FindBy(how = How.ID, using = "Workflows")
    private WebElement workflowsContainer;

    @FindBy(how = How.ID, using = "windowDialog_wnd_title")
    private WebElement windowDialogAndTitle;

    @FindBy(how = How.ID, using = "newStep")
    private WebElement addNewStep;

    @FindBy(how = How.XPATH, using = "//*[@id='autoLaunchNew']/../label")
    private WebElement autoLaunch;

    @FindBy(how = How.XPATH, using = ".//*[@id='optionalNew']/../label")
    private WebElement skip;

    @FindBy(how = How.ID, using = "saveDesignActivate")
    private WebElement saveAndActivate;

    @FindBy(how = How.ID, using = "saveDesignReturn")
    private WebElement saveAndReturn;

    public WorkflowsPage(boolean usePseudoLocale) {
        if (usePseudoLocale) {
            homepageUrl += "?locale=qps-PLOC";
        }
    }

    public WebElement getContainer() {
        return workflowsContainer;
    }

    public WebElement getCreateNewButton() {
        return createNewButton;
    }

    public WebElement getHeaders() {
        return headers;
    }

    public WebElement getPageHeader() {
        return pageHeader;
    }
    public WorkflowsPage(){

    }
    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    /**
     * Navigates to the Admin Tools | Workflows page using a QA environment test user account
     * and then calls PageFactory.initElements.
     */
    public void navigateTo() {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + homepageUrl);
        SeleniumTest.waitForPageLoadToComplete();
        this.initializePageFactory();
    }

    /**
     * Navigates to the Admin portal with a QA environment admin account, then proxies into a test user account,
     * then navigates to the Admin Tools | Workflows page and calls PageFactory.initElements.
     */
    public void navigateToProxied(int customerUserId){
        Driver.getDriver().get(URL.getURL(Sites.Site.ADMIN_CONSOLE) +
                homepageUrl + "&OverrideUserID=" + Integer.toString(customerUserId));
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + homepageUrl);
        this.initializePageFactory();
    }

    /**
     * Clicks on the 'Create New' button on the Admin Tools Workflows page.
     * @return WorkflowsCreateNewPage initialized page object
     */
    public WorkflowsCreateNewPage clickCreateNewButton() {
        SeleniumTest.waitForPageLoadToComplete();
        initializePageFactory();
        SeleniumTest.waitMs(3000);
        SeleniumTest.click(getCreateNewButton());
        SeleniumTest.waitForPageLoadToComplete();
        WorkflowsCreateNewPage workflowsCreateNewPage = new WorkflowsCreateNewPage();
        return workflowsCreateNewPage;
    }

    public WebElement getWindowDialogAndTitle() {
        return windowDialogAndTitle;
    }

    public void clickAddNewStep() {
        SeleniumTest.click(addNewStep);
    }

    public void selectStepsInWorkflow(int[] packageId) {
        clickAddNewStep();
        for (int i = 0; i < packageId.length; i++){
            SeleniumTest.click(By.xpath(".//*[@id='"+"id"+packageId[i]+"']/../label"));
        }
    }

    //To select the steps using steps name
    public void selectStepsInWorkflowByStepName(String[] packageStepsName) {
        clickAddNewStep();
        for(String stepName : packageStepsName){
            SeleniumTest.click(By.xpath("//td[@role='gridcell' and text()='"+stepName+"']/preceding-sibling::td"));
        }
    }

    public static void workflowStepSelectByTitle(String title){
        SeleniumTest.click(By.xpath(".//span[contains(text(),'"+title+"')]/.."));
    }

    public void clickAutoLaunch() {
        if(!SeleniumTest.isCheckboxChecked(autoLaunch)) {
            SeleniumTest.click(autoLaunch);
        }
    }

    public WorkflowsCreateNewPage clickSaveActivateThenReturn(Class<? extends WorkflowsCreateNewPage> returnedClass) {
        SeleniumTest.click(saveAndActivate);
        WaitUntil.waitUntil(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//*[@class='popupNotification']")));
        SeleniumTest.click(saveAndReturn,10);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }


}