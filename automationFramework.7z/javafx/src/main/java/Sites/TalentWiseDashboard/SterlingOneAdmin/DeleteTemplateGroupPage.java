package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DeleteTemplateGroupPage extends ToolPage {
    private DeleteTemplateGroupPage page;
    public DeleteTemplateGroupPage() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    @FindBy(how=How.CSS, using="button.actionButton.primaryAction")
    private WebElement deleteButton;

    public void deleteTemplateGroup() {
        SeleniumTest.click(deleteButton);
    }
}
