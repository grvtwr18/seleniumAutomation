package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;

public class EmailChangePage extends ToolPage {
    static {
        PageFactory.initElements(Driver.getDriver(), EmailChangePage.class);
    }

    @FindBy(how = How.ID, using = "Subject")
    private static WebElement subjectLine;

    @FindBy(how = How.ID, using = "EmailChange")
    private static WebElement emailChange;

    @FindBy(how = How.ID, using = "ContactInformation")
    private static WebElement contactInformation;

    @FindBy(how = How.ID, using = "DoNotReplyMessage")
    private static WebElement doNotreplyMessage;


    @FindBy(how = How.XPATH, using = ".//a[@class='toolBreadCrumb']")
    private static WebElement backToStandardTemplateLink;

    @FindBy(how=How.ID, using="showVars")
    private static WebElement showVariables;

    @FindBy(how=How.ID, using="hideVars")
    private static WebElement hideVariables;

    public static String getShowVariables() { return SeleniumTest.getText(showVariables); }
    public static String getHideVariables() { return SeleniumTest.getText(hideVariables); }
    public static String getSubjectLine() { return SeleniumTest.getText(subjectLine); }
    public static String getEmailChange() { return SeleniumTest.getText(emailChange); }
    public static String getContactInformation() { return SeleniumTest.getText(contactInformation); }
    public static String getDoNotreplyMessage() { return SeleniumTest.getText(doNotreplyMessage); }





    @FindBy(how = How.XPATH, using=".//label[@for='Portal Name']")
    private static WebElement portalName;

    @FindBy(how = How.XPATH, using=".//label[@for='Company Name']")
    private static WebElement companyName;

    @FindBy(how = How.XPATH, using=".//label[@for='Portal Url']")
    private static WebElement portalUrl;

    @FindBy(how = How.XPATH, using="//label[@for='Candidate Email']")
    private static WebElement candidateEmail;

    @FindBy(how = How.XPATH, using="//label[@for='Candidate Name']")
    private static WebElement candidateName;

    @FindBy(how = How.XPATH, using="//label[@for='Contact Email']")
    private static WebElement contactEmail;

    @FindBy(how = How.XPATH, using="//label[@for='Contact Phone']")
    private static WebElement contactPhone;

    @FindBy(how = How.XPATH, using="//label[@for='Contact Email2']")
    private static WebElement contactEmail2;

    @FindBy(how = How.XPATH, using="//label[@for='Contact Phone2']")
    private static WebElement contactPhone2;

    @FindBy(how = How.XPATH, using="//label[@for='Logo Image']")
    private static WebElement logoImage;

    @FindBy(how = How.XPATH, using="//label[@for='From Email']")
    private static WebElement fromEmail;

    public static String getLabelPortalName() { return SeleniumTest.getText(portalName); }
    public static String getLabelCompanyName() { return SeleniumTest.getText(companyName); }
    public static String getLabelPortalUrl() { return SeleniumTest.getText(portalUrl); }
    public static String getLabelCandidateEmail() { return SeleniumTest.getText(candidateEmail); }
    public static String getLabelCandidateName() { return SeleniumTest.getText(candidateName); }
    public static String getLabelContactEmail() { return SeleniumTest.getText(contactEmail); }
    public static String getLabelContactPhone() { return SeleniumTest.getText(contactPhone); }
    public static String getLabelContactEmail2() { return SeleniumTest.getText(contactEmail2); }
    public static String getLabelContactPhone2() { return SeleniumTest.getText(contactPhone2); }
    public static String getLabelLogoImage() { return SeleniumTest.getText(logoImage); }
    public static String getLabelFromEmail() { return SeleniumTest.getText(fromEmail); }

    public static String getPortalName() { return SeleniumTest.getText(Driver.getDriver().findElement(By.id("Portal " + "Name"))); }
    public static String getCompanyName() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Company Name"))); }
    public static String getPortalUrl() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Portal Url"))); }
    public static String getCandidateEmail() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Candidate Email"))); }
    public static String getCandidateName() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Candidate Name"))); }
    public static String getContactEmail() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Contact Email"))); }
    public static String getContactPhone() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Contact Phone"))); }
    public static String getContactEmail2() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Contact Email2"))); }
    public static String getContactPhone2() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Contact Phone2"))); }
    public static String getLogoImage() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("Logo Image"))); }
    public static String getFromEmail() { return SeleniumTest.getText( Driver.getDriver().findElement(By.id("From Email"))); }

    public static void clickReturnToGroup() {
        SeleniumTest.click(backToStandardTemplateLink);
    }
}
