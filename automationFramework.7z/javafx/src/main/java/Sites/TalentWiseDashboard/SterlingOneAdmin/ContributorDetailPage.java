package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.TalentWiseDashboard.Helpers.AdminMenubar;
import Sites.TalentWiseDashboard.Helpers.Header;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by abrackett on 10/30/2015.
 */
public class ContributorDetailPage extends ToolPage {
    @FindBy(how = How.LINK_TEXT, using = "Back to Contributors")
    private static WebElement backToContributorsLink;

    // TODO: remove duplicate element
    @FindBy(how = How.LINK_TEXT, using = "Back to Contributors")
    public static WebElement backLink;

    @FindBy(how = How.ID, using = "contributorDeleteButton")
    public static WebElement deleteButton;
   // @FindBy(how = How.XPATH, using ="//*[@id='windowDialogContent']/div[2]/button[1] ")
   // public static WebElement deleteButton;
    @FindBy(how = How.CSS, using = "h2")
    public static WebElement subHeader;
    public static final String subHeaderExpectedText = "Contributor Information";

    @FindBy(how = How.XPATH, using = "//span[text()='Edit']/..")
    private static WebElement editLink;

    //<editor-fold desc="add/edit elements">
    @FindBy(how = How.NAME, using = "firstName")
    private static WebElement firstNameBox;

    @FindBy(how = How.NAME, using = "lastName")
    private static WebElement lastNameBox;

    @FindBy(how = How.XPATH, using = "//label[@for='emailAddress']")
    public static WebElement emailAddressBoxLabel;
    public static final String EMAIL_ADDRESS_BOX_LABEL_EXPECTED_TEXT = "Email Address";

    @FindBy(how = How.CSS, using = "input[name='emailAddress']")
    private static WebElement emailAddressInput;

    @FindBy(how = How.XPATH, using = "//label[@for='contributorStatus']/following-sibling::span"
                                     + "/span/span")
    private WebElement contributorStatusDropdown;

    @FindBy(how = How.CSS, using = "#loginGroups > label")
    public static WebElement loginGroupHeader;
    public static final String LOGIN_GROUP_HEADER_EXPECTED_TEXT = "Login Group(s)";

    // text input for new group
    @FindBy(how = How.NAME, using = "loginGroup")
    public static WebElement loginGroupBox;

    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Create')]")
    private WebElement createButton;

    @FindBy(how = How.XPATH, using = "//button[text()='Save']")
    private static WebElement saveButton;

    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Cancel')]")
    private static WebElement cancelButton;
    //</editor-fold>

    @FindBy(how = How.XPATH, using = "//div[@class='popupNotification']")
    private static List<WebElement> popupKendoNotifications;

    @FindBy(how = How.ID, using = "contributorStatus")
    private static WebElement status;

    // hth did this ever work? does it?
    @FindBy(how = How.ID, using = "userDetailsEdit")
    public static WebElement editButton;

    // TODO: these locators could be improved; and many should probably be split into two elements.
    @FindBy(how = How.CSS, using = "div.inputField")
    public static WebElement contributorFirstName;

    @FindBy(how = How.CSS, using = "label")
    public static WebElement firstNameBoxLabel;
    public static String firstNameBoxLabelExpectedText = "First Name";

    @FindBy(how = How.XPATH, using = "//form[@id='userForm']/div/div[2]/div/div/div[2]")
    public static WebElement contributorLastName;

    @FindBy(how = How.XPATH, using = "//label[@for='lastName']")
    public static WebElement lastNameBoxLabel;
    public static String lastNameBoxLabelExpectedText = "Last Name";

    @FindBy(how = How.XPATH, using = "//form[@id='userForm']/div/div[2]/div/div/div[3]")
    public static WebElement contributorEmailAddress;

    @FindBy(how = How.XPATH, using = "//label[text()='Contributor Group(s)']")
    public static WebElement groupLabel;

    @FindBy(how = How.CLASS_NAME, using = "validationError")
    public static WebElement errorMessage;

    private static final By CONTRIBUTOR_STATUS_LOCATOR = By.xpath(
            "//label[@for='contributorStatus']/following-sibling::span/span/span");

    @FindBy(how = How.ID, using = "createNew")
    private WebElement createNewButton;

    private static final By tempPasswordLocator = By.id("tempPassword");
    @FindBy(how = How.ID, using = "tempPassword")
    private WebElement tempPassword;

    private static ThreadLocal<ContributorDetailPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                ContributorDetailPage.class));
    }

    private static ContributorDetailPage getInstance() {
        return threadLocalInstance.get();
    }

    public static void waitForPageReady() {
        SeleniumTest.waitForJQueryAjaxDone();
        WaitUntil.waitUntil(
                () -> Driver.getDriver().findElement(By.xpath("//div[@class='sectionHead']")).isDisplayed(),
                org.openqa.selenium.NoSuchElementException.class);
    }

    /**
     * Clicks the Back to Contributors link
     */
    public ContributorsVerifiersPage clickBackToContributorsLink() {
        try {
            SeleniumTest.click(getInstance().backToContributorsLink);
        } catch (WebDriverException wde) {
            // Maybe this happens sometimes because the "Contributor updated successfully" notification blocks the link ???
            logger.info("Trying JavaScriptHelper.click() after SeleniumTest.click() of \"Back to Contributors\" link threw {}",
                    wde.getMessage());
            JavaScriptHelper.click(getInstance().backToContributorsLink);
        }

        return PageFactory.initElements(Driver.getDriver(), ContributorsVerifiersPage.class);
    }

    // TODO: fix these two to avoid page-object return when DeleteUserModal can handle it.
    public static void clickDelete() {
        SeleniumTest.click(getInstance().deleteButton);
        DeleteUserModal.waitForModalVisible();
    }

    public static void deleteContributor() {
        SeleniumTest.click(getInstance().deleteButton);
        DeleteUserModal.waitForModalVisible();
    }

    /**
     * Returns the contributor's current status
     * From the Contributor Details page - if the contributor is not editable
     * it will make the contributor editable to read the status value then return the page
     * to read only.  If the page is already editable it will remain on the edit page after
     * retrieving the status
     *
     * TODO: move this to a helper class.
     * @return
     */
    public static String getContributorStatus() {
        String text = "";

        if (getInstance().editLink.isDisplayed()) {
            SeleniumTest.click(getInstance().editLink);
            text = Driver.getDriver().findElement(getInstance().CONTRIBUTOR_STATUS_LOCATOR)
                    .getText();
            SeleniumTest.click(getInstance().cancelButton);
        } else {
            text = Driver.getDriver().findElement(getInstance().CONTRIBUTOR_STATUS_LOCATOR)
                    .getText();
        }
        return text;
    }

    public static void clickEdit() {
        waitForPopUpNotificationToGoAway();
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.click(getInstance().editLink);
        getInstance().waitForPageReady();
    }

    //<editor-fold desc="Add/edit methods">
    public static void setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(getInstance().firstNameBox, firstName);
    }

    public static void setLastName(String lastName) {
        SeleniumTest.clearAndSetText(getInstance().lastNameBox, lastName);
    }

    public static void setEmail(String email) {
        SeleniumTest.clearAndSetText(getInstance().emailAddressInput, email);
    }

    public static void setLoginGroup(String group){
        SeleniumTest.clearAndSetText(getInstance().loginGroupBox, group);
    }

    public static String getEmailAddressInputValue() {
        return getInstance().emailAddressInput.getAttribute("value");
    }

    public static List<String> getContributorStatusOptions() {
        List<String> output = new ArrayList<>();
        WebElement select =
                Driver.getDriver()
                        .findElement(By.cssSelector("select#contributorStatus"));
        WaitUntil.waitUntil(() -> select.findElement(By.tagName("option"))
                .isEnabled(), NoSuchElementException.class);
        List<WebElement> options = select.findElements(By.tagName("option"));
        for (WebElement option : options) {
            output.add(option.getAttribute("innerText"));
        }

        return output;
    }

    /**
     * Gets all Kendo popup notifications currently on the Contributor Details page.
     *
     * @return All Kendo popup notifications currently on the Contributor Details page.
     */
    public static List<WebElement> getPopupKendoNotifications() {
        return getInstance().popupKendoNotifications;
    }

    public static void selectContributorStatus(final String status) {
        final int MAX_ATTEMPTS = 3;
        final By statusItemLocator = By.xpath("//li[text()='" + status + "']");

        // In the Jenkins environment this contributorStatusDropdown refuses to select the expected status, so get aggressive about it ...
        for (int attempt = 0; !SeleniumTest.getText(getInstance().contributorStatusDropdown).equals(status); ++attempt) {

            if (MAX_ATTEMPTS <= attempt) {
                throw new InvalidElementStateException("Can't select Contributor Status = \"" + status + "\"");
            } else if (0 < attempt) {
                logger.info("#{} Waiting a second before trying to select Contributor Status = \"{}\" once again",
                        attempt, status);
                SeleniumTest.waitMs(1000);
            }

            try {
                // can't use the SeleniumTest functions for drop-downs because it's a span, not a select
                logger.info("Click on the drop-down before attempting to select \"{}\"", status);
                SeleniumTest.click(getInstance().contributorStatusDropdown);
                logger.info("Wait for item to be visible: {}", statusItemLocator);
                SeleniumTest.waitForElementVisible(statusItemLocator);
                logger.info("Wait for item to be clickable: {}", statusItemLocator);
                SeleniumTest.waitForElementToBeClickable(statusItemLocator);

                if (0 == attempt) {
                    logger.info("SeleniumTest.click(\"{}\")", statusItemLocator);
                    SeleniumTest.waitMs(2000);
                    SeleniumTest.click(statusItemLocator);
                } else {
                    logger.info("JavaScriptHelper.click(\"{}\")", statusItemLocator);
                    JavaScriptHelper.click(statusItemLocator);
                }
            } catch (WebDriverException wde) {
                logger.warn("Attempt #{} to select \"{}\" resulted in \"{}\" : \"{}\"",
                        attempt, statusItemLocator, wde.getClass(), wde.getMessage());
            }
        }
    }

    public static void clickCreateButton() {
        SeleniumTest.click(getInstance().createButton);
    }

    public static void clickSave() {
        SeleniumTest.click(getInstance().saveButton);
        PageFactory.initElements(Driver.getDriver(), ContributorDetailPage.class);
    }

    public static void clickSaveWorkaroundFDN_741() {
        SeleniumTest.click(getInstance().saveButton);
        //workaround for FDN-741
        // for some reason ContributorDetailPage.clickBackToContributors() is not working
        Header.clickAdmin();
        AdminMenubar.clickContributorsMenuItem();
        ContributorsVerifiersPage.openContributorDetailsCurrentContributor();
    }

    public static void clickCancel() {
        SeleniumTest.click(getInstance().cancelButton);
        getInstance().waitForPageReady();
    }

    public static void clickCreateNewButton() {
        SeleniumTest.click(getInstance().createNewButton);
    }

    public static boolean isTempPasswordVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(tempPasswordLocator);
    }

    public static String getTempPassword(){
        return SeleniumTest.getText(getInstance().tempPassword);
    }

    //</editor-fold>
}