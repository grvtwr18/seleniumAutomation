package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by qli on 5/26/17.
 */
public class NewPortalPage extends ToolPage {
    @FindBy(how= How.CLASS_NAME, using = "toolSetContainer")
    private static WebElement toolSetContainer;


    @FindBy(how = How.XPATH, using = "//*[@id=\"portalInfoEdit\"]/div[4]/label/i")
    private static WebElement activePortalTooltip;

    @FindBy(how = How.CLASS_NAME, using = "companyNameTooltip")
    private static WebElement companyPortalTooltip;

    @FindBy(how = How.ID, using = "activePortalNew")
    private static WebElement activePortalNew;

    @FindBy(how = How.CSS, using = "label[for='activePortalNew']")
    private static WebElement activePortalNewClickTarget;

    @FindBy(how = How.ID, using = "submitNewPortal")
    private static WebElement submitNewPortal;

    @FindBy(how=How.CSS, using="tbody>tr:first-child>td:first-child")
    private static WebElement firstPortalName;

    @FindBy(how=How.LINK_TEXT, using="Portal Name")
    private static WebElement portalName;

    @FindBy(how=How.ID, using="PortalsSearchBox")
    private static WebElement portalsSearchBox;

    @FindBy(how=How.ID, using="portalTitle")
    private static WebElement newportalTitle;
    @FindBy(how = How.XPATH, using = ".//a[@class='toolBreadCrumb']")
    private static WebElement backToPortalsLink;
    @FindBy(how=How.CSS, using="#portalInformation > div > div.sectionHead.ui-helper-clearfixd > h2")
    private static WebElement portalInformationLabel;
    @FindBy(how=How.ID, using="displayNameNew")
    private static WebElement displayNameNew;
    @FindBy(how=How.ID, using="portalDescNew")
    private static WebElement portalDescNew;
    @FindBy(how=How.ID, using="displayNameNewCounter")
    private static WebElement displayNameNewCounter;
    @FindBy(how=How.ID, using="portalDescNewCounter")
    private static WebElement portalDescNewCounter;
    @FindBy(how=How.ID, using="displayNameNewError")
    private static WebElement displayNameNewError;
    /*
    @FindBy(how=How.CSS, using="#portalInformation > div > div.sectionHead.ui-helper-clearfix > h2")
    private static WebElement portalConfiguration;
    */
    @FindBy(how=How.ID, using="portalConfigView")
    private static WebElement portalConfigView;

    @FindBy(how=How.CSS, using="#portalInformation > div > div.sectionHead.ui-helper-clearfix.portalBrandingSection > h2")
    private static WebElement portalBranding;

    @FindBy(how=How.XPATH, using="//label[@for='companyNameNew']")
    private static WebElement companyNameNewLabel;

    @FindBy(how=How.ID, using="companyNameNew")
    private static WebElement companyNameNew;

    @FindBy(how=How.CSS, using="#portalConfigControls > button.actionButton.secondaryAction")
    private static WebElement cancelButton;

    @FindBy(how=How.CSS, using="div.popupNotification > div")
    private static WebElement portalCreatedtooltip;

    @FindBy(how=How.CSS, using="#portalInfoView")
    private static WebElement portalInfoView;

    //@FindBy(how=How.CSS, using="#portalConfigView > div:nth-child(1) > div:nth-child(1)")
    @FindBy(how=How.CSS, using="i[class$=subPathTooltip]")
    private static WebElement portalUrlTooltip;

    //@FindBy(how=How.CSS, using="i[class$=companyNameTooltip]")
    @FindBy(how=How.XPATH, using="//*[@id='portalConfigView']/div[2]/div[1]/i")
    private static WebElement companyNameTooltip;

    @FindBy(how=How.ID, using="subPath")
    private static WebElement subPath;


    static {
        PageFactory.initElements(Driver.getDriver(), NewPortalPage.class);
    }

    public static void setDisplayNameNew(String string) {
        SeleniumTest.clearAndSetText(NewPortalPage.displayNameNew,string);
    }

    public static void setPortalDescNew(String string) {
        SeleniumTest.clearAndSetText(NewPortalPage.portalDescNew,string);
    }

    public static void setActivePortalNew(Boolean checked) {
        if (checked) {
            SeleniumTest.check(activePortalNewClickTarget, activePortalNew);
        } else {
            SeleniumTest.unCheck(activePortalNewClickTarget, activePortalNew);
        }
    }

    public static WebElement getToolSetContainer() {
        return toolSetContainer;
    }

    public static WebElement getActivePortalTooltip() {
        return activePortalTooltip;
    }

    public static WebElement getActiveCompanyTooltip() {
        return companyPortalTooltip;
    }

    public static String getFirstPortalName() {
        return firstPortalName.getText();
    }

    public static void toggerSort() {
        SeleniumTest.click(portalName);
    }

    public static void SearchPortal(String portal) {
        SeleniumTest.clearAndSetText(portalsSearchBox, portal);
    }

    public static String getPortalUrlTooltip(By by) {
        return getTooltip(portalUrlTooltip, By.cssSelector("div.toolSetToolTipContent"
                                                           + ".toolSetToolTipContentSmall"));
    }


    public static String getCompanyNameToolTip() {
        /*
        WebDriver driver = Driver.getDriver();
        Actions tooltip = new Actions(driver);
        tooltip.clickAndHold(companyNameNew).perform();
        */
        return getTooltip(companyNameTooltip, By.cssSelector("div.toolSetToolTipContent"
                                                             + ".toolSetToolTipContentSmall"));
    }
    public static String getNewPortalTitle() {
        return newportalTitle.getText();
    }
    public static WebElement getBackToPortals() {
        return backToPortalsLink;
    }
    public static void gobackToPortals() {
        SeleniumTest.click(backToPortalsLink);
    }
    public static String getPortalInformationLabel() {
        return portalInformationLabel.getText();
    }
    public static String getNewPortalName() {
        return displayNameNew.getText();
    }
    public static String getPortalDescNew() {
        return portalDescNew.getText();
    }
    public static String getCompanyNameNewLabel() {
        return companyNameNewLabel.getText();
    }
    public static String getCompanyNameNew() {
        return companyNameNew.getText();
    }
    public static int getPortalNameMaxCount() {
        return Integer.parseInt(displayNameNewCounter.getText());
    }
    public static int getPortalDescNewMaxCount() {
        return Integer.parseInt(portalDescNewCounter.getText());
    }
    public static String getDisplayNameNewError() {
        return displayNameNewError.getText();
    }

    public static boolean cancelButtonVisible() {
        //return SeleniumTest.verifyElementVisible(cancelButton);
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("#portalConfigControls > button.actionButton"
                                                                     + ".secondaryAction"));
    }
    public static void typePortalNameNew(String name) {
        SeleniumTest.clearAndSetText(displayNameNew, name);
    }
    public static void typePortalDescNew(String desc) {
        SeleniumTest.clearAndSetText(portalDescNew, desc);
    }
    public static String getCreatedTooltip() {
        return portalCreatedtooltip.getText();
    }
    public static String getPortalInfoViewText() {
        return portalInfoView.getText();
    }
    public static String getPortalBrandingLabel() {
        return portalBranding.getText();
    }
    public static String getPortalConfigViewText() {
        return portalConfigView.getText();
    }
    public static String getSubPath () {
        return subPath.getText();
    }

    public static void clickSubmit() {
        SeleniumTest.click(submitNewPortal);
    }

}
