package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 8/2/2016.
 */
public class ChangePasswordPage extends ToolPage{

    @FindBy(how = How.ID_OR_NAME, using = "PasswordOld")
    private static WebElement oldPassword;

    @FindBy(how = How.ID_OR_NAME, using = "Password")
    private static WebElement password;

    @FindBy(how = How.ID_OR_NAME, using = "Password2")
    private static WebElement confirmPassword;

    // the change password page
    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    public static WebElement saveButton;

    @FindBy(how = How.ID, using = "changePassword")
    public static WebElement changePasswordForm;

    @FindBy(how = How.XPATH, using = "//input[@value='Change']")
    public static WebElement changeButton;

    @FindBy(how = How.XPATH, using = "//*[@id=\"changePassword\"]/div[1]/div[3]/div")
    private static WebElement errorMessage;
    public static final String NO_MATCH_ERROR_MSG_EXPECTED_TEXT = "New Password values must match.";

    @FindBy(how = How.XPATH, using = " //*[@id=\"changePassword\"]/h3")
    private static WebElement psdChangedMessage;
    public static final String PASSWORD_CHANGED_MESSAGE = "Password successfully changed.";

    private static String pageUrl = "/screening/tools.php?view=my_acctpw&FReset=1";

    static {
        PageFactory.initElements(Driver.getDriver(), ChangePasswordPage.class);
    }

    public static void setOldPassword(String oldPassword) {
        SeleniumTest.clearAndSetText(ChangePasswordPage.oldPassword, oldPassword);
    }

    public static void setPassword(String password) {
        SeleniumTest.clearAndSetText(ChangePasswordPage.password, password);
    }

    public static void setConfirmPassword(String confirmPassword) {
        SeleniumTest.clearAndSetText(ChangePasswordPage.confirmPassword, confirmPassword);
    }

    public static String getErrorMessage() {
        return errorMessage.getText();
    }

    public static String getPsdChangedMessage() {
        return SeleniumTest.getText(psdChangedMessage);
    }

    /**
     * for use on admin and customer dashboard
     * @param oldPassword
     * @param newPassword
     */
    public static void changePasswordUIVersion2(String oldPassword, String newPassword) {
        setOldPassword(oldPassword);
        setPassword(newPassword);
        setConfirmPassword("this will not match");
        clickChangeButton();
        setConfirmPassword(newPassword);
        clickChangeButton();
    }

    /**
     * For use on the candidate portal
     * @param oldPassword
     * @param newPassword
     */
    public static void changePasswordUIVersion3(String oldPassword, String newPassword) {
        setOldPassword(oldPassword);
        setPassword(newPassword);
        setConfirmPassword("this will not match");
        clickSaveButton();
        SeleniumTest.verifyElementTextEquals(NO_MATCH_ERROR_MSG_EXPECTED_TEXT, errorMessage);
        setConfirmPassword(newPassword);
        clickSaveButton();
        SeleniumTest.verifyElementTextEquals(PASSWORD_CHANGED_MESSAGE, psdChangedMessage);
    }

    /**
     * This button is on the candidate portal change password page
     */
    public static void clickSaveButton() {
        saveButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    /**
     * this button is on the dashboard change password page
     */
    public static void clickChangeButton() {
        changeButton.click();
    }

    public static boolean onPage()
    {
        return Driver.getDriver().getCurrentUrl().contains(pageUrl);
    }
}
