package Sites.TalentWiseDashboard.SterlingOneAdmin.Modals;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by ali on 6/2/2017.
 */
public class DeleteAssetsModal extends ToolPage {

    @FindBy(how = How.CSS, using = "//button[contains(@onclick, 'clickTsDeleteAssets()')]")
    public static WebElement deleteButton;

    @FindBy(how = How.CSS, using = "//button[contains(@onclick, 'tsCloseModal(\'windowDialog\')')]")
    public static WebElement cancelButton;

    @FindBy (how = How.ID, using = "windowDialogContent")
    public static WebElement container;

    public static WebElement getContainer() {
        return container;
    }
}
