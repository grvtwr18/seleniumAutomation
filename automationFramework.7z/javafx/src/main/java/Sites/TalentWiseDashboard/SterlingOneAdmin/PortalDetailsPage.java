package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 2/16/2017.
 * Usage replaced by EditPortalPage on 6/8/2017
 */

public class PortalDetailsPage extends ToolPage {

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalBrandingNavigationControls\"]/button")
    private WebElement continueToPortalBrandingButton;

    @FindBy(how = How.XPATH, using = "//*[@id='toggleSettings' and contains (@onclick, 'showBranding')]")
    private WebElement toggleBrandingXmlDiv;

    private static ThreadLocal<PortalDetailsPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(
                () -> PageFactory.initElements(Driver.getDriver(), PortalDetailsPage.class));
    }

    private static PortalDetailsPage getInstance() {
        return threadLocalInstance.get();
    }

    public static PortalBrandingPage clickContinueToPortalBrandingButton() {
        SeleniumTest.click(getInstance().continueToPortalBrandingButton);
        return PageFactory.initElements(Driver.getDriver(), PortalBrandingPage.class);
    }

    public static boolean isToggleBrandingXmlDivPresent() {
        try {
            return getInstance().toggleBrandingXmlDiv.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}
