package Sites.TalentWiseDashboard.SterlingOneAdmin.Workflows;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * created in InteliJ IDEA 2017.2.6 by user cfrediani on 02/22/18.
 *
 * Selenium Page Class for Admin Tools | Workflows | Workflow Designer | Add Steps
 */
public class WorkflowDesignerAddStepsModal extends ToolPage {

    // ToDo cfrediani 02/22/18 improve XPATH
    // @FindBy(how = How.XPATH, using = "//[@class='staticCheckboxLabel']label")
    // @FindBy(how = How.CLASS_NAME, using = "staticCheckboxLabel")
    // @FindBy(how = How.XPATH, using = "//*[@id='uberformList']/div[2]/table/tbody/tr/td[1]/label")
    @FindBy(how = How.XPATH, using = "//*[@id='uberformList']/div[2]/table/tbody/tr/td[1]/label")
    private WebElement lineItemCheckBox;

    // @FindBy(how = How.CLASS_NAME, using = "actionButton primaryAction importSteps")
    @FindBy(how = How.XPATH, using = "//*[@id='windowDialog']/div/div[3]/button[1]")
    private WebElement addToOneGroupButton;

    @FindBy(how = How.XPATH, using = "//td[contains(text(),'New')]/preceding-sibling::td/label")
    private WebElement chkNewHire;

    @FindBy(how = How.XPATH, using = "//td[contains(text(),'Custom')]/preceding-sibling::td/label")
    private WebElement chkCustomField;

    @FindBy(how = How.XPATH, using = "//td[contains(text(),'E Verify')]/preceding-sibling::td/label")
    private WebElement chkEVerify;

    @FindBy(how = How.XPATH, using = "//td[contains(text(),'Candidate')]/preceding-sibling::td/label")
    private WebElement chkCandQuestionary;

    @FindBy (how = How.XPATH, using = "//button[text()='Add to Individual Groups']")
    private  WebElement btnAddToIndividualGroup;

    public WorkflowDesignerAddStepsModal() {
        initializePageFactory();
    }

    public WorkflowDesignerPage clickAddToOneGroupButton() {
        SeleniumTest.click(addToOneGroupButton);
        SeleniumTest.waitForPageLoadToComplete();
        return new WorkflowDesignerPage();
    }

    public void addPackagesToWrkflw(){
        chkNewHire.click();
        chkEVerify.click();
        chkCustomField.click();
        chkCandQuestionary.click();
        btnAddToIndividualGroup.click();
    }

    public WebElement getLineItemCheckBox() {
        return lineItemCheckBox;
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }
}