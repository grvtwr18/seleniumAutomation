package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import java.text.SimpleDateFormat;

/**
 * Created by kparker on 2017/06/23
 */
public class NewEmailTemplatePage extends ToolPage{

    @FindBy(how = How.ID, using = "groupNameNew")
    private static WebElement groupNameNew;

    @FindBy(how = How.ID, using = "groupDescNew")
    private static WebElement groupDescNew;

    @FindBy(how = How.CLASS_NAME, using = "pageHeader")
    private static WebElement pageHeader;

    @FindBy(how = How.ID, using = "templateGroupEdits")
    public static WebElement templateForm;

    @FindBy(how = How.ID, using = "submitTemplateGroup")
    public static WebElement saveButton;

    @FindBy(how = How.CLASS_NAME, using = "popupNotification")
    private static WebElement popupNotification;

    @FindBy(how = How.ID, using = "activeGroupEdit")
    private static WebElement activeTooltip;

    // the element that contains the text of the tooltip, only rendered on hover
    @FindBy(how = How.CLASS_NAME, using = "toolSetToolTipResetStyle")
    private static WebElement activeTooltipText;

    static {
        PageFactory.initElements(Driver.getDriver(), NewEmailTemplatePage.class);
    }

    public static WebElement getTemplateForm() {
        return templateForm;
    }

    public static WebElement getPageHeader() { return pageHeader; }

    public static WebElement getActiveTooltip() { return activeTooltip; }

    public static WebElement getActiveTooltipText() { return activeTooltipText; }

    // set all form values to default
    public static void clearForm(){
        groupNameNew.clear();
        groupDescNew.clear();
    }

    // submit the form with no entries, wait for validation error to confirm submission complete
    public static void submitEmptyForm() {
        clearForm();
        saveButton.click();
    }

    // submit a valid form to test success
    public static void submitValidForm() {
        clearForm();
        groupNameNew.sendKeys(dateToString());
        groupDescNew.sendKeys("Test description");
        saveButton.click();
    }

    // submit a form with a duplicate description to trigger error
    public static void submitDuplicateForm() {
        clearForm();
        groupNameNew.sendKeys("Standard Template Group");
        groupDescNew.sendKeys("Test");
        saveButton.click();
    }

    // get the current datetime in a string - used to create unique template name
    public static String dateToString(){
        return new SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());
    }
}