package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by btorbert on 7/31/17.
 */
public class CompanyProfilesPage extends ToolPage {
    @FindBy(how = How.CSS, using = "pageHeader")
    private WebElement pageHeader;

    @FindBy(how = How.ID, using = "profileTitle")
    private static WebElement companyProfileTitle;

    @FindBy(how = How.ID, using = "createNew")
    private static WebElement createNewButton;

    @FindBy(how = How.ID, using = "ProfilesSearchBox")
    private WebElement profilesSearchBox;

    @FindBy(how = How.CLASS_NAME, using = "k-grid-header")
    private WebElement headers;

    static {
        PageFactory.initElements(Driver.getDriver(), CompanyProfilesPage.class);
    }

    public static String getPageTitleText() {
        SeleniumTest.waitForJQueryAjaxDone();
        return companyProfileTitle.getText();
    }

    public static void clickCreateNewButton() {
        SeleniumTest.waitForJQueryAjaxDone();
        WaitUntil.waitUntil(() -> createNewButton.isDisplayed());
        createNewButton.click();
    }
}
