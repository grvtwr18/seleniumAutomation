package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by qli on 5/30/17.
 */
public class EditPortalPage {
    @FindBy(how = How.ID, using = "displayName")
    private static WebElement displayName;
    private static final By displayNameLocator = By.id("displayName");

    @FindBy(how = How.ID, using = "portalDescription")
    private static WebElement portalDescription;
    private static final By portalDescriptionLocator = By.id("portalDescription");

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalConfigView\"]/div[1]/div[2]")
    private static WebElement portalURL;

    @FindBy(how = How.ID, using = "companyName")
    private static WebElement companyName;

    @FindBy(how = How.ID, using = "portalTitle")
    private static WebElement portalTitle;

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalInfoView\"]/div[4]/i")
    private static WebElement defaultPortalTooltip;

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalConfigView\"]/div[2]/div[1]/i")
    private static WebElement companyNameTooltip;

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalInfoView\"]/div[3]/i")
    private static WebElement activePortalTooltip;

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalConfigView\"]/div[1]/div[1]/i")
    private static WebElement subPathTooltip;

    @FindBy(how = How.CLASS_NAME, using = "toolSetContainer")
    private static WebElement toolSetContainer;

    @FindBy(how = How.XPATH, using = "//button[@onclick=\"openPortalBranding()\"]")
    private static WebElement portalBrandingButton;

    @FindBy(how = How.XPATH, using = ".//*[@id='portalInfoEditToggle']//span[text()=\"Edit\"]")
    private static WebElement portalInfoEditLink;

    @FindBy(how = How.ID, using = "displayNameNew")
    private static WebElement displayNameNewTextBox;

    private static final By submitPortalInfoButtonLocator = By.id("submitPortalInfo");

    @FindBy(how = How.ID, using = "activePortal")
    private static WebElement portalActiveIndicator;

    static {
        PageFactory.initElements(Driver.getDriver(), EditPortalPage.class);
    }

    public static boolean isOnPage() {
        return SeleniumTest.isElementVisibleNoWaiting(displayNameLocator)
                && SeleniumTest.isElementVisibleNoWaiting(portalDescriptionLocator);
    }

    public static void hideVariableElements() {
        BodyTextHelper.hideElement(portalTitle);
        BodyTextHelper.hideElement(displayName);
        BodyTextHelper.hideElement(portalDescription);
        BodyTextHelper.hideElement(portalURL);
        BodyTextHelper.hideElement(companyName);
    }

    public static WebElement getSubPathTooltip() {
        return subPathTooltip;
    }

    public static WebElement getActivePortalTooltip() {
        return activePortalTooltip;
    }

    public static WebElement getDefaultPortalTooltip() {
        return defaultPortalTooltip;
    }

    public static WebElement getCompanyNameTooltip() {
        return companyNameTooltip;
    }

    public static WebElement getToolSetContainer() {
        return toolSetContainer;
    }

    public static void clickPortalBrandingButton() {
        SeleniumTest.click(portalBrandingButton);
    }

    public static void clickPortalInfoEditLink() {
        SeleniumTest.click(portalInfoEditLink);
    }

    public static void setDisplayNameNewText(String displayNameNewText) {
        SeleniumTest.clearAndSetText(displayNameNewTextBox, displayNameNewText);
    }

    public static void clickSubmitPortalInfoButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(submitPortalInfoButtonLocator);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static String getDisplayName() {
        return SeleniumTest.getText(displayName);
    }
    public static String getPortalDescription() {
        return SeleniumTest.getText(portalDescription);
    }

    public static boolean isPortalActiveIndicatorVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("activePortal"));
    }

    public static void waitForPopUpNotificationToGoAway() {
        WaitUntil.waitUntil(() -> !SeleniumTest.isElementVisibleNoWaiting(By.className("popupNotification")));
    }
}
