package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.Site;
import Sites.URL;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;

import java.net.UnknownHostException;
import java.util.List;
import java.util.stream.Collectors;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * Created by KHersey and jpflager on 5/9/2017.
 */
public class OrgHierarchyPage {
    public enum ViewMode {
        LIST, TREE
    }
    private ViewMode currentView = ViewMode.TREE;

    // It may become advantageous to have this class extend ToolPage. It's probably even more advantageous to refactor
    // most of ToolPage into some Kendo grid helper and keep not extending..
    static final String ORG_CHART_CONTAINER_ID = "chart-container";
    static final String ORG_CHART_CLASS = "orgchart";
    private static final String ORG_HIERARCHY_URL_PATH = "/screening/tools.php?view=org_orgsettings";

    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'orgListRow')]")
    private List<WebElement> allListViewOrgNodes;

    @FindBy(how = How.XPATH, using = "//span[contains(@class, 'orgListChevron')]")
    private List<WebElement> allListViewCollapsibleElements;

    @FindBy(how = How.XPATH, using = "//span[contains(@class, 'collapsibleLabel')]")
    private List<WebElement> allTreeViewCollapsibleElements;

    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'node') and not(contains(.//p, '#'))]")
    private List<WebElement> allTreeViewNewAndUnsavedOrgNodes;

    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'node') and @draggable='true']")
    private List<WebElement> allTreeViewOrgNodes;

    @FindBy(how = How.XPATH, using = "//button[@class='actionButton primaryAction']")
    private WebElement confirmationDialogPrimaryButton;

    @FindBy(how = How.XPATH, using = "//button[@class='actionButton secondaryAction']")
    private WebElement confirmationDialogSecondaryButton;

    @FindBy(how = How.ID, using = "windowDialogContent")
    private WebElement editNewOrgWithoutSavingErrorDialog;

    @FindBy(how = How.XPATH, using = "//*[contains(@class, 'actionButton primaryAction')]")
    private WebElement editNewOrgWithoutSavingErrorOkButton;

    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'orgListNew')]")
    private List<WebElement> newListViewOrgs;

    @FindBy(how = How.ID, using = "idOrgViewList")
    private WebElement orgListView;

    @FindBy(how = How.ID, using = "idOrgSearch")
    private WebElement orgSearchButton;

    @FindBy(how = How.ID, using = "idOrgSearchClear")
    private WebElement orgSearchClearSpan;

    @FindBy(how = How.ID, using = "idOrgSearchString")
    private WebElement orgSearchStringInput;

    @FindBy(how = How.ID, using = "idOrgViewTree")
    private WebElement orgTreeView;

    @FindBy(how = How.XPATH, using = "//div[@class='popupNotification']")
    private List<WebElement> popupKendoNotifications;

    @FindBy(how = How.ID, using = "idOrgChartSave")
    private WebElement saveChangesbutton;

    //<editor-fold desc="Org node sub-xpaths">
    static final By LIST_VIEW_ADD_XPATH = By.xpath(".//*[@id='idOrgViewListAdd']");
    private static final By LIST_VIEW_ALL_ORG_NODES_XPATH = By.xpath("//div[contains(@class, 'orgListRow')]");
    private static final By LIST_VIEW_BARS_XPATH = By.xpath(".//..//i[contains(@class, 'fa fa-bars')]");
    static final By LIST_VIEW_DELETE_XPATH = By.xpath(".//*[@id='idOrgViewListDelete']");
    static final By LIST_VIEW_EDIT_XPATH = By.xpath(".//*[@id='idOrgViewListEdit']");
    static final By LIST_VIEW_HIDE_OR_SHOW_XPATH = By.xpath("..//span[@class='orgListChevron']");
    static final By LIST_VIEW_NODE_NAME_XPATH = By.xpath(".//span[@contenteditable='true']");
    static final By TREE_VIEW_ADD_XPATH = By.xpath(".//i[contains(@class, 'fa fa-plus')]");
    private static final By TREE_VIEW_ALL_NODES_XPATH =
            By.xpath("//div[contains(@class, 'node') and @draggable='true']");
    static final By TREE_VIEW_DELETE_XPATH = By.xpath(".//i[contains(@class, 'fa fa-close')]");
    static final By TREE_VIEW_EDIT_XPATH = By.xpath(".//i[contains(@class, 'fa-pencil')]");
    static final By TREE_VIEW_HIDE_OR_SHOW_XPATH = By.xpath(".//span[@class='collapsibleLabel']");
    private static final By TREE_VIEW_NODE_NAME_XPATH = By.xpath(".//div[@contenteditable='true']");
    //</editor-fold>

    //<editor-fold desc="Gets and Sets">
    /**
     * Gets all the hidden orgs nodes.
     *
     * @return All the hidden org nodes found.
     */
    public List<WebElement> getAllHiddenOrgNodes() {
        return getAllOrgNodes().stream().filter(we -> !we.isDisplayed()).collect(Collectors.toList());
    }

    /**
     * Gets the newly created, unsaved org nodes in the current org hierarchy.
     *
     * @return The newly created and unsaved nodes found in the current org hierarchy.
     */
    public List<WebElement> getAllNewAndUnsavedOrgNodes() {
        if (currentView == ViewMode.TREE) {
            return allTreeViewNewAndUnsavedOrgNodes;
        } else {
            return newListViewOrgs;
        }
    }

    /**
     * Gets all the Hide/Show child node expanders on the current page in the current view.
     *
     * @return All node expanders found on the current page.
     */
    public List<WebElement> getAllNodeExpanders() {
        if (currentView == ViewMode.TREE) {
            return allTreeViewCollapsibleElements;
        } else {
            return allListViewCollapsibleElements;
        }
    }

    /**
     * Gets all the org nodes.
     *
     * @return All the visible and hidden org nodes found.
     */
    public List<WebElement> getAllOrgNodes() {
        if (currentView == ViewMode.TREE) {
            return allTreeViewOrgNodes;
        } else {
            return allListViewOrgNodes;
        }
    }

    /**
     * Gets all the visible orgs nodes.
     *
     * @return All the visible org nodes found.
     */
    public List<WebElement> getAllVisibleOrgNodes() {
        return getAllOrgNodes().stream().filter(we -> we.isDisplayed()).collect(Collectors.toList());
    }

    /**
     * Gets the Bars element at the end of the org node row with the given ID in List View. This element is used for
     * Add, Edit, and Delete operations.
     *
     * @param id The org node row element in List View to get the Bars element for.
     * @return The Bars element for the org row node with the given ID.
     */
    public WebElement getBarsElementForListViewOrg(String id) {
        return getOrgNode(id).findElement(LIST_VIEW_BARS_XPATH);
    }

    /**
     * Gets the primary button(affirming the action) on the confirmation dialog box.
     *
     * @return The primary button element on the confirmation dialog box.
     */
    public WebElement getConfirmationDialogPrimaryButton() {
        return confirmationDialogPrimaryButton;
    }

    /**
     * Gets the secondary button(cancelling the action) on the confirmation dialog box.
     *
     * @return The secondary button element on the confirmation dialog box.
     */
    public WebElement getConfirmationDialogSecondaryButton() {
        return confirmationDialogSecondaryButton;
    }

    /**
     * Gets the delete element for the org node with the given ID.
     *
     * @param id The ID of the org node to get the delete element for.
     * @return The delete icon element for the node with the given ID.
     */
    public WebElement getDeleteOrgElement(String id) {
        if (currentView == ViewMode.TREE) {
            return getOrgNode(id).findElement(TREE_VIEW_DELETE_XPATH);
        } else {
            SeleniumTest.click(getBarsElementForListViewOrg(id));
            return Driver.getDriver().findElement(LIST_VIEW_DELETE_XPATH);
        }
    }

    /**
     * Gets the error message window content element when trying to edit a new org without saving first.
     *
     * @return The error message window content element.
     */
    public WebElement getEditNewOrgWithoutSavingErrorDialog() {
        return editNewOrgWithoutSavingErrorDialog;
    }

    /**
     * Get an individual org node by ID.
     *
     * @param id The ID of the org node to get.
     * @return The org node with the given ID.
     */
    public WebElement getOrgNode(String id) {
        if (currentView == ViewMode.TREE) {
            return Driver.getDriver().findElement(By.xpath("//div[contains(@class, 'node') and @id='" + id + "']"));
        } else {
            List<WebElement> containsNumber = Driver.getDriver().findElements(
                    By.xpath("//span[contains(@class, 'orgListDes') and contains(text(), '# " + id + "')]"));
            if (containsNumber.size() == 1) {
                return containsNumber.get(0).findElement(By.xpath(".."));
            } else {
                WebElement exactElement = containsNumber.get(0);
                for (WebElement element : containsNumber) {
                    if (element.getText().equals("")) { // case where node is hidden
                        continue;
                    }
                    if (element.getText().substring(element.getText().indexOf("#") + 2).split(",")[0].equals(id)) {
                        exactElement = element;
                    }
                }
                return exactElement.findElement(By.xpath(".."));
            }
        }
    }

    /**
     * Gets all the org nodes found with the given name.
     *
     * @param name The name of the org nodes to get.
     * @return All orgs found with the given name.
     */
    public List<WebElement> getOrgNodesByName(String name) {
        if (currentView == ViewMode.TREE) {
            return Driver.getDriver().findElements(
                    By.xpath("//div[contains(@class, 'node') and contains(div/p, '" + name + "')]"));
        } else {
            return Driver.getDriver().findElements(
                    By.xpath("//span[contains(@class, 'orgListName') and contains(text(), '" + name + "')]"));
        }
    }

    /**
     * Gets the ID for an org node element.
     *
     * @param orgElement The org element to get an ID for.
     * @return The given org elements ID.
     */
    public String getOrgNodeId(WebElement orgElement)
    {
        if (currentView == ViewMode.TREE) {
            String orgInfo = orgElement.findElement(By.xpath(".//div[contains(@class, 'title')]/p")).getText();
            return orgInfo.substring(orgInfo.lastIndexOf("#") + 1).split("\\r?\\n")[0].trim();

        } else {
            return orgElement.getText().substring(orgElement.getText().lastIndexOf("#") + 1).split(",")[0].trim();
        }
    }

    /**
     * Gets the org name element which can be inline edited.
     *
     * @param id The ID of the org to get the editable name element for.
     * @return The editable name element for the given org.
     */
    public WebElement getOrgNodeNameElement(String id) {
        if (currentView == ViewMode.TREE) {
            return getOrgNode(id).findElement(TREE_VIEW_NODE_NAME_XPATH);
        } else {
            return getOrgNode(id).findElement(LIST_VIEW_NODE_NAME_XPATH);
        }
    }

    /**
     * Gets all Kendo popup notifications currently on the page.
     *
     * @return All Kendo popup notifications currently on the page.
     */
    public List<WebElement> getPopupKendoNotifications() {
        return popupKendoNotifications;
    }

    public WebElement getSearchBox() {
        return orgSearchStringInput;
    }

    /**
     * Get the current view mode the page is in.
     */
    public ViewMode getViewMode() {
        return currentView;
    }

    /**
     * Gets the 'Save Changes' button.
     *
     * @return The 'Save Changes' button.
     */
    public WebElement getSaveChangesButton() {
        return saveChangesbutton;
    }

    /**
     * Ensures the current view mode of the org hierarchy page is set to the given view.
     *
     * @param view The view to ensure is current set.
     */
    public void setViewMode(ViewMode view) {
        if (view == ViewMode.LIST) {
            if (currentView == ViewMode.TREE) {
                SeleniumTest.click(orgListView);
                currentView = ViewMode.LIST;
            }
        } else {
            if (currentView == ViewMode.LIST) {
                SeleniumTest.click(orgTreeView);
                currentView = ViewMode.TREE;
            }
        }
    }
    //</editor-fold>

    //<editor-fold desc="Filter actions">
    /**
     * Click the "X" to clear a current search.
     */
    public void clickClearSearch() {
        SeleniumTest.click(orgSearchClearSpan);
    }

    /**
     * Click the "Search" button.
     */
    public void clickSearch() {
        SeleniumTest.click(orgSearchButton);
    }

    /**
     * Filter the visible orgs using the search input.
     *
     * @param input the string to filter the visible orgs with, when Search is clicked
     */
    public void filterBy(String input) {
        SeleniumTest.clearAndSetText(orgSearchStringInput, input);
    }
    //</editor-fold>

    //<editor-fold desc="Page actions">
    /**
     * Clicks on the OK button in the error message displayed when trying to edit an un-saved org.
     */
    public void clickEditNewOrgWithoutSavingErrorOkButton() {
        SeleniumTest.click(editNewOrgWithoutSavingErrorOkButton);
    }

    /**
     * Open the org hierarchy web page in the browser.
     *
     * @throws UnknownHostException
     */
    public void navigateTo() throws UnknownHostException {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + ORG_HIERARCHY_URL_PATH);
        setViewMode(ViewMode.TREE);
        waitForOrgStructurePopulation();
    }

    /**
     * Wait for the org chart to load, by verifying 1 org node is present.
     */
    public void waitForOrgStructurePopulation() {
        if (currentView == ViewMode.TREE) {
            WaitUntil.waitUntil(ExpectedConditions.presenceOfElementLocated(TREE_VIEW_ALL_NODES_XPATH));
        } else {
            WaitUntil.waitUntil(ExpectedConditions.presenceOfElementLocated(LIST_VIEW_ALL_ORG_NODES_XPATH));
        }
    }
    //</editor-fold>
}