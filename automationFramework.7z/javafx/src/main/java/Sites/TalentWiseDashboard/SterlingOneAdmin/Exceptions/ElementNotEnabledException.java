package Sites.TalentWiseDashboard.SterlingOneAdmin.Exceptions;

import org.openqa.selenium.InvalidElementStateException;

/**
 * Created by wogden on 7/20/2015.
 */
public class ElementNotEnabledException extends InvalidElementStateException {
    public ElementNotEnabledException(String message) {
        super(message);
    }

    public ElementNotEnabledException(String message, Throwable cause) {
        super(message, cause);
    }
}