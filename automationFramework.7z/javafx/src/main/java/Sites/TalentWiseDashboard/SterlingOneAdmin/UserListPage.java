package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Data.Utf8StringCreator;
import Sites.AdminConsole.CustomerSupport.ScreeningSupport.Tickets.TicketPage;
import Sites.Site;
import Sites.TalentWiseDashboard.Helpers.AdminMenubar;
import Sites.TalentWiseDashboard.Kendo;
import Sites.URL;
import TWFramework.BasicTest;
import TWFramework.JavaScriptHelper;
import Workflows.User;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;

/**
 * Created by wogden on 2/29/2016.
 */
public class UserListPage extends ToolPage {

    @FindBy(how = How.ID, using = "createNew")
    public static WebElement createNewButton;
    @FindBy(how = How.ID, using = "UserListSearchBox")
    public static WebElement searchUsers;
    @FindBy(how = How.LINK_TEXT, using = "User ID")
    public static WebElement userIDColumnHeader;
    @FindBy(how = How.LINK_TEXT, using = "Employee ID")
    public static WebElement employeeIDColumnHeader;
    @FindBy(how = How.LINK_TEXT, using = "User Name")
    public static WebElement userNameColumnHeader;
    //because Link_TEXT Roles is on the admin sidebar
    @FindBy(how = How.XPATH, using = "//div[@id='UserList']/table/thead/tr/th[4]")
    public static WebElement rolesColumnHeader;
    @FindBy(how = How.LINK_TEXT, using = "Email Address")
    public static WebElement emailAddressColumnHeader;
    @FindBy(how = How.LINK_TEXT, using = "User Status")
    public static WebElement userStatusColumnHeader;
    public static By editIconToolTipLocator = By.cssSelector("div.toolSetToolTipContent" +
            ".toolSetToolTipContentSmall");
    @FindBy(how = How.LINK_TEXT, using = "Report Viewing")
    public static WebElement reportViewingColumnHeader;
    @FindBy(how = How.XPATH, using = "//div[@id='UserList']/table/thead/tr/th[8]")
    public static WebElement actionsColumnHeader;
    @FindBy(how = How.XPATH, using = "//span[@class='k-pager-info k-label']")
    public static WebElement userGridItemCount;
    @FindBy(how = How.ID, using = "reportviewhelp")
    public WebElement reportViewingToolTipIcon;
    public By reportViewingToolTipLocator = By.xpath("");
    @FindBy(how = How.XPATH, using = "")
    public WebElement reportViewingToolTip;
    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    public WebElement saveButton;
    @FindBy(how = How.CSS, using = "button.actionButton.secondaryAction")
    public WebElement cancelButton;
    private static final By createNewButtonLocator = By.id("createNew");

    @FindBy(how = How.XPATH, using = "//div[@id='UserList']/table/tbody/tr/td//a[contains(@href, " +
            "'user_users&op=edit')]/i")
    private static WebElement firstEditLink;

    @FindBy(how = How.XPATH, using = ".//input[@name='firstName']")
    private static WebElement subAccountUserFirstName;

    @FindBy(how = How.XPATH, using = ".//input[@name='lastName']")
    private static WebElement subAccountUserLastName;

    @FindBy(how = How.XPATH, using = ".//input[@name='phoneNumber']")
    private static WebElement subAccountUserPhoneNumber;

    @FindBy(how = How.XPATH, using = ".//input[@name='emailAddress']")
    private static WebElement subAccountUserEmailAddress;

    @FindBy(how = How.XPATH, using = ".//*[@id='userForm']/div[1]/button[1]")
    private static WebElement subAccountUserCreateButton;

    @FindBy(how = How.ID, using = "AssignedOrgs")
    private static WebElement assignedOrgs;

    @FindBy(how = How.ID, using = "addOrgs")
    private static WebElement addOrgs;

    @FindBy(how = How.XPATH, using = "//span[text()='Org1']/..//input")
    private static WebElement childOrg;

    @FindBy(how = How.CSS, using = "table > tbody > tr > td:nth-child(2) > span > span > span.k-select > span")
    private static WebElement roleSelectDropDown;

    @FindBy(how = How.CSS, using = "#gridView > div.k-grid-content.k-auto-scrollable > table > tbody > tr > td:nth-child(3) > span > span > span.k-select")
    private static WebElement accessLevelSelectDropDown;


    @FindBy(how = How.CSS, using = "body > div.k-animation-container > div > div.k-list-scroller > ul > li:nth-child(3)")
    private static WebElement roleSelect;

    @FindBy(how = How.CSS, using = "body > div.k-animation-container > div > div.k-list-scroller > ul > li:nth-child(5)")
    private static WebElement orgAccessLevelSelect;

    @FindBy(how = How.ID, using = "assignOrgsToUser")
    private static WebElement assignOrgsToUser;

    @FindBy(how = How.CSS, using ="#userForm > div > div.sectionContent > div:nth-child(2) > span > span > span.k-select > span")
    private static WebElement primaryOrg_listbox;

    @FindBy(how = How.CSS, using ="#primaryOrg_listbox > li:nth-child(2)")
    private static WebElement primaryOrgChange;

    @FindBy(how = How.XPATH, using = "//button[@class='actionButton primaryAction' and text()='Remove Organizations' ]")
    private static WebElement removeOrgBtn;

    @FindBy(how = How.XPATH, using = "//div[@class='popupNotification']//div")
    private static WebElement subaccountCreationMessage;

    @FindBy(how = How.XPATH, using = "//*[text()='Delete']")
    private static WebElement delete;

    @FindBy(how=How.XPATH, using = "//select[@data-role='dropdownlist']")
    private static WebElement dropDownListItemPerPage;

    @FindBy(how=How.CSS, using="a[title='Go to the next page']")
    private static WebElement navNext;

    /**
     * basic constructor
     */
    public UserListPage() {
        super();
        SeleniumTest.waitForElementVisible(createNewButtonLocator);
        expectedHeaderText = "User List";
        gridName = "UserList";
        kendoGridColumnOffset = 1;
    }

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(createNewButtonLocator);
    }

    public static UserListPage navigateTo(String userId) {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + "/screening/tools.php?view=user_users&OverrideUserID=" + userId);
        WaitUntil.waitUntil(() -> UserListPage.onPage());
        return PageFactory.initElements(Driver.getDriver(), UserListPage.class);
    }

    public static UserDetailsPage clickEditUser(Integer userID) {
        return clickEditUser(userID.toString());
    }

    public static UserDetailsPage clickEditUser(String userID) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//a[@id='editUser_" + userID + "']")));
        return PageFactory.initElements(Driver.getDriver(), UserDetailsPage.class);
    }

    public static UserDetailsPage clickNameToViewUserDetails(String fullName) {
        SeleniumTest.click(Driver.getDriver().findElement(By.linkText(fullName)));
        return PageFactory.initElements(Driver.getDriver(), UserDetailsPage.class);
    }

    /**
     * Clicks the Create new button
     *
     * @return userDetails page
     */
    public static UserDetailsPage createNewButtonClick() {
        SeleniumTest.waitForPageLoadToComplete();
        WaitUntil.waitUntil(() -> createNewButton.isEnabled());
        SeleniumTest.click(createNewButton);
        UserDetailsPage.setEditMode();
        UserDetailsPage.expectedHeaderText = "New User";
        return PageFactory.initElements(Driver.getDriver(), UserDetailsPage.class);
    }

    public static DeleteUserModal clickDeleteUser(Integer userID) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//a[@id='editUser_" + userID +
                "']/parent::span/following-sibling::span/a[contains(@class,'deleteIcon')]")));
        DeleteUserModal.waitForModalVisible();
        return DeleteUserModal.getInstance();
    }

    //TODO implement the others
    public static void searchForUser(String email) {
        SeleniumTest.clearAndSetText(searchUsers, email);
        SeleniumTest.waitForPageLoadToComplete();
        waitForKendoGridRefresh();
    }

    public static String getUserId(int row) {
        return SeleniumTest.getTextByLocator(By.xpath("//div[@id='UserList']/table/tbody/tr[" + row + "]/td[1]"));
    }

    public static String getUserName(int row) {
        return SeleniumTest.getTextByLocator(By.xpath("//div[@id='UserList']/table/tbody/tr[" + row + "]/td[2]"));
    }

    public static String getUserEmail(int row) {
        Kendo.waitForKendoBusyImageToGoAway();
        return SeleniumTest.getTextByLocator(By.xpath("//div[@id='UserList']/table/tbody/tr[" + row + "]/td[4]"));
    }

    public static String getUserStatus(int row) {
        return SeleniumTest.getTextByLocator(By.xpath("//div[@id='UserList']/table/tbody/tr["
                + row + "]/td[5]/span/span/span[1]"));
    }

    public static void setStatus(Integer userID, String inactive) {
        final String incoming = inactive;
        openStatusDropDown(userID);
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
        if (!statusDropDownIsOpen(userID)) {
            openStatusDropDown(userID);
        }
        WaitUntil.waitUntil(()-> statusDropDownIsOpen(userID));
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//li[text()='" + incoming + "']")));
    }

    private static boolean statusDropDownIsOpen(Integer userID) {
        return Driver.getDriver().findElement(By.xpath("//td[text()='" + userID +
                "']/following-sibling::td[4]/span")).getAttribute("aria-expanded").equals("true");
    }

    private static void openStatusDropDown(Integer userID) {
        logger.info("Open Status drop down.");
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//td[text()='" + userID +
                "']/following-sibling::td[4]/span/span/span")));
    }

    /**
     * Filters to one user and verifies the grid
     * TODO: this shouldn't be in a page class.
     */
    public static void verifyUserInGrid(User user) {
        logger.info("Converting assigned roles array into a string");
        String assignedRoles = "";
        for (String role : user.getAssignedRoles()) {
            logger.debug("Adding {}", role.toString());
            assignedRoles = assignedRoles.concat(role).concat(" ");
        }
        assignedRoles = assignedRoles.trim();
        logger.info("Creating string array for grid verification");
        String[] userString = {user.getUserId(), user.getEmployeeId(), user.getFirstName()
                + " " + user.getLastName(), assignedRoles, user.getEmailAddress()};
        searchForUser(user.getEmailAddress());
        SeleniumTest.waitForPageLoadToComplete();
        waitForKendoGridRefresh();
        // TODO; need to check User Status and Report Viewing dropdowns
        verifyNewItemInGrid(userString, 5, 1);
    }

    public static WebElement getFirstEditLink() {
        return firstEditLink;
    }

    public static void clickFirstEditLink() {
        SeleniumTest.click(firstEditLink);
    }

    public static void clickEditIcon(int userId) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//a[contains(@href,'" + userId + "')]")));
    }

    public String getReportViewing(String email) {
        return Driver.getDriver().findElement(By.xpath("//td[contains(text(), '" + email + "')]/" +
                "following-sibling::td[2]/span/span/span")).getText();
    }

    public enum ReportViewing {
        BILLING_ONLY("Billing Only"),
        SELF_ONLY("Self Only"),
        ALL("All"),
        NONE("None"),
        GROUP("Group");

        private String viewing;

        ReportViewing(String viewing) {
            this.viewing = viewing;
        }

        public String toString() {
            return viewing;
        }
    }

    public static void enterSubAccountUserEmailAddress(String emailID)
    {
        SeleniumTest.clearAndSetText(subAccountUserEmailAddress,emailID);
    }

    public static void enterSubAccountUserFisrtName(String name)
    {
        SeleniumTest.clearAndSetText(subAccountUserFirstName,name);
    }

    public static void enterSubAccountUserLastName(String name)
    {
        SeleniumTest.clearAndSetText(subAccountUserLastName,name);
    }

    public static void enterSubAccountUserPhoneNumber(String number)
    {
        SeleniumTest.clearAndSetText(subAccountUserPhoneNumber,number);
    }

    public static void clickSubAccountCreateButton()
    {
        SeleniumTest.click(subAccountUserCreateButton);
    }

    public static String getSubaccountSuccessMessage()
    {
        return SeleniumTest.getText(subaccountCreationMessage);
    }

    public static void clickAddOrg(){
        SeleniumTest.click(addOrgs);
    }

    public static void selectOrdAndAccessLevel(){
        JavaScriptHelper.click(childOrg);
        SeleniumTest.click(roleSelectDropDown);
        SeleniumTest.click(roleSelect);
        SeleniumTest.click(accessLevelSelectDropDown);
        SeleniumTest.click(orgAccessLevelSelect);
        SeleniumTest.click(assignOrgsToUser);
    }

    public static void changePrimaryOrg(){
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.click(primaryOrg_listbox);
        SeleniumTest.click(primaryOrgChange);
    }

    public static void removeOrg(String orgName){
        SeleniumTest.click(By.xpath("//td[text()='"+orgName+"']/../td[5]//a/i"));
        SeleniumTest.click(removeOrgBtn);
    }

    public void deleteUserByEmail(String email){
        SeleniumTest.click(By.xpath("//*[@id='UserList']//td[4][text()='"+email+"']/../td[7]//a[@title='Delete']"));
        SeleniumTest.click(delete);
    }

    public static void changeItemPerPage(String value){
        SeleniumTest.selectByValueFromDropDown(dropDownListItemPerPage, value);
    }

    public void navigateToNextPage(){
        SeleniumTest.click(navNext);
    }

}