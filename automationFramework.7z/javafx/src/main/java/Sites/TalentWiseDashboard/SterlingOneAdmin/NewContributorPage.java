package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.Random;

/**
 * Created by abrackett on 10/30/2015.
 */
public class NewContributorPage extends ToolPage{

    @FindBy(how = How.LINK_TEXT, using = "Back to Contributors")
    public static WebElement backLink;

    By subHeaderLocator = By.cssSelector("h2");
    @FindBy(how = How.CSS, using = "h2")
    public static WebElement subHeader;
    public static String SUB_HEADER_EXPECTED_TEXT = "Contributor Information";

    //By actionButtonsLocator = By.className("actionButton");
    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    public static WebElement createButton;

    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Save')]")
    public static WebElement SaveButton;

    @FindBy(how = How.XPATH, using = "//button[contains(text(), 'Cancel')]")
    public static WebElement cancelButton;

    @FindBy(how = How.ID, using = "contributorDeleteButton")
    public static WebElement deleteButton;

    @FindBy(how = How.ID, using = "userDetailsEdit")
    public static WebElement editButton;

    @FindBy(how = How.ID_OR_NAME, using = "firstName")
    public static WebElement firstNameBox;
    public static String FIRST_NAME_BOX_PLACEHOLDER_TEXT = "";

    @FindBy(how = How.CSS, using = "label")
    public static WebElement firstNameBoxLabel;
    public static String FIRST_NAME_BOX_LABEL_EXPECTED_TEXT = "First Name *";

    @FindBy(how = How.ID_OR_NAME, using = "lastName")
    public static WebElement lastNameBox;
    public static String LAST_NAME_BOX_PLACEHOLDER_TEXT = "";

    @FindBy(how = How.XPATH, using = "//label[@for='lastName']")
    public static WebElement lastNameBoxLabel;
    public static String LAST_NAME_BOX_LABEL_EXPECTED_TEXT = "Last Name *";

    @FindBy(how = How.ID_OR_NAME, using = "emailAddress")
    public static WebElement emailAddressBox;
    public static String EMAIL_ADDRESSBOX_PLACEHOLDER_TEXT = "";

    // TODO: change this when TOOL-780 / FDN-256 is fixed
    @FindBy(how = How.XPATH, using = "//form[@id='userForm']/div/div[2]/div/div/div[3]/label")
    public static WebElement emailAddressBoxLabel;
    public static String EMAIL_ADDRESSBOX_LABELEXPECTED_TEXT = "Email Address *";

    @FindBy (how = How.CSS, using ="#loginGroups > label")
    public static WebElement loginGroupHeader;
    public static String LOGIN_GROUP_HEADER_EXPECTED_TEXT = "Login Group(s) *";

    // text input for new group
    @FindBy(how = How.NAME, using = "loginGroup")
    public static WebElement loginGroupBox;
    public static String LOGIN_GROUP_BOX_PLACEHOLDER_HEXT = "Enter New Group";

    @FindBy (how = How.XPATH, using ="//div[@id='loginGroups']/div[2]")
    public static WebElement newLoginGroupLabel;
    public static String NEW_LOGIN_GROUP_LABEL_EXPECTED_TEXT = "Or";

    @FindBy (how = How.XPATH, using ="//label[text()='Contributors']")
    public static WebElement contributorGroupCheckBox;


    private static final By errorMessageLocator = By.className("validationError");

    public static String NOTIFICATION_TEXT_EMAIL_IN_USE = "Email Address already in use.";
    public static String NOTIFICATION_TEXT_CREATE_SUCCESSFUL = "Contributor created successfully.";

    public static String NO_LOGIN_SELECTED_ERROR_MESSAGE = "No login group selected";

    private static String loginGroupFrontHalf = "//label[contains(text(), '";
    private static String loginGroupBackHalf = "')]/preceding-sibling::input";

    static {
        expectedHeaderText = "New Contributor";
        PageFactory.initElements(Driver.getDriver(), NewContributorPage.class);
    }

    public static void setContributorGroup(){
        contributorGroupCheckBox.click();
    }


    /**
     * Constructor for the New Contributor Page Object
     * @param driver Current instance of the WebDriver
     */
    public NewContributorPage(WebDriver driver) {
        super();
        expectedHeaderText = "New Contributor";
    }

    /**
     * clicks backLink to load the contributors page, and fixes the expectedHeaderText
     */
    public static void backLinkClick() {
        // this is needed because the expectedHeaderText is static in the ToolsPage abstract class
        expectedHeaderText = "Contributors (verifiers)";
        backLink.click();
    }


    /**
     * Set the First Name in the First Name Box
     * @param firstName the first Name to set
     */
    public static void setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
    }

    /**
     * Set the last name in the last name box
     * @param lastName the last name to set
     */
    public static void setLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
    }

    /**
     * Set the email address in the email address box
     * @param emailAddress the email address to set
     */
    public static void setEmailAddress(String emailAddress) {
        SeleniumTest.clearAndSetText(emailAddressBox, emailAddress);
    }

    /**
     * Check the box for the specific login group you want
     * @param loginGroupName the login group name
     */
    public static void checkLoginGroup(String loginGroupName) {
        WebElement theLabel = Driver.getDriver().findElement(By.xpath(loginGroupFrontHalf + loginGroupName + "')]"));
        WebElement theCheckBox = Driver.getDriver().findElement(By.xpath(loginGroupFrontHalf + loginGroupName + loginGroupBackHalf));

        if(!theCheckBox.isSelected()) {
            theLabel.click();
        }
    }

    /**
     * uncheck the box for the specific login group you want
     * @param loginGroupName the login group name
     */
    public static void uncheckLoginGroup(String loginGroupName) {
        WebElement theLabel = Driver.getDriver().findElement(By.xpath(loginGroupFrontHalf + loginGroupName + "')]"));
        WebElement theCheckBox = Driver.getDriver().findElement(By.xpath(loginGroupFrontHalf + loginGroupName + loginGroupBackHalf));
        if(theCheckBox.isSelected()) {
            theLabel.click();
        }
    }

    /**
     * Checks existing login groups
     * @param loginGroup the logingroup to create
     */
    public static void setLoginGroup(String... loginGroup) {
        for(String specificGroup : loginGroup){
            try {
                WebElement element = Driver.getDriver()
                        .findElement(By.xpath("//label[text()='" + specificGroup + "']"));
                WebElement checkableElement = Driver.getDriver().findElement(
                        By.xpath("//label[text()='" + specificGroup + "']/preceding-sibling::input"));
                SeleniumTest.check(element, checkableElement);
            } catch (NoSuchElementException nse) {
                // must create a new one
                logger.info("Creating login group {}", specificGroup);
                SeleniumTest.clearAndSetText(loginGroupBox, specificGroup);
            }
        }
    }

    /**
     * Click the Create Button
     * @return ContributorDetailPage object
     */
    public static ContributorDetailPage clickCreateButton() {
        createButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
        return PageFactory.initElements(Driver.getDriver(), ContributorDetailPage.class);
    }

    /**
     * Click the Cancel Button
     */
    public static ContributorsVerifiersPage clickCancelButton() {
        cancelButton.click();
        return PageFactory.initElements(Driver.getDriver(), ContributorsVerifiersPage.class);
    }

    /**
     * Creates a new Contributor
     */
    public static String[] createNewContributor(String time, String groupName) {
        logger.info("Create new contributor");
        String[] newContributor = {"contributorFName" + time,"contributorLName" + time, "contributorEmail" + time + "@sts.com", groupName};
        firstNameBox.sendKeys(newContributor[0]);
        lastNameBox.sendKeys(newContributor[1]);
        emailAddressBox.sendKeys(newContributor[2]);
        setLoginGroup(newContributor[3]);
        clickCreateButton();
        return newContributor;
    }

    public static String[] createNewContributorStaging(String time, String groupName,int random) {
        logger.info("Create new contributor");
        String[] newContributor = {"contributorFName" + time,"contributorLName" + time, "sbctwdemo+VKR"+random+"contributor"+"@gmail.com", groupName};
        firstNameBox.sendKeys(newContributor[0]);
        lastNameBox.sendKeys(newContributor[1]);
        emailAddressBox.sendKeys(newContributor[2]);
        setLoginGroup(newContributor[3]);
        clickCreateButton();
        return newContributor;
    }

    /**
     * Wait for the given number of waitSeconds to determine whether an Error Message is showing.
     *
     * @param waitSeconds How long to wait and see if an Error Message is Visible
     * @return true if an Error Message was found within the given waitSeconds time, otherwise false.
     */
    public static boolean isErrorMessageVisibleWithinTimeLimit(int waitSeconds) {
        try {
            WaitUntil.waitUntil(waitSeconds, 1, () -> SeleniumTest.isElementVisibleNoWaiting(errorMessageLocator));
            return true;
        } catch (TimeoutException toe) {
            return false;
        }
    }

    public static String getErrorMessageText() {
        return SeleniumTest.getTextByLocator(errorMessageLocator);
    }

}
