package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TaskOverduePage extends TaskNotificationPage {
    static {
        PageFactory.initElements(Driver.getDriver(), TaskOverduePage.class);
    }

    @FindBy(how=How.ID, using="OverdueText")
    private static WebElement overdueText;

    public static String getOverdueText() {
        return overdueText.getText();
    }

}
