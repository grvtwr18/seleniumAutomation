package Sites.TalentWiseDashboard.SterlingOneAdmin.Workflows;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * created in InteliJ IDEA 2017.2.6 by user cfrediani on 02/22/18.
 *
 * Selenium page helper class for 'Admin Tools | Workflows | Workflow Details page'.
 */
public class WorkflowDetailsPage extends ToolPage {

    @FindBy(how = How.XPATH, using = "//*[@id='windowDialogContent']/div[2]/button[1]")
    private WebElement confirmDeleteButton;

    @FindBy(how = How.XPATH, using = "//*[@id='workflowDesignerAnchor']/button")
    private WebElement continueToWorkflowDesignerButton;

    @FindBy(how = How.XPATH, using = "//*[@id='deleteWorkflow']")
    private WebElement deleteButton;

    // ToDo cfrediani 02/22/18 improve XPATH
    //@FindBy(how = How.XPATH, using = "//*[contains(@class, 'fa fa-pencil')]/span")
    @FindBy(how = How.XPATH, using = "//*[@id='workflowInfoEditToggle']/div/div[2]/span/span")
    private WebElement editLink;

    @FindBy(how = How.XPATH, using = "//*[@id='saf']")
    private WebElement saveButton;

    @FindBy(how = How.XPATH, using = "//*[@id='workflowTitle']")
    private WebElement workflowTitle;

    @FindBy(how = How.XPATH, using = "//*[@id='workflowDescription']")
    private WebElement workflowDescriptionTextBox;

    @FindBy(how = How.XPATH, using = "//*[@id='displayName']")
    private WebElement workflowNameTextBox;

    public WorkflowDetailsPage() {
        initializePageFactory();
    }

    public WorkflowDesignerPage clickContinueToWorkflowDesignerButton() {
        SeleniumTest.click(continueToWorkflowDesignerButton);
        SeleniumTest.waitForPageLoadToComplete();
        return new WorkflowDesignerPage();
    }

    public WorkflowEditDetailsPage clickEditLink() {
        SeleniumTest.click(editLink);
        SeleniumTest.waitForPageLoadToComplete();
        return new WorkflowEditDetailsPage();
    }

    public WebElement getConfirmDeleteButton() {
        return confirmDeleteButton;
    }

    public WebElement getDeleteButton() {
        return deleteButton;
    }

    public WebElement getSaveButton() {
        return saveButton;
    }

    public WebElement getWorkflowDescription() {
        return workflowDescriptionTextBox;
    }

    public WebElement getWorkflowName() {
        return workflowNameTextBox;
    }

    public WebElement getWorkflowTitle() {
        return workflowTitle;
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }
}