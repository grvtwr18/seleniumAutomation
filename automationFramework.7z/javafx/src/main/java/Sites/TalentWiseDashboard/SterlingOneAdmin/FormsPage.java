package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.Site;
import Sites.URL;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import java.net.UnknownHostException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by wogden on 2/3/2016.
 */
public class FormsPage extends ToolPage {
    private static final String FORMS_URL = "/screening/tools.php?view=cfg_forms";
    private static final String EXPECTED_HEADER_CONTENT = "Forms";

    @FindBy(how = How.ID, using = "CreateButton")
    public static WebElement addNewButton;

    @FindBy(how = How.ID, using = "EditButton")
    public static WebElement editButton;

    @FindBy(how = How.ID, using = "formSearch")
    public static WebElement searchField;

    @FindBy(how = How.LINK_TEXT, using = "Form Name")
    public static WebElement formNameColumnHeader;

    @FindBy(how = How.LINK_TEXT, using = "Form Number")
    public static WebElement formNumberColumnHeader;

    @FindBy(how = How.LINK_TEXT, using = "Form Type")
    public static WebElement formTypeColumnHeader;

    @FindBy(how = How.LINK_TEXT, using = "Revision")
    public static WebElement revisionColumnHeader;

    @FindBy(how = How.LINK_TEXT, using = "Modified On")
    public static WebElement modifiedOnColumnHeader;

    @FindBy(how = How.LINK_TEXT, using = "Modified By")
    public static WebElement modifiedByColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='FormList']/table/thead/tr/th[8]")
    public static WebElement actionColumnHeader;

    /**
     * default constructor, also set's expectedHeaderText
     */
    public FormsPage() {
        super();
        SeleniumTest.waitForElementVisible(pageHeaderLocator);
        expectedHeaderText = "Forms";

    }

    /**
     * Navigates directly to the forms page URL, while logged in as a customer.
     *
     * @throws UnknownHostException
     */
    public static void navigateTo() throws UnknownHostException {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + FORMS_URL);
    }

    /**
     * Navigates directly to the forms page URL, while proxied.
     *
     * @param userId the userId to proxy
     * @throws UnknownHostException
     */
    public static void navigateToProxied(int userId) throws UnknownHostException {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + FORMS_URL + "&OverrideUserID=" + userId);
    }

    public static String getExpectedHeaderContent() {
        return EXPECTED_HEADER_CONTENT;
    }
}
