package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class NewTemplateGroupPage extends EmailTemplatesPage {

    static {
        PageFactory.initElements(Driver.getDriver(), NewTemplateGroupPage.class);
    }

    @FindBy(how=How.CSS, using="h2")
    private static WebElement templateGroupInformation;

    @FindBy(how=How.CSS, using="#page-wrapper > div > a.toolBreadCrumb")
    private static WebElement backToEmailTemplates;


    @FindBy(how=How.XPATH, using=".//label[@for='groupNameNew']")
    private static WebElement templateGroupName;
    @FindBy(how= How.XPATH, using="//input[@id='groupNameNew']")
    private static WebElement templateGroupNameValue;
    @FindBy(how=How.CSS, using="th:first-child>a.k-link")
    private static WebElement sortByTemplateGroupName;

    @FindBy(how= How.XPATH, using="//label[@for='groupDescNew']")
    private static WebElement templateGroupDescription;
    @FindBy(how= How.XPATH, using="//input[@id='groupDescNew']")
    private static WebElement templateGroupDescriptionValue;

    @FindBy(how=How.XPATH, using="//label[@for='activeGroupNew')")
    private static WebElement activeTemplateGroup;

    @FindBy(how=How.ID, using="submitTemplateGroup")
    private static WebElement createTemplateGroupButton;

    @FindBy(how=How.CSS, using="div.clearBoth.buttonContainer>button.actionButton.secondaryAction")
    private static WebElement cancelButton;

    @FindBy(how=How.CSS, using="div.popupNotification > div")
    private static WebElement groupCreated;

    @FindBy(how=How.XPATH, using="//*[@id='CandidateEmailTemplateGroupList']/table/tbody/tr[1]/td[1]/a")
    private static WebElement newTemplateGroupName;

    @FindBy(how=How.XPATH, using="//*[@id='CandidateEmailTemplateGroupList']/table/tbody/tr[1]/td[2]")
    private static WebElement newTemplateGroupDescription;

    @FindBy(how=How.CSS, using="span.disabledCheckedIcon")
    private static WebElement defaultGroupSet;

    @FindBy(how=How.ID, using="defaultGroupNotSet")
    private static WebElement defaultGroupNotSet;

    //@FindBy(how=How.CSS, using="div.actionText > span")
    @FindBy(how=How.CSS, using="tr:first-child>td>span>a[title='Edit']")
    private static WebElement editTemplate;

    @FindBy(how=How.CSS, using="#groupEdit>div>div.actionText")
    private static WebElement editTemplateGroupInfo;

    @FindBy(how = How.ID, using = "activeGroupEdit")
    private static WebElement activeGroupEdit;

    @FindBy(how = How.XPATH, using = ".//*[@id='groupEdit']//*[text()=\"Edit\"]")
    private static WebElement groupEditLink;


    public static String getBackToEmailTemplates() {
        return backToEmailTemplates.getText();
    }

    public static String getTemplateGroupName() {
        return templateGroupName.getText();
    }

    // this is for the newly created template group
    public static String getNewTemplateGroupName() {
        return newTemplateGroupName.getText();
    }

    public static void setTemplateGroupNameValue(String val) {
        SeleniumTest.clearAndSetText(templateGroupNameValue, val);
    }

    public static String getTemplateGroupDescription() {
        return templateGroupDescription.getText();
    }

    public static void setTemplateGroupDescriptionValue(String val) {
        SeleniumTest.clearAndSetText(templateGroupDescriptionValue, val);
    }

    public static String getNewTemplateGroupDescriptionValue() {
        return newTemplateGroupDescription.getText();
    }

    public static String getActiveTemplateGroup() {
        return activeTemplateGroup.getText();
    }

    public static void clickCreateTemplateGroupButton() {
        SeleniumTest.click(createTemplateGroupButton);
    }

    public static void clickCancelButton() {
        SeleniumTest.click(cancelButton);
    }


    public static void waitforGroupCreated() {
        SeleniumTest.waitForElementVisible(groupCreated);
    }

    public static boolean isDefaultGroupSelected() {
        return defaultGroupSet.isSelected();
    }

    public static void waitForDefaultGroupCheckboxVisible() {
        SeleniumTest.waitForElementVisible(defaultGroupNotSet);
    }

    public static boolean isDefaultGroupNotSet() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("defaultGroupNotSet"));
    }

    // this is for editing template group created
    public static void clickEditTemplateGroupInformation() {
        SeleniumTest.click(editTemplateGroupInfo);
    }

    public static void clickSortByTemplateGroupName() {
        SeleniumTest.click(sortByTemplateGroupName);
    }

    public static void clickGroupEditLink() {
        // Because it is very hard to be sure all Kendo Pop-Ups have gone away from blocking this link ...
        WaitUntil.waitUntil(() -> {
            SeleniumTest.click(groupEditLink);
            return true;
        }, WebDriverException.class);
    }

    public static void clickEditFormTemplate(String formName) {
        WaitUntil.waitUntil(() -> {
            SeleniumTest.click(By.xpath(".//*[text()='" + formName + "']/../../td[4]//a"));
            return true;
        }, StaleElementReferenceException.class);
    }
}
