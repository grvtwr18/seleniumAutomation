package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.Site;
import Sites.URL;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;

import java.net.UnknownHostException;

/**
 * Created by jpflager on 3/7/2016.
 */
public class SamlSsoSettingsPage extends ToolPage {
    private static final String SAML_SSO_SETTINGS_URL_PATH = "/screening/tools.php?view=cfg_sso";

    public SamlSsoSettingsPage() {
        expectedHeaderText = "SAML SSO Settings";
    }

    /**
     * Navigates directly to the SAML SSO Settings page URL for an active customer session.
     * @return a new SAML SSO Settings page object
     * @throws UnknownHostException
     */
    public static SamlSsoSettingsPage navigateTo() throws UnknownHostException {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + SAML_SSO_SETTINGS_URL_PATH);
        return PageFactory.initElements(Driver.getDriver(), SamlSsoSettingsPage.class);
    }

    /**
     * Navigates directly to the SAML SSO Settings page URL, while proxied.
     * @param userId the userId to proxy the SAML SSO Settings page for
     * @return a new SAML SSO Settings page object
     * @throws UnknownHostException
     */
    public static SamlSsoSettingsPage navigateToProxied(int userId) throws UnknownHostException {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + SAML_SSO_SETTINGS_URL_PATH + "&OverrideUserID=" + userId);
        return PageFactory.initElements(Driver.getDriver(), SamlSsoSettingsPage.class);
    }
}
