package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Data.Utf8StringCreator;
import Sites.TalentWiseDashboard.Helpers.AdminMenubar;
import TWFramework.BasicTest;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;


import static Sites.TalentWiseDashboard.SterlingOneAdmin.UserListPage.createNewButtonClick;

public class ManualSubAccountHelper {


    static {
        PageFactory.initElements(Driver.getDriver(), ManualSubAccountHelper.class);
    }

    public void createSubAccountViaManualProcess()
    {
        String alphaChar;
        Utf8StringCreator.setLength(10);
        alphaChar = Utf8StringCreator.getAlphaRand().toLowerCase();
        // Append characters based on the date to try and ensure unique names ...
        alphaChar += BasicTest.getStringUniqueToDateSeconds();
        String strFirstName = "F"+alphaChar;
        String strLastName = "L"+alphaChar;
        String strFullName = strFirstName+" "+strLastName;
        SeleniumTest.waitForPageLoadToComplete();
        createNewButtonClick();
        UserListPage.enterSubAccountUserEmailAddress("TestUser"+System.currentTimeMillis()+"@sterlingts.com");
        UserListPage.enterSubAccountUserFisrtName(strFirstName);
        UserListPage.enterSubAccountUserLastName(strLastName);
        UserListPage.enterSubAccountUserPhoneNumber("5156509898");
        UserListPage.clickSubAccountCreateButton();
    }
}
