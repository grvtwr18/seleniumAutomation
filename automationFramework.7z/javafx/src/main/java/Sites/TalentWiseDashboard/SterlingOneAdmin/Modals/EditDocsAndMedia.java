package Sites.TalentWiseDashboard.SterlingOneAdmin.Modals;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Created by wogden on 11/17/2015.
 */
public class EditDocsAndMedia extends ToolPage {

    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    public static WebElement saveButton;

    @FindBy(how = How.CSS, using = "button.actionButton.secondaryAction")
    public static WebElement cancelButton;

    // can't use a FindBy because the element is based on the assetID
    public static WebElement filePath;

    @FindBy(how = How.ID, using = "errorContainer")
    public static WebElement errorMessage;

    @FindBy (how = How.ID, using = "windowDialogContent")
    public static WebElement editAssetContainer;

    protected static Logger logger = LoggerFactory.getLogger("EditDocsAndMedia");

    /**
     * changes the asset name, saves, and captures the notification text
     * @param editAssetID
     * @param newName
     */
    public static EditDocsAndMedia changeAssetNameInEditModal(int editAssetID, String newName) {
        changeFileName(editAssetID, newName);
        saveAndGetNotification();
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    /**
     * changes the URL, saves, and sets the lastNotification value
     * @param editAssetID
     * @param newURL
     */
    public static EditDocsAndMedia changeURLTargetInEditModal(int editAssetID, String newURL) {
        changeURL(editAssetID, newURL).saveAndGetNotification();
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    /**
     * Changes the file target to replace that asset
     * @param editAssetID
     * @param newAsset
     * @return
     * @throws FileNotFoundException
     */
    public static EditDocsAndMedia changeFileTargetInEditModal(int editAssetID, File newAsset) throws FileNotFoundException {
        String newFilePathlocator = "#assetUpload_"+Integer.toString(editAssetID);
        if (!newAsset.exists()) {
            throw new FileNotFoundException("File Asset not Found at: " + newAsset.getAbsolutePath());
        }
        setFilePath(newAsset.getAbsolutePath(), newFilePathlocator).saveAndGetNotification();
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    /**
     * clears the field and sets it to the new value
     * @param assetId
     * @param newName
     * @return
     */
    private static EditDocsAndMedia changeFileName(int assetId, String newName) {
        WebElement fileName = Driver.getDriver().findElement(By.id("fileName_" + Integer.toString(assetId)));
        SeleniumTest.clearAndSetText(fileName, newName, true);
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    /**
     * clears the field and sets the new URL
     * @param assetId
     * @param newURL
     * @return
     */
    private static EditDocsAndMedia changeURL (int assetId, String newURL) {
        WebElement URL = Driver.getDriver().findElement(By.id("assetUrl_" + Integer.toString(assetId)));
        SeleniumTest.clearAndSetText(URL, newURL);
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    /**
     * Exposes the path element and puts the path in
     * @param path
     * @param filePathLocator
     * @return
     */
    private static EditDocsAndMedia setFilePath(String path, String filePathLocator) {
        String jQueryString = "jQuery('" + filePathLocator + "').show()";
        ((JavascriptExecutor) Driver.getDriver()).executeScript(jQueryString);
        SeleniumTest.waitForElementVisible(By.cssSelector(filePathLocator));
        //filePath.sendKeys(path); this doesn't work.  I'm leaving it here, becuase his is annoying
        Driver.getDriver().findElement(By.cssSelector(filePathLocator)).sendKeys(path);
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    /**
     * Saves changes to the asset and sets lastNotifiction
     * @return
     */
    public static EditDocsAndMedia saveAndGetNotification() {
        if (errorMessage.isDisplayed()) {
            throw new AssertionError("Error message is displayed.");
        }
        saveButton.click();
        lastNotification = getNotificationText();
        waitForPopUpNotificationToGoAway();
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    public static WebElement getContainer() {
        return editAssetContainer;
    }

    public static void get(String portalName) {
        Driver.getDriver().findElement(By.linkText(portalName)).click();
    }
}
