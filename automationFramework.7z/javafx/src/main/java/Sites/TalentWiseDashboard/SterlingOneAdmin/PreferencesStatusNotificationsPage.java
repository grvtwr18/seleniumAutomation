package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by ali on 6/13/2017
 */
public class PreferencesStatusNotificationsPage {

    private static final String FORMS_URL = "/screening/tools.php?view=my_acctprefs_status";
    private static final String EXPECTED_HEADER_CONTENT = "Forms";

    @FindBy(how = How.CLASS_NAME, using = "pageHeader")
    private static WebElement pageHeader;

    @FindBy(how = How.ID, using = "divFormBody")
    private static WebElement statusContainer;

    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    private static WebElement saveButton;

    @FindBy(how = How.ID, using = "tooltipDailyStatus")
    private static WebElement tooltipDailyStatus;

    @FindBy(how = How.ID, using = "tooltipAdverseActionNotifyCanceled")
    private static WebElement tooltipAdverseActionNotifyCanceled;

    @FindBy(how = How.CLASS_NAME, using = "toolSetToolTipResetStyle")
    private static WebElement toolTipText;

    static {
        PageFactory.initElements(Driver.getDriver(), PreferencesStatusNotificationsPage.class);
    }

    public static WebElement getStatusContainer() {
        return statusContainer;
    }

    public static WebElement getPageHeader() {
        return pageHeader;
    }

    public static WebElement getSaveButton() {
        return saveButton;
    }

    public static WebElement getTooltipDailyStatus() {
        return tooltipDailyStatus;
    }

    public static WebElement getTooltipAdverseActionNotifyCanceled() {
        return tooltipAdverseActionNotifyCanceled;
    }

    public static WebElement getToolTipText() {
        return toolTipText;
    }
}
