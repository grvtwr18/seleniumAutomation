package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Data.customerportal.admin.orghierarchy.Org;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by cfrediani on 6/13/2017.
 */
public class EditOrgSettingsPageHelper {
    private final Logger LOGGER = LoggerFactory.getLogger(EditOrgSettingsPageHelper.class);
    private EditOrgSettingsPage page;
    
    public EditOrgSettingsPageHelper() {
        page = PageFactory.initElements(Driver.getDriver(), EditOrgSettingsPage.class);
    }

    public EditOrgSettingsPage getPage() {
        return page;
    }

    /**
     * Compares the supplied org object's fields to the UI edit org table fields, changes any that are different, and
     * then saves the changes to the UI org edit table.
     *
     * @param editOrg The edited org object to compare to the current UI org settings, in order to change the fields
     * that are different (edited).
     * @throws InterruptedException
     */
    public void editOrgInformation(Org editOrg) throws InterruptedException {
        LOGGER.info("Click the Edit hyperlink next to Organization Information.");
        SeleniumTest.click(page.getEditOrgInformationLink());

        if (!page.getEditTableName().getAttribute("value").equals(editOrg.getName())) {
            LOGGER.info("Enter new org name: " + editOrg.getName());
            page.typeEditTableName(editOrg.getName());
        }

        if (!page.getEditTableDescription().getAttribute("value").equals(editOrg.getDescription())) {
            LOGGER.info("Enter new org description: " + editOrg.getDescription());
            page.typeEditTableDescription(editOrg.getDescription());
        }

        if (editOrg.isActive() && !page.getEditTableActiveStatus().isSelected()) {
            LOGGER.info("Activate org.");
            SeleniumTest.click(page.getEditTableActiveStatus());
        } else if (!editOrg.isActive() && !page.getEditTableInactiveStatus().isSelected()) {
            LOGGER.info("De-activate org.");
            SeleniumTest.click(page.getEditTableInactiveStatus());
        }

        if (!page.getEditTableBillingCode().getAttribute("value").equals(editOrg.getBillingCode())) {
            LOGGER.info("Enter new org billing code: " + editOrg.getBillingCode());
            page.selectEditTableBillingCode(editOrg.getBillingCode());
        }

        if (!page.getEditTableReferenceCode().getAttribute("value").equals(editOrg.getReferenceCode())) {
            LOGGER.info("Enter new org reference code: " + editOrg.getReferenceCode());
            page.selectEditTableReferenceCode(editOrg.getReferenceCode());
        }

        LOGGER.info("Click save for edits made.");
        SeleniumTest.click(page.getEditTableSaveButton());
        WaitUntil.waitUntil(() -> page.getPopupKendoNotifications().size() < 1);
    }
}