package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import java.util.Iterator;
import java.util.List;
import TWFramework.WaitUntil;

/**
 * Created by kparker on 2017/06/14
 */
public class CreditCardPage extends ToolPage{

    @FindBy(how = How.ID, using = "CC_Name")
    private static WebElement ccName;

    @FindBy(how = How.ID, using = "CC_Number")
    private static WebElement ccNumber;

    @FindBy(how = How.ID, using = "CC_SecurityCode")
    private static WebElement ccSecurityCode;

    @FindBy(how = How.ID, using = "CC_Address")
    private static WebElement ccAddress;

    @FindBy(how = How.ID, using = "CC_City")
    private static WebElement ccCity;

    @FindBy(how = How.ID, using = "CC_PostCode")
    private static WebElement ccPostcode;

    // locate the select dropdowns on the page
    @FindBy(how = How.CLASS_NAME, using = "k-dropdown")
    private static List<WebElement> ccDropdowns;

    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    public static WebElement saveButton;

    @FindBy(how = How.ID, using = "accountpayment")
    public static WebElement accountPaymentForm;

    @FindBy(how = How.CLASS_NAME, using = "errorMsg")
    public static List<WebElement> formValidationErrors;

    // the element to hover over to display the tooltip
    @FindBy(how = How.ID, using = "tooltipCC_SecurityCode")
    private static WebElement ccvTooltip;

    // the element that contains the text of the tooltip, only rendered on hover
    @FindBy(how = How.CLASS_NAME, using = "toolSetToolTipResetStyle")
    private static WebElement ccvTooltipText;

    @FindBy(how = How.CLASS_NAME, using = "popupNotification")
    private static WebElement popupNotification;

    // locate select dropdown options
    @FindBy(how = How.CLASS_NAME, using = "k-item")
    private static List<WebElement> dropdownOptions;

    static {
        PageFactory.initElements(Driver.getDriver(), CreditCardPage.class);
    }

    public static WebElement getCcvTooltip() {
        return ccvTooltip;
    }

    public static WebElement getCcvTooltipText() {
        return ccvTooltipText;
    }

    public static WebElement getAccountPaymentForm() {
        return accountPaymentForm;
    }

    // Return a string contianing all validation error mesages displayed on the form
    public static String getFormValidationErrorText(){
        String errors = "";
        for (WebElement i : formValidationErrors) {
            if(!i.getText().equals("")) {
                errors += i.getText() + "\n";
            }
        }
        return errors.trim();
    }

    public static List<WebElement> getDropdownOptions() {
        return dropdownOptions;
    }

    // set all form values to default
    public static void clearForm(){
        ccName.clear();
        ccNumber.clear();
        makeSelection(ccDropdowns.get(1), "2017");
        ccSecurityCode.clear();
        ccAddress.clear();
        ccCity.clear();
        makeSelection(ccDropdowns.get(3),"Select State/Territory");
        ccPostcode.clear();
    }

    // submit the form with no entries, wait for validation error to confirm submission complete
    public static void submitEmptyForm() {
        clearForm();
        saveButton.click();
        WaitUntil.waitUntil(30, 2, () -> formValidationErrors.get(0).isDisplayed());
    }

    // submit a form with entries that will cause validation errors
    public static void submitInvalidForm() {
        clearForm();
        ccName.sendKeys("Test");
        ccNumber.sendKeys("aaaaa");
        ccSecurityCode.sendKeys("1");
        ccAddress.sendKeys("x");
        ccCity.sendKeys("a");
        ccPostcode.sendKeys("abcde");
        saveButton.click();
        WaitUntil.waitUntil(30, 2, () -> formValidationErrors.get(1).isDisplayed());
    }

    // submit a valid form to test success
    public static void submitValidForm() {
        clearForm();
        ccName.sendKeys("Test Test");
        ccNumber.sendKeys("5105105105105100");
        makeSelection(ccDropdowns.get(1), "2027");
        ccSecurityCode.sendKeys("123");
        ccAddress.sendKeys("225 108th ave NE");
        ccCity.sendKeys("Bellevue");
        makeSelection(ccDropdowns.get(3), "Washington");
        ccPostcode.sendKeys("98004");
        saveButton.click();

        WaitUntil.waitUntil(30, 2, () -> popupNotification.isDisplayed());
    }

    public static String getPopupNotificationText(){
        return popupNotification.getText();
    }

    // helper to make a selection in the kendo dropdown options.
    private static void makeSelection(WebElement dropdown, String selection) {
        // click the dropdown to generate the options
        dropdown.click();
        // get the list of options
        List<WebElement> options = getDropdownOptions();
        for (Iterator<WebElement> iterator = options.iterator(); iterator.hasNext();) {
            WebElement next = iterator.next();
            if(next.isDisplayed() && next.getText().equals(selection)) {
                next.click();
            }
        }
    }
}