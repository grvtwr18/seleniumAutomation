package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PasswordResetPage extends FormI9InstructionPage {
    static {
        PageFactory.initElements(Driver.getDriver(), PasswordResetPage.class);
    }

    @FindBy(how=How.ID, using="PassResetText")
    private static WebElement passResetText;

    @FindBy(how=How.ID, using="ContactInformation")
    private static WebElement contactInformation;

    public static String getContactInformation() {
        return contactInformation.getText();
    }

}
