package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FormI9ReminderPage extends EmailChangePage {
    static {
        PageFactory.initElements(Driver.getDriver(), FormI9ReminderPage.class);
    }


    @FindBy(how = How.ID, using = "Salutation")
    private static WebElement salutation;

    // //div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/p
    @FindBy(how = How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td/p")
    private static WebElement emailAndPassword;

    // //div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/p[2]
    @FindBy(how = How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td/p[2]")
    private static WebElement copyright;

    @FindBy(how = How.ID, using="Instruction")
    private static WebElement instruction;

    @FindBy(how=How.CSS, using="th")
    private static WebElement task;
    @FindBy(how=How.CSS, using="th[2]")
    private static WebElement dueDate;
    @FindBy(how=How.CSS, using="th[3]")
    private static WebElement status;

    // /div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[2]/td
    @FindBy(how=How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td/table/tbody/tr[2]/td[1]")
    private static WebElement task1;
    // //div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[2]/td[2]
    @FindBy(how=How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td/table/tbody/tr[2]/td[2]")
    private static WebElement duedate1;
    // //div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[2]/td[3]
    @FindBy(how=How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td/table/tbody/tr[2]/td[3]")
    private static WebElement status1;

    // //div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[3]/td
    @FindBy(how=How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td[2]/table/tbody/tr[3]/td[1]")
    private static WebElement task2;
    // //div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[3]/td[2]
    @FindBy(how=How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td/table/tbody/tr[3]/td[2]")
    private static WebElement duedate2;
    // //div[@id='page-wrapper']/div[3]/div[2]/table/tbody/tr[2]/td[2]/table/tbody/tr[3]/td[3]
    @FindBy(how=How.XPATH, using="//div[@class='templateView']/table/tbody/tr/td/table/tbody/tr[3]/td[3]")
    private static WebElement status2;


    public static String getSalutation() { return SeleniumTest.getText(salutation); }
    public static String getEmailAndPassword() { return SeleniumTest.getText(emailAndPassword); }
    public static String getInstruction() { return SeleniumTest.getText(instruction); }
    public static String getCopyright() { return SeleniumTest.getText(copyright); }

    public static String getTask() { return SeleniumTest.getText(task); }
    public static String getDueDate() { return SeleniumTest.getText(dueDate); }
    public static String getStatus() { return SeleniumTest.getText(status); }

    public static String getTask1() { return SeleniumTest.getText(task1); }
    public static String getDueDate1() { return SeleniumTest.getText(duedate1); }
    public static String getStatus1() { return SeleniumTest.getText(status1); }

    public static String getTask2() { return SeleniumTest.getText(task2); }
    public static String getDueDate2() { return SeleniumTest.getText(duedate2); }
    public static String getStatus2() { return SeleniumTest.getText(status2); }

}
