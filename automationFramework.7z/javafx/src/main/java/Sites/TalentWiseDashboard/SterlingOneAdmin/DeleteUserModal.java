package Sites.TalentWiseDashboard.SterlingOneAdmin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by abrackett on 5/11/16.
 */
public class DeleteUserModal {

    @FindBy(how = How.XPATH, using = "//button[text()='Delete']")
    private WebElement deleteButton;

    @FindBy(how = How.XPATH, using = "//button[text()='Cancel']")
    private WebElement cancelButton;

    private static ThreadLocal<DeleteUserModal> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() ->
                PageFactory.initElements(Driver.getDriver(), DeleteUserModal.class));
    }

    public static DeleteUserModal getInstance() {
        return threadLocalInstance.get();
    }

    public static void waitForModalVisible() {
        // This identifier seems pretty ambiguous. But don't wanna break people. So have it, I guess.
        SeleniumTest.waitForElementVisible(Driver.getDriver().findElement(By.xpath("//button[text()='Delete']")));
    }

    public static void clickDelete() {
        SeleniumTest.click(getInstance().deleteButton);
    }

    /**
     * Clicks Delete in the User/Contributor Delete Modal dialog
     * @param returnedClass The page you intend to return to
     * omitting the return since the expected class will be initialized
     */
    public static void clickDelete(Class<? extends ToolPage> returnedClass) {
        getInstance().deleteButton.click();
        PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks Cancel in the User/Contributor Delete Modal dialog
     * @param returnedClass The page you intend to return to
     * omitting the return since the expected class will be initialized
     */
    public static void clickCancel(Class<? extends ToolPage> returnedClass) {
        getInstance().cancelButton.click();
        PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
