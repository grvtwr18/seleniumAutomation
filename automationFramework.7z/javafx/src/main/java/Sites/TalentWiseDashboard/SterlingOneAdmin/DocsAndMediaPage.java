package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.TalentWiseDashboard.SterlingOneAdmin.Modals.AddDocsAndMedia;
import Sites.TalentWiseDashboard.SterlingOneAdmin.Modals.EditDocsAndMedia;
import Sites.TalentWiseDashboard.SterlingOneAdmin.Modals.DeleteAssetsModal;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.BodyTextHelper;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by wogden on 6/19/2015.
 */
public class DocsAndMediaPage extends ToolPage {

    @FindBy(how = How.ID, using = "CreateButton")
    public static WebElement createButton;
    private By createButtonLocator = By.id("CreateButton");

    @FindBy(how = How.ID, using = "EditButton")
    public static WebElement editButton;

    @FindBy(how = How.ID, using = "DeleteButton")
    public static WebElement deleteButton;

    @FindBy(how = How.ID, using = "assetSearch")
    public static WebElement assetSearchField;

    @FindBy(how = How.XPATH, using = "//div[@id='ListViewToolBar']/div[5]/div/span[2]")
    public static WebElement thumbnailViewButton;

    @FindBy(how = How.XPATH, using = "//div[@id='ListViewToolBar']/div[5]/div/span")
    public static WebElement tableViewButton;

    @FindBy(how = How.LINK_TEXT, using = "Name")
    public static WebElement nameColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[2]/a/span")
    public static WebElement nameFilter;

    @FindBy(how = How.LINK_TEXT, using = "Category")
    public static WebElement categoryColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[3]/a/span")
    public static WebElement categoryFilter;

    @FindBy(how = How.LINK_TEXT, using = "Type")
    public static WebElement typeColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[4]/a/span")
    public static WebElement typeFilter;

    @FindBy(how = How.LINK_TEXT, using = "Size")
    public static WebElement sizeColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[5]/a/span")
    public static WebElement sizeFilter;

    @FindBy(how = How.LINK_TEXT, using = "Modified Date")
    public static WebElement modifiedDateColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[6]/a/span")
    public static WebElement modifiedDateFilter;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[7]")
    public static WebElement modifiedByColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[7]/a/span")
    public static WebElement modifiedByFilter;

    @FindBy(how = How.XPATH, using = "//div[@id='AssetList']/table/thead/tr/th[8]")
    public static WebElement actionsColumnHeader;

    @FindBy (how = How.ID, using = "assetSearch")
    public static WebElement assetSearch;

    @FindBy (how = How.ID, using = "page-wrapper")
    public static WebElement assetsContainer;

    @FindBy (how = How.ID, using = "dbIdFooter")
    public static WebElement footer;

    @FindBy(how = How.XPATH, using = "//td[@role='gridcell']")
    private static List<WebElement> gridCells;

    public DocsAndMediaPage() {
        super();
        SeleniumTest.waitForElementVisible(createButtonLocator);
        expectedHeaderText = "Documents and Media";
        gridName = "AssetList";
        kendoGridColumnOffset = 2;
    }

    /**
     * Opens an asset for editing
     * @param assetID
     * @return
     */
    public static EditDocsAndMedia clickAssetEditIcon(int assetID) {
        JavaScriptHelper.click(By.cssSelector("a#UpdateAsset"+assetID+" .fa.fa-pencil.largeIcon.actionIcon"));
        return PageFactory.initElements(Driver.getDriver(), EditDocsAndMedia.class);
    }

    /**
     * Opens all assets for editing
     * @return
     */
    public DocsAndMediaPage editAllAssets() {
        selectAllCheckBox.click();
        editButton.click();
        return this;
    }

    public static WebElement getContainer() {
        return assetsContainer;
    }

    /**
     * Gets an asset item web element with the given name from the Documents and Media table.
     *
     * @param assetName The table asset web element to get.
     * @return The web element for the asset with the given name.
     */
    public static WebElement getTableAsset(String assetName) {
        return Driver.getDriver().findElement(By.linkText(assetName));
    }

    /**
     * Hide elements which are either from DB or dynamic strings which no need to verify
     */
    public static void hideVariableElements() {
        // hide footer
        BodyTextHelper.hideElement(footer);

        // hide assets data
        gridCells.forEach(cell -> BodyTextHelper.hideElement(cell));
    }

    /**
     * Click Add New button goes to Add Asset modale
     * @return AddDocsAndMedia page
     */
    public static AddDocsAndMedia clickAddNewButton() {
        createButton.click();
        return PageFactory.initElements(Driver.getDriver(), AddDocsAndMedia.class);
    }

    /**
     * Click delete button go to Delete assets modal
     * @param assetID
     * @return DeleteAssetsModal
     */
    public static DeleteAssetsModal clickDeleteButton(int assetID) {
        WebElement checkbox = Driver.getDriver().findElement(By.xpath("//a[@id='deleteAsset" + assetID + "']/i"));
        checkbox.click();
        return PageFactory.initElements(Driver.getDriver(), DeleteAssetsModal.class);
    }

    public static String getSearchFormValue() {
        return assetSearch.getAttribute("placeholder");
    }

    public void openAddDocsAndMediaModal(){
        logger.info("Open the add asset modal");
        SeleniumTest.click(createButton);
    }

    public static void assetSearch(String name){
        SeleniumTest.clearAndSetText(assetSearch, name);
        SeleniumTest.waitForPageLoadToComplete();
        waitForKendoGridRefresh();
    }

    public static String getAssetName(String rowNumber) {
        return SeleniumTest.getTextByLocator(By.xpath(".//*[@id='AssetList']//tr["+rowNumber+"]/td[2]/a"));
    }

    public static int getAssetID(String name){
        return Integer.parseInt(Driver.getDriver().findElement(By.xpath(".//*[@id='AssetList']//td[2]/a[contains(text(),'"+name+"')]")).getAttribute("data-assetid"));
    }
}
