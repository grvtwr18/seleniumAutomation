package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.User;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by ali on 6/29/2017.
 */
public class RoleEditPage extends ToolPage {

    @FindBy(how = How.CSS, using = "pageHeader")
    private WebElement pageHeader;

    @FindBy(how = How.ID, using = "roleDetails")
    private WebElement roleDetails;

    // The following How.ID stopped working because two controls with
    // the same ID showed up on the same page on 05/17/2018
    //@FindBy(how = How.ID, using = "roleName")
    @FindBy(how = How.XPATH, using = "//input[@id=\"roleName\"]")
    private WebElement roleName;

    @FindBy(how = How.ID, using = "roleDescription")
    private WebElement roleDescription;

    @FindBy(how = How.ID, using = "permissionsInfoTooltipdisplay")
    private WebElement permissionsInfoTooltipdisplay;

    @FindBy(how = How.CLASS_NAME, using = "toolSetToolTipResetStyle")
    private WebElement toolSetToolTip;

    @FindBy(how = How.XPATH, using = ".//*[@id='roleDetailsEdit']//*[text()=\"Edit\"]")
    private WebElement roleDetailsEdit;

    @FindBy(how = How.CSS, using = "div#rolePermissionSetEdit div.editToggle.actionText>span")
    private WebElement rolePermissionSetEdit;

    @FindBy(how = How.ID, using = "roleForm")
    private WebElement roleForm;

    @FindBy(how = How.ID, using = "rolePermissionsForm")
    private WebElement rolePermissionsForm;

    @FindBy(how = How.ID, using = "createNew")
    private WebElement createNewRoleButton;

    @FindBy(how = How.XPATH, using = ".//*[@id='roleForm']/button[text()=\"Create\"]")
    private WebElement createButton;

    @FindBy(how = How.ID, using = "RoleListSearchBox")
    private WebElement roleListSearchBox;

    @FindBy(how = How.XPATH, using = ".//*[@id='roleForm']//button[text()=\"Save\"]")
    private WebElement saveRoleFormButton;

    @FindBy(how = How.XPATH, using = ".//*[@class='grid displayView']//tbody/tr")
    private List<WebElement> rowPermissionTable;

    @FindBy(how = How.XPATH, using = ".//form[@id=\"rolePermissionsForm\"]//button[@type='submit']")
    private WebElement saveRolePermissionsForm;

    @FindBy(how = How.ID, using = "addUsers")
    private WebElement addUsersButton;

    @FindBy(how = How.ID, using = "userSearch")
    private WebElement userSearchText;

    @FindBy(how = How.ID, using = "addUsersToRole")
    private WebElement addUsersToRoleButton;

    private static ThreadLocal<RoleEditPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(), RoleEditPage.class));
    }

    private static RoleEditPage getInstance() {
        return threadLocalInstance.get();
    }

    public static WebElement getContainer() {
        return getInstance().roleDetails;
    }

    public static WebElement getTooltip() {
        return getInstance().permissionsInfoTooltipdisplay;
    }

    public static WebElement getTooltipContent() {
        return getInstance().toolSetToolTip;
    }

    public static WebElement getRoleForm() {
        return getInstance().roleForm;
    }

    public static WebElement getRolePermissionsForm() {
        return getInstance().rolePermissionsForm;
    }

    /**
     * Hide role name and description since it's different account by account
     */
    public static void hideVariableElements() {
        BodyTextHelper.hideElement(Driver.getDriver().findElement(By.id("roleName")));
        BodyTextHelper.hideElement(Driver.getDriver().findElement(By.id("roleDescription")));
    }

    public static void clickCreateNewRoleButton() {
        SeleniumTest.click(getInstance().createNewRoleButton);
    }

    public static void typeRoleName(String roleName) {
        SeleniumTest.clearAndSetText(getInstance().roleName, roleName);
    }

    public static void typeRoleDescription(String roleDescription) {
        SeleniumTest.clearAndSetText(getInstance().roleDescription, roleDescription);
    }

    public static void clickCreateButton() {
        SeleniumTest.click(getInstance().createButton);
    }

    public static void clickRoleDetailsEditLink() {
        SeleniumTest.click(getInstance().roleDetailsEdit);
    }

    public static void clickSaveRoleFormButton() {
        SeleniumTest.click(getInstance().saveRoleFormButton);
    }

    public static void clickRolePermissionSetEditLink() {
        SeleniumTest.click(getInstance().rolePermissionSetEdit);
    }

    public static void clickSaveRolePermissionsFormButton() {
        SeleniumTest.click(getInstance().saveRolePermissionsForm);
    }

    public static void setAllPermissionsToMax() {
        for(int i = 0; i < getInstance().rowPermissionTable.size(); i++) {
            if(SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("#permissionSetId_" + i + "_3_radio"))) {
                SeleniumTest.click(By.cssSelector("#permissionSetId_" + i + "_3_radio"));
            } else {
                SeleniumTest.click(By.cssSelector("#permissionSetId_" + i + "_1_radio"));
            }
        }
    }

    public static void clickAddUsersButton() {
        SeleniumTest.click(getInstance().addUsersButton);
    }

    public static void searchForUser(String userEmailAddress) {
        SeleniumTest.clearAndSetText(getInstance().userSearchText, userEmailAddress);
        SeleniumTest.waitForPageLoadToComplete();
        waitForKendoGridRefresh();
    }

    public static void clickUserToAddCheckBox(String userId) {
        final By userIdLocator = By.xpath("//table[@class='shadow']//label[@for='id" + userId + "']");
        try {
            SeleniumTest.click(userIdLocator);
            // SeleniumTest.check() doesn't work for this staticCheckboxLabel
        } catch (WebDriverException wde) {
            // Sometimes this happens because the Kendo Busy Grid Refresh image flickers away and back.
            logger.warn("First click to Add User ID={} failed: {}", userId, wde.getMessage());
            wde.printStackTrace();
            waitForKendoGridRefresh();
            SeleniumTest.click(userIdLocator);
        }
    }

    public static void clickAddUsersToRoleButton() {
        SeleniumTest.click(getInstance().addUsersToRoleButton);
    }

    public static void searchForRole(String str) {
        SeleniumTest.clearAndSetText(getInstance().roleListSearchBox, str);
        SeleniumTest.waitForPageLoadToComplete();
        waitForKendoGridRefresh();
    }

    public static String getRoleName(String row){
        return SeleniumTest.getTextByLocator(By.xpath("//div[@id='RoleList']/table/tbody/tr[" + row + "]/td[2]"));
    }
}
