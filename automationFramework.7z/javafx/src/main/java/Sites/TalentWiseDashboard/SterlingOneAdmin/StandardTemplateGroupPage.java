    package Sites.TalentWiseDashboard.SterlingOneAdmin;

    import TWFramework.SeleniumTest;
    import WebDriver.Driver;
    import org.openqa.selenium.By;
    import org.openqa.selenium.WebElement;
    import org.openqa.selenium.support.FindBy;
    import org.openqa.selenium.support.How;
    import org.openqa.selenium.support.PageFactory;

    public class StandardTemplateGroupPage extends ToolPage {
        static {
            PageFactory.initElements(Driver.getDriver(), StandardTemplateGroupPage.class);
        }
        @FindBy(how = How.CSS, using = "h1")
        private static WebElement standardTemplateGroup;

        @FindBy(how=How.PARTIAL_LINK_TEXT, using="Back to Email Templates")
        private static WebElement backToEmailTemplates;

        @FindBy(how=How.XPATH, using="//*[@id=\"templateGroupEdits\"]/div/div[2]/div[6]/div[1]/span[1]")
        private static WebElement checkBoxActiveTemplateGroup;

        @FindBy(how=How.ID, using="defaultGroupSet")
        private static WebElement checkBoxDefaultTemplateGroup;


        //@FindBy(how=How.ID, using="duplicateGroup")
        @FindBy(how=How.CSS, using="#duplicateGroup > button[id=actionButton.secondaryAction]")
        private static WebElement duplicateGroup;

        @FindBy(how=How.ID, using="deleteGroup")
        private static WebElement deleteGroup;


        @FindBy(how = How.ID, using = "Subject")
        private static WebElement subjectLine;

        @FindBy(how=How.ID, using="activeGroupDisplay")
        private static WebElement activeGroupDisplay;

        @FindBy(how=How.CSS, using="#templateGroupEdits > div > div.sectionHead > h2")
        private static WebElement templateGroupEditsHeader;

        @FindBy(how=How.ID, using="CandidateEmailTemplateList")
        private static WebElement candidateEmailTemplateList;

        @FindBy(how=How.CSS, using="span.k-pager-info.k-label")
        private static WebElement templateTotal;

        @FindBy(how=How.ID, using="defaultGroupDisplay")
        private static WebElement defaultGroupDisplay;

        public static boolean isStandardTemplateGroupVisible() {
            return SeleniumTest.isElementVisible(standardTemplateGroup);
        }

        public static void clickReturnToGroup() {
            SeleniumTest.click(By.className("toolBreadCrumb"));
        }

        public static void clickBackToEmailTemplates() {
            SeleniumTest.click(backToEmailTemplates);
        }

        public static String getTemplateGroupEditsHeader() {
            return SeleniumTest.getText(templateGroupEditsHeader);
        }

        public static String getActiveGroupDisplayTooltip() {
            return getTooltip(activeGroupDisplay, By.cssSelector(".ui-tooltip"));
        }

        public static String getDefaultGroupDisplayTooltip() {
            return getTooltip(defaultGroupDisplay, By.cssSelector(".ui-tooltip"));
        }
        public static String getCheckBoxActiveTemplateGroup() {
            return checkBoxActiveTemplateGroup.getAttribute("class");
        }

        public static String getCheckBoxDefaultTemplateGroup() {
            return checkBoxDefaultTemplateGroup.getAttribute("class");
        }

        public static WebElement getTemplateTable()  {
            return candidateEmailTemplateList.findElement(By.className("shadow"));
        }

    }
