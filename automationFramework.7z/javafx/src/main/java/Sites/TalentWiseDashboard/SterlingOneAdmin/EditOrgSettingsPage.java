package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by cfrediani on 5/17/2017.
 */
public class EditOrgSettingsPage {
    @FindBy(how = How.XPATH, using = "//a[@class='toolBreadCrumb' and contains(@href,'view=org_orgsettings')]")
    private WebElement backToOrgTreeLink;

    @FindBy(how = How.XPATH, using = "//*[contains(@class, 'fa fa-pencil')]")
    private WebElement editOrgInformationLink;

    @FindBy(how = How.XPATH, using = "//div[@class='pageHeader']/h1")
    private WebElement pageHeaderOrgName;

    @FindBy(how = How.XPATH, using = "//*[contains(@class, 'pageTitleDetails')]")
    private WebElement pageHeaderOrgId;

    @FindBy(how = How.XPATH, using = "//div[contains(@data-bind,'orgBillingCode')]")
    private WebElement tableBillingCode;

    @FindBy(how = How.XPATH, using = "//div[contains(@id, 'orgDesc')]")
    private WebElement tableDescription;

    @FindBy(how = How.XPATH, using = "//div[contains(@data-bind, 'orgName') and not(contains(@data-bind, 'New'))]")
    private WebElement tableName;

    @FindBy(how = How.XPATH, using = "//div[contains(@data-bind,'orgReferenceCode')]")
    private WebElement tableReferenceCode;

    @FindBy(how = How.XPATH, using = "//div[@id='orgStatus']")
    private WebElement tableStatus;

    @FindBy(how = How.XPATH, using = "//*[@id='activeOrgActive' and @class='styledRadio']")
    private WebElement editTableActiveStatus;

    @FindBy(how = How.XPATH, using = "//*[contains(@data-bind,'orgBillingCodes')]")
    private WebElement editTableBillingCode;

    @FindBy(how = How.XPATH, using = "//*[@class='actionButton secondaryAction']")
    private WebElement editTableCancelButton;

    @FindBy(how = How.XPATH, using = "//*[@id='orgDescNew']")
    private WebElement editTableDescription;

    @FindBy(how = How.XPATH, using = "//*[@id='activeOrgInactive' and @class='styledRadio']")
    private WebElement editTableInactiveStatus;

    @FindBy(how = How.XPATH, using = "//*[@id='orgNameNew']")
    private WebElement editTableName;

    @FindBy(how = How.XPATH, using = "//*[contains(@data-bind,'orgReferenceCodes')]")
    private WebElement editTableReferenceCode;

    @FindBy(how = How.XPATH, using = "//*[@id='submitOrgInfo']")
    private WebElement editTableSaveButton;

    @FindBy(how = How.XPATH, using = "//div[contains(@data-bind,'orgNameNewErr')]")
    private WebElement editTableSaveWithBlankOrgNameError;

    @FindBy(how = How.XPATH, using = "//div[@class='popupNotification']")
    private List<WebElement> popupKendoNotifications;

    /**
     * Gets the element linking back to the org hierarchy page.
     *
     * @return The return link element to the org hierarchy page.
     */
    public WebElement getBackToOrgTreeLink() {
        return backToOrgTreeLink;
    }

    /**
     * Gets the org name from the page header of the org currently being edited.
     *
     * @return The org name text element in the page header of the org being edited.
     */
    public WebElement getPageHeaderOrgName() {
        return pageHeaderOrgName;
    }

    /**
     * Gets the org ID from the page header of the org currently being edited.
     *
     * @return The org ID text element in the page header of the org being edited.
     */
    public WebElement getPageHeaderOrgId() {
        return pageHeaderOrgId;
    }

    /**
     * Gets all Kendo popup notifications currently on the edit org settings page.
     *
     * @return All Kendo popup notifications currently on the edit org settings page.
     */
    public List<WebElement> getPopupKendoNotifications() {
        return popupKendoNotifications;
    }

    /**
     * Gets the org info table Billing Code in view mode.
     *
     * @return The Billing Code text element for the org info table in view mode.
     */
    public WebElement getTableBillingCode() {
        return tableBillingCode;
    }

    /**
     * Gets the org info table Organization Description in view mode.
     *
     * @return The Organization Description text element for the org info table in view mode.
     */
    public WebElement getTableDescription() {
        return tableDescription;
    }

    /**
     * Gets the org info table Organization Name in view mode.
     *
     * @return The Organization Name text element for the org info table in view mode.
     */
    public WebElement getTableName() {
        return tableName;
    }

    /**
     * Gets the org info table Reference Code in view mode.
     *
     * @return The Reference Code text element for the org info table in view mode.
     */
    public WebElement getTableReferenceCode() {
        return tableReferenceCode;
    }

    /**
     * Gets the org info table Status in view mode.
     *
     * @return The Status text element for the org info table in view mode.
     */
    public WebElement getTableStatus() {
        return tableStatus;
    }

    /**
     * Gets the Edit link used to switch the org table from view mode to edit mode.
     *
     * @return The link used to switch the org table from view mode to edit mode.
     */
    public WebElement getEditOrgInformationLink() {
        return editOrgInformationLink;
    }

    /**
     * Gets the org info table Active Status radio button in edit mode.
     *
     * @return The Active Status radio button element for the org info table in edit mode.
     */
    public WebElement getEditTableActiveStatus() {
        return editTableActiveStatus;
    }

    /**
     * Gets the org info table Billing Code dropdown menu in edit mode.
     *
     * @return The Billing Code dropdown menu element for the org info table in edit mode.
     */
    public WebElement getEditTableBillingCode() {
        return editTableBillingCode;
    }

    /**
     * Gets the org info table Cancel button in edit mode.
     *
     * @return The Cancel button element for the org info table in edit mode.
     */
    public WebElement getEditTableCancelButton() {
        return editTableCancelButton;
    }

    /**
     * Gets the org info table Organization Description text box in edit mode.
     *
     * @return The Organization Description text box element for the org info table in edit mode.
     */
    public WebElement getEditTableDescription() {
        return editTableDescription;
    }

    /**
     * Gets the org info table Inactive Status radio button in edit mode.
     *
     * @return The Inactive Status radio button element for the org info table in edit mode.
     */
    public WebElement getEditTableInactiveStatus() {
        return editTableInactiveStatus;
    }

    /**
     * Gets the org info table Organization Name text box in edit mode.
     *
     * @return The Organization Name text box element for the org info table in edit mode.
     */
    public WebElement getEditTableName() {
        return editTableName;
    }

    /**
     * Gets the org info table Reference Code dropdown menu in edit mode.
     *
     * @return The Reference Code dropdown menu element for the org info table in edit mode.
     */
    public WebElement getEditTableReferenceCode() {
        return editTableReferenceCode;
    }

    /**
     * Gets the org info table Save button in edit mode.
     *
     * @return The Save button element for the org info table in edit mode.
     */
    public WebElement getEditTableSaveButton() {
        return editTableSaveButton;
    }

    /**
     * Gets the text error element shown under the Name when trying to save a empty string org name in edit mode.
     *
     * @return The red text error element displayed when trying to save an empty string for org name in edit mode.
     */
    public WebElement getEditTableSaveWithBlankOrgNameError() {
        return editTableSaveWithBlankOrgNameError;
    }

    /**
     * Selects the given code from the Billing Code dropdown menu element in edit mode.
     *
     * @param code The code to select from the Billing Code dropdown menu element in edit mode.
     */
    public void selectEditTableBillingCode(String code) {
        SeleniumTest.selectByVisibleTextFromDropDown(editTableBillingCode, code);
    }

    /**
     * Selects the given code from the Reference Code dropdown menu element in edit mode.
     *
     * @param code The code to select from the Reference Code dropdown menu element in edit mode.
     */
    public void selectEditTableReferenceCode(String code) {
        SeleniumTest.selectByVisibleTextFromDropDown(editTableReferenceCode, code);
    }

    /**
     * Clears and types the given org description into the Organization Description text box in edit mode.
     *
     * @param description The new ord description to type into the Organization Description text box in edit mode.
     */
    public void typeEditTableDescription(String description) {
        SeleniumTest.click(editTableDescription);
        SeleniumTest.clearAndSetText(editTableDescription, description);
    }

    /**
     * Clears and types the given org name into the Organization Name text box in edit mode.
     *
     * @param name The new ord description to type into the Organization Name text box in edit mode.
     */
    public void typeEditTableName(String name) {
        SeleniumTest.click(editTableName);
        SeleniumTest.clearAndSetText(editTableName, name);
    }
}