package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by qli on 6/13/17.
 */
public class PreferencesGeneralNotificationsPage {

    @FindBy(how = How.ID, using = "divFormBody")
    private static WebElement formbody;

    @FindBy(how = How.CLASS_NAME, using = "pageHeader")
    private static WebElement pageHeader;

    @FindBy(how = How.XPATH, using = "//*[@id=\"page-wrapper\"]/div[3]/div[1]/button")
    private static WebElement saveButton;

    static {
        PageFactory.initElements(Driver.getDriver(), PreferencesGeneralNotificationsPage.class);
    }

    public static WebElement getFormbody() {
        return formbody;
    }

    public static String getSaveButtonText() {
        return saveButton.getText();
    }

    public static String getPageHeader() {
        return pageHeader.getText();
    }
}
