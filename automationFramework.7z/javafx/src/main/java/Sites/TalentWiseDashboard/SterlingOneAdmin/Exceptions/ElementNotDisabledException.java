package Sites.TalentWiseDashboard.SterlingOneAdmin.Exceptions;

import org.openqa.selenium.InvalidElementStateException;

/**
 * Created by wogden on 7/20/2015.
 */
public class ElementNotDisabledException extends InvalidElementStateException {
    public ElementNotDisabledException(String message) {
        super(message);
    }

    public ElementNotDisabledException(String message, Throwable cause) {
        super(message, cause);
    }
}