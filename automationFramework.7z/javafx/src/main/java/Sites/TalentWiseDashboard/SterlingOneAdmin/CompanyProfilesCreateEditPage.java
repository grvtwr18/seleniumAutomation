package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by btorbert on 7/31/17.
 */
public class CompanyProfilesCreateEditPage extends ToolPage {

    @FindBy(how = How.ID, using = "profileTitle")
    private static WebElement companyProfileTitle;

    @FindBy(how = How.ID, using = "profileNameNew")
    private static WebElement editCompanyProfileInfoLink;

    @FindBy(how = How.ID, using = "profileNameNew")
    private static WebElement profileNameTextBox;

    @FindBy(how = How.ID, using = "profileNameNewError")
    private static WebElement profileNameErrorMessage;

    @FindBy(how = How.ID, using = "profileDescNew")
    private static WebElement profileDescriptionTextBox;

    @FindBy(how = How.ID, using = "profileTypeI9")
    private static WebElement i9ProfileTypeCheckBox;

    @FindBy(how = How.ID, using = "profileTypeNewHireForms")
    private static WebElement newHireFormsProfileTypeCheckBox;

    @FindBy(how = How.ID, using = "profileSectionsNewError")
    private static WebElement profileTypeErrorMessage;

    @FindBy(how = How.ID, using = "activeProfile")
    private static WebElement activeRadioButton;

    @FindBy(how = How.ID, using = "inActiveProfile")
    private static WebElement inactiveRadioButton;

    @FindBy(how = How.ID, using = "profileDefaultNew")
    private static WebElement makeDefaultProfileCheckBox;

    @FindBy(how = How.ID, using = "submitProfileInfo")
    private static WebElement profileInfoSaveButton;

    @FindBy(how = How.ID, using = "cancelProfileInfo")
    private static WebElement profileInfoCancelButton;

    static {
        PageFactory.initElements(Driver.getDriver(), CompanyProfilesCreateEditPage.class);
    }

    public static String getPageTitleText() {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.waitForPageLoadToComplete();
        return companyProfileTitle.getText();
    }

    // Company Profile Information section
    public static void clickEditProfileInfoLink() {
        editCompanyProfileInfoLink.click();
    }

    public static void enterCompanyProfileName(String name) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(profileNameTextBox, name);
    }

    public static void enterCompanyProfileDescription(String name) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(profileDescriptionTextBox, name);
    }

    public static void setI9ProfileTypeCheckBox() {
        i9ProfileTypeCheckBox.click();
    }

    public static void setNewHireFormsProfileTypeCheckBox() {
        newHireFormsProfileTypeCheckBox.click();
    }

    public static void setActiveRadioButton() {
        activeRadioButton.click();
    }

    public static void setInactiveRadioButton() {
        inactiveRadioButton.click();
    }

    public static void setMakeDefaultProfileCheckBox() {
        makeDefaultProfileCheckBox.click();
    }

    public static void clickProfileInfoSaveButton() {
        SeleniumTest.waitForJQueryAjaxDone();
        profileInfoSaveButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static void clickProfileInfoCancelButton() {
        profileInfoCancelButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static String getProfileNameErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return profileNameErrorMessage.getText();
    }

    public static String getProfileTypeErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return profileTypeErrorMessage.getText();
    }

    // I-9 and E-Verify section
    @FindBy(how = How.ID, using = "editEverifyInfo")
    private static WebElement editI9EverifyInfoLink;

    @FindBy(how = How.ID, using = "clientCompanyIdNew")
    private static WebElement clientCompanyIdTextBox;

    @FindBy(how = How.ID, using = "clientCompanyIdNewError")
    private static WebElement clientCompanyIdErrorMessage;

    @FindBy(how = How.ID, using = "earliestYearAllowedNew")
    private static WebElement earliestYearAllowedDropDown;

    @FindBy(how = How.ID, using = "enableHistoricalDataNew")
    private static WebElement enableHistoricalI9CheckBox;

    @FindBy(how = How.ID, using = "everifyEmployerNameNew")
    private static WebElement i9EverifyEmployerNameTextBox;

    @FindBy(how = How.ID, using = "everifyEmployerAddressNew")
    private static WebElement i9EverifyEmployerAddressTextBox;

    @FindBy(how = How.ID, using = "everifyEmployerAddressNewError")
    private static WebElement i9EverifyEmployerAddressErrorMessage;

    @FindBy(how = How.ID, using = "everifyEmployerCityNew")
    private static WebElement i9EverifyEmployerCityTextBox;

    @FindBy(how = How.ID, using = "everifyEmployerCityNewError")
    private static WebElement i9EverifyEmployerCityErrorMessage;

    @FindBy(how = How.ID, using = "everifyEmployerStateNew")
    private static WebElement i9EverifyEmployerStateDropDown;

    @FindBy(how = How.ID, using = "everifyEmployerStateNewError")
    private static WebElement i9EverifyEmployerStateErrorMessage;

    @FindBy(how = How.ID, using = "everifyEmployerZipNew")
    private static WebElement i9EverifyEmployerZipTextBox;

    @FindBy(how = How.ID, using = "everifyEmployerZipNewError")
    private static WebElement i9EverifyEmployerZipErrorMessage;

    @FindBy(how = How.ID, using = "submitEverifyInfo")
    private static WebElement i9EverifySaveButton;

    @FindBy(how = How.ID, using = "cancelEverifyInfo")
    private static WebElement i9EverifyCancelButton;

    public static void clickEditI9EverifyInfoLink() {
        editI9EverifyInfoLink.click();
    }

    public static void enterClientCompanyId(String companyId) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(clientCompanyIdTextBox, companyId);
    }

    public static void clickEarliestYearAllowedDropDown() {
        earliestYearAllowedDropDown.click();
    }

    public static void selectEarliestYearAllowed(String earliestYear) {
        clickEarliestYearAllowedDropDown();
        Select select = new Select(earliestYearAllowedDropDown);
        select.selectByVisibleText(earliestYear);
    }

    public static void clickEnableHistoricalI9CheckBox() {
        enableHistoricalI9CheckBox.click();
    }

    public static void enterI9EverifyEmployerName(String name) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(i9EverifyEmployerNameTextBox, name);
    }

    public static void enterI9EverifyEmployerAddress(String address) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(i9EverifyEmployerAddressTextBox, address);
    }

    public static void enterI9EverifyEmployerCity(String city) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(i9EverifyEmployerCityTextBox, city);
    }

    public static void clickI9EverifyEmployerStateDropDown() {
        i9EverifyEmployerStateDropDown.click();
    }

    public static void selectI9EverifyEmployerState(String state) {
        SeleniumTest.waitForJQueryAjaxDone();
        clickI9EverifyEmployerStateDropDown();
        Select select = new Select(i9EverifyEmployerStateDropDown);
        select.selectByVisibleText(state);
    }

    public static void enterI9EverifyEmployerZip(String zip) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(i9EverifyEmployerZipTextBox, zip);
    }

    public static void clickI9EverifyInfoSaveButton() {
        waitOnDisplayedEnabledThenClick(i9EverifySaveButton);
    }

    public static void clickI9EverifyInfoCancelButton() {
        i9EverifyCancelButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static String getClientCompanyIdErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return clientCompanyIdErrorMessage.getText();
    }

    public static String getI9EverifyEmployerAddressErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return i9EverifyEmployerAddressErrorMessage.getText();
    }

    public static String getI9EverifyEmployerCityErrorMessageErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return i9EverifyEmployerCityErrorMessage.getText();
    }

    public static String getI9EverifyEmployerStateErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return i9EverifyEmployerStateErrorMessage.getText();
    }

    public static String getI9EverifyEmployerZipErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return i9EverifyEmployerZipErrorMessage.getText();
    }

    // General Employer Info Section
    @FindBy(how = How.ID, using = "editGeneralEmpInfo")
    private static WebElement editGeneralEmployerInfoLink;

    @FindBy(how = How.ID, using = "employerNameNew")
    private static WebElement generalEmployerInfoNameTextBox;

    @FindBy(how = How.ID, using = "employerStreetAddressNew")
    private static WebElement generalEmployerInfoAddressTextBox;

    @FindBy(how = How.ID, using = "employerStreetAddressNewError")
    private static WebElement generalEmployerInfoAddressErrorMessage;

    @FindBy(how = How.ID, using = "employerCityNew")
    private static WebElement generalEmployerInfoCityTextBox;

    @FindBy(how = How.ID, using = "employerCityNewError")
    private static WebElement generalEmployerInfoCityErrorMessage;

    @FindBy(how = How.ID, using = "employerStateNew")
    private static WebElement generalEmployerInfoStateDropDown;

    @FindBy(how = How.ID, using = "employerStateNewError")
    private static WebElement generalEmployerInfoStateErrorMessage;

    @FindBy(how = How.ID, using = "employerZipNew")
    private static WebElement generalEmployerInfoZipTextBox;

    @FindBy(how = How.ID, using = "employerZipNewError")
    private static WebElement generalEmployerInfoZipErrorMessage;

    @FindBy(how = How.ID, using = "employerContactPersonNew")
    private static WebElement generalEmployerInfoContactPersonTextBox;

    @FindBy(how = How.ID, using = "employerPhoneNew")
    private static WebElement generalEmployerInfoPhoneTextBox;

    @FindBy(how = How.ID, using = "employerPhoneNewError")
    private static WebElement generalEmployerInfoPhoneErrorMessage;

    @FindBy(how = How.ID, using = "fedEmployerIdNumNew")
    private static WebElement federalEmployerIdentificationNumberTextBox;

    @FindBy(how = How.ID, using = "fedEmployerIdNumNewError")
    private static WebElement federalEmployerIdentificationNumberErrorMessage;

    @FindBy(how = How.ID, using = "submitGeneralEmpInfo")
    private static WebElement generalEmployerInfoSaveButton;

    @FindBy(how = How.ID, using = "cancelGeneralEmpInfo")
    private static WebElement generalEmployerInfoCancelButton;

    public static void clickEditGeneralEmployerInfoLink() {
        editGeneralEmployerInfoLink.click();
    }

    public static void enterGeneralEmployerInfoName(String name) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(generalEmployerInfoNameTextBox, name);
    }

    public static void enterGeneralEmployerInfoAddress(String address) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(generalEmployerInfoAddressTextBox, address);
    }

    public static void enterGeneralEmployerInfoCity(String city) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(generalEmployerInfoCityTextBox, city);
    }

    public static void clickGeneralEmployerInfoStateDropDown() {
        generalEmployerInfoStateDropDown.click();
    }

    public static void selectGeneralEmployerInfoState(String state) {
        SeleniumTest.waitForJQueryAjaxDone();
        clickGeneralEmployerInfoStateDropDown();
        Select select = new Select(generalEmployerInfoStateDropDown);
        select.selectByVisibleText(state);
    }

    public static void enterGeneralEmployerInfoZip(String zip) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(generalEmployerInfoZipTextBox, zip);
    }

    public static void enterGeneralEmployerInfoContactPerson(String name) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(generalEmployerInfoContactPersonTextBox, name);
    }

    public static void enterGeneralEmployerInfoPhone(String phone) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(generalEmployerInfoPhoneTextBox, phone);
    }

    public static void enterFederalEmployerIdentificationNumber(String fein) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(federalEmployerIdentificationNumberTextBox, fein);
    }

    public static void clickGeneralEmployerInfoSaveButton() {
        waitOnDisplayedEnabledThenClick(generalEmployerInfoSaveButton);
    }

    public static void clickGeneralEmployerInfoCancelButton() {
        waitOnDisplayedEnabledThenClick(generalEmployerInfoCancelButton);
    }

    public static String getGeneralEmployerInfoAddressErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return generalEmployerInfoAddressErrorMessage.getText();
    }

    public static String getGeneralEmployerInfoCityErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return generalEmployerInfoCityErrorMessage.getText();
    }

    public static String getGeneralEmployerInfoStateErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return generalEmployerInfoStateErrorMessage.getText();
    }

    public static String getGeneralEmployerInfoZipErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return generalEmployerInfoZipErrorMessage.getText();
    }

    public static String getGeneralEmployerInfoPhoneErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return generalEmployerInfoPhoneErrorMessage.getText();
    }

    public static String getFederalEmployerIdNumberErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return federalEmployerIdentificationNumberErrorMessage.getText();
    }

    // State Tax Section
    @FindBy(how = How.ID, using = "editStateTaxInfo")
    private static WebElement editStateTaxInfoLink;

    @FindBy(how = How.ID, using = "alabamaIdNew")
    private static WebElement alabamaEmployerStateIdTextBox;

    @FindBy(how = How.ID, using = "californiaIdNew")
    private static WebElement californiaEmployerAccountNumberTextBox;

    @FindBy(how = How.ID, using = "connecticutIdNew")
    private static WebElement connecticutTaxRegistrationNumberTextBox;

    @FindBy(how = How.ID, using = "georgiaIdNew")
    private static WebElement georgiaEmployerWithholdingAddressTextBox;

    @FindBy(how = How.ID, using = "hawaiiIdNew")
    private static WebElement hawaiiTaxIdentificationNumberTextBox;

    @FindBy(how = How.ID, using = "indianaIdNew")
    private static WebElement indianaEmployerTIDNumberTextBox;

    @FindBy(how = How.ID, using = "iowaIdNew")
    private static WebElement iowaTaxLast3DigitSuffixTextBox;

    @FindBy(how = How.ID, using = "iowaIdNewError")
    private static WebElement iowaTaxLast3DigitSuffixErrorMessage;

    @FindBy(how = How.ID, using = "iowaTaxStreetAddressNew")
    private static WebElement iowaTaxAddressTextBox;

    @FindBy(how = How.ID, using = "iowaTaxCityNew")
    private static WebElement iowaTaxCityTextBox;

    @FindBy(how = How.ID, using = "iowaTaxStateNew")
    private static WebElement iowaTaxStateDropDown;

    @FindBy(how = How.ID, using = "iowaTaxZipNew")
    private static WebElement iowaTaxZipTextBox;

    @FindBy(how = How.ID, using = "iowaTaxZipNewError")
    private static WebElement iowaTaxZipErrorMessage;

    @FindBy(how = How.ID, using = "kentuckyIdNew")
    private static WebElement kentuckyPayrollNumberTextBox;

    @FindBy(how = How.ID, using = "louisianaIdNew")
    private static WebElement louisianaEmployersStateWithholdingAccountNumberTextBox;

    @FindBy(how = How.ID, using = "missouriIdNew")
    private static WebElement missouriTaxIdNumberTextBox;

    @FindBy(how = How.ID, using = "minnesotaIdNew")
    private static WebElement minnesotaTaxIdNumberTextBox;

    @FindBy(how = How.ID, using = "nebraskaIdNew")
    private static WebElement nebraskaIdNumberTextBox;

    @FindBy(how = How.ID, using = "northcarolinaIdNew")
    private static WebElement northCarolinaCountyEnterFirstFiveLettersTextBox;

    @FindBy(how = How.ID, using = "submitStateTaxInfo")
    private static WebElement stateTaxInfoSaveButton;

    @FindBy(how = How.ID, using = "cancelStateTaxInfo")
    private static WebElement stateTaxInfoCancelButton;

    public static void enterAlabamaEmployerStateId(String id) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(alabamaEmployerStateIdTextBox, id);
    }

    public static void enterCaliforniaEmployerAccountNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(californiaEmployerAccountNumberTextBox, number);
    }

    public static void enterConnecticutTaxRegistrationNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(connecticutTaxRegistrationNumberTextBox, number);
    }

    public static void enterGeorgiaEmployerWithholdingAddress(String address) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(georgiaEmployerWithholdingAddressTextBox, address);
    }

    public static void enterHawaiiTaxIdentificationNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(hawaiiTaxIdentificationNumberTextBox, number);
    }

    public static void enterIndianaEmployerTIDNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(indianaEmployerTIDNumberTextBox, number);
    }

    public static void enterIowaTaxLast3DigitSuffix(String digits) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(iowaTaxLast3DigitSuffixTextBox, digits);
    }

    public static void enterIowaTaxAddress(String address) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(iowaTaxAddressTextBox, address);
    }

    public static void enterIowaTaxCity(String city) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(iowaTaxCityTextBox, city);
    }

    public static void clickIowaTaxStateDropDown() {
        SeleniumTest.waitForJQueryAjaxDone();
        iowaTaxStateDropDown.click();
    }

    public static void selectIowaTaxState(String state) {
        SeleniumTest.waitForJQueryAjaxDone();
        clickIowaTaxStateDropDown();
        Select select = new Select(iowaTaxStateDropDown);
        select.selectByVisibleText(state);
    }

    public static void enterIowaTaxZip(String zip) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(iowaTaxZipTextBox, zip);
    }

    public static void enterKentuckyPayrollNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(kentuckyPayrollNumberTextBox, number);
    }

    public static void enterLouisianaEmployersStateWithholdingAccountNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(
                louisianaEmployersStateWithholdingAccountNumberTextBox, number);
    }

    public static void enterMissouriTaxIdNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(missouriTaxIdNumberTextBox, number);
    }

    public static void enterMinnesotaTaxIdNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(minnesotaTaxIdNumberTextBox, number);
    }

    public static void enterNebraskaIdNumber(String number) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(nebraskaIdNumberTextBox, number);
    }

    public static void enterNorthCarolinaCountyEnterFirstFiveLetters(String letters) {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.clearAndSetText(northCarolinaCountyEnterFirstFiveLettersTextBox, letters);
    }

    public static void clickStateTaxInfoSaveButton() {
        SeleniumTest.waitForJQueryAjaxDone();
        stateTaxInfoSaveButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static void clickStateTaxInfoCancelButton() {
        stateTaxInfoCancelButton.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static String getIowaTaxLast3DigitSuffixErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return iowaTaxLast3DigitSuffixErrorMessage.getText();
    }

    public static String getIowaTaxZipErrorMessage() {
        SeleniumTest.waitForJQueryAjaxDone();
        return iowaTaxZipErrorMessage.getText();
    }

    private static void waitOnDisplayedEnabledThenClick(WebElement element) {
        SeleniumTest.waitForJQueryAjaxDone();
        WaitUntil.waitUntil(() -> element.isDisplayed() && element.isEnabled());
        element.click();
        SeleniumTest.waitForJQueryAjaxDone();
    }
}
