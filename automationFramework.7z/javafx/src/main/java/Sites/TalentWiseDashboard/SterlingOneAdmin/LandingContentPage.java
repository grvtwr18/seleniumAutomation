package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.Site;
import Sites.URL;
import WebDriver.Driver;
import java.net.UnknownHostException;

/**
 * Created by jpflager on 6/12/2017.
 */
public class LandingContentPage extends ToolPage {
    private static final String LANDING_CONTENT_URL = "/screening/tools.php?view=landing_content";
    private static final String EXPECTED_HEADER_CONTENT = "Content";

    /**
     * Navigates directly to the landing content page URL for an active customer session.
     *
     * @throws UnknownHostException
     */
    public static void navigateTo() throws UnknownHostException {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + LANDING_CONTENT_URL);
    }

    /**
     * Navigates directly to the landing content page URL, while proxied.
     *
     * @param userId the userId to proxy
     * @throws UnknownHostException
     */
    public static void navigateToProxied(int userId) throws UnknownHostException {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + LANDING_CONTENT_URL + "&OverrideUserID=" + userId);
    }

    public static String getExpectedHeaderContent() {
        return EXPECTED_HEADER_CONTENT;
    }
}
