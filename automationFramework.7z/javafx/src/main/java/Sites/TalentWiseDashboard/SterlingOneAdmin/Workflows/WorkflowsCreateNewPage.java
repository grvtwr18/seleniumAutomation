package Sites.TalentWiseDashboard.SterlingOneAdmin.Workflows;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by ali on 7/12/2017.
 *
 * Selenium Page Class for Admin Tools | Workflows | Create New
 */
public class WorkflowsCreateNewPage extends ToolPage {

    @FindBy(how = How.XPATH, using = "//button[contains(@onclick,'setInfoEditState')]")
    private WebElement cancelButton;

    @FindBy(how = How.ID, using = "workflowProfile")
    private WebElement container;

    @FindBy(how = How.XPATH, using = "//*[@id='submitNewWorkflow']")
    private WebElement createButton;

    @FindBy(how = How.CSS, using = "pageHeader")
    private WebElement pageHeader;

    @FindBy(how = How.XPATH, using = "//*[@id='workflowDescNew']")
    private WebElement workflowDescriptionTextBox;

    @FindBy(how = How.XPATH, using = "//*[@id='displayNameNew']")
    private WebElement workflowNameTextBox;

    @FindBy(how = How.ID, using = "workflowDesignerAnchor")
    private WebElement continueToWFDesigner;

    public WorkflowsCreateNewPage() {
        initializePageFactory();
    }

    public WebElement getCancelButton() {
        return cancelButton;
    }

    public WebElement getContainer() {
        return container;
    }

    public WebElement getcreateButton(){
        return createButton;
    }

    public WebElement getcontinueToWFDesignerLink(){
        return continueToWFDesigner;
    }

    public WorkflowDetailsPage clickCreateButton(String newName) {
        SeleniumTest.click(createButton);
        SeleniumTest.waitForPageLoadToComplete();
        WorkflowDetailsPage detailsPage = new WorkflowDetailsPage();
        WaitUntil.waitUntil(() -> detailsPage.getWorkflowTitle().getText().equals(newName));
        return new WorkflowDetailsPage();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public void typeInWorkflowName(String name) {
        SeleniumTest.click(workflowNameTextBox);
        SeleniumTest.clearAndSetText(workflowNameTextBox, name);
    }

    public void typeInWorkflowDescription(String description) {
        SeleniumTest.click(workflowDescriptionTextBox);
        SeleniumTest.clearAndSetText(workflowDescriptionTextBox, description);
    }

    public void OnWorkflowProfilePage(){
        SeleniumTest.waitForElementVisible(getContainer());
    }

    public void addWorkflowNameAndDescription(String name) {
        typeInWorkflowName(name);
        typeInWorkflowDescription(name);
        createButton.click();
        SeleniumTest.waitForElementVisible(getcontinueToWFDesignerLink());
        continueToWFDesigner.click();
    }
}