package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.TalentWiseDashboard.SterlingOneAdmin.OrgHierarchyPage.ViewMode;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebElement;

/**
 * Created by jpflager on 5/18/2017.
 */
public class OrgHierarchyPageHelper {
    private OrgHierarchyPage page;

    public OrgHierarchyPageHelper() {
        page = PageFactory.initElements(Driver.getDriver(), OrgHierarchyPage.class);
    }

    public OrgHierarchyPage getPage() {
        return page;
    }

    //<editor-fold desc="Modify">
    /**
     * Adds a new child org with the given name under the given parent org.
     *
     * @param parentId The parent org for new sub org to be created under.
     * @param newSubOrgName The name to give the newly created sub org.
     */
    public void addOrg(String parentId, String newSubOrgName, Boolean saveNewOrg) throws InterruptedException {
        WebElement newNameElement;
        if (page.getViewMode() == ViewMode.TREE) {
            SeleniumTest.click(page.getOrgNode(parentId).findElement(page.TREE_VIEW_ADD_XPATH));
            newNameElement = page.getAllNewAndUnsavedOrgNodes().get(0)
                    .findElement(By.xpath(".//div/p/div"));
        } else {
            SeleniumTest.click(page.getBarsElementForListViewOrg(parentId));
            SeleniumTest.click(Driver.getDriver().findElement(page.LIST_VIEW_ADD_XPATH));
            newNameElement = page.getAllNewAndUnsavedOrgNodes().get(0).findElement(
                    page.LIST_VIEW_NODE_NAME_XPATH);
        }

        SeleniumTest.click(newNameElement);
        newNameElement.sendKeys(newSubOrgName);
        if (saveNewOrg) {
            SeleniumTest.click(page.getSaveChangesButton());
            WaitUntil.waitUntil(() -> page.getPopupKendoNotifications().size() < 1);
        }
    }

    /**
     * Deletes an active org with no users or children.
     *
     * @param id The ID of the org to delete.
     */
    public void deleteOrg(String id) {
        SeleniumTest.click(page.getDeleteOrgElement(id));
        SeleniumTest.click(page.getConfirmationDialogPrimaryButton());
        SeleniumTest.click(page.getSaveChangesButton());
    }

    /**
     * "Drag" a viable target org onto another viable parent org to make it a new child of that parent.
     *
     * @param targetOrgId the dragged node's ID
     * @param destinationParentOrgId the new parent node's ID
     */
    public void dragOrgToOrg(String targetOrgId, String destinationParentOrgId) {
        WebElement elementFrom = page.getOrgNode(targetOrgId);
        WebElement elementTo = page.getOrgNode(destinationParentOrgId);
        simulateDragOrgToOrgByElement(elementFrom, elementTo);
    }

    /**
     * Edits an org.
     *
     * @param id The ID of the org to edit.
     */
    public void editOrg(String id) {
        if (page.getViewMode() == ViewMode.TREE) {
            editOrg(page.getOrgNode(id));
        } else {
            SeleniumTest.click(page.getBarsElementForListViewOrg(id));
            SeleniumTest.click(Driver.getDriver().findElement(page.LIST_VIEW_EDIT_XPATH));
        }
    }

    /**
     * Edits an org.
     *
     * @param node The web element node of the org to edit.
     */
    public void editOrg(WebElement node) {
        if (page.getViewMode() == ViewMode.TREE) {
            SeleniumTest.click(node.findElement(page.TREE_VIEW_EDIT_XPATH));
        } else {
            editOrg(page.getOrgNodeId(node));
        }
    }

    /**
     * Clear and type in new org name inline for the org with the given id.
     *
     * @param id The ID of the org to rename.
     * @param newName The text to type as the new org name.
     */
    public void renameOrg(String id, String newName) {
        WebElement name = page.getOrgNodeNameElement(id);
        SeleniumTest.click(name);
        SeleniumTest.clearAndSetText(name, newName);
        // click on Search box to leave list view inline node name edit
        SeleniumTest.click(page.getSearchBox());
        saveOrgInfoAndWaitForKendoNotificationClear();
    }

    /**
     * Save the org hierarchy page changes, and wait for the kendo message (success or failure) to clear.
     */
    public void saveOrgInfoAndWaitForKendoNotificationClear() {
        SeleniumTest.click(page.getSaveChangesButton());
        WaitUntil.waitUntil(() -> page.getPopupKendoNotifications().size() < 1);
    }

    /**
     * Simulate the dragging of an org underneath another org using the org chart library's JavaScript. This was a
     * workaround that actually worked.
     *
     * @param from the dragged WebElement
     * @param to the new parent WebElement
     */
    private void simulateDragOrgToOrgByElement(WebElement from, WebElement to) {
        JavaScriptHelper.runScript(
                "function simulate(idFrom, idTo) { "
                        + "var $orgChartContainer = $('#" + page.ORG_CHART_CONTAINER_ID + "'); "
                        + "var $orgChart = $orgChartContainer.find('." + page.ORG_CHART_CLASS + "'); "
                        + "var $dragFrom = $(idFrom); "
                        + "var $dragTo = $(idTo); "
                        + "$orgChart.data('dragged', $dragFrom); $dragTo.trigger('drop'); "
                        + "}"
                        + "simulate(arguments[0], arguments[1]);", from, to);
    }
    //</editor-fold>

    //<editor-fold desc="State">
    /**
     * Returns true if the node with the given ID has children.
     *
     * @param id The ID of the node to check for children.
     * @return True if the node with the given ID has children.
     */
    public boolean doesNodeHaveChildren(String id) {
        if (page.getViewMode() == ViewMode.TREE) {
            // if tree view node has a collapsible element it has children
            try {
                page.getOrgNode(id).findElement(page.TREE_VIEW_HIDE_OR_SHOW_XPATH);
            } catch (Exception NoSuchElementException) {
                return false;
            }

            return true;
        } else {
            // if list view node row parent's parent is of class 'orgHasChildren' then it has children
            if (page.getOrgNode(id).findElement(By.xpath("../..")).getAttribute("class")
                    .contains("orgHasChildren")) {
                return true;
            } else {
                return false;
            }
        }
    }
    //</editor-fold>

    //<editor-fold desc="View">
    /**
     * Expands all the nodes (shows all subnodes).
     */
    public void expandAllNodes() {
        List<WebElement> visibleExpanders = page.getAllNodeExpanders().stream().filter(x -> x.isDisplayed())
                .collect(Collectors.toList());
        List<WebElement> checked = new ArrayList<>();
        boolean hierarchyDidNotExpand = false;
        int expandHighWaterMark = page.getAllVisibleOrgNodes().size();
        int lastExpandedMark = 0;
        while (!hierarchyDidNotExpand) {
            if (expandHighWaterMark == lastExpandedMark) {
                hierarchyDidNotExpand = true;
            } else {
                lastExpandedMark = expandHighWaterMark;
            }
            for (WebElement expander : visibleExpanders) {
                if (checked.contains(expander)) {
                    continue;
                }
                long currentVisibleNodes = page.getAllVisibleOrgNodes().size();
                SeleniumTest.click(expander);
                if (page.getAllVisibleOrgNodes().size() < currentVisibleNodes) {
                    SeleniumTest.click(expander);
                }
                checked.add(expander);
            }
            visibleExpanders = page.getAllNodeExpanders().stream().filter(x -> x.isDisplayed())
                    .collect(Collectors.toList());
            expandHighWaterMark = page.getAllVisibleOrgNodes().size();
        }
    }

    /**
     * Toggles hiding or showing the children (aka sub orgs) for the given org.
     *
     * @param id The ID of the org to toggle hiding or showing its children.
     */
    public void hideOrShowChildren(String id) {
        if (page.getViewMode() == ViewMode.TREE) {
            SeleniumTest
                    .click(page.getOrgNode(id).findElement(page.TREE_VIEW_HIDE_OR_SHOW_XPATH));
        } else {
            SeleniumTest
                    .click(page.getOrgNode(id).findElement(page.LIST_VIEW_HIDE_OR_SHOW_XPATH));
        }
    }


    //</editor-fold>
}