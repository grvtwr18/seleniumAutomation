package Sites.TalentWiseDashboard.SterlingOneAdmin.Workflows;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * created in InteliJ IDEA 2017.2.6 by user cfrediani on 02/22/18.
 *
 * Selenium Page Class for Admin Tools | Workflows | Workflow Designer
 */
public class WorkflowDesignerPage extends ToolPage {

    @FindBy(how = How.XPATH, using = "//*[@id='newStep']")
    private WebElement addStepsButton;

    @FindBy(how = How.XPATH, using = "//*[@id='saveDesignActivate']")
    private WebElement saveAndActivateButton;

    @FindBy(how = How.XPATH, using = "//*[@id='saveDesignReturn']")
    private WebElement saveAndReturnButton;

    public WorkflowDesignerPage() {
        initializePageFactory();
    }

    public WorkflowDesignerAddStepsModal clickAddStepsButton() {
        SeleniumTest.click(addStepsButton);
        SeleniumTest.waitForPageLoadToComplete();
        return new WorkflowDesignerAddStepsModal();
    }

    public WorkflowDesignerPage clickSaveAndActivateButton() {
        SeleniumTest.click(saveAndActivateButton);
        SeleniumTest.waitForPageLoadToComplete();
        return new WorkflowDesignerPage();
    }

    public WorkflowDetailsPage clickSaveAndReturnButton() {
        SeleniumTest.click(saveAndReturnButton);
        SeleniumTest.waitForPageLoadToComplete();
        return new WorkflowDetailsPage();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }
}