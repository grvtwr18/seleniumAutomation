package Sites.TalentWiseDashboard.SterlingOneAdmin;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class TaskNotificationPage extends FormI9InstructionPage {
    static {
        PageFactory.initElements(Driver.getDriver(), TaskNotificationPage.class);
    }

}
