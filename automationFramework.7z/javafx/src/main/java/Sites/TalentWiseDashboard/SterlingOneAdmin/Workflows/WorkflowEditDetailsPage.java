package Sites.TalentWiseDashboard.SterlingOneAdmin.Workflows;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * created in InteliJ IDEA 2017.2.6 by user cfrediani on 02/22/18.
 *
 * Selenium page helper class for 'Admin Tools | Workflows | Workflow Details page'.
 */
public class WorkflowEditDetailsPage extends ToolPage {

    @FindBy(how = How.XPATH, using = "//*[@id=\"submitWorkflowInfo\"]")
    private WebElement saveButton;

    @FindBy(how = How.XPATH, using = "//*[@id='workflowDescNew']")
    private WebElement workflowDescriptionTextBox;

    @FindBy(how = How.XPATH, using = "//*[@id='displayNameNew']")
    private WebElement workflowNameTextBox;

    public WorkflowEditDetailsPage() {
        initializePageFactory();
    }

    public WorkflowDetailsPage clickSaveButton(String editedName) {
        SeleniumTest.click(saveButton);
        SeleniumTest.waitForPageLoadToComplete();
        WorkflowDetailsPage detailsPage = new WorkflowDetailsPage();
        WaitUntil.waitUntil(() -> detailsPage.getWorkflowTitle().getText().equals(editedName));
        return new WorkflowDetailsPage();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public void typeInWorkflowName(String name) {
        SeleniumTest.click(workflowNameTextBox);
        SeleniumTest.clearAndSetText(workflowNameTextBox, name);
    }

    public void typeInWorkflowDescription(String description) {
        SeleniumTest.click(workflowDescriptionTextBox);
        SeleniumTest.clearAndSetText(workflowDescriptionTextBox, description);
    }
}