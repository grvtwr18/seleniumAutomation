package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.Pages;
import Sites.TalentWiseDashboard.Helpers.AdminMenubar;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Kendo;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by wogden on 6/22/2015.
 * Originally this was only used in Tools pages, under Customer Dasnboard/admin
 * however, now several of the search pages are using Kendo grids
 * TODO: rename this to Kendo Helper or something similar
 */
public class ToolPage extends Pages {
    public WebDriverWait wait;
    public Header header;
    public static AdminMenubar adminMenubar;

    @FindBy(how = How.CSS , using = "span.k-icon.k-i-seek-w")
    public static WebElement goToFirstPage;

    @FindBy(how = How.CSS , using = "span.k-icon.k-i-arrow-w")
    public static WebElement goToPreviousPage;

    public By currentPageLocator = By.cssSelector("span.k-state-selected");
    @FindBy(how = How.CSS , using = "span.k-state-selected")
    public static WebElement currentPage;

    // on "smaller' resolutions, our responsive design changes the UI elements for pagination
    public By currentPageLocatorLowRes = By.cssSelector("span.k-link.k-pager-nav");
    @FindBy(how = How.CSS , using = "span.k-link.k-pager-nav")
    public static WebElement currentPageLowRes;

    @FindBy(how = How.CSS , using = "span.k-icon.k-i-arrow-e")
    public static WebElement goToNextPage;

    @FindBy(how = How.CSS , using = "span.k-icon.k-i-seek-e")
    public static WebElement goToLastPage;

    @FindBy(how = How.CSS , using = "span.k-pager-info.k-label")
    public static WebElement numGridItems;

    @FindBy(how = How.CSS , using = "td.gridError")
    public static WebElement gridEmptyIndicator;
    public static By gridEmptyIndicatorLocator = By.cssSelector("td.gridError");

    @FindBy(how = How.CSS, using = "th.k-header > label.staticCheckboxLabel")
    public static WebElement selectAllCheckBox;
    public static final By selectAllCheckBoxLocator = By.cssSelector("th.k-header > label.staticCheckboxLabel");

    public static final By pageHeaderLocator = By.cssSelector("h1");

    @FindBy(how = How.CSS, using = "h1")
    public static WebElement pageHeader;

    @FindBy(how = How.ID, using = "submitTemplateAndReturn")
    private static WebElement submitAndReturn;

    @FindBy(how = How.ID, using = "submitTemplate")
    private static WebElement submit;

    @FindBy(how = How.ID, using = "cancelTemplateEdit")
    private static WebElement cancelEdit;

    @FindBy(how=How.CSS, using="span.k-pager-info.k-label")
    private static WebElement countLabel;

    public static boolean isSubmitAndReturnPresent() {

        return SeleniumTest.isElementVisibleNoWaiting(By.id("submitTemplateAndReturn"));
    }

    public static boolean isSubmitPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("submitTemplate"));
    }
    public static boolean isCancelEditPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("cancelTemplateEdit"));
    }


    // each class which extends ToolPage needs to set this
    public static String expectedHeaderText;
    public static String gridName;

    public By loadingImageLocator = By.cssSelector("div.k-loading-image");

    public static final By notificationLocator = By.cssSelector("div.popupNotification > div");

    // this was pulled from Docs and Media
    public static final By notification2Locator = By.xpath("//div[11]/div/div/div/ul/li[2]");
    
    // "You are not authorized" error div
    private static final By youAreNotAuthorizedErrorDivBy = By.xpath(
            "//div[@class='dbMessage' and contains(.,'You are not authorized to see this page')]");

    public static String lastNotification;
    public static int itemCount;
    public static int kendoGridColumnOffset = 0;

    protected static Logger logger = LoggerFactory.getLogger("ToolsPage");

    public ToolPage() {
        logger.debug("Initializing footer and admin menubar");
        this.header = PageFactory.initElements(Driver.getDriver(), Header.class);
        this.adminMenubar = PageFactory.initElements(Driver.getDriver(), AdminMenubar.class);
    }

    /**
     * Getter for the adminMenubar.
     * @return the AdminMenubar object stored in the adminMenubar field of the current ToolPage
     */
    public AdminMenubar getAdminMenubar() {
        return adminMenubar;
    }

    /**
     * Checks for the presence of the "You are not authorized" error message and returns true if present, false if not.
     * @return boolean true if error is present, false if not
     */
    public static boolean isYouAreNotAuthorizedErrorDivPresent() {
        try {
            Driver.getDriver().findElement(youAreNotAuthorizedErrorDivBy);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * updates ToolPage.itemCount
     */
    public static int updateItemCount() {
        logger.info("Updating item count");
        String countString = numGridItems.getText();
        if (countString.equals("") || countString.equals("No items to display")) {
            itemCount = 0;
        }
        else {
            itemCount = Integer.parseInt(countString.substring(countString.indexOf("of ") + 3, countString.indexOf("items") - 1));
        }
        logger.info("Item count = {}", itemCount);

        return itemCount;
    }

    /**
     * Returns the header on a tools page; to identify that the correct page loaded
     * @return
     */
    public static String getHeaderText() {
        return Driver.getDriver().findElement(pageHeaderLocator).getText();
    }

    /**
     * If the kendoBusyImage indicator is present, waits for it to go away
     */
    public static void waitForKendoGridRefresh() {
        Kendo.waitForKendoBusyImageToGoAway();
    }

    /**
     * returns page of grid, 1, 2, etc
     * @return
     */
    public String getCurrentPageofGrid() {
        return currentPage.getText();
    }

    /**
     * this reruns "1-10 of 15" or etc.; how many items (users, assets) are displayed out of how may
     * @return a - b of c
     */
    public String getNumGridItems() {
        return numGridItems.getText();
    }

    /**
     * Get's the text of the first notification
     * @return
     */
    public static String getNotificationText() {
        return getNotificationText(0);
    }

    /**
     * Get's the text of the first notification
     * @param waitFlag parameter, if true then this won't return until the notification has disappeared
     * @return
     */
    public static String getNotificationText(boolean waitFlag) {
        return getNotificationText(0, waitFlag);
    }

    /**
     * Get's text for a notification if multiple notifications present, starting with 0
     * @param elementNumber
     * @param waitFlag optional parameter, if true then this won't return until the notification has disappeared
     * @return
     */
    public static String getNotificationText(int elementNumber, boolean... waitFlag) {
        if (!SeleniumTest.isElementVisibleNoWaiting(notificationLocator)) {
            logger.info("Waiting for notification to appear");
            waitForNotification();
        }

        String note = Driver.getDriver().findElements(notificationLocator).get(elementNumber).getText();
        logger.info("Notification: {}", note);
        if (waitFlag.length>0) {
            if (waitFlag[0]) {
                logger.info("Waiting for notification to disappear");
                waitForNotificationGone(notificationLocator);
            }
        }
        return note;
    }

    //TODO refactor for variable number of notifications
    public static List<String> get2NotificationTexts() {
        if (SeleniumTest.isElementNotPresent(notificationLocator)) {
            logger.info("Waiting for notification to appear");
            waitForNotification();
        }
        WebElement currentNotification = Driver.getDriver().findElement(notificationLocator);
        String noteOne = currentNotification.getText();
        currentNotification.click();
        currentNotification = Driver.getDriver().findElement(notificationLocator);
        String noteTwo = currentNotification.getText();
        logger.info("Notifications: {}, {}", noteOne, noteTwo);
        return Arrays.asList(noteOne, noteTwo);
    }

    /**
     * Waits for a notification to disappear
     * @param by
     */
    private static void waitForNotificationGone(final By by) {
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(60, TimeUnit.SECONDS)
                .pollingEvery(3, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                           public boolean apply(WebDriver driver) {
                               return !SeleniumTest.isElementVisibleNoWaiting(by);
                           }
                       }
                );
    }

    /**
     * Wait for a notification to appear
     */
    private static void waitForNotification() {
        WaitUntil.waitUntil(60, 3, () -> {
            Driver.getDriver().findElement(notificationLocator);
            return true;
        }, WebDriverException.class);
    }

    public static void waitForNotification(final int maxWaitTimeInSeconds) {
        WaitUntil.waitUntil(maxWaitTimeInSeconds, 2, () -> {
            return SeleniumTest.isElementVisibleNoWaiting(notificationLocator);
        });
    }

    /**
     * This is only there to be extended.  Needed for eventual home page navigation tests
     * @return
     */
    protected ToolPage clickCarouselElement() {
        return this;
    }

    /**
     * Returns the current date; for verification of grid
     * @return
     */
    public static String setToday() {
        Date today = Calendar.getInstance().getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy");
        return sdf.format(today);
    }

    /**
     * Returns the String Text contents of the item in a kendo grid at the given row and column.
     *
     * @param row of the item
     * @param column of the item
     * @return the String Text contents of the given row and column in a kendo grid
     */
    public static String findElementTextInGrid(int row, int column) {
        // make sure the grid is ready
        if (gridName == null) {
            org.testng.AssertJUnit.fail("Toolpage.gridName is null, must set it when calling this function");
        }
        final By locator = By.xpath("//div[@id='" + gridName + "']/table/tbody/tr[" + row + "]/td[" + column + "]");
        // Elements in this kendo grid appear to flicker, easily resulting in StaleElementReferenceException(s).
        final int MAX_TRIES = 5;

        for (int attempt = 1; attempt <= MAX_TRIES; ++attempt) {
            try {
                return SeleniumTest.getTextByLocator(locator);
            } catch (StaleElementReferenceException sere) {
                logger.info("Attempt #{} to findElementTextInGrid({}, {}) threw StaleElementReferenceException", attempt, row, column);
                if (attempt < MAX_TRIES) {
                    // Wait a second before trying again ...
                    SeleniumTest.waitMs(1000);
                } else {
                    // We can't seem to avoid the StaleElementReferenceException, so go ahead and throw it ...
                    throw sere;
                }
            }
        }

        org.testng.AssertJUnit.fail("Should never have reached this point within ToolPage.findElementTextInGrid()");
        return null;
    }


    /**
     * Sorts by the column, waits for the grid to refesh, and verifies the grid isn't empy
     * @param colHeader
     */
    public static void sortGridByColumn(Class<? extends ToolPage> currentPage, WebElement colHeader) {
        colHeader.click();
        waitForKendoGridRefresh();
        PageFactory.initElements(Driver.getDriver(), currentPage);
        WaitUntil.waitUntil(15, 2, () -> !SeleniumTest.isElementVisibleNoWaiting(gridEmptyIndicatorLocator));
    }

    /**
     * finds the item on the page then verifies the row
     * @param gridItem number of columns and number of items in array being checked
     * @param numColumns number of columns
     */
    public static void verifyNewItemInGrid(String[] gridItem, int numColumns) {
        updateItemCount();
        logger.info("VerifyNewItemInGrid in an unknown row");
        Boolean present = false;
        int row;
        // loop through the names to find it
        logger.info("Determine what row the item \"{}\" is on", gridItem[0]);
        for (row = 1; row <= itemCount; row++) {
            // 2 is the column.  So far, the first column is checkboxes, sometimes hidden
            // so the name is always column 2.  so far.
            final String elementTextInGrid = findElementTextInGrid(row, 2);
            logger.info("Element in grid at row {}: \"{}\"", row, elementTextInGrid);
            if (elementTextInGrid.equals(gridItem[0])) {
                // we found the name
                logger.info("This matches what we were looking for: \"{}\"");
                present = true;
                break;
            }
        }

        if (present) {
            logger.info("Item is on row {}", row);
        } else {
            throw new NoSuchElementException("Never found this item in the grid: \"" + gridItem[0] + "\"");
        }
        // now we have the row, we can check the values
        verifyPageNavigationControls(itemCount);
        verifyNewItemInGrid(gridItem, numColumns, row);
    }

    /**
     * checks the row for the correct text
     * TODO: this shouldn't be in a page class
     * @param gridItem a string array of the expected text
     * @param row the row being checked
     * @param numColumns number of columns and number of items in array being checked
     */
    public static void verifyNewItemInGrid(String[] gridItem, int numColumns, int row) {
        logger.info("VerifyNewItemInGrid in row {}", row);
        logger.info("Verifying row {}",row);
        String cellContents;
        int columnOffset = ToolPage.kendoGridColumnOffset;
        logger.debug("Column offset: {}", columnOffset);
        for (int tableColumn = columnOffset; tableColumn < numColumns + columnOffset; tableColumn++) {
            logger.info("Checking column {} for {}", (tableColumn - columnOffset), gridItem[tableColumn - columnOffset]);
            cellContents = findElementTextInGrid(row, tableColumn);
            logger.info("Cell contains {}",cellContents);
            if(!gridItem[tableColumn - columnOffset].equals(cellContents)) {
                TWFramework.SeleniumTest.takeWebDriverScreenshot();
                throw new InvalidElementStateException("The expected content '" + cellContents + "' does not match actual content '" + gridItem[tableColumn - columnOffset] + "'.");
            }
        }
    }


    /**
     * Verifies the navigation controls on the kendo grid common to all tools pages
     * TODO: this shouldn't be in a page class.
     * @param numItems
     * @param selectAll optional parameter, some pages have a select all radio, some do not.  set this to false for
     * pages w/out the select all control
     */
    public static void verifyPageNavigationControls(int numItems, boolean... selectAll){
        if (numItems == 0) {
            logger.info("Verifying nav controls for empty page");
            verifyPageNavigationControlsEmptyPage(selectAll);
        }
        else {
            logger.info("Verifying nav controls for page with {} items", numItems);
            verifyPageNavigationControlsNotEmptyPage(numItems, selectAll);
        }
    }

    /**
     * verifies the controls on an empty page.  many controls are hidden
     * TODO: this shouldn't be in a page class.
     * @param selectAll
     */
    private static void verifyPageNavigationControlsEmptyPage(boolean... selectAll) {
        waitForKendoGridRefresh();
        updateItemCount();
        // this means an empty grid.  most controls not visible
        TWFramework.SeleniumTest.waitForElement(gridEmptyIndicatorLocator);
        TWFramework.SeleniumTest.verifyElementVisible(gridEmptyIndicator);
        TWFramework.SeleniumTest.verifyElementHidden(goToFirstPage);
        TWFramework.SeleniumTest.verifyElementHidden(goToPreviousPage);
        TWFramework.SeleniumTest.verifyElementHidden(currentPage);
        TWFramework.SeleniumTest.verifyElementHidden(currentPageLowRes);
        TWFramework.SeleniumTest.verifyElementHidden(goToNextPage);
        TWFramework.SeleniumTest.verifyElementHidden(goToLastPage);
        TWFramework.SeleniumTest.verifyElementHidden(numGridItems);
        if (selectAll.length > 0) {
            verifySelectAllCheckBox(selectAll[0]);
        }
        else verifySelectAllCheckBox();
    }

    /**
     * verifies the conrols on a grid with elements.
     * TODO: this shouldn't be in a page class.
     * @param numItems
     * @param selectAll
     */
    private static void verifyPageNavigationControlsNotEmptyPage(int numItems, boolean... selectAll)
    {
        waitForKendoGridRefresh();
        updateItemCount();
        if (numItems == 0)
        {
            logger.error("qa code error, shouldn't call this function with numItems = 0");
            verifyPageNavigationControlsEmptyPage(selectAll);
        }
        else
        {
            // this means a full grid.  most stuff shows up
            // if the empty indicator is present, abort the test
            if (SeleniumTest.isElementVisibleNoWaiting(gridEmptyIndicatorLocator)) {
                throw new InvalidElementStateException("Empty indicator element was visible when it should't have been: " + gridEmptyIndicatorLocator);
            }
            TWFramework.SeleniumTest.verifyElementVisible(goToFirstPage);
            TWFramework.SeleniumTest.verifyElementVisible(goToPreviousPage);
            verifyCurrentPageElementVisible();
            TWFramework.SeleniumTest.verifyElementVisible(goToNextPage);
            TWFramework.SeleniumTest.verifyElementVisible(goToLastPage);
            TWFramework.SeleniumTest.verifyElementVisible(numGridItems);
            //TODO find a static way of verifying something is equal
            //verifyEquals(numItems, itemCount);
        }
        if (selectAll.length > 0) {
            verifySelectAllCheckBox(selectAll);
        }
        else verifySelectAllCheckBox();
    }

    /**
     * makes sure select all is present and enabled, or not visible
     * @param selectAll false means no select all box is on the page
     * TODO: this shouldn't be in a page class.
     */
    private static void verifySelectAllCheckBox(boolean... selectAll) {
        if (selectAll.length > 0) {
            if (!selectAll[0]) {
                logger.info("Verifying that selectAllCheckBox is not present");
                if (SeleniumTest.isElementVisibleNoWaiting(selectAllCheckBoxLocator)) {
                    throw new InvalidElementStateException("The selectAllCheckBox was expected not to be present: " + selectAllCheckBoxLocator);
                }
            } else {
                logger.info("Verifying that selectAllCheckBox is visible and enabled");
                TWFramework.SeleniumTest.isElementEnabled(selectAllCheckBox);
            }
        } else {
            // this is the default
            logger.info("Verifying that selectAllCheckBox is visible and enabled");
            TWFramework.SeleniumTest.isElementEnabled(selectAllCheckBox);
        }
    }

    /**
     * CurrentPageElement is one of two elements depending on screen resolution
     * this checks that at least one is present
     * TODO refactor for known resolution
     * TODO change to use waitUntil
     * TODO: this shouldn't be in a page class.
     */
    private static void verifyCurrentPageElementVisible() {
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(30, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                           public boolean apply(WebDriver d) {
                               // might be an issue if user doesn't have email permission
                               if (TWFramework.SeleniumTest.isElementVisible(currentPageLowRes)
                                       || TWFramework.SeleniumTest.isElementVisible(
                                       currentPage)) {
                                   return true;
                               }
                               return false;
                           }
                       }
                );
    }

    protected static String getTooltip(WebElement element, By by) {
        WebDriver driver  = Driver.getDriver();
        Actions   tooltip = new Actions(driver);
        tooltip.moveToElement(element).build().perform();
        WebElement tooltipElement = driver.findElement(by);
        String actualTooltip = tooltipElement.getText();
        return actualTooltip;
    }


    public static boolean isAscSortIconPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("span.k-icon.k-i-sort-asc-sm"));
    }

    public static boolean isDecSortIconPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("span.k-icon.k-i-sort-desc-sm"));
    }


    public static String getCountLabel() {
        return countLabel.getText();
    }

    public static void waitForPopUpNotificationToGoAway() {
        final By popupNotificationLocator = By.className("popupNotification");

        try {
            logger.info("Wait up to 3 seconds for a Popup Notification to appear: {}", popupNotificationLocator);
            WaitUntil.waitUntil(3, 1,
                    () -> SeleniumTest.isElementVisibleNoWaiting(popupNotificationLocator));
            logger.info("Waiting for Popup Notification to disappear");
        } catch (TimeoutException toe) {
            logger.info("No Popup Notification was ever found to be visible.");
        }

        WaitUntil.waitUntil(() -> !SeleniumTest.isElementVisibleNoWaiting(popupNotificationLocator));
    }
}