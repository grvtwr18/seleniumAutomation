package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.Site;
import Sites.TalentWiseDashboard.CustomerLoginPage;
import Sites.TalentWiseDashboard.Enums.AccountType;
import Sites.TalentWiseDashboard.Enums.CarouselElement;
import Sites.URL;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.WebElement;

public class HomePage extends ToolPage {
    private static final String HOME_PAGE_URL_PATH = "/screening/tools.php?view=home";

    @FindBy(how = How.CLASS_NAME , using = "jcarousel-control-next")
    public static WebElement scrollCarouselRightButton;

    @FindBy(how = How.CLASS_NAME , using = "widget-jcarousel-wrapper")
    public static WebElement widgetCarousel;

    @FindBy(how = How.CLASS_NAME , using = "landing-page-widget-content")
    public static List<WebElement> widgetTitles;

    @FindBy(how = How.LINK_TEXT , using = "<")
    public static WebElement scrollCarouselLeftButton;

    @FindBy(how = How.ID, using = "L10nLocale")
    private static WebElement localeDropdown;

    @FindBy(how = How.ID, using = "side-menu")
    private static WebElement sideMenu;

    /**
     * make a selection on the locale dropdown to update and change user's locale
     */
    public static void changeLocale(String value) {
        SeleniumTest.selectByValueFromDropDown(localeDropdown, value);
        SeleniumTest.waitForJQueryAjaxDone();
    }

    /**
     * return the admin side menu
     */
    public static WebElement getSideMenu() {
        return sideMenu;
    }

    /**
     * Navigates to and initializes a Tools HomePage from an active customer session.
     * @return A new Tool HomePage object.
     * TODO: why does this getURL() take so long to "finish"? Async loading default videos?
     */
    public static HomePage navigateTo() {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + HOME_PAGE_URL_PATH);
        return PageFactory.initElements(Driver.getDriver(), HomePage.class);
    }

    /**
     * Navigates to and initializes a Tools HomePage from an active customer session
     *
     * TODO: what's the value the asProxy param, if you have to set up the session differently?
     * @param asProxy Whether to navigate as a proxy'd user
     * @param overrideUserId The proxy'd user to navigate with
     * @return A new Tool HomePage Object
     */
    public static HomePage navigateTo(boolean asProxy, int overrideUserId) {
        if (asProxy) {
            Driver.getDriver()
                    .get(URL.getURL(
                            Sites.Site.ADMIN_CONSOLE) +
                            HOME_PAGE_URL_PATH +
                            "&OverrideUserID=" +
                            Integer.toString(overrideUserId));
            return PageFactory.initElements(Driver.getDriver(), HomePage.class);
        } else {
            return navigateTo();
        }
    }

    /**
     * Overloaded method to navigate to the Tools HomePage without an active customer session, given the login
     * credentials.
     * @param userName login credentials username (email)
     * @param password login credentials password
     * @return a new Tools HomePage object
     */
    public static HomePage navigateTo(String userName, String password) {
        CustomerLoginPage.navigateTo().signInAs(userName, password, AccountType.CUSTOMER_ACCOUNT);
        return navigateTo();
    }

    /**
     * Navigates to and initializes a proxied Tools HomePage from an active admin console session, given a userId.
     * @return a new Tool HomePage object
     */
    public static HomePage navigateToProxied(int userId) {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + HOME_PAGE_URL_PATH + "&OverrideUserID=" + userId);
        return PageFactory.initElements(Driver.getDriver(), HomePage.class);
    }

    /**
     * Navigates to one of the "carousel" items on the 'Home' page of the Admin area
     * @param index
     * @param returnedClass
     * @return
     */
    public static ToolPage carouselClick(CarouselElement index, Class<? extends ToolPage> returnedClass) {
        getCarouselElement(index).click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static String getCarouselValue(CarouselElement index) {
        WebElement element = getCarouselElement(index);
        if (SeleniumTest.isElementHidden(element)) {
            logger.info("Scrolling carousel");
            SeleniumTest.clickUntilElementAppears(scrollCarouselRightButton, element);
        }
        return element.getText();
    }

    public static String getCarouselText(CarouselElement index) {
        WebElement element = getCarouselElementLabel(index);
        if (SeleniumTest.isElementHidden(element)) {
            logger.info("Scrolling carousel");
            SeleniumTest.clickUntilElementAppears(scrollCarouselRightButton, element);
        }
        return element.getText();
    }

    public static String getCarouselExpectedText(LocaleHelper.Locale locale, CarouselElement index) {
        switch (locale.UrlTag()){
            case "en-US":
                switch (index) {
                    case Portals:
                        return "Portals";
                    case Workflows:
                        return "Workflows";
                    case EmailTemplates:
                        return "Email Templates";
                    case DocsAndMedia:
                        return "Documents And Media";
                    case Users:
                        return "Users";
                    case Roles:
                        return "Roles";
                    case CompanyProfiles:
                        return "Company Profiles";
                    default:
                        return "UNIMPLEMENTED CAROUSEL ELEMENT";
                }
            case "qps-PLOC":
                switch (index) {
                    case Portals:
                        return "[{ba10} Ƥǿřŧȧŀş]";
                    case Workflows:
                        return "[{e6b0} Ẇǿřķƒŀǿẇş]";
                    case EmailTemplates:
                        return "[{c143} Ḗḿȧīŀ Ŧḗḿƥŀȧŧḗş]";
                    case DocsAndMedia:
                        return "[{928a} Ḓǿƈŭḿḗƞŧş Ȧƞḓ Ḿḗḓīȧ]";
                    case Users:
                        return "[{f9aa} Ŭşḗřş]";
                    case Roles:
                        return "[{a5cd} Řǿŀḗş]";
                    case CompanyProfiles:
                        return "Company Profiles";
                    default:
                        return "UNIMPLEMENTED CAROUSEL ELEMENT";
                }
        }
        return "";
    }

    private static WebElement getCarouselElement(CarouselElement index) {
        return Driver.getDriver().findElement(By.xpath("//div[@id='widget-carousel']/ul/li[" + index + "]/a/div/span"));
    }
    private static WebElement getCarouselElementLabel(CarouselElement index) {
        return Driver.getDriver().findElement(By.xpath("//div[@id='widget-carousel']/ul/li[" + index + "]/a/div/div[2]"));
    }

    public static WebElement getWidgetCarousel() {
        return widgetCarousel;
    }

    public static List<WebElement> getWidgetTitles() {
        return widgetTitles;
    }
}
