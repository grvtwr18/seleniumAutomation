package Sites.TalentWiseDashboard.SterlingOneAdmin.Modals;

import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 7/1/2015.
 */
public class KendoDeleteConfirmation extends ToolPage {

    private static By deleteConfirmationButtonLocator = By.cssSelector("button.actionButton.primaryAction");

    static {
        PageFactory.initElements(Driver.getDriver(), KendoDeleteConfirmation.class);
    }

    public KendoDeleteConfirmation() {
        super();
        SeleniumTest.waitForElement(deleteConfirmationButtonLocator);
    }

    public static void clickOK() {
        boolean successful = false;
        try {
            Driver.getDriver().findElement(deleteConfirmationButtonLocator).click();
            successful = true;
        } finally {
            if (!successful) {
                logger.info("Taking a screenshot because KendoDeleteConfirmation.clickOK() failed");
                SeleniumTest.takeWebDriverScreenshot();
            }
        }
    }
}
