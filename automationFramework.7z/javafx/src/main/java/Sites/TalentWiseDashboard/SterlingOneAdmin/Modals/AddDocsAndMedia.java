package Sites.TalentWiseDashboard.SterlingOneAdmin.Modals;

import Sites.TalentWiseDashboard.SterlingOneAdmin.DocsAndMediaPage;
import Sites.TalentWiseDashboard.SterlingOneAdmin.ToolPage;
import Sites.TalentWiseDashboard.Enums.DocsAndMediaType;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

import static org.openqa.selenium.By.name;

/**
 * Created by wogden on 6/24/2015.
 */
public class AddDocsAndMedia extends ToolPage {

    @FindBy(how = How.NAME, using = "categoryList")
    private static WebElement categoryList;

    @FindBy(how = How.ID, using = "urlRadio")
    public static WebElement urlRadio;

    @FindBy(how = How.ID, using = "fileRadio")
    public static WebElement fileRadio;

    @FindBy(how = How.ID, using = "assetUrl")
    public static WebElement assetURL;

    // we need this string for a script
    public static final String filePathIdentifier = "#assetFileUpload";

    @FindBy(how = How.CSS, using = filePathIdentifier)
    private static WebElement filePath;

    @FindBy(how = How.ID, using = "allowedFileTypes")
    public static WebElement allowedFileTypesString;

    @FindBy(how = How.ID, using = "assetUrlAddButton")
    private static WebElement assetUrlAddButton;

    private static final By uploadButtonLocator = By.id("upload-button");

    @FindBy(how = How.CSS, using = "div.ui-helper-clearfix > button.actionButton.secondaryAction")
    private static WebElement cancelButton;

    @FindBy (how = How.ID, using = "errorContainer")
    public static WebElement errorMessage;

    @FindBy (how = How.ID, using = "windowDialogContent")
    private static WebElement addAssetContainer;

    @FindBy (how = How.CSS, using = "input.assetName")
    private static WebElement assetName;

    public AddDocsAndMedia() {
        super();
    }

    public static int indexOfNewItem = 0;

    static {
        PageFactory.initElements(Driver.getDriver(), AddDocsAndMedia.class);
    }

    /**
     * This sets the Category dropdown; video, logo, etc
     * @param selection enem of type of asset
     */
    public static void setCategoryList(DocsAndMediaType selection) {
        SeleniumTest.waitForElementTimeout = 30;
        SeleniumTest.waitForElement(By.name("categoryList"));  // w/out this line it fails on FF
        categoryList = Driver.getDriver().findElement(name("categoryList"));
        Select dropdown = new Select(categoryList);
        dropdown.selectByValue(selection.toString());
    }


    /**
     * sets the name of an asset in the add asset dialog
     * @param newName name it's be be changed to
     * @param itemIndex if not set, it'll be the last item added
     */
    public static void setAssetName(String newName, int... itemIndex) {
        int nameIndex;
        if (itemIndex.length == 0) {
            nameIndex = indexOfNewItem;
        } else {
            nameIndex = itemIndex[0];
        }
        SeleniumTest.waitForElement(By.cssSelector("input.assetName"));
        logger.info("(//input[@type='text'])[{}]", nameIndex + 2);
        SeleniumTest.waitForElement(By.xpath("(//input[@type='text'])[" + Integer.toString(nameIndex + 2) + "]"));
        WebElement assetName = Driver.getDriver().findElement(By.xpath("(//input[@type='text'])[" + Integer.toString(nameIndex + 2) + "]"));
        if (Driver.getBrowserType() != DriverType.FIREFOX) {
            // can't set the new name in FF, it thinks it's blank
            // can't use the Firefox workarounds, I need the ID for the field
            // current solution is to not edit the name
            // TODO: investigate ways to fix this.
            // FF doesn't work with clearandsettext
            SeleniumTest.clearAndSetText(assetName, newName, true);
        }
    }

    public static void clickSubmitUploadButton() {
        SeleniumTest.clickUntilElementDisappearsNoWaiting(uploadButtonLocator);
    }

    /**
     * adds the assets in the upload dialog to the account
     * @return the number of assets in the dialog
     */
    public static void addAssets() {
        clickSubmitUploadButton();
        lastNotification = getNotificationText(true);
        PageFactory.initElements(Driver.getDriver(), DocsAndMediaPage.class);
        indexOfNewItem = 0;
    }

    /**
     * sets the file path for a file upload
     * @param path
     */
    public static void setFilePath(String path) {
        String jQueryString = "jQuery('" + filePathIdentifier + "').show()";
        ((JavascriptExecutor) Driver.getDriver()).executeScript(jQueryString);
        SeleniumTest.waitForElementVisible(By.cssSelector(filePathIdentifier));
        filePath.sendKeys(path);
    }

    public static WebElement getContainer() {
        return addAssetContainer;
    }

    public static void addFileToUpload(DocsAndMediaType mediaType, File newAsset)
            throws FileNotFoundException {
        logger.info("Set the categoryList");
        setCategoryList(mediaType);
        logger.info("click the file radio button");
        SeleniumTest.click(fileRadio);
        if (!newAsset.exists()) {
            logger.error("Couldn't find asset");
            throw new FileNotFoundException("File Asset not Found at: " + newAsset.getAbsolutePath());
        }
        logger.info("Set the file path");
        setFilePath(newAsset.getAbsolutePath());
    }

    public static void setAssetName(String newName){
        SeleniumTest.waitForPageLoadToComplete();
        // This routine assumes that the assetNameBox will be the last //input[@type='text']
        List<WebElement> boxes = Driver.getDriver().findElements(By.xpath("(//input[@type='text'])"));
        SeleniumTest.clearAndSetText(boxes.get(boxes.size() - 1), newName, true);
    }


    /**
     * adds a url to the upload modal
     *
     * @param mediaType image, logo, etc
     * @param url       url to be added
     */
    public static void addUrlToUpload(DocsAndMediaType mediaType, String url) {
        logger.info("Setting Category list to {}", mediaType);
        setCategoryList(mediaType);
        logger.info("Clicking URL radio button");
        SeleniumTest.click(urlRadio);
        try {
            // this was required for IE.  Plus it's closer to the user experience
            SeleniumTest.click(assetURL);
        } catch (ElementNotVisibleException e) {
            // if it's not visible, that means that somehow, the category wasn't selected, which happens
            // intermittently on FF.  log it, and set the category again
            e.printStackTrace();
            logger.error("Failed to select catgory. (is browser FF?)");
            logger.warn("Trying again to set it");
            setCategoryList(mediaType);
            logger.warn("FF - Clicking URL radio");
            SeleniumTest.click(urlRadio);
            logger.warn("FF - Entering URL");
            SeleniumTest.click(assetURL);
        }
        logger.info("Typing Url into field: {}", url);
        SeleniumTest.clearAndSetText(assetURL, url);
        // sometimes on IE the URL is only partially typed in
        if (Driver.getBrowserType() == DriverType.IE) {
            if (assetURL.getAttribute("value") != url) {
                logger.debug("IE: URL failed to be typed into field");
                SeleniumTest.setTextValue(AddDocsAndMedia.assetURL, url);
            }
        }
        logger.info("clicking url add button");
        clickAssetUrlAddButton();
    }

    public static void clickAssetUrlAddButton() {
        SeleniumTest.click(assetUrlAddButton);
        waitForKendoGridRefresh(); // Really, wait for the busy spinner to go away.
    }

}
