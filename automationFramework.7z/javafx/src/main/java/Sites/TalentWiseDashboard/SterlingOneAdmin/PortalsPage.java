package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.Site;
import Sites.URL;
import TWFramework.BodyTextHelper;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by wogden on 2/3/2016.
 */
public class PortalsPage extends ToolPage{
    private static final String PORTALS_URL = "/screening/tools.php?view=cfg_prtls";
    private static final String STANDARD_PORTAL_NAME = "Standard Portal";

    @FindBy(how = How.XPATH, using = "//tr[@role='row']")
    private static WebElement first_row;

    @FindBy(how = How.XPATH, using = "//tr[@role='row']/.//td[@role='gridcell']")
    private static List<WebElement> first_row_cells;

    @FindBy(how = How.XPATH, using = "//tr[@role='row']/.//a[contains(@id, 'delete')]")
    private static WebElement first_row_delete_button;

    @FindBy(how = How.XPATH, using = "//tr[@role='row'][2]/.//a[contains(@id, 'delete')]")
    private static WebElement second_row_delete_button;

    @FindBy(how = How.CLASS_NAME, using = "k-window")
    private static WebElement delete_modal;

    @FindBy(how = How.CLASS_NAME, using = "k-i-close")
    private static WebElement delete_modal_close;

    @FindBy(how = How.ID, using = "createNew")
    private static WebElement createNew;

    // The following assumes a certain table entry will always be at row 2 ...
    @FindBy(how = How.XPATH, using = "//*[@id=\"Portals\"]/table/tbody/tr[2]/td[1]/a")
    private static WebElement testPortal;

    @FindBy(how = How.ID, using = "dbIdFooter")
    private static WebElement pageFooter;

    @FindBy(how = How.CLASS_NAME, using = "k-grid-pager")
    private static WebElement kendorPaginator;

    @FindBy(how = How.ID, using = "page-wrapper")
    private static WebElement portalListSection;

    @FindBy(how = How.ID, using = "PortalsSearchBox")
    private static WebElement portalsSearchBox;

    static {
        PageFactory.initElements(Driver.getDriver(), PortalsPage.class);
        expectedHeaderText = "Portals";
    }

    /**
     * Navigates directly to the forms page URL, while logged in as a customer.
     */
    public static void navigateTo() {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + PORTALS_URL);
    }

    public static int getRowCount() {
        int count = 0;

        while (SeleniumTest.isElementVisibleNoWaiting(By.xpath("//table[@role='grid']//tr[" + (count + 1) + "]//td[1]"))) {
            ++count;
        }

        return count;
    }

    /**
     * Find the row of the given portalName in the Portals table.
     *
     * @param portalName the portalName to look for
     * @return the 1 based index of the row where the given portalName is found, or -1 if no such portalName can be found.
     */
    public static int findPortalNameRow(final String portalName) {
        for (int row = 1; ; ++row) {
            final By locator = By.xpath("//table[@role='grid']//tr[" + row + "]//td[1]");
            if (!SeleniumTest.isElementVisibleNoWaiting(locator)) {
                break;
            }

            if (portalName.equals(SeleniumTest.getTextByLocator(locator).trim())) {
                return row;
            }
        }

        return -1;
    }

    public static void deleteRow(final int row) {
        SeleniumTest.click(By.xpath("//table[@role='grid']//tr[" + row + "]//a[starts-with(@id, 'deleteSubPath')]"));
        // Click "Delete" on the confirm dialog box ...
        SeleniumTest.clickUntilElementDisappearsNoWaiting(By.className("primaryAction"));
    }

    /**
     * Navigates directly to the forms page URL, while proxied.
     *
     * @param userId the userId to proxy
     */
    public static void navigateToProxied(int userId) {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + PORTALS_URL + "&OverrideUserID=" + userId);
    }

    public static void openPortalDetailsByName(String portalName) {
        Driver.getDriver().findElement(By.linkText(portalName)).click();
    }

    public static WebElement getActionsCell() {
        return first_row_cells.get(first_row_cells.size()-1);
    }

    public static WebElement openAndGetDeleteModal(boolean first_row) {
        if(first_row && first_row_delete_button != null) {
            //Need to hide tooltip, because it will block the delete button if the line wraps
            JavaScriptHelper.modifyAttributeForElement(first_row_delete_button.findElement(By.tagName("i")), "title", "");
            first_row_delete_button.click();
        }
        else if(!first_row && second_row_delete_button != null) {
            //Need to hide tooltip, because it will block the delete button if the line wraps
            JavaScriptHelper.modifyAttributeForElement(second_row_delete_button.findElement(By.tagName("i")), "title", "");
            second_row_delete_button.click();
        }
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementNotPresent(By.className("k-loading-image"));
        if(SeleniumTest.isElementVisible(delete_modal)) {
            return delete_modal;
        }
        return null;
    }

    public static void closeDeleteModal() {
        delete_modal_close.click();
    }

    public static void clickCreateNew() {
        // The following waitForElementVisible() assumes a certain table entry will always be at row 2.
        // This has been observed to fail for a new customer, until at least one table entry has been
        // made for that new customer ...
        SeleniumTest.waitForElementVisible(testPortal);
        createNew.click();
    }

    public static void clickTestPortal() {
        testPortal.click();
    }

    public static String getStandardPortalName() {
        return STANDARD_PORTAL_NAME;
    }

    public static WebElement getPortalListSection() {
        // hide un-necessary or dynamic elements.
        BodyTextHelper.hideElement(kendorPaginator);
        BodyTextHelper.hideElement(pageFooter);
        WebElement dynamicRows = portalListSection.findElement(By.tagName("tbody"));
        BodyTextHelper.hideElement(dynamicRows);

        return portalListSection;
    }

    @FindBy(how = How.LINK_TEXT, using = "Portal Name")
    private static WebElement portalNameLabel;

    @FindBy(how = How.LINK_TEXT, using = "Description")
    private static WebElement descriptionLabel;

    @FindBy(how = How.LINK_TEXT, using = "Company Name")
    private static WebElement companyNameLabel;

    @FindBy(how = How.LINK_TEXT, using = "Default Portal")
    private static WebElement defaultPortalLabel;

    @FindBy(how = How.LINK_TEXT, using = "Status")
    private static WebElement statusLabel;

    @FindBy(how = How.LINK_TEXT, using = "Modified On")
    private static WebElement modifiedOnLabel;

    @FindBy(how = How.LINK_TEXT, using = "Modified By")
    private static WebElement modifiedByLabel;

    @FindBy(how = How.XPATH, using = "//table/thead/tr/th[8]")
    private static WebElement actionsLabel;

    @FindBy(how=How.ID, using="span>a[id^=edit]:not([id$='talentwise'])")
    private static WebElement editStandardPortalAction;

    @FindBy(how=How.ID, using="span>a[id^=duplicate]:not([id$='talentwise'])")
    private static WebElement duplicateStandardPortalAction;

    @FindBy(how=How.ID, using="span>a[id^=delete]:not([id$='talentwise'])")
    private static WebElement deleteStandardPortalAction;

    @FindBy(how=How.ID, using="editTalentWise")
    private static WebElement editTalentWiseAction;

    @FindBy(how=How.ID, using="duplicateTalentWise")
    private static WebElement duplicateTalentWiseAction;

    @FindBy(how=How.ID, using="deleteSubPathTalentWise")
    private static WebElement deleteTalentWiseAction;

    @FindBy(how=How.ID, using="dbIdFooter")
    private static WebElement footer;

    public static String getPortalNameLabel() {
        return portalNameLabel.getText();
    }
    public static String getDescriptionLabel() {
        return descriptionLabel.getText();
    }
    public static String getCompanyNameLabel() {
        return companyNameLabel.getText();
    }
    public static String getDefaultPortalLabel() {
        return defaultPortalLabel.getText();
    }
    public static String getStatusLabel() {
        return statusLabel.getText();
    }
    public static String getModifiedOnLabel() {
        return modifiedOnLabel.getText();
    }
    public static String getModifiedByLabel() {
        return modifiedByLabel.getText();
    }
    public static String getActionsLabel() {
        return actionsLabel.getText();
    }
    public static String getPortalRows() {
        String content = "";
        for (WebElement we : first_row_cells) {
            content += we.getText() + "|";
        }
        return content;
    }
    public static boolean verifyStandardPortalAction() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("span>a[id^=edit]:not([id$='talentwise'])"))
            && SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("span>a[id^=duplicate]:not([id$='talentwise'])"))
            && !SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("span>a[id^=delete]:not"
                                                                      + "([id$='talentwise']>i[class~='disabled'])"));
    }

    public static boolean verifyTalentWisePortalAction() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("deleteSubPathTalentWise")) &&
               SeleniumTest.isElementVisibleNoWaiting(By.id("editTalentWise")) &&
               SeleniumTest.isElementVisibleNoWaiting(By.id("duplicateTalentWise"));
    }

    public static String getFooterText() {
        return footer.getText();
    }

    public static void setSearchBoxText(String val) {
        SeleniumTest.clearAndSetText(portalsSearchBox, val);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static String getPortalName(String rowNumber) {
        return SeleniumTest.getTextByLocator(By.xpath(".//*[@id='Portals']//tr[" + rowNumber + "]/td[1]/a"));
    }
}


