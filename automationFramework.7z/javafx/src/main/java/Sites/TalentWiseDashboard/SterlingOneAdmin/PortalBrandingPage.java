package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.TalentWiseDashboard.Kendo;
import TWFramework.BodyTextHelper;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.Iterator;
import java.util.List;

/**
 * Created by wogden on 2/16/2017.
 */
public class PortalBrandingPage {
    @FindBy(how = How.ID, using = "themeSelector")
    private static WebElement themeSelector;

    @FindBy(how = How.ID, using = "themeChoices")
    private static WebElement themeChoices;

    @FindBy(how = How.ID, using = "addLogoImage")
    private static WebElement addLogoImage;

    @FindBy(how = How.ID, using = "selectNewWelcomePackets")
    private static WebElement addDocumentsButton;

    @FindBy(how = How.CLASS_NAME, using = "k-window")
    private static WebElement addItemsMenu;

    @FindBy(how = How.ID, using = "createNewAsset")
    private static WebElement addNewDocumentButton;

    @FindBy(how = How.XPATH, using = "//div[@id=\"ListViewToolBar\"]/div[5]/ul[1]/li[1]/span[1]")
    private static WebElement addItemsFilterButton;

    @FindBy(how = How.XPATH, using = "//div[@id=\"treeview\"]")
    private static WebElement addItemsFilterList;

    @FindBy(how = How.NAME, using = "categoryList")
    private static WebElement addItemsCategoryList;

    //region Branding Controls
    @FindBy(how = How.ID, using = "portalToolbar")
    private static WebElement portalToolBar;

    //region Header
    @FindBy(how = How.ID, using = "headerTools")
    private static WebElement headerExpander;
    private static final String HEADER_EXPANDER_ENUS = "Header";

    //region Header Styling
    @FindBy(how = How.ID, using = "headerStylingNav")
    private static WebElement headerStylingExpander;
    @FindBy(how = How.XPATH, using = "//*[@id=\"portalToolbar\"]/div[1]/div[1]/div[2]/div[2]/span[1]")
    private static WebElement headerStylingBackgroundColor;
    //endregion

    //region Top Bar/Breadcrumbs
    @FindBy(how = How.XPATH, using = "//*[@id=\"topActionBarNav\"]")
    private static WebElement topBarBreadcrumbsExpander;
    //endregion
    //endregion

    //region Content
    @FindBy(how = How.ID, using = "contentTools")
    private static WebElement contentExpander;
    private static final String CONTENT_EXPANDER_ENUS = "Content";

    //region Company Links
    @FindBy(how = How.XPATH, using = "//*[@id=\"portalToolbar\"]/div[2]/h2[1]")
    private static WebElement contentCompanyLinksExpander;
    @FindBy(how = How.ID, using = "widgetHeaderNav")
    private static WebElement contentAddNewLinkExpander;
    @FindBy(how = How.ID, using = "addCompanyLink")
    private static WebElement contentAddNewLinkButton;
    @FindBy(how = How.ID, using = "companyLinkTitleNew")
    private static WebElement contentAddNewLinkTitleField;
    @FindBy(how = How.ID, using = "companyLinkURLNew")
    private static WebElement contentAddNewLinkURLField;
    //endregion

    //region Social Media Links
    @FindBy(how = How.XPATH, using = "//*[@id=\"portalToolbar\"]/div[2]/h2[2]")
    private static WebElement contentSocialMediaLinksExpander;
    @FindBy(how = How.XPATH, using = "//*[@for=\"displayFacebook\"]")
    private static WebElement contentFacebookLinkLabel;
    @FindBy(how = How.XPATH, using = "//*[@for=\"displayTwitter\"]")
    private static WebElement contentTwitterLinkLabel;
    @FindBy(how = How.XPATH, using = "//*[@for=\"displayLinkedIn\"]")
    private static WebElement contentLinkedInLinkLabel;
    //endregion

    //region Widgets
    @FindBy(how = How.XPATH, using = "//*[@id=\"portalToolbar\"]/div[2]/h2[3]")
    private static WebElement contentWidgetsExpander;
    @FindBy(how = How.XPATH, using = "(//*[@id=\"widgetHeaderNav\"])[2]") //Two elements exist with this id
    private static WebElement contentWidgetHeaderExpander;
    @FindBy(how = How.ID, using = "widgetBodyNav")
    private static WebElement contentWidgetBodyExpander;
    //endregion

    //region Fonts
    @FindBy(how = How.XPATH, using = "//*[@id=\"portalToolbar\"]/div[2]/h2[5]")
    private static WebElement contentFontsExpander;
    @FindBy(how = How.ID, using = "portalBodyFontNav")
    private static WebElement contentBodyFontExpander;
    @FindBy(how = How.ID, using = "portalHeaderFontNav")
    private static WebElement contentHeaderFontExpander;
    //endregion

    //region Background Colors
    @FindBy(how = How.XPATH, using = "//*[@id=\"portalToolbar\"]/div[2]/h2[6]")
    private static WebElement contentBackgroundColorExpander;
    //endregion

    //region Welcome Packet Documents
    @FindBy(how = How.XPATH, using = "//*[@id=\"portalToolbar\"]/div[2]/h2[7]")
    private static WebElement contentWelcomePacketDocumentsExpander;
    @FindBy(how = How.XPATH, using = "//*[@for=\"includeWelcomePackets\"]")
    private static WebElement contentIncludeDocumentsLabel;
    //endregion

    //region Buttons
    @FindBy(how = How.ID, using = "launchTaskButtonNav")
    private static WebElement buttonsExpander;

    @FindBy(how = How.XPATH, using = "//label[@for='widgetButtonBackgroundColorStyle']")
    private static WebElement buttonBackgroundColorLabel;

    @FindBy(how = How.ID, using = "topButtonColor")
    private static WebElement buttonTopColorLabel;

    @FindBy(how = How.ID, using = "botButtonColor")
    private static WebElement buttonBottomColorLabel;
    //endregion
    //endregion

    //region Footer
    @FindBy(how = How.ID, using = "footerTools")
    private static WebElement footerExpander;
    private static final String FOOTER_EXPANDER_ENUS = "Footer";

    //region Background Color
    @FindBy(how = How.ID, using = "portalFooterNav")
    private static WebElement footerBackgroundColorExpander;
    //endregion

    //region
    @FindBy(how = How.ID, using = "portalFooterFontNav")
    private static WebElement footerLinksAndContactsExpander;
    //endregion
    //endregion

    //endregion

    //region Form Fields
    @FindBy(how = How.ID, using = "portalHeader")
    private static WebElement portalHeader;
    @FindBy(how = How.ID, using = "breadCrumbs")
    private static WebElement breadCrumbs;
    @FindBy(how = How.ID, using = "portalBrandingContent")
    private static WebElement portalBodyContent;
    @FindBy(how = How.ID, using = "bannerText")
    private static WebElement bannerTextField;
    @FindBy(how = How.XPATH, using = "//div[@id=\"myInbox\"]/div[contains(@class, \"portalContentHeader\")]")
    private static WebElement myInboxHeader;
    @FindBy(how = How.XPATH, using = "//div[@id=\"myInbox\"]/div[contains(@class, \"portalContentBody\")]")
    private static WebElement myInboxBody;
    @FindBy(how = How.XPATH, using = "//div[@id=\"myDocuments\"]/div[contains(@class, \"portalContentHeader\")]")
    private static WebElement myDocumentsHeader;
    @FindBy(how = How.XPATH, using = "//div[@id=\"myDocuments\"]/div[contains(@class, \"portalContentBody\")]")
    private static WebElement myDocumentsBody;
    @FindBy(how = How.XPATH, using = "//div[@id=\"welcomePackets\"]/div[contains(@class, \"portalContentHeader\")]")
    private static WebElement myPacketsHeader;
    @FindBy(how = How.XPATH, using = "//div[@id=\"welcomePackets\"]/div[contains(@class, \"portalContentBody\")]")
    private static WebElement myPacketsBody;
    @FindBy(how = How.ID, using = "verticalButton")
    private static WebElement verticalButton;
    @FindBy(how = How.XPATH, using = "//div[@id=\"myProfile\"]/div[contains(@class, \"portalContentHeader\")]")
    private static WebElement myProfileHeader;
    @FindBy(how = How.XPATH, using = "//div[@id=\"myProfile\"]/div[contains(@class, \"portalContentListContent\")]")
    private static WebElement myProfileBody;
    //region Footer Content
    @FindBy(how = How.ID, using = "footerBar")
    private static WebElement footerBar;
    @FindBy(how = How.ID, using = "contactPointLabel_2")
    private static WebElement footerLabelField1;
    @FindBy(how = How.ID, using = "contactPointPhone_2")
    private static WebElement footerPhoneNumberField1;
    @FindBy(how = How.ID, using = "contactPointEmail_1")
    private static WebElement footerEmailAddressField1;
    @FindBy(how = How.ID, using = "contactPoint2Label_2")
    private static WebElement footerLabelField2;
    @FindBy(how = How.ID, using = "contactPoint2Phone_2")
    private static WebElement footerPhoneNumberField2;
    @FindBy(how = How.ID, using = "contactPoint2Email_1")
    private static WebElement footerEmailAddressField2;
    @FindBy(how = How.ID, using = "companyLinksTitle_2")
    private static WebElement companyLinksTitle;
    @FindBy(how = How.XPATH, using = "//div[@id=\"column2\"]")
    private static WebElement socialLinksTitle;

    @FindBy(how = How.ID, using = "upload-button")
    private static WebElement uploadButton;

    private static final By saveBrandingReturnLocator = By.id("saveBrandingReturn");
    //endregion
    //endregion

    public static String getButtonText(LocaleHelper.Locale locale, String button) {
        switch (locale.UrlTag()){
            case "en-US":
                switch (button) {
                    case "Expander":
                        return "Buttons";
                    case "BackgroundColor":
                        return "Background Color";
                    case "TopColor":
                        return "Top Color";
                    case "BottomColor":
                        return "Bottom Color";
                }
            case "qps-PLOC":
                switch (button) {
                    case "Expander":
                        return "[{5b3e} Ɓŭŧŧǿƞş]";
                    case "BackgroundColor":
                        return "[{75e7} Ɓȧƈķɠřǿŭƞḓ Ƈǿŀǿř]";
                    case "TopColor":
                        return "Top Color";
                    case "BottomColor":
                        return "[{bc5d} Ɓǿŧŧǿḿ Ƈǿŀǿř]";
                }
        }

        return "unknown button";
    }

    @FindBy(how = How.ID, using = "cancelBranding")
    private static WebElement cancelBranding;

    static {
        PageFactory.initElements(Driver.getDriver(), PortalBrandingPage.class);
    }

    public static void hideDateElements() {
        List<WebElement> dateElements = Driver.getDriver().findElements(By.className("currentDateField"));
        for(Iterator<WebElement> i = dateElements.iterator(); i.hasNext();) {
            BodyTextHelper.hideElement(i.next());
        }
        return;
    }

    public static void clickThemeSelector() {
        SeleniumTest.click(themeSelector);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static WebElement getThemeChoices() {
        return themeChoices;
    }

    public static void clickAddLogoImage() {
        SeleniumTest.click(addLogoImage);
        ToolPage.waitForKendoGridRefresh();
    }

    public static void clickAddDocumentsButton() {
        SeleniumTest.click(addDocumentsButton);
        ToolPage.waitForKendoGridRefresh();
    }

    public static void clickAddNewDocumentsButton() {
        SeleniumTest.click(addNewDocumentButton);
        SeleniumTest.waitForPageLoadToComplete();
        ToolPage.waitForKendoGridRefresh();
    }

    public static WebElement getAddItemsFilterList() {
        return addItemsFilterList;
    }

    public static void clickAddItemsFilter() {
        SeleniumTest.click(addItemsFilterButton);
    }

    public static void clickAddItemsCategoryList() {
        SeleniumTest.click(addItemsCategoryList);
    }

    public static WebElement getAddItemsCategoryList() {
        return addItemsCategoryList;
    }

    public static WebElement getPortalToolBar() { return portalToolBar; }

    public static WebElement getAddItemsMenu() { return addItemsMenu; }

    public static String getButtonExpanderText() {
        return buttonsExpander.getText();
    }

    public static String getButtonBackgroundColorText() {
        return buttonBackgroundColorLabel.getText();
    }

    public static String getButtonTopColorText() {
        return buttonTopColorLabel.getText();
    }

    public static String getButtonBottomColorText() {
        return buttonBottomColorLabel.getText();
    }

    /*Side Menu*/
    public static void clickHeaderExpander() {
        SeleniumTest.click(headerExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickHeaderStylingExpander() {
        SeleniumTest.click(headerStylingExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickTopBarExpander() {
        SeleniumTest.click(topBarBreadcrumbsExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static void clickContentExpander() {
        SeleniumTest.click(contentExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickCompanyLinksExpander() {
        SeleniumTest.click(contentCompanyLinksExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickAddNewLinkExpander() {
        SeleniumTest.click(contentAddNewLinkExpander);
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.click(contentAddNewLinkButton);
    }
    public static void createNewLink() {
        SeleniumTest.setTextValue(contentAddNewLinkTitleField, "Test");
        SeleniumTest.setTextValue(contentAddNewLinkURLField, "https://www.sterlingtalentsolutions.com/");
        SeleniumTest.click(contentAddNewLinkButton);
    }
    public static void clickSocialMediaLinksExpander() {
        SeleniumTest.click(contentSocialMediaLinksExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFacebookLabel() {
        SeleniumTest.click(contentFacebookLinkLabel);
    }
    public static void clickTwitterLabel() {
        SeleniumTest.click(contentTwitterLinkLabel);
    }
    public static void clickLinkedInLabel() {
        SeleniumTest.click(contentLinkedInLinkLabel);
    }
    public static void clickWidgetsExpander() {
        SeleniumTest.click(contentWidgetsExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickWidgetHeaderExpander() {
        SeleniumTest.click(contentWidgetHeaderExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickWidgetBodyExpander() {
        SeleniumTest.click(contentWidgetBodyExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickButtonExpander() {
        SeleniumTest.click(buttonsExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFontsExpander() {
        SeleniumTest.click(contentFontsExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickBodyFontExpander() {
        SeleniumTest.click(contentBodyFontExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickHeaderFontExpander() {
        SeleniumTest.click(contentHeaderFontExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickBackgroundColorExpander() {
        SeleniumTest.click(contentBackgroundColorExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickWelcomePacketDocumentsExpander() {
        SeleniumTest.click(contentWelcomePacketDocumentsExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickIncludeDocumentsLabel() {
        SeleniumTest.click(contentIncludeDocumentsLabel);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static void clickFooterExpander() {
        SeleniumTest.click(footerExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterFontColorExpander() {
        SeleniumTest.click(footerBackgroundColorExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterLinksAndContactsExpander() {
        SeleniumTest.click(footerLinksAndContactsExpander);
        SeleniumTest.waitForPageLoadToComplete();
    }

    /*Control Fields*/
    public static void clickPortalHeader() {
        SeleniumTest.click(portalHeader);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickBreadCrumbs() {
        SeleniumTest.click(breadCrumbs);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickPortalBodyContent() {
        SeleniumTest.click(portalBodyContent);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickBannerTextField() {
        SeleniumTest.click(bannerTextField);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyInboxHeader() {
        SeleniumTest.click(myInboxHeader);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyInboxBody() {
        SeleniumTest.click(myInboxBody);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyDocumentsHeader() {
        SeleniumTest.click(myDocumentsHeader);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyDocumentsBody() {
        SeleniumTest.click(myDocumentsBody);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyPacketsHeader() {
        SeleniumTest.click(myPacketsHeader);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyPacketsBody() {
        SeleniumTest.click(myPacketsBody);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickVerticalButton() {
        SeleniumTest.click(verticalButton);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyProfileHeader() {
        SeleniumTest.click(myProfileHeader);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickMyProfileBody() {
        SeleniumTest.click(myProfileBody);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterBar() {
        SeleniumTest.click(footerBar);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterLabelField1() {
        SeleniumTest.click(footerLabelField1);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterPhoneNumberField1() {
        SeleniumTest.click(footerPhoneNumberField1);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterEmailAddressField1() {
        SeleniumTest.click(footerEmailAddressField1);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterLabelField2() {
        SeleniumTest.click(footerLabelField2);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterPhoneNumberField2() {
        SeleniumTest.click(footerPhoneNumberField2);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickFooterEmailAddressField2() {
        SeleniumTest.click(footerEmailAddressField2);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickCompanyLinksTitle() {
        SeleniumTest.click(companyLinksTitle);
        SeleniumTest.waitForPageLoadToComplete();
    }
    public static void clickSocialLinksTitle() {
        SeleniumTest.click(socialLinksTitle);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static void clickCancelBranding() {
        SeleniumTest.click(cancelBranding);
    }

    public static void clickVisibleColorDropdown(boolean thirdDiv) {
        String lookup_path = "//div[contains(@style,'display: block;')]/div[contains(@style,'display: block;')]";
        if(thirdDiv)
        {
            lookup_path += "/div[contains(@style,'display: block;')]";
        }
        WebElement section = portalToolBar.findElement(By.xpath(lookup_path));
        WebElement dropdown = section.findElement(By.className("k-dropdown"));
        SeleniumTest.click(dropdown);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static WebElement getVisibleColorDropdown() {
        WebElement dropdownDiv = portalToolBar.findElement(By.xpath(
                "//div[@class=\"k-animation-container\"][contains(@style,'display: block;')]"));
        return dropdownDiv;
    }

    public static void enableWelcomePacketDocuments() {
        clickMyDocumentsHeader();
        clickWelcomePacketDocumentsExpander();
        clickIncludeDocumentsLabel();
    }

    public static void typeBannerTextField(String bannerText) {
        SeleniumTest.clearAndSetText(bannerTextField, bannerText);
    }

    public void selectLogoAndUpload(String fileName){
        SeleniumTest.click(uploadButton);
        Kendo.waitForKendoBusyImageToGoAway();
        SeleniumTest.click(By.xpath(".//td[text()='"+fileName+"']/../td[1]/input"));
        SeleniumTest.click(uploadButton);
    }

    public void clickSaveBrandingAndReturn(){
        // If this doesn't make sure that the "Save and Return" button has gone away,
        // The browser will linger on the page, and assume the data hasn't saved until
        // the button has completed its task.  If automation tries to navigate away while
        // the button is still visible, Chrome pops up an alert saying something like,
        // "Leave this page?  You will lose unsaved data."
        SeleniumTest.clickUntilElementDisappearsNoWaiting(saveBrandingReturnLocator);
        SeleniumTest.waitForPageLoadToComplete();
    }

}
