package Sites.TalentWiseDashboard.SterlingOneAdmin.Exceptions;

import org.openqa.selenium.InvalidElementStateException;

/**
 * Created by wogden on 7/20/2015.
 */
public class ElementNotHiddenException extends InvalidElementStateException {
    public ElementNotHiddenException(String message) {
        super(message);
    }

    public ElementNotHiddenException(String message, Throwable cause) {
        super(message, cause);
    }
}