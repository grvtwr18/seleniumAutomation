package Sites.TalentWiseDashboard.SterlingOneAdmin;

import Sites.TalentWiseDashboard.Helpers.Header;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Contributor;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 10/30/2015.
 */
public class ContributorsVerifiersPage extends ToolPage {

    @FindBy(how = How.ID, using = "createNew")
    private static WebElement createNewButton;
    @FindBy(how = How.XPATH, using = "//span[text()='Go to the last page']")
    private static WebElement arrowGoToLastPage;
    public static By firstRowNameLocator = By.xpath("//div[@id='ContributorList']/table/tbody/tr/td[2]");
    @FindBy(how = How.ID, using = "ContributorListSearchBox")
    public static WebElement searchField;

    @FindBy(how = How.LINK_TEXT, using = "User Name")
    public static WebElement userNameColumnHeader;

    @FindBy(how = How.LINK_TEXT, using = "Email Address")
    public static WebElement emailAddressColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='ContributorList']/table/thead/tr/th[4]")
    public static WebElement groupsColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='ContributorList']/table/thead/tr/th[7]")
    public static WebElement contributorStatusColumnHeader;

    @FindBy(how = How.XPATH, using = "//div[@id='ContributorList']/table/thead/tr/th[8]")
    public static WebElement actionsColumnHeader;

    @FindBy(how = How.XPATH, using = "//span[@class='k-pager-info k-label']")
    public static WebElement contributorGridItemCount;

    @FindBy(how = How.CSS, using = "button.actionButton.primaryAction")
    public static WebElement saveButton;

    @FindBy(how = How.CSS, using = "button.actionButton.secondaryAction")
    public static WebElement CancelButton;
    private By createNewButtonLocator = By.id("createNew");

    private static ThreadLocal<ContributorsVerifiersPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                ContributorsVerifiersPage.class));
    }

    private static ContributorsVerifiersPage getInstance() {
        return threadLocalInstance.get();
    }

    public ContributorsVerifiersPage() {
        super();
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.waitForElementVisible(createNewButtonLocator);
        expectedHeaderText = "Contributors (verifiers)";
        gridName = "ContributorList";
        kendoGridColumnOffset = 2;
    }

    /**
     * Goes to the contributor list page.
     * @return
     */
    public static void navigateToContributorList() {
        Header.clickAdmin().getAdminMenubar().clickContributorsMenuItem();
    }

    /**
     * Clicks on the Create New Button
     *
     * @return Returns a new Contributor Page Object
     */
    public static void clickCreateNewButton() {
        SeleniumTest.waitForJQueryAjaxDone();
        SeleniumTest.click(getInstance().createNewButton);
    }



    public static void clickGoToLastPage() {
        WaitUntil.waitUntil(() -> getInstance().arrowGoToLastPage.isDisplayed(), NoSuchElementException.class);
        SeleniumTest.click(getInstance().arrowGoToLastPage);
    }

    public static void clickDeleteContributorIcon(String emailAddress) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//td[text()='" + emailAddress +
                "']/following-sibling::td[5]/span[2]")));
    }

    public static void deleteContributor(String emailAddress) {
        getInstance().clickDeleteContributorIcon(emailAddress);
        DeleteUserModal.clickDelete(ContributorsVerifiersPage.class);
    }

    public static WebElement getContributorGridItemCount() {
        return getInstance().contributorGridItemCount;
    }

    public static void selectContributorStatus(String status, String emailAddress) {
        // For some very strange reason this element changes when clicked.
        // Have to find it raw first
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//td[text()='" + emailAddress +
                "']/following-sibling::td[3]/span")));
        // Then have to find the newly created /li on the page since clicking above creates new
        // elements on the fly.
        WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.xpath("//li[text()='" + status + "']"))
                .isEnabled());
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//li[text()='" + status + "']")));
    }

    public static ContributorDetailPage openContributorDetails(Integer loginIDForContributor) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//a[contains(@href,'" + loginIDForContributor +
                "')]")));
        return PageFactory.initElements(Driver.getDriver(), ContributorDetailPage.class);
    }

    public static ContributorDetailPage openContributorDetailsCurrentContributor() {
        SeleniumTest.clearAndSetText(getInstance().searchField, Contributor.getCurrentContributor().getEmailAddress());
        // Wait for the spinning loading mask to go away before expecting to click on the person's name ...
        SeleniumTest.waitForElementNotPresentNoWaiting(By.cssSelector("div.k-loading-mask"));
        final By locator = By.linkText(Contributor.getCurrentContributor().getLastName()
                + ", " + Contributor.getCurrentContributor().getFirstName());
        SeleniumTest.click(locator);
        return PageFactory.initElements(Driver.getDriver(), ContributorDetailPage.class);
    }

    public static ContributorDetailPage openContributorDetails(String firstName, String lastName) {
        SeleniumTest.click(Driver.getDriver().findElement(By.linkText(lastName + ", " + firstName)));
        return PageFactory.initElements(Driver.getDriver(), ContributorDetailPage.class);
    }

    //TODO do others
    public static String getContribuutorEmail(String row) {
        return Driver.getDriver().findElement(By.xpath("//div[@id='ContributorList']/table/tbody/tr[" + row + "]/td[3]")).getText();
    }

    public static String getContributorStatus(String row) {
        return Driver.getDriver().findElement(By.xpath("//div[@id='ContributorList']/table/tbody/tr[" + row + "]/td[7]")).getText();
    }

    /**
     * Types and searches for the given string
     */
    public void searchContributors(String searchString) {
        SeleniumTest.clearAndSetText(getInstance().searchField, searchString);
        SeleniumTest.waitForPageLoadToComplete();
        waitForKendoGridRefresh();
    }

    public static ContributorsVerifiersPage clickSave() {
        SeleniumTest.click(getInstance().saveButton);
        return PageFactory.initElements(Driver.getDriver(), ContributorsVerifiersPage.class);
    }

    public static void clickEditIcon(int contributorId) {
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath(
                "//a[contains(@class,'editIcon')][contains(@href,'" + contributorId + "')]")));
    }

    public String getContributorUserName(int row) {
        return SeleniumTest.getTextByLocator(By.xpath(".//*[@id='ContributorList']/table/tbody/tr[" + row + "]/td[2]"));
    }

    public String getContributorEmail(int row){
        return SeleniumTest.getTextByLocator(By.xpath(".//*[@id='ContributorList']/table/tbody/tr[" + row + "]/td[3]"));
    }

    public String getGroupName(int row){
        return SeleniumTest.getTextByLocator(By.xpath(".//*[@id='ContributorList']/table/tbody/tr[" + row + "]/td[4]"));
    }
}