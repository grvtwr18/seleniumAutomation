package Sites.TalentWiseDashboard.SterlingOneAdmin;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by kparker on 2017/06/23
 */
public class EmailTemplatesPage extends ToolPage{
    static {
        PageFactory.initElements(Driver.getDriver(), EmailTemplatesPage.class);
    }

    @FindBy(how = How.ID, using = "createNew")
    private static WebElement createNew;

    // below are always taking the first row of the templates, which is the product behavior
    @FindBy(how = How.XPATH, using = "//*[@id=\"CandidateEmailTemplateGroupList\"]/table/tbody/tr/td[1]/a")
    private static WebElement tableContent;

    @FindBy(how=How.ID, using="showVars")
    private static WebElement showVariables;

    @FindBy(how=How.ID, using="hideVars")
    private static WebElement hideVariables;

    @FindBy(how=How.ID, using="CandidateEmailTemplateGroupListSearchBox" )
    private static WebElement searchBox;

    @FindBy(how=How.XPATH, using="//div[@id='CandidateEmailTemplateGroupList']/table/tbody/tr/td")
    private static WebElement templateGroupName;

    @FindBy(how=How.XPATH, using="//div[@id='CandidateEmailTemplateGroupList']/table/tbody/tr/td[2]")
    private static WebElement descriptionValue;



    @FindBy(how=How.XPATH, using="//div[@id='CandidateEmailTemplateGroupList']/table/tbody/tr/td[4]")
    private static WebElement statusValue;

    @FindBy(how=How.XPATH, using="//div[@id='CandidateEmailTemplateGroupList']/table/tbody/tr/td[5]")
    private static WebElement modifiedOnValue;

    @FindBy(how=How.XPATH, using="//div[@id='CandidateEmailTemplateGroupList']/table/tbody/tr/td[6]")
    private static WebElement modifiedByValue;

    @FindBy(how=How.XPATH, using="//div[@id='CandidateEmailTemplateGroupList']/table/tbody/tr/td[7]")
    private static WebElement actionContent;

    @FindBy(how=How.CSS, using="span.k-icon.k-i-sort-asc-sm")
    private static WebElement templateNameAscSortIcon;
    @FindBy(how=How.CSS, using="span.k-icon.k-i-sort-desc-sm")
    private static WebElement templateNameDecSortIcon;

    @FindBy(how=How.ID, using="duplicateGroup")
    private static WebElement newDuplicateGroup;

    @FindBy(how=How.ID, using="deleteGroup")
    private static WebElement newDeleteGroup;

    @FindBy(how=How.CSS, using="tr:first-child>td>span>a[title='Edit']")
    private static WebElement editGroup;

    @FindBy(how=How.CSS, using="span>a[title='Duplicate']")
    private static WebElement duplicateGroup;

    @FindBy(how=How.CSS, using="span[style='display:inline']>a[id^=deleteGroup]")
    private static WebElement deleteGroup;



    @FindBy(how=How.CSS, using="a[title='Go to the first page']")
    private static WebElement navFirst;

    @FindBy(how=How.CSS, using="a[title='Go to the previous page']")
    private static WebElement navPrevious;

    @FindBy(how=How.CSS, using="a[title='Go to the next page']")
    private static WebElement navNext;

    @FindBy(how=How.CSS, using="a[title='Go to the last page']")
    private static WebElement navLast;

    @FindBy(how=How.CSS, using="span.k-input")
    private static WebElement numOfItemsPerPage;


    public static void clickEditGroup() {
        SeleniumTest.click(editGroup);
    }


    public static String getEditTooltip(By by) {
        return getTooltip(editGroup, by);
    }

    public static String getDupTooltip(By by) {
        return getTooltip(duplicateGroup, by);
    }

    public static void clickDeleteGroup() {
        SeleniumTest.click(deleteGroup);
    }

    public static boolean isDeleteGroupPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("deleteGroup"));
    }

    // these are buttons on New Template Group page
    public static boolean isNewDuplicateGroupPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("duplicateGroup"));
    }

    public static boolean isNewDeleteGroupPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("deleteGroup"));
    }


    public static void clickNew(){
        SeleniumTest.waitForElementVisible(tableContent);
        SeleniumTest.click(createNew);
    }

    public static void clickShowVariables() { SeleniumTest.click(showVariables); }
    public static void clickHideVariables() { SeleniumTest.click(hideVariables); }

    public static boolean isSearchBoxPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("CandidateEmailTemplateGroupListSearchBox"));
    }

    public static void setSearchBoxText(String val) {
        SeleniumTest.clearAndSetText(searchBox, val);
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static boolean isNavFirstPrent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("a[title='Go to the first page']"));
    }

    public static boolean isNavPreviousPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("a[title='Go to the previous page']"));
    }

    public static boolean isNavNextPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("a[title='Go to the next page']"));
    }

    public static boolean isNavLastPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("a[title='Go to the last page']"));
    }

    public static int getNumOfItemsPerPage() {
        return Integer.parseInt(SeleniumTest.getText(numOfItemsPerPage));
    }

    public static String getTemplateGroupName() {
        return templateGroupName.getText();
    }

    public static String getDescriptionValue() {
        return descriptionValue.getText();
    }


    public static String getStatusValue() {
        return statusValue.getText();
    }

    public static String  getModifiedOnValue() {
        return modifiedOnValue.getText();
    }

    public static String getModifiedByValue() {
        return modifiedByValue.getText();
    }

    public static boolean isAscSortIconPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("span.k-icon.k-i-sort-asc-sm"));
    }

    public static boolean isDecSortIconPresent() {
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("span.k-icon.k-i-sort-desc-sm"));
    }

    public static String getTemplateName(int rowNumber) {
        return SeleniumTest.getTextByLocator(By.xpath(".//*[@id='CandidateEmailTemplateGroupList']//tr["+rowNumber+"]/td[1]/a"));
    }
}
