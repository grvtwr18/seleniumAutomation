package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.SterlingOneAdmin.Exceptions.ElementExistsException;
import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Sidebar;
import TWFramework.BasicTest;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import static WebDriver.Driver.getDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;

/**
 * Created by abrackett on 10/19/2015.
 */
public class EditProfileModal {
    public Sidebar sidebar;
    public Header header;
    public Footer footer;

    private static final By entireModalFormLocator = By.id("divEditProfile");
    @FindBy(how = How.ID, using = "divEditProfile")
    private static WebElement entireModalForm;

    @FindBy(how = How.ID, using = "qf")
    private static WebElement firstNameBox;

    @FindBy(how = How.ID, using = "qmi")
    private static WebElement middleNameBox;

    @FindBy(how = How.ID, using = "qnomi")
    private static WebElement noMiddleNameCheckbox;

    @FindBy(how = How.ID, using = "qn")
    private static WebElement lastNameBox;

    @FindBy(how = How.NAME, using = "qee")
    private WebElement emailAddress;

    @FindBy(how = How.NAME, using = "qssn")
    private WebElement ssnBox;

    @FindBy(how = How.NAME, using = "qmm")
    private WebElement dobMonth;

    @FindBy(how = How.NAME, using = "qdd")
    private WebElement dobDay;

    @FindBy(how = How.NAME, using = "qyy")
    private WebElement dobYear;

    @FindBy(how = How.NAME, using = "qstartmonth")
    private WebElement startMonth;

    @FindBy(how = How.NAME, using = "qstartday")
    private WebElement startDay;

    @FindBy(how = How.NAME, using = "qstartyear")
    private WebElement startYear;

    @FindBy(how = How.ID, using = "qpa1")
    private static WebElement activePortalLoginRadio;

    @FindBy(how = How.ID, using = "qpa2")
    private static WebElement inActivePortalLoginRadio;

    @FindBy(how = How.XPATH, using = "//input[contains(@value, 'Save Changes')]")
    private static WebElement saveChangesButton;

    @FindBy(how = How.XPATH, using = "//input[contains(@value, 'Cancel')]")
    private static WebElement cancelButton;
    
    @FindBy(how = How.CSS, using = "img[alt='Add Name']")
    private static WebElement addNameLink;

    @FindBy(how = How.ID, using = "organizationid_0")
    private static WebElement organization;

    @FindBy(how = How.XPATH, using = "//*[@id='divEditProfile' and @class='modalWindow']")
    private static WebElement editProfileModal;

    private static final By missingRequiredFieldsErrorMessageLocator = By.cssSelector("div.dbAlertColor");

    private static boolean emailAddressChanged = false;

    private static final Logger staticLogger = LoggerFactory.getLogger(EditProfileModal.class);

    @Deprecated // Page routines should not return WebElements
    public static WebElement getEntireModal() {
        return entireModalForm;
    }

    public static void waitForEntireModalToGoAway() {
        WaitUntil.waitUntil(() -> !SeleniumTest.isElementVisibleNoWaiting(entireModalFormLocator));
    }

    public static EditProfileModal setPortalLoginActive() {
        SeleniumTest.click(activePortalLoginRadio);
        return PageFactory.initElements(getDriver(), EditProfileModal.class);
    }

    public static EditProfileModal setPortalLoginInActive() {
        SeleniumTest.click(inActivePortalLoginRadio);
        return PageFactory.initElements(getDriver(), EditProfileModal.class);
    }

    public static String getCandidateFirstAndLastName() {
        return getCandidateFirstName() + " " + getCandidateLastName();
    }

    public static String getCandidateFirstMiddleAndLastName() {
        return getCandidateFirstName() + " "
                + getCandidateMiddleName() + " "
                + getCandidateLastName();
    }

    public static String getCandidateFirstName() {
        return SeleniumTest.getText(firstNameBox);
    }

    public static String getCandidateMiddleName() {
        return SeleniumTest.getText(middleNameBox);
    }

    public static String getCandidateLastName() {
        return SeleniumTest.getText(lastNameBox);
    }

    /**
     * Sets the e-mail Address in the Edit Profile Modal
     * @param newEmailAddress e-mail address to use
     */
    public EditProfileModal setEmailAddress(String newEmailAddress) {
        if (!emailAddress.getAttribute("value").equalsIgnoreCase(newEmailAddress)) {
            emailAddressChanged = true;
            SeleniumTest.clearAndSetText(emailAddress, newEmailAddress);
        }
        return this;
    }

    /**
     * Sets first name
     * @param firstName
     * @return
     */
    public EditProfileModal setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
        return this;
    }

    /**
     * sets middle name
     * @param middleName
     * @return
     */
    public static EditProfileModal setMiddleName(String middleName) {
        if (middleName.isEmpty()) {
            if (!noMiddleNameCheckbox.isSelected()) {
                SeleniumTest.click(noMiddleNameCheckbox);
            }
        }
        else {
            if (noMiddleNameCheckbox.isSelected()) {
                SeleniumTest.click(noMiddleNameCheckbox);
            }
            SeleniumTest.clearAndSetText(middleNameBox, middleName);
            staticLogger.info("Set Middle Name = {}", middleName);
        }
        return PageFactory.initElements(getDriver(), EditProfileModal.class);
    }

    /**
     * sets last name
     * @param lastName
     * @return
     */
    public EditProfileModal setLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
        return this;
    }

    /**
     * sets SSN
     * @param ssn
     * @return
     */
    public EditProfileModal setSSN(String ssn) {
        // removing the hard coded ssn
        boolean isSSNEditable = false;
        try {
            isSSNEditable = ssnBox.isDisplayed();
        } catch(NullPointerException | NoSuchElementException e) {
            // fall through
        }
        if(ssn !=null && isSSNEditable) {
            SeleniumTest.clearAndSetText(ssnBox, ssn);
            staticLogger.info("Set SSN = {}", ssn);
        }
        return this;
    }

    /**
     * Sets Date of Birth
     * @param dateOfBirth
     * @return
     */
    public EditProfileModal setDOB(LocalDate dateOfBirth)
    {
        String threeCharacterMonth = dateOfBirth.getMonth().toString().substring(0,3);
        threeCharacterMonth = threeCharacterMonth.substring(0,1) + threeCharacterMonth.substring(1,3).toLowerCase();
        boolean isDateOfBirthEditable = false;
        try {
            if(dobMonth.isDisplayed() && dobYear.isDisplayed() && dobDay.isDisplayed()) {
                isDateOfBirthEditable = true;
            }
        } catch(NoSuchElementException | NullPointerException e) {
            // Fall through
        }
        if(isDateOfBirthEditable) {
            if (dateOfBirth != null) {
                SeleniumTest.selectShortMonthByVisibleText(dobMonth, threeCharacterMonth);
                SeleniumTest.selectByVisibleTextFromDropDown(dobDay, Integer.toString(dateOfBirth.getDayOfMonth()));

                SeleniumTest.selectByVisibleTextFromDropDown(dobYear, Integer.toString(dateOfBirth.getYear()));
            } else {
                SeleniumTest.selectShortMonthByVisibleText(dobMonth, "Nov");
                SeleniumTest.selectByVisibleTextFromDropDown(dobDay, Integer.toString(11));
                SeleniumTest.selectByVisibleTextFromDropDown(dobYear, Integer.toString(1984));
            }
            staticLogger.info("Set DOB = {}",
                              dateOfBirth.format(LocaleHelper.getDateFormatShortDateSlash()));
        }
        return this;
    }

    /**
     * Sets Start Date
     * @param startDate
     * @return
     */
    public EditProfileModal setStartDate(java.time.LocalDate startDate) {
        if (startDate != null) {
            SeleniumTest.selectShortMonthByVisibleText(startMonth, startDate);
            SeleniumTest.selectByVisibleTextFromDropDown(startDay, Integer.toString(startDate.getDayOfMonth()));
            SeleniumTest.selectByVisibleTextFromDropDown(startYear, Integer.toString(startDate.getYear()));
        } else {
            LocalDate today = LocalDate.now();
            SeleniumTest.selectShortMonthByVisibleText(startMonth, today);
            SeleniumTest.selectByVisibleTextFromDropDown(startDay, Integer.toString(today.getDayOfMonth()));
            SeleniumTest.selectByVisibleTextFromDropDown(startYear, Integer.toString(today.getYear()));
        }
        return this;
    }

    /**
     * Clicks cancel button and closes the modal
     * @param returnedClass the Page Object to be returned
     * @return
     */
    public static CustomerDashboardPages clickCancelButton(Class<? extends CustomerDashboardPages> returnedClass) {
        SeleniumTest.click(cancelButton);
        // Explicitly waiting for edit profile modal to close before continuing
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks save changes
     * @param returnedClass the Page Object to be returned
     * @return
     */
    public static CustomerDashboardPages clickSaveChanges(Class<? extends CustomerDashboardPages> returnedClass) {
        SeleniumTest.click(saveChangesButton);
        SeleniumTest.waitForPageLoad();
        // check for an error with required fields
        if (isErrorMessageTextVisible()) {
            staticLogger.error("Missing a required field, can't save");
            staticLogger.error("{}", getErrorMessageText());
            BasicTest.addErrorToCollector(new ElementExistsException("Required Field missing"));
        }
        // Explicitly waiting for edit profile modal to close before continuing
        SeleniumTest.defaultWaitForElementWithMultiplier(.2);
        if (emailAddressChanged) {
            try {
                ChangeEmailAddressModal changeEmailAddressModal = PageFactory.initElements(Driver.getDriver(),
                        ChangeEmailAddressModal.class);
                SeleniumTest.click(changeEmailAddressModal.confirmChangesButton);
            }
            catch(NoSuchElementException nse) {
                // we don't care if we cannot find the confirm changes button
                // proceed with dismissing the dialog
                // another blind fix for firefox
            }
        }
        emailAddressChanged = false;
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static void clickEditLinkForCustomField(int customFieldID){
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath(
                "//*[@id='CustomField" + customFieldID + "_FormUserArea_1-deactivated']/a")));
    }

    /**
     * Clicks on Save Changes Button
     * @param className String representation of the Classname to return
     * @return Object representation of the class being returned
     */
    public static Object clickSaveChanges(String className) {
        //TODO take and return a class
        Object returnedClass = null;
        SeleniumTest.click(saveChangesButton);
        switch(className) {
            case "ChangeEmailAddressModal":
                 returnedClass = PageFactory.initElements(Driver.getDriver(), ChangeEmailAddressModal.class);
                break;
            case "EditProfileModal":
                returnedClass = PageFactory.initElements(Driver.getDriver(), EditProfileModal.class);
                break;
            default:
                // if you call this with a class and it's not a handled class, you'll need to add that case
                // returning false should through an error
                return false;
        }
        return returnedClass;
    }

    public static boolean isCustomFieldRequired(String fieldIndex) {
        try {
            return Driver.getDriver().findElement(
                    By.xpath("//div[3]/div/table/tbody/tr[" + fieldIndex + "]/th/span")).getText().equals("*");
        }
        catch (NoSuchElementException e)
        {
            return false;
        }
    }

    /**
     * Retuns the custom field locator
     * @param customFieldID 1 for first,2 for second, etc.
     * @return
     */
    public static By.ById getCustomFieldLocator(int customFieldID) {
        return new By.ById("CustomField" + customFieldID + "_FormUserArea_1");
    }

    /**
     * Retuns the custom field locator
     * @param customFieldID 1 for first,2 for second, etc
     * @param enabled true if it's enabled, false if it is not
     * @return
     */
    public static By.ById getCustomFieldLocator(int customFieldID, boolean enabled) {
        if (enabled) {
            return getCustomFieldLocator(customFieldID);
        } else {
            return new By.ById("CustomField" + customFieldID + "_FormUserArea_1-deactivated");
        }
    }

    /**
     * Sets the text for a text custom field
     * @param customFieldID
     * @param text
     */
    public static void setCustomFieldText(By.ById customFieldID, String text) {
        SeleniumTest.clearAndSetText(Driver.getDriver().findElement(customFieldID), text);
    }

    /**
     * Selects a value from a custom field dropdown
     * @param customFieldID
     * @param dropdownValue
     */
    public static void setCustomFieldDropdown(By.ById customFieldID, String dropdownValue) {
        new Select(Driver.getDriver().findElement(customFieldID)).selectByVisibleText(dropdownValue);
    }

    /**
     * Gets the text for a text custom field
     * @param customFieldID
     */
    public static String getCustomFieldText(By.ById customFieldID) {
        return Driver.getDriver().findElement(customFieldID).getText();
    }

    /**
     * Types alternate first name
     * @param alternateFName
     */
    public static void typeAlternateFirstName(int index, String alternateFName) {
        String firstNameID = "qfalias";
        SeleniumTest.waitForElementVisible(By.id(firstNameID + index));
        WebElement fNameTextBox = Driver.getDriver().findElement(By.id(firstNameID + index));
        SeleniumTest.clearAndSetText(fNameTextBox, alternateFName);
    }

    /**
     * Types alternate Middle name
     * @param alternateMName
     */
    public static void typeAlternateMiddleName(int index, String alternateMName) {
        String middleNameID = "qmalias";
        SeleniumTest.waitForElementVisible(By.id(middleNameID + index));
        WebElement mNameTextBox = Driver.getDriver().findElement(By.id(middleNameID + index));
        SeleniumTest.clearAndSetText(mNameTextBox, alternateMName);
    }

    /**
     * Types alternate Last name
     * @param alternateLName
     */
    public static void typeAlternateLastName(int index, String alternateLName) {
        String lastNameID = "qnalias";
        SeleniumTest.waitForElementVisible(By.id(lastNameID + index));
        WebElement lNameTextBox = Driver.getDriver().findElement(By.id(lastNameID + index));
        SeleniumTest.clearAndSetText(lNameTextBox, alternateLName);
    }

    /**
     * Clicks on Add Name link in Alternate Names section.
     */
    public static void clickAddNameLink() {
        SeleniumTest.click(addNameLink);
    }

    public static boolean isErrorMessageTextVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(missingRequiredFieldsErrorMessageLocator);
    }

    public static String getErrorMessageText() {
        return SeleniumTest.getTextByLocator(missingRequiredFieldsErrorMessageLocator);
    }

    public static void waitForEditProfileModalLoadingCompleted() {
        SeleniumTest.waitForPageLoadToComplete();
        WaitUntil.waitUntil(60, 3, () -> !Driver.getDriver().findElements(
                By.id("divEditProfileLoading")).get(0).isDisplayed(), NoSuchElementException.class);
    }

    public void setOrganization(String dropdownValue) {
        new Select(organization).selectByVisibleText(dropdownValue);
    }

    public static void waitForModalDialogDisappear(){
        SeleniumTest.waitForElementNotVisible(editProfileModal);
    }
}