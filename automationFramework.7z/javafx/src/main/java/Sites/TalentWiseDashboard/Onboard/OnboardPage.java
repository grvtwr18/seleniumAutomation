package Sites.TalentWiseDashboard.Onboard;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import Sites.TalentWiseDashboard.CustomerPortalPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by abrackett on 9/28/16.
 */
public class OnboardPage extends CustomerPortalPage {

    private static final Logger staticLogger = LoggerFactory.getLogger(OnboardPage.class);
    private static final By onboardingSubTabLocator = By.xpath(
            "//div[contains(@id, 'onboard.php')]");
    private static final By eVerifySubTabLocator = By.xpath(
            "//div[contains(@id, 'casemanagement.php')]");

    @FindBy(how = How.XPATH, using = "//div[@class='withitems']")
    private static WebElement subTabDiv;

    @FindBy(how = How.NAME,using = "qcandid")
    private static WebElement reportIDtextbox;

    @FindBy(how = How.XPATH, using = ".//*[contains(@onclick,'dbSearchClick')]")
    private static WebElement searchButton;

    @FindBy(how = How.XPATH, using = ".//*[@class='resultsgrid']//tr")
    private static List<WebElement> searchResultTable;

    static {
        PageFactory.initElements(Driver.getDriver(), OnboardPage.class);
    }

    public static void waitForPageToLoad() {
        WaitUntil.waitUntil(() ->
                subTabDiv.findElement(onboardingSubTabLocator)
                         .isDisplayed() &&
                subTabDiv.findElement(eVerifySubTabLocator)
                         .isDisplayed());
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static void clickOnboardingSubTab() {
        final WebElement subTab = subTabDiv.findElement(onboardingSubTabLocator);
        if(!subTab.getAttribute("class").contains("active")) {
            subTab.click();
        }
        OnboardingSubTab.waitForPageToLoad();
    }

    public static void clickEVerifySubTab() {
        final WebElement subTab = subTabDiv.findElement(eVerifySubTabLocator);
        if(!subTab.getAttribute("class").contains("active")) {
            subTab.click();
        }
        EVerifySubTab.waitForPageToLoad();
    }

    public static void searchReportID(String reportID)
    {
        SeleniumTest.clearAndSetText(reportIDtextbox,reportID);
        SeleniumTest.click(searchButton);
        SeleniumTest.waitForPageLoad();
    }

    public static String getFirstReportDetailsContaining(String str)
    {
        if(!searchResultTable.isEmpty())
        {
            for(int i=0;i<searchResultTable.size();i++)
            {
                List<WebElement> colHeader = searchResultTable.get(i).findElements(By.xpath("//th"));
                List<WebElement> colHeaderValue = searchResultTable.get(i).findElements(By.xpath("//td"));
                staticLogger.info("Table size with header "+colHeader.size());
                staticLogger.info("Table size with header value "+colHeaderValue);
                for(int j=0;j<colHeader.size();j++)
                {
                    if(colHeader.get(j).getText().contains(str))
                    {
                        staticLogger.info("Report status "+colHeaderValue.get(j+4).getText());
                        return colHeaderValue.get(j+4).getText();
                    }
                }
            }
        }
        return "error";
    }
}
