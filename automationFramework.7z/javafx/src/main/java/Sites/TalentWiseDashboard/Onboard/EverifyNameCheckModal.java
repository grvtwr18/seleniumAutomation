package Sites.TalentWiseDashboard.Onboard;

import TWFramework.WaitUntil;
import static WebDriver.Driver.getDriver;

import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * The modal displayed when you click "Manage Case" when viewing an E-Verify report in the dashboard,
 * when the E-Verify request is in the Pending Name Check status. This page object is not complete.
 */
public class EverifyNameCheckModal {

    // region First page
    @FindBy(how = How.XPATH, using = "//div[@id='divCaseModalAction']/button[1]")
    private static WebElement closeCaseButton;

    @FindBy(how = How.XPATH, using = "//input[@value='Close']")
    private static WebElement closeButton;
    // endregion

    // region Close Case page
    @FindBy(how = How.CSS, using = "#qemployed1Label")
    private static WebElement yesEmployedRadioButtonLabel;

    @FindBy(how = How.CSS, using = "#qemployed2Label")
    private static WebElement noEmployedRadioButtonLabel;
    @FindBy(how = How.ID , using = "qinvalidreasonyes0Label")
    private static WebElement  ChooseAppropriateStatment;

    // The labels for these buttons are messed up, so I only added the one that was needed right now. ONB-997 will hopefully be worked to fix the labels before others are needed.
    //@FindBy(how = How.XPATH, using = "//input[@id='qinvalidreasonyes0']/../label[2]")
   // private static WebElement yesReason1RadioButtonLabel;

    // endregion

    // region Result page
    @FindBy(how = How.CSS, using="#caseSuccess")
    private static WebElement resultSuccessMessage;

    @FindBy(how = How.CSS, using = "#caseModalActionContent")
    private static WebElement caseResult;

    @FindBy(how = How.ID, using = "confirmEmpNotifyLabel")
    private static WebElement iHaveNotNotifiedRadioLabel;

    @FindBy(how = How.ID, using = "confirmEmpNotify1Label")
    private static WebElement iHaveNotifiedRadioLabel;
    // endregion

    static {
        PageFactory.initElements(getDriver(), EverifyNameCheckModal.class);
    }

    public static void closeCase() {
        closeCaseButton.click();
    }


    public static void clickYesBecauseEmploymentAuth() {

        yesEmployedRadioButtonLabel.click();
        //yesReason1RadioButtonLabel.click();
        ChooseAppropriateStatment.click();
        closeCaseButton.click();

        WaitUntil.waitUntil(() -> {
            return resultSuccessMessage.isDisplayed();
        }, NoSuchElementException.class);

    }

    public static String getCaseResult() {
        return caseResult.getText();
    }


    public static void clickClose() {
        closeButton.click();
    }

    public static void chooseIHaveNotifiedEmployee() {
        iHaveNotifiedRadioLabel.click();
    }

    public static void chooseIHaveNotNotifiedEmployee() {
        iHaveNotNotifiedRadioLabel.click();
    }
}
