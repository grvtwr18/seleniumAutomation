package Sites.TalentWiseDashboard.Onboard;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import TWFramework.WaitUntil;
import WebDriver.Driver;

/**
 * Created by abrackett on 9/28/16.
 */
public class EVerifySubTab {

    @FindBy(how = How.CLASS_NAME, using = "title")
    private static WebElement pageTitle;


    static {
        PageFactory.initElements(Driver.getDriver(), EVerifySubTab.class);
    }

    public static void waitForPageToLoad() {
        WaitUntil.waitUntil(() -> pageTitle.getText().contains("E-Verify Case Management"));

    }
}
