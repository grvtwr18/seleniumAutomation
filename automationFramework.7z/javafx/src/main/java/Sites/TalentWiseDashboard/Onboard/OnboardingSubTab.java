package Sites.TalentWiseDashboard.Onboard;

import Sites.AdminConsole.atstools.SearchHelper;
import Sites.Site;
import Sites.TalentWiseDashboard.CancelModal;
import Sites.TalentWiseDashboard.CustomerDashboardPages;
import Sites.TalentWiseDashboard.EditTasksModal;
import Sites.TalentWiseDashboard.ProductFormPages.CancelFormI9Page;
import Sites.TalentWiseDashboard.ResendNotificationModal;
import Sites.TalentWiseDashboard.Search.Records.ViewReportPage;
import TWFramework.SeleniumTest;
import org.apache.commons.lang.SystemUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.io.FilenameFilter;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

/**
 * Created by abrackett on 9/28/16.
 */
public class OnboardingSubTab extends CustomerDashboardPages {

    private static final String OPEN_TASK_ID           = "open_task";
    private static final String VIEW_REPORT_ID         = "view_report";
    private static final String OPEN_PDF_ID            = "open_pdf";
    private static final String PRINT_REPORT_ID        = "print_report";
    private static final String RESEND_NOTIFICATION_ID = "resend_notifications";
    private static final String EDIT_TASKS_ID          = "edit_tasks";
    private static final String CANCEL_ID              = "cancel";

    @FindBy(how = How.CLASS_NAME, using = "title")
    private static WebElement pageTitle;

    @FindBy(how = How.XPATH, using = "//input[contains(@onclick,'dbSearchClick')]")
    private WebElement searchButton;

    @FindBy(how = How.ID, using = "aClearForm")
    private WebElement clearAllLink;

    static {
        PageFactory.initElements(Driver.getDriver(), OnboardingSubTab.class);
    }

    public static void waitForPageToLoad() {
        WaitUntil.waitUntil(() -> pageTitle.getText().contains("Search Onboarding"));
    }

    public static OnboardingSubTab initElements() {
        SeleniumTest.waitForPageLoadToComplete();
        return PageFactory.initElements(Driver.getDriver(), OnboardingSubTab.class);
    }

    public static OnboardingSubTab navigateTo() throws URISyntaxException {
        int userId = 0;
        URIBuilder builder = new URIBuilder(Driver.getDriver().getCurrentUrl());

        List<NameValuePair> queryParams =
                builder.getQueryParams();

        for(NameValuePair nvp : queryParams) {
            if (nvp.getName().equals("OverrideUserID")) {
                userId = Integer.parseInt(nvp.getValue());
            }
        }

        builder = new URIBuilder(Sites.URL.getURL(Site.CUSTOMER_DASHBOARD) + "/screening/onboard.php");
        if (userId > 0) {
            builder.setParameter("OverrideUserID", Integer.toString(userId));
        }
        Driver.getDriver().get(builder.toString());
        return initElements();
    }

    public OnboardingSubTab setValueInTextBox(String inputLabel, String value) {
        WebElement textBox = Driver.getDriver().findElement(By.xpath("//label[text()='"
                + inputLabel + "']/following-sibling::input"));
        SeleniumTest.clearAndSetText(textBox, value);
        return this;
    }

    public OnboardingSubTab clickSearch() {
        searchButton.click();
        SeleniumTest.waitForPageLoadToComplete();
        return this;
    }

    public static CustomerDashboardPages selectActionDropdown(int reportId, String visibleText) {

        WebElement actiondd = Driver.getDriver().findElement(By.xpath
                ("//select[contains(@id,'" + reportId + "')]"));
        actiondd.click();
        Select actionDropdown = new Select(actiondd);

        switch (visibleText) {

            case "View Report":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, VIEW_REPORT_ID);
                return PageFactory.initElements(Driver.getDriver(), ViewReportPage.class);

            case "Open PDF":
                // Establish the download folder
                File directory;

                if (SystemUtils.IS_OS_WINDOWS) {
                    directory = new File(System.getenv("USERPROFILE") + "/Downloads");
                } else {
                    directory = new File(System.getenv("HOME") + "/Downloads");
                }
                // Create a filename Filter to search for pdfs
                FilenameFilter filter = new FilenameFilter() {
                    @Override
                    public boolean accept(File directory, String name) {
                        return name.toLowerCase().endsWith(".pdf");
                    }
                };
                // Return the list of current pdf files in the directory
                File[] files = directory.listFiles(filter);
                // set the count
                int pdfFilesCount = files.length;
                // select Open PDF from the dropdown
                actionDropdown.selectByVisibleText(visibleText);
                // wait until a new pdf file is found in the download folder
                try {
                    WaitUntil.waitUntil(30, 2, () -> directory.listFiles(filter).length >
                            pdfFilesCount);
                } catch (TimeoutException toe) {
                    throw new RuntimeException("Failed to find the pdf");
                }
                // Return the NEW list of current pdf files in the directory
                File[] files2 = directory.listFiles(filter);
                // enumerate through the list and delete the newly found pdf
                for (File f : Arrays.asList(files2)) {
                    if (!Arrays.asList(files).contains(f)) {
                        f.delete();
                    }
                }

                return PageFactory.initElements(Driver.getDriver(), OnboardingSubTab
                        .class);

            case "Print Report":

                break;
            case "Resend Notifications":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, RESEND_NOTIFICATION_ID);
                PageFactory.initElements(Driver.getDriver(), ResendNotificationModal.class);
                ResendNotificationModal.closeResendNotification(OnboardingSubTab.class);
                // Hard wait for modal dialog to close - waiting on modal disappearing is not
                // working - waiting on elements to be present when themodal closes
                // does not work either.
                // TODO:  Fix this some day.
                SeleniumTest.defaultWaitForElementWithMultiplier(1);
                return PageFactory.initElements(Driver.getDriver(), OnboardingSubTab
                        .class);

            case "Edit Tasks":
                SeleniumTest.selectByPartialIdFromDropDown(actionDropdown, EDIT_TASKS_ID);
                return PageFactory.initElements(Driver.getDriver(), EditTasksModal.class);

            case "Cancel":

                SeleniumTest.selectByVisibleTextFromDropDown(actionDropdown, "Cancel");
                SeleniumTest.waitForPageLoadToComplete();
                if (!CancelFormI9Page.onPage()) {
                    PageFactory.initElements(Driver.getDriver(), CancelModal.class);
                    CancelModal.clickConfirm(OnboardingSubTab.class);
                    return PageFactory.initElements(Driver.getDriver(), OnboardingSubTab
                            .class);
                } else {
                    return PageFactory.initElements(Driver.getDriver(), CancelFormI9Page.class);
                }

            case "Cancel I-9":
                SeleniumTest.selectByVisibleTextFromDropDown(actionDropdown, "Cancel");
                return PageFactory.initElements(Driver.getDriver(), CancelFormI9Page.class);

            default:
                return PageFactory.initElements(Driver.getDriver(), OnboardingSubTab
                        .class);
        }
        return PageFactory.initElements(Driver.getDriver(), OnboardingSubTab
                .class);
    }
    public OnboardingSubTab clickClearAllLink() {
        clearAllLink.click();
        SeleniumTest.waitForPageLoadToComplete();
        return this;
    }
}
