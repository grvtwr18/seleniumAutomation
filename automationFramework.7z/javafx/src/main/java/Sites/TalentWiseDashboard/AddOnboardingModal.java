package Sites.TalentWiseDashboard;

import Data.locations.us.UsStateTerritory;
import Sites.TalentWiseDashboard.ProductFormPages.ElectronicI9LaunchPage;
import Sites.TalentWiseDashboard.ProductFormPages.FormReviewFormSet87253999Page;
import Sites.TalentWiseDashboard.ProductFormPages.ProductFormPages;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;

import static WebDriver.Driver.getDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;

/**
 * Created by abrackett on 9/14/2015.
 */
public class AddOnboardingModal extends AddPackageModal {
    private static final String VISIBLE_STARTDATE = "dp_qstartdate";
    private static final String HIDDEN_STARTDATE = "qstartdate";

    private static final By modalOnboardingQuickLaunchHeadLocator = new By.ById("divQuickLaunchModalOnboardHead");
    private static final By modalOnboardingHeadLocator = new By.ById("divLaunchOnboardingHead");

    @FindBy(how = How.CSS, using = "div#divLaunchOnboardingContent > .modalWindowContent > .padTwenty > .stripe > p")
    private static WebElement errorMessageLocator;

    @FindBy(how = How.CSS, using = "h3")
    private static WebElement headerLocator;

    @FindBy(how = How.CSS, using = "div.stripe>p")
    private static WebElement paragraphLocator;

    @FindBy(how = How.CSS, using = "p>label")
    private static WebElement rehireDateLabel;

    @FindBy(how = How.XPATH, using = "//button[text()='Continue']")
    private static WebElement continueBtn;

    @FindBy(how = How.XPATH, using = "//input[contains(@value,'Continue')]")
    private static WebElement continueLaunchRehireButton;

    @FindBy(how = How.XPATH, using = "//*[@id='divLaunchOnboardingContent']/div[3]/button")
    private static WebElement continueBtnOnRehireEFormI9Page;

    @FindBy(how = How.CSS, using = "div[class='dbAlertColor']")
    private static WebElement modalAlertMessage;

    @FindBy(how = How.NAME, using = "qStateOfWork")
    private static WebElement stateOfWorkDropdown;

    @FindBy(how = How.ID, using = "divQuickLaunchModalOnboardContent")
    private static WebElement addOnboardingModalContent;

    @FindBy(how = How.XPATH, using = "//input[@value='Launch I-9']")
    private static WebElement btnLaunchI9;

    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View existing report.')]")
    private static WebElement lnkViewExistingReport;

    private static final Logger logger = LoggerFactory.getLogger("Sites.CustomerDashboardPages.Records.CandidateDetailsPage.AddOnboarding Modal");

    static {
        PageFactory.initElements(getDriver(), AddOnboardingModal.class);
    }

    public static void waitForPageToLoad() {
        try {
            WaitUntil.waitUntil(() -> getDriver().findElement(By.xpath("//h1[@class='flushTop']" +

                    "[contains(text(),'Launch')]" +
                    "[contains(text(),'Onboard')]")) != null, NoSuchElementException.class);
            // the line below didn't work when launching from the candidate details page
            // leaving it in in case the line breaks somewhere else
            // and we need to have multiple versions of the waitForPageToLoad
            //           "[contains(text(),'Onboard')]")).isDisplayed(), NoSuchElementException.class);
        } catch (TimeoutException toe) {
            throw new TimeoutException("Add Onboarding Modal is not open");
        }
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static boolean isSelectStateOfWorkDropdownPresent() {
        return SeleniumTest.isElementVisible(stateOfWorkDropdown);

    }

    /**
     * Sets the state of work for the candidate
     *
     * @param state The state where the candidate will be working
     */
    public static void selectStateOfWork(UsStateTerritory state) {
        SeleniumTest.selectByVisibleTextFromDropDown(stateOfWorkDropdown, state.getFullName());
    }

    public static void selectLaunchI9(){
        if(btnLaunchI9.isDisplayed()){
            btnLaunchI9.click();
        }
    }
    /**
     * Returns the error message displayed on Add Onboarding modal.
     */
    public static String getErrorMessage() {
        return errorMessageLocator.getText();
    }


    /**
     * Returns the rehire Electronic I-9 Form text.
     */
    public static String getParagraph() {
        return paragraphLocator.getText();
    }

    /**
     * Returns the label corresponding to the Rehire date text box.
     */
    public static String getRehireDateLabel() {
        return rehireDateLabel.getText();
    }

    /**
     * Clicks the onboarding uberform by index
     */
    public Object clickOnboardingUberform(Integer uberFormIndex) {
        String uberFormText = getDriver().findElement(By.xpath("//div[" + uberFormIndex + "]/div[2]/h2/a")).getText();
        WebElement uberFormButton = getDriver().findElement(By.xpath("//div[" + uberFormIndex + "]/div[3]/div/a/button"));
        uberFormButton.click();
        Object theReturnValue;
        switch (uberFormText) {
            case "Form Review FormSet 87253999":
                theReturnValue = PageFactory.initElements(getDriver(), FormReviewFormSet87253999Page.class);
                break;
            default:
                theReturnValue = null;
                break;
        }
        return theReturnValue;

    }

    public static ElectronicI9LaunchPage clickOnboardingEverifyUberform(Integer uberFormIndex) {
        getDriver().findElement(By.xpath("//*[@id=\"btncustom_" + uberFormIndex + "_1\"]")).click();
        return PageFactory.initElements(getDriver(), ElectronicI9LaunchPage.class);
    }

    /**
     * Clicks the onboarding uberform by name
     *
     * @param uberFormName  the name of the uberform to launch
     * @param returnedClass the Page Factory class to be returned
     */
    public static ProductFormPages clickOnboardingUberform(String uberFormName, Class<? extends ProductFormPages> returnedClass) {
        logger.info("Launching uberform");
        clickUberForm(uberFormName);
        return PageFactory.initElements(getDriver(), returnedClass);
    }

    /**
     * Clicks the onboarding uberform but still remain on Add Onboarding modal.
     */
    public static AddOnboardingModal launchRehireToGoToAddOnboardingModal(String uberFormName) {
        getDriver().findElement(By.xpath("//a[contains(text(), '" + uberFormName + "')]/../../following-sibling::div/div/*")).click();
        return PageFactory.initElements(getDriver(), AddOnboardingModal.class);
    }

    /**
     * Clicks on Uber Form name in add onboarding modal.
     * TODO: this probably duplicates something in AddScreeningModal. Might be better in parent.
     *
     * @param uberFormName
     */
    public static void clickUberForm(String uberFormName) {
        WebElement dialog = Driver.getDriver().findElement(
                By.xpath("//div[@class='modalWindowContent']"));

        WebElement launchButton = dialog.findElement(By.xpath(".//a[contains"
                + "(text()"
                + ", '" +
                uberFormName + "')"
                + "]/../../following-sibling::div/div/*"));
        SeleniumTest.waitForElementVisible(launchButton);
        launchButton.click();

        // explicit wait to ensure whatever page is supposed to open has the time to do so before returning
        SeleniumTest.waitForElementVisible(Driver.getDriver()
                .findElement(
                        By.xpath(
                                "//h1[contains(text(), '"
                                        + uberFormName.trim()
                                        + "')]")));
        // Set up a loop to try to click the element multiple times until FireFox figures out that the click happened
        // adding a counter to ensure this loop does not go beyond 5 times incase something goes way awry and it never ends.
        // Scared to remove this counter at the moment do not have time to verify test cases
        // still work if this is removed - leaving for now.
        int counter = 0;
        while (counter < 5) {
            try {

                if (Driver.getDriver().findElement(By.xpath("//h1[contains(text(), '" +
                        uberFormName.trim() + "')]")).isDisplayed
                        ()) {
                    break;
                }
            } catch (NoSuchElementException nse) {
                // we don't care
            }
            counter++;
            dialog.findElement(By.xpath(".//a[contains"
                    + "(text()"
                    + ", '" +
                    uberFormName.trim() + "')"
                    + "]/../../following-sibling::div/div/*"))
                    .click();

            SeleniumTest.waitForElementVisible(Driver.getDriver().findElement(By.xpath("//h1[contains(text(), '" + uberFormName + "')]")));
        }
    }

    /**
     * Types due date in Rehire Start date field.
     */
    public static Boolean typeEmployeeRehireStartDate(LocalDate localDate) {
        SeleniumTest.waitForElementToBeClickable(rehireDateLabel, SeleniumTest.FLUENTWAIT_TIMEOUT);
        SeleniumTest.waitMs(2000);
        try {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(localDate, VISIBLE_STARTDATE, HIDDEN_STARTDATE);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException nse) {
            return false;
        }
    }

    /**
     * Click on Continue button.
     */
    public static ProductFormPages clickContinue(Class<? extends ProductFormPages> returnedClass) {
        if (SeleniumTest.isElementVisible(continueBtn)) {
            continueBtn.click();
        } else {
            getDriver().findElement(By.xpath("//input[contains(@value,'Continue')]")).click();
        }
        return PageFactory.initElements(getDriver(), returnedClass);
    }

    /**
     * Click on Continue button.
     */
    public static AddOnboardingModal clickContinueBtnToRemainOnAddOnboardingPage() {
        //TODO investigate move wait until into ctor
        WaitUntil.waitUntil(() -> continueBtn.isDisplayed());
        continueBtn.click();
        return PageFactory.initElements(getDriver(), AddOnboardingModal.class);
    }

    /**
     * Click on Continue button on Rehire Add Onboarding Modal.
     */
    public static AddOnboardingModal clickContinueBtnOnRehire() {
        //TODO investigate move wait until into ctor
        WaitUntil.waitUntil(() -> continueBtnOnRehireEFormI9Page.isDisplayed());
        continueBtnOnRehireEFormI9Page.click();
        return PageFactory.initElements(getDriver(), AddOnboardingModal.class);
    }

    /**
     * Click on Continue button on Rehire Add Onboarding Modal, and returns passed ProductFormPages
     * returnedClass.
     */
    public static ProductFormPages clickContinueBtnOnRehire(Class<? extends ProductFormPages> returnedClass) {
        WaitUntil.waitUntil(() -> continueBtnOnRehireEFormI9Page.isDisplayed());
        continueBtnOnRehireEFormI9Page.click();
        return PageFactory.initElements(getDriver(), returnedClass);
    }


    /**
     * Clicks the onboarding uberform by name
     *
     * @param uberFormName  the name of the uberform to launch
     * @param returnedClass the Page Factory class to be returned
     */
    public static ProductFormPages launchUberform(String uberFormName, Class<? extends ProductFormPages> returnedClass) {
        clickUberForm(uberFormName);
        return PageFactory.initElements(getDriver(), returnedClass);
    }

    /**
     * Clicks on the launch button corresponding to the formset name.
     */
    public static ProductFormPages clickLaunchButton(String formSetName, Class<? extends ProductFormPages> returnClass) {
        clickLaunchButton(formSetName);
        return PageFactory.initElements(getDriver(), returnClass);
    }

    /**
     * Overload to clicks on the launch button corresponding to the formset name.
     */
    public static void clickLaunchButton(String formSetName) {
        getDriver().findElement(By.xpath("//a[contains(text(),'" + formSetName + "')]/../../following-sibling::div/div/*")).click();
        staticlogger.info("Add Onboarding Modal:  Click Launch Button for {}", formSetName);
    }

    /**
     * Clicks on the launch button corresponding to the formset name.
     */
    public static CustomerDashboardPages clickLaunchButtonToRemainOnModal(String formSetName, Class<? extends CustomerDashboardPages> returnClass) {
        WebElement launchButton = getDriver().findElement(By.xpath("//a[contains(text(),'" + formSetName + "')]/../../following-sibling::div/div/*"));
        launchButton.click();
        return PageFactory.initElements(getDriver(), returnClass);
    }

    /**
     * Clicks on the launch button corresponding to the formset name and returns string of displayed
     * message.
     */
    public static String clickLaunchButtonToRemainOnModalAndGetMessage(String formSetName) {
        WebElement launchButton = getDriver().findElement(By.xpath("//a[contains(text(),'" + formSetName + "')]/../../following-sibling::div/div/*"));
        launchButton.click();
        return getErrorMessage();
    }

    /**
     * Click on Continue button.
     */
    public static AddOnboardingModal clickContinueBtnOnRehireEFormI9Page() {
        continueBtnOnRehireEFormI9Page.click();
        SeleniumTest.waitForElementToBeClickable(continueLaunchRehireButton, SeleniumTest.FLUENTWAIT_TIMEOUT);
        return PageFactory.initElements(getDriver(), AddOnboardingModal.class);
    }

    /**
     * Clicks the last continue button immediately before launch - causes Launch form to be exposed
     *
     * @param returnedClass The specific rehire Launch form you expect to use
     * @return Initializes the expected Rehire launch form - 788 or 650
     */
    public static ProductFormPages clickContinueButtonToLaunchI9Form(Class<? extends ProductFormPages> returnedClass) {
        continueLaunchRehireButton.click();
        return PageFactory.initElements(getDriver(), returnedClass);
    }

    /**
     * click continue, if alert is present return before wait, otherwise return after wait as normal.
     *
     * @return
     */
    public static AddOnboardingModal clickContinueCheckForAlert() {
        continueBtnOnRehireEFormI9Page.click();

        //TODO investigate rolling this into similar existing methods
        if (SeleniumTest.isElementPresent(modalAlertMessage)) {
            logger.info("Alert found on continue.");
            return PageFactory.initElements(getDriver(), AddOnboardingModal.class);
        }

        SeleniumTest.waitForElementToBeClickable(continueBtn, SeleniumTest.FLUENTWAIT_TIMEOUT);
        return PageFactory.initElements(getDriver(), AddOnboardingModal.class);
    }

    /**
     * returns true if Modal Alert Message is Displayed
     *
     * @return
     */
    public static boolean isModalAlertMessageDisplayed() {
        return modalAlertMessage.isDisplayed();
    }

    /**
     * returns Modal ALert Message Text.
     *
     * @return
     */
    public static String getModalAlertMessageText() {
        return modalAlertMessage.getText();
    }

    /**
     * returns true if Modal Alert Message is present.
     *
     * @return
     */
    public static boolean isModalAlertMessagePresent() {
        return SeleniumTest.isElementPresent(modalAlertMessage);
    }

    public static void clickContinue() {
        continueBtn.click();
    }

    /**
     * Clicks passed formName <Launch> button from Quick Launch Drop Down AddOnboarding Modal, and returns passed returnClass.
     *
     * @param formName
     * @param returnClass
     * @return
     */
    public static ProductFormPages clickFormLaunchButtonFromQuickLaunchDropDown(String formName, Class<? extends ProductFormPages> returnClass) {
        //TODO find a better way to accomplish this wait dynamically.
        SeleniumTest.defaultWaitForElementWithMultiplier(.5);
        WaitUntil.waitUntil(() -> addOnboardingModalContent.isDisplayed());
        WebElement formElement = addOnboardingModalContent.findElement(By.xpath(".//h2/a[contains(text(), '" + formName + "')]/../../following-sibling::div"));
        WebElement formButton = formElement.findElement(By.xpath(".//button"));
        formButton.click();
        return PageFactory.initElements(getDriver(), returnClass);
    }
}
