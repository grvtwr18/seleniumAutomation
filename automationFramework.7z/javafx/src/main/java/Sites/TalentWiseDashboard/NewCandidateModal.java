package Sites.TalentWiseDashboard;

import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by abrackett on 9/14/2015.
 */
public class NewCandidateModal {
    private WebDriverWait wait;
    public Candidate candidate;
    private static final Logger staticLogger = LoggerFactory
            .getLogger(NewCandidateModal.class.getName());



    static {
        PageFactory.initElements(Driver.getDriver(), NewCandidateModal.class);
    }
    /**
     * Constructs a new Candidate Modal page object.
     */
    public NewCandidateModal(){
        this.wait       = new WebDriverWait(Driver.getDriver(), 10);
    }

    public static void waitForReady() {
        SeleniumTest.waitForElementNotVisible(By.id("divQuickLaunchModalNewCandidateLoading"));
    }

    public static WebElement getModal() {
        return Driver.getDriver().findElement(By.id("divQuickLaunchModalNewCandidate"));
    }

    /**
     * Types the Candidate Firstname into the First Name box
     * @param firstName String representing the candidate first name
     */
    public void typeFirstName(String firstName){
        String locatorText = "qf";
        WebElement firstNameBox = Driver.getDriver().findElement(By.id(locatorText));
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
        staticLogger.info("Create Candidate:  First Name set to {}", firstName);
    }

    /**
     * Retrieves the first name found in the firstName box
     * @return String representation of the firstName
     */
    public String getFirstName(){
        String locatorText = "qf";
        WebElement firstNameBox = Driver.getDriver().findElement(By.id(locatorText));
        return firstNameBox.getAttribute("value");
    }

    /**
     * Types the Candidate Middlename into the Middle Name box
     * @param middleName String representing the candidate middle name
     */
    public void typeMiddleName(String middleName){
        String locatorText = "qmi";
        WebElement middleNameBox = Driver.getDriver().findElement(By.id(locatorText));
        SeleniumTest.clearAndSetText(middleNameBox, middleName);
        staticLogger.info("Create Candidate:  Middle Name set to {}", middleName);
    }

    /**
     * Retrieves the middle name found in the middleName box
     * @return String representation of the Middle name
     */
    public String getMiddleName(){
        String locatorText = "qmi";
        WebElement middleNameBox = Driver.getDriver().findElement(By.id(locatorText));
        return middleNameBox.getAttribute("value");
    }

    /**
     * Types the Candidate Lastname into the Last Name box
     * @param lastName String representing the candidate last name
     */
    public void typeLastName(String lastName){
        String locatorText = "qn";
        WebElement lastNameBox = Driver.getDriver().findElement(By.id(locatorText));
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
        staticLogger.info("Create Candidate:  Last Name set to {}", lastName);
    }

    /**
     * Retrieves the last name found in the lastName box
     * @return String representation of the last name
     */
    public String getLastName(){
        String locatorText = "qn";
        WebElement lastNameBox = Driver.getDriver().findElement(By.id(locatorText));
        return lastNameBox.getAttribute("value");
    }

    /**
     * Types the email into the Email Address box
     * @param email String representing the candidate's email address
     */
    public void typeEmailAddress(String email){
        String locatorText = "qee";
        WebElement emailAddressBox = Driver.getDriver().findElement(By.name(locatorText));
        SeleniumTest.clearAndSetText(emailAddressBox, email);
        staticLogger.info("Create Candidate:  email address set to {}", email);
    }

    public  void selectRefLongNamCodeOne(String RefLongNamCodeOne){
        String locatorText = "candidaterefcodeadd_1";
        WebElement refLongNamCodeOneDropDown = Driver.getDriver().findElement(By.id(locatorText));
        SeleniumTest.selectByVisibleTextFromDropDown(refLongNamCodeOneDropDown, RefLongNamCodeOne);
        staticLogger.info("Create Candidate: reference code set to {}", RefLongNamCodeOne);
    }

    public void selectRefCodeLongNamTwo(String RefCodeLongNamTwo){
        String locatorText = "candidaterefcodeadd_2";
        WebElement RefCodeLongNamTwoDropDown = Driver.getDriver().findElement(By.id(locatorText));
        SeleniumTest.selectByVisibleTextFromDropDown(RefCodeLongNamTwoDropDown, RefCodeLongNamTwo);
        staticLogger.info("Create Candidate: reference code set to {}", RefCodeLongNamTwo);
    }

    public void selectRefCodeThree(String RefCodeThree){
        String locatorText = "candidaterefcodeadd_3";
        WebElement RefCodeThreeDropDown = Driver.getDriver().findElement(By.id(locatorText));
        SeleniumTest.selectByVisibleTextFromDropDown(RefCodeThreeDropDown, RefCodeThree);
        staticLogger.info("Create candidate: reference code set to {}", RefCodeThree);
    }

    public void selectThreeRefCodes(String refcodeOne,String refcodeTwo, String refcodeThree){
        String ref1LocatorText = "refcodehierarchy_1";
        WebElement RefCodeOneDropDown = Driver.getDriver().findElement(By.id(ref1LocatorText));
        SeleniumTest.selectByVisibleTextFromDropDown(RefCodeOneDropDown, refcodeOne);
        staticLogger.info("Create candidate: reference code set to {}", refcodeOne);
        String ref2LocatorText = "refcodehierarchy_2";
        WebElement RefCodeTwoDropDown = Driver.getDriver().findElement(By.id(ref2LocatorText));
        SeleniumTest.selectByVisibleTextFromDropDown(RefCodeTwoDropDown, refcodeTwo);
        staticLogger.info("Create candidate: reference code set to {}", refcodeTwo);
        String ref3LocatorText = "refcodehierarchy_3";
        WebElement RefCodeThreeDropDown = Driver.getDriver().findElement(By.id(ref3LocatorText));
        SeleniumTest.selectByVisibleTextFromDropDown(RefCodeThreeDropDown, refcodeThree);
        staticLogger.info("Create candidate: reference code set to {}", refcodeThree);

    }
    /**
     * Selects the Position as shown in the drop down list
     * @param positionName String representation of the position you intend to select
     */
    public void selectPosition(String positionName)
    {
        String locatorText = "qpositionid";
        SeleniumTest.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By.id(locatorText)), positionName);
        staticLogger.info("Create Candidate:  Position {} selected", positionName);
    }

    /**
     * Integer representing CandidateID initialized to -1 until populated
     */
    public Integer candidateID = -1;
    /**
     * Clicks the "close" link at the top right of the modal
     */
    public void clickCloseModal(){
        String locatorText = "(//a[contains(text(),'Close')])[3]";
        WebElement closeLink = Driver.getDriver().findElement(By.xpath(locatorText));
        closeLink.click();
        staticLogger.info("Create Candidate:  Click Close");
    }

    /**
     * Clicks the "cancel" Button at the bottom right of the modal
     */
    public void clickCancelModalButton(){
        String locatorText = "//input[@value='Cancel']";
        WebElement cancelButton = Driver.getDriver().findElement(By.xpath(locatorText));
        cancelButton.click();
        staticLogger.info("Create Candidate:  Click Cancel");
    }

    /**
     * Clicks the Create Candidate Button
     * @return String representation of the
     */
    public CandidateDetailsPage clickCreateCandidateButton(){
        String locatorText = "//input[@value='Create Candidate']";
        WebElement createCandidateButton = Driver.getDriver().findElement(By.xpath(locatorText));
        String firstName = getFirstName();
        String middleName = getMiddleName();
        String lastName = getLastName();
        createCandidateButton.click();
        staticLogger.info("Create Candidate:  Click Create Candidate");
        WebElement candidateIDElement;
        // locator is failing when run in jenkins - updating to be more robust and report
        // with a RunTimeException when the Candidate is not properly created
        try {
            // Explicitly waiting for a longer period of time than the default timeout
            // hoping this helps the lab situation by giving enough time
            // before bailing on the candidate creation.
            WaitUntil.waitUntil(SeleniumTest.waitForElementTimeout *2, 2, () ->
                            Driver.getDriver().findElement(By.xpath(
                                    "//th[text()='Candidate ID']/following-sibling::td")).isDisplayed(),
                    NoSuchElementException.class);

            candidateIDElement = Driver.getDriver().findElement(By.xpath(
                    "//th[text()='Candidate ID']/following-sibling::td"));

            candidateID = Integer.parseInt(candidateIDElement.getText());

            this.candidate.setCandidateID(candidateID);

        } catch (TimeoutException toe) {
            throw new RuntimeException("Unable to confirm Candidate creation, did not find Candidate ID");
        }

        CandidateDetailsPage cdPage = PageFactory.initElements(Driver.getDriver(), CandidateDetailsPage.class);
        return cdPage;
    }

    /**
     * Creates a new candidate using all parameters for the New Candidate Modal Dialog
     * @param firstName String representation of the candidate First Name
     * @param middleName String representation of the Candidate Middle Name
     * @param lastName String representation of the Candidate Last Name
     * @param email String representation of the Candidate e-mail address
     * @param position CandidateDetailsPage class
     */
    public CandidateDetailsPage createNewCandidate(
            String firstName,
            String middleName,
            String lastName,
            String email,
            String position
    ){
        typeFirstName(firstName);
        typeMiddleName(middleName);
        typeLastName(lastName);
        typeEmailAddress(email);
        if(null != position && position != "")
            selectPosition(position);

        this.candidate = new Candidate();
        this.candidate.setFirstName(firstName);
        this.candidate.setMiddleName(middleName);
        this.candidate.setLastName(lastName);
        this.candidate.setEmailAddress(email);

        return clickCreateCandidateButton();
    }

    public CandidateDetailsPage createNewCandidateWithReferenceCodes(
            String firstName,
            String lastName,
            String email,
            String refLongNameCodeOne,
            String refCodeLongNamTwo,
            String refCodeThree


    ){
        typeFirstName(firstName);
        typeLastName(lastName);
        selectRefLongNamCodeOne(refLongNameCodeOne);
        selectRefCodeLongNamTwo(refCodeLongNamTwo);
        selectRefCodeThree(refCodeThree);
        typeEmailAddress(email);


        this.candidate = new Candidate();
        this.candidate.setFirstName(firstName);
        this.candidate.setLastName(lastName);
        this.candidate.setEmailAddress(email);

        return clickCreateCandidateButton();
    }

    /**
     * Supporting method to retrieve the CandidateID once a new candidate is created
     * @param firstName String representation of the complete firstName
     * @param middleName String representation of the complete middleName
     * @param lastName String representation of the complete lastName
     * @return Integer representing the generated CandidateID
     */
//    private Integer getCandidateID(String firstName, String middleName, String lastName){
//        DbReader myReader = new DbReader();
//        List<HashMap<String, Object>> candidateIDList =
//                myReader.executeQuery(
//                        "TalentWise",
//                        "SELECT `CandidateID` FROM `Candidate` WHERE `GivenName` = '" +
//                                firstName +
//                                "' AND `MiddleName` = '" +
//                                middleName +
//                                "' AND `FamilyName` = '" +
//                                lastName +
//                                "' ORDER BY `CandidateID` LIMIT 0 , 1");
//        return Integer.parseInt(((HashMap) candidateIDList.get(0)).get("CandidateID").toString());
//    }
}
