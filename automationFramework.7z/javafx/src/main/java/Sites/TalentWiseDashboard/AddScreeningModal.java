package Sites.TalentWiseDashboard;

import Sites.AdminConsole.Helpers.Header;
import Sites.TalentWiseDashboard.Helpers.Footer;
import Sites.TalentWiseDashboard.ProductFormPages.ProductFormPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jpflager on 10/27/2015.
 */
public class AddScreeningModal extends AddPackageModal {

    public Sites.TalentWiseDashboard.Helpers.Header header;
    public Footer footer;

    @FindBy(how = How.XPATH, using = "//img[@alt='Add Additional Criminal County Search + NY/VT/ME Fees']")
    private  WebElement AdditinalcountyLink;

    @FindBy(how = How.XPATH, using = "//img[@alt='Add Education Verification']")
    private static WebElement AdditinalcountyLinkforEducation;

    @FindBy(how = How.XPATH, using = "//img[@alt='Add Employment Verification']")
    private static WebElement AdditinalcountyLinkforEmployment;

    @FindBy(how = How.XPATH, using = "//img[@alt='Add Reference Check']")
    private static WebElement AdditinalcountyLinkforReference;

    /**
     * Clicks on the launch button corresponding to the formset name.
     * TODO: this probably duplicates something in AddOnboardingModal. Might be better in parent.
     * @param formSetName Name of the uber formset
     */
    public static ProductFormPages clickLaunchButton(String formSetName, Class<? extends ProductFormPages> returnClass) {
        SeleniumTest.click(By.xpath("//div[@class='productcolumn']/h2/a[contains(text(),'"
                + formSetName + "')]/../../following-sibling::div/div/a/button"));
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Clicks on the Ticket button corresponding to the formset name.
     * @param formSetName Name of the uber formset
     */
    public static ProductFormPages clickTicketButton(String formSetName, Class<? extends ProductFormPages> returnClass) {
        SeleniumTest.click(By.xpath("//div[@class='productcolumn']/h2/a[contains(text(),'"
                + formSetName + "')]/../../following-sibling::div/div/a[2]/button"));
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /*
     * @param uberFormID
     */
    public static void clickTicketButton(String uberFormID) {
        By ticketButton = By.xpath("//*[@id='ticket_" + uberFormID + "_1']");
        SeleniumTest.click(ticketButton);
        SeleniumTest.waitForPageLoad();
    }

    /*
    *Clicks on the Add Additonal county search link
     */
    public void clickAddAdditonalLink() {
        SeleniumTest.click(AdditinalcountyLink);
        SeleniumTest.waitForPageLoad();
    }

     /*
    *Clicks on the Add Additonal Education section link
     */
    public static void clickAddAdditonalEducationLink() {
        SeleniumTest.click(AdditinalcountyLinkforEducation);
        SeleniumTest.waitForPageLoad();
    }

    public static void clickAddAdditonalReferenceLink() {
        SeleniumTest.click(AdditinalcountyLinkforReference);
        SeleniumTest.waitForPageLoad();
    }

    public static void clickAddAdditonalEmploymentLink() {
        SeleniumTest.click(AdditinalcountyLinkforEmployment);
        SeleniumTest.waitForPageLoad();
    }

    /**
     * Wait for quick launch screening modal dialog loaded completely
     */
    public static void waitForReady() {
        SeleniumTest.waitForElementNotVisible(By.id("divQuickLaunchModalScreenLoading"));
    }
}
