package Sites.TalentWiseDashboard;

import Data.testdata.UserLogin;
import Sites.Site;
import Sites.TalentWiseDashboard.Dashboard.DashboardPage;
import Sites.TalentWiseDashboard.Enums.AccountType;
import Sites.TalentWiseDashboard.SterlingOneAdmin.ChangePasswordPage;
import Sites.URL;
import TWFramework.JavaScriptHelper;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import com.sun.jna.platform.win32.Advapi32Util;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Page object that represents the login page for the TalentWise website (Ex. "https://talentwise.dvm-eelefson1.sea.talentwise.com/screening/login.php").
 * @author eelefson
 * @author ssmith
 */
public class CustomerLoginPage {

    private static final Logger logger = LoggerFactory.getLogger(CustomerLoginPage.class);

    private static final String LOGIN_URL = "/screening/login.php";

    @FindBy(how = How.CSS, using = "div#dbIdLogin div.title")
    private WebElement signInText;
    private static final String SIGN_IN_TO_STERLINGONE_EXPECTED_TEXT = "Sign in to SterlingONE";

    @FindBy(how = How.ID, using = "loginNote")
    private WebElement loginNote;
    private static final String LOGIN_NOTE_EXPECTED_TEXT =
            "TalentWise is now SterlingONE!\n"
            + "Enjoy the same streamlined experience and all of the screening and hiring benefits that you and your "
            + "candidates have come to know and trust.\n"
            + "Please use your email address and password to access your personal dashboard. From there, you can run "
            + "employment or background checks, request a drug test, initiate onboarding, view reports, check "
            + "statements and invoices, and more.";

    private static final String TALENTWISE_IS_NOW_STERLING_ONE_LOCATOR = "TalentWise is now SterlingONE!";

    private static final String ENJOY_THE_SAME_STREAMLINED_LOCATOR =
            "Enjoy the same streamlined experience and all of the screening and hiring benefits that you and your "
            + "candidates have come to know and trust.";
    private static final String PLEASE_USE_YOUR_EMAIL_LOCATOR =
            "Please use your email address and password to access your personal dashboard.  From there, you can run "
            + "employment or background checks, request a drug test, initiate onboarding, view reports, check "
            + "statements and invoices, and more.";

    @FindBy(how = How.XPATH, using = "//*[@id=\"dbIdLogin\"]/div/div")
    private WebElement areYouNewText;
    private static final String ARE_YOU_NEW_EXPECTED_TEXT = "New customer?";

    @FindBy(how = How.XPATH, using = "//*[@id=\"dbIdLogin\"]/div")
    private WebElement newUserNote;
    private static final String NEW_USER_NOTE_EXPECTED_TEXT =
            "New customer?\n"
            + "Kennect by Sterling Talent Solutions offers fast, reliable background screening for small businesses "
            + "and household employers.  Get started now!";

    @FindBy(how = How.XPATH, using = "//td[@class='logoCell']/a/img")
    private WebElement companyLogo;

    @FindBy(how = How.ID, using = "newcust_0")
    private WebElement iHaveAccountRadioButton;

    //TODO when GL-204 is done, these needs  IDs
    @FindBy(how = How.XPATH, using = "//div[@class='member']/a[text()='Sign In']")
    private WebElement signInLink;
    private static final String SIGN_IN_LINK_EXPECTED_LINK_TEXT = "Sign In";

    @FindBy(how = How.XPATH, using = "//div[@class='member']/a[text()='New Account']")
    private WebElement newAccountLink;
    private static final String NEW_ACCOUNT_LINK_EXPECTED_LINK_TEXT = "New Account";

    @FindBy(how = How.CLASS_NAME, using = "contacttext")
    private WebElement yourCustomerSupportTeamLabel;
    private static final String YOUR_CUSTOMER_SUPPORT_TEAM_LABEL_EXPECTED_TEXT =
            "Your Customer Support Team:";

    @FindBy(how = How.CLASS_NAME, using = "contactphone")
    private WebElement customerSupportPhoneNumber;
    // TODO: determine how this varies by account
    private static final String CUSTOMER_CUPPORT_EXPECTED_PHONE_NUMBER = "1.877.982.9888";

    @FindBy(how = How.XPATH, using = "//td[@class='contactemail']/a")
    private WebElement contactEmail;
    private static final String CONTACT_EMAIL_EXPECTED_ADDRESS =
            "mailto:customersupport@talentwise.com";

    @FindBy(how = How.CLASS_NAME, using = "//td[@class='contactemail']/a/img")
    private WebElement contactEmailIcon;

    private static final String EMAIL_BOX_NAME = "EmailAddr";
    @FindBy(how = How.NAME, using = EMAIL_BOX_NAME)
    private WebElement emailBox;

    @FindBy(how = How.CSS, using = "label[for='EmailAddr']")
    private WebElement emailBoxLabel;
    private static final String EMAIL_BOX_LABEL_EXPECTED_TEXT = "Your Email Address";

    private static final String PASSWORD_BOX_NAME = "Password";
    @FindBy(how = How.NAME, using = PASSWORD_BOX_NAME)
    private WebElement passwordBox;

    @FindBy(how = How.CSS, using = "label[for='Password']")
    private WebElement passwordBoxLabel;
    private static final String PASSWORD_BOX_LABEL_EXPECTED_TEXT = "Your Password";

    private static final String SIGN_IN_BUTTON_ID = "SignIn";
    @FindBy(how = How.ID, using = SIGN_IN_BUTTON_ID)
    private WebElement signInButton;
    private static final String SIGN_IN_BUTTON_LABEL_EXPECTED_TEXT = "Sign In";

    @FindBy (how = How.XPATH, using = "//input[@value='Sign In']")
    private static WebElement signIn;

    private static final String LOG_IN_BUTTON_XPATH = "//button[@value='Login']";
    @FindBy(how = How.XPATH, using = LOG_IN_BUTTON_XPATH)
    private WebElement logInButton;
    private static final String LOG_IN_BUTTON_LABEL_EXPECTED_TEXT = "Log In";

    @FindBy(how = How.ID, using = "ForgetYourPasswordLink")
    private WebElement forgotPasswordLink;
    private static final String FORGOT_YOUR_PASSWORD_EXPECTED_TEXT = "Forgot your password?";

    @FindBy(how = How.CSS, using = "input.button")
    private WebElement forgotYourPasswordSubmitButton;

    @FindBy(how = How.XPATH, using = ".//*[@id='dbIdContentInner']/div[1]/form/div/div[2]/input")
    private WebElement forgotYourPasswordTextBox;

    @FindBy(how = How.XPATH, using = "//*[@id='dbIdLogin']/div/a")
    private WebElement getStartedLink;
    private static final String GET_STARTED_NOW_LINK_EXPECTED_TEXT = "Get started now!";

    @FindBy(how = How.CLASS_NAME, using = "dbLinkNoUnderline")
    private WebElement privacyPolicyLink;

    @FindBy(how = How.CLASS_NAME, using = "dbMessage")
    private WebElement invalidCredentialsText;

    private static final String invalidCredentialsExpectedText = "Invalid credentials.\n"
            + "Please try again or use the \"Forgot your password?\" link to receive a temporary password.";

    private static final String invalidCredentialsThreeMoreText = "Invalid credentials. "
            + "After 3 more failed attempts, you will be required to reset your password.\n"
            + "Please try again or use the \"Forgot your password?\" link to receive a temporary password.";

    private static final String invalidCredentialsTwoMoreText = "Invalid credentials. "
            + "After 2 more failed attempts, you will be required to reset your password.\n"
            + "Please try again or use the \"Forgot your password?\" link to receive a temporary password.";

    private static final String invalidCredentialsOneMoreText = "Invalid credentials. "
            + "After your next failed attempt, you will be required to reset your password.\n"
            + "Please try again or use the \"Forgot your password?\" link to receive a temporary password.";

    private static final String invalidCredentialsDeactivated =
            "Your account has been deactivated.\n"
            + "Please contact Customer Support for assistance.";

    private static ThreadLocal<CustomerLoginPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                                                                                     CustomerLoginPage.class));
    }

    private static CustomerLoginPage getInstance() {
        return threadLocalInstance.get();
    }

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(SIGN_IN_BUTTON_ID))
                && SeleniumTest.isElementVisibleNoWaiting(By.name(EMAIL_BOX_NAME))
                && SeleniumTest.isElementVisibleNoWaiting(By.name(PASSWORD_BOX_NAME));
    }

    /**
     * Utility method to automate the process of getting to the login page.
     * Since we don't have an user, we will use the locale setting in the LocaleHelper object.
     *
     * @return A new login page object
     */
    public static CustomerLoginPage navigateTo() {

        // check to see if we need to skip test or not
        LocaleHelper.skipTestPerLocale();

        String url = URL.getURL(Site.CUSTOMER_DASHBOARD) + LOGIN_URL;

        // use the locale from the Locale object.
        if (null != LocaleHelper.getCurrentLocale()) {
            url += "?locale=" + LocaleHelper.getCurrentLocale().UrlTag();
        }

        Driver.getDriver().get(url);
        SeleniumTest.conditionalClickThroughCertMessage();
        return getInstance();
    }

    /**
     * Utility method to automate the process of getting to the login page.
     *
     * @return A new login page object
     */
    public static CustomerLoginPage navigateTo(String URL) {

        // check to see if we need to skip test or not
        LocaleHelper.skipTestPerLocale();

        String url = URL + LOGIN_URL;

        if (null != LocaleHelper.getCurrentLocale()) {
            url += "?locale=" + LocaleHelper.getCurrentLocale().UrlTag();
        }
        Driver.getDriver().get(url);

        SeleniumTest.conditionalClickThroughCertMessage();
        return getInstance();
    }

    public static void navigateTo(UserLogin userLogin) {
        navigateTo(URL.getURL(Site.CUSTOMER_DASHBOARD)).signInAs(userLogin);
    }

    /**
     * Utility method to automate the process of getting to the login page  for the specified email user.
     */
    public static void navigateTo(String email, String password) {
        navigateTo(URL.getURL(Site.CUSTOMER_DASHBOARD))
                .signInAs(email, password, AccountType.CUSTOMER_ACCOUNT);
    }

    public static String getSignInLinkExpectedLinkText() {
        return SIGN_IN_LINK_EXPECTED_LINK_TEXT;
    }

    public static String getSignInLinkText() {
        return getInstance().signInLink.getText();
    }

    public static String getNewAccountLinkExpectedLinkText() {
        return NEW_ACCOUNT_LINK_EXPECTED_LINK_TEXT;
    }

    public static String getNewAccountLinkText() {
        return getInstance().newAccountLink.getText();
    }

    public static String getYourCustomerSupportTeamLabelExpectedText() {
        return YOUR_CUSTOMER_SUPPORT_TEAM_LABEL_EXPECTED_TEXT;
    }

    public static String getYourCustomerSupportTeamLabel() {
        return getInstance().yourCustomerSupportTeamLabel.getText();
    }

    public static String getCustomerCupportExpectedPhoneNumber() {
        return CUSTOMER_CUPPORT_EXPECTED_PHONE_NUMBER;
    }

    public static String getCustomerSupportPhoneNumber() {
        return getInstance().customerSupportPhoneNumber.getText();
    }

    public static String getContactSupportEmailAddress() {
        return getInstance().contactEmail.getAttribute("href");
    }

    public static String getContactSupportExpectedEmailAddress() {
        return CONTACT_EMAIL_EXPECTED_ADDRESS;
    }

    /**
     * Types the specified email into the email text box.
     *
     * @param email The email to be typed
     */
    public static void typeEmail(String email) {
        SeleniumTest.clearAndSetText(getInstance().emailBox, email);
    }

    public static String getEmailTextBoxLabel() {
        return getInstance().emailBoxLabel.getText();
    }

    public static String getEmailTextBoxLabelExpectedText() {
        return EMAIL_BOX_LABEL_EXPECTED_TEXT;
    }

    /**
     * Types the specified password into the password text box.
     *
     * @param password The password to be typed
     */
    public static void typePassword(String password) {
        SeleniumTest.clearAndSetText(getInstance().passwordBox, password);
    }

    public static String getPasswordTextBoxLabel() {
        return getInstance().passwordBoxLabel.getText();
    }

    public static String getPasswordTextBoxLabelExpectedText() {
        return PASSWORD_BOX_LABEL_EXPECTED_TEXT;
    }

    public static String getInvalidCredentialsString() {
        return getInstance().invalidCredentialsText.getText();
    }

    public static String getInvalidCredentialsExpectedText() {
        return invalidCredentialsExpectedText;
    }

    public static String getInvalidCredentialsThreeMoreText() {
        return invalidCredentialsThreeMoreText;
    }

    public static String getInvalidCredentialsTwoMoreText() {
        return invalidCredentialsTwoMoreText;
    }

    public static String getInvalidCredentialsOneMoreText() {
        return invalidCredentialsOneMoreText;
    }


    public static String getSignInText() {
        return getInstance().signInText.getText();
    }

    public static String getSignInToSterlingoneExpectedText() {
        return SIGN_IN_TO_STERLINGONE_EXPECTED_TEXT;
    }

    public static String getLoginNote() {
        return getInstance().loginNote.getText();
    }

    public static String getLoginNoteExpectedText() {
        return LOGIN_NOTE_EXPECTED_TEXT;
        // change this when localization is enabled
        //return LocaleHelper.getVisibleText(TALENTWISE_IS_NOW_STERLING_ONE_LOCATOR) + "\n"
        //		+ LocaleHelper.getVisibleText(ENJOY_THE_SAME_STREAMLINED_LOCATOR) + "\n"
        //		+ LocaleHelper.getVisibleText(PLEASE_USE_YOUR_EMAIL_LOCATOR);
    }

    public static String getAreYouNewNote() {
        return getInstance().areYouNewText.getText();
    }

    public static String getAreYouNewNoteExpectedText() {
        return ARE_YOU_NEW_EXPECTED_TEXT;
    }

    public static String getNewUserNote() {
        return getInstance().newUserNote.getText();
    }

    public static String getNewUserNoteExpectedText() {
        return NEW_USER_NOTE_EXPECTED_TEXT;
    }

    public static String getGetStartedNowLinkDisplayText() {
        return getInstance().getStartedLink.getText();
    }

    public static String getGetStartedNowLinkExpectedText() {
        return GET_STARTED_NOW_LINK_EXPECTED_TEXT;
    }

    /**
     * Clicks the sign in button with the assumption that the user credentials provided
     * will result in a successful sign in attempt.
     *
     * @param accountType The account type to be signed in under
     * @return A new dashboard page object
     */
    public static DashboardPage clickSignIn(AccountType accountType) {
        getInstance().signInButton.click();
        JavaScriptHelper.waitForJQueryAjaxDone();
        if (MultipleAccountsFoundPage.onPage()) {
            if (Driver.getDriver().getCurrentUrl().contains("login.php")) {
                Driver.getDriver().findElement(By.xpath(
                        "//label[contains(@for,"
                        + "'multiple_account_radio')"
                        + "]/strong[contains(text(), '" + accountType + "')]")).click();
                Driver.getDriver().findElement(By.xpath("//input[@class='button']"))
                        .click();
            }
        }
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public static DashboardPage clickLogIn (){
        getInstance().logInButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public static DashboardPage clickIHaveAccountRadioButton () {
       getInstance().iHaveAccountRadioButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Clicks the sign in button with the assumption that the user credentials provided
     * will result in an unsuccessful sign in attempt.
     *
     * @return A new login page object
     */
    public static CustomerLoginPage clickSignInExpectingFailure() {
        getInstance().signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), CustomerLoginPage.class);
    }

    public static void clickSignInButton() {
        getInstance().signInButton.click();
    }

    public static String getSignInButtonLabel() {
        return getInstance().signInButton.getAttribute("value");
    }

    public static String getSignInButtonLabelExpectedText() {
        return SIGN_IN_BUTTON_LABEL_EXPECTED_TEXT;
    }

    public static void signInAs(UserLogin userLogin) {
        signInAs(userLogin.getEmailAddress(), userLogin.getPassword(), userLogin.getAccountType());
    }

    /**
     * Attempts to sign in the user with valid credentials. The provided credentials
     * must be ones that would result in a successful sign in attempt.
     *
     * @param email       The email to be typed
     * @param password    The password to be typed
     * @param accountType The account type to be signed in under
     * @return A new dashboard page object
     */
    public static void signInAs(String email, String password, AccountType accountType) {
        typeEmail(email);
        typePassword(password);
        clickSignIn(accountType);
    }

    public static void logInAs (String email, String password,AccountType accountType) {
        typeEmail(email);
        typePassword(password);
        clickLogIn();
    }

    public static void signInAs(String password) {
        typePassword(password);
        signIn.click();
        SeleniumTest.waitMs(3000);
    }


    /**
     * Attempts to sign in the user with invalid credentials. The provided credentials
     * must be ones that would result in an unsuccessful sign in attempt.
     *
     * @param email    The email to be typed
     * @param password The password to be type
     * @return A new login page object
     */
    public static CustomerLoginPage signInAsExpectingFailure(String email, String password) {
        typeEmail(email);
        typePassword(password);
        return clickSignInExpectingFailure();
    }

    /**
     * call this when the next failed attempt locks you out
     * and forces you to the passwrod reset page
     *
     * @param email
     * @param password
     * @return
     */
    public static ForgotPasswordPage signInAndForcePasswordReset(String email, String password) {
        typeEmail(email);
        typePassword(password);
        getInstance().signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.ForgotPasswordPage.class);
    }

    public static ChangePasswordPage signInWithTempPassword(String email, String password) {
        typeEmail(email);
        typePassword(password);
        getInstance().signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.SterlingOneAdmin.ChangePasswordPage.class);
    }

    /**
     * Clicks the "Forgot your password?" link.
     */
    public static void clickForgotPasswordLink() {
        getInstance().forgotPasswordLink.click();
        PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.ForgotPasswordPage.class);
    }

    public static String getForgotYourPasswordLinkText() {
        return getInstance().forgotPasswordLink.getText();
    }

    public static String getForgotYourPasswordExpectedText() {
        return FORGOT_YOUR_PASSWORD_EXPECTED_TEXT;
    }

    /**
     * Clicks the "Get started now!" link.
     */
    public static void clickGetStartedLink() {
        getInstance().getStartedLink.click();
    }

    /**
     * Logs into the customer Dashboard using AccountType.CUSTOMER_ACCOUNT
     *
     * @param userName     email to use for login
     * @param userPassword password to use for login
     * @return DashboardPage
     */
    public static void navigateToAndLoginToCustomerDashboard(String userName, String userPassword) {
        CustomerLoginPage theLoginPage = CustomerLoginPage.navigateTo(URL.getURL(Site.CUSTOMER_DASHBOARD));
        theLoginPage.signInAs(userName, userPassword, AccountType.CUSTOMER_ACCOUNT);
    }

    public static void navigateToAndLoginToCustomerDashboard(Workflows.User user) {
        logger.info("Logging in as {} with locale {}", user.getEmailAddress(), user.getUserLocale());
        navigateToAndLoginToCustomerDashboard(user.getEmailAddress(), user.getPassword());
    }

    /**
     * Logs into the customer Dashboard using AccountType.CUSTOMER_ACCOUNT
     *
     * @param userName     email to use for login
     * @param userPassword password to use for login
     * @return DashboardPage
     */
    public void navigateToAndLoginToCustomerDashboardAdminConsole(String userName, String userPassword) {
        CustomerLoginPage theLoginPage = CustomerLoginPage.navigateTo(URL.getURL(Site.ADMIN_CONSOLE));
        theLoginPage.signInAs(userName, userPassword, AccountType.CUSTOMER_ACCOUNT);
    }

}
