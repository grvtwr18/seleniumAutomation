package Sites.TalentWiseDashboard.Records;

import Sites.Site;
import Sites.URL;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * created by user cfrediani on 08/20/2018
 * Selenium page class for Customer Dashboard | Records | Archived Documents.
 */
public class ArchivedDocumentsPage {
    private String homepageUrl = "/screening/records.php?view=archived-documents";

    // NOTE -  This UI is only temporary - for testing that Backend Unified Search is pulling data from Legacy Systems.
    // the Archived Documents page will be finished for customer use later, causing XPaths to change - so they
    // aren't finalized to shorter/cleaner values yet.

    @FindBy(how = How.XPATH, using = "//input[@class='jss114' and @name='reportId']")
    private WebElement reportIdTextBox;

    @FindBy(how = How.XPATH, using = "//input[@class='jss114' and @name='firstName']")
    private WebElement firstNameTextBox;

    @FindBy(how = How.XPATH, using = "//input[@class='jss114' and @name='lastName']")
    private WebElement lastNameTextBox;

    @FindBy(how = How.XPATH, using = "//input[@class='jss114' and @name='governmentId']")
    private WebElement governmentIdTextBox;

    @FindBy(how = How.XPATH, using = "//div[@class='jss120 jss121 jss114']")
    private WebElement dataRangeTextBox;

    @FindBy(how = How.XPATH, using = "(//input[@class='jss114'])[5]")
    private WebElement startDateTextBox;

    @FindBy(how = How.XPATH, using = "//*[@id=\"unifiedSearch\"]/div/div/div[1]/div[1]/div[7]/div/div/input")
    private WebElement endDateTextBox;

    @FindBy(how = How.XPATH, using = "//button[@class='jss144 jss174 jss180 jss181 jss187']")
    private WebElement searchButton;

    @FindBy(how = How.XPATH, using = "//button[@class='jss144 jss174 jss180 jss187']")
    private WebElement resetButton;

    @FindBy(how = How.XPATH, using = "//tbody[@class='jss232']")
    private WebElement searchResultsTable;

    @FindBy(how = How.XPATH, using = "(//tr[@class='jss219 jss221 jss220'])[1]")
    private WebElement searchResultsTableRow;

    @FindBy(how = How.XPATH, using = "//td[contains(@class,'jss224 jss226')]")
    private WebElement[] searchResultsTableRows;

    /**
     * Constructor for this ArchivedDocumentsPage selenium page class.
     * @param usePseudoLocale If true initializes the page class with the pseudo local URL format.
     */
    public ArchivedDocumentsPage(boolean usePseudoLocale) {
        if (usePseudoLocale) {
            homepageUrl += "?locale=qps-PLOC";
        }
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    WebElement getReportIdTextBox() {
        return this.reportIdTextBox;
    }

    WebElement getFirstNameTextBox () {
        return this.firstNameTextBox;
    }

    WebElement getLastNameTextBox() {
        return this.lastNameTextBox;
    }

    WebElement getGovernmentIdTextBox() {
        return this.governmentIdTextBox;
    }

    WebElement getDataRangeTextBox() {
        return this.dataRangeTextBox;
    }

    WebElement getStartDateTextBox() {
        return this.startDateTextBox;
    }

    WebElement getEndDateTextBox() {
        return this.endDateTextBox;
    }

    WebElement getTable() {
        return this.searchResultsTable;
    }

    WebElement getTableRow() {
        return this.searchResultsTableRow;
    }

    WebElement[] getTableRows() {
        return this.searchResultsTableRows;
    }

    /**
     * Navigates to the Customer Dashboard | Records | Archived Documents page and then calls PageFactory.initElements.
     */
    public void navigateTo() {
        Driver.getDriver().get(URL.getURL(Site.CUSTOMER_DASHBOARD) + homepageUrl);
        SeleniumTest.waitForPageLoadToComplete();
        this.initializePageFactory();
    }

    /**
     * Navigates to Customer Dashboard | Records | Archived Documents page with the Proxy OverrideUserID URL
     * and calls PageFactory.initElements.
     */
    public void navigateToProxied(int customerUserId){
        Driver.getDriver().get(URL.getURL(Sites.Site.ADMIN_CONSOLE) +
                this.homepageUrl + "&OverrideUserID=" + Integer.toString(customerUserId));
        this.initializePageFactory();
    }

    /**
     * Clears the Report ID text box and then types in the supplied text.
     * @param reportId The new report ID to enter into the text box.
     */
    public void clearAndEnterReportId(String reportId) {
        SeleniumTest.clearAndSetText(this.reportIdTextBox, reportId);
    }

    /**
     * Clears the first name text box and then types in the supplied text.
     * @param firstName The new first name to enter into the text box.
     */
    public void clearAndEnterFirstName(String firstName) {
        SeleniumTest.clearAndSetText(this.getFirstNameTextBox(), firstName);
    }

    /**
     * Clears the last name text box and then types in the supplied text.
     * @param lastName The new last name to enter into the text box.
     */
    public void clearAndEnterLastName(String lastName) {
        SeleniumTest.clearAndSetText(this.getLastNameTextBox(), lastName);
    }

    /**
     * Clears the government ID text box and then types in the supplied text.
     * @param governmentId The new government ID to enter into the text box.
     */
    public void clearAndEnterGovernmentId(String governmentId) {
        SeleniumTest.clearAndSetText(this.getGovernmentIdTextBox(), governmentId);
    }

    /**
     * Clears the start date text box and then types in the supplied text.
     * @param startDate The new start date to enter into the text box.
     */
    public void clearAndEnterStartDate(String startDate) {
        SeleniumTest.clearAndSetText(this.getStartDateTextBox(), startDate);
    }

    /**
     * Clears the end date text box and then types in the supplied text.
     * @param endDate The new end date to enter into the text box.
     */
    public void clearAndEnterEndDate(String endDate) {
        SeleniumTest.clearAndSetText(this.getStartDateTextBox(), endDate);
    }

    /**
     *  Clicks the search button.
     */
    public void clickSearchButton() {
        SeleniumTest.click(searchButton);
    }

    /**
     * Clicks the reset button.
     */
    public void clickResetButton() {
        SeleniumTest.click(resetButton);
    }
}