package Sites.TalentWiseDashboard.Records;

import TWFramework.SeleniumTest;

/**
 * created by user cfrediani on 08/20/2018
 * Selenium page class helper for Customer Dashboard | Records | Archived Documents.
 */
public class ArchivedDocumentsPageHelper {
    private ArchivedDocumentsPage page;

    /**
     * Constructor for this selenium page class helper.
     * @param adp The ArchivedDocumentsPage instance of the selenium page class this helper operates against.
     */
    public ArchivedDocumentsPageHelper(ArchivedDocumentsPage adp) {
        this.page = adp;
    }

    /**
     * Returns the entire text contents of the search results table's first page of data.
     * @return The search results table's first page of data.
     */
    public String returnSearchResultsPageText() {
        return SeleniumTest.getText(this.page.getTable());
    }
}