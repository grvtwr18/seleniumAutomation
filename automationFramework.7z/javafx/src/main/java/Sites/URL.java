package Sites;

import java.net.InetAddress;
import java.net.UnknownHostException;

import Workflows.User;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by ssmith on 3/26/2015.
 */
public abstract class URL {
    private static final Logger LOGGER = LoggerFactory.getLogger(URL.class);

    private static final MonolithUrlBuilder monolithUrlBuilder = new MonolithUrlBuilder(
            getEnvironmentFromHostnameProperties(), System.getProperty("url.region"), httpsPort()
    );

    /**
     * Determines the environment by ripping apart hostname properties. Ideally we should have an "environment"
     * property that is just that and only that. But this is backward-compatible.
     *
     * @return the environment subdomain from the "hostname"
     */
    private static String getEnvironmentFromHostnameProperties() {
        String environmentProperty = System.getProperty("url.environment");
        if (environmentProperty != null) {
            return environmentProperty;
        }

        // We must keep the expected host name as the first value for the box's IP in the /etc/HOSTS file.
        String defaultHost = null;
        try {
            defaultHost = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            LOGGER.info("InetAddress.getLocalHost() failed with exception: {}", e.toString());
        }
        if ((SystemUtils.IS_OS_WINDOWS || SystemUtils.IS_OS_MAC_OSX) && System.getenv("DVM") != null) {
            defaultHost = System.getenv("DVM");
        }

        // we have habitually been using the "hostname" property to contain only the environment subdomain...
        String environment = System.getProperty("hostname", defaultHost);
        if(environment.isEmpty())
        {
            User ur = new User();
            environment = ur.getstrBOSEnvironment();
        }
        // but we can't count on that, sometimes there has been other crap there.
        int domainIndex = environment.indexOf(".talentwise.com");
        if (domainIndex > -1) {
            environment = environment.substring(0, domainIndex);
        }

        String www = "www.";
        if (environment.startsWith(www)) {
            environment = environment.substring(www.length());
        }

        return environment;
    }

    private static int httpsPort() {
        String portProperty = System.getProperty("s1.https.port");
        return StringUtils.isNotBlank(portProperty) ?
                Integer.parseInt(portProperty) :
                443;
    }
    /**
     * Returns the domain (with environment), ensuring it has the company-level "talentwise.com" domain and no prefix.
     *
     * @return the domain (with environment subdomain) of the current host
     */
    public static String getBasicHost() {
        return getHost(Site.NONE);
    }

    /**
     * Get the base host for a given Site (i.e. application).
     *
     * @param s Site enum value for the desired application subdomain
     * @return the base url
     */
    public static String getHost(Site s) {
        return monolithUrlBuilder.getApplicationHost(s);
    }

    /**
     * Get the base URL for a given Site (i.e. application) as a string.
     *
     * @param s Site enum value for the desired application subdomain
     * @return the base URL as a String
     */
    public static String getURL(Site s) {
        return getUriBuilder(s).toString();
    }

    /**
     * Get a URIBuilder instance with application subdomain basics set.
     *
     * @param s Site enum value for the desired application subdomain
     * @return the URI builder for further manipulation
     */
    public static URIBuilder getUriBuilder(Site s) {
        return monolithUrlBuilder.getApplicationUriBuilder(s);
    }
}


