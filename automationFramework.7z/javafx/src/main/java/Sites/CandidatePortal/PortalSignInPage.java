package Sites.CandidatePortal;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.Site;
import Sites.URL;
import TWFramework.BasicTest;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Page object that represents the Portal Sign In page for the Candidate Portal website.
 *
 * @author eelefson
 * @author ssmith
 */
public class PortalSignInPage extends CandidatePortalPages {
    private static final Logger logger =
            LoggerFactory.getLogger("Sites.CandidatePortal.PortalSignInPage");
    private static String candidatePortalURL;
    private static String login_url;

    @FindBy(how = How.NAME, using = "Email")
    private static WebElement emailBox;

    @FindBy(how = How.NAME, using = "Password")
    private static WebElement passwordBox;

    @FindBy(how = How.ID, using = "locale")
    private static WebElement localeDropDown;

    @FindBy(how = How.XPATH, using = "//input[@type='submit']")
    private static WebElement signInButton;

	@FindBy(how = How.LINK_TEXT, using = "Forgot your password?")
	private static WebElement forgotYourPasswordLink;

    @FindBy(how = How.XPATH, using = "//*[@id=\"widgetleft1\"]/div[2]/div/p")
    private static WebElement changePasswordErrorText;

    @FindBy(how = How.ID, using = "launch-")
    private static WebElement launchButton;

    @FindBy(how = How.XPATH, using = "//*[@id='widgetright1']/div[2]/div[3]/table/tbody/tr[2]/td[3]")
    private static WebElement requestStatus;

    static {
        PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    public static final String INVALID_CREDENTIALS_EXPECTED_TEXT = "Invalid email address or password.";
    public static final String PASSWORD_NO_MATCH_TEXT = "Passwords do not match.";
    //FDN-525 and FDN-830
    private static final String MALFORMED_URL_EXPECTED_MESSAGE_TEXT = "To sign in, please find the email message "
            + "inviting you to the Sterling Talent Solutions portal and click the link.";

    private static final String INVALID_CREDENTIALS_EXPECTED_TEXT_THIRD_ATTEMPT =
            "Invalid email address or password. After 3 more failed attempts, you will need to reset your password.\n"
                    + "\n"
                    + "Please use the \"Forgot your password\" link to receive a new temporary password.";

    private static final String INVALID_CREDENTIALS_EXPECTED_TEXT_FOURTH_ATTEMPT =
            "Invalid email address or password. After 2 more failed attempts, you will need to reset your password.\n"
                    + "\n"
                    + "Please use the \"Forgot your password\" link to receive a new temporary password.";

    private static final String INVALID_CREDENTIALS_EXPECTED_TEXT_FIFTH_ATTEMPT =
            "Invalid email address or password. After your next failed attempt, you will need to reset your password.\n"
                    + "\n"
                    + "Please use the \"Forgot your password\" link to receive a new temporary password.";

    private static final String INVALID_CREDENTIALS_LOCKEDOUT_EXPECTED_TEXT =
            "You have made too many password attempts.\n" + "\n"
                    + "Please use the \"Forgot your password\" link to receive a new temporary password.";

    @FindBy(how = How.NAME, using = "qSSNVerify")
    private static WebElement ssnVerify;

    @FindBy(how = How.NAME, using = "qDOBMonthVerify")
    private static WebElement dobMonth;

    @FindBy(how = How.NAME, using = "qDOBDayVerify")
    private static WebElement dobDay;

    @FindBy(how = How.NAME, using = "qDOBYearVerify")
    private static WebElement dobYear;

    @FindBy(how = How.CSS, using = "div.formButtonContainer > input.button")
    private static WebElement verifyButton;

    @FindBy(how = How.NAME, using = "NewPassword")
    private static WebElement newPasswordText;

    @FindBy(how = How.NAME, using = "NewPassword_Confirm")
    private static WebElement confirmNewPasswordText;

    @FindBy(how = How.CSS, using = "div.formButtonContainer > input.button")
    private static WebElement confirmNewPasswordButton;


    /**
     * Constructs a new Portal Sign In page object.
     */
    public PortalSignInPage() {
    }

    static {
        PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Utility method to automate the process of getting to the existing account login page.
     *
     * @return A new login page object
     */
    public static PortalSignInPage navigateTo(String URL, String cobrand, String sender,
            String email, String candidateID) {
        email = email.replaceAll("@", "%40");
        String login_url = "/" + cobrand + "/ptl/dashboard.php?Sender=" + sender + "&Email=" + email
                + "&OverrideCandidateID=" + candidateID;
        Driver.getDriver().get(URL + login_url);
        logger.debug("{}{}", URL, login_url);
        if (Driver.getDriver().getCurrentUrl().contains("invalidcert.htm")) {
            JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
            js.executeScript("arguments[0].click();",
                    Driver.getDriver().findElement(By.id("overridelink")));
        }
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Utility method to automate the process of getting to the existing account login page.
     *
     * @return A new login page object
     * @author jgupta
     */
    public static PortalSignInPage navigateTo(String URL, String cobrand, String sender) {
        String login_url = "/" + cobrand + "/ptl/dashboard.php?Sender=" + sender;
        Driver.getDriver().get(URL + login_url);
        logger.debug("{}{}", URL, login_url);
        if (Driver.getDriver().getCurrentUrl().contains("invalidcert.htm")) {
            JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
            js.executeScript("arguments[0].click();",
                    Driver.getDriver().findElement(By.id("overridelink")));
        }
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    public static String getInvalidCredentialsExpectedText() {
        return INVALID_CREDENTIALS_EXPECTED_TEXT;
    }

    public static String getMalformedUrlExpectedMessageText() {
        return MALFORMED_URL_EXPECTED_MESSAGE_TEXT;
    }

    public static String getInvalidCredentialsLockedoutExpectedText() {
        return INVALID_CREDENTIALS_LOCKEDOUT_EXPECTED_TEXT;
    }

    public static String getInvalidCredentialsThirdAttemptExpectedText() {
        return INVALID_CREDENTIALS_EXPECTED_TEXT_THIRD_ATTEMPT;
    }

    public static String getInvalidCredentialsFourthAttemptExpectedText() {
        return INVALID_CREDENTIALS_EXPECTED_TEXT_FOURTH_ATTEMPT;
    }

    public static String getInvalidCredentialsFifthAttemptExpectedText() {
        return INVALID_CREDENTIALS_EXPECTED_TEXT_FIFTH_ATTEMPT;
    }

    public static String getIEmailText() {
        return emailBox.getAttribute("value");
    }

    public static String getErrorText() {
        SeleniumTest.waitForElement(changePasswordErrorText);
        return changePasswordErrorText.getText();
    }

    /**
     * Types the specified password into the password text box.
     * @param password The password to be typed
     */
    public static void typePassword(String password)
    {
        SeleniumTest.clearAndSetText(passwordBox, password);
    }

    /**
     * Set the locale in the Language dropdown
     * @param locale
     */
    public static void setLocale(String locale)
    {
        SeleniumTest.selectByValueFromDropDown(localeDropDown, locale);
    }

    /**
     * Clicks the "Sign In" button to go to Verifier Portal.
     * @return A new Verifier Portal Dashboard page object
     */
    public static DashboardPage clickSignInButtonToGoToVerifierPortalDashboard()
    {
        signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public static void clickLaunchButton() {
        SeleniumTest.click(launchButton);
    }

    public static boolean launchButtonExists() {
        return SeleniumTest.isElementVisible(launchButton);
    }

    /**
     * Logs into candidate portal
     *
     * @return Dashboard page object
     * @author jgupta
     */
    public static DashboardPage loginCandidatePortal(String email, String password)
    {
        return loginCandidatePortal(email, password, "");
    }

    /**
     * Logs into candidate portal and sets locale
     *
     * @return Dashboard page object
     * @author djoe
     */
    public static DashboardPage loginCandidatePortal(String email, String password, String locale)
    {
        SeleniumTest.clearAndSetText(emailBox, email);
        SeleniumTest.clearAndSetText(passwordBox, password);

        if (!locale.isEmpty()) {
            SeleniumTest.selectByVisibleTextFromDropDown(localeDropDown, locale);
        }

        SeleniumTest.click(signInButton);
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Logs into candidate portal using only password as email field was populated by url.
     *
     * @param password
     * @return DashboardPage
     */
    public static DashboardPage loginCandidatePortal(String password) {
        SeleniumTest.clearAndSetText(passwordBox, password);
        signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /* Logs into candidate portal using only password as email field was populated by url.
     * @param password
     * @param returnClass
     * @return DashboardPage
     */
    public static CandidatePortalPages loginCandidatePortal(String password,
            Class<? extends CandidatePortalPages> returnClass) {
        SeleniumTest.clearAndSetText(passwordBox, password);
        signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /* Logs into candidate portal using only password as email field was populated by url.
     * @param password
     * @param returnClass
     * @return Sites.TalentWiseDashboard.Dashboard.DashboardPage
     */
    public static void loginCandidatePortalVerifierResetPassword(String password) {
        SeleniumTest.clearAndSetText(passwordBox, password);
        signInButton.click();
        PageFactory.initElements(Driver.getDriver(), Sites.TalentWiseDashboard.SterlingOneAdmin.ChangePasswordPage.class);
    }

    /**
     * Use this function when you are going to sign in with the wrong password for the last time
     * and get locked out.
     *
     * @param email
     * @param password
     * @return the ForgotPasswordPage
     */
    public static Sites.CandidatePortal.ForgotPasswordPage signInAndForcePasswordReset(String email,
            String password) {
        typeEmail(email);
        typePassword(password);
        signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), Sites.CandidatePortal.ForgotPasswordPage.class);
    }

    /**
     * Logs into portal as verifier
     *
     * @param URL
     * @param cobrand
     * @param sender
     * @param emailID
     * @return PortalSignInPage
     * @author jgupta
     */
    public static PortalSignInPage navigateAsVerifier(String URL, String cobrand, String sender,
            String emailID) {
        // Changed the URL back to verifyDashboard as this is specific to verifiers
        login_url = "/" + cobrand + "/ptl/verifydashboard.php?Sender=" + sender + "&Email=" +
                    emailID
                + "&LoginType=1";
        Driver.getDriver().get(URL + login_url);
        if (Driver.getDriver().getCurrentUrl().contains("invalidcert.htm")) {
            JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
            js.executeScript("arguments[0].click();",
                    Driver.getDriver().findElement(By.id("overridelink")));
        }
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Set the Candidate portal base URL
     *
     * @return
     * @author tjoshi
     */
    public static String setCandidatePortalUrl() {
        return URL.getURL(Site.CANDIDATE_PORTAL);
    }

    /**
     * Types the specified email into the email text box.
     *
     * @param email The email to be typed
     */
    public static void typeEmail(String email) {
        SeleniumTest.clearAndSetText(emailBox, email);
    }

    /**
     * Clicks the "Forgot your password?" link.
     *
     * @return A new Forgot Password page object
     */
    public static ForgotPasswordPage clickForgotPasswordLink() {
        forgotYourPasswordLink.click();
        return PageFactory.initElements(Driver.getDriver(), ForgotPasswordPage.class);
    }

    /**
     * Clicks the "Sign In" button.
     *
     */
    public static void clickSignInButton() {
        SeleniumTest.click(signInButton);
    }

    /**
     * Clicks the "Sign In" button.
     *
     * @param returnClass
     * @return
     */
    public static CandidatePortalPages clickSignInButton(
            Class<? extends CandidatePortalPages> returnClass) {
        SeleniumTest.click(signInButton);
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Verifies the SSN, and DOB for the first time login on a candidate portal
     *
     * @param email
     * @param password
     * @param last4SSN
     * @param dob
     * @return
     * @author tjoshi
     */
    public static DashboardPage loginCandidatePortal(String email, String password, String last4SSN,
            LocalDate dob) {
        Driver.getDriver().manage().deleteAllCookies();
        SeleniumTest.clearAndSetText(emailBox, email);
        SeleniumTest.clearAndSetText(passwordBox, password);
        signInButton.click();
        SeleniumTest.clearAndSetText(ssnVerify, last4SSN);

        //TODO refactor for locale specific date formats
        //format(MMM) for month differs for June/Sept, so use selectbyValue instead of selectByVisibleText
        if (SeleniumTest.isElementVisibleNoWaiting(By.name("qDOBMonthVerify"))){
            SeleniumTest.selectByValueFromDropDown(dobMonth, dob.format(DateTimeFormatter.ofPattern("M")).toString());
            selectDateByVisibleTextFromDropDown(dobDay, dob, "d");
            selectDateByVisibleTextFromDropDown(dobYear, dob, "yyyy");
        }
        verifyButton.click();

        return setNewPasswordOnFirstLogin();
    }

    public static DashboardPage loginCandidatePortal(Candidate candidate) {
        Driver.getDriver().manage().deleteAllCookies();
        SeleniumTest.clearAndSetText(emailBox, candidate.getEmailAddress());
        logger.info("Candidate Password:" + candidate.getPortalPassword());
        SeleniumTest.clearAndSetText(passwordBox, candidate.getPortalPassword());
        signInButton.click();
        SeleniumTest.waitForPageLoadToComplete();
        if(Driver.getDriver().getCurrentUrl().contains("verifycandidate.php")) {
            verifySsnAndOrDob(candidate);
            verifyButton.click();
        }
        if (!Driver.getDriver().getCurrentUrl().contains("dashboard.php")) {
            return setNewPasswordOnFirstLogin(candidate);
        }
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public static void verifySsnAndOrDob(Candidate candidate) {
        // This shouldn't assume it has to verify SSN simply because the candidate has an SSN,
        // just as it shouldn't assume it has to verify DOB simply because the candidate has a DOB.
        if (!BasicTest.isNullOrEmpty(candidate.getSocialSecurityNumber(), true)
                && SeleniumTest.isElementVisibleNoWaiting(By.name("qSSNVerify"))) {
            logger.info("Verifying SSN = \"{}\" for candidate: {}", candidate.getSocialSecurityNumber(), candidate);
            SeleniumTest.clearAndSetText(ssnVerify, candidate.getSocialSecurityNumber()
                    .substring(candidate.getSocialSecurityNumber().length() - 4));
        }
        if (candidate.getDOB() != null && SeleniumTest.isElementVisibleNoWaiting(By.name("qDOBMonthVerify"))) {
            //TODO refactor for locale specific date formats
            logger.info("Verifying DOB = \"{}\" for candidate: {}", candidate.getDOB(), candidate);
            selectDateByVisibleTextFromDropDown(dobMonth, candidate.getDOB(), "MMM");
            selectDateByVisibleTextFromDropDown(dobDay, candidate.getDOB(), "d");
            selectDateByVisibleTextFromDropDown(dobYear, candidate.getDOB(), "yyyy");
        }
    }

    /**
     * Sets password upon first login and navigates to the dashboard
     *
     * @return
     */
    public static DashboardPage setNewPasswordOnFirstLogin(Candidate... candidate) {
        SeleniumTest.waitForElementEnabled(newPasswordText);

        String newPassword = "Test!234";
        SeleniumTest.clearAndSetText(newPasswordText, newPassword);

        //FDN-1494
        SeleniumTest.clearAndSetText(confirmNewPasswordText, "This is wrong");
        confirmNewPasswordButton.click();
        SeleniumTest.verifyElementTextEquals(PASSWORD_NO_MATCH_TEXT, changePasswordErrorText);

        SeleniumTest.clearAndSetText(confirmNewPasswordText, newPassword);
        confirmNewPasswordButton.click();

        // For those who use the Candidate Object - we update it here to set
        // the permanent portal password for future use.
        if (candidate.length == 1) {
            candidate[0].setPortalPassword(newPassword);
        }
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Selects a date drop down value from a given LocalDate
     *
     * @param element
     * @param date
     * @param format
     */
    public static void selectDateByVisibleTextFromDropDown(WebElement element, LocalDate date, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        String value = date.format(formatter).toString();

        SeleniumTest.selectByVisibleTextFromDropDown(element, value);
    }

    /**
     * sets temporary password, and new password on first login to portal page and verify launch button exists
     *
     */
    public static boolean signInFirstTimeIntoPortal(String tempPassword, String newPassword) {
        typePassword(tempPassword);
        signInButton.click();
        SeleniumTest.clearAndSetText(newPasswordText, newPassword);
        SeleniumTest.clearAndSetText(confirmNewPasswordText, newPassword);
        confirmNewPasswordButton.click();
        return SeleniumTest.isElementVisible(launchButton);
    }

    /**
     * Utility method to automate the process of getting to the existing account login page.
     *
     * @return A new login page object
     * @author mnam
     */
    public static PortalSignInPage navigateTo(String cobrand, String email) {
        String login_url = "/" + cobrand + "/ptl/dashboard.php?&Email=" + email;
        String URL = Sites.URL.getURL(Site.CANDIDATE_PORTAL);
        Driver.getDriver().get(URL + login_url);
        logger.debug("{}{}", URL, login_url);
        if (Driver.getDriver().getCurrentUrl().contains("invalidcert.htm")) {
            JavascriptExecutor js = (JavascriptExecutor) Driver.getDriver();
            js.executeScript("arguments[0].click();",
                    Driver.getDriver().findElement(By.id("overridelink")));
        }
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * gets ticketId on launch button onclick attribute and get ticketId
     *
     */
    public static String getTicketId() {
        return launchButton.getAttribute("onclick").split("ticket=")[1].split("\\D+")[0].toString();
    }

    public static String getRequestStatus() {
        return requestStatus.getText();
    }

    public static String getReportID() {
        return SeleniumTest.getTextByLocator(By.xpath("//td[@class='reportsDoubleWidth ']"));
    }

    public void getSsnVerificationDone(Candidate candidate)
    {
        verifySsnAndOrDob(candidate);
    }

    public void clickVerifySsnButton(){ SeleniumTest.click(verifyButton);}

    public void setNewPassword(String newPassword)
    {
        SeleniumTest.clearAndSetText(newPasswordText, newPassword);
        SeleniumTest.clearAndSetText(confirmNewPasswordText, newPassword);
        confirmNewPasswordButton.click();

    }
}
