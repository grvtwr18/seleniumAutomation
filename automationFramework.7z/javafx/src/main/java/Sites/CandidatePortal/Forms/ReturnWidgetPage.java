package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.DashboardPage;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 8/31/2015.
 */
public class ReturnWidgetPage extends FormPage {

    @FindBy(how = How.CSS, using = "input[type='radio']")
    private static WebElement firstRadioButton;

    @FindBy(how = How.CSS, using = "input[value='2']")
    private static WebElement secondRadioButton;

    @FindBy(how = How.CSS, using = "button.button")
    private WebElement closeButton;

    @FindBy(how = How.CSS, using = "button[value='Submit']")
    private static WebElement submitButton;

    @FindBy(how = How.ID, using = "prevownererror")
    private WebElement taskOwnerErrorMessage;

    @FindBy(how = How.CSS, using = "textarea")
    private static WebElement returnNoteTextArea;

    @FindBy(how = How.ID, using = "noteerror")
    private WebElement errorMsg;

    static {
        PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }

    /**
     * Constructs a new Return Widget page object.
     * @author guptaj
     */
    public ReturnWidgetPage() {

    }

    /**
     * Click on radio button for the first task owner (the candidate).
     */
    public static ReturnWidgetPage selectFirstTaskOwner(){
        firstRadioButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }

    /**
     * Click on the radio button for second task owner i.e. reviewer.
     */
    public static ReturnWidgetPage selectSecondTaskOwner(){
        secondRadioButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }

    /**
     * Click on submit button without specifying comments.
     */
    public ReturnWidgetPage clickSubmitButtonWithoutSpecifyingComments(){
        submitButton.click();
        return this;
    }

    /**
     * Click on submit button after specifying comments.
     * @return
     */
    public static DashboardPage clickSubmitButtonAfterSpecifyingComments(){
        submitButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Get the error message displayed on the Return widget
     * @return
     */
    public String getErrorMessageOnReturnWidget() {
        return errorMsg.getText().toString();
    }

    /**
     * This method gets the text for the task owner error message i.e. when user tries to return a form without specifying task owner, an error message is displayed.
     * @return
     */
    public String getTaskOwnerErrorMessageOnReturnWidget() {
        return taskOwnerErrorMessage.getText().toString();
    }

    /**
     * This method types the return comments in the return note.
     * @param text
     */
    public static ReturnWidgetPage typeReturnComments(String text) {
        returnNoteTextArea.sendKeys(text);
        return PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }

    /** Add a comment to this line
     *  This method clicks on the close button to close the return dialog.
     */
    public  void clickCloseButton(){
        closeButton.click();
    }

}
