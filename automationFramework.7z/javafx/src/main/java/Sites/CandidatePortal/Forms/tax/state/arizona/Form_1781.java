package Sites.CandidatePortal.Forms.tax.state.arizona;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.tax.state.CommonFunctions;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.apache.commons.lang.NotImplementedException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_1781 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//a[@href='https://www.azdor.gov/Forms/Withholding.aspx']")
    private WebElement stateOfArizonaWECFormLink;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_5']")
    public WebElement completeFormWecLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_5_Yes']")
    private WebElement completeFormWECYesRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_5_No']")
    private WebElement completeFormWECNoRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_14']")
    private WebElement withholdingStatusLabel;

    @FindBy(how = How.ID, using = "1781-1781_14")
    private WebElement withholdingStatusDropdown;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Withholding Status']")
    private WebElement pleaseSelectOneExemptDropdown;

    @FindBy(how = How.XPATH, using = "//input[@id='1781-1781_31']")
    private WebElement tribalCensusNumberTextbox;

    @FindBy(how = How.XPATH, using = "//input[@id='1781-1781_32']")
    private WebElement reservationResidenceTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_33']")
    private WebElement tribalMembershipLabel;

    @FindBy(how = How.ID, using = "1781-1781_33")
    private WebElement tribalMembershipCheckbox;

    @FindBy(how = How.XPATH, using = "//input[@id='1781-1781_34']")
    private WebElement employeeOfTextbox;

    @FindBy(how = How.XPATH, using = "//input[@id='1781-1781_31']")
    private WebElement employerNameTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_16']")
    private WebElement iUnderstandLabel;

    @FindBy(how = How.ID, using = "1781-1781_16")
    private WebElement iUnderstandCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_62']")
    private WebElement iNoLongerQualifyCheckboxLabel;

    @FindBy(how = How.ID, using = "1781-1781_62")
    private WebElement iNoLongerQualifyCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_11']")
    private WebElement iDeclareLabel;

    @FindBy(how = How.ID, using = "1781-1781_11")
    private WebElement iDeclareCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1781-1781_30']")
    private WebElement chkNativeAmerican;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_1781() {

    }

    public static Form_1781 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_1781.class);
    }

    public boolean stateOfArizonaWECLinkExists() {
        return stateOfArizonaWECFormLink.isDisplayed();
    }

    public Form_1781 chooseCompleteFormWECYesRadiobutton() {
        completeFormWECYesRadiobutton.click();
        logger.info("Complete WEC Form Yes Chosen");
        return this;
    }

    public Form_1781 chooseNativeAmerican() {
        chkNativeAmerican.click();
        logger.info("Native American checkbox selected");
        return this;
    }

    public Form_1781 chooseCompleteFormWECNoRadiobutton() {
        completeFormWECNoRadiobutton.click();
        logger.info("Complete WEC Form No Chosen");
        return this;
    }

    public Form_1781 fillRequiredFields(boolean completeWECForm, WithholdingStatus withholdingStatus) {
        if (completeWECForm) {

            chooseCompleteFormWECYesRadiobutton();
            selectWithholdingStatus(withholdingStatus.toString());
            switch (withholdingStatus) {
                case EXEMPT:
                    chooseNativeAmerican();
                    setTribalCensusNumber("1");
                    setReservationResidence("My Reservation");
                    checkTribalMembership();
                    setEmployerName("Employer Name");
                    SeleniumTest.clearAndSetText(employeeOfTextbox,"Sterling");
                    selectPleaseSelectOne(ExemptReason.EXEMPT);
                    break;
                case FULLY_SUBJECT_TO_TAXES:
                    selectPleaseSelectOne(ExemptReason.SUBJECT_TO_TAXES);
                    break;
            }
            checkIDeclare();
        } else {
            chooseCompleteFormWECNoRadiobutton();
        }
        return this;
    }

    public String getWithholdingStatus() {
        Select dropdown = new Select(withholdingStatusDropdown);
        return dropdown.getFirstSelectedOption().getText();
    }

    public Form_1781 selectWithholdingStatus(String withholdingStatus) {
        SeleniumTest.selectByVisibleTextFromDropDown(withholdingStatusDropdown, withholdingStatus);
        logger.info("Withholding Status of {} selected", withholdingStatus);
        return this;
    }

    public Form_1781 checkIDeclare() {
        SeleniumTest.check(iDeclareLabel, iDeclareCheckbox);
        logger.info("I Declare checked");
        return this;
    }

    public Form_1781 unCheckIDeclare() {
        SeleniumTest.unCheck(iDeclareLabel, iDeclareCheckbox);
        logger.info("I Declare unchecked");
        return this;
    }

    public Form_1781 checkiNoLongerQualify() {
        SeleniumTest.check(iNoLongerQualifyCheckboxLabel, iNoLongerQualifyCheckbox);
        logger.info("I No longer qualify checkbox checked");
        return this;
    }

    public Form_1781 uncheckiNoLongerQualify() {
        SeleniumTest.unCheck(iNoLongerQualifyCheckboxLabel, iNoLongerQualifyCheckbox);
        logger.info("I No longer qualify checkbox unchecked");
        return this;
    }

    public Form_1781 selectPleaseSelectOne(ExemptReason exemptReason) {

        SeleniumTest.selectByVisibleTextFromDropDown(pleaseSelectOneExemptDropdown, exemptReason.toString());

        switch (exemptReason) {
            case NATIVE_AMERICAN:
                setTribalCensusNumber("1");
                setReservationResidence("My Reservation");
                checkTribalMembership();
                setEmployerName("Employer Name");
                checkIUnderstand();
                break;
            case SPOUSE_OF_ACTIVE_DUTY:
                throw new NotImplementedException("Not yet Implemented");

            case ARIZONA_NON_RESIDENT:
                throw new NotImplementedException("Not yet Implemented");
            case EXEMPT:
                checkIUnderstand();
        }
        return this;
    }

    public Form_1781 setTribalCensusNumber(String tribalCensusNumber) {
        SeleniumTest.clearAndSetText(tribalCensusNumberTextbox, tribalCensusNumber);
        logger.info("Tribal Census number set to {}", tribalCensusNumber);
        return this;
    }

    public Form_1781 setReservationResidence(String reservationResidence) {
        SeleniumTest.clearAndSetText(reservationResidenceTextbox, reservationResidence);
        logger.info("Reservation Residence set to {}", reservationResidence);
        return this;
    }

    public Form_1781 checkTribalMembership() {
        SeleniumTest.click(tribalMembershipLabel);
        logger.info("Tribal Membership Checked");
        return this;
    }

    public Form_1781 uncheckTribalMembership() {
        SeleniumTest.unCheck(tribalMembershipLabel, tribalMembershipCheckbox);
        logger.info("Tribal Membership unchecked");
        return this;
    }

    public String getEmployerName() {
        return employerNameTextbox.getText();
    }

    public void setEmployerName(String employerName) {
        SeleniumTest.clearAndSetText(employerNameTextbox, employerName);
        logger.info("Employer name set to {}", employerName);
    }

    public Form_1781 checkIUnderstand() {
        SeleniumTest.check(iUnderstandLabel, iUnderstandCheckbox);
        logger.info("I Understand Checked");
        return this;
    }

    public Form_1781 uncheckIUnderstand() {
        SeleniumTest.unCheck(iUnderstandLabel, iUnderstandCheckbox);
        logger.info("I Understand unchecked");
        return this;
    }

    public enum ExemptReason {
        NATIVE_AMERICAN("I am a Native American"),
        SPOUSE_OF_ACTIVE_DUTY("I am the spouse of an active duty servicemember"),
        ARIZONA_NON_RESIDENT("I am an Arizona nonresident"),
        SUBJECT_TO_TAXES("Fully Subject to Taxes"),
        EXEMPT("Exempt");
        private final String text;

        ExemptReason(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    public enum WithholdingStatus {
        EXEMPT("Exempt"),
        FULLY_SUBJECT_TO_TAXES("Fully Subject to Taxes");

        private final String text;

        WithholdingStatus(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
