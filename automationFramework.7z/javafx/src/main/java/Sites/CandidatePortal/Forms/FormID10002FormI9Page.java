package Sites.CandidatePortal.Forms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;

import Sites.CandidatePortal.PortalSignInPage;
import TWFramework.SeleniumTest;
import Utility.URLParameters;
import WebDriver.Driver;

/**
 * Created by jgupta on 1/18/2016.
 */
public class FormID10002FormI9Page extends FormPage {


    @FindBy(how = How.ID, using = "10002-100_1")
    private static WebElement firstNameBox;

    @FindBy(how = How.ID, using = "10002-qmi-100_2")
    private static WebElement middleNameBox;

    @FindBy(how = How.ID, using = "10002-100_3")
    private static WebElement lastNameBox;

    @FindBy(how = How.XPATH, using = "//label[@for='10002-qmi-100_17']")
    private static WebElement middleNameCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='10002-qMaidenNameNA']")
    private static WebElement noOtherNamesCheckbox;

    @FindBy(how = How.ID, using = "10002-100_5")
    private static WebElement ssnTextBox;

    @FindBy(how = How.ID, using = "10002-100_6-qmm")
    private static WebElement monthDropDownLocator;

    @FindBy(how = How.ID, using = "10002-100_6-qdd")
    private static WebElement dayDropDownLocator;

    @FindBy(how = How.ID, using = "10002-100_6-qyy")
    private static WebElement yearDropDownLocator;

    @FindBy(how = How.ID, using = "10002-100_7")
    private static WebElement addressLineOneBox;

    @FindBy(how = How.XPATH, using = "//label[@for='10002-qunit-100_20']")
    private WebElement noAptNumberCheckbox;

    @FindBy(how = How.ID, using = "10002-address100_9-100_10")
    private static WebElement cityBox;

    @FindBy(how = How.ID, using = "10002-address100_9-100_9")
    private static WebElement countryRegionDropDown;

    @FindBy(how = How.ID, using = "10002-address100_9-100_11")
    private static WebElement stateOrProvinceDropDown;

    @FindBy(how = How.ID, using = "10002-address100_9-100_12")
    private static WebElement zipCodeBox;

    @FindBy(how = How.XPATH, using = "//label[@for='10002-qEmailAddressNA']")
    private static WebElement doNotProvideEmailCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='10002-qPhoneNumberNA']")
    private static WebElement doNotProvidePhoneNumberCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='10002-qWorkerEligibilityType_USCitizen']")
    private static WebElement usCitizenRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='10002-qCertifySigning']")
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private static WebElement saveButton;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    /**
     * Sets the first name
     * @param firstName
     * @return
     */
    public static void setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
    }

    /**
     * Sets the middle name
     * @param middleName
     * @return
     */
    public static void setMiddleName(String middleName) {
        if(middleNameCheckbox.isSelected())
            middleNameCheckbox.click();
        SeleniumTest.clearAndSetText(middleNameBox, middleName);
    }

    /**
     * Sets the last name
     * @param lastName
     * @return
     */
    public static void setlastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
    }

    /**
     * Checks the no middle name box
     * @return
     */
    public void checkNoMiddleNameBox() {
        if(!Driver.getDriver().findElement(By.id("10002-qmi-100_17")).isSelected())
            middleNameBox.click();
    }

    /**
     * Checks the no other names checkbox
     * @return
     */
    public static void checkNoOtherNames() {
        if(!Driver.getDriver().findElement(By.id("10002-qMaidenNameNA")).isSelected())
            noOtherNamesCheckbox.click();
    }

    /**
     * Sets the Social Security Number
     * @param ssn
     * @return
     */
    public static void setSocialSecurityNumber(int ssn) {
        SeleniumTest.clearAndSetText(ssnTextBox, Integer.toString(ssn));
    }

    /**
     * Sets the address line 1
     * @param address1
     * @return
     */
    public static void setStreetAddress1(String address1) {
        SeleniumTest.clearAndSetText(addressLineOneBox, address1);
    }

    /**
     * Checks the no apartment number checkbox
     * @return
     */
    public void checkNoApartmentNumberCheckbox() {
        if(!Driver.getDriver().findElement(By.xpath("//label[text()='No Apt. Number']")).isSelected())
            noAptNumberCheckbox.click();
    }

    /**
     * sets the city
     * @param city
     * @return
     */
    public static void setCity(String city) {
        SeleniumTest.clearAndSetText(cityBox, city);
    }

    /**
     * selects the country or region
     * @param countryOrRegion
     * @return
     */
    public static void selectCountryOrRegion(String countryOrRegion) {
        Select countryDropDown = new Select(countryRegionDropDown);
        countryDropDown.selectByVisibleText(countryOrRegion);
    }

    /**
     * selects the state or province
     * @param stateOrProvince
     * @return
     */
    public static void selectStateOrProvince(String stateOrProvince) {
        Select stateDropDown = new Select(stateOrProvinceDropDown);
        stateDropDown.selectByVisibleText(stateOrProvince);
    }

    /**
     * sets the zip code
     * @param zipCode
     * @return
     */
    public static void setZipCode(String zipCode) {
        SeleniumTest.clearAndSetText(zipCodeBox, zipCode);
    }

    /**
     * checks the do not provide email checkbox
     * @return
     */
    public static void checkDoNotProvideEmail() {
        if(!Driver.getDriver().findElement(By.id("10002-qEmailAddressNA")).isSelected())
            doNotProvideEmailCheckbox.click();
    }

    /**
     * checks the do not provide phone number checkbox
     * @return
     */
    public static void checkDoNotProvideTelephone() {
        if(!Driver.getDriver().findElement(By.id("10002-qPhoneNumberNA")).isSelected())
            doNotProvidePhoneNumberCheckbox.click();
    }

    /**
     * chooses US Citizen
     * @return
     */
    public static void chooseCitizenOfUnitedStates() {
        usCitizenRadiobutton.click();
    }

    /**
     * checks the I acknowledge checkbox
     * @return
     */
    public static void checkIAcknowledge() {
      if(!Driver.getDriver().findElement(By.xpath("//label[text()='I Acknowledge']")).isSelected())
      iAcknowledgeCheckbox.click();
    }

    /**
     * Clicks next
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Selects month of birth from month dropdown in Date of Birth section
     * @param month
     */
    public static void selectDobMonth(String month) {
        SeleniumTest.selectShortMonthByVisibleText(monthDropDownLocator, month);
    }

    /**
     * Selects day of birth from day dropdown in Date of Birth section
     * @param day
     */
    public static void selectDobDay(String day) {
        Select dayDropDown = new Select(dayDropDownLocator);
        dayDropDown.selectByVisibleText(day);
    }

    /**
     * Selects year of birth from year dropdown in Date of Birth section
     * @param year
     */
    public static void selectDobYear(String year) {
        Select yearDropDown = new Select(yearDropDownLocator);
        yearDropDown.selectByVisibleText(year);
    }

    /**
     * Clicks on Save button.
     */
    public static void clickSave() {
        saveButton.click();
    }

    public static PortalSignInPage signOut() {
        signOutLink.click();
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Returns task id from the url.
     * @return
     */
    public static String getTaskIDFromURL() {
        URLParameters parameters = new URLParameters();
        HashMap<String,String> valueMap = parameters.getValue(Driver.getDriver().getCurrentUrl());
        return valueMap.get("TaskID");
    }
}