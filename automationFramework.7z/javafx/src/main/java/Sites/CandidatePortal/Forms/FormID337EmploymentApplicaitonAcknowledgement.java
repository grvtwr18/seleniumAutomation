package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 11/16/2015.
 */
public class FormID337EmploymentApplicaitonAcknowledgement extends FormPage {
    @FindBy(how = How.XPATH, using = "//label[@for='337-337_4']")
    private WebElement readAndUnderstandCheckbox;

    @FindBy(how = How.ID, using = "337-previousnextbuttons-previousbutton")
    private WebElement previousButton;

    @FindBy(how = How.ID, using = "337-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "337-previousnextbuttons-savebutton")
    private WebElement saveButton;

    /**
     * Check Read and Understand Checkbox
     * @return
     */
    public FormID337EmploymentApplicaitonAcknowledgement checkReadAndUnderstandCheckbox () {
        if(!readAndUnderstandCheckbox.isSelected())
            readAndUnderstandCheckbox.click();
        return this;
    }

    /**
     * Uncheck Read and Understand Checkbox
     * @return
     */
    public FormID337EmploymentApplicaitonAcknowledgement uncheckReadAndUnderstandCheckbox () {
        if(readAndUnderstandCheckbox.isSelected())
            readAndUnderstandCheckbox.click();
        return this;
    }

    /**
     * Click Prewious Button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickPreviousButton(Class<? extends CandidatePortalPages> returnedClass) {
        previousButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Click Next Button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNextButton(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Click Save Button
     * @return
     */
    public FormID337EmploymentApplicaitonAcknowledgement clickSaveButton() {
        saveButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID337EmploymentApplicaitonAcknowledgement.class);
    }

}
