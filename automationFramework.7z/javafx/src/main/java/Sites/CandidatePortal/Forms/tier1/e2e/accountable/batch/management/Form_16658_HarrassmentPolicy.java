package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_16658_HarrassmentPolicy extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "16658-16658_4")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16658-16658_4']")
    private WebElement iAcknowledgeLabel;

    protected Logger logger = LoggerFactory.getLogger(Form_16658_HarrassmentPolicy.class);

    public Form_16658_HarrassmentPolicy checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_16658_HarrassmentPolicy uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledged Unchecked");
        return this;
    }

    public static Form_16658_HarrassmentPolicy getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16658_HarrassmentPolicy.class);
    }

}
