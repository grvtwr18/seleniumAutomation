package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * Created by Mayank.Jain on 2/15/2018.
 */
public class FormID6018DirectDepositPage extends CandidatePortalPages {

    @FindBy(how = How.CSS, using = "label[for$='6018-283_6_Checking']")
    private WebElement checkingRadioBtnLabel;

    @FindBy(how = How.CSS, using = "input[id$='6018-283_6_Checking']")
    private WebElement checkingRadioBtn;

    @FindBy(how = How.CSS, using = "label[for$='6018-283_7_Net Check']")
    private WebElement selectNetCheckLabel;

    @FindBy(how = How.CSS, using = "input[id$='6018-283_7_Net Check']")
    private WebElement selectNetCheck;

    @FindBy(how = How.ID, using = "6018-283_9")
    private WebElement bankName;

    @FindBy(how = How.ID, using = "6018-283_15")
    private WebElement name;

    @FindBy(how = How.ID, using = "6018-283_10")
    private WebElement transit;

    @FindBy(how = How.ID, using = "6018-283_11")
    private WebElement accountNumber;

    @FindBy(how = How.XPATH, using = ".//*[@id='6018-6015_129']/../label")
    private WebElement iAcknowledge;

    @FindBy(how = How.ID, using = "6018-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    public static FormID6018DirectDepositPage getInstance (){
        return PageFactory.initElements(Driver.getDriver(), FormID6018DirectDepositPage.class);
    }

    public void setCheckingaccountType() {
        SeleniumTest.check(getInstance().checkingRadioBtnLabel,getInstance().checkingRadioBtn);
    }

    public void setSelectNetCheck() {
        SeleniumTest.check(getInstance().selectNetCheckLabel,getInstance().selectNetCheck);
    }

    public void setBankNameName(String bank) {
        SeleniumTest.clearAndSetText(getInstance().bankName,bank);
    }

    public void setName(String nam) {
        SeleniumTest.clearAndSetText(getInstance().name,nam);
    }

    public void setTransit(String transitNumber) {
        SeleniumTest.clearAndSetText(getInstance().transit,transitNumber);
    }

    public void setAccountNumber(String account) {
        SeleniumTest.clearAndSetText(getInstance().accountNumber,account);
    }

    public void checkIAcknowledge() {
        SeleniumTest.click(getInstance().iAcknowledge);
    }

    public FormID1eSignPage clickNextBtn(Class<? extends FormID1eSignPage> returnedClass) {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public FormID1eSignPage fillDirectDepositDetails(Candidate candidate){
        setCheckingaccountType();
        setSelectNetCheck();
        setBankNameName("CITI");
        setName("Sterling");
        setTransit("123456789");
        setAccountNumber("1234567891234567");
        checkIAcknowledge();
        return (FormID1eSignPage) clickNextBtn(FormID1eSignPage.class);
    }

    public void fillDirectDepositDetails(){
        setCheckingaccountType();
        setSelectNetCheck();
        setBankNameName("CITI");
        setName("Sterling");
        setTransit("123456789");
        setAccountNumber("1234567891234567");
        checkIAcknowledge();
    }
}
