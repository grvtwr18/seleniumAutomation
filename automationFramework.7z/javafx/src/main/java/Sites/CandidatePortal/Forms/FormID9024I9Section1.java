package Sites.CandidatePortal.Forms;

import com.google.common.base.Predicate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by abrackett on 12/17/2015.
 */
public class FormID9024I9Section1 extends FormPage {

    @FindBy(how = How.ID, using = "9024-I9s1_1")
    private static WebElement firstNameBox;

    @FindBy(how = How.ID, using = "9024-I9s1_3_1")
    private static WebElement middleNameBox;

    @FindBy(how = How.ID, using = "9024-I9s1_2")
    private static WebElement lastNameBox;

    @FindBy(how = How.XPATH, using = "//label[@for='9024-I9s1_3NA']")
    private static WebElement middleNameCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='9024-I9s1_4NA']")
    private static WebElement noOtherNamesCheckbox;

    @FindBy(how = How.ID, using = "9024-I9s1_11")
    private static WebElement ssnBox;

    @FindBy(how = How.ID, using = "9024-I9s1_10")
    private static WebElement dobBox;

    @FindBy(how = How.ID, using = "9024-I9s1_5")
    private static WebElement addressLineOneBox;

    @FindBy(how = How.XPATH, using = "//label[@for='9024-I9s1_6NA']")
    private static WebElement noAptNumberCheckbox;

    @FindBy(how = How.ID, using = "9024-addressI9s1_7-I9s1_7")
    private static WebElement cityBox;

    @FindBy(how = How.ID, using = "9024-addressI9s1_7-I9s1_56")
    private static WebElement countryRegionDropDown;

    @FindBy(how = How.ID, using = "9024-addressI9s1_7-I9s1_8")
    private static WebElement stateOrProvinceDropDown;

    @FindBy(how = How.ID, using = "9024-addressI9s1_7-I9s1_9")
    private static WebElement zipCodeBox;

    @FindBy(how = How.XPATH, using = "//label[@for='9024-qEmailAddressNA']")
    private static WebElement doNotProvideEmailCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='9024-qPhoneNumberNA']")
    private static WebElement doNotProvidePhoneNumberCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='9024-I9s1_14_USCITIZEN']")
    private static WebElement usCitizenRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='9024-qCertifySigning']")
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.ID, using = "9024-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    /**
     * Sets the first name
     * @param firstName
     * @return
     */
    public static FormID9024I9Section1 setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Sets the middle name
     * @param middleName
     * @return
     */
    public static FormID9024I9Section1 setMiddleName(String middleName) {
        if(middleNameCheckbox.isSelected())
            middleNameCheckbox.click();
        SeleniumTest.clearAndSetText(middleNameBox, middleName);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Sets the last name
     * @param lastName
     * @return
     */
    public static FormID9024I9Section1 setlastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Checks the no middle name box
     * @return
     */
    public static FormID9024I9Section1 checkNoMiddleNameBox() {
        if(!Driver.getDriver().findElement(By.id("9024-I9s1_3NA")).isSelected())
            middleNameBox.click();
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Checks the no other names checkbox
     * @return
     */
    public static FormID9024I9Section1 checkNoOtherNames() {
        if(!Driver.getDriver().findElement(By.id("9024-I9s1_4NA")).isSelected())
            noOtherNamesCheckbox.click();
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Sets the Social Security Number
     * @param ssn
     * @return
     */
    public static FormID9024I9Section1 setSocialSecurityNumber(int ssn) {
        ssnBox.clear();
        ssnBox.sendKeys(Integer.toString(ssn));
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Sets the date of Birth
     * @param lDate
     * @return
     */
    public static FormID9024I9Section1 setDateOfBirth(LocalDate lDate) {
        String twoDigitMonth = Integer.toString(lDate.getMonthValue());
        if(1 == twoDigitMonth.length())
            twoDigitMonth = "0" + twoDigitMonth;
        String twoDigitDay = Integer.toString(lDate.getDayOfMonth());
        if(1 == twoDigitDay.length())
            twoDigitDay = "0" + twoDigitDay;
        dobBox.clear();
        dobBox.sendKeys(twoDigitMonth + "/" + twoDigitDay + "/" + Integer.toString(lDate.getYear()));
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Sets the address line 1
     * @param address1
     * @return
     */
    public static FormID9024I9Section1 setStreetAddress1(String address1) {
        SeleniumTest.clearAndSetText(addressLineOneBox, address1);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Checks the no apartment number checkbox
     * @return
     */
    public static FormID9024I9Section1 checkNoApartmentNumberCheckbox() {
        if(!Driver.getDriver().findElement(By.id("9024-I9s1_6NA")).isSelected())
            noAptNumberCheckbox.click();
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * sets the city
     * @param city
     * @return
     */
    public static FormID9024I9Section1 setCity(String city) {
        SeleniumTest.clearAndSetText(cityBox, city);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * selects the country or region
     * @param countryOrRegion
     * @return
     */
    public static FormID9024I9Section1 selectCountryOrRegion(String countryOrRegion) {
        final Select countryDropDown = new Select(countryRegionDropDown);
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(countryDropDown.getOptions().size() > 5) {
                            return true;
                        }
                        return false;
                    }
                });
        countryDropDown.selectByVisibleText(countryOrRegion);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * selects the state or province
     * @param stateOrProvince
     * @return
     */
    public static FormID9024I9Section1 selectStateOrProvince(String stateOrProvince) {
        final Select stateDropDown = new Select(stateOrProvinceDropDown);
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(stateDropDown.getOptions().size() > 5) {
                            return true;
                        }
                        return false;
                    }
                });
        stateDropDown.selectByVisibleText(stateOrProvince);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * sets the zip code
     * @param zipCode
     * @return
     */
    public static FormID9024I9Section1 setZipCode(String zipCode) {
        SeleniumTest.clearAndSetText(zipCodeBox, zipCode);
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * checks the do not provide email checkbox
     * @return
     */
    public static FormID9024I9Section1 checkDoNotProvideEmail() {
        if(!Driver.getDriver().findElement(By.id("9024-qEmailAddressNA")).isSelected())
            doNotProvideEmailCheckbox.click();
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * checks the do not provide phone number checkbox
     * @return
     */
    public static FormID9024I9Section1 checkDoNotProvideTelephone() {
        if(!Driver.getDriver().findElement(By.id("9024-qPhoneNumberNA")).isSelected())
            doNotProvidePhoneNumberCheckbox.click();
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * chooses US Citizen
     * @return
     */
    public static FormID9024I9Section1 chooseCitizenOfUnitedStates() {
        usCitizenRadiobutton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * checks the I acknowledge checkbox
     * @return
     */
    public static FormID9024I9Section1 checkIAcknowledge() {
        if(!Driver.getDriver().findElement(By.id("9024-qCertifySigning")).isSelected())
            iAcknowledgeCheckbox.click();
        return PageFactory.initElements(Driver.getDriver(), FormID9024I9Section1.class);
    }

    /**
     * Clicks next
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

}
