package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.FormID1eSignPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StateConfirmationForm extends CandidatePortalPages {

    protected static final Logger staticLogger = LoggerFactory.getLogger(StateConfirmationForm.class);

    /*private static final String labelValue = "1911-1911_3";
    @FindBy(how = How.XPATH,using = "//label[@for='"+labelValue+"']")*/
    @FindBy(how = How.XPATH,using = "//label[text()='I Confirm']")
    private WebElement iConfirmCheckbox;

    @FindBy(how = How.XPATH,using = "//*[@class='errorText']")
    private WebElement iConfirmCheckboxError;

    @FindBy(how = How.XPATH, using = "//*[@fieldname='Residency Statement']")
    private WebElement residencyStatementDropDown;

    @FindBy(how = How.XPATH, using = "//*[@fieldname='Employment Statement']")
    private WebElement employmentStatementDropDown;

    @FindBy(how = How.XPATH, using = "//*[@value='Next']")
    private WebElement NextButton;

    @FindBy(how = How.XPATH, using = "//*[@value='Previous']")
    private WebElement PreviousButton;

    @FindBy(how = How.XPATH, using = "//*[@value='Save']")
    private WebElement SaveButton;

    @FindBy(how = How.XPATH, using = "//*[@class='taskNav']//div[3]//a[2]")
    private WebElement LeftHandSideStateConfirmationLink;

    @FindBy(how = How.XPATH, using = "//*[@class='taskNav']//div[4]//a[2]")
    private WebElement LeftHandSideEsignFormLink;

    public CandidatePortalPages NavigatetoEsignFormSection(Class<? extends CandidatePortalPages> returnedClass)
    {
        SeleniumTest.click(LeftHandSideEsignFormLink);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public void NavigateToStateConfirmationSection()
    {
        SeleniumTest.click(LeftHandSideStateConfirmationLink);
    }

    public boolean isErrorForMandatoryFieldsVisible()
    {
        /*WebDriverWait wait = new WebDriverWait(Driver.getDriver(), 10);
        WebElement flag = wait.until(ExpectedConditions.visibilityOf(iConfirmCheckboxError));*/
        if(SeleniumTest.isElementVisibleNoWaiting(By.xpath("//*[contains(@src,'error.png')]")))
        //if(flag!=null)
        {
            staticLogger.info("Error is displayed as mandatory fields of form are not updated");
            return true;
        }
        else
        {
            staticLogger.info("Error not present");
            return false;
        }
    }

    public void clickNext()
    {
        SeleniumTest.click(NextButton);
    }
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        SeleniumTest.click(NextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public String selectResidencyStatement(String statement, String strStateName)
    {
        String strStatement = statement+" "+strStateName;
        SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropDown,strStatement);
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(residencyStatementDropDown);
    }

    public String selectEmployementStatement(String statement, String strStateName)
    {
        String strStatement;
        if(statement.contains("state"))
        {
            strStatement = statement;
        }
        else {
            strStatement = statement+" "+strStateName;
        }
        SeleniumTest.selectByVisibleTextFromDropDown(employmentStatementDropDown,strStatement);
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(employmentStatementDropDown);
    }

    public void fillformDetails(String stateName,String residencyStatement, String workStatement)
    {
        selectEmployementStatement(workStatement,stateName);
        selectResidencyStatement(residencyStatement,stateName);
        //clickNext();
    }

    public void checkIConfirm()
    {
        SeleniumTest.click(iConfirmCheckbox);
    }

    public void clickPrevious()
    {
        SeleniumTest.click(PreviousButton);
    }
}
