package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 10/21/16.
 */
public class Form_17063 {

    static {
        PageFactory.initElements(Driver.getDriver(), Form_17063.class);
    }



    public static class Section1 extends Sites.CandidatePortal.Forms.Objects.I9.Section1 {

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_15']")
        private static WebElement lawfulPermanentResidentSpan;

        public static String getLawfulPermanentResidentNumber() {
            return lawfulPermanentResidentSpan.getText();
        }

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_16']")
        private static WebElement AlienAuthorizationExpirationSpan;

        public static String getAlienAuthorizationExpirationDate() {
            return AlienAuthorizationExpirationSpan.getText();
        }

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_17']")
        private static WebElement AlienRegistrationNumberSpan;

        public static String getAlienRegistrationNumber() {
            return AlienRegistrationNumberSpan.getText();
        }

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_18']")
        private static WebElement i94AdmissionNumberSpan;

        public static String getI94AdmissionNumber() {
            return i94AdmissionNumberSpan.getText();
        }

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_19']")
        private static WebElement foreignPassportNumberSpan;

        public static String getForeignPassportNumber() {
            return foreignPassportNumberSpan.getText();
        }

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_20']")
        private static WebElement countryOfIssuanceSpan;

        public static String getCountryOfIssuance() {
            return countryOfIssuanceSpan.getText();
        }
    }

    public static class PreparerOrTranslatorCertification {
        static {
            PageFactory.initElements(Driver.getDriver(), PreparerOrTranslatorCertification.class);
        }

    }

    public static class Section2 extends Sites.CandidatePortal.Forms.Objects.I9.Section2 {

    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {

    }
}
