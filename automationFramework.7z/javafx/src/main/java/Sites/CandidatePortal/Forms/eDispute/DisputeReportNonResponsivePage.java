package Sites.CandidatePortal.Forms.eDispute;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.eDispute.DisputeEnums.ReasonForDisputeEducation;
import Sites.CandidatePortal.Forms.eDispute.DisputeEnums.ReasonForDisputeEmployment;
import Sites.CandidatePortal.Forms.eDispute.DisputeEnums.ReasonForDisputeMvr;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 11/4/2017.
 */
public class DisputeReportNonResponsivePage extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//div[@id='portalContent']/div/table/tbody/tr[2]/td")
    private static WebElement disclosureSecondParagraph;

    static {
        PageFactory.initElements(Driver.getDriver(), DisputeReportNonResponsivePage.class);
    }

    public static void selectReasonForDisputeEducationProductLine(int reasonForDisputeButtonIndex,
            ReasonForDisputeEducation reasonForDispute) {
        clickReasonForDispute(reasonForDisputeButtonIndex);
        SeleniumTest.click(By.cssSelector("input[value='" + reasonForDispute.getValue() + "']"));
    }

    public static void selectReasonForDisputeMvrProductLine(int reasonForDisputeButtonIndex,
            ReasonForDisputeMvr reasonForDispute) {
        clickReasonForDispute(reasonForDisputeButtonIndex);
        SeleniumTest.click(By.cssSelector("input[value='" + reasonForDispute.getValue() + "']"));
    }

    public static void selectReasonForDisputeEmploymentProductLine(int reasonForDisputeButtonIndex,
            ReasonForDisputeEmployment reasonForDispute) {
        clickReasonForDispute(reasonForDisputeButtonIndex);
        SeleniumTest.click(By.cssSelector("input[value='" + reasonForDispute.getValue() + "']"));
    }

    public static void clickReasonForDispute(int reasonForDisputeButtonIndex) {
        SeleniumTest.click(By.xpath("(//button[@type='button'])[" + reasonForDisputeButtonIndex + "]"));
    }

    public static void typeAdditionalComments(int textAreaIndex, String additionalComments) {
        SeleniumTest.clearAndSetText(By.xpath("(//textarea)[" + textAreaIndex + "]"), additionalComments);
    }

    public static void clickNextButton(int buttonIndex) {
        SeleniumTest.click(By.xpath("(//button[@type='button'])[" + buttonIndex + "]"));
    }

    public static String getEdisputeDisclosureSecondParagraph() {
        return disclosureSecondParagraph.getText();
    }


}
