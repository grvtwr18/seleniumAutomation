package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by jgupta on 10/19/2017.
 */
public class AttachmentViewerPage extends CandidatePortalPages {
    @FindBy(how = How.ID, using = "div4img")
    private static WebElement document;

    public static WebElement getDocumentLocator() {
        return document;
    }

}
