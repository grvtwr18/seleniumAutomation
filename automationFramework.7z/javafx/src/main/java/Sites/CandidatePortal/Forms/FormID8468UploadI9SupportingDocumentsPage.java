package Sites.CandidatePortal.Forms;

import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by abrackett on 12/17/2015.
 */
public class FormID8468UploadI9SupportingDocumentsPage extends FormPage {

    private static final Logger logger = LoggerFactory.getLogger("Sites.CandidatePortal.Forms.FormID8468UploadI9SupportingDocumentsPage");

    @FindBy(how = How.XPATH, using = "//label[@for='8468-310_15_List A']")
    private static WebElement listARadiobutton;

    private static final String filePathBoxLocatorString = "8468-310_3-filebrowse";
    By filePathBoxLocator = By.id(filePathBoxLocatorString);
    @FindBy(how = How.ID, using = filePathBoxLocatorString)
    private static WebElement filePathBox;

    @FindBy(how = How.CLASS_NAME, using = "btnPostFileToServer")
    private static WebElement uploadFileButton;

    @FindBy(how = How.XPATH, using = "//label[@for='8468-310_9']")
    private static WebElement iAcknowledgeCheckbox;

    private static final String listADocumentTitleID = "8468-311_4";
    By listALocator = By.id(listADocumentTitleID);
    @FindBy(how = How.ID, using = listADocumentTitleID)
    private static WebElement listADropDown;

    @FindBy(how = How.ID, using = "8468-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    /**
     * choose List A Radio Button
     * @return
     */
    public static FormID8468UploadI9SupportingDocumentsPage chooseListA() {
        if(!listARadiobutton.isSelected())
            listARadiobutton.click();
        SeleniumTest.waitForElementVisible(By.id("8468-311_4"));
        return PageFactory.initElements(Driver.getDriver(), FormID8468UploadI9SupportingDocumentsPage.class);
    }

    /**
     * select List A Document
     * @param document
     * @return
     */
    public static FormID8468UploadI9SupportingDocumentsPage selectListADocument(String document) {
        Select listADocument = new Select(listADropDown);
        listADocument.selectByVisibleText(document);
        return PageFactory.initElements(Driver.getDriver(), FormID8468UploadI9SupportingDocumentsPage.class);
    }

    /**
     * Sets the file to upload
     * @param filePath
     * @return
     */
    public static FormID8468UploadI9SupportingDocumentsPage setFileToUpload(String filePath) {
        if(OS.isFamilyWindows())
            filePath = filePath.replace('/', '\\');
        ((JavascriptExecutor)Driver.getDriver()).executeScript("document.getElementById('" + filePathBox.getAttribute("id") + "').style.visibility = 'visible';");
        if(!filePath.startsWith("/") && !filePath.contains(":")) {
            filePath = "/" + filePath;
        }
        logger.debug("File to upload path is {}", filePath);
        filePathBox.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(uploadFileButton, 10);
        return PageFactory.initElements(Driver.getDriver(), FormID8468UploadI9SupportingDocumentsPage.class);
    }

    /**
     * Clicks the upload file button
     * @return
     */
    public static FormID8468UploadI9SupportingDocumentsPage clickUploadFile() {
        uploadFileButton.click();
        SeleniumTest.waitForElementToBeClickable(By.xpath("//label[text()='Previously Uploaded:']"), 60);
        return PageFactory.initElements(Driver.getDriver(), FormID8468UploadI9SupportingDocumentsPage.class);
    }

    /**
     * checks the I acknowledge checkbox
     * @return
     */
    public static FormID8468UploadI9SupportingDocumentsPage checkIAcknowledgeCheckbox() {
        if(!(Driver.getDriver().findElement(By.id("8468-310_9")).isSelected()))
            iAcknowledgeCheckbox.click();
        return PageFactory.initElements(Driver.getDriver(), FormID8468UploadI9SupportingDocumentsPage.class);
    }

    /**
     * Clicks Next Button
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

}
