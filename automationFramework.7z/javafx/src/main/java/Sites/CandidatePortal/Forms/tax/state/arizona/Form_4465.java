package Sites.CandidatePortal.Forms.tax.state.arizona;

import Data.locations.us.UsStateTerritory;
import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_4465 extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "4465-100_1")
    private WebElement firstName;

    @FindBy(how = How.ID, using = "4465-100_18")
    private WebElement middleInitial;

    @FindBy(how = How.ID, using = "4465-100_3")
    private WebElement lastName;

    @FindBy(how = How.ID, using = "4465-100_5")
    private WebElement ssn;

    @FindBy(how = How.ID, using = "4465-100_7")
    private WebElement addressLine1;

    @FindBy(how = How.ID, using = "4465-100_8")
    private WebElement apartmentNumber;

    @FindBy(how = How.ID, using = "4465-100_10")
    private WebElement city;

    @FindBy(how = How.ID, using = "4465-100_11")
    private WebElement state;

    @FindBy(how = How.ID, using = "4465-100_12")
    private WebElement zip;

    @FindBy(how = How.XPATH, using = "//input[@id='4465-1781_30']")
    private WebElement nativeAmericanExemption;

    @FindBy(how = How.XPATH, using = "//span[@id='4465-1781_31']")
    private WebElement tribalCensusNumber;

    @FindBy(how = How.XPATH, using = "//span[@id='4465-1781_32']")
    private WebElement reservationName;

    @FindBy(how = How.XPATH, using = "//span[@id='4465-1781_34']")
    private WebElement employerName;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_4465() {

    }

    public static Form_4465 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_4465.class);
    }

    public String getFirstName() {
        return firstName.getText();
    }

    public String getMiddleInitial() {
        return middleInitial.getText();
    }

    public String getLastName() {
        return lastName.getText();
    }

    public String getSsn() {
        return ssn.getText();
    }

    public String getAddressLine1() {
        return addressLine1.getText();
    }

    public String getApartmentNumber() {
        return apartmentNumber.getText();
    }

    public String getCity() {
        return city.getText();
    }

    public UsStateTerritory getState() {
        return UsStateTerritory.parse(state.getText());
    }

    public String getZip() {
        return zip.getText();
    }

    public boolean nativeAmericanExemptionChecked() {
        String attr = nativeAmericanExemption.getAttribute("checked");
        if (attr.equals("true")) {
            return true;
        }
        return false;
    }

    public String getTribalCensusNumber() {
        return tribalCensusNumber.getText();
    }

    public String getReservationName() {
        return reservationName.getText();
    }

    public String getEmployerName() {
        return employerName.getText();
    }
}
