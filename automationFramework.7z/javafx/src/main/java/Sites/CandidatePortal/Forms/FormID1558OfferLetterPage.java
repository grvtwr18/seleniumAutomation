package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/17/2015.
 */
public class FormID1558OfferLetterPage extends FormPage {
    @FindBy(how = How.ID, using = "1558-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * Clicks Next Button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
