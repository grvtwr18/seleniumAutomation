package Sites.CandidatePortal.Forms.Objects;

import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by abrackett on 10/21/16.
 */
public class TwESign {

    static {
        PageFactory.initElements(Driver.getDriver(), TwESign.class);
    }

    private static final Logger staticLogger = LoggerFactory.getLogger(TwESign.class);

    public static class Signature {

        static {
            PageFactory.initElements(Driver.getDriver(), Signature.class);
        }

        public static String getSignatureImageSrc(Integer... index) {
            Integer internalIndex = index != null && index.length > 0 ? index[0] : 0;
            return Driver.getDriver().findElements(By.id("signature")).get(internalIndex).findElement(By.xpath(".//img")).getAttribute("src");
        }

        public static String getSignDate(Integer... index) {
            Integer internalIndex = index != null && index.length > 0 ? index[0] : 0;
            return Driver.getDriver().findElements(By.id("signature")).get(internalIndex).findElement(By.id("sign-date")).getText();
        }

        public static String getSignTime(Integer... index) {
            Integer internalIndex = index != null && index.length > 0 ? index[0] : 0;
            return Driver.getDriver().findElements(By.id("signature")).get(internalIndex).findElement(By.id("sign-time")).getText();
        }

        public static String getSignId(Integer... index) {
            Integer internalIndex = index != null && index.length > 0 ? index[0] : 0;
            return Driver.getDriver().findElements(By.id("signature")).get(internalIndex).findElement(By.id("sign-id")).getText();
        }

        public static String getSignIP(Integer... index) {
            Integer internalIndex = index != null && index.length > 0 ? index[0] : 0;
            return Driver.getDriver().findElements(By.id("signature")).get(internalIndex).findElement(By.id("sign-ip")).getText();
        }

        public static boolean getSignatureMetaData(String[] metaData, Integer... index){
            Integer internalIndex = index != null && index.length > 0 ? index[0] : 0;
            boolean flag = false;
            for(int i=0;i<metaData.length;i++) {
                flag = Driver.getDriver().findElements(By.id("signature")).get(internalIndex).findElement(By.id(metaData[i])).isDisplayed();
                if(flag == false){
                    staticLogger.info("Signature metadata didn't match");
                    return flag;
                }
            }
            return flag;
        }
    }

    public static class Date {

        static {
            PageFactory.initElements(Driver.getDriver(), Date.class);
        }

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_22']")
        private static WebElement dateSignedSpan;

        public static String getDateSigned() {
            return dateSignedSpan.findElement(By.xpath(".//div[contains(@class,'datesigned-')]"))
                    .getText();
        }
    }
}
