package Sites.CandidatePortal.Forms;

import Sites.AdminConsole.AdminHomePage;
import Sites.AdminConsole.CustomerSupport.ScreeningSupport.RequestQueue.RequestDetailPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Vivek.Rai on 4/18/2018.
 * This page has the details about the process request.
 * e.g Education verification process request
 */
public class ProcessRequestForm extends AdminHomePage{

    @FindBy(how= How.XPATH ,using="//*[@class='checkBoxContainerLeft']/input[@value='Manual']")
    private WebElement checkBoxRunManualSearch;

    @FindBy(how= How.XPATH ,using="//*[@class='checkBoxContainerLeft']/input[@value='Search']")
    private WebElement checkBoxSearchListedSchool;

    @FindBy(how= How.XPATH ,using="//*[@id='PreProcessingForm']//button[text()='Search']")
    private WebElement searchBtn;

    @FindBy(how= How.XPATH ,using="//*[@id='PreProcessingForm']//div[starts-with(text(),'Results for')]")
    private WebElement heading;

    @FindBy(how= How.XPATH ,using="//*[@id='PreProcessingForm']//td[2]//strong")
    private List<WebElement> resultsTextList;

    @FindBy(how= How.XPATH ,using="//button[@onclick='$(\"#schoolCode\").val(\"2128\"); $(\"#schoolName\").val(\"BOSTON COLLEGE\"); $(\"#PreProcessingForm\").submit()']")
    private WebElement processButtonForBostonCollege;

    private final String xpathSchoolName="//*[@id='PreProcessingForm']//td[2]//strong[text()='%s']";

    private final String gordonConwellThLogicalSchoolName="//button[@onclick='$(\"#schoolCode\").val(\"%d\"); $(\"#schoolName\").val(\"%s\"); $(\"#PreProcessingForm\").submit()']/../preceding-sibling::td/strong";


    public ProcessRequestForm(){

        PageFactory.initElements(Driver.getDriver(),this);
    }


    //To click on radio button Run Manual Search
    public void clickCheckBoxRunManualSearch(){
        SeleniumTest.click(checkBoxRunManualSearch);
    }

    //To click on radio button Search Listed Schools
    public void clickCheckBoxSearchListedSchool(){
        SeleniumTest.click(checkBoxSearchListedSchool);
    }

    //To click on Search button
    public RequestDetailPage clickSearchBtn(){
        SeleniumTest.click(searchBtn);
        return PageFactory.initElements(Driver.getDriver(),RequestDetailPage.class);
    }

    //to get Heading of the form
    public String getHeading(){
        return SeleniumTest.getText(heading);
    }

    //To get the all the result
    public List<String> getAllTheResults(){
        List<String> resultTexts=new ArrayList<>();
        for(int i=0;i<resultsTextList.size();i++){
            resultTexts.add(resultsTextList.get(i).getText());
        }
        return resultTexts;
    }

    //Check if checkBoxSearchListedSchool is already checked
    public boolean isCheckBoxSearchListedSchoolChecked(){
        return SeleniumTest.isCheckboxChecked(checkBoxSearchListedSchool);
    }

    //Click on Process button Boston College
    public void clickProcessBtnBostonCollege(){
        SeleniumTest.click(processButtonForBostonCollege);
    }

    //Validate if the school name is available on Section Process Request form on Admin Page
    public boolean isSchoolFound(String schoolName){
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath(String.format(xpathSchoolName, schoolName)));
    }

    public String getSchoolNameByValue(int schoolCode,String schoolValue){
       return SeleniumTest.getTextByLocator(By.xpath(String.format(gordonConwellThLogicalSchoolName, schoolCode,schoolValue)));
    }
}

