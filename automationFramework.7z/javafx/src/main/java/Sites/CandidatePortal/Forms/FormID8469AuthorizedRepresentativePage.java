package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/22/2015.
 */
public class FormID8469AuthorizedRepresentativePage extends FormPage {
    @FindBy(how = How.XPATH, using = "//label[@for='8469-311_47_DocumentsMatch']")
    private WebElement documentsMatchRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='8469-311_47_EditsRequired']")
    private WebElement editsRequiredRadiobutton;

    @FindBy(how = How.ID, using = "8469-I9s2_44")
    private WebElement firstNameBox;

    @FindBy(how = How.ID, using = "8469-I9s2_43")
    private WebElement lastNameBox;

    String iAttestID = "8469-311_999";
    By iAttestCheckboxLocator = By.id(iAttestID);
    @FindBy(how = How.XPATH, using = "//label[@for='8469-311_999']")
    private WebElement iAttestCheckbox;

    String iAttestSecondBoxID = "8469-I9s2_40";
    By iAttestSecondCheckboxLocator = By.id(iAttestSecondBoxID);
    @FindBy(how = How.XPATH, using = "//label[@for='8469-I9s2_40']")
    private WebElement iAttestSecondCheckbox;

    @FindBy(how = How.ID, using = "8469-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * choose Documents match
     * @return
     */
    public FormID8469AuthorizedRepresentativePage chooseDocumentsMatch() {
        documentsMatchRadiobutton.click();
        return this;
    }

    /**
     * choose Edits required
     * @return
     */
    public FormID8469AuthorizedRepresentativePage chooseEditsRequired() {
        editsRequiredRadiobutton.click();
        return this;
    }

    /**
     * set First Name
     * @param firstName
     * @return
     */
    public FormID8469AuthorizedRepresentativePage setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
        return this;
    }

    /**
     * set Last Name
     * @param lastName
     * @return
     */
    public FormID8469AuthorizedRepresentativePage setLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
        return this;
    }

    /**
     * checks I Attest Box #1
     * @return
     */
    public FormID8469AuthorizedRepresentativePage checkIAttest() {
        if(!Driver.getDriver().findElement(iAttestCheckboxLocator).isSelected())
            iAttestCheckbox.click();
        return this;
    }

    /**
     * checks I Attest Box #2
     * @return
     */
    public FormID8469AuthorizedRepresentativePage checkIAttestBox2() {
        if(!Driver.getDriver().findElement(iAttestSecondCheckboxLocator).isSelected())
            iAttestSecondCheckbox.click();
        return this;
    }

    /**
     * clicks Next Button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
