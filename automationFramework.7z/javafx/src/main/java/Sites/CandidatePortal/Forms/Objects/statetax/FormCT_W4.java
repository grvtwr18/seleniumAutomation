package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 8/3/17.
 */
public class FormCT_W4 extends CandidatePortalPages {

    @FindBy(how = How.CSS, using = "label[for$='1786_18']")
    private WebElement iDeclareLabel;

    @FindBy(how = How.CSS, using = "input[id$='1786_18']")
    private WebElement iDeclareCheckbox;

    public static FormCT_W4 getInstance() {
        return PageFactory.initElements(Driver.getDriver(), FormCT_W4.class);
    }

    public FormCT_W4 checkIDeclare() {
        SeleniumTest.check(iDeclareLabel, iDeclareCheckbox);
        return this;
    }

    public FormCT_W4 uncheckIDeclare() {
        SeleniumTest.unCheck(iDeclareLabel, iDeclareCheckbox);
        return this;
    }

    public FormCT_W4NA clickNext() {
        return (FormCT_W4NA)Sites.CandidatePortal.Forms.Objects.Navigation
                .clickNext(FormCT_W4NA.class);
    }
}
