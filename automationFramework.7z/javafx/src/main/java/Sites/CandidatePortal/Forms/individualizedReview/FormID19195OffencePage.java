package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import org.openqa.selenium.By;

/**
 * This file contains supporting methods for Offence page displayed in IR workflow.
 * Created by jgupta on 10/1/2017.
 */
public class FormID19195OffencePage extends IrWorkflowPages {

    public static void typeAdditionalInformation(int index, String additionalInformation) {
        SeleniumTest.clearAndSetText(By.id
                ("19195-history-1-19195_3-19195_3_" + index), additionalInformation);
    }

    public static void typeNatureOfOffence(int index, String natureOfOffence) {
        SeleniumTest.clearAndSetText(By.id
                ("19195-history-1-19195_3-19195_5_" + index), natureOfOffence);
    }

    public static void typeLevelOfOffence(int index, String levelOfOffence) {
        SeleniumTest.clearAndSetText(By.id
                ("19195-history-1-19195_3-19195_6_" + index), levelOfOffence);
    }

    public static void typeTimeOfOffence(int index, String timeOfOffence) {
        SeleniumTest.clearAndSetText(By.id
                ("19195-history-1-19195_3-19195_13_" + index), timeOfOffence);
    }

    public static void typeAgeAtConviction(int index, String ageAtConviction) {
        SeleniumTest.clearAndSetText(By.id
                ("19195-history-1-19195_3-19195_7_" + index), ageAtConviction);
    }

    public static void typeAgeAtRelease(int index, String ageAtRelease) {
        SeleniumTest.clearAndSetText(By.id
                ("19195-history-1-19195_3-19195_15_" + index), ageAtRelease);
    }

    public static void typeNumberOfCharges(int index, String typeNumberOfCharges) {
        SeleniumTest.clearAndSetText(By.id
                ("19195-history-1-19195_3-19195_10_" + index), typeNumberOfCharges);
    }

    /**
     * Fills the form for offence information.
     */
    public static void fillOffenceForm(int index, String additionalInformation, String natureOfOffence, String levelOfOffence,
                                       String timeOfOffence, String ageAtConviction, String ageAtRelease, String numberOfCharges) {
        FormID19195OffencePage.typeAdditionalInformation(index, additionalInformation);
        FormID19195OffencePage.typeNatureOfOffence(index, natureOfOffence);
        FormID19195OffencePage.typeLevelOfOffence(index, levelOfOffence);
        FormID19195OffencePage.typeTimeOfOffence(index, timeOfOffence);
        FormID19195OffencePage.typeAgeAtConviction(index, ageAtConviction);
        FormID19195OffencePage.typeAgeAtRelease(index, ageAtRelease);
        FormID19195OffencePage.typeNumberOfCharges(index, numberOfCharges);
    }

    public static CandidatePortalPages fillOffenceFormAndSubmit(int index, String additionalInformation, String natureOfOffence, String levelOfOffence, String timeOfOffence,
                                                                String ageAtConviction, String ageAtRelease, String numberOfCharges,
                                                                Class<? extends CandidatePortalPages> returnedClass) {
        fillOffenceForm(index, additionalInformation, natureOfOffence, levelOfOffence, timeOfOffence, ageAtConviction, ageAtRelease, numberOfCharges);
        return FormID19195OffencePage.clickNext(returnedClass);
    }

}
