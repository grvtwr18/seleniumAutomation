package Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow;

import Data.locations.us.UsStateTerritory;
import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.Objects.I9.Section1;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * The second candidate form in three step I-9 (FS 4577)
 */
public class ThreeStepSection1Data extends CandidatePortalPages {

    static {
        PageFactory.initElements(Driver.getDriver(), ThreeStepSection1Data.class);
    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {}

    // region Locators

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_1']")
    private static WebElement firstNameTextBox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_3_1']")
    private static WebElement middleNameTextBox;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_3NA']")
    private static WebElement noMiddleNameLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_3NA']")
    private static WebElement noMiddleNameCheckbox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_2']")
    private static WebElement lastNameTextBox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_4_1']")
    private static WebElement otherNamesTextBox;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_4NA']")
    private static WebElement noOtherNamesLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_4NA']")
    private static WebElement noOtherNamesCheckbox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_11']")
    private static WebElement ssnTextBox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_10']")
    private static WebElement dobTextBox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_5']")
    private static WebElement addressTextBox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_6_1']")
    private static WebElement aptNumberTextBox;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_6NA']")
    private static WebElement noAptNumberLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_6NA']")
    private static WebElement noAptNumberCheckbox;

    @FindBy(how = How.CSS, using = "input[id$='-addressI9s1_7-I9s1_7']")
    private static WebElement cityTextBox;

    @FindBy(how = How.CSS, using = "select[id$='-addressI9s1_7-I9s1_56']")
    private static WebElement countryRegionDropDown;

    @FindBy(how = How.CSS, using = "select[id$='-addressI9s1_7-I9s1_8']")
    private static WebElement stateOrProvinceDropDown;

    @FindBy(how = How.CSS, using = "input[id$='-addressI9s1_7-I9s1_9']")
    private static WebElement zipCodeTextBox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_12_1']")
    private static WebElement emailTextBox;

    @FindBy(how = How.CSS, using = "label[for$='-qEmailAddressNA']")
    private static WebElement doNotProvideEmailLabel;

    @FindBy(how = How.CSS, using = "input[id$='-qEmailAddressNA']")
    private static WebElement doNotProvideEmailCheckbox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_13_1']")
    private static WebElement phoneNumberTextBox;

    @FindBy(how = How.CSS, using = "label[for$='-qPhoneNumberNA']")
    private static WebElement doNotProvidePhoneNumberLabel;

    @FindBy(how = How.CSS, using = "input[id$='-qPhoneNumberNA']")
    private static WebElement doNotProvidePhoneNumberCheckbox;

    @FindBy(how = How.CSS, using = "label[for$='-qCertifySigning']")
    private static WebElement iAcknowledgeLabel;

    @FindBy(how = How.CSS, using = "input[id$='-qCertifySigning']")
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how= How.XPATH, using = "//input[@id='19604-I9s1_19_1']")
    private static WebElement txtForeignPassportNumber;

    @FindBy(how= How.XPATH, using = "//input[@id='19604-I9s1_16_1-I9s1_16_1']")
    private static WebElement dtExpiration;
    // endregion

    public static void setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameTextBox, firstName);
    }

    public static void setMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameTextBox, middleName);
    }

    public static void checkNoMiddleNameBox() {
        if(noMiddleNameCheckbox.isSelected()) {
            noMiddleNameLabel.click();
        }
    }

    public static void uncheckNoMiddleNameBox() {
        if(!noMiddleNameCheckbox.isSelected()) {
            noMiddleNameLabel.click();
        }
    }

    public static void setlastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameTextBox, lastName);
    }

    public static void setOtherName(String otherName) {
        SeleniumTest.clearAndSetText(otherNamesTextBox, otherName);
    }

    public static void checkNoOtherNameBox() {
        if(noOtherNamesCheckbox.isSelected()) {
            noOtherNamesLabel.click();
        }
    }

    public static void uncheckNoOtherNameBox() {
        if(!noOtherNamesCheckbox.isSelected()) {
            noOtherNamesLabel.click();
        }
    }

    public static void setSocialSecurityNumber(String ssn) {
        SeleniumTest.clearAndSetText(ssnTextBox, ssn);
    }

    public static void setDateOfBirth(LocalDate lDate) {
        SeleniumTest.clearAndSetText(
                dobTextBox,
                lDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))
        );
    }

    public static void setStreetAddress(String address) {
        SeleniumTest.clearAndSetText(addressTextBox, address);
    }

    public static void setAptNumberName(String aptNumber) {
        SeleniumTest.clearAndSetText(aptNumberTextBox, aptNumber);
    }

    public static void checkNoAptNumberBox() {
        if(noAptNumberCheckbox.isSelected()) {
            noAptNumberLabel.click();
        }
    }

    public static void uncheckNoAptNumberBox() {
        if(!noAptNumberCheckbox.isSelected()) {
            noAptNumberLabel.click();
        }
    }

    public static void setCity(String city) {
        SeleniumTest.clearAndSetText(cityTextBox, city);
    }

    public static void selectCountryOrRegion(String countryOrRegion) {
        SeleniumTest.selectByVisibleTextFromDropDown(countryRegionDropDown, countryOrRegion);
    }

    public static void setExpirationDate(String date){
        dtExpiration.sendKeys(date);
    }

    public static void setForeignPassportNumber(String number){
       SeleniumTest.clearAndSetText(txtForeignPassportNumber,number);
    }
    public static void selectStateOrProvince(UsStateTerritory state) {
        SeleniumTest.selectByVisibleTextFromDropDown(
                stateOrProvinceDropDown, state.getFullName());
    }

    public static void selectStateOrProvince(String state) {
        SeleniumTest.selectByVisibleTextFromDropDown(
                stateOrProvinceDropDown, state);
    }

    public static void setZipCode(String zipCode) {
        SeleniumTest.clearAndSetText(zipCodeTextBox, zipCode);
    }


    public static void setEmail(String email) {
        SeleniumTest.clearAndSetText(emailTextBox, email);
    }

    public static void checkNoEmailBox() {
        if(doNotProvideEmailCheckbox.isSelected()) {
            doNotProvideEmailLabel.click();
        }
    }

    public static void uncheckNoEmailBox() {
        if(!doNotProvideEmailCheckbox.isSelected()) {
            doNotProvideEmailLabel.click();
        }
    }

    public static void setPhoneNumber(String phoneNumber) {
        SeleniumTest.clearAndSetText(phoneNumberTextBox, phoneNumber);
    }

    public static void checkNoPhoneNumberBox() {
        if(doNotProvidePhoneNumberCheckbox.isSelected()) {
            doNotProvidePhoneNumberLabel.click();
        }
    }

    public static void uncheckNoPhoneNumberBox() {
        if(!doNotProvidePhoneNumberCheckbox.isSelected()) {
            doNotProvidePhoneNumberLabel.click();
        }
    }

    public static void checkIAcknowledge() {
        if(!iAcknowledgeCheckbox.isSelected()) {
            iAcknowledgeLabel.click();
        }
    }

    public static void uncheckIAcknowledge() {
        if(iAcknowledgeCheckbox.isSelected()) {
            iAcknowledgeLabel.click();
        }
    }

    public static class CitizenAttestation extends Section1.CitizenAttestation {
        static {
            PageFactory.initElements(Driver.getDriver(), CitizenAttestation.class);
        }
    }
}
