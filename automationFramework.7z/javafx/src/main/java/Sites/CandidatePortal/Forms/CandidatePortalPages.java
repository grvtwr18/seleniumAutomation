package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.PortalSignInPage;
import Sites.Pages;
import Sites.Site;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by abrackett on 10/29/2015.
 */
public class CandidatePortalPages extends Pages {
    @FindBy(how = How.XPATH, using = "//a[@href='ptl/signout.php']")
    private static WebElement signOutLink;

    protected final static Logger staticLogger = LoggerFactory.getLogger("CandidatePortalPages");

    static {
        PageFactory.initElements(Driver.getDriver(), CandidatePortalPages.class);
    }

    public static PortalSignInPage signOut() {
        SeleniumTest.waitForElementEnabled(signOutLink);
        signOutLink.click();
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Attempts to make sure the Dashboard page is loaded before returning
     * If no text is supplied it will wait for the url to contain dashboard.php and
     * it will look for the Sterling Talent Solutions image in the footer
     * If you supply textToLookFor it will find this text in the page source before returning
     * @param textToLookFor The text you want to search for on the page.
     */
    protected static void waitForPageLoad(String pageName, String... textToLookFor) {
        waitForPageLoad(SeleniumTest.FLUENTWAIT_TIMEOUT * 2,
                        SeleniumTest.POLLING_TIMEOUT,
                        pageName,
                        textToLookFor);
    }

    protected static void waitForPageLoad(int timeOut, int polling, String pageName, String...
            textToLookFor) {
        String searchText = textToLookFor.length > 0 ? textToLookFor[0] : "";
        if(!searchText.isEmpty()) {
            try {
                WaitUntil.waitUntil(timeOut, polling, () -> Driver.getDriver().getPageSource()
                                                                .contains(searchText));
            } catch (TimeoutException toe) {
                if(Driver.getDriver().getPageSource().contains("Fatal error:")) {
                    staticLogger.info("GOV-1446:  Timing out because there is a Fatal Error on "
                                      + "the page");
                } else {
                    throw toe;
                }
            }
        } else {
            WaitUntil.waitUntil(timeOut, polling, () -> Driver.getDriver().getCurrentUrl().contains
                    (pageName));
            //TODO:  Add this back in once the PHP Error is fixed
            try {
                WaitUntil.waitUntil(timeOut, polling, () -> Driver.getDriver().findElement(
                        By.xpath("//img[contains(@src,images/talentwise_poweredby_logo.png)]"))
                                                .isEnabled(), NoSuchElementException.class);

            } catch (TimeoutException toe) {
                if(Driver.getDriver().getPageSource().contains("Fatal error:")) {
                    staticLogger.info("GOV-1446:  This is timing out because there is a PHP Error");
                } else {
                    throw toe;
                }
            }
        }
        SeleniumTest.waitForPageLoad();
    }

    public static boolean sourceContains(String value) {
        return sourceContains(value, false);
    }

    public static boolean sourceContains(String value, boolean ignoreCase) {
        if (ignoreCase) {
            return Driver.getDriver().getPageSource().toLowerCase().contains(value.toLowerCase());
        } else {
            return Driver.getDriver().getPageSource().contains(value);
        }
    }

    /**
     * Case sensitive comparison looking for anchors which are visible and containing text
     * @param text the text to look for
     * @return Whether there is an anchor link on the page containing your text
     */
    public static boolean containsAnchorText(String text) {
        return containsAnchorText(text, false);
    }

    /**
     * Comparison looking for anchors which are visible and containing text
     * @param text the text to look for
     * @param ignoreCase Determines case sensitive or not
     * @return Whether there is an anchor link on the page containing your text
     */
    public static boolean containsAnchorText(String text, Boolean ignoreCase) {

        String xpathExpression = "";

        if (ignoreCase) {
            xpathExpression =
                    "//a[contains("             // beginning anchor element locator
                    + translateToLower(".")     // locate text converting to lower case
                    + ",'"
                    + text.toLowerCase()        // value to find converted to lower case
                    + "')]";
        } else {
            xpathExpression =
                    "//a[contains(" // beginning anchor element locator
                    + "."           // locate text in the anchor
                    + ",'"
                    + text          // value to find
                    + "')]";
        }
        List<WebElement> elements =
                ((EventFiringWebDriver)Driver.getDriver())
                        .getWrappedDriver().findElements(By.xpath(
                xpathExpression));
        if (elements.size() > 0) {
            for (WebElement element : elements) {
                if (element.isDisplayed()) {
                    return true;
                }
            }
        }
        return false;
    }

    private static String translateToLower(String attribute) {
        return "translate("
               + attribute
               + ",'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')";
    }

    public void navigateToDocumentUploadPage(String subPortal, String requestId)
    {
        SeleniumTest.navigateToUrl(Sites.URL.getURL(Site.CANDIDATE_PORTAL)+"/"+subPortal+"/"+"ptl/documentupload.php?RequestID="+requestId);
    }
}
