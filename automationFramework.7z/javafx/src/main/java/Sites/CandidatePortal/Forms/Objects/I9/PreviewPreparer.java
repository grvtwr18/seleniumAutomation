package Sites.CandidatePortal.Forms.Objects.I9;

import Sites.CandidatePortal.Forms.RichFormsBase;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * The I-9 PDF preview page for only Preparer I-9 workflow. Lots of duplicate code with Preview.
 * Unfortunately this version is needed because of the mis-alignment between Preparer and
 * Core I-9 previews. Remove this Page object when bug ONB-1472 is fixed.
 */
public class PreviewPreparer extends RichFormsBase {
    static {
        PageFactory.initElements(Driver.getDriver(), Preview.class);
    }

    public static class Section1 {
        static {
            PageFactory.initElements(Driver.getDriver(), Preview.Section1.class);
        }

        @FindBy(how = How.XPATH, using = "//div[@id='s1wrapper-I9s1_2']//span[contains(@id, '-I9s1_2')]")
        public static WebElement LastNameI9s1_2;

        @FindBy(how = How.XPATH, using = "//div[@id='s1wrapper-I9s1_1']//span[contains(@id, '-I9s1_1')]")
        public static WebElement FirstNameI9s1_1;

        @FindBy(how = How.XPATH, using = "//div[@id='s1wrapper-I9s1_3']//div[contains(@id, '-I9s1_3')]//span")
        public static WebElement MiddleInitialI9s1_3;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_4'] span")
        public static WebElement OtherNamesI9s1_4;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_5']")
        public static WebElement AddressI9s1_5;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_6'] span")
        public static WebElement UnitI9s1_6;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_7']")
        public static WebElement CityI9s1_7;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_8']")
        public static WebElement StateI9s1_8;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_9']")
        public static WebElement ZipI9s1_9;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_10']")
        public static WebElement DateOfBirthI9s1_10;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_12'] span")
        public static WebElement EmailI9s1_12;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_13'] span")
        public static WebElement PhoneI9s1_13;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_USCITIZEN']")
        public static WebElement Authorization1I9s1_14;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_USNONCITIZENNATIONAL']")
        public static WebElement Authorization2I9s1_14;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_LAWFULPERMANENTRESIDENT']")
        public static WebElement Authorization3I9s1_14;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_ALIENAUTHORIZEDTOWORK']")
        public static WebElement Authorization4I9s1_14;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_15']")
        public static WebElement LPR_AlienRegistrationNumberI9s1_15;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_16']")
        public static WebElement WorkAuthExpDateI9s1_16;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_17']")
        public static WebElement AlienRegistrationNumberI9s1_17;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_18']")
        public static WebElement FormI94AdmissionNumberI9s1_18;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_20']")
        public static WebElement CountryOfIssuanceI9s1_20;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_19']")
        public static WebElement ForeignPassportNumberI9s1_19;

        // Employee signature and sign date go here
        @FindBy(how = How.CSS, using = "span[id$='-I9s1_21']")
        public static WebElement EmployeeSignatureI9s1_21;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_21'] #sign-date")
        public static WebElement SignStampSignDate;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_21'] #sign-name small")
        public static WebElement SignStampSignNameText;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_22']")
        public static WebElement EmployeeDateSignedI9s1_22;


        @FindBy(how = How.CSS, using = "input[id$='-I9s1_32_false']")
        public static WebElement NoPreparerI9s1_32;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_32_true']")
        public static WebElement YesPreparerI9s1_32;

        // The below elements will only exist if YesPreparerI9s1_32 is checked.
        @FindBy(how = How.CSS, using = "span[id$='-I9s1_24']")
        public static WebElement PreparerAcknowledgeI9s1_24;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_25']")
        public static WebElement PreparerSignedDateI9s1_25;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_26']")
        public static WebElement PreparerLastNameI9s1_26;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_27']")
        public static WebElement PreparerFirstNameI9s1_27;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_28']")
        public static WebElement PreparerAddressI9s1_28;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_29']")
        public static WebElement PreparerCityI9s1_29;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_30']")
        public static WebElement PreparerStateI9s1_30;

        @FindBy(how = How.CSS, using = "span[id$='-I9s1_31']")
        public static WebElement PreparerZipI9s1_31;

        public static String getSsn() {
            WebDriver driver = Driver.getDriver();
            return driver.findElement(By.cssSelector("span[id$='-I9s1_11_1']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_2']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_3']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_4']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_5']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_6']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_7']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_8']")).getText()
                    + driver.findElement(By.cssSelector("span[id$='-I9s1_11_9']")).getText();
        }

        //TODO test & find better solution for these next 4 methods.
        public static boolean isCitizenRadioSelected() {
            return !Authorization1I9s1_14.getAttribute("checked").equals(null);
        }

        public static boolean isNonCitizenRadioSelected() {
            return !Authorization2I9s1_14.getAttribute("checked").equals(null);
        }

        public static boolean isLawfulPermanentResidentRadioSelected() {
            return !Authorization3I9s1_14.getAttribute("checked").equals(null);
        }

        public static boolean isAlienAuthorizedToWorkRadioSelected() {
            return !Authorization4I9s1_14.getAttribute("checked").equals(null);
        }

        public static void getAuthorizationUsed() {
            // TODO. Return an int or string or something based on Authorization1I9s1_14 (etc.) checked and what we get from S2 to compare too
        }

        public static boolean preparerUsedChecked() {
            return YesPreparerI9s1_32.isSelected() && !NoPreparerI9s1_32.isSelected();
        }

        public static boolean preparerNotUsedChecked() {
            return !YesPreparerI9s1_32.isSelected() && NoPreparerI9s1_32.isSelected();
        }

    }

    public static class Section2 {
        static {
            PageFactory.initElements(Driver.getDriver(), Preview.Section2.class);
        }

        @FindBy(how = How.XPATH, using = "//div[@id='s2wrapper-I9s1_2']//span[contains(@id, '-I9s1_2')]")
        public static WebElement EmployeeLastNameI9s1_2;

        @FindBy(how = How.XPATH, using = "//div[@id='s2wrapper-I9s1_1']//span[contains(@id, '-I9s1_1')]")
        public static WebElement EmployeeFirstNameI9s1_1;

        @FindBy(how = How.XPATH, using = "//div[@id='s2wrapper-I9s1_3']//span[contains(@id, '-I9s1_3')]")
        public static WebElement EmployeeMiddleInitialI9s1_3;

        @FindBy(how = How.XPATH, using = "//div[contains(@id, '-I9s1_14_1')]")
        public static WebElement EmployeeCitizenshipImmigrationStatusI9s1_4;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_56']")
        public static WebElement EmployeeFirstDayOfEmployment;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_1']")
        public static WebElement DocumentTitleA1I9s2_1;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_2-31']")
        public static WebElement IssuingAuthorityA1I9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_3-4-5-6-7-8-32']")
        public static WebElement DocumentNumberA1I9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_9-33']")
        public static WebElement ExpirationDateA1I9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_10']")
        public static WebElement DocumentTitleA2I9s2_10;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_11']")
        public static WebElement IssuingAuthorityA2I9s2_11;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_12-13']")
        public static WebElement DocumentNumberA2I9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_14']")
        public static WebElement ExpirationDateA2I9s2_14;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_15']")
        public static WebElement DocumentTitleA3I9s2_15;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_16']")
        public static WebElement IssuingAuthorityA3I9s2_16;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_17']")
        public static WebElement DocumentNumberA3I9s2_17;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_18']")
        public static WebElement ExpirationDateA3I9s2_18;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_19']")
        public static WebElement DocumentTitleBI9s2_19;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_21-22-34']")
        public static WebElement IssuingAuthorityBI9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_23-24-35']")
        public static WebElement DocumentNumberBI9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_25-36']")
        public static WebElement ExpirationDateBI9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_26']")
        public static WebElement DocumentTitleCI9s2_26;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_27-37']")
        public static WebElement IssuingAuthorityCI9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_28-29-38']")
        public static WebElement DocumentNumberCI9s2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_30-39']")
        public static WebElement ExpirationDateCI9s2;

        @FindBy(how = How.CSS, using = "div[id$='-I9s2_60'] span")
        public static WebElement AdditionalInfoI9s2_60;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_56']")
        public static WebElement I9HireDateI9s2_56;

        // Employer signature and sign date go here

        @FindBy(how = How.CSS, using = "div[id$='-I9s2_40'] #sign-date")
        public static WebElement EmployerSignStampSignDate;

        @FindBy(how = How.CSS, using = "div[id$='-I9s2_40'] #sign-name small")
        public static WebElement EmployerSignStampSignNameText;

        @FindBy(how = How.CSS, using = "div[id$='-I9s2_41']")
        public static WebElement EmployerDateSignedI9s2_41;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_42']")
        public static WebElement EmployerTitleI9s2_42;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_43']")
        public static WebElement EmployerLastNameI9s2_43;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_44']")
        public static WebElement EmployerFirstNameI9s2_44;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_45']")
        public static WebElement EmployerOrganizationNameI9s2_45;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_46']")
        public static WebElement EmployerAddressI9s2_46;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_47']")
        public static WebElement EmployerCityI9s2_47;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_48']")
        public static WebElement EmployerStateI9s2_48;

        @FindBy(how = How.CSS, using = "span[id$='-I9s2_49']")
        public static WebElement EmployerZipI9s2_49;
    }

    public static class Section3 {
        static {
            PageFactory.initElements(Driver.getDriver(), Preview.Section3.class);
        }

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_2']")
        public static WebElement LastNameI9s3_2;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_1']")
        public static WebElement FirstNameI9s3_1;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_3']")
        public static WebElement MiddleNameI9s3_3;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_4']")
        public static WebElement RehireDateI9s3_4;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_5-22']")
        public static WebElement DocumentTitleI9s3;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_13-14-15-16-17-18-23']")
        public static WebElement DocumentNumberI9s3;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_19-24']")
        public static WebElement ExpirationDateI9s3;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_12']")
        public static WebElement EmployerNameI9s3_12;

        // Employer signature and sign date go here
    }
}
