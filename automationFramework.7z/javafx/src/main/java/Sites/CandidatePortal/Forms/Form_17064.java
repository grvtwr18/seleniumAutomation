package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.I9.Section1;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

/**
 * Created by Mayank.Jain on 2/20/2018.
 */
public class Form_17064 extends CandidatePortalPages {
    @FindBy(how = How.CSS, using = "input[id$='-I9s1_1']")
    private WebElement firstName;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_2']")
    private WebElement lastName;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_4NA']")
    private WebElement noOtherNameLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_4NA']")
    private WebElement noOtherNameInput;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_11']")
    private WebElement ssn;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_10']")
    private WebElement dob;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_5']")
    private WebElement address;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_6_1']")
    private WebElement aptNumber;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_7']")
    private WebElement city;

    @FindBy(how = How.CSS, using = "select[id$='-I9s1_56']")
    private WebElement country;

    @FindBy(how = How.CSS, using = "select[id$='-I9s1_8']")
    private WebElement state;

    @FindBy(how = How.ID, using = "17065-addressI9s1_7-err")
    private WebElement lblStateError;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_9']")
    private WebElement zip;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_12_1']")
    private WebElement email;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_13_1']")
    private WebElement telephone;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_USCITIZEN']")
    private WebElement USCitizenInput;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_USCITIZEN']")
    private WebElement USCitizenLabel;

    @FindBy(how = How.CSS, using = "input[id$='17065-I9s1_14_LAWFULPERMANENTRESIDENT']")
    private WebElement LawfulCitizenInput;

    @FindBy(how = How.CSS, using = "label[for$='17065-I9s1_14_LAWFULPERMANENTRESIDENT']")
    private WebElement LawfulCitizenLabel;

    @FindBy(how = How.XPATH, using = "//select[@id='17065-I9s1_38']")
    private WebElement LawfulCitizenDocumentType;

    @FindBy(how = How.ID, using = "17065-I9s1_15")
    private WebElement LawfulCitizenDocumentNumberField;

    @FindBy(how = How.CSS, using = "input[id$='17065-I9s1_14_ALIENAUTHORIZEDTOWORK']")
    private WebElement AlianCitizenInput;

    @FindBy(how = How.CSS, using = "label[for$='17065-I9s1_14_ALIENAUTHORIZEDTOWORK']")
    private WebElement AlianCitizenLabel;

    @FindBy(how = How.ID, using = "17065-I9s1_16_1-I9s1_16_1")
    private WebElement AlianExpirationDate;

    @FindBy(how = How.CSS, using = "select[id$='-I9s1_37']")
    private static WebElement aawAlienNumberDropDown;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_17']")
    private static WebElement aawAlienNumberTextBox;

    @FindBy(how = How.CSS, using = "label[for$='-qCertifySigning']")
    private WebElement acknowledgeLabel;

    @FindBy(how = How.CSS, using = "input[id$='-qCertifySigning']")
    private WebElement acknowledgeInput;

    @FindBy(how = How.CSS, using = "button[id$='-nextbutton']")
    private WebElement next;

    public Form_17064() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public FormID1eSignPage filli9Section1(Candidate candidate) {
        SeleniumTest.clearAndSetText(firstName, candidate.getFirstName());
        SeleniumTest.clearAndSetText(lastName, candidate.getLastName());
        SeleniumTest.check(noOtherNameLabel, noOtherNameInput);
        SeleniumTest.clearAndSetText(ssn, candidate.getSocialSecurityNumber().replace("-", ""));
        SeleniumTest.clearAndSetText(dob, candidate.getDOB().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")));
        SeleniumTest.clearAndSetText(address, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(aptNumber, candidate.getApartmentNumber());
        SeleniumTest.clearAndSetText(city, candidate.getCity());

        // A little waiting after selecting Country allowed the following State to stick,
        // where otherwise the state would somehow get de-selected, so clickNextBtn() would
        // fail to give rise to the expected FormID1eSignPage ...
        SeleniumTest.waitMs(1000L);

        Select stateDD = new Select(state);
        String stateName = candidate.getState();
        if (stateName.length() < 3)
            stateDD.selectByValue(stateName);
        else
            stateDD.selectByVisibleText(stateName);

        SeleniumTest.clearAndSetText(zip, candidate.getZip());
        if ((null != candidate.getEmailAddress()) && !candidate.getEmailAddress().trim().isEmpty()) {
            SeleniumTest.clearAndSetText(email, candidate.getEmailAddress());
        }
        SeleniumTest.clearAndSetText(telephone, candidate.getCandidatePhone());
        SeleniumTest.check(USCitizenLabel, USCitizenInput);
        SeleniumTest.check(acknowledgeLabel, acknowledgeInput);
        return (FormID1eSignPage) clickNextBtn(FormID1eSignPage.class);
    }

    public FormID1eSignPage clickNextBtn(Class<? extends FormID1eSignPage> returnedClass) {
        SeleniumTest.waitForElementToBeClickable(next);
        SeleniumTest.click(next);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public FormID1eSignPage filli9Section1(String FirstName, String LastName, String SSN) {
        SeleniumTest.clearAndSetText(firstName, FirstName);
        SeleniumTest.clearAndSetText(lastName, LastName);
        SeleniumTest.check(noOtherNameLabel, noOtherNameInput);
        SeleniumTest.clearAndSetText(ssn, SSN);
        SeleniumTest.clearAndSetText(dob, "11/04/1996");
        SeleniumTest.clearAndSetText(address, "123 main road");
        SeleniumTest.clearAndSetText(aptNumber, "");
        SeleniumTest.clearAndSetText(city, "Los Angeles");

        // A little waiting after selecting Country allowed the following State to stick,
        // where otherwise the state would somehow get de-selected, so clickNextBtn() would
        // fail to give rise to the expected FormID1eSignPage ...
        SeleniumTest.waitMs(1000L);

        Select stateDD = new Select(state);
        String stateName = "California";
        if (stateName.length() < 3)
            stateDD.selectByValue(stateName);
        else
            stateDD.selectByVisibleText(stateName);

        SeleniumTest.clearAndSetText(zip, "90006");

        SeleniumTest.clearAndSetText(telephone, "3689258765");
        SeleniumTest.check(USCitizenLabel, USCitizenInput);
        SeleniumTest.check(acknowledgeLabel, acknowledgeInput);
        return (FormID1eSignPage) clickNextBtn(FormID1eSignPage.class);
    }

    public void validateBlankStateErrorMessage(Candidate candidate) {
        SeleniumTest.clearAndSetText(firstName, candidate.getFirstName());
        SeleniumTest.clearAndSetText(lastName, candidate.getLastName());
        SeleniumTest.check(noOtherNameLabel, noOtherNameInput);
        SeleniumTest.clearAndSetText(ssn, candidate.getSocialSecurityNumber().replace("-", ""));
        SeleniumTest.clearAndSetText(dob, candidate.getDOB().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")));
        SeleniumTest.clearAndSetText(address, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(aptNumber, candidate.getApartmentNumber());
        SeleniumTest.clearAndSetText(city, candidate.getCity());
        SeleniumTest.clearAndSetText(zip, candidate.getZip());
        SeleniumTest.check(USCitizenLabel, USCitizenInput);
        SeleniumTest.check(acknowledgeLabel, acknowledgeInput);
        SeleniumTest.click(next);
        Assert.assertEquals("State is required.", lblStateError.getText());
    }

    public FormID1eSignPage filli9Section1ForDifferentCitizens(Candidate candidate, String document) {
        SeleniumTest.clearAndSetText(firstName, candidate.getFirstName());
        SeleniumTest.clearAndSetText(lastName, candidate.getLastName());
        SeleniumTest.check(noOtherNameLabel, noOtherNameInput);
        SeleniumTest.clearAndSetText(ssn, candidate.getSocialSecurityNumber().replace("-", ""));
        SeleniumTest.clearAndSetText(dob, candidate.getDOB().format(DateTimeFormatter.ofPattern("dd/MM/uuuu")));
        SeleniumTest.clearAndSetText(address, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(aptNumber, candidate.getApartmentNumber());
        SeleniumTest.clearAndSetText(city, candidate.getCity());

        // A little waiting after selecting Country allowed the following State to stick,
        // where otherwise the state would somehow get de-selected, so clickNextBtn() would
        // fail to give rise to the expected FormID1eSignPage ...
        SeleniumTest.waitMs(1000L);

        Select stateDD = new Select(state);
        String stateName = candidate.getState();
        if (stateName.length() < 3)
            stateDD.selectByValue(stateName);
        else
            stateDD.selectByVisibleText(stateName);

        SeleniumTest.clearAndSetText(zip, candidate.getZip());
        if ((null != candidate.getEmailAddress()) && !candidate.getEmailAddress().trim().isEmpty()) {
            SeleniumTest.clearAndSetText(email, candidate.getEmailAddress());
        }
        SeleniumTest.clearAndSetText(telephone, candidate.getCandidatePhone());
        switch (document) {
            case "U.S. Passport":
                SeleniumTest.check(USCitizenLabel, USCitizenInput);
                SeleniumTest.check(acknowledgeLabel, acknowledgeInput);
                break;
            case "U.S. Passport Card":
                SeleniumTest.check(USCitizenLabel, USCitizenInput);
                SeleniumTest.check(acknowledgeLabel, acknowledgeInput);
                break;
            case "Perm. Resident Card (Form I-551)":
                SeleniumTest.check(LawfulCitizenLabel, LawfulCitizenInput);
                SeleniumTest.selectByVisibleTextFromDropDown(LawfulCitizenDocumentType, "Alien Number");
                SeleniumTest.clearAndSetText(LawfulCitizenDocumentNumberField, "234859623");
                SeleniumTest.check(acknowledgeLabel, acknowledgeInput);
                break;
            case "Employment Authorization Document (Form I-766)":
                SeleniumTest.check(AlianCitizenLabel, AlianCitizenInput);
                Section1.CitizenAttestation.AlienAuthorizedToWork.setWorkAuthorizationExpirationDate(
                        LocalDate.now().plusYears(1));
                Section1.CitizenAttestation.AlienAuthorizedToWork.chooseAlienRegistrationNumber();
                SeleniumTest.selectByVisibleTextFromDropDown(aawAlienNumberDropDown, "Alien Number");
                SeleniumTest.clearAndSetText(aawAlienNumberTextBox, "123413124");
                SeleniumTest.check(acknowledgeLabel, acknowledgeInput);
                break;
        }
        return (FormID1eSignPage) clickNextBtn(FormID1eSignPage.class);
    }


}
