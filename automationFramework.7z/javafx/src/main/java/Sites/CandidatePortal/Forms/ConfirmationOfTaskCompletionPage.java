package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 11/03/2015.
 */
public class ConfirmationOfTaskCompletionPage extends FormPage {

    @FindBy(how = How.CSS, using = "input[value='Confirm']")
    private WebElement confirmButton;

    /**
     * Clicks on Confirm button
     * @return CandidatePortalPages
     */
    public CandidatePortalPages clickConfirmButton(Class<? extends CandidatePortalPages> returnClass) {
        confirmButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }
}