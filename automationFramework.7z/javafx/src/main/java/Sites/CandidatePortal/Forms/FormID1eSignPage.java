package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 8/13/2015.
 */
public class FormID1eSignPage extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "acceptButton")
    private static WebElement acceptButton;

    @FindBy(how = How.LINK_TEXT, using = "I Decline to Use an Electronic Signature")
    private static WebElement declineLink;

    @FindBy(how = How.ID, using = "declineReason")
    private static WebElement reasonTextArea;

    @FindBy(how = How.ID, using = "declineButton")
    private static WebElement declineButton;

    @FindBy(how = How.CSS, using = "input[value='Start eSigning >>']")
    private static WebElement starteSigning;

    public FormID1eSignPage() {
        WaitUntil.waitUntil(() -> {
            return Driver.getDriver().findElement(By.id("acceptButton")).isDisplayed();
        }, NoSuchElementException.class);
    }
    /**
     * Clicks on accept button.
     */
    public static FormeSignConfirmSignaturePage clickCompleteTaskButton() {
        try {
            acceptButton.click();
        }
        catch(NoSuchElementException nse) {
            System.out.println(nse.getMessage());
        }
        return PageFactory.initElements(Driver.getDriver(), FormeSignConfirmSignaturePage.class);
    }

    /**
     * Clicks complete and allows the caller to choose the page that gets returned
     * @param returnedClass One of the possible return pages (Additional Signature Pages, Dashboard, TaskComplete, etc...)
     * @return
     */
    public static CandidatePortalPages clickCompleteTaskButton(Class<? extends CandidatePortalPages> returnedClass) {
        acceptButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks on decline link
     */
    public static void clickIDeclineToUseAnElectronicSignatureLink() {
        declineLink.click();
    }

    /**
     * Types the reason for declining
     */
    public static void typeReasonForDecline(String reason) {
        reasonTextArea.sendKeys(reason);
    }

    /**
     * Clicks on 'Decline' button on Decline Electronic Signature modal dialog
     */
    public static CandidatePortalPages clickDeclineButton(Class<? extends CandidatePortalPages> returnClass){
        declineButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Clicks on start eSigning button
     */
    public static DocuSignReviewStandaloneI9Page clickStarteSigningButton() {
        starteSigning.click();
        return PageFactory.initElements(Driver.getDriver(), DocuSignReviewStandaloneI9Page.class);
    }

    public static void clickSectionNameLink(String sectionName)
    {
        SeleniumTest.click(By.linkText(sectionName));
    }
}
