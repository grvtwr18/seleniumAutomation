package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_6021_CC305 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='6021-6021_25_YES, I HAVE A DISABILITY (or previously had a disability)']")
    private WebElement yesIHaveADisabilityRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='6021-6021_25_NO, I DO NOT HAVE A DISABILITY']")
    private WebElement noIDoNotHaveADisabilityRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='6021-6021_25_I DO NOT WISH TO ANSWER']")
    private WebElement iDoNotWishToAnswerRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='6021-6021_39']")
    private WebElement iConfirmLabel;

    @FindBy(how = How.ID, using = "6021-6021_39")
    private WebElement iConfirmCheckbox;

    protected Logger logger = LoggerFactory.getLogger(Form_6021_CC305.class);

    public static Form_6021_CC305 getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_6021_CC305.class);
    }

    public Form_6021_CC305 chooseYesIHaveADisability() {
        yesIHaveADisabilityRadiobutton.click();
        logger.info("I Have a Disability Chosen");
        return this;
    }

    public Form_6021_CC305 chooseNoIDoNotHaveADisability() {
        noIDoNotHaveADisabilityRadiobutton.click();
        logger.info("I Do not have a Disability Chosen");
        return this;
    }

    public Form_6021_CC305 chooseIDoNotWishToAnswer() {
        iDoNotWishToAnswerRadiobutton.click();
        logger.info("I Do not wish to Answer Chosen");
        return this;
    }

    public Form_6021_CC305 checkIConfirm() {
        SeleniumTest.check(iConfirmLabel, iConfirmCheckbox);
        logger.info("I Confirm checked");
        return this;
    }

    public Form_6021_CC305 uncheckIConfirm() {
        SeleniumTest.unCheck(iConfirmLabel, iConfirmCheckbox);
        logger.info("I Confirm unchecked");
        return this;
    }
}
