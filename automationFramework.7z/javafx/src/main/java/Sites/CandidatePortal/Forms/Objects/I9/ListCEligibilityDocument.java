package Sites.CandidatePortal.Forms.Objects.I9;

import java.time.LocalDate;

/**
 * Created by abrackett on 10/18/16.
 */
public class ListCEligibilityDocument {
    private Section2.Documents.ListCDocuments ListCDocument           =
            Section2.Documents.ListCDocuments.SOCIAL_SECURITY_CARD;
    private boolean                           receipt                 = false;
    private Section2.Documents.ListCDocuments listCdocumentType            =
            Section2.Documents.ListCDocuments.LIST_C7_SUB_DOC_CERTIFICATE_OF_USCITIZENSHIP_N560;
    private String                            stateOfUnion            = "";
    private String                            issuingAuthority        = "U.S. Department of State";
    private String                            documentNumber          = "888888888";
    private String                            associatedDocumentValue = "";
    private LocalDate                         expirationDate          = null;

    public ListCEligibilityDocument() {

    }

    public ListCEligibilityDocument(Section2.Documents.ListCDocuments document, boolean receipt,
                                    Section2.Documents.ListCDocuments documentType, String stateOfUnion,
                                    String issuingAuthority, String documentNumber,
                                    String associatedDocumentValue, LocalDate expirationDate) {

        this.ListCDocument = document;
        this.receipt = receipt;
        this.listCdocumentType = documentType;
        this.stateOfUnion = stateOfUnion;
        this.issuingAuthority = issuingAuthority;
        this.documentNumber = documentNumber;
        this.associatedDocumentValue = associatedDocumentValue;
        this.expirationDate = expirationDate;
    }


    public Section2.Documents.ListCDocuments getListCDocument() {
        return ListCDocument;
    }

    public void setListCDocument(Section2.Documents.ListCDocuments ListCDocument) {
        this.ListCDocument = ListCDocument;
    }

    public Section2.Documents.ListCDocuments getDocumentType() {
        return listCdocumentType;
    }

    public void setDocumentType(Section2.Documents.ListCDocuments documentType) {
        this.listCdocumentType = documentType;
    }

    public String getStateOfUnion() {
        return stateOfUnion;
    }

    public void setStateOfUnion(String stateOfUnion) {
        this.stateOfUnion = stateOfUnion;
    }

    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    public void setIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getAssociatedDocumentValue() {
        return associatedDocumentValue;
    }

    public void setAssociatedDocumentValue(String associatedDocumentValue) {
        this.associatedDocumentValue = associatedDocumentValue;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public boolean isReceipt() {
        return receipt;
    }

    public void setReceipt(boolean receipt) {
        this.receipt = receipt;
    }

}
