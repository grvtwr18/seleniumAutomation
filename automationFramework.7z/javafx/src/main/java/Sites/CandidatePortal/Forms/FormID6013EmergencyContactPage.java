package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by btorbert on 8/29/16.
 */
public class FormID6013EmergencyContactPage extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "6013-106_4")
    public static WebElement eContact1_FullNameTextbox;

    @FindBy(how = How.ID, using = "6013-106_5")
    private static WebElement eContact1_AddressTextbox;

    @FindBy(how = How.ID, using = "6013-address6013_110-6013_111")
    private static WebElement eContact1_CityTextBox;

    @FindBy(how = How.ID, using = "6013-address6013_110-6013_112")
    private static WebElement eContact1_StateDropdown;

    @FindBy(how = How.ID, using = "6013-address6013_110-6013_110")
    private static WebElement eContact1_CountryDropdown;

    @FindBy(how = How.ID, using = "6013-address6013_110-6013_113")
    private static WebElement eContact1_Zip;

    @FindBy(how = How.ID, using = "6013-106_10")
    private static WebElement eContact1_HomePhone;

    @FindBy(how = How.ID, using = "6013-106_11")
    private static WebElement eContact1_WorkPhone;

    @FindBy(how = How.ID, using = "6013-106_12")
    private static WebElement eContact1_OtherPhone;

    @FindBy(how = How.ID, using = "6013-106_14")
    public static WebElement eContact2_FullNameTextbox;

    @FindBy(how = How.ID, using = "6013-106_15")
    private static WebElement eContact2_AddressTextbox;

    @FindBy(how = How.ID, using = "6013-address6013_116-6013_117")
    private static WebElement eContact2_CityTextBox;

    @FindBy(how = How.ID, using = "6013-address6013_116-6013_118")
    private static WebElement eContact2_StateDropdown;

    @FindBy(how = How.ID, using = "6013-address6013_116-6013_116")
    private static WebElement eContact2_CountryDropdown;

    @FindBy(how = How.ID, using = "6013-address6013_116-6013_119")
    private static WebElement eContact2_Zip;

    @FindBy(how = How.ID, using = "6013-106_20")
    private static WebElement eContact2_HomePhone;

    @FindBy(how = How.ID, using = "6013-106_21")
    private static WebElement eContact2_WorkPhone;

    @FindBy(how = How.ID, using = "6013-106_22")
    private static WebElement eContact2_OtherPhone;

    @FindBy(how = How.CSS, using = "label[for='6013-6013_106_Yes']")
    private static WebElement AddAnotherPersonToEmergencyContacts_YesRadioButton;

    @FindBy(how = How.CSS, using = "label[for='6013-6013_106_No']")
    private WebElement AddAnotherPersonToEmergencyContacts_NoRadioButton;

    @FindBy(how = How.CSS, using = "label[for='6013-6013_122']")
    public static WebElement iConfirmCheckBox;

    //TODO move this type of functionality to a formbase class & create dev ticket to standardise these type of selectors.
    @FindBy(how = How.CSS, using = "button[value='Next']")
    public static WebElement nextButton;

    /**
     * Enters Emergency Contact 1 full name text
     * @param fullName
     */
    public static void enterEmergencyContact1_FullNameText(String fullName) {
        SeleniumTest.clearAndSetText(eContact1_FullNameTextbox, fullName);
    }

    /**
     * Enters Emergency Contact 2 full name text
     * @param fullName
     */
    public static void enterEmergencyContact2_FullNameText(String fullName) {
        SeleniumTest.clearAndSetText(eContact2_FullNameTextbox, fullName);
    }

    /**
     * Enter Contact 1 Home phone number text
     * @param homePhone
     */
    public static void enterEmergencyContact1_HomePhoneNumber(String homePhone) {
        SeleniumTest.clearAndSetText(eContact1_HomePhone, homePhone);
    }

    /**
     * Enter Contact 2 Home phone number text
     * @param homePhone
     */
    public static void enterEmergencyContact2_HomePhoneNumber(String homePhone) {
        SeleniumTest.clearAndSetText(eContact2_HomePhone, homePhone);
    }

    /**
     * Enters Emergency Contact 1 Work Phone Number text
     * @param workPhone
     */
    public static void enterEmergencyContact1_WorkPhoneNumber(String workPhone) {
        SeleniumTest.clearAndSetText(eContact1_WorkPhone, workPhone);
    }

    /**
     * Enters Emergency Contact 2 Work Phone Number text
     * @param workPhone
     */
    public static void enterEmergencyContact2_WorkPhoneNumber(String workPhone) {
        SeleniumTest.clearAndSetText(eContact2_WorkPhone, workPhone);
    }

    /**
     * Enters Emergency Contact 1 Other Phone Number text
     * @param otherPhone
     */
    public static void enterEmergencyContact1_OtherPhoneNumber(String otherPhone) {
        SeleniumTest.clearAndSetText(eContact1_OtherPhone, otherPhone);
    }

    /**
     * Enters Emergency Contact 2 Other Phone Number text
     * @param otherPhone
     */
    public static void enterEmergencyContact2_OtherPhoneNumber(String otherPhone) {
        SeleniumTest.clearAndSetText(eContact2_OtherPhone, otherPhone);
    }

    /**
     * Enters Emergency Contact 1 Address text
     * @param address
     */
    public static void enterEmergencyContact1_Address(String address) {
        SeleniumTest.clearAndSetText(eContact1_AddressTextbox, address);
    }

    /**
     * Enters Emergency Contact 2 Address text
     * @param address
     */
    public static void enterEmergencyContact2_Address(String address) {
        SeleniumTest.clearAndSetText(eContact2_AddressTextbox, address);
    }

    /**
     * Enters Emergency Contact 1 City text
     * @param city
     */
    public static void enterEmergencyContact1_City(String city) {
        SeleniumTest.clearAndSetText(eContact1_CityTextBox, city);
    }

    /**
     * Enters Emergency Contact 2 City text
     * @param city
     */
    public static void enterEmergencyContact2_City(String city) {
        SeleniumTest.clearAndSetText(eContact2_CityTextBox, city);
    }

    /**
     * Selects Emergency Contact 1 State option
     * @param state
     */
    public static void selectEmergencyContact1_State(String state) {
        SeleniumTest.selectByValueFromDropDown(eContact1_StateDropdown, state);
    }

    /**
     * Selects Emergency Contact 2 State option
     * @param state
     */
    public static void selectEmergencyContact2_State(String state) {
        SeleniumTest.selectByValueFromDropDown(eContact2_StateDropdown, state);
    }

    /**
     * Selects Emergency Contact 1 Country option
     * @param country
     */
    public static void selectEmergencyContact1_Country(String country) {
        SeleniumTest.selectByValueFromDropDown(eContact1_CountryDropdown, country);
    }

    /**
     * Selects Emergency Contact 2 Country option
     * @param country
     */
    public static void selectEmergencyContact2_Country(String country) {
        SeleniumTest.selectByValueFromDropDown(eContact2_CountryDropdown, country);
    }

    /**
     * Enters Emergency Contact 1 Zip Code text
     * @param zip
     */
    public static void enterEmergencyContact1_Zip(String zip) { SeleniumTest.clearAndSetText(eContact1_Zip, zip); }

    /**
     * Enters Emergency Contact 2 Zip Code text
     * @param zip
     */
    public static void enterEmergencyContact2_Zip(String zip) { SeleniumTest.clearAndSetText(eContact2_Zip, zip); }

    /**
     * Selects the Add Another Person To Emergency Contacts "Yes" Radio Button
     */
    public static void setAddAnotherPersonToEmergencyContacts_YesRadio() {
        AddAnotherPersonToEmergencyContacts_YesRadioButton.click();
    }

    /**
     * Selects the Add Another Person To Emergency Contacts "No" Radio Button
     */
    public void setAddAnotherPersonToEmergencyContacts_NoRadio() {
        AddAnotherPersonToEmergencyContacts_NoRadioButton.click();
    }
}
