package Sites.CandidatePortal.Forms.tax.state.Oregon;


import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class Form_22537 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "(//a [@href='https://www.oregon.gov/DOR/forms/FormsPubs/form-or-w-4_101-402_2019.pdf'])[1]")
    public WebElement stateOfOregonLink;

    @FindBy(how = How.XPATH, using = "//label[@for='22537-22537_1_Single']")
    public WebElement maritalStatusSingle;

    @FindBy (how = How.XPATH, using = "//p[contains(text(), ' “Single” box.')]")
    public WebElement selectOneNoteLabel;

    @FindBy (how = How.XPATH, using = "//p[contains(text(),' if any, you want')]")
    public WebElement additionalAmountLabel;

    @FindBy(how = How.ID, using = "22537-22537_25")
    public WebElement allowanceBox;

    @FindBy(how = How.ID, using = "22537-22537_26")
    public WebElement additionalAmountBox;

    @FindBy(how = How.ID, using = "22537-22537_37")
    public WebElement exemptionCode;

    @FindBy(how = How.ID, using = "22537-22537_39")
    public WebElement exemptBox;

    @FindBy(how = How.ID, using = "22537-22537_41")
    public WebElement withholdingStatusDropdown;

    @FindBy(how = How.ID, using = "22537-22537_47")
    public WebElement residencyStatementDropdown;

    @FindBy(how = How.ID, using = "22537-22537_48")
    public WebElement employmentStatementDropdown;

    @FindBy(how = How.ID, using = "22537-22537_25-err")
    public WebElement allowanceErrorLabel;

    @FindBy(how = How.ID, using = "22537-22537_26-err")
    public WebElement additionalAmountErrorLabel;

    @FindBy(how = How.ID, using = "22537-22537_37-err")
    public WebElement exemptCodeErrorLabel;

    @FindBy(how = How.ID, using = "22537-22537_39-err")
    public WebElement writeExemptErrorLabel;

    @FindBy(how = How.ID, using = "22537-22537_1-err")
    public WebElement pleaseSelectOneErrorLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='22537-22537_1']")
    public WebElement pleaseSelectOneLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='22537-22537_18']")
    public WebElement iDeclareCheckbox;

    @FindBy(how = How.ID, using = "22537-22537_18-err")
    public WebElement iDeclareErrorLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='22537-22537_18']")
    public WebElement iDeclareLabel;


    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_22537() {

    }

    public static Form_22537 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_22537.class);
    }

    public boolean stateOfOregonLinkExists(){
        return stateOfOregonLink.isDisplayed();
    }

    public Form_22537 chooseMaritalStatusSingle() {
        SeleniumTest.click(maritalStatusSingle);
        logger.info("Single radio button is selected");
        return this;
    }

    public Form_22537 setAllowanceAmount(String amount) {
        SeleniumTest.clearAndSetText(allowanceBox, amount);
        logger.info("Allowance amount is entered", amount);
        return this;
    }

    public Form_22537 setAdditionalAmount(String amount) {
        SeleniumTest.clearAndSetText(additionalAmountBox, amount);
        logger.info("Additional amount is entered", amount);
        return this;
    }

    public Form_22537 setexemptioncode(String code) {
        SeleniumTest.clearAndSetText(exemptionCode, code);
        logger.info("Exemption code is entered", code);
        return this;
    }

    public Form_22537 setexempt(String text) {
        SeleniumTest.clearAndSetText(exemptBox, text);
        logger.info("Exempt is entered", text);
        return this;
    }

    public Form_22537 selectWithholdingStatus(String withholdingStatus) {
        SeleniumTest.selectByVisibleTextFromDropDown(withholdingStatusDropdown, withholdingStatus);
        logger.info("Withholding Status of {} selected", withholdingStatus);
        return this;
    }

    public Form_22537 checkIdeclare() {

        SeleniumTest.click(iDeclareCheckbox);
        logger.info("Ideclare button is clicked");
        return this;
    }

    public Form_22537 selectResidencyStatement(String residencyStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropdown, residencyStatement);
        logger.info("Residency Status Selected {}", residencyStatement);
        return this;
    }

    public Form_22537 selectEmploymentStatementDropdown(String employmentStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(employmentStatementDropdown, employmentStatement);
        logger.info("Employment Status Selected {}", employmentStatement);
        return this;
    }

    public void fillRequiredFields(boolean statetaxform, String allowanceamount, String additionalamount, String Exemptioncode, String Exempt, WithholdingStatus withholdingStatus, String flow) {
        if (statetaxform) {

            this.setAllowanceAmount(allowanceamount);
            this.setAdditionalAmount(additionalamount);
            this.setexemptioncode(Exemptioncode);
            this.setexempt(Exempt);
            if (flow != "normal"){
                selectWithholdingStatus(withholdingStatus.toString());
                switch(withholdingStatus) {
                    case EXEMPT:
                        this.selectResidencyStatement("I live in Oregon");
                        this.selectEmploymentStatementDropdown("I work out of state");
                        break;
                    case FULLY_SUBJECT_TO_TAXES:
                        this.selectResidencyStatement("I live out of state");
                        this.selectEmploymentStatementDropdown("I work in Oregon");
                        break;
            }

            }
            else
            {
                this.selectResidencyStatement("I live in Oregon");
                this.selectEmploymentStatementDropdown("I work in Oregon");
            }

            this.checkIdeclare();

        }

    }





    public void verifyRequiredErrorLables(String allowanceamount,String additionalamount, String Exemptioncode, String Exempt) {
            this.setAllowanceAmount(allowanceamount);
            this.setAdditionalAmount(additionalamount);
            this.setexemptioncode(Exemptioncode);
            this.setexempt(Exempt);




    }
    public enum WithholdingStatus {
        EXEMPT("Exempt"),
        FULLY_SUBJECT_TO_TAXES("Fully Subject to Taxes");

        private final String text;

        WithholdingStatus(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    public enum AllowanceAdditionalAmount {
        ALLOWANCE_AMOUNT("23"),ADDITIONAL_AMOUNT("0"),
        ALLOWANCE_AMOUNT_BLANK(""),ADDITIONAL_AMOUNT_BLANK("");

        private final String text;

        AllowanceAdditionalAmount(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }



}