package Sites.CandidatePortal.Forms.vro;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by jgupta on 3/26/2017.
 */
public class ViewVroReportPage {
    private static final Logger logger =
            LoggerFactory.getLogger(ViewVroReportPage.class);

    static {
        PageFactory.initElements(Driver.getDriver(), ViewVroReportPage.class);
    }
    @FindBy(how = How.CSS, using = "button[class='btn dropdown-toggle']")
    private static WebElement actionDropDown;

    @FindBy(how = How.CSS, using = "ul.dropdown-menu.dropdown-menu-right > li.icon.icon-dispute > a")
    private static WebElement disputeButton;

    @FindBy(how = How.CLASS_NAME, using = "dispute-check")
    private static List<WebElement> allDisputeCheckboxes;

    @FindBy(how = How.CSS, using = "div[data-target='#customer-legal-body']")
    private static WebElement customReportDisclosureHeader;

    @FindBy(how = How.ID, using = "customer-legal-body")
    private static WebElement customReportDisclosureText;

    @FindBy(how = How.CLASS_NAME, using = "dispute-report")
    private static WebElement initiateDisputeForSelectedResultButton;

    @FindBy(how = How.CLASS_NAME, using = "dispute-count")
    private static WebElement initiateDisputeCount;


    public static void selectActionDropDownOption(String option) {
        SeleniumTest.click(actionDropDown);
        if (option.equals("Dispute")) {
            SeleniumTest.click(disputeButton);
        } else {
            logger.warn("ViewVroReport.selectActionDropDown() currently doesn't handle option: {}", option);
        }
    }

    static {
        PageFactory.initElements(Driver.getDriver(), ViewVroReportPage.class);
    }

    /**
     * Clicks on the custom disclosure header to expand it.
     */
    public static void expandCustomDisclosure() {
        SeleniumTest.click(customReportDisclosureHeader);
        SeleniumTest.waitForElementVisible(customReportDisclosureText);
    }

    /**
     * Retrieve the text of custom disclosure
     * @return String
     */
    public static String getCustomDisclosureText() {
        //Added extra wait for element visible as the test were failing to get whole text.
        SeleniumTest.waitForElementVisible(customReportDisclosureText);
        return customReportDisclosureText.getText();
    }

    public static void selectAllCheckboxesForDispute() {
        // With the way this page shows overlapping bars and unusual scrolling, it pretty
        // well thwarted Selenium's ability to scroll into view and click().  The following
        // worked around the problem just fine ...
        for (WebElement disputeCheckbox: allDisputeCheckboxes){
            //SeleniumTest.click(disputeCheckbox); // Didn't work for reason above!
            JavaScriptHelper.click(disputeCheckbox);
        }

        WaitUntil.waitUntil(() -> {
            logger.info("Dispute checkbox count: {}", allDisputeCheckboxes.size());
            logger.info("Count showing in Initiate Dispute button circle: {}", getInitiateDisputeCount());
            return allDisputeCheckboxes.size() == getInitiateDisputeCount();
        }, NumberFormatException.class);
    }

    public static void clickInitiateDisputeForSelectedResultButton() {
        try {
            logger.info("Clicking to Initiate Dispute for the (#) selected results");
            SeleniumTest.click(initiateDisputeForSelectedResultButton);
        } catch (WebDriverException e) {
            logger.warn("Try clicking Initate Dispute with JavaScript, because Selenium didn't work");
            JavaScriptHelper.click(initiateDisputeForSelectedResultButton);
        }
        logger.info("Clicked Initiate Dispute for the (#) selected results");
    }

    public static int getInitiateDisputeCount() {
        String initiateDisputeCount;
        // There have been grave difficulties reading this number off this page using Selenium ...
        try {
            initiateDisputeCount = SeleniumTest.getTextByLocator(By.className("dispute-count"));
            logger.info("Initiate Dispute Count by CLASS_NAME \"dispute-count\" : {}", initiateDisputeCount);
            return Integer.parseInt(initiateDisputeCount);
        } catch (NumberFormatException e) {
            initiateDisputeCount = SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"initiate-dispute\"]/div[2]/button[2]/div[1]"));
            logger.info("Initiate Dispute Count by XPATH : {}", initiateDisputeCount);
            return Integer.parseInt(initiateDisputeCount);
        }
    }
}

