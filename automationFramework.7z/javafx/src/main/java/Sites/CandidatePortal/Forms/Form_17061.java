package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.I9.Section2;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;

/**
 * Created by abrackett on 10/21/16.
 */
public class Form_17061 {

    static {
        PageFactory.initElements(Driver.getDriver(), Form_17061.class);
    }

    public static class Section2Documents {

        static {
            PageFactory.initElements(Driver.getDriver(), Section2Documents.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_9_1'][type='text']")
        private static WebElement documentExpirationDateCalendarControl;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_9_1'][type='hidden']")
        private static WebElement hiddenDocumentExpirationDateCalendarControl;

        public static void setExpirationDate(LocalDate date) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                    date,
                    documentExpirationDateCalendarControl.getAttribute("id"),
                    hiddenDocumentExpirationDateCalendarControl.getAttribute("id"));
        }

        @FindBy(how = How.CSS, using = "input[id$='-311_47_DocumentsMatch']")
        private static WebElement documentsMatchRadioButton;

        @FindBy(how = How.CSS, using = "label[for$='-311_47_DocumentsMatch']")
        private static WebElement documentsMatchRadioButtonLabel;

        @FindBy(how = How.CSS, using = "input[id$='-311_47_EditsRequired']")
        private static WebElement editsRequiredRadioButton;

        @FindBy(how = How.CSS, using = "label[for$='-311_47_EditsRequired']")
        private static WebElement editsRequiredRadioButtonLabel;

        public static void chooseDocumentsMatch() {
            documentsMatchRadioButtonLabel.click();
        }

        public static void chooseEditsRequired() {
            editsRequiredRadioButtonLabel.click();
        }
    }

    public static class Certification extends Section2.Certification {

    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {

    }

}
