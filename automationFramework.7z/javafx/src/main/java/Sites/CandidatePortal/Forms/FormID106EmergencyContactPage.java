package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by tjoshi on 11/24/2015.
 */
public class FormID106EmergencyContactPage extends FormPage {
    @FindBy(how = How.ID, using = "106-106_1")
    private WebElement spouseFullNameTextbox;

    @FindBy(how = How.ID, using = "106-106_2")
    private WebElement phoneNumberTextbox;

    @FindBy(how = How.ID, using = "106-106_4")
    private WebElement eContact1FullNameTextbox;

    @FindBy(how = How.ID, using = "106-106_5")
    private WebElement eContact1AddressTextbox;

    @FindBy(how = How.ID, using = "106-address106_6-106_7")
    private WebElement eContact1CityTextBox;

    @FindBy(how = How.ID, using = "106-address106_6-106_8")
    private WebElement eContact1StateDropdown;

    @FindBy(how = How.ID, using = "106-address106_6-106_6")
    private WebElement eContact1CountryDropdown;

    @FindBy(how = How.ID, using = "106-address106_6-106_9")
    private WebElement eContact1Zip;

    @FindBy(how = How.ID, using = "106-106_10")
    private WebElement eContact1Phone;

    @FindBy(how = How.ID, using = "106-106_14")
    private WebElement eContact2FullNameTextbox;

    @FindBy(how = How.ID, using = "106-106_15")
    private WebElement eContact2AddressTextbox;

    @FindBy(how = How.ID, using = "106-address106_16-106_17")
    private WebElement eContact2CityTextBox;

    @FindBy(how = How.ID, using = "106-address106_16-106_18")
    private WebElement eContact2StateDropdown;

    @FindBy(how = How.ID, using = "106-address106_16-106_16")
    private WebElement eContact2CountryDropdown;

    @FindBy(how = How.ID, using = "106-address106_16-106_19")
    private WebElement eContact2ZipTextbox;

    @FindBy(how = How.ID, using = "106-106_20")
    private WebElement eContact2PhoneTextbox;

    @FindBy(how = How.ID, using = "106-106_24")
    private WebElement physicianNameTextbox;

    @FindBy(how = How.ID, using = "106-106_25")
    private WebElement physicianPhoneTextbox;

    @FindBy(how = How.ID, using = "106-106_26")
    private WebElement physicianHospitalTextbox;

    @FindBy(how = How.ID, using = "106-106_28")
    private WebElement vehicleYearTextbox;

    @FindBy(how = How.ID, using = "106-106_29")
    private WebElement vehicleMakeTextbox;

    @FindBy(how = How.ID, using = "106-106_30")
    private WebElement vehicleModelTextbox;

    @FindBy(how = How.ID, using = "106-106_31")
    private WebElement vehicleLicenseTestDropdown;

    @FindBy(how = How.ID, using = "106-106_32")
    private WebElement vehicleLicenseNumberTextbox;

    @FindBy(how = How.ID, using = "106-106_33")
    private WebElement vehicleDriverLicenseStateDropbox;

    @FindBy(how = How.ID, using = "106-106_34")
    private WebElement vehicleDriverLicenseNumberTextbox;

    @FindBy(how = How.ID, using = "106-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * Set spouse full name
     * @param spouseFullName
     */
    public void setSpouseFullNameTextbox(String spouseFullName)
    {
        SeleniumTest.clearAndSetText(spouseFullNameTextbox, spouseFullName);
    }

    /**
     * Set phone number
     * @param phoneText
     */
    public void setPhoneNumberTextbox(String phoneText)
    {
        SeleniumTest.clearAndSetText(phoneNumberTextbox, phoneText);
    }

    /**
     * Fills in the first emergency contact information
     * @param fullName
     * @param address
     * @param city
     * @param state
     * @param country
     * @param zip
     * @param phone
     */
    public void setContactInfo1 (
            String fullName,
            String address,
            String city,
            String state,
            String country,
            String zip,
            String phone
    )
    {
        SeleniumTest.clearAndSetText(eContact1FullNameTextbox, fullName);
        SeleniumTest.clearAndSetText(eContact1AddressTextbox, address);
        SeleniumTest.clearAndSetText(eContact1CityTextBox, city);

        SeleniumTest.selectByValueFromDropDown(eContact1CountryDropdown, country);
        SeleniumTest.selectByValueFromDropDown(eContact1StateDropdown, state);

        SeleniumTest.clearAndSetText(eContact1Zip, zip);
        SeleniumTest.clearAndSetText(eContact1Phone, phone);
    }

    /**
     * Fills in the first emergency contact information
     * @param fullName
     * @param address
     * @param city
     * @param state
     * @param country
     * @param zip
     * @param phone
     */
    public void setContactInfo2 (
            String fullName,
            String address,
            String city,
            String state,
            String country,
            String zip,
            String phone
    )
    {
        SeleniumTest.clearAndSetText(eContact2FullNameTextbox, fullName);
        SeleniumTest.clearAndSetText(eContact2AddressTextbox, address);
        SeleniumTest.clearAndSetText(eContact2CityTextBox, city);

        SeleniumTest.selectByValueFromDropDown(eContact2CountryDropdown, country);
        SeleniumTest.selectByValueFromDropDown(eContact2StateDropdown, state);

        SeleniumTest.clearAndSetText(eContact2ZipTextbox, zip);
        SeleniumTest.clearAndSetText(eContact2PhoneTextbox, phone);
    }

    /**
     * Fill in the physician information
     * @param name
     * @param phone
     * @param hospital
     */
    public void fillPhysicianInfo(String name, String phone, String hospital)
    {
        SeleniumTest.clearAndSetText(physicianNameTextbox, name);
        SeleniumTest.clearAndSetText(physicianPhoneTextbox, phone);
        SeleniumTest.clearAndSetText(physicianHospitalTextbox, hospital);
    }

    /**
     * Fill vehicle information and driving license information
     * @param year
     * @param make
     * @param model
     * @param vehicleState
     * @param vehicleLicenseNum
     * @param driverState
     * @param driverLicenseNum
     */
    public void fillVehicleInformation(
            String year,
            String make,
            String model,
            String vehicleState,
            String vehicleLicenseNum,
            String driverState,
            String driverLicenseNum
    )
    {
        SeleniumTest.clearAndSetText(vehicleYearTextbox, year);
        SeleniumTest.clearAndSetText(vehicleMakeTextbox, make);
        SeleniumTest.clearAndSetText(vehicleModelTextbox, model);
        SeleniumTest.clearAndSetText(vehicleLicenseNumberTextbox, vehicleLicenseNum);
        SeleniumTest.clearAndSetText(vehicleDriverLicenseNumberTextbox, driverLicenseNum);

        SeleniumTest.selectByValueFromDropDown(vehicleLicenseTestDropdown, vehicleState);
        SeleniumTest.selectByValueFromDropDown(vehicleDriverLicenseStateDropbox, driverState);
    }


    /**
     * Click on Next button
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public CandidatePortalPages fillForm106(Class<? extends CandidatePortalPages> returnedClass)
    {
        setSpouseFullNameTextbox("Spouse's Full Name");
        setPhoneNumberTextbox("2061112222");

        setContactInfo1("Econtact One", "12345 NE 67th Street", "Bellevue", "WA", "US", "98004", "2061112222");
        setContactInfo2("Econtact Two", "12345 NE 67th Street", "Bellevue", "WA", "US", "98004", "2061112222");

        fillPhysicianInfo("Physician name", "2061112222", "Physician Hospital");

        fillVehicleInformation("2014", "Ford", "Fusion", "WA", "KMLWA", "WA", "XXXXXXX323X4");

        return clickNext(returnedClass);
    }
}
