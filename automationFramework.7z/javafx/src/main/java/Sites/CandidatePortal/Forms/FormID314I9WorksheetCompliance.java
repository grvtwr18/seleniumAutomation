package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;

/**
 * Created by abrackett on 12/11/2015.
 */
public class FormID314I9WorksheetCompliance extends FormPage {
    @FindBy(how = How.ID, using = "314-100_16-100_16")
    private WebElement employeeFirstDayBox;

    private String hiddenEmployeeFirstDayBox = "314-100_16";

    @FindBy(how = How.XPATH, using = "//label[@for='314-311_2_List A']")
    private WebElement listARadioButton;

    @FindBy(how = How.ID, using = "314-311_4")
    private WebElement listADocumentTitle;

    @FindBy(how = How.ID, using = "314-311_5")
    private WebElement issuingAuthority;

    @FindBy(how = How.ID, using = "314-314_12-314_12")
    private WebElement expirationDate;

    @FindBy(how = How.XPATH, using = "//label[@for='314-311_153']")
    private WebElement expirationCheckbox;

    @FindBy(how = How.ID, using = "314-311_141")
    private WebElement genderDropdown;

    @FindBy(how = How.ID, using = "314-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "314-311_6")
    private WebElement passportCardNumber;

    /**
     * Sets first day of employment
     * @param lDate
     * @return
     */
    public FormID314I9WorksheetCompliance setEmployeeFirstDay(LocalDate lDate) {
        employeeFirstDayBox.clear();
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(lDate, employeeFirstDayBox.getAttribute("id"), hiddenEmployeeFirstDayBox);
        employeeFirstDayBox.sendKeys(Keys.TAB);
        return this;
    }

    /**
     * Chooses List A
     * @return
     */
    public FormID314I9WorksheetCompliance chooseListA() {
        SeleniumTest.waitForElementToBeClickable(listARadioButton, 10);
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 5);
        listARadioButton.click();
        return this;
    }

    /**
     * Selects List A Document
     * @param document
     * @return
     */
    public FormID314I9WorksheetCompliance selectListADocument(String document) {
        SeleniumTest.waitForElementToBeClickable(listADocumentTitle, 10);
        Select listASelect = new Select(listADocumentTitle);
        listASelect.selectByVisibleText(document);
        return this;
    }

    /**
     * Sets Issuing Authority
     * @param authority
     * @return
     */
    public FormID314I9WorksheetCompliance setIssuingAuthority(String authority) {
        SeleniumTest.clearAndSetText(issuingAuthority, authority);
        return this;
    }

    /**
     * sets Expiration Date
     * @param lDate
     * @return
     */
    public FormID314I9WorksheetCompliance setExpirationDate(LocalDate lDate) {
        expirationDate.clear();
        expirationDate.sendKeys(Integer.toString(lDate.getMonthValue()) + "/" + Integer.toString(lDate.getDayOfMonth()) + "/" + Integer.toString(lDate.getYear()));
        return this;
    }

    /**
     * Checks Expiration N/A Box
     * @return
     */
    public FormID314I9WorksheetCompliance checkExpirationCheckbox() {
        if(!expirationCheckbox.isSelected())
            expirationCheckbox.click();
        return this;
    }

    /**
     * Selects Gender
     * @param gender
     * @return
     */
    public FormID314I9WorksheetCompliance selectGender(String gender) {
        Select genderSelect = new Select(genderDropdown);
        genderSelect.selectByVisibleText(gender);
        return this;
    }

    /**
     * Clicks Next
     * @return
     */
    public FormI9ConfirmationTaskComplete clickNext() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormI9ConfirmationTaskComplete.class);
    }

    /**
     * Sets Passport Card Number
     * @param cardNumber
     * @return
     */
    public FormID314I9WorksheetCompliance setPassportCardNumber(String cardNumber) {
        SeleniumTest.clearAndSetText(passportCardNumber, cardNumber);
        return this;
    }
}
