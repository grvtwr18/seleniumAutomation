package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.PortalSignInPage;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 10/9/2017.
 */
public class ProxyUserTaskCompletionPage extends FormPage {
    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    /**
     * Clicks on Sign Out Link.
     * @return
     */
    public static PortalSignInPage clickSignOut() {
            signOutLink.click();
            Driver.getDriver().manage().deleteAllCookies();
            return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }
}
