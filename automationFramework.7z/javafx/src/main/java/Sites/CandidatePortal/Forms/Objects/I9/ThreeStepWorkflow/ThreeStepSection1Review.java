package Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ThreeStepSection1Review extends CandidatePortalPages {

    static {
        PageFactory.initElements(Driver.getDriver(), ThreeStepSection1Review.class);
    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {}


    // region Locators

    @FindBy(how = How.ID, using = "returnbtn")
    private static WebElement returnButton;

    // TODO Return link?

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_1']")
    private static WebElement firstNameSpan;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_3_1']")
    private static WebElement middleNameSpan;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_3NA']")
    private static WebElement noMiddleNameLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_3NA']")
    private static WebElement noMiddleNameCheckBox;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_2']")
    private static WebElement lastNameSpan;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_4_1']")
    private static WebElement otherNamesSpan;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_4NA']")
    private static WebElement noOtherNamesLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_4NA']")
    private static WebElement noOtherNamesCheckbox;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_11']")
    private static WebElement ssnSpan;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_10']")
    private static WebElement dobSpan;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_5']")
    private static WebElement addressSpan;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_6_1']")
    private static WebElement aptNumberSpan;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_6NA']")
    private static WebElement noAptNumberLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_6NA']")
    private static WebElement noAptNumberCheckBox;

    @FindBy(how = How.CSS, using = "div[id$='-addressI9s1_7-I9s1_7']")
    private static WebElement citySpan;

    @FindBy(how = How.CSS, using = "div[id$='-addressI9s1_7-I9s1_56']")
    private static WebElement countrySpan;

    @FindBy(how = How.CSS, using = "div[id$='-addressI9s1_7-I9s1_8']")
    private static WebElement stateSpan;

    @FindBy(how = How.CSS, using = "div[id$='-addressI9s1_7-I9s1_9']")
    private static WebElement zipSpan;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_12_1']")
    private static WebElement emailSpan;

    @FindBy(how = How.CSS, using = "label[for$='-qEmailAddressNA']")
    private static WebElement noEmailLabel;

    @FindBy(how = How.CSS, using = "input[id$='-qEmailAddressNA']")
    private static WebElement noEmailCheckBox;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_13_1']")
    private static WebElement telephoneSpan;

    @FindBy(how = How.CSS, using = "label[for$='-qPhoneNumberNA']")
    private static WebElement noTelephoneLabel;

    @FindBy(how = How.CSS, using = "input[id$='-qPhoneNumberNA']")
    private static WebElement noTelephoneCheckBox;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_USCITIZEN']")
    private static WebElement citizenLabel;

    @FindBy(how = How.CSS, using = "div[id$='-I9s1_14_USCITIZEN']")
    private static WebElement citizenRadioButton;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_USNONCITIZENNATIONAL']")
    private static WebElement noncitizenLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_USNONCITIZENNATIONAL']")
    private static WebElement noncitizenRadioButton;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_LAWFULPERMANENTRESIDENT']")
    private static WebElement lawfulPermLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_LAWFULPERMANENTRESIDENT']")
    private static WebElement lawfulPermRadioButton;

    @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_ALIENAUTHORIZEDTOWORK']")
    private static WebElement alienLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_ALIENAUTHORIZEDTOWORK']")
    private static WebElement alienRadioButton;

    @FindBy(how = How.CSS, using = "label[for$='-qCertifySigning']")
    private static WebElement iAcknowledgeLabel;

    @FindBy(how = How.CSS, using = "input[id$='-qCertifySigning']")
    private static WebElement iAcknowledgeCheckBox;

    // endregion

    public static void clickReturnButton() {
        returnButton.click();
    }

    public static String getFirstNameText() {
        return firstNameSpan.getText();
    }

    public static String getMiddleNameText() {
        return middleNameSpan.getText();
    }

    public static boolean isNoMiddleNameChecked() {
        return noMiddleNameCheckBox.isSelected();
    }

    public static String getLastNameText() {
        return lastNameSpan.getText();
    }

    public static String getOtherNamesText() {
        return otherNamesSpan.getText();
    }

    public static boolean isNoOtherNamesChecked() {
        return noOtherNamesCheckbox.isSelected();
    }

    public static String getSsnText() {
        return ssnSpan.getText();
    }

    public static String getDobText() {
        return dobSpan.getText();
    }

    public static String getAddressText() {
        return addressSpan.getText();
    }

    public static String getAptNumberText() {
        return aptNumberSpan.getText();
    }

    public static boolean isNoAptNumberChecked() {
        return noAptNumberCheckBox.isSelected();
    }

    public static String getCityText() {
        return citySpan.getText();
    }

    public static String getCountryText() {
        return countrySpan.getText();
    }

    public static String getStateText() {
        return stateSpan.getText();
    }

    public static String getZipText() {
        return zipSpan.getText();
    }

    public static String getEmailText() {
        return emailSpan.getText();
    }

    public static boolean isNoEmailChecked() {
        return noEmailCheckBox.isSelected();
    }

    public static String getTelephoneText() {
        return telephoneSpan.getText();
    }

    public static boolean isNoTelephoneChecked() {
        return noTelephoneCheckBox.isSelected();
    }

    public static boolean isCitizenChecked() {
        return citizenRadioButton.isSelected();
    }

    public static boolean isNoncitizenChecked() {
        return noncitizenRadioButton.isSelected();
    }

    public static boolean isLawfulPermChecked() {
        return lawfulPermRadioButton.isSelected();
    }

    public static boolean isAlienChecked() {
        return alienRadioButton.isSelected();
    }

    public static boolean isiAcknowledgeChecked() {
        return iAcknowledgeCheckBox.isSelected();
    }
}
