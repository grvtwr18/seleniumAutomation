package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Form_16502_Profile extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='16502-16502_19_Home']")
    private WebElement primaryPhoneHomeRadioLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='16502-16502_19_Cell']")
    private WebElement primaryPhoneCellRadioLabel;

    public static Form_16502_Profile getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16502_Profile.class);
    }
    public void choosePrimaryPhoneHomeRadio() {
        primaryPhoneHomeRadioLabel.click();
        staticLogger.info("Primary Phone set to Home Phone");
    }

    public void choosePrimaryPhoneCellRadio() {
        primaryPhoneCellRadioLabel.click();
        staticLogger.info("Primary Phone set to Cell Phone");
    }

}

