package Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * The third candidate form in three step I-9 (FS 4577)
 */
public class ThreeStepSection1Upload extends CandidatePortalPages {

    static {
        PageFactory.initElements(Driver.getDriver(), ThreeStepSection1Upload.class);
    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {
    }

    // region Locators

    //TODO PDF link?


    @FindBy(how = How.CSS, using = "label[for$='-310_15_List A']")
    private static WebElement listALabel;

    @FindBy(how = How.CSS, using = "input[id$='-310_15_List A']")
    private static WebElement listARadioButton;

    @FindBy(how = How.CSS, using = "label[for$='-310_15_List B and C']")
    private static WebElement listBCLabel;

    @FindBy(how = How.CSS, using = "input[id$='-310_15_List B and C']")
    private static WebElement listBCRadioButton;

    @FindBy(how = How.CSS, using = "select[id$='-311_4']")
    private static WebElement listADropDown;

    @FindBy(how = How.CSS, using = "select[id$='-311_25']")
    private static WebElement listBDropDown;

    @FindBy(how = How.CSS, using = "select[id$='-311_33']")
    private static WebElement listCDropDown;

    @FindBy(how = How.XPATH, using = "//select[@id = '19604-I9s1_20_1']")
    private static WebElement issuingCountryDropDown;

    @FindBy(how = How.CSS, using = "input[id$='-310_3-filebrowse']")
    private static WebElement filePathBox;

    @FindBy(how = How.CLASS_NAME, using = "btnPostFileToServer")
    private static WebElement uploadFileButton;


    @FindBy(how = How.CSS, using = "label[for$='-310_9']")
    private static WebElement iAcknowledgeLabel;

    @FindBy(how = How.CSS, using = "input[id$='-310_9']")
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.CSS, using = "label[for$='-310_62']")
    private static WebElement iFurtherAcknowledgeLabel;

    @FindBy(how = How.CSS, using = "input[id$='-310_62']")
    private static WebElement iFurtherAcknowledgeCheckbox;

    // TODO Un-unpload functionality?

    // endregion

    public static void chooseListA() {
        listALabel.click();
        SeleniumTest.waitForElementVisible(listADropDown);
    }

    public static void chooseListBC() {
        listBCLabel.click();
        SeleniumTest.waitForElementVisible(listBDropDown);
        SeleniumTest.waitForElementVisible(listCDropDown);
    }

    public static void SelectIssuingCountry(String country) {
        SeleniumTest.selectByVisibleTextFromDropDown(issuingCountryDropDown, country);
    }

    public static void selectListDocument(Section2.Documents.ListDocuments document) {
        switch (document.getListType()) {
            case "A":
                selectListADocument(document.getName());
                break;
            case "B":
                selectListBDocument(document.getName());
                break;
            case "C":
                selectListCDocument(document.getName());
                break;
        }
    }

    public static void selectListADocument(String document) {
        SeleniumTest.selectByVisibleTextFromDropDown(listADropDown, document);
    }

    public static void selectListBDocument(String document) {
        SeleniumTest.selectByVisibleTextFromDropDown(listBDropDown, document);
    }

    public static void selectListCDocument(String document) {
        SeleniumTest.selectByVisibleTextFromDropDown(listCDropDown, document);
    }

    public static void setFileToUpload(String filePath) {
        if (OS.isFamilyWindows()) {
            filePath = filePath.replace('/', '\\');
        }
        ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" + filePathBox.getAttribute("id") + "').style.visibility = 'visible';");
        if (!filePath.startsWith("/") && !filePath.contains(":")) {
            filePath = "/" + filePath;
        }
        filePathBox.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(uploadFileButton, 10);
    }

    public static void clickUploadFile() {
        uploadFileButton.click();
        SeleniumTest.waitForElementToBeClickable(By.xpath("//label[text()='Previously Uploaded:']"), 60);
    }

    public static void checkIAcknowledgeCheckbox() {
        if (!iAcknowledgeCheckbox.isSelected()) {
            iAcknowledgeLabel.click();
        }
    }

    public static void uncheckIAcknowledgeCheckbox() {
        if (iAcknowledgeCheckbox.isSelected()) {
            iAcknowledgeLabel.click();
        }
    }

    public static void checkIFurtherAcknowledgeCheckbox() {
        if (!iFurtherAcknowledgeCheckbox.isSelected()) {
            iFurtherAcknowledgeLabel.click();
        }
    }

    public static void uncheckIFurtherAcknowledgeCheckbox() {
        if (iFurtherAcknowledgeCheckbox.isSelected()) {
            iFurtherAcknowledgeLabel.click();
        }
    }
}
