package Sites.CandidatePortal.Forms.Objects.I9;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by davidlam on 2/10/17.
 */
public class WorkEligibilityDocument {

    private String title;
    private String type;
    private String issuingAuthority;
    private String docNumber;
    private LocalDate expDate;
    private boolean isReceipt;
    private boolean hasExpDate;
    private String expirationReportTitle;

    private DocumentLocation docLocation;

    public WorkEligibilityDocument(
            String title, String type, String issuingAuthority, String docNumber, LocalDate expDate,
            boolean isReceipt, DocumentLocation docEnum, boolean hasExpDate) {
        this(title, type, issuingAuthority, docNumber, expDate, isReceipt, docEnum, hasExpDate, "");
    }

    public WorkEligibilityDocument(
            String title, String type, String issuingAuthority, String docNumber, LocalDate expDate,
            boolean isReceipt, DocumentLocation docEnum, boolean hasExpDate, String expirationReportTitle) {
        this.title = title;
        this.type = type;
        this.issuingAuthority = issuingAuthority;
        this.docNumber = docNumber;
        this.expDate = expDate;
        this.isReceipt = isReceipt;
        this.docLocation = docEnum;
        this.hasExpDate = hasExpDate;
        this.expirationReportTitle = expirationReportTitle;
    }

    public DocumentLocation getDocLocation() { return this.docLocation; }

    public String getIssuingAuthority() { return this.issuingAuthority; }
    public String getTitle() { return this.title; }
    public String getType() { return this.type; }
    public String getDocNumber() { return this.docNumber; }
    public String getExpDateStr() { return this.expDate.format(DateTimeFormatter.ofPattern("MM/dd/YYYY")); }
    public LocalDate getExpDate() { return this.expDate; }
    public boolean isReceipt() { return this.isReceipt; }
    public boolean isHasExpDate() { return this.hasExpDate; }
    public String getExpirationReportTitle() { return this.expirationReportTitle; }
}
