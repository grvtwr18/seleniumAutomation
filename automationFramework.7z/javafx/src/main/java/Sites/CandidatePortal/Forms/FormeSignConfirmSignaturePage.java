package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 8/31/2015.
 */
public class FormeSignConfirmSignaturePage extends FormPage {

    @FindBy(how = How.ID, using = "previewButton")
    private static WebElement proceedToeSignPreviewButton;

    static {
        PageFactory.initElements(Driver.getDriver(), FormeSignConfirmSignaturePage.class);
    }


    /**
     * Clicks on Proceed to eSign Preview Button
     */
    public static FormeSignPreviewPage clickProceedToeSignPreviewButton() {
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(proceedToeSignPreviewButton);
        proceedToeSignPreviewButton.click();
         return PageFactory.initElements(Driver.getDriver(), FormeSignPreviewPage.class);
    }
}
