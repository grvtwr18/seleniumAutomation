package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FormNC4 extends CandidatePortalPages {
    protected static final Logger staticLogger = LoggerFactory.getLogger(FormNC4.class);

    @FindBy(how = How.ID,using = "1854-1854_7")
    private WebElement TotalAllowancesTextbox;

    @FindBy(how = How.ID,using = "1854-1854_7-err")
    private WebElement TotalAllowancesTextboxErrorMessage;

    @FindBy(how = How.ID,using = "1854-1854_9")
    private WebElement AdditionalWithholdingsTextbox;

    @FindBy(how = How.ID,using = "1854-1854_10")
    private WebElement MaritalStatusDropDown;

    @FindBy(how = How.ID,using = "1854-1854_12")
    private WebElement CountryTextbox;

    @FindBy(how = How.ID,using = "1854-1854_12-err")
    private WebElement CountryTextboxErrorMessage;

    @FindBy(how = How.XPATH,using = "//label[text()='I Certify']")
    private WebElement IcertifyLabel;

    @FindBy(how = How.XPATH, using = "//input[@fieldname='I Certify']")
    private WebElement IcertifyCheckbox;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Residency Statement']")
    private WebElement residencyStatementDropDown;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Employment Statement']")
    private WebElement employeeStatementDropDown;

    @FindBy(how = How.XPATH, using = "//button[@value='Next']")
    private WebElement nextButton;

    public void enterTotalAllowances(String Allowances)
    {
        SeleniumTest.clearAndSetText(TotalAllowancesTextbox,Allowances);
    }

    public void enterAdditionalWithholding(String AdditionalWithholding)
    {
        SeleniumTest.clearAndSetText(AdditionalWithholdingsTextbox,AdditionalWithholding);
    }

    public void selectMaritalStatus(String status)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(MaritalStatusDropDown,status);
    }
    public void enterCountry(String countryName)
    {
        SeleniumTest.clearAndSetText(CountryTextbox,countryName);
    }

    public void clickIcertify()
    {
        SeleniumTest.check(IcertifyLabel,IcertifyCheckbox);
    }

    public void enterResidencyStatement(String statement,String stateName)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropDown,statement+" "+stateName);
    }

    public void enterEmployementStatement(String statement,String stateName)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(employeeStatementDropDown,statement+" "+stateName);
    }

    public void clickNext()
    {
        SeleniumTest.click(nextButton);
    }

    public CandidatePortalPages clickNextBtn(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public boolean areErrorsForMandatoryFieldsVisible()
    {
        if(SeleniumTest.isElementVisibleNoWaiting(By.id("1854-1854_7-err")))
        {
            if(SeleniumTest.isElementVisibleNoWaiting(By.id("1854-1854_12-err")))
            {
                return true;
            }
        }
        return false;
    }

}
