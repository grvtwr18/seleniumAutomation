package Sites.CandidatePortal.Forms;

import Sites.Site;
import Sites.URL;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;

public class W4CalculatorPage {

    @FindBy(how = How.XPATH, using = "//label[@for='105-105_37_No']")
    private WebElement w4CalculatorClaimFederalTaxNo;

    @FindBy(how = How.ID, using = "openW4Calculator")
    private WebElement w4CalculatorModalOpenLink;

    @FindBy(how = How.ID, using = "W4Page1")
    private WebElement w4Page1;

    @FindBy(how = How.ID, using = "W4Page2")
    private WebElement w4Page2;

    @FindBy(how = How.ID, using = "W4Page3")
    private WebElement w4Page3;

    @FindBy(how = How.ID, using = "W4Page4")
    private WebElement w4Page4;

    @FindBy(how = How.ID, using = "W4Page5")
    private WebElement w4Page5;

    @FindBy(how = How.ID, using = "W4continue1")
    private WebElement w4Continue1Button;

    @FindBy(how = How.ID, using = "W4continue2")
    private WebElement w4Continue2Button;

    @FindBy(how = How.ID, using = "W4back2")
    private WebElement w4Back2Button;

    @FindBy(how = How.ID, using = "W4continue3")
    private WebElement w4Continue3Button;

    @FindBy(how = How.ID, using = "W4back3")
    private WebElement w4Back3Button;

    @FindBy(how = How.ID, using = "W4apply3")
    private WebElement w4Apply3Button;

    @FindBy(how = How.ID, using = "W4continue4")
    private WebElement w4Continue4Button;

    @FindBy(how = How.ID, using = "W4back4")
    private WebElement w4Back4Button;

    @FindBy(how = How.ID, using = "W4continue5")
    private WebElement w4Continue5Button;

    @FindBy(how = How.ID, using = "W4back5")
    private WebElement w4Back5Button;

    @FindBy(how = How.ID, using = "A")
    private WebElement hiddenDivA;

    @FindBy(how = How.ID, using = "B")
    private WebElement hiddenDivB;

    @FindBy(how = How.ID, using = "C")
    private WebElement hiddenDivC;

    @FindBy(how = How.ID, using = "D")
    private WebElement hiddenDivD;

    @FindBy(how = How.ID, using = "E")
    private WebElement hiddenDivE;

    @FindBy(how = How.ID, using = "F")
    private WebElement hiddenDivF;

    @FindBy(how = How.ID, using = "G")
    private WebElement hiddenDivG;

    @FindBy(how = How.ID, using = "H")
    private WebElement hiddenDivH;

    @FindBy(how = How.ID, using = "I")
    private WebElement hiddenDivI;

    @FindBy(how = How.ID, using = "J")
    private WebElement hiddenDivJ;

    @FindBy(how = How.ID, using = "D1")
    private WebElement hiddenDivD1;

    @FindBy(how = How.ID, using = "D2")
    private WebElement hiddenDivD2;

    @FindBy(how = How.ID, using = "D3")
    private WebElement hiddenDivD3;

    @FindBy(how = How.ID, using = "D4")
    private WebElement hiddenDivD4;

    @FindBy(how = How.ID, using = "D5")
    private WebElement hiddenDivD5;

    @FindBy(how = How.ID, using = "D6")
    private WebElement hiddenDivD6;

    @FindBy(how = How.ID, using = "D7")
    private WebElement hiddenDivD7;

    @FindBy(how = How.ID, using = "D8")
    private WebElement hiddenDivD8;

    @FindBy(how = How.ID, using = "D9")
    private WebElement hiddenDivD9;

    @FindBy(how = How.ID, using = "D10")
    private WebElement hiddenDivD10;

    @FindBy(how = How.ID, using = "T1")
    private WebElement hiddenDivT1;

    @FindBy(how = How.ID, using = "T2")
    private WebElement hiddenDivT2;

    @FindBy(how = How.ID, using = "T3")
    private WebElement hiddenDivT3;

    @FindBy(how = How.ID, using = "T4")
    private WebElement hiddenDivT4;

    @FindBy(how = How.ID, using = "T5")
    private WebElement hiddenDivT5;

    @FindBy(how = How.ID, using = "T6")
    private WebElement hiddenDivT6;

    @FindBy(how = How.ID, using = "T7")
    private WebElement hiddenDivT7;

    @FindBy(how = How.ID, using = "T8")
    private WebElement hiddenDivT8;

    @FindBy(how = How.ID, using = "T9")
    private WebElement hiddenDivT9;

    @FindBy(how = How.ID, using = "T9A")
    private WebElement hiddenDivT9A;

    @FindBy(how = How.ID, using = "dev-tools")
    private WebElement devToolsRedElementOfTerror;

    @FindBy(how = How.ID, using = "NotADependent")
    private WebElement checkboxNotADependent;

    @FindBy(how = How.ID, using = "ClaimSpouse")
    private WebElement checkboxClaimSpouse;

    @FindBy(how = How.ID, using = "HeadOfHousehold")
    private WebElement checkboxHeadOfHousehold;

    @FindBy(how = How.ID, using = "HasHousalIncome")
    private WebElement checkboxHasHousalIncome;

    @FindBy(how = How.ID, using = "ChildTaxCredit")
    private static WebElement selectChildTaxCreditField;

    @FindBy(how = How.ID, using = "OtherDependents")
    private static WebElement selectOtherDependentsField;

    @FindBy(how = How.ID, using = "OtherCredits")
    private static WebElement inputOtherCreditsField;

    @FindBy(how = How.ID, using = "reduceWithholdingYes")
    private WebElement chooseRadioReduceWithholdingYes;

    @FindBy(how = How.ID, using = "reduceWithholdingNo")
    private WebElement chooseRadioReduceWithholdingNo;

    @FindBy(how = How.ID, using = "additionalIncomeYes")
    private WebElement chooseRadioAdditionalIncomeYes;

    @FindBy(how = How.ID, using = "additionalIncomeNo")
    private WebElement chooseRadioAdditionalIncomeNo;

    @FindBy(how = How.ID, using = "UnableToRedirect")
    private WebElement errorMessageUnableToRedirect;

    @FindBy(how = How.ID, using = "ItemizedDeductions")
    private static WebElement inputItemizedDeductionsField;

    @FindBy(how = How.ID, using = "JointFiling")
    private static WebElement selectJointFilingField;

    @FindBy(how = How.ID, using = "JointFilingError")
    private WebElement errorMessageJointFilingError;

    @FindBy(how = How.ID, using = "IncomeAdjustments")
    private static WebElement inputIncomeAdjustmentsField;

    @FindBy(how = How.ID, using = "ConvertingCredit")
    private static WebElement inputConvertingCreditField;

    @FindBy(how = How.ID, using = "LowestPayingJob")
    private static WebElement selectLowestPayingJobField;

    @FindBy(how = How.ID, using = "LowestPayingJobError")
    private WebElement errorMessageLowestPayingJob;

    @FindBy(how = How.ID, using = "HighestPayingJob")
    private static WebElement selectHighestPayingJobField;

    @FindBy(how = How.ID, using = "HighestPayingJobError")
    private WebElement errorMessageHighestPayingJob;

    @FindBy(how = How.ID, using = "NumberOfPayPeriods")
    private static WebElement selectNumberOfPayPeriodsField;

    @FindBy(how = How.ID, using = "105-105_3")
    private static WebElement inputTotalAllowanceNumber;

    @FindBy(how = How.ID, using = "105-105_4")
    private static WebElement inputAdditionalWithdraw;

    /**
     * Navigates to the ATS Tools page and initiates the page object.
     * @return
     */
    public static W4CalculatorPage navigateToUrl(Boolean IsResponsive) {
        String urlToNavigateTo = URL.getURL(Site.CUSTOMER_DASHBOARD);
        String URLParams;
        if (IsResponsive == true) {
            URLParams = "/admin/previewform.php?formID=105&previewForm=1&OverrideUserID=11&uberrwd=1";
        } else {
            URLParams = "/admin/previewform.php?formID=105&previewForm=1&OverrideUserID=11";
        }
        SeleniumTest.navigateToUrl(urlToNavigateTo + URLParams);
        return PageFactory.initElements(Driver.getDriver(), W4CalculatorPage.class);
    }


    public void clickRadioClaimFederalTaxNo () {
        SeleniumTest.click(w4CalculatorClaimFederalTaxNo);
    }

    public void clickUserOurCalculator () {
        SeleniumTest.click(w4CalculatorModalOpenLink);
    }

    public boolean isW4Page1Visible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(w4Page1.getAttribute("id")));
    }

    public boolean isW4Page2Visible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(w4Page2.getAttribute("id")));
    }

    public boolean isW4Page3Visible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(w4Page3.getAttribute("id")));
    }

    public boolean isW4Page4Visible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(w4Page4.getAttribute("id")));
    }

    public boolean isW4Page5Visible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(w4Page5.getAttribute("id")));
    }

    public void clickW4Page1ContinueButton () {
        SeleniumTest.click(w4Continue1Button);
    }

    public void clickW4Page2ContinueButton () {
        SeleniumTest.click(w4Continue2Button);
    }

    public void clickW4Page2BackButton () {
        SeleniumTest.click(w4Back2Button);
    }

    public void clickW4Page3BackButton () {
        SeleniumTest.click(w4Back3Button);
    }

    public void clickW4Page3ApplyButton () {
        SeleniumTest.click(w4Apply3Button);
    }

    public void clickW4Page4ContinueButton () {
        SeleniumTest.click(w4Continue4Button);
    }

    public void clickW4Page4BackButton () {
        SeleniumTest.click(w4Back4Button);
    }

    public void clickW4Page5ContinueButton () {
        SeleniumTest.click(w4Continue5Button);
    }

    public void clickW4Page5BackButton () {
        if (SeleniumTest.isElementPresent(devToolsRedElementOfTerror)) {
            JavaScriptHelper.runScript("document.getElementById('dev-tools').style.display = 'none';");
        }
        SeleniumTest.click(w4Back5Button);
    }

    public String getHiddenDivAValue () {
        return hiddenDivA.getAttribute("innerHTML");
    }

    public String getHiddenDivBValue () {
        return hiddenDivB.getAttribute("innerHTML");
    }

    public String getHiddenDivCValue () {
        return hiddenDivC.getAttribute("innerHTML");
    }

    public String getHiddenDivDValue () {
        return hiddenDivD.getAttribute("innerHTML");
    }

    public String getHiddenDivEValue () {
        return hiddenDivE.getAttribute("innerHTML");
    }

    public String getHiddenDivFValue () {
        return hiddenDivF.getAttribute("innerHTML");
    }

    public String getHiddenDivGValue () {
        return hiddenDivG.getAttribute("innerHTML");
    }

    public String getHiddenDivHValue () {
        return hiddenDivH.getAttribute("innerHTML");
    }

    public String getHiddenDivIValue () {
        return hiddenDivI.getAttribute("innerHTML");
    }

    public String getHiddenDivJValue () {
        return hiddenDivJ.getAttribute("innerHTML");
    }

    public String getHiddenDivD1Value () {
        return hiddenDivD1.getAttribute("innerHTML");
    }

    public String getHiddenDivD2Value () {
        return hiddenDivD2.getAttribute("innerHTML");
    }

    public String getHiddenDivD3Value () {
        return hiddenDivD3.getAttribute("innerHTML");
    }

    public String getHiddenDivD4Value () {
        return hiddenDivD4.getAttribute("innerHTML");
    }

    public String getHiddenDivD5Value () {
        return hiddenDivD5.getAttribute("innerHTML");
    }

    public String getHiddenDivD6Value () {
        return hiddenDivD6.getAttribute("innerHTML");
    }

    public String getHiddenDivD7Value () {
        return hiddenDivD7.getAttribute("innerHTML");
    }

    public String getHiddenDivD8Value () {
        return hiddenDivD8.getAttribute("innerHTML");
    }

    public String getHiddenDivD9Value () {
        return hiddenDivD9.getAttribute("innerHTML");
    }

    public String getHiddenDivD10Value () {
        return hiddenDivD10.getAttribute("innerHTML");
    }

    public String getHiddenDivT1Value () {
        return hiddenDivT1.getAttribute("innerHTML");
    }

    public String getHiddenDivT2Value () {
        return hiddenDivT2.getAttribute("innerHTML");
    }

    public String getHiddenDivT3Value () {
        return hiddenDivT3.getAttribute("innerHTML");
    }

    public String getHiddenDivT4Value () {
        return hiddenDivT4.getAttribute("innerHTML");
    }

    public String getHiddenDivT5Value () {
        return hiddenDivT5.getAttribute("innerHTML");
    }

    public String getHiddenDivT6Value () {
        return hiddenDivT6.getAttribute("innerHTML");
    }

    public String getHiddenDivT7Value () {
        return hiddenDivT7.getAttribute("innerHTML");
    }

    public String getHiddenDivT8Value () {
        return hiddenDivT8.getAttribute("innerHTML");
    }

    public String getHiddenDivT9Value () {
        return hiddenDivT9.getAttribute("innerHTML");
    }

    public String getHiddenDivT9AValue () {
        return hiddenDivT9A.getAttribute("innerHTML");
    }

    public void checkCheckboxNotADependent () {
        SeleniumTest.check(checkboxNotADependent);
    }

    public void unCheckCheckboxNotADependent () {
        SeleniumTest.unCheck(checkboxNotADependent);
    }

    public void checkCheckboxClaimSpouse () {
        SeleniumTest.check(checkboxClaimSpouse);
    }

    public void unCheckCheckboxClaimSpouse () {
        SeleniumTest.unCheck(checkboxClaimSpouse);
    }

    public void checkCheckboxHeadOfHousehold () {
        SeleniumTest.check(checkboxHeadOfHousehold);
    }

    public void unCheckCheckboxHeadOfHousehold () {
        SeleniumTest.unCheck(checkboxHeadOfHousehold);
    }

    public void checkCheckboxHasHousalIncome () {
        SeleniumTest.check(checkboxHasHousalIncome);
    }

    public void unCheckCheckboxHasHousalIncome () {
        SeleniumTest.unCheck(checkboxHasHousalIncome);
    }

    public static void setSelectOtherDependentsFieldValue(String otherDependentsValue){
        new Select(selectOtherDependentsField).selectByValue(otherDependentsValue);
        ((HasInputDevices)Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    public String getSelectOtherDependentsFieldValue () {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(selectOtherDependentsField);
    }

    public List<String> getAllValuesInChildTaxCreditDropDown() {
        Select theDropDown = new Select(selectChildTaxCreditField);
        List<String> values = new ArrayList<>();
        for(WebElement element : theDropDown.getOptions()) {
            values.add(element.getAttribute("value"));
        }
        return values;
    }

    public static void setSelectChildTaxCreditFieldValue(String selectChildTaxCreditValue){
        new Select(selectChildTaxCreditField).selectByValue(selectChildTaxCreditValue);
        ((HasInputDevices)Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    public String getSelectChildTaxCreditFieldValue () {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(selectChildTaxCreditField);
    }

    public static void setOtherCreditsFieldValue(String selectOtherCreditsFieldValue){
        SeleniumTest.clearAndSetText(inputOtherCreditsField, selectOtherCreditsFieldValue, true);
    }

    public String getOtherCreditsFieldValue () {
        return inputOtherCreditsField.getAttribute("value");
    }

    public void chooseRadioReduceWithholdingYes() {
        chooseRadioReduceWithholdingYes.click();
    }

    public void chooseRadioReduceWithholdingNo() {
        chooseRadioReduceWithholdingNo.click();
    }

    public void chooseRadioAdditionalIncomeYes() {
        chooseRadioAdditionalIncomeYes.click();
    }

    public void chooseRadioAdditionalIncomeNo() {
        chooseRadioAdditionalIncomeNo.click();
    }

    public boolean isErrorMessageUnableToRedirectVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(errorMessageUnableToRedirect.getAttribute("id")));
    }

    public static void setSelectJointFilingFieldValue(String jointFilingFieldValue){
        new Select(selectJointFilingField).selectByValue(jointFilingFieldValue);
        ((HasInputDevices)Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    public String getSelectJointFilingFieldValue () {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(selectJointFilingField);
    }

    public static void setItemizedDeductionsFieldValue(String selectItemizedDeductionsFieldValue){
        SeleniumTest.clearAndSetText(inputItemizedDeductionsField, selectItemizedDeductionsFieldValue, true);
    }

    public String getItemizedDeductionsFieldValue () {
        return inputItemizedDeductionsField.getAttribute("value");
    }

    public static void setIncomeAdjustmentsFieldValue(String selectIncomeAdjustmentsFieldValue){
        SeleniumTest.clearAndSetText(inputIncomeAdjustmentsField, selectIncomeAdjustmentsFieldValue, true);
    }

    public String getIncomeAdjustmentsFieldValue () {
        return inputIncomeAdjustmentsField.getAttribute("value");
    }

    public static void setConvertingCreditFieldValue(String selectConvertingCreditFieldValue){
        SeleniumTest.clearAndSetText(inputConvertingCreditField, selectConvertingCreditFieldValue, true);
    }

    public String getConvertingCreditFieldValue () {
        return inputConvertingCreditField.getAttribute("value");
    }

    public static void setSelectLowestPayingJobFieldValue(String lowestPayingJobFieldValue){
        new Select(selectLowestPayingJobField).selectByValue(lowestPayingJobFieldValue);
        ((HasInputDevices)Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    public String getSelectLowestPayingJobFieldValue () {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(selectLowestPayingJobField);
    }

    public static void setSelectHighestPayingJobFieldValue(String highestPayingJobFieldValue){
        new Select(selectHighestPayingJobField).selectByValue(highestPayingJobFieldValue);
        ((HasInputDevices)Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    public String getSelectHighestPayingJobFieldValue () {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(selectHighestPayingJobField);
    }

    public static void setSelectNumberOfPayPeriodsFieldValue(String numberOfPayPeriodsFieldValue){
        new Select(selectNumberOfPayPeriodsField).selectByValue(numberOfPayPeriodsFieldValue);
        ((HasInputDevices)Driver.getDriver()).getKeyboard().sendKeys(Keys.TAB);
    }

    public String getSelectNumberOfPayPeriodsFieldValue () {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(selectNumberOfPayPeriodsField);
    }

    public boolean isErrorMessageJointFilingErrorVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(errorMessageJointFilingError.getAttribute("id")));
    }

    public boolean isErrorMessageLowestPayingJobVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(errorMessageLowestPayingJob.getAttribute("id")));
    }

    public boolean isErrorMessageHighestPayingJobVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id(errorMessageHighestPayingJob.getAttribute("id")));
    }

    public String getTotalAllowanceNumberFieldValue () {
        return inputTotalAllowanceNumber.getAttribute("value");
    }

    public String getAdditionalWithdrawFieldValue () {
        return inputAdditionalWithdraw.getAttribute("value");
    }

    public boolean isAdditionalWithdrawFieldVisible() {
        return SeleniumTest.isElementVisible(inputAdditionalWithdraw);
    }
}
