package Sites.CandidatePortal.Forms.Objects.I9;

import Data.locations.us.UsStateTerritory;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: abajpai
 * Date: 1/26/17
 * Time: 3:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class PaperWorkflowI9 extends I9Base {

    static {
        PageFactory.initElements(Driver.getDriver(), PaperWorkflowI9.class);
    }

    protected static final Logger staticLogger = LoggerFactory.getLogger(PaperWorkflowI9.class);

    public static class Section1 {
        static {
            PageFactory.initElements(Driver.getDriver(), PaperWorkflowI9.Section1.class);
        }

        @FindBy(how = How.LINK_TEXT, using = "Test: AAW 776 - Photo Verification")
        private static WebElement section1PhotoVerificationLink;

        @FindBy(how = How.XPATH, using = "//input[@id='qLawfulPermanentResidentAlienID']")
        private static WebElement txtAlienNumber;

        @FindBy(how = How.XPATH, using = "//input[@id='qssn']")
        private static WebElement txtSSN;

        public static void fillSection1Details(String alienNumber) {
            SeleniumTest.clearAndSetText(txtAlienNumber, alienNumber);
        }

        public static void setSSN(String ssn) {
            SeleniumTest.clearAndSetText(txtSSN, ssn);
        }

        public static class DevPrefillLinks {

            static {
                PageFactory.initElements(Driver.getDriver(), PaperWorkflowI9.Section1.DevPrefillLinks.class);
            }

            public static void clickPrefillLink(String testSpecificLinkTextString) {
                Driver.getDriver().findElement(By.linkText(testSpecificLinkTextString)).click();
                SeleniumTest.waitForPageLoadToComplete();
            }

        }

        public static class Section1Intro {

            static {
                PageFactory.initElements(Driver.getDriver(), Section1Intro.class);
            }

            @FindBy(how = How.NAME, using = "qi9version")
            public static WebElement i9VersionPaperS1;

            public static String getI9Version() {

                return i9VersionPaperS1.getText();
            }

            /**
             * Choose Current I9 version 5
             */
            public static void chooseCurrentI9Version5() {
                Select selectVersion = new Select(
                        Driver.getDriver().findElement(By.id("qi9version")));
                selectVersion.selectByValue("5");
            }

            /**
             * Choose Previous I9 version 4
             */
            public static void choosePreviousI9Version4() {
                Select selectVersion = new Select(
                        Driver.getDriver().findElement(By.id("qi9version")));
                selectVersion.selectByValue("4");
            }

        }

        public static class EmployeeInfo {

            public static class Name {

                static {
                    PageFactory.initElements(Driver.getDriver(), Name.class);
                }

                @FindBy(how = How.NAME, using = "qf")
                private static WebElement firstNamePaperS1;

                @FindBy(how = How.CSS, using = "input[name='qf']:first-of-type + div")
                private static WebElement firstNameError;

                /**
                 * Gets the first name from the form
                 *
                 * @return
                 */
                public static String getFirstName() {
                    return firstNamePaperS1.getText();
                }

                public static void setFirstName(String firstName) {
                    SeleniumTest.clearAndSetText(firstNamePaperS1, firstName);
                    staticLogger.info("First Name set to {}", firstName);
                }

                public static String getFirstNameError() {
                    return firstNameError.getText();
                }

                @FindBy(how = How.CSS, using = "input[id^='qmi']")
                private static WebElement middleInitialPaperS1;

                /**
                 * Gets the middle name from the form
                 *
                 * @return
                 */

                public static String getMiddleName() {
                    return middleInitialPaperS1.getText();
                }

                public static void setMiddleName(String middleName) {
                    SeleniumTest.clearAndSetText(middleInitialPaperS1, middleName);
                    staticLogger.info("Middle Name set to {}", middleName);
                }

                @FindBy(how = How.CSS, using = "div[id='qmi_Err']")
                private static WebElement middleNameError;

                public static String getMiddleNameError() {
                    return middleNameError.getText();
                }

                @FindBy(how = How.NAME, using = "qn")
                private static WebElement lastNamePaperS1;

                @FindBy(how = How.CSS, using = "input[name='qn']:first-of-type + div")
                private static WebElement lastNameError;

                /**
                 * Gets the last name from the form
                 *
                 * @return
                 */
                public static String getLastName() {
                    return lastNamePaperS1.getText();
                }

                public static void setLastName(String lastName) {
                    SeleniumTest.clearAndSetText(lastNamePaperS1, lastName);
                    staticLogger.info("Last Name set to {}", lastName);
                }

                public static String getLastNameError() {
                    return lastNameError.getText();
                }

                @FindBy(how = How.NAME, using = "qnalias")
                private static WebElement otherLastNamePaperS1;

                @FindBy(how = How.CSS, using = "input[name='qnalias']:first-of-type + div")
                private static WebElement alternateNameError;

                public static String getAlternateNameError() {
                    return alternateNameError.getText();
                }

                /**
                 * Gets the alternate name from the form
                 *
                 * @return
                 */
                public static String getAlternateNamesUsed() {
                    return otherLastNamePaperS1.getText();
                }

                public static void setAlternateNamesUsed(String alternateNames) {
                    SeleniumTest.clearAndSetText(otherLastNamePaperS1, alternateNames);
                    staticLogger.info("Alternate Names Used set to {}", alternateNames);
                }

                public static void fillEmployeeInfo(Candidate candidate) {
                    setFirstName(candidate.getFirstName());
                    setLastName(candidate.getLastName());
                }

            }

            public static class SocialSecurityNumber {

                static {
                    PageFactory.initElements(Driver.getDriver(), SocialSecurityNumber.class);
                }

                @FindBy(how = How.CSS, using = "input[id='qssn']")
                private static WebElement ssnPaperS1;

                @FindBy(how = How.CSS, using = "input[id='qssn']:first-of-type ~ div")
                private static WebElement socialSecurityErr;

                /**
                 * Gets the Social Security number from the form
                 *
                 * @return
                 */
                public static String getSocialSecurityNumber() {
                    return ssnPaperS1.getText();
                }

                public static String getSocialSecurityError() {
                    return socialSecurityErr.getText();
                }

                public static void setSocialSecurityNumber(String socialSecurityNumber) {
                    SeleniumTest.clearAndSetText(ssnPaperS1, socialSecurityNumber);
                    staticLogger.info("Social Security Number set to {}", socialSecurityNumber);
                }
            }

            public static class DateOfBirth {

                static {
                    PageFactory.initElements(Driver.getDriver(), DateOfBirth.class);
                }

                @FindBy(how = How.CSS, using = "select[name='qmm']")
                private static WebElement monthOfBirthPaperS1;

                @FindBy(how = How.CSS, using = "select[name='qdd']")
                private static WebElement dayOfBirthPaperS1;

                @FindBy(how = How.CSS, using = "select[name='qyy']")
                private static WebElement yearOfBirthPaperS1;

                private static List<WebElement> dobErrs;
                private static WebElement monthOfBirthErr;
                private static WebElement dayOfBirthErr;
                private static WebElement yearOfBirthErr;

                public static String getMonthOfBirthError() {
                    dobErrs = Driver.getDriver().findElements(By.cssSelector("select[name='qyy'] ~ div"));
                    monthOfBirthErr = dobErrs.get(0);
                    return monthOfBirthErr.getText();
                }

                public static String getDayOfBirthError() {
                    dobErrs = Driver.getDriver().findElements(By.cssSelector("select[name='qyy'] ~ div"));
                    dayOfBirthErr = dobErrs.get(1);
                    return dayOfBirthErr.getText();
                }

                public static String getYearOfBirthError() {
                    dobErrs = Driver.getDriver().findElements(By.cssSelector("select[name='qyy'] ~ div"));
                    yearOfBirthErr = dobErrs.get(2);
                    return yearOfBirthErr.getText();
                }

                public static void selectMonth(LocalDate testDate) {
                    SeleniumTest.selectShortMonthByVisibleText(monthOfBirthPaperS1, testDate);
                    staticLogger.info("DOB Month set to {}", testDate.getMonth());
                }

                public static void selectDay(LocalDate testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(dayOfBirthPaperS1, Integer.toString(testDate.getDayOfMonth()));
                    staticLogger.info("DOB Day set to {}", Integer.toString(testDate.getDayOfMonth()));
                }

                public static void selectYear(LocalDate testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(yearOfBirthPaperS1, Integer.toString(testDate.getYear()));
                    staticLogger.info("DOB Year set to {}", Integer.toString(testDate.getYear()));
                }

                public static void selectYear(String testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(yearOfBirthPaperS1, testDate);
                    staticLogger.info("DOB Year set to {}", testDate);
                }

                public static void selectMonth(String testDate) {
                    SeleniumTest.selectShortMonthByVisibleText(monthOfBirthPaperS1, testDate);
                    staticLogger.info("DOB Month set to {}", testDate);
                }

                public static void selectDay(String testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(dayOfBirthPaperS1, testDate);
                    staticLogger.info("DOB Day set to {}", testDate);
                }

            }

            public static class Address {

                static {
                    PageFactory.initElements(Driver.getDriver(), Address.class);
                }

                @FindBy(how = How.CSS, using = "input[name='qa']")
                private static WebElement addressStreetPaperS1;

                @FindBy(how = How.CSS, using = "input[name='qa']:first-of-type + div")
                private static WebElement addressLine1Err;

                public static String getAddressLineError() {
                    return addressLine1Err.getText();
                }

                /**
                 * Gets the address street number from the form
                 *
                 * @return
                 */
                public static String getAddressStreetName() {
                    return addressStreetPaperS1.getText();
                }

                public static void setAddressStreetName(String addressStreetName) {
                    SeleniumTest.clearAndSetText(addressStreetPaperS1, addressStreetName);
                    staticLogger.info("Address Street Name set to {}", addressStreetName);
                }

                @FindBy(how = How.NAME, using = "qunit")
                private static WebElement apartmentUnitPaperS1;

                /**
                 * Gets the apartment number from the form
                 *
                 * @return
                 */
                public static String getApartmentUnit() {
                    return apartmentUnitPaperS1.getText();
                }

                public static void setApartmentUnit(String apartmentUnit) {
                    SeleniumTest.clearAndSetText(apartmentUnitPaperS1, apartmentUnit);
                    staticLogger.info("Apartment Unit set to {}", apartmentUnit);
                }

                @FindBy(how = How.NAME, using = "qc")
                public static WebElement cityPaperS1;

                /**
                 * Gets the City from the form
                 *
                 * @return
                 */
                public static String getCity() {
                    return cityPaperS1.getText();
                }

                public static void setCity(String city) {
                    SeleniumTest.clearAndSetText(cityPaperS1, city);
                    staticLogger.info("City set to {}", city);
                }

                @FindBy(how = How.NAME, using = "qs")
                public static WebElement statePaperS1;

                /**
                 * Gets the state from the form
                 *
                 * @return
                 */
                public static String getState() {
                    Select state = new Select(statePaperS1);
                    return state.getFirstSelectedOption().getText();
                }

                /**
                 * Selects the state based on expected String
                 *
                 * @param state String representation of the state to select
                 */
                public static void selectState(String state) {
                    SeleniumTest.selectByVisibleTextFromDropDown(statePaperS1, state);
                    staticLogger.info("State set to {}", state);
                }

                /**
                 * Selects the state based on a known State or Territory
                 *
                 * @param stateOrTerritory State or Territory to select
                 */
                public static void selectState(UsStateTerritory stateOrTerritory) {
                    SeleniumTest.selectByVisibleTextFromDropDown(statePaperS1, stateOrTerritory.getFullName());
                    staticLogger.info("State set to {}", stateOrTerritory.getFullName());
                }

                @FindBy(how = How.NAME, using = "qz")
                public static WebElement zipCodePaperS1;

                /**
                 * Gets the zip code from the form
                 *
                 * @return
                 */
                public static String getZipCode() {
                    return zipCodePaperS1.getText();
                }

                public static void setZipCode(String zipCode) {
                    SeleniumTest.clearAndSetText(zipCodePaperS1, zipCode);
                    staticLogger.info("Zip Code set to {}", zipCode);
                }

                @FindBy(how = How.CSS, using = "input[id='qz']:first-of-type + div")
                private static WebElement zipCodeErr;

                public static String getZipCodeError() {
                    return zipCodeErr.getText();
                }

            }

            public static class ContactInfo {

                static {
                    PageFactory.initElements(Driver.getDriver(), ContactInfo.class);
                }

                @FindBy(how = How.NAME, using = "qee")
                private static WebElement emailAddressPaperS1;

                @FindBy(how = How.CSS, using = "input[name='qee']:first-of-type + div")
                private static WebElement emailErr;

                public static String getEmailError() {
                    return emailErr.getText();
                }

                /**
                 * Gets the email address from the form
                 *
                 * @return
                 */
                public static String getEmail() {
                    return emailAddressPaperS1.getText();
                }

                public static void setEmail(String email) {
                    SeleniumTest.clearAndSetText(emailAddressPaperS1, email);
                    staticLogger.info("Email set to {}", email);
                }

                @FindBy(how = How.NAME, using = "qp")
                private static WebElement phoneNumberPaperS1;

                /**
                 * Gets the telephone number from the form
                 *
                 * @return
                 */
                public static String getTelephone() {
                    return phoneNumberPaperS1.getText();
                }

                public static void setTelephone(String telephone) {
                    SeleniumTest.clearAndSetText(phoneNumberPaperS1, telephone);
                    staticLogger.info("Telephone set to {}", telephone);
                }

                @FindBy(how = How.CSS, using = "input[name='qp']:first-of-type + div")
                private static WebElement phoneErr;

                public static String getTelephoneError() {
                    return phoneErr.getText();
                }

            }
        }

        public static class CitizenAttestation {

            static {
                PageFactory.initElements(Driver.getDriver(), CitizenAttestation.class);
            }

            @FindBy(how = How.CSS, using = "label[for$='status']:first-of-type + div")
            private static WebElement workerEligibilityTypeErr;

            public static String getWorkerEligibilityTypeError() {
                return workerEligibilityTypeErr.getText();
            }

            @FindBy(how = How.CSS, using = "input[id='qWorkerEligibilityType1']")
            private static WebElement citizenRadioButtonPaperS1;

            // Choose Citizen
            public static void chooseUSCitizen() {
                citizenRadioButtonPaperS1.click();
                staticLogger.info("Citizen chosen");
            }

            @FindBy(how = How.CSS, using = "input[id='qWorkerEligibilityType2']")
            private static WebElement nonCitizenRadioButtonPaperS1;

            // Choose Non-Citizen
            public static void chooseNonCitizen() {
                nonCitizenRadioButtonPaperS1.click();
                staticLogger.info("NonCitizen chosen");
            }

            @FindBy(how = How.CSS, using = "input[id='qWorkerEligibilityType3']")
            private static WebElement lawfulPermanentResidentRadioButtonPaperS1;

            // Choose Lawful Permanent Resident
            public static void chooseLawfulPermanentResident() {
                lawfulPermanentResidentRadioButtonPaperS1.click();
                staticLogger.info("Lawful Permanent Resident chosen");
            }

            @FindBy(how = How.ID, using = "qLawfulPermanentResidentAlienID")
            private static WebElement permResPaperS1;

            @FindBy(how = How.CSS, using = "input[id='qLawfulPermanentResidentAlienID']:first-of-type+div")
            private static WebElement alienRegistrationNumberErr;

            public static String getAlienRegistrationNumberError() {
                return alienRegistrationNumberErr.getText();
            }

            /**
             * Gets the Perm Res Alien Id from the form
             *
             * @return
             */
            public static String getPermResAlienId() {
                return permResPaperS1.getText();
            }

            public static void setPermResAlienId(String permResAlienId) {
                SeleniumTest.clearAndSetText(permResPaperS1, permResAlienId);
                staticLogger.info("Permanent Resident AlienID set to {}", permResAlienId);
            }

            // Alien Authorized To Work
            @FindBy(how = How.CSS, using = "input[id='qWorkerEligibilityType4']")
            private static WebElement alienAuthorizedToWorkRadioButtonPaperS1;


            // Choose Alien Authorized To Work
            public static void chooseAlienAuthorizedToWork() {
                alienAuthorizedToWorkRadioButtonPaperS1.click();
                staticLogger.info("Alien Authorized to work chosen");
            }

            public static class AlienAuthorizedToWork {

                // Static constructor
                static {
                    PageFactory.initElements(Driver.getDriver(), AlienAuthorizedToWork.class);
                }

                @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkUntilDateMonth")
                private static WebElement aawExpMonthPaperS1;

                @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkUntilDateDay")
                private static WebElement aawExpDayPaperS1;

                @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkUntilDateYear")
                private static WebElement aawExpYearPaperS1;

                @FindBy(how = How.CSS, using = "input[id='qAlienAuthorizedToWorkUtilNA'] ~ div")
                private static WebElement workAuthorizationExpirationDateErr;

                public static String getWorkAuthExpDateError() {
                    return workAuthorizationExpirationDateErr.getText();
                }

                @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkUtilDS")
                private static WebElement aawExpDSPaperS1;

                public static void chooseAAWExpDS() {
                    aawExpDSPaperS1.click();
                }

                @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkUtilNA")
                private static WebElement aawExpNAPaperS1;

                public static void chooseAAWExpNA() {
                    aawExpNAPaperS1.click();
                }

                // Alien Registration Number
                @FindBy(how = How.CSS, using = "input[id='qAlienAuthorizedToWorkIDTypeAlienID']")
                private static WebElement alienRegNumRadioButtonPaperS1;

                /**
                 * Chooses the Alien Registration Number radio button
                 */
                public static void chooseAlienRegistrationNumber() {
                    alienRegNumRadioButtonPaperS1.click();
                }

                /**
                 * Handles actions performed when Alien Registration Number is chosen
                 */
                public static class AlienRegistrationNumber {

                    static {
                        PageFactory.initElements(Driver.getDriver(), AlienRegistrationNumber.class);
                    }

                    @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkAlienID")
                    private static WebElement alienRegNumPaperS1;

                    @FindBy(how = How.CSS, using = "div[id='divqAlienAuthorizedToWorkIDType'] div")
                    private static WebElement aawAlienDocTypeErr;

                    @FindBy(how = How.CSS, using = "input[id='qAlienAuthorizedToWorkAlienID']:first-of-type+div")
                    private static WebElement aawAlienNumberErr;

                    public static String getAlienRegistrationDocTypeError() {
                        return aawAlienDocTypeErr.getText();
                    }

                    public static String getAlienRegistrationDocNumberError() {
                        return aawAlienNumberErr.getText();
                    }

                    /**
                     * Sets the Alien Registration Number
                     *
                     * @param number Number to Set
                     */
                    public static void setAlienRegistrationNumber(String number) {
                        SeleniumTest.clearAndSetText(alienRegNumPaperS1, number);
                    }

                }

                /**
                 * Chooses the I94 Admission Number Radio Button
                 */
                @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkIDI94")
                private static WebElement formI94NumRadioButtonPaperS1;

                public static void chooseI94AdmissionNumber() {
                    formI94NumRadioButtonPaperS1.click();
                }

                /**
                 * Handles actions performed when Form I94 Admission Number is chosen
                 */
                public static class FormI94AdmissionNumber {

                    @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkI94Number")
                    private static WebElement formI94NumPaperS1;

                    @FindBy(how = How.CSS, using = "input[id='qAlienAuthorizedToWorkI94Number']:first-of-type+div")
                    private static WebElement i94AdmissionNumberErr;

                    static {
                        PageFactory.initElements(Driver.getDriver(), FormI94AdmissionNumber.class);
                    }

                    /**
                     * Sets the I94 Admission Number
                     *
                     * @param number
                     */
                    public static void setI94AdmissionNumber(String number) {
                        SeleniumTest.clearAndSetText(formI94NumPaperS1, number);
                    }

                    public static String getI94AdmissionNumberError() {
                        return i94AdmissionNumberErr.getText();
                    }
                }

                // Choose Foreign Passport Number
                @FindBy(how = How.ID, using = "qAlienAuthorizedToWorkIDFPP")
                private static WebElement fppNumRadioButtonPaperS1;

                /**
                 * Chooses the Foreign Passport Number Radio Button
                 */
                public static void chooseForeignPassportNumber() {
                    fppNumRadioButtonPaperS1.click();
                }

                /**
                 * Handles actions performed when Foreign Passport Number is chosen
                 */
                public static class ForeignPassportNumber {

                    static {
                        PageFactory.initElements(Driver.getDriver(), ForeignPassportNumber.class);
                    }

                    @FindBy(how = How.ID, using = "qForeignPassportNumber")
                    private static WebElement foreignPassportNumberTextBoxPaperS1;

                    @FindBy(how = How.ID, using = "qForeignPassportCountry")
                    private static WebElement foreignPassportCountryOfIssuanceDropDownPaperS1;

                    @FindBy(how = How.CSS, using = "input[id='qForeignPassportNumber']:first-of-type+div")
                    private static WebElement foreignPassportNumberErr;

                    @FindBy(how = How.CSS, using = "span[id='qAlienAuthorizedToWorkNoFPPCheckbox']:first-of-type+div")
                    private static WebElement foreignPassportCountryOfIssuanceErr;

                    /**
                     * Sets the Foreign Passport Number
                     *
                     * @param number Number to set
                     */
                    public static void setForeignPassportNumber(String number) {
                        SeleniumTest.clearAndSetText(foreignPassportNumberTextBoxPaperS1, number);
                    }

                    /**
                     * Selects the Country of Issuance
                     *
                     * @param country Country to set
                     */
                    public static void selectCountryOfIssuance(String country) {
                        SeleniumTest.selectByValueFromDropDown(foreignPassportCountryOfIssuanceDropDownPaperS1, country);
                    }

                    public static String getForeignPassportNumberError() {
                        return foreignPassportNumberErr.getText();
                    }

                    public static String getCountryOfIssuanceError() {
                        return foreignPassportCountryOfIssuanceErr.getText();
                    }
                }
            }


            public enum Eligibility {
                USCITIZEN,
                NONCITIZEN,
                LAWFUL_PERMANENT_RESIDENT,
                ALIEN_AUTHORIZED_TO_WORK
            }
        }

    }

    public static class Section2 {

        @FindBy(how = How.XPATH, using = "//input[@id='qSection2DocumentType1']")
        private static WebElement rdoListADocument;

        @FindBy(how = How.XPATH, using = "//input[@id='qSection2DocumentType2']")
        private static WebElement rdoListBDocument;

        @FindBy(how = How.XPATH, using = "//select[@id='qListADocumentType']")
        private static WebElement ddlDocumentATitle;

        @FindBy(how = How.XPATH, using = "//select[@id='qListBDocumentType']")
        private static WebElement ddlDocumentBTitle;

        @FindBy(how = How.XPATH, using = "//select[@id='qListCDocumentType']")
        private static WebElement ddlDocumentCTitle;

        @FindBy(how = How.XPATH, using = "//input[@name='qListADocumentNumber1']")
        private static WebElement txtDocumentNumber;

        @FindBy(how = How.XPATH, using = "//input[@id='qListAIssuingAuthorityText']")
        private static WebElement txtIssuingAuthority;

        @FindBy(how = How.XPATH, using = "//select[@name='qListAExpDateMonth1']")
        private static WebElement ddlExpirationMonth;

        @FindBy(how = How.XPATH, using = "//select[@name='qListAExpDateDay1']")
        private static WebElement ddlExpirationDate;

        @FindBy(how = How.XPATH, using = "//select[@name='qListAExpDateYear1']")
        private static WebElement ddlExpirationYear;

        static {
            PageFactory.initElements(Driver.getDriver(), PaperWorkflowI9.Section2.class);
        }

        public static void fillSection2Details(String docTitle, String authority, String docNumber, LocalDate date) {
            rdoListADocument.click();
            SeleniumTest.selectByVisibleTextFromDropDown(ddlDocumentATitle, docTitle);
            SeleniumTest.clearAndSetText(txtIssuingAuthority, authority);
            SeleniumTest.clearAndSetText(txtDocumentNumber, docNumber);
            SeleniumTest.selectByValueFromDropDown(ddlExpirationMonth, String.valueOf(date.getMonthValue()));
            SeleniumTest.selectByValueFromDropDown(ddlExpirationDate, String.valueOf(date.getDayOfMonth()));
            SeleniumTest.selectByValueFromDropDown(ddlExpirationYear, String.valueOf(date.getYear()));
        }

        public static void selectListBDocument() {
            rdoListBDocument.click();
        }

        public static class DevPrefillLinks {

            static {
                PageFactory.initElements(Driver.getDriver(), PaperWorkflowI9.Section2.DevPrefillLinks.class);
            }

            public static void clickPrefillLink(String testSpecificLinkTextString) {
                if (SeleniumTest.isElementPresent(By.linkText(testSpecificLinkTextString))) {
                    Driver.getDriver().findElement(By.linkText(testSpecificLinkTextString)).click();
                }
            }

        }

        public static class EmploymentDetail {

            static {
                PageFactory.initElements(Driver.getDriver(), EmploymentDetail.class);
            }

            // Employee Start Date Month
            private static WebElement employeeStartMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qstartmonth']"));

            // Employee Start Date Day
            @FindBy(how = How.ID, using = "qstartday")
            private static WebElement employeeStartDayPaperS2;

            // Employee Start Date Year
            @FindBy(how = How.CSS, using = "select[name='qstartyear']")
            private static WebElement employeeStartYearPaperS2;


            private static List<WebElement> empStartDateErrs;
            private static WebElement empStartDateMonthErr;
            private static WebElement empStartDateDayErr;
            private static WebElement empStartDateYearErr;


            public static String getMonthOfEmpStartDateError() {
                empStartDateErrs = Driver.getDriver().findElements(By.cssSelector("select[name='qstartyear'] ~ div"));
                empStartDateMonthErr = empStartDateErrs.get(0);
                return empStartDateMonthErr.getText();
            }

            public static String getDayOfEmpStartDateError() {
                empStartDateErrs = Driver.getDriver().findElements(By.cssSelector("select[name='qstartyear'] ~ div"));
                empStartDateDayErr = empStartDateErrs.get(1);
                return empStartDateDayErr.getText();
            }

            public static String getYearOfEmpStartDateError() {
                empStartDateErrs = Driver.getDriver().findElements(By.cssSelector("select[name='qstartyear'] ~ div"));
                empStartDateYearErr = empStartDateErrs.get(2);
                return empStartDateYearErr.getText();
            }

            public static void selectMonth(LocalDate testDate) {
                SeleniumTest.selectShortMonthByVisibleText(employeeStartMonthPaperS2, testDate);
                staticLogger.info("Employee Start Month set to {}", testDate.getMonth());
            }

            public static void selectDay(LocalDate testDate) {
                SeleniumTest.selectByVisibleTextFromDropDown(employeeStartDayPaperS2, Integer.toString(testDate.getDayOfMonth()));
                staticLogger.info("Employee Start Day set to {}", Integer.toString(testDate.getDayOfMonth()));
            }

            public static void selectYear(LocalDate testDate) {
                SeleniumTest.selectByVisibleTextFromDropDown(employeeStartYearPaperS2, Integer.toString(testDate.getYear()));
                staticLogger.info("Employee Start Year set to {}", (testDate.getYear()));
            }

            public static void selectMonth1(String testDate) {
                SeleniumTest.selectShortMonthByVisibleText(employeeStartMonthPaperS2, testDate);
                staticLogger.info("Employee Start Month set to {}", testDate);
            }

            public static void selectDay1(String testDate) {
                SeleniumTest.selectByVisibleTextFromDropDown(employeeStartDayPaperS2, testDate);
                staticLogger.info("Employee Start Day set to {}", testDate);
            }

            public static void selectYear1(String testDate) {
                SeleniumTest.selectByVisibleTextFromDropDown(employeeStartYearPaperS2, testDate);
                staticLogger.info("Employee Start Year set to {}", testDate);
            }

            public static void selectDate(LocalDate testDate) {
                employeeStartMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qstartmonth']"));
                SeleniumTest.selectShortMonthByVisibleText(employeeStartMonthPaperS2, testDate);
                employeeStartDayPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qstartday']"));
                SeleniumTest.selectByVisibleTextFromDropDown(employeeStartDayPaperS2, Integer.toString(testDate.getDayOfMonth()));
                employeeStartYearPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qstartyear']"));
                SeleniumTest.selectByVisibleTextFromDropDown(employeeStartYearPaperS2, Integer.toString(testDate.getYear()));
            }

        }

        public static class EmployerReview {

            static {
                PageFactory.initElements(Driver.getDriver(), EmployerReview.class);
            }

            @FindBy(how = How.ID, using = "qSection2DocumentType1")
            private static WebElement listARadioButtonPaperWorkflowS2;

            @FindBy(how = How.ID, using = "qSection2DocumentType2")
            private static WebElement listBRadioButtonPaperWorkflowS2;

            @FindBy(how = How.ID, using = "missingDocumentType_Err")
            private static WebElement missingDocumentTypeError;


            public static void chooseListA() {
                listARadioButtonPaperWorkflowS2.click();
            }

            public static void chooseListBAndC() {
                listBRadioButtonPaperWorkflowS2.click();
            }

            public static String getMissingDocumentTypeError() {
                return missingDocumentTypeError.getText();
            }

        }

        public static class Documents {
            static {
                PageFactory.initElements(Driver.getDriver(), Documents.class);
            }

            public enum ThirdDocumentValue {
                NA(""),
                DS2019("50"),
                I20("51");

                private final String value;

                ThirdDocumentValue(final String value) {
                    this.value = value;
                }
            }

            /**
             * Enum of List A Documents
             */
            public enum ListADocuments {
                // String, receiptId, issuingAuthId, docId, associatedDocumentValue dropdown,  second issuingAuthId, second docId, third issuingAuthId, third docId
                USPASSPORT("U.S. Passport", "qListAReceipt", "qListAIssuingAuthorityText", "qListADocumentNumber1", "1", "", "", "", ""),
                USPASSPORTCARD("U.S. Passport Card", "qListAReceipt", "qListAIssuingAuthorityText", "qListADocumentNumber1", "2", "", "", "", ""),
                PERMANENTRESIDENTCARD("Perm. Resident Card (Form I-551)", "qListAReceipt", "qListAIssuingAuthorityText", "qListADocumentNumber1", "3", "", "", "", ""),
                ALIENREGISTRATIONRECEIPTCARD("Alien Registration Receipt Card (Form I-551)", "qListAReceipt", "qListAIssuingAuthorityText", "qListADocumentNumber1", "4", "", "", "", ""),
                FOREIGNPASSPORTWITHI_551STAMP("Foreign Passport containing a temp. I-551 stamp", "qListAReceipt", "qListAIssuingAuthorityText", "qListADocumentNumber1", "5", "", "", "", ""),
                FOREIGNPASSPORTWITHI_551MRIV("Foreign Passport containing a temp. I-551 MRIV", "qListAReceipt", "qListAIssuingAuthorityText", "qListADocumentNumber1", "17", "", "", "", ""),
                EMPLOYMENTAUTHORIZATIONDOCUMENT("Employment Authorization Document (Form I-766)", "qListAReceipt", "qListAIssuingAuthorityText", "qListADocumentNumber1", "6", "", "", "", ""),
                FOREIGNPASSPORTWITHI_94_AFORM("Foreign Passport with Form I-94/I-94A containing an endorsement of the alien's nonimmigrant status", "qListAReceipt", "qListAIssuingAuthorityCountrySelect", "qListADocumentNumber1", "7", "qListAIssuingAuthority2Text", "qListADocumentNumber2", "", ""),
                I_94_AFORMWITHREFUGEESTAMP("Receipt: Departure portion of a Form I-94/A with an unexpired refugee admission stamp or admission class of \"RE\"", "qListAReceipt", "qListAIssuingAuthorityCountrySelect", "qListADocumentNumber1", "16", "qListAIssuingAuthority2Text", "qListADocumentNumber2", "qVisitorStudentIssuingAuthority", "qVisitorStudentDocumentNumber"),
                I_94_AFORMWITHI_551STAMP("Receipt: The arrival portion of Form I-94/I-94A containing a temp. I-551 stamp and photo", "qListAReceipt", "qListAIssuingAuthorityCountrySelect", "qListADocumentNumber1", "18", "", "", "", ""),
                FSMPASSPORTWITHI_94_AFORM("Passport from the Federated States of Micronesia (FSM) with Form I-94/I-94A", "qListAReceipt", "qListAIssuingAuthorityCountrySelect", "qListADocumentNumber1", "8", "", "", "", ""),
                RMIPASSPORTWITHI_94_AFORM("Passport from the Republic of the Marshall Islands (RMI) with Form I-94/I-94A", "qListAReceipt", "qListAIssuingAuthorityCountrySelect", "qListADocumentNumber1", "9", "", "", "", "");

                private final String text;
                private final String receiptId;
                private final String issuingAuthorityId;
                private final String documentNumberId;
                private final String associatedDocumentValue;
                private final String secondDocIssuingAuthorityId;
                private final String secondDocNumberId;
                private final String thirdDocIssuingAuthorityId;
                private final String thirdDocNumberId;

                ListADocuments(final String text, final String receiptId,
                               final String issuingAuthorityId, final String documentNumberId, final String associatedDocumentValue,
                               final String secondDocIssuingAuthorityId, final String secondDocNumberId, final String thirdDocIssuingAuthorityId, final String thirdDocNumberId) {
                    this.text = text;
                    this.receiptId = receiptId;
                    this.issuingAuthorityId = issuingAuthorityId;
                    this.documentNumberId = documentNumberId;
                    this.associatedDocumentValue = associatedDocumentValue;
                    this.secondDocIssuingAuthorityId = secondDocIssuingAuthorityId;
                    this.secondDocNumberId = secondDocNumberId;
                    this.thirdDocIssuingAuthorityId = thirdDocIssuingAuthorityId;
                    this.thirdDocNumberId = thirdDocNumberId;

                }

                @Override
                public String toString() {
                    return text;
                }

            }

            /**
             * enum of List B Documents
             */
            public enum ListBDocuments {
                // String, associatedDocumentValue dropdown, receiptId, issuingAuth, docId
                USSTATEDRIVERSLICENSE("Driver's license issued by a State or outlying possession of the United States", "1", "qListBReceipt", "qListBIssuingAuthority_USDriverLicense", "qListBDocumentNumber"),
                USSTATEID("ID card issued by a State or outlying possession of the United States", "24", "qListBReceipt", "qListBIssuingAuthority_USDriverLicense", "qListBDocumentNumber"),
                GOVERNMENTID("Government Issued ID with Photo", "2", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                SCHOOLID("School ID card with a photograph", "3", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                VOTERREGISTRATIONCARD("Voter's registration card", "4", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                USMILITARYCARD("U.S. Military ID", "5", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                USMILITARYDRAFT("U.S. Military draft record", "23", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                MILITARYDEPENDENTIDCARD("Military dependent's ID card", "6", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                USCOASTGUARDMERCHANTMARINERCARD("U.S. Coast Guard Merchant Mariner Card", "7", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                NATIVEAMERICANTRIBALDOCUMENT("Native American tribal document", "8", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                CAGOVERNMENTDRIVERSLICENSE("Driver's license issued by a Canadian government authority", "9", "qListBReceipt", "qListBIssuingAuthority_CanadaDriverLicense", "qListBDocumentNumber"),
                SCHOOLRECORD("School record or report card (if under 18 and unable to present a document listed above)", "10", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                MEDICALRECORD("Clinic, doctor, or hospital record (if under 18 and unable to present a document listed above)", "11", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber"),
                PRE_SCHOOLRECORD("Day-care or nursery school record (if under 18 and unable to present a document listed above)", "12", "qListBReceipt", "qListBIssuingAuthority", "qListBDocumentNumber");

                private final String text;
                private final String associatedDocumentValue;
                private final String receiptId;
                private final String issuingAuthorityId;
                private final String documentNumberId;


                ListBDocuments(final String text, final String associatedDocumentValue, final String receiptId, final String issuingAuthorityId,
                               final String documentNumberId) {

                    this.text = text;
                    this.associatedDocumentValue = associatedDocumentValue;
                    this.receiptId = receiptId;
                    this.issuingAuthorityId = issuingAuthorityId;
                    this.documentNumberId = documentNumberId;

                }

                @Override
                public String toString() {
                    return text;
                }

            }

            /**
             * enum of List C Documents
             */
            public enum ListCDocuments {
                // String, associatedDocumentValue dropdown, receiptId, issuingAuth, docId
                SOCIAL_SECURITY_CARD("Social Security Card without restrictions", "1", "qListCReceipt", "qListCIssuingAuthority", ""),
                BIRTHABROADCERTIFICATEFS_545("Certification of Birth Abroad issued by the Department of State (Form FS-545)", "2", "qListCReceipt", "qListCIssuingAuthority", "qListCDocumentNumber"),
                BIRTHABROADCERTIFICATEDS_1350("Certification of Report of Birth issued by the Department of State (Form DS-1350)", "3", "qListCReceipt", "qListCIssuingAuthority", "qListCDocumentNumber"),
                BIRTHCERTIFICATEWITHSEAL("Original or certified copy of birth certificate bearing an official seal", "4", "qListCReceipt", "qListCIssuingAuthority", "qListCDocumentNumber"),
                NATIVEAMERICANTRIBALDOCUMENT("Native American tribal document", "5", "qListCReceipt", "qListCIssuingAuthority", "qListCDocumentNumber"),
                USCITIZENIDCARD("U.S. Citizen ID Card (Form I-197)", "6", "qListCReceipt", "qListCIssuingAuthority", "qListCDocumentNumber"),
                RESIDENTCITIZENIDCARD("Identification Card for Use of Resident Citizen in the United States (Form I-179)", "7", "qListCReceipt", "qListCIssuingAuthority", "qListCDocumentNumber"),
                DHSEMPLOYMENTAUTHORIZATIONDOCUMENT("Employment Auth. Doc. issued (DHS) List C #7", "8", "qListCReceipt", "qListCIssuingAuthority", "qListCDocumentNumber");

                private final String text;
                private final String associatedDocumentValue;
                private final String receiptId;
                private final String issuingAuthorityName;
                private final String documentNumberName;

                ListCDocuments(final String text, final String associatedDocumentValue, final String receiptId,
                               final String issuingAuthorityName, final String documentNumberName) {

                    this.text = text;
                    this.associatedDocumentValue = associatedDocumentValue;
                    this.receiptId = receiptId;
                    this.issuingAuthorityName = issuingAuthorityName;
                    this.documentNumberName = documentNumberName;
                }

                @Override
                public String toString() {
                    return text;
                }


            }


            public static class ListA {

                static {
                    PageFactory.initElements(Driver.getDriver(), ListA.class);
                }

                // List A Doc
                @FindBy(how = How.CSS, using = "select[id='qListADocumentType']")
                private static WebElement listADocumentDropDownPaperS2;

                @FindBy(how = How.ID, using = "qListAReceipt")
                private static WebElement listADocumentReceiptCheckBoxPaperS2;

                // Associated Doc
                @FindBy(how = How.ID, using = "qListAIssuingAuthorityCountrySelect")
                private static WebElement listAIssuingAuthDropDownPaperS2;

                @FindBy(how = How.ID, using = "qListAIssuingAuthorityText")
                private static WebElement listAIssuingAuthTextBoxPaperS2;

                @FindBy(how = How.NAME, using = "qListADocumentNumber1")
                private static WebElement listADocNum1PaperS2;

                @FindBy(how = How.NAME, using = "qListAExpDateMonth1")
                private static WebElement listADocNum1ExpDateMonth1PaperS2;

                @FindBy(how = How.NAME, using = "qListAExpDateDay1")
                private static WebElement listADocNum1ExpDateDay1PaperS2;

                @FindBy(how = How.NAME, using = "qListAExpDateYear1")
                private static WebElement listADocNum1ExpDateYear1PaperS2;

                //Second Document
                @FindBy(how = How.ID, using = "qListAIssuingAuthority2Text")
                private static WebElement listASecondDocumentIssuingAuthorityTextBoxPaperS2;

                @FindBy(how = How.NAME, using = "qListADocumentNumber2")
                private static WebElement listASecondDocumentDocumentNumberTextBoxPaperS2;

                // Use the DateHelper methods to get and set the date

                //Third Document
                @FindBy(how = How.ID, using = "qDocumentTypeVisitorStudent")
                private static WebElement listAThirdDocumentDropdownPaperS2;

                @FindBy(how = How.NAME, using = "qVisitorStudentIssuingAuthority")
                private static WebElement listAThirdDocumentIssuingAuthorityTextBoxPaperS2;

                @FindBy(how = How.NAME, using = "qVisitorStudentDocumentNumber")
                private static WebElement listAThirdDocumentDocumentNumberTextBoxPaperS2;

                @FindBy(how = How.NAME, using = "qVisitorStudentExpDateMonth")
                private static WebElement listAThirdDocumentExpDateMonthPaperS2;

                @FindBy(how = How.NAME, using = "qVisitorStudentExpDateDay")
                private static WebElement listAThirdDocumentExpDateDayPaperS2;

                @FindBy(how = How.NAME, using = "qVisitorStudentExpDateYear")
                private static WebElement listAThirdDocumentExpDateYearPaperS2;

                // endregion

                @FindBy(how = How.ID, using = "qListADocumentType_Err")
                private static WebElement listADocumentDropDownErr;

                public static String getListADocumentError() {
                    return listADocumentDropDownErr.getText();
                }

                @FindBy(how = How.ID, using = "qListAIssuingAuthorityCountrySelect_Err")
                private static WebElement qListAIssuingAuthErr;

                public static String getIssuingAuthorityError() {
                    return qListAIssuingAuthErr.getText();
                }

                @FindBy(how = How.ID, using = "qListADocumentNumber1_Err")
                private static WebElement qListADocumentNumberErr;

                public static String getDocumentNumberError() {
                    return qListADocumentNumberErr.getText();
                }

                @FindBy(how = How.ID, using = "qListAExpDateYear1_Err")
                private static WebElement qListAExpDateErr;

                public static String getExpirationDateError() {
                    return qListAExpDateErr.getText();
                }

                // List A Exp Date Month
                private static WebElement listAExpDateMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListAExpDateMonth1']"));

                // List A Exp Date Day
                @FindBy(how = How.CSS, using = "select[name='qListAExpDateDay1']")
                private static WebElement listAExpDateDayPaperS2;

                // List A Exp Date Year
                @FindBy(how = How.CSS, using = "select[name='qListAExpDateYear1']")
                private static WebElement listAExpDateYearPaperS2;

                public static void selectMonth(LocalDate testDate) {
                    listAExpDateMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListAExpDateMonth1']"));
                    SeleniumTest.selectShortMonthByVisibleText(listAExpDateMonthPaperS2, testDate);
                    staticLogger.info("List A Exp Date Month set to {}", testDate.getMonth());
                }

                public static void selectDay(LocalDate testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(listAExpDateDayPaperS2, Integer.toString(testDate.getDayOfMonth()));
                    staticLogger.info("List A Exp Date Day set to {}", Integer.toString(testDate.getDayOfMonth()));
                }

                public static void selectYear(LocalDate testDate) {
                    Integer.toString(testDate.getDayOfMonth());
                    staticLogger.info("List A Exp Date Year set to {}", testDate.getYear());
                }

                public static void selectYear(String testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(listAExpDateYearPaperS2, (testDate));
                    staticLogger.info("List A Exp Date Year set to {}", (testDate));
                }

                // region List A Receipt
                public static void selectListADocument(ListADocuments document) {
                    SeleniumTest.selectByValueFromDropDown(listADocumentDropDownPaperS2, document.associatedDocumentValue);
                    staticLogger.info("List A Document Selected {}", document);
                    SeleniumTest.waitForPageLoadToComplete();
                }


                // region Associated Doc
                public static void checkListAReceipt(ListADocuments document) {
                    WebElement receiptCheckBox = Driver.getDriver()
                            .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                    SeleniumTest.check(receiptCheckBox, receiptCheckBox);
                    staticLogger.info("List A Receipt checked");
                }

                public static void uncheckListAReceipt(ListADocuments document) {
                    WebElement receiptCheckBox = Driver.getDriver()
                            .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                    SeleniumTest.unCheck(receiptCheckBox, receiptCheckBox);
                    staticLogger.info("List A Receipt unchecked");
                }
                // endregion


                // region Issuing Authority
                public static WebElement getIssuingAuthorityElement(ListADocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("select[id$='" + document.issuingAuthorityId + "']"));
                }

                public static String getIssuingAuthority(ListADocuments document) {
                    try {

                        WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                        switch (issuingAuthorityElement.getTagName().toLowerCase()) {
                            case "input":
                                return issuingAuthorityElement.getText();
                            case "select":
                                Select dropDown = new Select(issuingAuthorityElement);
                                return dropDown.getFirstSelectedOption().getText();
                            default:
                                return "";
                        }
                    } catch (NoSuchElementException nse) {
                        return "";
                    }
                }

                public static void setOrSelectIssuingAuthority(ListADocuments document,
                                                               String value) {
                    try {
                        WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                        switch (issuingAuthorityElement.getTagName().toLowerCase()) {
                            case "input":
                                SeleniumTest.clearAndSetText(issuingAuthorityElement, value);
                                break;
                            case "select":
                                SeleniumTest.selectByVisibleTextFromDropDown(issuingAuthorityElement, value);
                                break;
                            default:
                                throw new RuntimeException("Unable to determine the type of element -"
                                        + " could not set Issuing Authority");
                        }
                        staticLogger.info("Issuing Authority set to {}", value);

                    } catch (NoSuchElementException nse) {
                        throw new RuntimeException("Unable to determine the type of element - could "
                                + "not set Issuing Authority");
                    }
                }

                public static void setListAIssuingAuthority(String val) {
                    WaitUntil.waitUntil(() -> listAIssuingAuthTextBoxPaperS2.isDisplayed());
                    SeleniumTest.clearAndSetText(listAIssuingAuthTextBoxPaperS2, val);
                    staticLogger.info("Issuing Authority set to {}", val);
                }

                // endregion

                public static void setOrSelectByIndexIssuingAuthority(ListADocuments document,
                                                                      int index) {
                    WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                    SeleniumTest.selectByDropDownIndexFromDropDown(issuingAuthorityElement, index);

                }

                public static void selectDate(LocalDate testDate) {
                    listAExpDateMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListAExpDateMonth1']"));
                    SeleniumTest.selectShortMonthByVisibleText(listAExpDateMonthPaperS2, testDate);
                    SeleniumTest.selectByVisibleTextFromDropDown(listAExpDateDayPaperS2, Integer.toString(testDate.getDayOfMonth()));
                    SeleniumTest.selectByVisibleTextFromDropDown(listAExpDateYearPaperS2, Integer.toString(testDate.getYear()));
                }

                // List A Exp Date Month
                private static WebElement listAExpDateMonthDoc1PaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListAExpDateMonth2']"));

                // List A Exp Date Day
                @FindBy(how = How.CSS, using = "select[name='qListAExpDateDay2']")
                private static WebElement listAExpDateDayDoc1PaperS2;

                // List A Exp Date Year
                @FindBy(how = How.CSS, using = "select[name='qListAExpDateYear2']")
                private static WebElement listAExpDateYearDoc1PaperS2;


                public static void selectDateDoc1(LocalDate testDate) {
                    listAExpDateMonthDoc1PaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListAExpDateMonth2']"));
                    SeleniumTest.selectShortMonthByVisibleText(listAExpDateMonthDoc1PaperS2, testDate);
                    SeleniumTest.selectByVisibleTextFromDropDown(listAExpDateDayDoc1PaperS2, Integer.toString(testDate.getDayOfMonth()));
                    SeleniumTest.selectByVisibleTextFromDropDown(listAExpDateYearDoc1PaperS2, Integer.toString(testDate.getYear()));
                }

                // region Document Number
                public static String getDocumentNumber(ListADocuments document) {
                    return getDocumentNumberElement(document).getText();
                }

                public static WebElement getDocumentNumberElement(ListADocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("input[name$='" + document.documentNumberId + "']"));
                }

                public static void setDocumentNumber(ListADocuments document, String documentNumber) {
                    SeleniumTest.clearAndSetText(getDocumentNumberElement(document), documentNumber);
                    staticLogger.info("Document Number set to {}", documentNumber);
                }
                // endregion

                // region Second Document

                public static String getSecondDocumentIssuingAuthority(ListADocuments document) {
                    WebElement secondIssuingAuthorityElement = getSecondIssuingAuthorityElement(document);
                    return secondIssuingAuthorityElement.getText();
                }

                public static WebElement getSecondIssuingAuthorityElement(ListADocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("input[id$='" + document.secondDocIssuingAuthorityId + "']"));
                }

                public static void setSecondDocumentIssuingAuthority(ListADocuments document, String issuingAuthorityValue) {
                    WebElement secondIssuingAuthorityElement = getSecondIssuingAuthorityElement(document);
                    SeleniumTest.clearAndSetText(secondIssuingAuthorityElement, issuingAuthorityValue);
                    staticLogger.info("Second document Issuing Authority set to {}", issuingAuthorityValue);
                }

                public static String getSecondDocumentNumber(ListADocuments document) {
                    return getSecondDocumentNumberElement(document).getText();
                }

                public static WebElement getSecondDocumentNumberElement(ListADocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("input[name$='" + document.secondDocNumberId + "']"));
                }

                public static void setSecondDocumentNumber(ListADocuments document, String documentNumber) {
                    SeleniumTest.clearAndSetText(getSecondDocumentNumberElement(document), documentNumber);
                    staticLogger.info("Second Document Number set to {}", documentNumber);
                }
                // endregion

                // region Third Document

                public static String getThirdDocumentIssuingAuthority(ListADocuments document) {
                    WebElement thirdIssuingAuthorityElement = getThirdIssuingAuthorityElement(document);
                    return thirdIssuingAuthorityElement.getText();
                }

                public static WebElement getThirdIssuingAuthorityElement(ListADocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("input[name$='" + document.thirdDocIssuingAuthorityId + "']"));
                }

                public static void setThirdDocumentIssuingAuthority(ListADocuments document, String issuingAuthorityValue) {
                    WebElement thirdIssuingAuthorityElement = getThirdIssuingAuthorityElement(document);
                    SeleniumTest.clearAndSetText(thirdIssuingAuthorityElement, issuingAuthorityValue);
                    staticLogger.info("Third document Issuing Authority set to {}", issuingAuthorityValue);
                }

                public static String getThirdDocumentNumber(ListADocuments document) {
                    return getThirdDocumentNumberElement(document).getText();
                }

                public static WebElement getThirdDocumentNumberElement(ListADocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("input[name$='" + document.thirdDocNumberId + "']"));
                }

                public static void setThirdDocumentNumber(ListADocuments document, String documentNumber) {
                    SeleniumTest.clearAndSetText(getThirdDocumentNumberElement(document), documentNumber);
                    staticLogger.info("Third Document Number set to {}", documentNumber);
                }

                // endregion
            }


            public static class ListB {

                @FindBy(how = How.ID, using = "qListBDocumentType")
                private static WebElement listBDocumentDropDownPaperS2;

                @FindBy(how = How.ID, using = "qListBReceipt")
                private static WebElement listBDocumentReceiptCheckBoxPaperS2;

                @FindBy(how = How.ID, using = "qListBIssuingAuthority")
                private static WebElement listBIssuingAuthTextBoxPaperS2;

                @FindBy(how = How.ID, using = "qListBIssuingAuthority_USDriverLicense")
                private static WebElement listBIssuingAuthUSDLDropDownPaperS2;

                @FindBy(how = How.ID, using = "qListBIssuingAuthority_CanadaDriverLicense")
                private static WebElement listBIssuingAuthCanadaDLDropDownPaperS2;

                @FindBy(how = How.ID, using = "qListBDocumentNumber")
                private static WebElement listBDocNumPaperS2;

                // Use the DateHelper methods to get and set the date

                @FindBy(how = How.CSS, using = "[id$='qListBDocumentType_Err']")
                private static WebElement qListBDocumentTitleErr;

                public static String getListBDocumentError() {
                    return qListBDocumentTitleErr.getText();
                }

                @FindBy(how = How.CSS, using = "[id$='qListBDocumentNumber_Err']")
                private static WebElement qListBDocumentNumberErr;

                public static String getDocumentNumberError() {
                    return qListBDocumentNumberErr.getText();
                }

                @FindBy(how = How.CSS, using = "[id$='qListBIssuingAuthority_Err']")
                private static WebElement qListBIssuingAuthErr;

                public static String getIssuingAuthorityError() {
                    return qListBIssuingAuthErr.getText();
                }

                @FindBy(how = How.ID, using = "qListBExpDateMonth_Err")
                private static WebElement qListBExpDateErr;

                public static String getExpirationDateError() {
                    return qListBExpDateErr.getText();
                }

                // List B Exp Date Month
                private static WebElement listBExpDateMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListBExpDateMonth']"));

                // List B Exp Date Day
                @FindBy(how = How.CSS, using = "select[name='qListBExpDateDay']")
                private static WebElement listBExpDateDayPaperS2;

                // List B Exp Date Year
                @FindBy(how = How.CSS, using = "select[name='qListBExpDateYear']")
                private static WebElement listBExpDateYearPaperS2;

                public static void selectMonth(LocalDate testDate) {
                    listBExpDateMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListBExpDateMonth']"));
                    SeleniumTest.selectShortMonthByVisibleText(listBExpDateMonthPaperS2, testDate);
                    staticLogger.info("List B Exp Date Month set to {}", testDate.getMonth());
                }

                public static void selectDay(LocalDate testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(listBExpDateDayPaperS2, Integer.toString(testDate.getDayOfMonth()));
                    staticLogger.info("List B Exp Date Day set to {}", Integer.toString(testDate.getDayOfMonth()));
                }

                public static void selectYear(LocalDate testDate) {
                    SeleniumTest.selectByVisibleTextFromDropDown(listBExpDateYearPaperS2, Integer.toString(testDate.getYear()));
                    staticLogger.info("List B Exp Date Year set to {}", Integer.toString(testDate.getYear()));
                }

                public static void selectDate(LocalDate testDate) {
                    listBExpDateMonthPaperS2 = Driver.getDriver().findElement(By.cssSelector("select[name='qListBExpDateMonth']"));
                    SeleniumTest.selectShortMonthByVisibleText(listBExpDateMonthPaperS2, testDate);
                    SeleniumTest.selectByVisibleTextFromDropDown(listBExpDateDayPaperS2, Integer.toString(testDate.getDayOfMonth()));
                    SeleniumTest.selectByVisibleTextFromDropDown(listBExpDateYearPaperS2, Integer.toString(testDate.getYear()));
                }

                static {
                    PageFactory.initElements(Driver.getDriver(), ListB.class);
                }

                public static void selectListBDocument(ListBDocuments document) {
                    SeleniumTest.selectByValueFromDropDown(listBDocumentDropDownPaperS2, document.associatedDocumentValue);
                    staticLogger.info("List B Document selected {}", document);
                }

                // region List B Receipt
                public static void checkListBReceipt(ListBDocuments document) {
                    WebElement receiptCheckBox = Driver.getDriver()
                            .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                    WebElement receiptCheckBoxLabel = Driver.getDriver()
                            .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                    SeleniumTest.check(receiptCheckBoxLabel, receiptCheckBox);
                    staticLogger.info("List B Receipt checked");
                }

                public static void uncheckListBReceipt(ListBDocuments document) {
                    WebElement receiptCheckBox = Driver.getDriver()
                            .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                    WebElement receiptCheckBoxLabel = Driver.getDriver()
                            .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                    SeleniumTest.unCheck(receiptCheckBoxLabel, receiptCheckBox);
                    staticLogger.info("List B Receipt unchecked");
                }
                // endregion

                public static WebElement getIssuingAuthorityElement(ListBDocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("select[id$='" + document.issuingAuthorityId + "']"));
                }

                public static String getIssuingAuthority(ListBDocuments document) {
                    try {
                        WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                        staticLogger.info("TagName for Issuing Auth", issuingAuthorityElement.getTagName().toLowerCase());
                        switch (issuingAuthorityElement.getTagName().toLowerCase()) {
                            case "input":
                                return issuingAuthorityElement.getText();
                            case "select":
                                Select dropDown = new Select(issuingAuthorityElement);
                                return dropDown.getFirstSelectedOption().getText();
                            default:
                                return "";
                        }
                    } catch (NoSuchElementException nse) {
                        return "";
                    }
                }

                public static void setOrSelectIssuingAuthority(ListBDocuments document,
                                                               String value) {
                    try {
                        WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                        switch (issuingAuthorityElement.getTagName().toLowerCase()) {
                            case "input":
                                SeleniumTest.clearAndSetText(issuingAuthorityElement, value);
                                break;
                            case "select":
                                SeleniumTest.selectByVisibleTextFromDropDown(issuingAuthorityElement, value);
                                break;
                            default:
                                throw new RuntimeException("Unable to determine the type of element -"
                                        + " could not set Issuing Authority");
                        }
                        staticLogger.info("Issuing Authority set to {}", value);

                    } catch (NoSuchElementException nse) {
                        throw new RuntimeException("Unable to determine the type of element - could "
                                + "not set Issuing Authority");
                    }
                }


                public static void setOrSelectByIndexIssuingAuthority(ListBDocuments document,
                                                                      int index) {
                    WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                    SeleniumTest.waitForPageLoadToComplete();
                    SeleniumTest.selectByDropDownIndexFromDropDown(issuingAuthorityElement, index);

                }

                // endregion

                public static String getDocumentNumber(ListBDocuments document) {
                    return getDocumentNumberElement(document).getText();
                }

                // region Document Number
                public static WebElement getDocumentNumberElement(ListBDocuments document) {
                    return Driver.getDriver().findElement(
                            By.cssSelector("input[name$='" + document.documentNumberId + "']"));
                }

                public static void setDocumentNumber(ListBDocuments document, String documentNumber) {
                    SeleniumTest.clearAndSetText(getDocumentNumberElement(document), documentNumber);
                    staticLogger.info("Document number set to {}", documentNumber);
                }
                // endregion

                // region document Associated Value

                public static String getAssociatedDocument(ListBDocuments document) {
                    try {

                        WebElement associatedDocument = getAssociatedDocumentElement(document);
                        switch (associatedDocument.getTagName().toLowerCase()) {
                            case "input":
                                return associatedDocument.getText();
                            case "select":
                                Select dropDown = new Select(associatedDocument);
                                return dropDown.getFirstSelectedOption().getText();
                            default:
                                return "";
                        }
                    } catch (NoSuchElementException nse) {
                        return "";
                    }
                }

                public static WebElement getAssociatedDocumentElement(ListBDocuments document) {
                    return Driver.getDriver().findElement(
                            By.xpath("//*[contains(@id, '" + document.associatedDocumentValue + "')]"));
                }

                public static void setOrSelectAssociatedDocument(ListBDocuments document,
                                                                 String value) {
                    try {
                        WebElement associatedDocument = getAssociatedDocumentElement(document);
                        switch (associatedDocument.getTagName().toLowerCase()) {
                            case "input":
                                SeleniumTest.clearAndSetText(associatedDocument, value);
                                break;
                            case "select":
                                SeleniumTest.selectByVisibleTextFromDropDown(associatedDocument, value);
                                break;
                            default:
                                throw new RuntimeException("Unable to determine the type of element -"
                                        + " could not set document value");
                        }
                        staticLogger.info("Set Associated Document to {}", value);

                    } catch (NoSuchElementException nse) {
                        throw new RuntimeException("Unable to determine the type of element - could "
                                + "not set document value");
                    }
                }
                // endregion

            }


            public static class ListC {

                @FindBy(how = How.ID, using = "qListCDocumentType")
                private static WebElement listCDocumentDropDownPaperS2;

                @FindBy(how = How.ID, using = "qListCReceipt")
                private static WebElement listCDocumentReceiptCheckBoxPaperS2;

                @FindBy(how = How.NAME, using = "qListCIssuingAuthority")
                private static WebElement listCIssuingAuthTextBoxPaperS2;

                @FindBy(how = How.NAME, using = "qListCDocumentNumber")
                private static WebElement listCDocNumPaperS2;

                @FindBy(how = How.NAME, using = "qListCExpDateMonth")
                private static WebElement listCExpDateMonthPaperS2;

                @FindBy(how = How.NAME, using = "qListCExpDateDay")
                private static WebElement listCExpDateDayPaperS2;

                @FindBy(how = How.NAME, using = "qListCExpDateYear")
                private static WebElement listCExpDateYearPaperS2;

                @FindBy(how = How.CSS, using = "[id$='qListCDocumentType_Err']")
                private static WebElement qListCDocumentTitleErr;

                @FindBy(how = How.XPATH, using = "//input[@name='qListCIssuingAuthority']")
                private static WebElement txtListCDocumentNumber;

                public static String getListCDocumentError() {
                    return qListCDocumentTitleErr.getText();
                }

                @FindBy(how = How.CSS, using = "[id$='qListCDocumentNumber_Err']")
                private static WebElement qListCDocumentNumberErr;

                public static String getDocumentNumberError() {
                    return qListCDocumentNumberErr.getText();
                }

                static {
                    PageFactory.initElements(Driver.getDriver(), ListC.class);
                }

                public static void selectListCDocument(ListCDocuments document) {
                    SeleniumTest.selectByValueFromDropDown(listCDocumentDropDownPaperS2, document.associatedDocumentValue);
                    staticLogger.info("List C Document selected {}", document);
                }

                // region List C Receipt
                public static void checkListCReceipt(ListCDocuments document) {
                    WebElement receiptCheckBox = Driver.getDriver()
                            .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                    WebElement receiptCheckBoxLabel = Driver.getDriver()
                            .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                    SeleniumTest.check(receiptCheckBoxLabel, receiptCheckBox);
                    staticLogger.info("List C Receipt checked");
                }

                public static void setListCDocumentNumber(String number) {
                    listCDocNumPaperS2.sendKeys(number);
                }

                public static void uncheckListCReceipt(ListCDocuments document) {
                    WebElement receiptCheckBox = Driver.getDriver()
                            .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                    WebElement receiptCheckBoxLabel = Driver.getDriver()
                            .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                    SeleniumTest.unCheck(receiptCheckBoxLabel, receiptCheckBox);
                    staticLogger.info("List C Receipt unchecked");
                }
                // endregion

                public static String getIssuingAuthority(ListCDocuments document) {
                    return getIssuingAuthorityElement(document).getText();
                }

                // region Issuing Authority
                public static WebElement getIssuingAuthorityElement(ListCDocuments document) {
                    // must find the right element type input or select before returning.
                    List<WebElement> elements = Driver.getDriver().findElements(
                            By.cssSelector("*[name$='" + document.issuingAuthorityName + "']"));
                    for (WebElement element : elements) {
                        if (element.getTagName().equals("input") || element.getTagName().equals
                                ("select")) {
                            return element;
                        }
                    }
                    return null;
                }

                public static void setIssuingAuthority(ListCDocuments document,
                                                       String issuingAuthority) {
                    WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                    switch (issuingAuthorityElement.getTagName()) {
                        case "input":
                            SeleniumTest
                                    .clearAndSetText(issuingAuthorityElement, issuingAuthority);
                            break;
                        case "select":
                            SeleniumTest
                                    .selectByVisibleTextFromDropDown(
                                            issuingAuthorityElement, issuingAuthority);
                            break;
                    }
                    staticLogger.info("Issuing Authority set to {}", issuingAuthority);
                }
                // endregion

                public static String getDocumentNumber(ListCDocuments document) {
                    return getDocumentNumberElement(document).getText();
                }

                // region Document Number
                public static WebElement getDocumentNumberElement(ListCDocuments document) {
                    List<WebElement> elements = Driver.getDriver().findElements(
                            By.cssSelector("*[name$='" + document.documentNumberName + "']"));
                    for (WebElement element : elements) {
                        if (element.getTagName().equals("input") ||
                                element.getTagName().equals("span")) {
                            return element;
                        }
                    }
                    return null;
                }

                public static void setDocumentNumber(String docNum) {
                    SeleniumTest.clearAndSetText(txtListCDocumentNumber, docNum);
                }

                public static void setDocumentNumber(ListCDocuments document, String documentNumber) {
                    WebElement documentElement = getDocumentNumberElement(document);
                    switch (documentElement.getTagName()) {
                        case "input":
                            SeleniumTest.clearAndSetText(documentElement, documentNumber);
                            staticLogger.info("Document Number set to {}", documentNumber);
                            break;

                        case "span":
                            staticLogger.info("Document Number is read only");
                            break;
                    }
                }
                // endregion
            }

        }

        public static class AdditionalInfo {

            static {
                PageFactory.initElements(Driver.getDriver(), AdditionalInfo.class);
            }

            @FindBy(how = How.ID, using = "qAdditionalInformation")
            private static WebElement additionalInformationPaperS2;

            /**
             * Gets the Additional Info from the form
             *
             * @return
             */
            public static String getAdditionalInfo() {
                return additionalInformationPaperS2.getText();
            }

            public static void setAdditionalInfo(String additionalInfo) {
                SeleniumTest.clearAndSetText(additionalInformationPaperS2, additionalInfo);
                staticLogger.info("Additional Info set to {}", additionalInfo);
            }

        }

        public static class Acknowledgement {

            static {
                PageFactory.initElements(Driver.getDriver(), Acknowledgement.class);
            }

            @FindBy(how = How.ID, using = "qcertify")
            private static WebElement certificationPaperS2;

            @FindBy(how = How.CSS, using = "[id$='qcertify_Err']")
            public static WebElement iCertifyCheckBoxErr;

            @FindBy(how = How.CSS, using = "[id$='fI9_Err']")
            public static WebElement attachmentErr;

            public static void checkIAcknowledgePaperWorkflow() {
                SeleniumTest.check(certificationPaperS2, certificationPaperS2);
                staticLogger.info("I Acknowledge checked");
            }

            public static void uncheckIAcknowledgePaperWorkflow() {
                SeleniumTest.unCheck(certificationPaperS2, certificationPaperS2);
                staticLogger.info("I Acknowledge unchecked");
            }

            public static String getICertifyCheckBoxError() {
                return iCertifyCheckBoxErr.getText();
            }

            public static String getAttachmentError() {
                return attachmentErr.getText();
            }

        }

        public static class UploadDocuments {

            static {
                PageFactory.initElements(Driver.getDriver(), UploadDocuments.class);
            }

            @FindBy(how = How.NAME, using = "fI9")
            private static WebElement chooseFileButtonPaperWorkflowS2;

            public static void setFileToUpload(String filePath) {
                if (OS.isFamilyWindows()) {
                    filePath = filePath.replace('/', '\\');
                }
                ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementsByName('" + chooseFileButtonPaperWorkflowS2.getAttribute("name") + "')[0].style.visibility = 'visible';");
                chooseFileButtonPaperWorkflowS2.sendKeys(filePath);
                SeleniumTest.waitForElementToBeClickable(chooseFileButtonPaperWorkflowS2, SeleniumTest.waitForElementTimeout);
                staticLogger.info("File Upload Path set to {}", filePath);
            }

        }

        public static class OrderTracking {

            static {
                PageFactory.initElements(Driver.getDriver(), OrderTracking.class);
            }

            @FindBy(how = How.ID, using = "refcode")
            private static WebElement refCodePaperS2;

            /**
             * Gets the Additional Info from the form
             *
             * @return
             */
            public static String getRefCode() {
                Select dropDown = new Select(refCodePaperS2);
                return dropDown.getFirstSelectedOption().getText();
            }

            public static void selectRefCode(String refCodeSelectionItem) {
                SeleniumTest.selectByValueFromDropDown(refCodePaperS2, refCodeSelectionItem);
                staticLogger.info("RefCode selected {}", refCodeSelectionItem);
            }
        }

        public static class OverdueReason {

            static {
                PageFactory.initElements(Driver.getDriver(), OverdueReason.class);
            }

            @FindBy(how = How.ID, using = "qOverdueReason")
            private static WebElement overDueReason;

            public static void selectOverdueReason(String reason) {
                SeleniumTest.selectByVisibleTextFromDropDown(overDueReason, reason);
                staticLogger.info("Select reason for Overdue{}", reason);
            }
        }


    }

}
