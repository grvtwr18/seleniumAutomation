package Sites.CandidatePortal.Forms.FormsHelpers;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.FormID6013EmergencyContactPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.candidate.CandidateEmergencyContacts;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by btorbert on 9/9/16.
 */
public class FormID6013EmergencyContactPageHelper extends FormID6013EmergencyContactPage {

    /**
     * Checks the "I Confirm" Check Box
     */
    public void clickTheIConfirmCheckBox() { FormID6013EmergencyContactPage.iConfirmCheckBox.click(); }

    /**
     * Fills in the first emergency contact information
     * @param fullName
     * @param address
     * @param city
     * @param state
     * @param country
     * @param zip
     * @param phone
     */
    public void setContactInfo1 (
            String fullName,
            String address,
            String city,
            String state,
            String country,
            String zip,
            String phone) {

        WaitUntil.waitUntil(() -> FormID6013EmergencyContactPage.eContact1_FullNameTextbox.isDisplayed());
        FormID6013EmergencyContactPage.enterEmergencyContact1_FullNameText(fullName);
        FormID6013EmergencyContactPage.enterEmergencyContact1_Address(address);
        FormID6013EmergencyContactPage.enterEmergencyContact1_City(city);
        FormID6013EmergencyContactPage.selectEmergencyContact1_Country(country);
        FormID6013EmergencyContactPage.selectEmergencyContact1_State(state);
        FormID6013EmergencyContactPage.enterEmergencyContact1_Zip(zip);
        FormID6013EmergencyContactPage.enterEmergencyContact1_HomePhoneNumber(phone);
    }

    /**
     * Fills in the first emergency contact information
     * @param fullName
     * @param address
     * @param city
     * @param state
     * @param country
     * @param zip
     * @param phone
     */
    public void setContactInfo2 (
            String fullName,
            String address,
            String city,
            String state,
            String country,
            String zip,
            String phone) {

        WaitUntil.waitUntil(() -> FormID6013EmergencyContactPage.eContact2_FullNameTextbox.isDisplayed());
        FormID6013EmergencyContactPage.enterEmergencyContact2_FullNameText(fullName);
        FormID6013EmergencyContactPage.enterEmergencyContact2_Address(address);
        FormID6013EmergencyContactPage.enterEmergencyContact2_City(city);
        FormID6013EmergencyContactPage.selectEmergencyContact2_Country(country);
        FormID6013EmergencyContactPage.selectEmergencyContact2_State(state);
        FormID6013EmergencyContactPage.enterEmergencyContact2_Zip(zip);
        FormID6013EmergencyContactPage.enterEmergencyContact2_HomePhoneNumber(phone);
    }

    /**
     * Click on Next button
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        FormID6013EmergencyContactPage.nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public CandidatePortalPages fillForm6013(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.waitMs(5000);
        CandidateEmergencyContacts.createEmergencyContacts();
        setContactInfo1(
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact1Name(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact1Address(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact1City(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact1State(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact1Country(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact1Zip(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact1Phone());

        FormID6013EmergencyContactPage.setAddAnotherPersonToEmergencyContacts_YesRadio();
        setContactInfo2(
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact2Name(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact2Address(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact2City(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact2State(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact2Country(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact2Zip(),
                CandidateEmergencyContacts.getCurrentEmergencyContacts().getContact2Phone());

        clickTheIConfirmCheckBox();
        return clickNext(returnedClass);
    }
}
