package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by wogden on 6/1/2016.
 */
public class FormID14718ConcatenatedClientFormFacebook extends RichFormsBase {

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_2']")
    private static WebElement signHereAdultMaterialCheckBox;

    //<editor-fold desc="ContingentWorker">
    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_6']")
    private static WebElement initialHereContingentWorkerCheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_7']")
    private static WebElement initialHereContingentWorkerPage2CheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_8']")
    private static WebElement initialHereContingentWorkerPage3CheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_9']")
    private static WebElement initialHereContingentWorkerPage4CheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_10']")
    private static WebElement initialHereContingentWorkerPage5CheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_11']")
    private static WebElement initialHereContingentWorkerPage6CheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_12']")
    private static WebElement initialHereContingentWorkerPage7CheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_14']")
    private static WebElement signHereContingentWorkerCheckBox;
    //</editor-fold>

    @FindBy(how = How.ID, using = "14718-14718_22")
    private static WebElement listOfPriorObligationsTextBox;

    //<editor-fold desc="Prior Inventions">
    // only added fields for one row
    @FindBy(how = How.ID, using = "14718-14718_23")
    private static WebElement titleInventionTextBox;

    @FindBy(how = How.ID, using = "14718-14718_26")
    private static WebElement dateInventionTextBox;

    @FindBy(how = How.ID, using = "14718-14718_29")
    private static WebElement numberOrDescriptionInventionTextBox;
    //</editor-fold>

    //<editor-fold desc="Open Source Projects">
    @FindBy(how = How.ID, using = "14718-14718_32")
    private static WebElement nameOpenSourceProjectTextBox;

    @FindBy(how = How.ID, using = "14718-14718_33")
    private static WebElement websiteOpenSourceProjectTextBox;
    //</editor-fold>

    //<editor-fold desc="Organizations">
    @FindBy(how = How.ID, using = "14718-14718_34")
    private static WebElement nameStandardsOrganizationTextBox;

    @FindBy(how = How.ID, using = "14718-14718_35")
    private static WebElement websiteStandardsOrganizationTextBox;
    //</editor-fold>

    //<editor-fold desc="Facebook User Data Access">
    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_36']")
    private static WebElement initialHereFacebookUserDataAccessCheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_37']")
    private static WebElement initialHereFacebookUserDataAccessPage2CheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_38']")
    private static WebElement signHereFacebookUserDataAccessCheckBox;
    //</editor-fold>

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_41']")
    private static WebElement signHereCheckBoxWaiverCheckBox;

    //<editor-fold desc="Pro Unlimited">
    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_44']")
    private static WebElement initialHereProUnlimitedCheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_46']")
    private static WebElement signHereProUnlimitedCheckBox;
    //</editor-fold>

    //<editor-fold desc="PTO">
    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_48']")
    private static WebElement initialHerePTOCheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_49']")
    private static WebElement initialHerePTOPage2CheckBox;
    //</editor-fold>

    @FindBy(how = How.XPATH, using = "//label[@for='14718-14718_50']")
    private static WebElement initialHereCheckBoxNewChildCheckBox;

    private static final Logger logger = LoggerFactory.getLogger("Sites.CandidatePortal.Forms.FOrmID14718");

    private static ThreadLocal<FormID14718ConcatenatedClientFormFacebook> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                FormID14718ConcatenatedClientFormFacebook.class));
    }

    private static FormID14718ConcatenatedClientFormFacebook getInstance() {
        return threadLocalInstance.get();
    }

    //<editor-fold desc="checkboxes">
    public static void clickSignHereAdultMaterialCheckBox() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().signHereAdultMaterialCheckBox);
    }

    public static void clickInitialHereContingentWorkerCheckBox() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereContingentWorkerCheckBox);
    }

    public static void clickInitialHereContingentWorkerPage2CheckBox() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereContingentWorkerPage2CheckBox);
    }

    public static void clickInitialHereContingentWorkerPage3CheckBox() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereContingentWorkerPage3CheckBox);
    }

    public static void clickInitialHereContingentWorkerPage4CheckBox() {
        SeleniumTest.waitForElementToBeClickable(getInstance().initialHereContingentWorkerPage4CheckBox);
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereContingentWorkerPage4CheckBox);
    }

    public static void clickInitialHereContingentWorkerPage5CheckBox() {
        SeleniumTest.waitForElementToBeClickable(getInstance().initialHereContingentWorkerPage5CheckBox);
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereContingentWorkerPage5CheckBox);
    }

    public static void clickInitialHereContingentWorkerPage6CheckBox() {
        SeleniumTest.waitForElementToBeClickable(getInstance().initialHereContingentWorkerPage6CheckBox);
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereContingentWorkerPage6CheckBox);
    }

    public static void clickInitialHereContingentWorkerPage7CheckBox() {
        SeleniumTest.waitForElementToBeClickable(getInstance().initialHereContingentWorkerPage7CheckBox);
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereContingentWorkerPage7CheckBox);
    }

    public static void clickSignHereContingentWorkerCheckBox() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().signHereContingentWorkerCheckBox);
    }

    public static void clickInitialHereFacebookUserDataAccessCheckBox() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereFacebookUserDataAccessCheckBox);
    }

    public static void clickInitialHereFacebookUserDataAccessPage2CheckBox() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereFacebookUserDataAccessPage2CheckBox);
    }

    public static void clickSignHereFacebookUserDataAccess() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().signHereFacebookUserDataAccessCheckBox);
    }

    public static void clickSignHereCheckBoxWaiver() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().signHereCheckBoxWaiverCheckBox);
    }

    public static void clickInitialHereProUnlimited() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereProUnlimitedCheckBox);
    }

    public static void clickSignHereProUnlimited() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().signHereProUnlimitedCheckBox);
    }

    public static void clickInitialHerePTO() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHerePTOCheckBox);
    }

    public static void clickInitialHerePTOPage2() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHerePTOPage2CheckBox);
    }

    public static void clickInitialHereNewChild() {
        SeleniumTest.waitThenCheckBoxDontVerifyState(getInstance().initialHereCheckBoxNewChildCheckBox);
    }
    //</editor-fold>

    //<editor-fold desc="text boxes">
    public static String getListOfPriorObligationsTextBox() {
        return getInstance().listOfPriorObligationsTextBox.getText();
    }

    public static void setListOfPriorObligationsTextBox(String listOfPriorObligationsTextBoxText) {
        getInstance().logger.info("setListOfPriorObligationsTextBox");
        SeleniumTest.clearAndSetText(getInstance().listOfPriorObligationsTextBox,listOfPriorObligationsTextBoxText);
    }

    public static String getTitleInventionTextBox() {
        return getInstance().titleInventionTextBox.getText();
    }

    public static void setTitleInventionTextBox(String titleInventionTextBoxText) {
        getInstance().logger.info("setTitleInventionTextBox");
        SeleniumTest.clearAndSetText(getInstance().titleInventionTextBox,titleInventionTextBoxText);
    }

    public static String getDateInventionTextBox() {
        return getInstance().dateInventionTextBox.getText();
    }

    public static void setDateInventionTextBox(String dateInventionTextBoxText) {
        getInstance().logger.info("setDateInventionTextBox");
        SeleniumTest.clearAndSetText(getInstance().dateInventionTextBox,dateInventionTextBoxText);
    }

    public static String getNumberOrDescriptionInventionTextBox() {
        return getInstance().numberOrDescriptionInventionTextBox.getText();
    }

    public static void setNumberOrDescriptionInventionTextBox(String numberOrDescriptionInventionTextBoxText) {
        getInstance().logger.info("setNumberOrDescriptionInventionTextBox");
        SeleniumTest.clearAndSetText(getInstance().numberOrDescriptionInventionTextBox,numberOrDescriptionInventionTextBoxText);
    }

    public static String getNameOpenSourceProjectTextBox() {
        return getInstance().nameOpenSourceProjectTextBox.getText();
    }

    public static void setNameOpenSourceProjectTextBox(String nameOpenSourceProjectTextBoxText) {
        getInstance().logger.info("setNameOpenSourceProjectTextBox");
        SeleniumTest.clearAndSetText(getInstance().nameOpenSourceProjectTextBox,nameOpenSourceProjectTextBoxText);
    }

    public static String getWebsiteOpenSourceProjectTextBox() {
        return getInstance().websiteOpenSourceProjectTextBox.getText();
    }

    public static void setWebsiteOpenSourceProjectTextBox(String websiteOpenSourceProjectTextBoxText) {
        getInstance().logger.info("setWebsiteOpenSourceProjectTextBox");
        SeleniumTest.clearAndSetText(getInstance().websiteOpenSourceProjectTextBox,websiteOpenSourceProjectTextBoxText);
    }

    public static String getNameStandardsOrganizationTextBox() {
        return getInstance().nameStandardsOrganizationTextBox.getText();
    }

    public static void setNameStandardsOrganizationTextBox(String nameStandardsOrganizationTextBoxText) {
        getInstance().logger.info("setNameStandardsOrganizationTextBox");
        SeleniumTest.clearAndSetText(getInstance().nameStandardsOrganizationTextBox,nameStandardsOrganizationTextBoxText);
    }

    public static String getWebsiteStandardsOrganizationTextBox() {
        return getInstance().websiteStandardsOrganizationTextBox.getText();
    }

    public static void setWebsiteStandardsOrganizationTextBox(String websiteStandardsOrganizationTextBoxText) {
        getInstance().logger.info("setWebsiteStandardsOrganizationTextBox");
        SeleniumTest.clearAndSetText(getInstance().websiteStandardsOrganizationTextBox,websiteStandardsOrganizationTextBoxText);
    }
    //</editor-fold>

    /**
     * Overloaded function to click and stay on same page
     * TODO: research how to put this into base class
     * @return Form14718 page
     */
    public static FormID14718ConcatenatedClientFormFacebook clickRichFormNavigationButton() {
        SeleniumTest.click(getInstance().richFormNavigationButton);
        return PageFactory.initElements(Driver.getDriver(), FormID14718ConcatenatedClientFormFacebook.class);
    }

    /**
     * This checks all the checkboxes on the form
     */
    public static void checkAllTheThings() {
        getInstance().logger.info("Checking all check boxes");
        SeleniumTest.waitForElementToBeClickable(getInstance().signHereFacebookUserDataAccessCheckBox);
        SeleniumTest.waitMs(3000); // Adding implicit wait, as script getting failed while clicking on multiple checkboxes
        clickSignHereAdultMaterialCheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereContingentWorkerCheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereContingentWorkerPage2CheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereContingentWorkerPage3CheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereContingentWorkerPage4CheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereContingentWorkerPage5CheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereContingentWorkerPage6CheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereContingentWorkerPage7CheckBox();
        SeleniumTest.waitMs(3000);
        clickSignHereContingentWorkerCheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereFacebookUserDataAccessCheckBox();
        SeleniumTest.waitMs(3000);
        clickInitialHereFacebookUserDataAccessPage2CheckBox();
        SeleniumTest.waitMs(3000);
        clickSignHereFacebookUserDataAccess();

        clickSignHereCheckBoxWaiver();
        clickInitialHereProUnlimited();
        clickSignHereProUnlimited();

        clickInitialHerePTO();
        clickInitialHerePTOPage2();
        clickInitialHereNewChild();
    }

    /**
     * This fills out all required text fields, and 2 not required ones
     */
    public static void fillOutAllTheFields() {
        getInstance().logger.info("Fill out all required text fields (and 2 not required");
        //TODO consider putting this into TestData
        setListOfPriorObligationsTextBox("Harry Potter");
        setNameOpenSourceProjectTextBox("World Wide Web");
        setWebsiteOpenSourceProjectTextBox("www");

        setNameStandardsOrganizationTextBox("Starfleet");
        setWebsiteStandardsOrganizationTextBox("www.startrek.org");
        // that's the last required field, now I need to move focus away so the button will change to From Complete
        setTitleInventionTextBox("Tom A Swift Electric Rifle");
        setDateInventionTextBox("this is unformatted");
        setNumberOrDescriptionInventionTextBox("A Taser");
    }
}