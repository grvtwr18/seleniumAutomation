package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MichiganStatesCitiesForm extends CandidatePortalPages {
    protected static final Logger staticLogger = LoggerFactory.getLogger(MichiganStatesCitiesForm.class);

    @FindBy(how = How.XPATH,using = "//label[@for='1824-1824_9_100%']")
    private WebElement albionEarnings100pRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1824-1824_10_No']")
    private WebElement albionAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1824-1824_14']")
    private WebElement albionExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1824-1824_14")
    private WebElement albionExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID, using = "1824-1824_17")
    private WebElement albionExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1824-1824_19']")
    private WebElement albionExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1824-1824_19")
    private WebElement albionExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1824-1824_22")
    private WebElement albionExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1824-1824_24")
    private WebElement albionExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1824-1824_26")
    private WebElement albinoExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID, using = "1824-1824_28")
    private WebElement albinoTotalExcemptionOfYourChildersNOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1824-1824_30")
    private WebElement albinoTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[text()='I Certify']")
    private WebElement iCertifyLabel;

    @FindBy(how = How.XPATH, using = "//input[@fieldname='I Certify']")
    private WebElement iCertifyCheckbox;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Residency Statement']")
    private WebElement residencyStatementDropDown;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Employment Statement']")
    private WebElement employeeStatementDropDown;

    @FindBy(how = How.XPATH, using = "//button[@value='Next']")
    private WebElement nextButton;

    @FindBy(how = How.XPATH, using = "//label[@for='1825-1825_7_Yes']")
    private WebElement battleCreekResidentYesRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1825-1825_10']")
    private WebElement battleCreekExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1825-1825_10")
    private WebElement battleCreekExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1825-1825_15")
    private WebElement battleCreekExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1825-1825_17']")
    private WebElement battleCreekExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1825-1825_17")
    private WebElement battleCreekExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1825-1825_22")
    private WebElement battleCreekExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1825-1825_24")
    private WebElement battleCreekExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1825-1825_26")
    private WebElement battleCreekExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1825-1825_28")
    private WebElement battleCreekTotalExcemptionOfYourChildersNOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1825-1825_30")
    private WebElement battleCreekTotalExcemptionTextBox;

    @FindBy(how = How.XPATH,using = "//label[@for='1826-1826_7_Resident']")
    private WebElement bigRapidsResidentStatusRadioButton;

    @FindBy(how = How.ID,using = "1826-1826_10")
    private WebElement bigRapidsExcemptionForYourselfDropDown;

    @FindBy(how = How.ID,using = "1826-1826_12")
    private WebElement bigRapidsExcemptionForYourWifeOrHusbandDropDown;

    @FindBy(how = How.ID,using = "1826-1826_14")
    private WebElement bigRapidsExcemptionForYourChildrensNOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1826-1826_16")
    private WebElement bigRapidsTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1827-1827_10_100%']")
    private WebElement detroitEarnings100pRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1827-1827_9_No']")
    private WebElement detroitAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1827-1827_16']")
    private WebElement detroitExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1827-1827_16")
    private WebElement detroitExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1827-1827_20")
    private WebElement detroitExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1827-1827_22']")
    private WebElement detroitExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1827-1827_22")
    private WebElement detroitExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1827-1827_26")
    private WebElement detroitExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1827-1827_28")
    private WebElement detroitEcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1827-1827_30")
    private WebElement detroitExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1827-1827_32")
    private WebElement detroitTotalExcemptionOfYourChildersNOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1827-1827_34")
    private WebElement detroitTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1831-1831_7_City Resident']")
    private WebElement flintResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1831-1831_15']")
    private WebElement flintExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1831-1831_15")
    private WebElement flintExcemptionForYourselfCheckbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1831-1831_21']")
    private WebElement flintExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1831-1831_21")
    private WebElement flintExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1831-1831_25")
    private WebElement flintExcemptionForYourselfNWifeOrHusbancCheckBoxCountDropDown;

    @FindBy(how = How.ID,using = "1831-1831_27")
    private WebElement flintExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1831-1831_29")
    private WebElement flintExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1831-1831_31")
    private WebElement flintExcemptionForYourChildrensNOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1831-1831_33")
    private WebElement flintTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1828-1828_7_Resident']")
    private WebElement grandRapidsResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1828-1828_9_100%']")
    private WebElement grandRapidsEarnings100pRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1828-1828_11']")
    private WebElement grandRapidsExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1828-1828_11")
    private WebElement grandRapidsExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1828-1828_15")
    private WebElement grandRapidsExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "//label[@for='1828-1828_17']")
    private WebElement grandRapidsExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1828-1828_17")
    private WebElement grandRapidsExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1828-1828_21")
    private WebElement grandRapidsExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1828-1828_23")
    private WebElement grandRapidsExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1828-1828_25")
    private WebElement grandRapidsExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1828-1828_27")
    private WebElement grandRapidsTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1832-1832_7_Resident']")
    private WebElement graylingResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1832-1832_11_100%']")
    private WebElement graylingEarnings100pRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1832-1832_10_No']")
    private WebElement graylingAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1832-1832_15']")
    private WebElement graylingExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1832-1832_15")
    private WebElement graylingExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1832-1832_19")
    private WebElement graylingExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1832-1832_21']")
    private WebElement graylingExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1832-1832_21")
    private WebElement graylingExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1832-1832_25")
    private WebElement graylingExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1832-1832_27")
    private WebElement graylingExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1832-1832_29")
    private WebElement graylingExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1832-1832_31")
    private WebElement graylingTotalExcemptionForYourChildrensNOtherDependetTextbox;

    @FindBy(how = How.ID,using = "1832-1832_33")
    private WebElement graylingTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1835-1835_7_Yes']")
    private WebElement hamtramckResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1835-1835_11_100%']")
    private WebElement hamtramckEarnings100pRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1835-1835_10_No']")
    private WebElement hamtramckAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1835-1835_15']")
    private WebElement hamtramckExcemptionForYourselflabel;

    @FindBy(how = How.ID,using = "1835-1835_15")
    private WebElement hamtramckExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1835-1835_19")
    private WebElement hamtramckExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1835-1835_21']")
    private WebElement hamtramckExcemptionForYourWifeOrHusbandlabel;

    @FindBy(how = How.ID,using = "1835-1835_21")
    private WebElement hamtramckExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1835-1835_25")
    private WebElement hamtramckExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1835-1835_27")
    private WebElement hamtramckExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1835-1835_29")
    private WebElement hamtramckExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1835-1835_31")
    private WebElement hamtramckTotalExcemptionForYourChildrensNYourOtherDependentTextBox;

    @FindBy(how = How.ID,using = "1835-1835_33")
    private WebElement hamtramckTotalExcemptionTextBox;

    @FindBy(how = How.XPATH,using = "//label[@for='1833-1833_7_Yes']")
    private WebElement highlandParkResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1833-1833_11_100%']")
    private WebElement highlandParkEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1833-1833_10_No']")
    private WebElement highlandParkAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1833-1833_15']")
    private WebElement highlandParkExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1833-1833_15")
    private WebElement highlandParkExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1833-1833_19")
    private WebElement highlandParkExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1833-1833_21']")
    private WebElement highlandParkExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1833-1833_21")
    private WebElement highlandParkExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1833-1833_25")
    private WebElement highlandParkExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1833-1833_27")
    private WebElement highlandParkExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1833-1833_29")
    private WebElement highlandParkExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1833-1833_31")
    private WebElement highlandParkTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1833-1833_33")
    private WebElement highlandParkTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1834-1834_7_Resident']")
    private WebElement hudsonResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1834-1834_11_100%']")
    private WebElement hudsonEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1834-1834_10_No']")
    private WebElement hudsonAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1834-1834_15']")
    private WebElement hudsonExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1834-1834_15")
    private WebElement hudsonExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1834-1834_19")
    private WebElement hudsonExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1834-1834_21']")
    private WebElement hudsonExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1834-1834_21")
    private WebElement hudsonExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1834-1834_25")
    private WebElement hudsonExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1834-1834_27")
    private WebElement hudsonExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1834-1834_29")
    private WebElement hudsonExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1834-1834_31")
    private WebElement hudsonTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1834-1834_33")
    private WebElement hudsonTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1829-1829_8_City Resident']")
    private WebElement iOniaResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1829-1829_10']")
    private WebElement iOniaExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1829-1829_10")
    private WebElement iOniaExcemptionForYourselfCheckbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1829-1829_17']")
    private WebElement iOniaExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1829-1829_17")
    private WebElement iOniaExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1829-1829_22")
    private WebElement iOniaExcemptionForYourselfNWifeOrHusbancCheckBoxCountDropDown;

    @FindBy(how = How.ID,using = "1829-1829_25")
    private WebElement iOniaExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1829-1829_27")
    private WebElement iOniaExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1829-1829_29")
    private WebElement iOniaExcemptionForYourChildrensNOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1829-1829_31")
    private WebElement iOniaTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1836-1836_7_Resident']")
    private WebElement jacksonResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1836-1836_11_100%']")
    private WebElement jacksonEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1836-1836_10_No']")
    private WebElement jacksonAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1836-1836_15']")
    private WebElement jacksonExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1836-1836_15")
    private WebElement jacksonExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1836-1836_19")
    private WebElement jacksonExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1836-1836_21']")
    private WebElement jacksonExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1836-1836_21")
    private WebElement jacksonExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1836-1836_25")
    private WebElement jacksonExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1836-1836_27")
    private WebElement jacksonExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1836-1836_29")
    private WebElement jacksonExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1836-1836_31")
    private WebElement jacksonTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1836-1836_33")
    private WebElement jacksonTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1830-1830_8_City Resident']")
    private WebElement lansingResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1830-1830_10']")
    private WebElement lansingExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1830-1830_10")
    private WebElement lansingExcemptionForYourselfCheckbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1830-1830_17']")
    private WebElement lansingExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1830-1830_17")
    private WebElement lansingExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1830-1830_22")
    private WebElement lansingExcemptionForYourselfNWifeOrHusbancCheckBoxCountDropDown;

    @FindBy(how = How.ID,using = "1830-1830_25")
    private WebElement lansingExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1830-1830_27")
    private WebElement lansingExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1830-1830_29")
    private WebElement lansingExcemptionForYourChildrensNOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1830-1830_33")
    private WebElement lansingTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1837-1837_7_Resident']")
    private WebElement lapeerResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1837-1837_11_100%']")
    private WebElement lapeerEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1837-1837_10_No']")
    private WebElement lapeerAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1837-1837_15']")
    private WebElement lapeerExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1837-1837_15")
    private WebElement lapeerExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1837-1837_19")
    private WebElement lapeerExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1837-1837_21']")
    private WebElement lapeerExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1837-1837_21")
    private WebElement lapeerExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1837-1837_25")
    private WebElement lapeerExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1837-1837_27")
    private WebElement lapeerExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1837-1837_29")
    private WebElement lapeerExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1837-1837_31")
    private WebElement lapeerTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1837-1837_33")
    private WebElement lapeerTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1838-1838_7_City Resident']")
    private WebElement muskegonResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1838-1838_11_100%']")
    private WebElement muskegonEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1838-1838_10_No']")
    private WebElement muskegonAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1838-1838_15']")
    private WebElement muskegonExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1838-1838_15")
    private WebElement muskegonExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1838-1838_18")
    private WebElement muskegonExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1838-1838_20']")
    private WebElement muskegonExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1838-1838_20")
    private WebElement muskegonExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1838-1838_23")
    private WebElement muskegonExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1838-1838_25")
    private WebElement muskegonExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1838-1838_27")
    private WebElement muskegonExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1838-1838_29")
    private WebElement muskegonTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1838-1838_31")
    private WebElement muskegonTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1839-1839_7_Resident']")
    private WebElement muskegonHeightsResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1839-1839_11_100%']")
    private WebElement muskegonHeightsEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1839-1839_10_No']")
    private WebElement muskegonHeightsAnotherCityNoRadioButton;

    @FindBy(how = How.ID,using = "1839-1839_15")
    private WebElement muskegonHeightsExcemptionForYourselfDropDown;

    @FindBy(how = How.ID,using = "1839-1839_17")
    private WebElement muskegonHeightsExcemptionForYourWifeOrHusbandDropDown;

    @FindBy(how = How.ID,using = "1839-1839_19")
    private WebElement muskegonHeightsExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1839-1839_21")
    private WebElement muskegonHeightsExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1839-1839_23")
    private WebElement muskegonHeightsTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1839-1839_25")
    private WebElement muskegonHeightsTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1841-1841_7_Yes']")
    private WebElement pontiacResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1841-1841_11_100%']")
    private WebElement pontiacEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1841-1841_10_No']")
    private WebElement pontiacAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1841-1841_15']")
    private WebElement pontiacExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1841-1841_15")
    private WebElement pontiacExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1841-1841_19")
    private WebElement pontiacExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1841-1841_21']")
    private WebElement pontiacExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1841-1841_21")
    private WebElement pontiacExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1841-1841_25")
    private WebElement pontiacExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1841-1841_27")
    private WebElement pontiacExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1841-1841_29")
    private WebElement pontiacExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1841-1841_31")
    private WebElement pontiacTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1841-1841_33")
    private WebElement pontiacTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1840-1840_7_Resident']")
    private WebElement portHuronResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1840-1840_11_100%']")
    private WebElement portHuronEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1840-1840_10_No']")
    private WebElement portHuronAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1840-1840_15']")
    private WebElement portHuronExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1840-1840_15")
    private WebElement portHuronExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1840-1840_21")
    private WebElement portHuronExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1840-1840_23']")
    private WebElement portHuronExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1840-1840_23")
    private WebElement portHuronExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1840-1840_29")
    private WebElement portHuronExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1840-1840_31")
    private WebElement portHuronExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1840-1840_33")
    private WebElement portHuronExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1840-1840_35")
    private WebElement portHuronTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1840-1840_37")
    private WebElement portHuronTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1842-1842_7_Resident']")
    private WebElement portlandResidencyStatusRadioButton;

    @FindBy(how = How.ID,using = "1842-1842_10")
    private WebElement portlandExcemptionForYourselfDropDown;

    @FindBy(how = How.ID,using = "1842-1842_12")
    private WebElement portlandExcemptionForYourWifeOrHusbandDropDown;

    @FindBy(how = How.ID,using = "1842-1842_14")
    private WebElement portlandExcemptionForYourChildrensNYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1842-1842_16")
    private WebElement portlandTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1844-1844_7_City Resident']")
    private WebElement saginawResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1844-1844_10_100%']")
    private WebElement saginawEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1844-1844_9_No']")
    private WebElement saginawAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1844-1844_14']")
    private WebElement saginawExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1844-1844_14")
    private WebElement saginawExcemptionForYourselfCheckbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1844-1844_20']")
    private WebElement saginawExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1844-1844_20")
    private WebElement saginawExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1844-1844_24")
    private WebElement saginawExcemptionForYourselfNForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1844-1844_26")
    private WebElement saginawExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1844-1844_28")
    private WebElement saginawExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1844-1844_30")
    private WebElement saginawTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1844-1844_32")
    private WebElement saginawTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1843-1843_7_Yes']")
    private WebElement springfieldResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1843-1843_10']")
    private WebElement springfieldExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1843-1843_10")
    private WebElement springfieldExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1843-1843_15")
    private WebElement springfieldExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1843-1843_17']")
    private WebElement springfieldExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1843-1843_17")
    private WebElement springfieldExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1843-1843_22")
    private WebElement springfieldExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1843-1843_24")
    private WebElement springfieldExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1843-1843_26")
    private WebElement springfieldExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1843-1843_28")
    private WebElement springfieldTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1843-1843_30")
    private WebElement springfieldTotalExcemptionTextbox;

    @FindBy(how = How.XPATH,using = "//label[@for='1845-1845_7_Resident']")
    private WebElement walkerResidencyStatusRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1845-1845_11_100%']")
    private WebElement walkerEarningsRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1845-1845_10_No']")
    private WebElement walkerAnotherCityNoRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1845-1845_16']")
    private WebElement walkerExcemptionForYourselfLabel;

    @FindBy(how = How.ID,using = "1845-1845_16")
    private WebElement walkerExcemptionForYourselfCheckbox;

    @FindBy(how = How.ID,using = "1845-1845_15")
    private WebElement walkerExcemptionForYourselfCheckboxCountDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1845-1845_19']")
    private WebElement walkerExcemptionForYourWifeOrHusbandLabel;

    @FindBy(how = How.ID,using = "1845-1845_19")
    private WebElement walkerExcemptionForYourWifeOrHusbandCheckbox;

    @FindBy(how = How.ID,using = "1845-1845_18")
    private WebElement walkerExcemptionForYourWifeOrHusbandCheckboxCountDropDown;

    @FindBy(how = How.ID,using = "1845-1845_21")
    private WebElement walkerExcemptionForYourChildrensDropDown;

    @FindBy(how = How.ID,using = "1845-1845_23")
    private WebElement walkerExcemptionForYourOtherDependentDropDown;

    @FindBy(how = How.ID,using = "1845-1845_25")
    private WebElement walkerTotalExcemptionForYourChildrensNYourOtherDependentTextbox;

    @FindBy(how = How.ID,using = "1845-1845_27")
    private WebElement walkerTotalExcemptionTextbox;

    public CandidatePortalPages clickNextBtn(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public void fillMichiganStateCityData(String stateName,String cityName,String statement)
    {
       switch (cityName)
       {
           case "Albion":
           {
               fillAlbionCityData();
               break;
           }
           case "Battle Creek":
           {
               fillBattleCreekCityData();
               break;
           }
           case "Big Rapids":
           {
               fillBigRapidsCityData();
               break;
           }
           case "Detroit":
           {
               fillDetroitCityData();
               break;
           }
           case "Flint":
           {
               fillFlintCityData();
               break;
           }
           case "Grand Rapids":
           {
               fillGrandRapidsCityData();
               break;
           }
           case "Grayling":
           {
               fillGraylingCityData();
               break;
           }
           case "Hamtramck":
           {
               fillHamtramckCityData();
               break;
           }
           case "Highland Park":
           {
               fillHighlandParkCityData();
               break;
           }
           case "Hudson":
           {
               fillHudsonCityData();
               break;
           }
           case "Ionia":
           {
               fillIoniaCityData();
               break;
           }
           case "Jackson":
           {
               fillJacksonCityData();
               break;
           }
           case "Lansing":
           {
               fillLansingCityData();
               break;
           }
           case "Lapeer":
           {
               fillLapeerCityData();
               break;
           }
           case "Muskegon":
           {
               fillMuskegonCityData();
               break;
           }
           case "Muskegon Heights":
           {
               fillMuskegonHeightsCityData();
               break;
           }
           case "Pontiac":
           {
               fillPontiacCityData();
               break;
           }
           case "Port Huron":
           {
               fillPortHuronCityData();
               break;
           }
           case "Portland":
           {
               fillPortlandCityData();
               break;
           }
           case "Saginaw":
           {
               fillSaginawCityData();
               break;
           }
           case "Springfield":
           {
               fillSpringfieldCityData();
               break;
           }
           case "Walker":
           {
               fillWalkerCityData();
               break;
           }
       }
       staticLogger.info("Check i Certify Checkbox");
       SeleniumTest.check(iCertifyLabel,iCertifyCheckbox);
        String strResidencyStatement = "I live in";
       String Statement = statement+" "+cityName;
       staticLogger.info("provide residency statement");
       SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropDown,strResidencyStatement+" "+cityName);
       SeleniumTest.selectByVisibleTextFromDropDown(employeeStatementDropDown,Statement);
    }

    public void fillAlbionCityData()
    {
        SeleniumTest.click(albionEarnings100pRadioButton);

        SeleniumTest.click(albionAnotherCityNoRadioButton);

        SeleniumTest.check(albionExcemptionForYourselfLabel,albionExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(albionExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenAlbinoCityDetails.EXCEMPTIONFORYOURSELF.toString());

       SeleniumTest.check(albionExcemptionForYourWifeOrHusbandLabel,albionExcemptionForYourWifeOrHusbandCheckbox);

       SeleniumTest.selectByVisibleTextFromDropDown(albionExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenAlbinoCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

       SeleniumTest.selectByVisibleTextFromDropDown(albionExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenAlbinoCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

       SeleniumTest.selectByVisibleTextFromDropDown(albinoExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenAlbinoCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillBattleCreekCityData()
    {
        SeleniumTest.click(battleCreekResidentYesRadioButton);

        SeleniumTest.check(battleCreekExcemptionForYourselfLabel,battleCreekExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(battleCreekExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenBattleCreekCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(battleCreekExcemptionForYourWifeOrHusbandLabel,battleCreekExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(battleCreekExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenBattleCreekCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(battleCreekExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenBattleCreekCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(battleCreekExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenBattleCreekCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillBigRapidsCityData()
    {
        SeleniumTest.click(bigRapidsResidentStatusRadioButton);

        SeleniumTest.selectByVisibleTextFromDropDown(bigRapidsExcemptionForYourselfDropDown,stateTaxFormTestData.MichigenBigRapidsCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(bigRapidsExcemptionForYourWifeOrHusbandDropDown,stateTaxFormTestData.MichigenBigRapidsCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(bigRapidsExcemptionForYourChildrensNOtherDependentDropDown,stateTaxFormTestData.MichigenBigRapidsCityDetails.EXCEMPTIONFORYOURCHILDRESOROTHERDEPENDENT.toString());
    }

    public void fillDetroitCityData()
    {
        SeleniumTest.click(detroitEarnings100pRadioButton);

        SeleniumTest.click(detroitAnotherCityNoRadioButton);

        SeleniumTest.check(detroitExcemptionForYourselfLabel,detroitExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(detroitExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenDetroitCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(detroitExcemptionForYourWifeOrHusbandLabel,detroitExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(detroitExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenDetroitCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(detroitEcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenDetroitCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(detroitExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenDetroitCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillFlintCityData()
    {
        SeleniumTest.click(flintResidencyStatusRadioButton);

        SeleniumTest.check(flintExcemptionForYourselfLabel,flintExcemptionForYourselfCheckbox);

        SeleniumTest.check(flintExcemptionForYourWifeOrHusbandLabel,flintExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(flintExcemptionForYourselfNWifeOrHusbancCheckBoxCountDropDown,stateTaxFormTestData.MichcigenFlintDetails.EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(flintExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichcigenFlintDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(flintExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichcigenFlintDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillGrandRapidsCityData()
    {
        SeleniumTest.click(grandRapidsResidencyStatusRadioButton);

        SeleniumTest.click(grandRapidsEarnings100pRadioButton);

        SeleniumTest.check(grandRapidsExcemptionForYourselfLabel,grandRapidsExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(grandRapidsExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenGrandRapidsCittDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(grandRapidsExcemptionForYourWifeOrHusbandLabel,grandRapidsExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(grandRapidsExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenGrandRapidsCittDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(grandRapidsExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenGrandRapidsCittDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(grandRapidsExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenGrandRapidsCittDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillGraylingCityData()
    {
        SeleniumTest.click(graylingResidencyStatusRadioButton);

        SeleniumTest.click(graylingEarnings100pRadioButton);

        SeleniumTest.click(graylingAnotherCityNoRadioButton);

        SeleniumTest.check(graylingExcemptionForYourselfLabel,graylingExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(graylingExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenGraylingCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(graylingExcemptionForYourWifeOrHusbandLabel,graylingExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(graylingExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenGraylingCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(graylingExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenGraylingCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(graylingExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenGraylingCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillHamtramckCityData()
    {
        SeleniumTest.click(hamtramckResidencyStatusRadioButton);

        SeleniumTest.click(hamtramckEarnings100pRadioButton);

        SeleniumTest.click(hamtramckAnotherCityNoRadioButton);

        SeleniumTest.check(hamtramckExcemptionForYourselflabel,hamtramckExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(hamtramckExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenHamtramckCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(hamtramckExcemptionForYourWifeOrHusbandlabel,hamtramckExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(hamtramckExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenHamtramckCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(hamtramckExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenHamtramckCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(hamtramckExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenHamtramckCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillHighlandParkCityData()
    {
        SeleniumTest.click(highlandParkResidencyStatusRadioButton);

        SeleniumTest.click(highlandParkEarningsRadioButton);

        SeleniumTest.click(highlandParkAnotherCityNoRadioButton);

        SeleniumTest.check(highlandParkExcemptionForYourselfLabel,highlandParkExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(highlandParkExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenHighlandParkCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(highlandParkExcemptionForYourWifeOrHusbandLabel,highlandParkExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(highlandParkExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenHighlandParkCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(highlandParkExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenHighlandParkCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(highlandParkExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenHighlandParkCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillHudsonCityData()
    {
        SeleniumTest.click(hudsonResidencyStatusRadioButton);

        SeleniumTest.click(hudsonEarningsRadioButton);

        SeleniumTest.click(hudsonAnotherCityNoRadioButton);

        SeleniumTest.check(hudsonExcemptionForYourselfLabel,hudsonExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(hudsonExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenHudsonCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(hudsonExcemptionForYourWifeOrHusbandLabel,hudsonExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(hudsonExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenHudsonCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(hudsonExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenHudsonCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(hudsonExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenHudsonCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillIoniaCityData()
    {
        SeleniumTest.click(iOniaResidencyStatusRadioButton);

        SeleniumTest.check(iOniaExcemptionForYourselfLabel,iOniaExcemptionForYourselfCheckbox);

        SeleniumTest.check(iOniaExcemptionForYourWifeOrHusbandLabel,iOniaExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(iOniaExcemptionForYourselfNWifeOrHusbancCheckBoxCountDropDown,stateTaxFormTestData.MichigenIoniaCityDetails.EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(iOniaExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenIoniaCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(iOniaExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenIoniaCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillJacksonCityData()
    {
        SeleniumTest.click(jacksonResidencyStatusRadioButton);

        SeleniumTest.click(jacksonEarningsRadioButton);

        SeleniumTest.click(jacksonAnotherCityNoRadioButton);

        SeleniumTest.check(jacksonExcemptionForYourselfLabel,jacksonExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(jacksonExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenJacksonCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(jacksonExcemptionForYourWifeOrHusbandLabel,jacksonExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(jacksonExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenJacksonCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(jacksonExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenJacksonCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(jacksonExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenJacksonCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillLansingCityData()
    {
        SeleniumTest.click(lansingResidencyStatusRadioButton);

        SeleniumTest.check(lansingExcemptionForYourselfLabel,lansingExcemptionForYourselfCheckbox);

        SeleniumTest.check(lansingExcemptionForYourWifeOrHusbandLabel,lansingExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(lansingExcemptionForYourselfNWifeOrHusbancCheckBoxCountDropDown,stateTaxFormTestData.MichigenLansingCityDetails.EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(lansingExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenLansingCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(lansingExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenLansingCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillLapeerCityData()
    {
        SeleniumTest.click(lapeerResidencyStatusRadioButton);

        SeleniumTest.click(lapeerEarningsRadioButton);

        SeleniumTest.click(lapeerAnotherCityNoRadioButton);

        SeleniumTest.check(lapeerExcemptionForYourselfLabel,lapeerExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(lapeerExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenLapeerCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(lapeerExcemptionForYourWifeOrHusbandLabel,lapeerExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(lapeerExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenLapeerCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(lapeerExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenLapeerCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(lapeerExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenLapeerCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillMuskegonCityData()
    {
        SeleniumTest.click(muskegonResidencyStatusRadioButton);

        SeleniumTest.click(muskegonEarningsRadioButton);

        SeleniumTest.click(muskegonAnotherCityNoRadioButton);

        SeleniumTest.check(muskegonExcemptionForYourselfLabel,muskegonExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenMuskegonCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(muskegonExcemptionForYourWifeOrHusbandLabel,muskegonExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenMuskegonCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenMuskegonCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenMuskegonCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillMuskegonHeightsCityData()
    {
        SeleniumTest.click(muskegonHeightsResidencyStatusRadioButton);

        SeleniumTest.click(muskegonHeightsEarningsRadioButton);

        SeleniumTest.click(muskegonHeightsAnotherCityNoRadioButton);

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonHeightsExcemptionForYourselfDropDown,stateTaxFormTestData.MichigenMuskegonHeightsDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonHeightsExcemptionForYourWifeOrHusbandDropDown,stateTaxFormTestData.MichigenMuskegonHeightsDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonHeightsExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenMuskegonHeightsDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(muskegonHeightsExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenMuskegonHeightsDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillPontiacCityData()
    {
        SeleniumTest.click(pontiacResidencyStatusRadioButton);

        SeleniumTest.click(pontiacEarningsRadioButton);

        SeleniumTest.click(pontiacAnotherCityNoRadioButton);

        SeleniumTest.check(pontiacExcemptionForYourselfLabel,pontiacExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(pontiacExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenPontiacCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(pontiacExcemptionForYourWifeOrHusbandLabel,pontiacExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(pontiacExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenPontiacCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(pontiacExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenPontiacCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(pontiacExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenPontiacCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillPortHuronCityData()
    {
        SeleniumTest.click(portHuronResidencyStatusRadioButton);

        SeleniumTest.click(portHuronEarningsRadioButton);

        SeleniumTest.click(portHuronAnotherCityNoRadioButton);

        SeleniumTest.check(portHuronExcemptionForYourselfLabel,portHuronExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(portHuronExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenPortHuronDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(portHuronExcemptionForYourWifeOrHusbandLabel,portHuronExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(portHuronExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenPortHuronDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(portHuronExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenPortHuronDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(portHuronExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenPortHuronDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillPortlandCityData()
    {
        SeleniumTest.click(portlandResidencyStatusRadioButton);

        SeleniumTest.selectByVisibleTextFromDropDown(portlandExcemptionForYourselfDropDown,stateTaxFormTestData.MichigenPortlandCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(portlandExcemptionForYourWifeOrHusbandDropDown,stateTaxFormTestData.MichigenPortlandCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(portlandExcemptionForYourChildrensNYourOtherDependentDropDown,stateTaxFormTestData.MichigenPortlandCityDetails.EXCEMPTIONFORYOURCHILDRESNOTHERDEPENDENT.toString());
    }

    public void fillSaginawCityData()
    {
        SeleniumTest.click(saginawResidencyStatusRadioButton);

        SeleniumTest.click(saginawEarningsRadioButton);

        SeleniumTest.click(saginawAnotherCityNoRadioButton);

        SeleniumTest.check(saginawExcemptionForYourselfLabel,saginawExcemptionForYourselfCheckbox);

        SeleniumTest.check(saginawExcemptionForYourWifeOrHusbandLabel,saginawExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(saginawExcemptionForYourselfNForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenSaginawCityDetails.EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(saginawExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenSaginawCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(saginawExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenSaginawCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillSpringfieldCityData()
    {
        SeleniumTest.click(springfieldResidencyStatusRadioButton);

        SeleniumTest.check(springfieldExcemptionForYourselfLabel,springfieldExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(springfieldExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenSpringfieldCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(springfieldExcemptionForYourWifeOrHusbandLabel,springfieldExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(springfieldExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenSpringfieldCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(springfieldExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenSpringfieldCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(springfieldExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenSpringfieldCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }

    public void fillWalkerCityData()
    {
        SeleniumTest.click(walkerResidencyStatusRadioButton);

        SeleniumTest.click(walkerEarningsRadioButton);

        SeleniumTest.click(walkerAnotherCityNoRadioButton);

        SeleniumTest.check(walkerExcemptionForYourselfLabel,walkerExcemptionForYourselfCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(walkerExcemptionForYourselfCheckboxCountDropDown,stateTaxFormTestData.MichigenWalkerCityDetails.EXCEMPTIONFORYOURSELF.toString());

        SeleniumTest.check(walkerExcemptionForYourWifeOrHusbandLabel,walkerExcemptionForYourWifeOrHusbandCheckbox);

        SeleniumTest.selectByVisibleTextFromDropDown(walkerExcemptionForYourWifeOrHusbandCheckboxCountDropDown,stateTaxFormTestData.MichigenWalkerCityDetails.EXCEMPTIONFORYOURWIFEORHUSBAND.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(walkerExcemptionForYourChildrensDropDown,stateTaxFormTestData.MichigenWalkerCityDetails.EXCEMPTIONFORYOURCHILDRES.toString());

        SeleniumTest.selectByVisibleTextFromDropDown(walkerExcemptionForYourOtherDependentDropDown,stateTaxFormTestData.MichigenWalkerCityDetails.EXCEMPTIONFORYOUROTHERDEPENDENT.toString());
    }
}
