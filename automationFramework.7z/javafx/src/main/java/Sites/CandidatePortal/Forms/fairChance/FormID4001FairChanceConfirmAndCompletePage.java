package Sites.CandidatePortal.Forms.fairChance;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.individualizedReview.IrWorkflowPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * @author sbashar
 */
public class FormID4001FairChanceConfirmAndCompletePage extends IrWorkflowPages {

    @FindBy(how = How.CSS, using = "input[value='Confirm']")
    private static WebElement confirmButton;

    /**
     * Click on the confirm button.
     */
    public static CandidatePortalPages clickConfirm(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(confirmButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

}
