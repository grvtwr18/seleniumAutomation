package Sites.CandidatePortal.Forms.tax.state.oklahoma;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_21253 extends CandidatePortalPages {
    @FindBy(how = How.CLASS_NAME, using = "title")
    private WebElement title;

    @FindBy(how = How.CLASS_NAME, using = "subTitle")
    private WebElement subTitle;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_3']")
    public WebElement filingStatus;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_3_Single']")
    private WebElement singleRadioButton;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_3_Married']")
    private WebElement marriedRadioButton;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_3_Married, but withhold at higher Single rate']")
    private WebElement marriedButWithholdingAtAHigherRateRadioButton;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_5']")
    public WebElement allowanceForYourself;

    @FindBy(how = How.ID, using = "21253-21253_5")
    private WebElement allowanceForYourselfInput;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_7']")
    public WebElement spouseWorks;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_9']")
    public WebElement spouseAllowance;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_7_Yes']")
    private WebElement spouseAllowanceYesRadioButton;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_7_No']")
    private WebElement spouseAllowanceNoRadioButton;

    @FindBy(how = How.ID, using = "21253-21253_9")
    private WebElement yesAllowanceValueInput;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_11']")
    public WebElement dependentAllowance;

    @FindBy(how = How.ID, using = "21253-21253_11")
    private WebElement allowanceForDependentsInput;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_13']")
    public WebElement additionalAllowance;

    @FindBy(how = How.ID, using = "21253-21253_13")
    private WebElement additionalAllowancesInput;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_15']")
    public WebElement totalAllowance;

    @FindBy(how = How.ID, using = "21253-21253_15")
    private WebElement totalAllowancesInput;

    @FindBy(how = How.ID, using = "21253-21253_17")
    private WebElement additionalWithholdingInput;

    @FindBy(how = How.ID, using = "21253-21253_19")
    private WebElement oklahomaExemptInput;

    @FindBy(how = How.ID, using = "21253-21253_21")
    private WebElement oklahomaMilitarySpouseExemptInput;

    @FindBy(how = How.ID, using = "21253-21253_23")
    private WebElement oklahomaMilitaryExemptInput;

    @FindBy(how = How.ID, using = "21253-21253_25")
    private WebElement iCertifyCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='21253-21253_25']")
    public WebElement iCertify;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_21253() {
    }

    public static Form_21253 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_21253.class);
    }

    public Form_21253 navigateTo() {
        return PageFactory.initElements(Driver.getDriver(), Form_21253.class);
    }

    public boolean onPage() {
        return getTitle().equals("W-4 (Oklahoma)");
    }

    public String getTitle() {
        return title.getText();
    }

    public String getSubTitle() {
        return subTitle.getText();
    }

    public Form_21253 chooseSingleRadioButton() {
        singleRadioButton.click();
        logger.info("Single Radio Button Chosen");
        return this;
    }

    public Form_21253 chooseMarriedRadioButton() {
        marriedRadioButton.click();
        logger.info("Married Radio Button Chosen");
        return this;
    }

    public Form_21253 chooseMarriedButWithholdingAtAHigherRateRadioButton() {
        this.marriedButWithholdingAtAHigherRateRadioButton = marriedButWithholdingAtAHigherRateRadioButton;
        logger.info("Married But withholding at a higher single rate Chosen");
        return this;
    }

    public String getAllowanceForYourself() {
        return allowanceForYourselfInput.getText();
    }

    public Form_21253 setAllowanceForYourselfInput(String allowance) {
        SeleniumTest.clearAndSetText(allowanceForYourselfInput, allowance);
        logger.info("Allowance for yourself set to {}", allowance);
        return this;
    }

    public Form_21253 chooseSpouseAllowanceYesRadioButton() {
        spouseAllowanceYesRadioButton.click();
        logger.info("Spouse allowance Yes Radio Button Chosen");
        return this;
    }

    public Form_21253 chooseSpouseAllowanceNoRadioButton() {
        spouseAllowanceNoRadioButton.click();
        logger.info("Spouse allowance No Radio Button Chosen");
        return this;
    }

    public String getSpouseYesAllowanceValue() {
        return yesAllowanceValueInput.getText();
    }

    public Form_21253 setSpouseYesAllowanceValue(String value) {
        SeleniumTest.clearAndSetText(yesAllowanceValueInput, value);
        logger.info("Spouse Allowance Value set to {}", value);
        return this;
    }

    public String getAllowanceForDependents() {
        return allowanceForDependentsInput.getText();
    }

    public Form_21253 setAllowanceForDependentsInput(String allowance) {
        SeleniumTest.clearAndSetText(allowanceForDependentsInput, allowance);
        logger.info("Allowance for Dependents set to {}", allowance);
        return this;
    }

    public String getAdditionalAllowances() {
        return additionalAllowancesInput.getText();
    }

    public Form_21253 setAdditionalAllowances(String allowances) {
        SeleniumTest.clearAndSetText(additionalAllowancesInput, allowances);
        logger.info("Additional Allowances set to {}", allowances);
        return this;
    }

    public String getTotalAllowances() {
        return totalAllowancesInput.getText();
    }

    public Form_21253 setTotalAllowances(String allowances) {
        SeleniumTest.clearAndSetText(totalAllowancesInput, allowances);
        logger.info("Total Allowances set to {}", allowances);
        return this;
    }

    public String getAdditionalWithholding() {
        return additionalWithholdingInput.getText();
    }

    public Form_21253 setAdditionalWithholding(String additionalWithholding) {
        SeleniumTest.clearAndSetText(additionalWithholdingInput, additionalWithholding);
        logger.info("Additional Withholding set to {}", additionalWithholding);
        return this;
    }

    public String getOklahomaExempt() {
        return oklahomaExemptInput.getText();
    }

    public Form_21253 setOklahomaExempt(String exempt) {
        SeleniumTest.clearAndSetText(oklahomaExemptInput, exempt);
        logger.info("Oklahoma Exempt set to {}", exempt);
        return this;
    }

    public String getOklahomaMilitarySpouseExempt() {
        return oklahomaMilitarySpouseExemptInput.getText();
    }

    public Form_21253 setOklahomaMilitarySpouseExempt(String exempt) {
        SeleniumTest.clearAndSetText(oklahomaMilitarySpouseExemptInput, exempt);
        logger.info("Oklahoma Military Spouse Exempt set to {}", exempt);
        return this;
    }

    public String getOklahomaMilitaryExemptInput() {
        return oklahomaMilitaryExemptInput.getText();
    }

    public Form_21253 setOklahomaMilitaryExempt(String exempt) {
        SeleniumTest.clearAndSetText(oklahomaMilitaryExemptInput, exempt);
        logger.info("Oklahoma Military Exempt set to {}", exempt);
        return this;
    }

    public Form_21253 checkICertifyCheckbox() {
        SeleniumTest.check(iCertify, iCertifyCheckbox);
        logger.info("I Certify Checked");
        return this;
    }

    public Form_21253 uncheckICertifyCheckbox() {
        SeleniumTest.unCheck(iCertify, iCertifyCheckbox);
        logger.info("I Certify unChecked");
        return this;
    }

    public void fillAllRequiredFields(
            FilingStatus status,
            String selfAllowance,
            String spouseAllowance,
            String dependentAllowance,
            String additonalAllowance,
            String totalAllowances) {
        switch(status) {
            case SINGLE:
                chooseSingleRadioButton();
                break;
            case MARRIED:
                chooseMarriedRadioButton();
                break;
            case MARRIED_AT_SINGLE_RATE:
                chooseMarriedButWithholdingAtAHigherRateRadioButton();
                break;
        }
        setAllowanceForYourselfInput(selfAllowance);
        chooseSpouseAllowanceYesRadioButton();
        setSpouseYesAllowanceValue(spouseAllowance);
        setAllowanceForDependentsInput(dependentAllowance);
        setAdditionalAllowances(additonalAllowance);
        setTotalAllowances(totalAllowances);
        checkICertifyCheckbox();
    }

    public boolean isRequired(WebElement element) {
        return element.getAttribute("class").toLowerCase().contains("required");
    }

    public String getErrorText(WebElement element) {
        try {
            return ((EventFiringWebDriver)Driver.getDriver()).getWrappedDriver()
                    .findElement(By.id(element.getAttribute("for") + "-err")).getText();
        } catch (NoSuchElementException nse) {
            return "";
        }
    }

    public enum FilingStatus {
        SINGLE(),
        MARRIED(),
        MARRIED_AT_SINGLE_RATE()
    }
}
