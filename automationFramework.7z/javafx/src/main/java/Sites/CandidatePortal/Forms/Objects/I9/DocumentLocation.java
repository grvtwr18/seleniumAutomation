package Sites.CandidatePortal.Forms.Objects.I9;

/**
 * Created by davidlam on 2/10/17.
 */
public interface DocumentLocation {
    String getValue();
    String getDocumentNumberId();
    String getReceiptId();
    String getIssuingAuthorityId();
    String getExpirationId();
    String getExpirationNaId();
    String getRichformDocTitle();
    String getRichformDocExpDate();
    String getRichformDocNumber();
}