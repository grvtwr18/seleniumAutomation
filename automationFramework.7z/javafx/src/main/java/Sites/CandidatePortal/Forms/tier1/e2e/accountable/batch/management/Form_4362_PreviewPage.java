package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Data.locations.us.UsStateTerritory;
import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_4362_PreviewPage extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_1']/span")
    private WebElement firstNameSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_18']/span")
    private WebElement middleNameSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_3']/span")
    private WebElement lastNameSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_5']/span")
    private WebElement ssnSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_7']/span")
    private WebElement addressLine1Span;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_8']/span")
    private WebElement apartmentNumberSpan;

    @FindBy(how = How.XPATH, using = "//input[@id='4362-105_1_Single']")
    private WebElement singleRadiobutton;

    @FindBy(how = How.XPATH, using = "//input[@id='4362-105_1_Married']")
    private WebElement marriedRadiobutton;

    @FindBy(how = How.XPATH, using = "//input[@id='4362-105_1_Married, but withhold at higher Single rate.']")
    private WebElement marriedAtSingleRateRadiobutton;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_10']/span")
    private WebElement citySpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_11']/span")
    private WebElement stateSubDivisionCodeSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-100_12']/span")
    private WebElement zipCodeSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-105_3']/span")
    private WebElement allowancesSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-105_4']/span")
    private WebElement additionalAmountSpan;

    @FindBy(how = How.XPATH, using = "//div[@id='4362-div-4362_20']")
    private WebElement dateSignedDiv;

    protected Logger logger = LoggerFactory.getLogger(Form_4362_PreviewPage.class);

    public static Form_4362_PreviewPage getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_4362_PreviewPage.class);
    }

    public String getFirstName() {
        return firstNameSpan.getText();
    }

    public String getMiddleName() {
        return middleNameSpan.getText();
    }

    public String getLastName() {
        return lastNameSpan.getText();
    }

    public String getSsn() {
        return ssnSpan.getText();
    }

    public String getAddressLine1() {
        return addressLine1Span.getText();
    }

    public String getApartmentNumber() {
        return apartmentNumberSpan.getText();
    }

    public boolean isSingleChosen() {
        if (singleRadiobutton.getAttribute("checked") != null) {
            return true;
        }
        return false;
    }

    public boolean isMarriedChosen() {
        if (marriedRadiobutton.getAttribute("checked") != null) {
            return true;
        }
        return false;
    }

    public boolean isMarriedButWithooldingAtHigherRateChecked() {
        if (marriedAtSingleRateRadiobutton.getAttribute("checked") != null) {
            return true;
        }
        return false;
    }

    public String getCity() {
        return citySpan.getText();
    }

    public UsStateTerritory getState() {
        return UsStateTerritory.parse(stateSubDivisionCodeSpan.getText());
    }

    public String getZipCode() {
        return zipCodeSpan.getText();
    }

    public String getAllowances() {
        return allowancesSpan.getText();
    }

    public String getAdditionalAmount() {
        return additionalAmountSpan.getText();
    }

    public String getDateSigned() {
        return dateSignedDiv.getText();
    }
}
