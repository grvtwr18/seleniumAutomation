package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * This file contains methods common to most pages in IR workflow.
 * Created by jgupta on 10/1/2017.
 */
public class IrWorkflowPages extends CandidatePortalPages {
    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private static WebElement saveButton;

    /**
     * Click on Next button
     * @return Returns the next class
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Click on the save button.
     */
    public static CandidatePortalPages save(Class<? extends CandidatePortalPages> returnedClass)
    {
        SeleniumTest.click(saveButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks on Add button.
     * @param index Starts from 0
     */
    public static void clickAddButton(int index) {
        SeleniumTest.click(By.id("historyAdd" + index));
    }

}
