package Sites.CandidatePortal.Forms.Objects.statetax;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 8/3/17.
 */
public class FormCT_W4NA_EmployeeCertification {

    @FindBy(how = How.CSS, using = "label[for$='1787_20']")
    private WebElement iCertifyLabel;

    @FindBy(how = How.CSS, using = "input[id$='1787_20']")
    private WebElement iCertifyCheckbox;

    public static FormCT_W4NA_EmployeeCertification getInstance() {
        return PageFactory.initElements(Driver.getDriver(), FormCT_W4NA_EmployeeCertification.class);
    }

    public FormCT_W4NA_EmployeeCertification checkICertify() {
        SeleniumTest.check(iCertifyLabel, iCertifyCheckbox);
        return this;
    }

    public FormCT_W4NA_EmployeeCertification uncheckICertify() {
        SeleniumTest.unCheck(iCertifyLabel, iCertifyCheckbox);
        return this;
    }
}
