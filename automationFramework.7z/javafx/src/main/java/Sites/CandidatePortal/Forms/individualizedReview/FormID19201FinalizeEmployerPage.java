package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FormID19201FinalizeEmployerPage extends IrWorkflowPages {

    @FindBy(how = How.CSS, using = "label[for='19201-19201_4']")
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.ID, using = "19201-19201_6")
    private static WebElement aaDropdown;

    @FindBy(how = How.ID, using = "19201-19201_8")
    private static WebElement aditionalComments;

    @FindBy(how = How.CSS, using = "button[value='Submit']")
    private static WebElement submitButton;

    public enum AdverseActionNextStep {
        PROCEED("Proceed with Adverse Action"),
        CANCEL("Cancel Adverse Action");

        private final String name;

        AdverseActionNextStep(String name) {
            this.name = name;
        }

        public String toString() {
            return name;
        }
    }

    /**
     * Checks the checkbox on IR overview page.
     */
    public static void checkIacknowledgeCheckbox() {
        if(!SeleniumTest.isCheckboxChecked(iAcknowledgeCheckbox))
            SeleniumTest.click(iAcknowledgeCheckbox);

    }

    public static void selectAdverseActionNextStep(AdverseActionNextStep action) {
        SeleniumTest.selectByVisibleTextFromDropDown(aaDropdown, action.toString());
    }

    public static void typeAdditionalComments(String comment) {
        SeleniumTest.clearAndSetText(aditionalComments, comment);
    }

    public static CandidatePortalPages typeAdditionalCommentsAndSubmit(String comment, Class<? extends
            CandidatePortalPages> returnedClass) {
        typeAdditionalComments(comment);
        return FormID19201FinalizeEmployerPage.clickSubmit(returnedClass);
    }

    public static CandidatePortalPages typeAdditionalCommentsAndSave(String comment, Class<? extends
            CandidatePortalPages> returnedClass) {
        typeAdditionalComments(comment);
        return FormID19201FinalizeEmployerPage.save(returnedClass);
    }

    /**
     * Click on the submit button.
     */
    public static CandidatePortalPages clickSubmit(Class<? extends CandidatePortalPages> returnedClass)
    {
        SeleniumTest.click(submitButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

}
