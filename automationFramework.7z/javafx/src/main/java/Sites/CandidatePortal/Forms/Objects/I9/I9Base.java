package Sites.CandidatePortal.Forms.Objects.I9;

import Data.locations.us.UsStateTerritory;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by abrackett on 10/17/16.
 */
public class I9Base {
    protected static final Logger staticLogger = LoggerFactory.getLogger(I9Base.class);
    public static String getErrorText(WebElement element) {
        WebElement errorText;
        try {
            errorText = element.findElement(By.id(element.getAttribute("id") + "-err"));
        } catch (NoSuchElementException nse) {
            return "";
        }
        return errorText.getText();
    }

    public static boolean isWriteable(WebElement element) {
        boolean writeable = true;
        try {
            writeable = !element.getAttribute("readonly").toLowerCase().equals("readonly");
        } catch (NullPointerException npe) {
            // leave boolean as writeable because we could not find the readonly attribute
        }
        return writeable;
    }

    public static boolean isRequired(WebElement element) {
        // Find the label for the field to check whether or not it is required
        // check for a class attribute or the * whichever works.
        try {
            String partialId = element.getAttribute("id").split("-")[element.getAttribute("id").split
                    ("-").length -1];

            if(!element.getAttribute("id").isEmpty()) {
                WebElement label = Driver.getDriver().findElement(
                        By.cssSelector("label[for$='" + partialId + "']"));
                return label.getText().contains("*") ||
                       label.getAttribute("class").toLowerCase().contains("required");
            }
        } catch (NoSuchElementException nse) {
            // nothing found this means it is not required
        }
        return false;
    }

    public static void selectStateOrProvince(UsStateTerritory state, WebElement element) {
        selectStateOrProvince(state.getFullName(), element);
    }

    public static void selectStateOrProvince(String state, WebElement element) {
        SeleniumTest.defaultWaitForElementWithMultiplier(.1);
        Select doItManuallyCauseSeleniumTestDoesNotWorkHere = new Select(element);
        WaitUntil.waitUntil(() -> {
            doItManuallyCauseSeleniumTestDoesNotWorkHere.selectByVisibleText(state);
            return doItManuallyCauseSeleniumTestDoesNotWorkHere
                    .getFirstSelectedOption().getText().equals(state);
        }, NoSuchElementException.class);

        if (isStateSelected(state, element)) {
            staticLogger.info("State or Province successfully set to {}", state);
        } else {
            staticLogger.info("Failed to set state to: {}", state);
            throw new RuntimeException("State " + state + " was not selected.");
        }
    }

    public static boolean isStateSelected(String state, WebElement element) {
        Select s = new Select(element);
        return s.getFirstSelectedOption().getText().equals(state);
    }
}
