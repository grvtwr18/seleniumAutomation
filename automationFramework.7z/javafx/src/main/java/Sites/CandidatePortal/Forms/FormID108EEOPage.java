package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by tjoshi on 11/24/2015.
 */
public class FormID108EEOPage  extends FormPage {

    @FindBy(how = How.XPATH, using = "//label[@for='108-108_15_1']")
    private WebElement completeVoluntaryEEOFormRadioValueYes;

    @FindBy(how = How.ID, using = "108-108_1")
    private WebElement jobTitleTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='108-108_2_1']")
    private WebElement genderRadioButtonValueMale;

    @FindBy(how = How.XPATH, using = "//label[@for='108-108_3_American Indian or Alaska Native (Not Hispanic or Latino)']")
    private WebElement raceRadioButtonValueAmericanIndian;

    @FindBy(how = How.CSS, using = "label[for='108-108_40']")
    private WebElement confirmationCheckBox;

    @FindBy(how = How.ID, using = "108-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * Select Yes for completing the voluntary EEO form
     */
    public void setCompleteVoluntaryEEOFormRadioValueYes()
    {
        completeVoluntaryEEOFormRadioValueYes.click();
    }

    /**
     * Set gender radio button to Male
     */
    public void setGenderMale()
    {
        genderRadioButtonValueMale.click();
    }

    /**
     * Set the job title
     * @param value
     */
    public void setJobTitleTextbox(String value)
    {
        SeleniumTest.clearAndSetText(jobTitleTextbox, value);
    }

    /**
     * Set race radio button to American Indian
     */
    public void setRaceRadioButtonValueAmericanIndian()
    {
        raceRadioButtonValueAmericanIndian.click();
    }


    /**
     * Click on Next button
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Fill in the form completely and submit the form
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages fillForm108EEO(Class<? extends CandidatePortalPages> returnedClass)
    {
        setCompleteVoluntaryEEOFormRadioValueYes();
        setGenderMale();
        setJobTitleTextbox("Professional Title");
        setRaceRadioButtonValueAmericanIndian();
        confirmationCheckBox.click();
        return clickNext(returnedClass);
    }
}
