package Sites.CandidatePortal.Forms.Objects.I9;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by davidlam on 2/3/17.
 */
public class Section3 extends I9Base {

    static {
        PageFactory.initElements(Driver.getDriver(), Section3.class);
    }

    @FindBy(how = How.CSS, using = "input[id$='-I9s3_52']")
    public static WebElement iAcknowledgeCheckBox;

    @FindBy(how = How.CSS, using = "label[for$='-I9s3_52']")
    public static WebElement iAcknowledgeCheckBoxLabel;

    @FindBy(how = How.CSS, using = "button[id='17231-previousnextbuttons-nextbutton']")
    public static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[id='acceptButton']")
    public static WebElement acceptButton;

    @FindBy(how = How.CSS, using = "button[id='previewButton']")
    public static WebElement previewButton;

    @FindBy(how = How.CSS, using = "button[id='confirmButton']")
    public static WebElement confirmButton;

    @FindBy(how = How.CSS, using = "button[class='buttonlink changeButton']")
    public static WebElement changeButton;

    public static void clickChangeButton() {
        changeButton.click();
        staticLogger.info("Clicked to make additional changes");
    }

    public static void checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
        staticLogger.info("I Acknowledge checked");
    }

    public static void clickNextBtn() {
        nextButton.click();
        staticLogger.info("Clicked Next button");
    }

    public static void clickAgreeToUseEsignBtn()
    {
        acceptButton.click();
        staticLogger.info("Clicked agree to use esign button");
    }

    public static void clickPreviewBtn() {
        previewButton.click();
        staticLogger.info("Clicked preview button");
    }

    public static void clickConfirmBtn() {
        confirmButton.click();
        staticLogger.info("Clicked confirm button");
    }

    protected static final Logger staticLogger = LoggerFactory.getLogger(Section3.class);

    public static class SectionA {
        static {
            PageFactory.initElements(Driver.getDriver(), SectionA.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-I9s3_1_1']")
        public static WebElement firstNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s3_1NA']")
        public static WebElement firstNameCheckBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_1_1-err']")
        public static WebElement firstNameErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s3_3_1']")
        public static WebElement middleNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s3_3NA']")
        public static WebElement middleNameCheckBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_3_1-err']")
        public static WebElement middleNameErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s3_2_1']")
        public static WebElement lastNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s3_2NA']")
        public static WebElement lastNameCheckBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_2_1-err']")
        public static WebElement lastNameErr;

        public static void setFirstName(String name) {
            SeleniumTest.clearAndSetText(firstNameTextBox, name, true);
        }

        public static String getFirstNameError() {
            return SectionA.firstNameErr.getText();
        }

        public static void setMiddleName(String name) {
            SeleniumTest.clearAndSetText(middleNameTextBox, name, true);
        }

        public static String getMiddleNameError() {
            return SectionA.middleNameErr.getText();
        }

        public static void setLastName(String name) {
            SeleniumTest.clearAndSetText(lastNameTextBox, name, true);
        }

        public static String getLastNameError() {
            return SectionA.lastNameErr.getText();
        }

        public static void setFirstNameCheckBox() { SeleniumTest.check(firstNameCheckBox);}

        public static void setMiddleNameCheckBox() { SeleniumTest.check(middleNameCheckBox);}

        public static void setLastNameCheckBox() { SeleniumTest.check(lastNameCheckBox);}
    }

    public static class SectionB {
        static {
            PageFactory.initElements(Driver.getDriver(), SectionB.class);
        }

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_4']")
        public static WebElement rehireDateSpan;
    }

    public static class SectionC {

        static {
            PageFactory.initElements(Driver.getDriver(), SectionC.class);
        }

        @FindBy(how = How.CSS, using = "select[id$='-17231_1']")
        public static WebElement ListDocumentDropDown;

        public static class Document {

            public enum ListDocument implements DocumentLocation {

                USPASSPORT("-I9s3_13", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                USPASSPORTCARD("-I9s3_13", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                PERMANENTRESIDENTCARD("-I9s3_14", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                ALIENREGISTRATIONRECEIPTCARD("-I9s3_14", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                FOREIGNPASSPORTWITHI_551STAMP("-I9s3_14", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                FOREIGNPASSPORTWITHI_551MRIV("-I9s3_14", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                EMPLOYMENTAUTHORIZATIONDOCUMENT("-I9s3_14", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                FOREIGNPASSPORTWITHI_94_AFORM("-I9s3_15", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                FSMPASSPORTWITHI_94_AFORM("-I9s3_15", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                RMIPASSPORTWITHI_94_AFORM("-I9s3_15", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                I_94_AFORMWITHI_551STAMP("-I9s3_15", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                I_94_AFORMWITHREFUGEESTAMP("-I9s3_15", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                I_20("-I9s3_16", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                DS_2019("-I9s3_16", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                SSACCOUNTNUMBERCARD("-I9s3_17", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                BIRTHABROADCERTIFICATEFS_545("-I9s3_18", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                BIRTHABROADCERTIFICATEDS_1350("-I9s3_18", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                BIRTHCERTIFICATEWITHSEAL("-I9s3_18", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                NATIVEAMERICANTRIBALDOCUMENT("-I9s3_18", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                USCITIZENIDCARD("-I9s3_18", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                RESIDENTCITIZENIDCARD("-I9s3_18", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22"),
                DHSEMPLOYMENTAUTHORIZATIONDOCUMENT("-I9s3_18", "-I9s3_19", "-I9s3_13", "-I9s3_24", "-I9s3_22");

                private String documentNumberId;
                private String expirationId;
                private String expirationNaId;
                private String richformDocNumberId;
                private String richformDocExpId;
                private String richformDocTitleId;

                ListDocument(
                        String documentNumberId,
                        String expirationId,
                        String richformDocNumberId,
                        String richformDocExpId,
                        String richformDocTitleId
                        ) {
                    this.documentNumberId = documentNumberId;
                    this.expirationId = expirationId;
                    this.expirationNaId = expirationId.concat("NA");
                    this.richformDocNumberId = richformDocNumberId;
                    this.richformDocExpId = richformDocExpId;
                    this.richformDocTitleId = richformDocTitleId;
                }

                @Override
                public String getDocumentNumberId() {
                    return this.documentNumberId;
                }

                @Override
                public String getExpirationId() {
                    return this.expirationId;
                }

                @Override
                public String getExpirationNaId() {
                    return this.expirationNaId;
                }

                public String getReceiptId() {
                    return "";
                }

                public String getIssuingAuthorityId() {
                    return "";
                }

                public String getValue() {
                    return "";
                }

                @Override
                public String getRichformDocTitle() { return this.richformDocTitleId; }

                @Override
                public String getRichformDocExpDate() { return this.richformDocExpId; }

                @Override
                public String getRichformDocNumber() { return this.richformDocNumberId; }
            }

            /**
             * U.S. Passport
             * U.S. Passport Card
             */
            public static final String DOC_US_PASSPORT_REQUIRED = "Passport Number cannot be empty";
            public static final String DOC_US_PASSPORT_FORMAT = "Passport Number must be 9 digits or a 'C' followed by 8 digits.";

            /**
             * Permanent Resident Card (I-551)
             * Alien Registration Receipt Card (Form I-551)
             * Foreign Passport containing a temp. I-551 Stamp
             * Foreign Passport containing a temp. I-551 MRIV
             * Employment Authorization Document (Form I-766)
             */
            public static final String DOC_I551_REQUIRED = "Document Number is required";
            public static final String DOC_I551_FORMAT = "Document Number must be 3 uppercase alphabetic characters followed by 10 digits (0-9).";
            public static final String DOC_I551_MRIV_FORMAT = "Document Number may be 1 uppercase alphabetic character followed by 7 digits (0-9) or 8 digits (0-9).";
         //   public static final String DOC_I551_FORMAT_STAMP ="Document Number must be 6-12 uppercase alphanumeric characters.";
         public static final String DOC_I551_FORMAT_STAMP = "Document Number must be 3 uppercase alphabetic characters followed by 10 digits (0-9).";
            /**
             * Foreign Passport with Form I-94/I-94A containing an endorsement of the alien's nonimmigrant status
             * Passport from the Federated States of Micronesia (FSM) with Form I-94/I-94A
             * Passport from the Republic of the Marshall Islands (RMI) with Form I-94/I-94A
             * Receipt: The arrival portion of Form I-94/I-94A containing a temp. I-551 stamp and photo
             * Receipt: Departure portion of a Form I-94/A with an unexpired refugee admission stamp or admission class of "RE”
             */
            public static final String DOC_I94_REQUIRED = "I-94/A Number cannot be empty";
            public static final String DOC_I94_FORMAT = "Must be 11 characters. All numeric, -OR- 9 digits, followed by a letter, followed by a digit.";
          //  public static final String DOC_I94_FORMAT ="Must be 11 characters. All numeric, -OR- 9 digits, followed by a letter, followed by a digit.";
            /**
             * I-20
             * DS-2019
             */
            public static final String DOC_I20_DS2019_REQUIRED = "Document number cannot be empty";
            public static final String DOC_I20_DS2019_FORMAT = "Document number must begin with an 'N' followed by 10 digits";

            /**
             * Social Security Card without restrictions
             */
            public static final String DOC_SOC_SEC_CARD_REQUIRED = "SSN cannot be empty";
            public static final String DOC_SOC_SEC_CARD_FORMAT = "Social Security Card Number must be 9 digits";


            /**
             * Certification of Birth Abroad (Form FS-545)
             * Certification of Report of Birth (Form DS-1350)
             * Original or certified copy of U.S. birth certificate bearing an official seal
             * Native American Tribal Document
             * U.S. Citizen ID Card (Form I-197)
             * Resident Citizen ID Card (Form I-179)
             * Employment Auth. Document (DHS) List C #8
             */
            public static final String OTHER_LIST_C_DOCS_REQUIRED = "Document Number is required";

            public static final String OTHER_LIST_C_DOCS_NOT_EMPTY = "Document Number cannot be empty";

            public static final String EXP_DATE_REQUIRED = "Expiration Date cannot be empty";

            public enum DocumentType {
                USPASSPORT(
                        "U.S. Passport",
                        "USPASSPORT",
                        "-I9s3_13",
                        "-I9s3_13-err",
                        Document.DOC_US_PASSPORT_FORMAT,
                        Document.DOC_US_PASSPORT_REQUIRED,
                        true,
                        true
                ),
                USPASSPORTCARD(
                        "U.S. Passport Card",
                        "USPASSPORTCARD",
                        "-I9s3_13",
                        "-I9s3_13-err",
                        Document.DOC_US_PASSPORT_FORMAT,
                        Document.DOC_US_PASSPORT_REQUIRED,
                        true,
                        true
                ),
                PERMANENTRESIDENTCARD(
                        "Permanent Resident Card (I-551)",
                        "PERMANENTRESIDENTCARD",
                        "-I9s3_14_OTHER",
                        "-I9s3_14_OTHER-err",
                        Document.DOC_I551_FORMAT,
                        Document.DOC_I551_REQUIRED,
                        true,
                        false
                ),
                ALIENREGISTRATIONRECEIPTCARD(
                        "Alien Registration Receipt Card (Form I-551)",
                        "ALIENREGISTRATIONRECEIPTCARD",
                        "-I9s3_14_OTHER",
                        "-I9s3_14_OTHER-err",
                        Document.DOC_I551_FORMAT,
                        Document.DOC_I551_REQUIRED,
                        true,
                        false
                ),
                FOREIGNPASSPORTWITH_I551STAMP(
                        "Foreign Passport containing a temp. I-551 Stamp",
                        "FOREIGNPASSPORTWITHI-551STAMP",
                        "-I9s3_14_OTHER",
                        "-I9s3_14_OTHER-err",
                        Document.DOC_I551_FORMAT_STAMP,
                        Document.DOC_I551_REQUIRED,
                        true,
                        false
                ),
                FOREIGNPASSPORTWITH_I551MRIV(
                        "Foreign Passport containing a temp. I-551 MRIV",
                        "FOREIGNPASSPORTWITHI-551MRIV",
                        "-I9s3_14_MRIV",
                        "-I9s3_14_MRIV-err",
                        Document.DOC_I551_MRIV_FORMAT,
                        Document.DOC_I551_REQUIRED,
                        true,
                        false
                ),
                EMPLOYMENTAUTHORIZATIONDOCUMENT(
                        "Employment Authorization Document (Form I-766)",
                        "EMPLOYMENTAUTHORIZATIONDOCUMENT",
                        "-I9s3_14_OTHER",
                        "-I9s3_14_OTHER-err",
                        Document.DOC_I551_FORMAT,
                        Document.DOC_I551_REQUIRED,
                        true,
                        false
                ),
                FOREIGNPASSPORTWITH_I94AFORM(
                        "Foreign Passport with Form I-94/I-94A containing an endorsement of the alien's nonimmigrant status",
                        "FOREIGNPASSPORTWITHI-94/AFORM",
                        "-I9s3_15",
                        "-I9s3_15-err",
                        Document.DOC_I94_FORMAT,
                        Document.DOC_I94_REQUIRED,
                        true,
                        false
                ),
                FSMPASSPORTWITH_I94AFORM(
                        "Passport from the Federated States of Micronesia (FSM) with Form I-94/I-94A",
                        "FSMPASSPORTWITHI-94/AFORM",
                        "-I9s3_15",
                        "-I9s3_15-err",
                        Document.DOC_I94_FORMAT,
                        Document.DOC_I94_REQUIRED,
                        true,
                        false
                ),
                RMIPASSPORTWITH_I94AFORM(
                        "Passport from the Republic of the Marshall Islands (RMI) with Form I-94/I-94A",
                        "RMIPASSPORTWITHI-94/AFORM",
                        "-I9s3_15",
                        "-I9s3_15-err",
                        Document.DOC_I94_FORMAT,
                        Document.DOC_I94_REQUIRED,
                        true,
                        false
                ),
                I94_AFORMWITH_I551STAMP(
                        "Receipt: The arrival portion of Form I-94/I-94A containing a temp. I-551 stamp and photo",
                        "I-94/AFORMWITHI-551STAMP",
                        "-I9s3_15",
                        "-I9s3_15-err",
                        Document.DOC_I94_FORMAT,
                        Document.DOC_I94_REQUIRED,
                        true,
                        false
                ),
                I94_AFORMWITHREFUGEESTAMP(
                        "Receipt: Departure portion of a Form I-94/A with an unexpired refugee admission stamp or admission class of \"RE\"",
                        "I-94/AFORMWITHREFUGEESTAMP",
                        "-I9s3_15",
                        "-I9s3_15-err",
                        Document.DOC_I94_FORMAT,
                        Document.DOC_I94_REQUIRED,
                        true,
                        false
                ),
                I20(
                        "I-20",
                        "I-20",
                        "-I9s3_16",
                        "-I9s3_16-err",
                        Document.DOC_I20_DS2019_FORMAT,
                        Document.DOC_I20_DS2019_REQUIRED,
                        true,
                        false
                ),
                DS2019(
                        "DS-2019",
                        "DS-2019",
                        "-I9s3_16",
                        "-I9s3_16-err",
                        Document.DOC_I20_DS2019_FORMAT,
                        Document.DOC_I20_DS2019_REQUIRED,
                        true,
                        false
                ),
                SSACCOUNTNUMBERCARD(
                        "Social Security Card without restrictions",
                        "SSACCOUNTNUMBERCARD",
                        "-I9s3_17",
                        "-I9s3_17-err",
                        Document.DOC_SOC_SEC_CARD_FORMAT,
                        Document.DOC_SOC_SEC_CARD_REQUIRED,
                        false,
                        false
                ),
                BIRTHABROADCERTIFICATE_FS_545(
                        "Certification of Birth Abroad (Form FS-545)",
                        "BIRTHABROADCERTIFICATEFS-545",
                        "-I9s3_18",
                        "-I9s3_18-err",
                        "", // EMPTY ON PURPOSE
                        Document.OTHER_LIST_C_DOCS_REQUIRED,
                        false,
                        false
                ),
                BIRTHABROADCERTIFICATE_DS_1350(
                        "Certification of Report of Birth (Form DS-1350)",
                        "BIRTHABROADCERTIFICATEDS-1350",
                        "-I9s3_18",
                        "-I9s3_18-err",
                        "", // EMPTY ON PURPOSE
                        Document.OTHER_LIST_C_DOCS_REQUIRED,
                        false,
                        false
                ),
                BIRTHCERTIFICATEWITHSEAL(
                        "Original or certified copy of U.S. birth certificate bearing an official seal",
                        "BIRTHCERTIFICATEWITHSEAL",
                        "-I9s3_18",
                        "-I9s3_18-err",
                        "", // EMPTY ON PURPOSE
                        Document.OTHER_LIST_C_DOCS_REQUIRED,
                        false,
                        false
                ),
                NATIVEAMERICANTRIBALDOCUMENT(
                        "Native American Tribal Document",
                        "NATIVEAMERICANTRIBALDOCUMENT",
                        "-I9s3_18",
                        "-I9s3_18-err",
                        "", // EMPTY ON PURPOSE
                        Document.OTHER_LIST_C_DOCS_REQUIRED,
                        false,
                        false
                ),
                USCITIZENIDCARD(
                        "U.S. Citizen ID Card (Form I-197)",
                        "USCITIZENIDCARD",
                        "-I9s3_18",
                        "-I9s3_18-err",
                        "", // EMPTY ON PURPOSE
                        Document.OTHER_LIST_C_DOCS_REQUIRED,
                        false,
                        false
                ),
                RESIDENTCITIZENIDCARD(
                        "Resident Citizen ID Card (Form I-179)",
                        "RESIDENTCITIZENIDCARD",
                        "-I9s3_18",
                        "-I9s3_18-err",
                        "", // EMPTY ON PURPOSE
                        Document.OTHER_LIST_C_DOCS_NOT_EMPTY,
                        false,
                        false
                ),
                DHSEMPLOYMENTAUTHORIZATIONDOCUMENT(
                        "Employment Auth. Document (DHS) List C #7",
                        "DHSEMPLOYMENTAUTHORIZATIONDOCUMENT",
                        "-I9s3_18",
                        "-I9s3_18-err",
                        "", // EMPTY ON PURPOSE
                        Document.OTHER_LIST_C_DOCS_NOT_EMPTY,
                        false,
                        false
                );

                private final String name;
                private final String value;
                private final String inputId;
                private final String errorId;
                private final String requiredErr;
                private final String formatErr;
                private final boolean hasExpDate;
                private final boolean hasAttachment;

                DocumentType(final String name, final String value, final String inputId, final String errorId, final String formatErrMsg, final String requiredErrMsg, final boolean hasExpDate, final boolean hasAttachment) {
                    this.name = name;
                    this.value = value;
                    this.inputId = inputId;
                    this.errorId = errorId;
                    this.formatErr = formatErrMsg;
                    this.requiredErr = requiredErrMsg;
                    this.hasExpDate = hasExpDate;
                    this.hasAttachment = hasAttachment;
                }

                public String getName() {
                    return this.name;
                }

                public String getRequiredErr() {
                    return this.requiredErr;
                }

                public String getFormatErr() {
                    return this.formatErr;
                }

                public boolean isHasExpDate() {
                    return this.hasExpDate;
                }

                public boolean isHasDocAttachment() {
                    return this.hasAttachment;
                }
            }

            public static String getDocNumberError(DocumentType doc) {
                WebElement ele = Driver.getDriver()
                        .findElement(By.cssSelector("div[id$='" + doc.errorId + "']"));
                return ele.getText();
            }

            public static String getName(DocumentType doc) {
                return doc.name;
            }

            public static String getRequiredErrMsg(DocumentType doc) {
                return doc.requiredErr;
            }

            public static String getFormatErrMsg(DocumentType doc) {
                return doc.formatErr;
            }

            public static void fillDocNumber(DocumentType doc, String inputValue) {
                WebElement ele = Driver.getDriver()
                        .findElement(By.cssSelector("input[id$='" + doc.inputId + "']"));
                WaitUntil.waitUntil(()->ele.isDisplayed());
                SeleniumTest.clearAndSetText(ele, inputValue, true);
            }

            public static void SelectDocumentType(DocumentType doc) {
                SeleniumTest.selectByValueFromDropDown(listACDocumentDropDown, doc.value);
                staticLogger.info("List A/C Document Selected {}", doc.value);
            }
        }

        static {
            PageFactory.initElements(Driver.getDriver(), SectionC.class);
        }

        /**
         * All documents - Doc Number, Doc Type, and Doc Exp
         * Attach Document
         */
        @FindBy(how = How.CSS, using = "div[id$='-17231_1-err']")
        public static WebElement documentTitleErr;

        public static String getDocumentTitleError() {
            return documentTitleErr.getText();
        }

        @FindBy(how = How.CSS, using = "select[id$='-17231_1']")
        private static WebElement listACDocumentDropDown;

        /**
         * Documents in Section 3 are share their WebElements
         */

        /**
         * U.S. Passport
         * U.S. Passport Card
         */
        @FindBy(how = How.CSS, using = "input[id$='-I9s3_13']")
        public static WebElement usPassportAndCardNumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_13-err']")
        public static WebElement usPassportAndCardNumberErr;

        public static void setUsPassportAndCardNumber(String docNumber) {
            SeleniumTest.clearAndSetText(usPassportAndCardNumberTextBox, docNumber, true);
        }

        public static String getUsPassportAndCardNumber() {
            return usPassportAndCardNumberTextBox.getText();
        }

        public static String getUsPassportAndCardError() {
            return usPassportAndCardNumberErr.getText();
        }

        /**
         * Permanent Resident Card (I-551)
         * Alien Registration Receipt Card (Form I-551)
         * Foreign Passport containing a temp. I-551 Stamp
         * Foreign Passport containing a temp. I-551 MRIV
         * Employment Authorization Document (Form I-766)
         */
        @FindBy(how = How.CSS, using = "input[id$='-I9s3_14']")
        public static WebElement i551AndI766NumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_14-err']")
        public static WebElement i551AndI766NumberErr;

        public static void seti551AndI766Number(String docNumber) {
            SeleniumTest.clearAndSetText(i551AndI766NumberTextBox, docNumber, true);
        }

        public static String geti551AndI766Number() {
            return i551AndI766NumberTextBox.getText();
        }

        public static String geti551AndI766NumberError() {
            return i551AndI766NumberErr.getText();
        }

        /**
         * Foreign Passport with Form I-94/I-94A containing an endorsement of the alien's nonimmigrant status
         * Passport from the Federated States of Micronesia (FSM) with Form I-94/I-94A
         * Passport from the Republic of the Marshall Islands (RMI) with Form I-94/I-94A
         * Receipt: The arrival portion of Form I-94/I-94A containing a temp. I-551 stamp and photo
         * Receipt: Departure portion of a Form I-94/A with an unexpired refugee admission stamp or admission class of "RE”
         */
        @FindBy(how = How.CSS, using = "input[id$='-I9s3_15']")
        public static WebElement i94NumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_15-err']")
        public static WebElement i94NumberErr;

        public static void setI94Number(String docNumber) {
            SeleniumTest.clearAndSetText(i94NumberTextBox, docNumber, true);
        }

        public static String getI94Number() {
            return i94NumberTextBox.getText();
        }

        public static String getI94NumberError() {
            return i94NumberErr.getText();
        }

        /**
         * I-20
         * DS-2019
         */
        @FindBy(how = How.CSS, using = "input[id$='-I9s3_16']")
        public static WebElement i20AndDs2019NumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_16-err']")
        public static WebElement i20AndDs2019NumberErr;

        public static void setI20AndDs2019Number(String docNumber) {
            SeleniumTest.clearAndSetText(i20AndDs2019NumberTextBox, docNumber, true);
        }

        public static String getI20AndDs2019Number() {
            return i20AndDs2019NumberTextBox.getText();
        }

        public static String getI20AndDs2019NumberError() {
            return i20AndDs2019NumberErr.getText();
        }

        /**
         * Social Security Card without restrictions
         */
        @FindBy(how = How.CSS, using = "input[id$='-I9s3_17']")
        public static WebElement socialSecCardNumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_17-err']")
        public static WebElement socialSecCardNumberErr;

        public static void setSocialSecCardNumber(String docNumber) {
            SeleniumTest.clearAndSetText(socialSecCardNumberTextBox, docNumber, true);
        }

        public static String getSocialSecCardNumber() {
            return socialSecCardNumberTextBox.getText();
        }

        public static String getSocialSecCardNumberError() {
            return socialSecCardNumberErr.getText();
        }

        /**
         * Certification of Birth Abroad (Form FS-545)
         * Certification of Report of Birth (Form DS-1350)
         * Original or certified copy of U.S. birth certificate bearing an official seal
         * Native American Tribal Document
         * U.S. Citizen ID Card (Form I-197)
         * Resident Citizen ID Card (Form I-179)
         * Employment Auth. Document (DHS) List C #8
         */
        @FindBy(how = How.CSS, using = "input[id$='-I9s3_18']")
        public static WebElement otherListCDocNumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_18-err']")
        public static WebElement otherListCDocNumberErr;

        public static void setOtherListCDocNumber(String docNumber) {
            SeleniumTest.clearAndSetText(otherListCDocNumberTextBox, docNumber, true);
        }

        public static String getOtherListCDocNumber() {
            return otherListCDocNumberTextBox.getText();
        }

        public static String getOtherListCDocNumberError() {
            return otherListCDocNumberErr.getText();
        }

        /**
         * All Documents above share the same expiration date field
         */
        @FindBy(how = How.XPATH, using = "//input[contains(@id,'-I9s3_19')][@type='text']")
        public static WebElement expirationDateVisibleBox;

        @FindBy(how = How.XPATH, using = "//input[contains(@id,'-I9s3_19')][@type='hidden']")
        public static WebElement expirationDateHiddenBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_19-err']")
        public static WebElement expirationDateErr;

        public static void setExpirationDate(LocalDate expirationDate) {

            SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                expirationDate, expirationDateVisibleBox.getAttribute("id"),
                expirationDateHiddenBox.getAttribute("id"));
        }

        public static String getExpirationDate() {
            return expirationDateVisibleBox.getText();
        }

        public static String getExpirationDateError() {
            return expirationDateErr.getText();
        }

        /**
         * Receipt Number + Receipt Expiration Date fields are used by all document types
         */
        @FindBy(how = How.CSS, using = "div[id$='-I9s3_23']")
        public static WebElement receiptDocNumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_23-err']")
        public static WebElement receiptDocNumberErr;

        public static void setReceiptDocNumber(String docNumber) {
            SeleniumTest.clearAndSetText(receiptDocNumberTextBox, docNumber, true);
        }

        public static String getReceiptDocNumber() {
            return receiptDocNumberTextBox.getText();
        }

        public static String getReceiptDocNumberError() {
            return receiptDocNumberErr.getText();
        }

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_24']")
        public static WebElement receiptExpirationDateTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_24-err']")
        public static WebElement receiptExpirationDateErr;

        public static void setReceiptExpDate(String expDate) {
            SeleniumTest.clearAndSetText(receiptExpirationDateTextBox, expDate, true);
        }

        public static String getReceiptExpDate() {
            return receiptExpirationDateTextBox.getText();
        }

        public static String getReceiptExpDateError() {
            return receiptExpirationDateErr.getText();
        }

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_222-filebrowse']")
        public static WebElement attachmentErr;

        public static String getAttachmentError() { return attachmentErr.getText(); }
    }

    public static class AdditionalInformation {

        @FindBy(how = How.XPATH, using = "//textarea[@id='17231-I9s3_60']")
        private static WebElement additionalInformationTextArea;

        static {
            PageFactory.initElements(Driver.getDriver(), AdditionalInformation.class);
        }

        public static String getAdditionalInformation() {
            return additionalInformationTextArea.getAttribute("value");
        }

        public static void setAdditionalInformation(String text) {
            SeleniumTest.clearAndSetText(additionalInformationTextArea, text);
        }

    }

    public static class Acknowledgement {

        static {
            PageFactory.initElements(Driver.getDriver(), Acknowledgement.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-I9s3_52']")
        public static WebElement iAcknowledgeCheckBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_52-err']")
        public static WebElement iAcknowledgeErr;

        @FindBy(how = How.CSS, using = "label[for$='-I9s3_52']")
        private static WebElement iAcknowledgeCheckBoxLabel;

        public static void checkIAcknowledge() {
            SeleniumTest.check(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
            staticLogger.info("I Acknowledge checked");
        }

        public static void uncheckIAcknowledge() {
            SeleniumTest.unCheck(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
            staticLogger.info("I Acknowledge unchecked");
        }

        public static String getIAcknowledgeError() {
            return iAcknowledgeErr.getText();
        }
    }

    public static class Richform {
        static {
            PageFactory.initElements(Driver.getDriver(), Richform.class);
        }

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_2'] span")
        public static WebElement lastName;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_1'] span")
        public static WebElement firstName;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_3'] span")
        public static WebElement middleInitial;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_4'] span")
        public static WebElement rehireDate;

        @FindBy(how = How.CSS, using = "span[id$='-I9s3_12']")
        public static WebElement authorizedRepresentative;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_9'] div")
        public static WebElement dateSigned;

        @FindBy(how = How.CSS, using = "div[id$='-I9s3_8'] div div div img")
        public static WebElement signature;

        public static String getDocumentNumber(WorkEligibilityDocument document) {
            WebElement richformDocEle = getRichFormWebElement(document.getDocLocation().getRichformDocNumber());
            return richformDocEle.getText();
        }

        public static String getDocumentExpDate(WorkEligibilityDocument document) {
            WebElement richformDocEle = getRichFormWebElement(document.getDocLocation().getRichformDocExpDate());
            return richformDocEle.getText();
        }

        public static String getDocumentTitle(WorkEligibilityDocument document) {
            WebElement richformDocEle = getRichFormWebElement(document.getDocLocation().getRichformDocTitle());
            return richformDocEle.getText();
        }

        public static WebElement getRichFormWebElement(String eleId) {
            return Driver.getDriver().findElement(
                    By.cssSelector("div[id$='" + eleId + "'] span"));
        }

        public static boolean checkDocNumber(WorkEligibilityDocument doc) {
            String docNumber = getDocumentNumber(doc);
            return docNumber.equals(doc.getDocNumber());
        }

        public static boolean checkDocExpDate(WorkEligibilityDocument doc) {
            String documentExpDate = getDocumentExpDate(doc);
            if (!doc.isHasExpDate()) {
                return documentExpDate.equals("N/A");
            }
            return documentExpDate.equals(doc.getExpDateStr());
        }

        public static boolean checkDocTitle(WorkEligibilityDocument doc) {
            String docTitle = getDocumentTitle(doc);
            Object richformTitle = RichFormTitle.RichFormTitleMap.get(doc.getTitle());
            staticLogger.info("Doc Title ({}) : RichForm ({})", docTitle, richformTitle.toString());
            return docTitle.equals(richformTitle);
        }

        public static boolean checkName(Candidate candidate) {
            boolean returnValue = true;
            returnValue &= Richform.firstName.getText().equals(candidate.getFirstName());
            returnValue &= Richform.lastName.getText().equals(candidate.getLastName());
            returnValue &= Richform.middleInitial.getText().equals(candidate.getMiddleNameInitial());
            return returnValue;
        }

        public static boolean checkStartDate(Candidate candidate) {
            return Richform.rehireDate.getText().equals(candidate.getStartDateStr(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        }

        public static boolean checkSignature() {
            return Richform.signature.isDisplayed();
        }

        public static boolean checkAuthorizedRep(String name) {
            return Richform.authorizedRepresentative.getText().equals(name);
        }
    }

    public static class RichFormTitle {

        public static Map RichFormTitleMap = RichFormTitle.createMapDocTitles();

        public static Map<String, String> createMapDocTitles() {
            Map<String, String> result = new HashMap<String, String>();
            result.put("U.S. Passport",    "U.S. Passport");
            result.put("U.S. Passport Card",    "U.S. Passport Card");
            result.put("Permanent Resident Card (I-551)",    "Perm. Resident Card (Form I-551)");
            result.put("Alien Registration Receipt Card (Form I-551)",
                       "Alien Reg. Receipt Card (Form I-551)");
            result.put("Foreign Passport containing a temp. I-551 Stamp",    "Foreign Passport");
            result.put("Foreign Passport containing a temp. I-551 MRIV",    "Foreign Passport with Temp. I-551 MRIV");
            result.put("Employment Authorization Document (Form I-766)",    "Employment Auth. Document (Form I-766)");
            result.put("Foreign Passport with Form I-94/I-94A containing an endorsement of the alien's nonimmigrant status",    "Foreign Passport, work-authorized non- immigrant");
            result.put("Passport from the Federated States of Micronesia (FSM) with Form I-94/I-94A",    "FSM Passport with Form I-94");
            result.put("Passport from the Republic of the Marshall Islands (RMI) with Form I-94/I-94A",    "RMI Passport with Form I-94");
            result.put("Receipt: The arrival portion of Form I-94/I-94A containing a temp. I-551 stamp and photo",    "Receipt: Form I-94/I-94A w/I-551 stamp, photo");
            result.put("Receipt: Departure portion of a Form I-94/A with an unexpired refugee admission stamp or admission class of \"RE\"",    "Form I-94/I-94A w/refugee stamp");
            result.put("I-20",    "Form I-20");
            result.put("DS-2019",    "Form DS-2019");
            result.put("Social Security Card without restrictions",    "Social Security Card (Unrestricted)");
            result.put("Certification of Birth Abroad (Form FS-545)",    "Form FS-545");
            result.put("Certification of Report of Birth (Form DS-1350)",    "Form DS-1350");
            result.put("Original or certified copy of U.S. birth certificate bearing an official seal",    "Birth Certificate");
            result.put("Native American Tribal Document",    "Native American tribal document");
            result.put("U.S. Citizen ID Card (Form I-197)",    "Form I-197");
            result.put("Resident Citizen ID Card (Form I-179)",    "Form I-179");
            result.put("Employment Auth. Document (DHS) List C #8",    "Employment Auth. document (DHS) List C #8");
            return Collections.unmodifiableMap(result);
        }
    }

}
