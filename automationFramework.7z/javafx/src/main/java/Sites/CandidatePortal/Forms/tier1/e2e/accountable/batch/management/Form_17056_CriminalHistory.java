package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.Objects.I9.Section2;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Form_17056_CriminalHistory extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='17056-17056_2_Yes']")
    private WebElement guiltyCrimeYesRadioLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='17056-17056_2_No']")
    private WebElement guiltyCrimeNoRadioLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='17056-17056_24']")
    private WebElement iCertifyCheckboxLabel;

    @FindBy(how = How.ID, using = "17056-17056_24")
    private WebElement iCertifyCheckbox;

    @FindBy(how = How.ID, using = "17056-17056_4")
    private WebElement natureOfOffensesTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='17056-17056_5_Misdemeanor']")
    private WebElement misdemeanorRadioLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='17056-17056_5_Felony']")
    private WebElement felonyRadioLabel;

    @FindBy(how = How.ID, using = "17056-17056_6")
    private WebElement applicablePleaDatesTextbox;

    @FindBy(how = How.ID, using = "17056-17056_7")
    private WebElement countiesTextbox;

    @FindBy(how = How.ID, using = "17056-17056_8")
    private WebElement statesTextbox;

    @FindBy(how = How.ID, using = "17056-17056_19")
    private WebElement additionalDetailsTextbox;

    public static Form_17056_CriminalHistory getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_17056_CriminalHistory.class);
    }

    public void chooseGuiltyOfCrimeYesRadio() {
        guiltyCrimeYesRadioLabel.click();
        staticLogger.info("Guilty of Crime Yes Radio Button chosen");
    }

    public void chooseGuiltyOfCrimeNoRadio() {
        guiltyCrimeNoRadioLabel.click();
        staticLogger.info("Guilty of Crime No Radio Button chosen");
    }

    public void checkICertify() {
        SeleniumTest.check(iCertifyCheckboxLabel, iCertifyCheckbox);
        staticLogger.info("I Certify Checked");
    }

    public void uncheckICertify() {
        SeleniumTest.unCheck(iCertifyCheckboxLabel, iCertifyCheckbox);
        staticLogger.info("I Certify Unchecked");
    }

    public String getNatureOfOffensesText() {
        return natureOfOffensesTextbox.getText();
    }

    public void setNatureOfOffensesTextbox(String text) {
        SeleniumTest.clearAndSetText(natureOfOffensesTextbox, text);
        staticLogger.info("Nature of Offense set to {}", text);
    }

    public static class UploadDocuments {

        @FindBy(how = How.CSS, using = "input[id$='-filebrowse']")
        public static WebElement chooseFileButton;

        @FindBy(how = How.CLASS_NAME, using = "btnPostFileToServer")
        public static WebElement uploadFileButton;

        @FindBy(how = How.CSS, using = "div[id$='-err']")
        public static WebElement uploadFileErrorMessage;

        static {
            PageFactory.initElements(Driver.getDriver(), Section2.UploadDocuments.class);
        }

        public static void setFileToUpload(String filePath) {
            staticLogger.info("File path : " + filePath);
            if (OS.isFamilyWindows()) {
                filePath = filePath.startsWith("/") ? filePath.substring(1) : filePath;
            }
            ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" +
                    chooseFileButton
                            .getAttribute("id") +
                    "').style.visibility = "
                    + "'visible';");
            if (!filePath.startsWith("/") && !filePath.contains(":")) {
                filePath = "/" + filePath;
            }

            chooseFileButton.sendKeys(filePath);
            SeleniumTest.waitForElementToBeClickable(uploadFileButton, 60);
            staticLogger.info("File Upload Path set to {}", filePath);
        }

        public static void clickUploadFile() {
            uploadFileButton.click();
            staticLogger.info("Upload File Button Pressed");
            SeleniumTest
                    .waitForElementToBeClickable(By.xpath("//label[text()='Previously Uploaded:']"),
                            90);
            WaitUntil.waitUntil(90, 3, () -> Driver.getDriver()
                    .findElement(By.className("btnPostFileToServer")).getAttribute("disabled")
                    .equals("true"), NullPointerException.class);
            staticLogger.info("Upload File Button Action Complete");
        }

        /**
         * Returns the error text when a file is not attached.
         * @return
         */
        public String getUploadErrorText() {
            return uploadFileErrorMessage.getText();
        }
    }

}
