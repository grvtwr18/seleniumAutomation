package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by abrackett on 4/2/2016.
 */
public class FormID5077I9Section2 extends FormPage {
    public static final String FORMID_5077 = "5077-5077";
    public static final String FORMID_I9S2 = "5077-I9s2";
    public static final String ADDRESS_I9S2_47 = "5077-addressI9s2_47";
    public static final String PREVIOUSNEXTBUTTONS = "5077-previousnextbuttons-";
    public static final String ISSUING_AUTHORITY = "C12345678";
    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    public static final String EXPIRATION_DATE = "_9-I9s2_9";
    public static final String FOREIGN_COUNTRY = "CANADA";
    private static Logger logger = LoggerFactory.getLogger("FormID5077I9Section2");

    // List A Specific Elements
    @FindBy(how = How.XPATH, using = "//label[@for='" + FORMID_5077 + "_2_List A']")
    private static WebElement listARadiobutton;

    // List B & C Specific Elements
    @FindBy(how = How.XPATH, using = "//label[@for='" + FORMID_5077 + "_2_List B and C']")
    private static WebElement listBRadiobutton;

    @FindBy(how = How.ID, using = FORMID_5077 + "_26")
    private static WebElement listCDocument;

    @FindBy(how = How.XPATH, using = "//label[@for='" + FORMID_5077 + "_136']")
    private static WebElement receiptForCDocumentLabel;

    @FindBy(how = How.ID, using = FORMID_5077 + "_136")
    private static WebElement receiptForCDocumentCheckbox;


    @FindBy(how = How.ID, using = FORMID_I9S2 + "_38")
    private static WebElement receiptNumberDocumentC;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_27")
    private static WebElement issuingAuthorityDocumentC;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_28")
    private static WebElement documentNumberDocumentC;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_23")
    private static WebElement documentNumber;


    // List agnostic Elements
    @FindBy(how = How.ID, using = FORMID_5077 + "_4")
    private static WebElement listDocumentTitle;

    @FindBy(how = How.XPATH, using = "//label[@for='" + FORMID_5077 + "_135']")
    private static WebElement receiptCheckboxLabel;

    @FindBy(how = How.ID, using = FORMID_5077 + "_135")
    private static WebElement receiptCheckbox;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_32")
    private static WebElement receiptNumber;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_22")
    private static WebElement issuingAuthority;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_25-I9s2_25")
    private static WebElement expirationDate;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_56-I9s2_56")
    private static WebElement employeeStartDate;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_42")
    private static WebElement authorizedRepresentativeTitle;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_45")
    private static WebElement employerBusinessName;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_46")
    private static WebElement employerAddress1;


    @FindBy(how = How.ID, using = ADDRESS_I9S2_47 + "-I9s2_47")
    private static WebElement employerCity;

    @FindBy(how = How.ID, using = ADDRESS_I9S2_47 + "-I9s2B_44")
    private static WebElement employerCountry;

    @FindBy(how = How.ID, using = ADDRESS_I9S2_47 + "-I9s2_48")
    private static WebElement employerState;

    @FindBy(how = How.ID, using = ADDRESS_I9S2_47 + "-I9s2_49")
    private static WebElement employerZip;

    @FindBy(how = How.XPATH, using = "//label[@for='" + FORMID_I9S2 + "_52']")
    private static WebElement iAcknowledgeLabel;

    @FindBy(how = How.ID, using = FORMID_I9S2 + "_52")
    private static WebElement iAcknowledgeCheckbox;


    @FindBy(how = How.ID, using = PREVIOUSNEXTBUTTONS + "previousbutton")
    private static WebElement previousButton;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.ID, using = PREVIOUSNEXTBUTTONS + "savebutton")
    private static WebElement saveButton;

    private static final String filePathBoxLocatorString = "8468-310_3-filebrowse";
    By filePathBoxLocator = By.id(filePathBoxLocatorString);
    @FindBy(how = How.ID, using = filePathBoxLocatorString)
    private static WebElement filePathBox;

    private static final String filePathLocatorString = FORMID_5077 + "_1-filebrowse";
    By filePathLocator = By.id(filePathLocatorString);
    @FindBy(how = How.ID, using = filePathLocatorString)
    private static WebElement fileBox;

    @FindBy(how = How.CLASS_NAME, using = "btnPostFileToServer")
    private static WebElement uploadFileButton;


    public static void fillListADetails(Form_I9Pages.ListADocuments document, Boolean hasReceipt, LocalDate expires, LocalDate employeeStart) {
        listARadiobutton.click();
        SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, document.toString());
        if(hasReceipt) {
            SeleniumTest.check(receiptCheckboxLabel, receiptCheckbox);
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_31")), ISSUING_AUTHORITY);
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_32")), "R12345678");
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_33-I9s2_33")), expires.format(FORMATTER), true);
        }
        else {
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + EXPIRATION_DATE)), expires.format(FORMATTER), true);
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_2")), ISSUING_AUTHORITY);
            switch(document) {
                case USPASSPORT:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_3")), ISSUING_AUTHORITY);
                    break;
                case USPASSPORTCARD:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_3")), ISSUING_AUTHORITY);
                    break;
                case PERMANENTRESIDENTCARD:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_4")), ISSUING_AUTHORITY);
                    break;
                case ALIENREGISTRATIONRECEIPTCARD:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_5")), ISSUING_AUTHORITY);
                    break;
                case EMPLOYMENTAUTHORIZATIONDOCUMENT:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_7")), ISSUING_AUTHORITY);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_57")), FOREIGN_COUNTRY);
                    break;
                case I_94_AFORMWITHREFUGEESTAMP:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_8")), ISSUING_AUTHORITY);
                    break;
                default:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_6")), ISSUING_AUTHORITY);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_53")), FOREIGN_COUNTRY);
                    break;
            }
        }
        fillEmployerData(employeeStart);
    }

    public static void fillListBAndCDetails(Form_I9Pages.ListBDocuments bDocument, String bDocumentNumber, String issuingAuthority, Boolean bHasReceipt, LocalDate bExpires, Form_I9Pages.ListCDocuments cDocument, String cDocumentNumber, String cIssuingAuthority, Boolean cHasReceipt, LocalDate cExpires, LocalDate employeeStart) {
        logger.info("Select List B and C Radio Button");
        listBRadiobutton.click();
        logger.info("Select List B Document: {}", bDocument.toString());
        SeleniumTest.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By.id(FORMID_5077 + "_25")),bDocument.toString());

        if(bHasReceipt) {
            logger.info("Check Receipt for Document B Checkbox");
            SeleniumTest.check(receiptCheckboxLabel, receiptCheckbox);
            logger.info("Fill in Issuing Authority: {}", issuingAuthority);
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_34")), issuingAuthority);
            logger.info("Fill in Receipt Number: R12345678");
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_35")), "R12345678");
            logger.info("Fill in Receipt Expiration: {}", bExpires.format(FORMATTER));
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_36-I9s2_36")), bExpires.format(FORMATTER));
        }
        else {
            logger.info("Set Issuing Authority: {}", issuingAuthority);
            logger.info("Set Document number: {}", bDocumentNumber);
            logger.info("Set Document B Expiration Date: {}", bExpires.format(FORMATTER));
            switch(bDocument) {
                case USSTATEDRIVERSLICENSE:
                    SeleniumTest.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_20")), "License");
                    SeleniumTest.selectByValueFromDropDown(Driver.getDriver().findElement(By.id("5077-licenseI9s2_21-I9s2_21")), issuingAuthority);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id("5077-licenseI9s2_21-I9s2_24")), bDocumentNumber);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_25-I9s2_25")), bExpires.format(FORMATTER));
                    break;
                default:
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_22")), issuingAuthority);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_23")), bDocumentNumber);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_25-I9s2_25")), bExpires.format(FORMATTER));
                    break;
            }
        }

        logger.info("Select List C Document: {}", cDocument.toString());
        SeleniumTest.selectByVisibleTextFromDropDown(Driver.getDriver().findElement(By.id(FORMID_5077 + "_26")),cDocument.toString());

        if(cHasReceipt) {
            logger.info("Check Receipt for Document C Checkbox");
            SeleniumTest.check(receiptForCDocumentLabel, receiptForCDocumentCheckbox);
            logger.info("Fill in Issuing Authority: {}", cIssuingAuthority);
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_37")), cIssuingAuthority);
            logger.info("Fill in Receipt Number: R12345678");
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_38")), "R12345678");
            logger.info("Fill in Receipt Expiration: {}", cExpires.format(FORMATTER));
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_39-I9s2_39")), cExpires.format(FORMATTER));
        }
        else {
            logger.info("Fill in Issuing Authority: {}", cIssuingAuthority);
            SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_27")), cIssuingAuthority);
            switch(cDocument) {
                case SSACCOUNTNUMBERCARD:
                    logger.info("Set Document number: {}", cDocumentNumber);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id("5077-I9s1_11_2_1")), cDocumentNumber);
                    break;
                case RESIDENTCITIZENIDCARD:
                    logger.info("Set Document number: {}", cDocumentNumber);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_28")), cDocumentNumber);
                    logger.info("Set Document Expiration: {}", cExpires.format(FORMATTER));
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_30-I9s2_30")), cExpires.format(FORMATTER));
                    break;
                case DHSEMPLOYMENTAUTHORIZATIONDOCUMENT:
                    logger.info("Set Document number: {}", cDocumentNumber);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_28")), cDocumentNumber);
                    logger.info("Set Document Expiration: {}", cExpires.format(FORMATTER));
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_30-I9s2_30")), cExpires.format(FORMATTER));
                    break;
                default:
                    logger.info("Set Document number: {}", cDocumentNumber);
                    SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(FORMID_I9S2 + "_28")), cDocumentNumber);
                    break;
            }
        }
        fillEmployerData(employeeStart);
    }

    /**
     * Fills in all Employer Information in Section 2
     * @param employeeStart Employee Start Date
     */
    public static void fillEmployerData(LocalDate employeeStart) {
        logger.info("Fill in all Employer Data");
        SeleniumTest.clearAndSetText(employeeStartDate, employeeStart.format(FORMATTER), true);
        SeleniumTest.clearAndSetText(authorizedRepresentativeTitle, "Title of Authorized Representative");
        SeleniumTest.clearAndSetText(employerBusinessName, "Employer Business Name");
        SeleniumTest.clearAndSetText(employerAddress1, "1 First Street");
        SeleniumTest.clearAndSetText(employerCity, "Redmond");
        SeleniumTest.selectByVisibleTextFromDropDown(employerCountry, "United States");
        SeleniumTest.selectByVisibleTextFromDropDown(employerState, "Washington");
        SeleniumTest.clearAndSetText(employerZip, "98052");
        logger.info("Check I Acknowledge Checkbox");
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
    }

    /**
     * Clicks next and instantiates the appropriate page class
     * @param returnedClass The Page to navigate to
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    //region ENUMS

    /**
     * Sets the file to upload
     * @param filePath
     * @return
     */
    public static FormID5077I9Section2 setFileToUpload(String filePath) {
        if(OS.isFamilyWindows())
            filePath = filePath.replace('/', '\\');
        ((JavascriptExecutor)Driver.getDriver()).executeScript("document.getElementById('" + fileBox.getAttribute("id") + "').style.visibility = 'visible';");
        if(!filePath.startsWith("/") && !filePath.contains(":")) {
            filePath = "/" + filePath;
        }

        fileBox.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(uploadFileButton, 60);
        return PageFactory.initElements(Driver.getDriver(), FormID5077I9Section2.class);
    }

    /**
     * Clicks the upload file button
     * @return
     */
    public static FormID5077I9Section2 clickUploadFile() {
        uploadFileButton.click();
        WaitUntil.waitUntil(60, 3, () -> {
            try {
                return Driver.getDriver().findElement(By.className("btnPostFileToServer")).getAttribute("disabled").equals("true");
            }
            catch(NullPointerException npe) {
                // we don't care - try again
                return false;
            }
        });
        SeleniumTest.waitForElementToBeClickable(By.xpath("//label[text()='Previously "
                                                          + "Uploaded:']"), 120);

        return PageFactory.initElements(Driver.getDriver(), FormID5077I9Section2.class);
    }
    //endregion
}
