package Sites.CandidatePortal.Forms.Objects.statetax;

import Data.Data;
import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class FormLST_Exemption_Pittsburgh extends CandidatePortalPages {
    private static final Logger staticLogger = LoggerFactory.getLogger(FormLST_Exemption_Pittsburgh.class);

    @FindBy(how = How.XPATH,using = "//label[@for='1878-1878_5_Yes']")
    private WebElement lstExemptionYesRadioButton;

    @FindBy(how = How.ID,using = "1878-1878_5-err")
    private WebElement lstExemptionYesRadioButtonErrorMessage;

    @FindBy(how = How.ID,using = "1878-1878_7")
    private WebElement taxYearTextbox;

    @FindBy(how = How.ID,using = "1878-1878_7-err")
    private WebElement taxYearTextboxErrorMessage;

    @FindBy(how = How.ID,using = "1878-1878_145")
    private WebElement withHoldingsStatusDropDown;

    @FindBy(how = How.XPATH,using = "//label[@for='1878-1878_21']")
    private WebElement iDeclareCheckboxLabel;

    @FindBy(how = How.ID,using = "1878-1878_21")
    private WebElement iDeclareCheckbox;

    @FindBy(how = How.ID,using = "1878-1878_21-err")
    private WebElement iDeclareCheckboxErrorMessage;

    @FindBy(how = How.XPATH,using = "//button[@value='Next']")
    private WebElement nextButton;

    public void CompleteLSTExemptionForm()
    {
        SeleniumTest.click(lstExemptionYesRadioButton);
    }

    public void enterLSTExemptionTaxYear()
    {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDate date = LocalDate.now();
        staticLogger.info(dateFormat.format(date)); //2016/11/16 12:08:43
        String[] strDate = dateFormat.format(date).split("/");
        int year = Integer.parseInt(strDate[0]);
        staticLogger.info("Tax Year "+year);
        SeleniumTest.clearAndSetText(taxYearTextbox,String.valueOf(year));
    }

    public void selectWithholdingStatus(String status)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(withHoldingsStatusDropDown,status);
    }

    public void clickIDeclare()
    {
        SeleniumTest.check(iDeclareCheckboxLabel,iDeclareCheckbox);
    }

    public void clickNext()
    {
        SeleniumTest.click(nextButton);
    }

    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public boolean areMandatoryFieldsErrorVisible()
    {
        if(SeleniumTest.isElementVisibleNoWaiting(By.id("1878-1878_5-err")))
        {
            if(SeleniumTest.isElementVisibleNoWaiting(By.id("1878-1878_7-err")))
            {
                if(SeleniumTest.isElementVisibleNoWaiting(By.id("1878-1878_21-err")))
                {
                    return true;
                }
            }
        }
        return false;
    }
}
