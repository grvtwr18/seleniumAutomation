package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 2/8/2016.
 */
public class FormID10eSignFormsPage extends FormPage {
    @FindBy(how = How.ID, using = "acceptButton")
    private static WebElement iAgreeToUseAnElectronicSignatureButton;

    static {
        PageFactory.initElements(Driver.getDriver(), FormID10eSignFormsPage.class);
    }

     /**
     * Clicks on I agree to use electronic signature button.
     */
    public static FormeSignConfirmSignaturePage clickIAgreeToUseAnElectronicSignatureButton() {
        SeleniumTest.waitMs(2000);
        SeleniumTest.waitForElementToBeClickable(iAgreeToUseAnElectronicSignatureButton);
        iAgreeToUseAnElectronicSignatureButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormeSignConfirmSignaturePage.class);
    }
}
