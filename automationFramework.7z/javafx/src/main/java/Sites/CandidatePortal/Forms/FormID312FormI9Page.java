package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

/**
 * Created by abrackett on 11/17/2015.
 */
public class FormID312FormI9Page extends FormPage {

    @FindBy(how = How.XPATH, using = "//label[@for='312-312_6']")
    private WebElement otherNamesCheckbox;

    @FindBy(how = How.ID, using = "312-100_5")
    private WebElement ssnBox;

    @FindBy(how = How.ID, using = "312-100_6-100_6")
    private WebElement dobBox;

    private String hiddenDobBox = "312-100_6";

    @FindBy(how = How.ID, using = "312-100_7")
    private WebElement streetAddressBox;

    @FindBy(how = How.ID, using = "312-address100_9-100_10")
    private WebElement cityBox;

    private final String countryID = "312-address100_9-100_9";
    By countryLocator = By.id(countryID);
    @FindBy(how = How.ID, using = countryID)
    private WebElement countryDropdown;

    private final String stateID = "312-address100_9-100_11";
    By stateLocator = By.id(stateID);
    @FindBy(how = How.ID, using = stateID)
    private WebElement stateOrProvinceDropdown;

    @FindBy(how = How.ID, using = "312-address100_9-100_12")
    private WebElement zipBox;

    @FindBy(how = How.XPATH, using = "//label[@for='312-312_14']")
    private WebElement emailAddressNACheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='312-312_18']")
    private WebElement telephoneNumberNACheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='312-I9s1_14_USCitizen']")
    private WebElement citizenRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='312-I9s1_14_USNoncitizenNational']")
    private WebElement noncitizenRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='312-I9s1_14_LawfulPermanentResident']")
    private WebElement lawfulResidentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='312-I9s1_14_AlienAuthorizedToWork']")
    private WebElement authorizedAlienRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='312-I9s1_21']")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.ID, using = "312-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "312-previousnextbuttons-savebutton")
    private WebElement saveButton;

    /**
     * Check Other Names Checkbox
     * @return
     */
    public FormID312FormI9Page checkOtherNamesNA() {
        if(!otherNamesCheckbox.isSelected())
            otherNamesCheckbox.click();
        return this;
    }

    /**
     * Uncheck other names checkbox
     * @return
     */
    public FormID312FormI9Page uncheckOtherNamesNA() {
        if(otherNamesCheckbox.isSelected())
            otherNamesCheckbox.click();
        return this;
    }

    /**
     * Set SSN
     * @param ssn
     * @return
     */
    public FormID312FormI9Page setSocialSecurityNumber(String ssn) {
        SeleniumTest.clearAndSetText(ssnBox, ssn);
        return this;
    }

    /**
     * Set DOB
     * @param lDate
     * @return
     */
    public FormID312FormI9Page setDateOfBirth(LocalDate lDate) {
        dobBox.clear();
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(lDate, dobBox.getAttribute("id"), hiddenDobBox);
        return this;
    }

    /**
     * Set Street Address
     * @param streetAddress
     * @return
     */
    public FormID312FormI9Page setStreetAddress(String streetAddress) {
        SeleniumTest.clearAndSetText(streetAddressBox, streetAddress);
        return this;
    }

    /**
     * Set City
     * @param city
     * @return
     */
    public FormID312FormI9Page setCity(String city) {
        SeleniumTest.clearAndSetText(cityBox, city);
        return this;
    }

    /**
     * Select Country or Region
     * @param country
     * @return
     */
    public FormID312FormI9Page selectCountryRegion(String country) {
        Select countrySelect = new Select(countryDropdown);
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(countryLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        countrySelect.selectByVisibleText(country);
        return this;
    }

    /**
     * Select State or Province
     * @param state
     * @return
     */
    public FormID312FormI9Page selectStateOrProvince(String state) {
        Select stateSelect = new Select(stateOrProvinceDropdown);
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(stateLocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        stateSelect.selectByVisibleText(state);
        return this;
    }

    /**
     * Set Zip Code
     * @param zip
     * @return
     */
    public FormID312FormI9Page setZipCode(String zip) {
        SeleniumTest.clearAndSetText(zipBox, zip);
        return this;
    }

    /**
     * Check Email Address N/A
     * @return
     */
    public FormID312FormI9Page checkEmailAddressNA() {
        if(!emailAddressNACheckbox.isSelected())
            emailAddressNACheckbox.click();
        return this;
    }

    /**
     * uncheck Email Address N/A
     * @return
     */
    public FormID312FormI9Page uncheckEmailAddressNA() {
        if(emailAddressNACheckbox.isSelected())
            emailAddressNACheckbox.click();
        return this;
    }

    /**
     * Check Telephone number N/A
     * @return
     */
    public FormID312FormI9Page checkTelephoneNumberNA() {
        if(!telephoneNumberNACheckbox.isSelected())
            telephoneNumberNACheckbox.click();
        return this;
    }

    /**
     * uncheck Telephone number N/A
     * @return
     */
    public FormID312FormI9Page uncheckTelephoneNumberNA() {
        if(telephoneNumberNACheckbox.isSelected())
            telephoneNumberNACheckbox.click();
        return this;
    }

    /**
     * Choose Citizen Radio Button
     * @return
     */
    public FormID312FormI9Page chooseCitizenRadiobutton() {
        citizenRadiobutton.click();
        return this;
    }

    /**
     * Choose non Citizen Radio Button
     * @return
     */
    public FormID312FormI9Page chooseNonCitizenRadiobutton() {
        noncitizenRadiobutton.click();
        return this;
    }

    /**
     * Choose Lawful permanent rsident Radio button
     * @return
     */
    public FormID312FormI9Page chooseLawfulPermanentResidentRadiobutton() {
        lawfulResidentRadiobutton.click();
        return this;
    }

    /**
     * Choose Authorized Alian Radio Button
     * @return
     */
    public FormID312FormI9Page chooseAuthorizedAlienRadiobutton() {
        authorizedAlienRadiobutton.click();
        return this;
    }

    /**
     * Check I acknowledge chackbox
     * @return
     */
    public FormID312FormI9Page checkIAcknowledgeCheckbox() {
        if(!iAcknowledgeCheckbox.isSelected())
            iAcknowledgeCheckbox.click();
        return this;
    }

    /**
     * uncheck I acknowledge Checkbox
     * @return
     */
    public FormID312FormI9Page uncheckIAcknowledgeCheckbox() {
        if(iAcknowledgeCheckbox.isSelected())
            iAcknowledgeCheckbox.click();
        return this;
    }

    /**
     * Click Next Button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNextButton(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Click Save Button
     * @return
     */
    public FormID312FormI9Page clickSaveButton() {
        saveButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID312FormI9Page.class);
    }
}
