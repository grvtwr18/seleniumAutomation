package Sites.CandidatePortal.Forms;

import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;

/**
 * Created by abrackett on 4/14/2016.
 */
public class FormID12532I9Section3Page extends Form_I9Pages {
    public static final String I9S3 = "17231-I9s3";
    public static final String I9S3_3_NA = I9S3 + "_3NA";
    public static final String I9S3_52 = I9S3 + "_52";
    private static final Logger logger = LoggerFactory.getLogger("FormID12532I9Section3Page");

    @FindBy(how = How.ID, using = I9S3 + "_1")
    private static WebElement firstNameBox;

    @FindBy(how = How.ID,using = I9S3 + "_3_1")
    private static WebElement middleNameBox;

    @FindBy(how = How.ID, using = I9S3_3_NA)
    private static WebElement hiddenMiddleNameCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='" + I9S3_3_NA + "']")
    private static WebElement visibleMiddleNameLabel;

    @FindBy(how = How.ID, using = I9S3 + "_2")
    private static WebElement lastNameBox;

    @FindBy(how = How.ID, using = I9S3_52)
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='" + I9S3_52 + "']")
    private static WebElement iAcknowledgeLabel;

    @FindBy(how = How.ID, using = "12532-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    @FindBy(how = How.ID, using = "12532-12532_1")
    private static WebElement listAOrCDocumentDropDown;

    static {
        PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }

    public static FormID12532I9Section3Page setFirstName(String fName) {
        SeleniumTest.clearAndSetText(firstNameBox, fName);
        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }

    public static FormID12532I9Section3Page setMiddleName(String mName) {
        if(mName.isEmpty()) {
            SeleniumTest.check(visibleMiddleNameLabel, hiddenMiddleNameCheckbox);
        }
        else {
            SeleniumTest.clearAndSetText(middleNameBox, mName);
        }
        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }

    public static FormID12532I9Section3Page setLastName(String lName) {
        SeleniumTest.clearAndSetText(lastNameBox, lName);
        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }

    public static FormID12532I9Section3Page checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }

    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        logger.info("Attempt to navigate to the next page {}", returnedClass.getSimpleName());
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Select from DropDown List A Document
     * @param document ListADocument
     * @return
     */
    public static FormID12532I9Section3Page selectListAOrCDocument(ListADocuments document) {
        return selectListAOrCDocument(document.toString());
    }
    /**
     * Select from DropDown List C Document
     * @param document ListADocument
     * @return
     */
    public static FormID12532I9Section3Page selectListAOrCDocument(ListCDocuments document) {
        return selectListAOrCDocument(document.toString());
    }

    /**
     * Select from DropDown List A or C Document
     * @param document ListADocument
     * @return
     */
    private static FormID12532I9Section3Page selectListAOrCDocument(String document) {
        // Attempting to add a click here to stop the test from failing repeatedly when searching
        // for elements
        listAOrCDocumentDropDown.click();
        SeleniumTest.selectByVisibleTextFromDropDown(listAOrCDocumentDropDown, document);
        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }

    /**
     * Fills in the Section 3 Form
     * @param document What document to use for the form
     * @param documentNumber What document number to fill in
     * @param expirationDate the expiration of the document or null if none
     * @return
     */
    public static FormID12532I9Section3Page fillSection3Reverification(ListADocuments document, String documentNumber, LocalDate expirationDate) {
        logger.info("Select Document {}", document.toString());
        selectListAOrCDocument(document);
        logger.info("Fill Document number: {}", documentNumber);
        switch (document) {
            case USPASSPORT:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_13")), documentNumber);
                // document number : 12532-I9s3_13
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case USPASSPORTCARD:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_13")), documentNumber);
                // document number : 12532-I9s3_13
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case PERMANENTRESIDENTCARD:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_14")), documentNumber);
                // document number : 12532-I9s3_14
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case ALIENREGISTRATIONRECEIPTCARD:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_14")), documentNumber);
                // document number : 12532-I9s3_14
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case FOREIGNPASSPORTWITHI_551STAMP:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_14")), documentNumber);
                // document number : 12532-I9s3_14
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case EMPLOYMENTAUTHORIZATIONDOCUMENT:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_14")), documentNumber);
                // document number : 12532-I9s3_14
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case FOREIGNPASSPORTWITHI_94_AFORM:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_15")), documentNumber);
                // document number : 12532-I9s3_15
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case FSMPASSPORTWITHI_94_AFORM:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_15")), documentNumber);
                // document number : 12532-I9s3_15
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case RMIPASSPORTWITHI_94_AFORM:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_15")), documentNumber);
                // document number : 12532-I9s3_15
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case I_94_AFORMWITHREFUGEESTAMP:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_15")), documentNumber);
                // document number : 12532-I9s3_15
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
        }
        logger.info("Set Expiration Date: {}",
                    expirationDate.format(LocaleHelper.getDateFormatShortDateSlash()));
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(expirationDate, I9S3 + "_19-I9s3_19", I9S3 + "_19");
        logger.info("Check I Acknowledge");
        checkIAcknowledge();

        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }

    /**
     * Fills in the Section 3 Form
     * @param document What document to use for the form
     * @param documentNumber What document number to fill in
     * @param expirationDate the expiration of the document or null if none
     * @return
     */
    public static FormID12532I9Section3Page fillSection3Reverification(ListCDocuments document, String documentNumber, LocalDate expirationDate) {
        logger.info("Select Document {}", document.toString());
        selectListAOrCDocument(document);
        logger.info("Fill Document number: {}", documentNumber);
        switch (document) {
            case I_20:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_16")), documentNumber);
                logger.info("Set Expiration Date: {}", expirationDate.format(LocaleHelper
                                                                                     .getDateFormatShortDateSlash()));
                SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(expirationDate, I9S3 + "_19-I9s3_19", I9S3 + "_19");
                // document number : 12532-I9s3_16
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case DS_2019:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_16")), documentNumber);
                logger.info("Set Expiration Date: {}",
                            expirationDate.format(LocaleHelper.getDateFormatShortDateSlash()));
                SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(expirationDate, I9S3 + "_19-I9s3_19", I9S3 + "_19");
                // document number : 12532-I9s3_16
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case SSACCOUNTNUMBERCARD:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_17")), documentNumber);
                // document number : 12532-I9s3_17
                break;
            case BIRTHABROADCERTIFICATEFS_545:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_18")), documentNumber);
                // document number : 12532-I9s3_18
                break;
            case BIRTHABROADCERTIFICATEDS_1350:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_18")), documentNumber);
                // document number : 12532-I9s3_18
                break;
            case BIRTHCERTIFICATEWITHSEAL:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_18")), documentNumber);
                // document number : 12532-I9s3_18
                break;
            case NATIVEAMERICANTRIBALDOCUMENT:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_18")), documentNumber);
                // document number : 12532-I9s3_18
                break;
            case USCITIZENIDCARD:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_18")), documentNumber);
                // document number : 12532-I9s3_18
                break;
            case RESIDENTCITIZENIDCARD:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_18")), documentNumber);
                logger.info("Set Expiration Date: {}",
                            expirationDate.format(LocaleHelper.getDateFormatShortDateSlash()));
                SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(expirationDate, I9S3 + "_19-I9s3_19", I9S3 + "_19");
                // document number : 12532-I9s3_18
                // expiration date : 12532-I9s3_19-I9s3_19
                break;
            case DHSEMPLOYMENTAUTHORIZATIONDOCUMENT:
                SeleniumTest.clearAndSetText(Driver.getDriver().findElement(By.id(I9S3 + "_18")), documentNumber);
                logger.info("Set Expiration Date: {}",
                            expirationDate.format(LocaleHelper.getDateFormatShortDateSlash()));
                SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(expirationDate, I9S3 + "_19-I9s3_19", I9S3 + "_19");
                break;
        }
        logger.info("Check I Acknowledge");
        checkIAcknowledge();
        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);

    }





    public static FormID12532I9Section3Page fillSection3NameChange(Candidate candidate, String newFirstName, String newMiddleName, String newLastName) {
        if(!newFirstName.isEmpty()){
            setFirstName(newFirstName);
        }
        else {
            setFirstName(candidate.getFirstName());
        }
        if(!newMiddleName.isEmpty()) {
            setMiddleName(newMiddleName);
        }
        else {
            setMiddleName(candidate.getMiddleName());
        }
        if(!newLastName.isEmpty()) {
            setLastName(newLastName);
        }
        else {
            setLastName(candidate.getLastName());
        }
        checkIAcknowledge();
        return PageFactory.initElements(Driver.getDriver(), FormID12532I9Section3Page.class);
    }


}
