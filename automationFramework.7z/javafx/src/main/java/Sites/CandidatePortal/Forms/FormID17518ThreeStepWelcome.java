package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;

/**
 * The first candidate form in three step I-9 (FS 4577)
 */
public class FormID17518ThreeStepWelcome extends CandidatePortalPages {

    static {
        PageFactory.initElements(Driver.getDriver(), FormID17518ThreeStepWelcome.class);
    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {}
}
