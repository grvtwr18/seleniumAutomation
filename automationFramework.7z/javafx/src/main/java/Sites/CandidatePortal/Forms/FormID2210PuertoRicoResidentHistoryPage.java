package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.Navigation;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by jgupta on 3/6/2016.
 */
public class FormID2210PuertoRicoResidentHistoryPage extends FormPage {

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private static WebElement saveButton;

    static String addressBaseID = "2210-history-2-2210_3-address2210_8_";

    /**
     * Types From date
     * @param index
     * @param date
     */
    public static void typeFromDate(String index, String date) {
        // typing dates does not work must use javascript to set the value
        WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("2210-history-2-2210_3-2210_3_" + index + "-2210_3_" + index)).isDisplayed());
        WebElement visibleElement = Driver.getDriver().findElement(By.id("2210-history-2-2210_3-2210_3_" + index +
                                                                         "-2210_3_" + index));
        String visibleElementId = visibleElement.getAttribute("id");

        WebElement hiddenElement = Driver.getDriver().findElement(By.id(
                "2210-history-2-2210_3-2210_3_" + index));
        String hiddenElementId = hiddenElement.getAttribute("id");

        JavaScriptHelper.setValue(date, hiddenElementId);
        JavaScriptHelper.setValue(date, visibleElementId);
    }

    /**
     * Types To date
     * @param index
     * @param date
     */
    public static void typeToDate(String index, String date) {
        // typing dates does not work must use javascript to set the value
        WaitUntil.waitUntil(() -> Driver.getDriver().findElement(By.id("2210-history-2-2210_3-2210_4_" + index + "-2210_4_" + index)).isDisplayed());
        WebElement visibleElement = Driver.getDriver().findElement(By.id("2210-history-2-2210_3-2210_4_" + index +
                                                                         "-2210_4_" + index));
        String visibleElementId = visibleElement.getAttribute("id");

        WebElement hiddenElement = Driver.getDriver().findElement(By.id
                ("2210-history-2-2210_3-2210_4_" + index));
        String hiddenElementId = hiddenElement.getAttribute("id");

        JavaScriptHelper.setValue(date, hiddenElementId);
        JavaScriptHelper.setValue(date, visibleElementId);
    }

    /**
     * Clicks on save button
     */
    public static void clickSaveButton() {
        saveButton.click();
    }

    /**
     * Clicks on Add button.
     * @param index
     * @param indexOfExpectedNewLabel
     */
    public static void clickAddButton(int index, int indexOfExpectedNewLabel) {
        WebElement addButton = Driver.getDriver().findElement(By.id("historyAdd" + index));
        addButton.click();
        SeleniumTest.waitForElementVisible(By.cssSelector("div.subTitle[ref='history-2-2210_3-label_" + indexOfExpectedNewLabel + "']"));
    }

    /**
     * Clicks on Add button.
     * @param index
     */
    public static void clickAddButton(int index) {
        WebElement addButton = Driver.getDriver().findElement(By.id("historyAdd" + index));
        addButton.click();
    }

    /**
     * Clicks on remove history button.
     * @param index
     */
    public static void clickRemoveButton(int index) {
        WebElement removeButton = Driver.getDriver().findElement(By.id("historyRemove" + index));
        removeButton.click();
    }

    /**
     * Clicks on remove history button.
     * @param index
     */
    public static void clickRemoveButton(int index, int indexExpectedToBeDeleted) {
        WebElement removeButton = Driver.getDriver().findElement(By.id("historyRemove" + index));
        removeButton.click();
        SeleniumTest.waitForElementNotPresent(By.id("historyRemove" + indexExpectedToBeDeleted)); //Wait for the entry to get deleted
    }

    /**
     * Clicks Next
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        return Navigation.clickNext(returnedClass);
    }

    /**
     * Check the current checkbox.
     */
    public static void checkCurrentCheckbox(int index) {
        WebElement currentCheckbox = Driver.getDriver().findElement(By.cssSelector("label[for='2210-history-2-2210_3-2210_5_" + index + "']"));
        currentCheckbox.click();
    }

    /**
     * Fills the history form.
     * @param index
     * @param fromDate
     * @param toDate
     * @param isCurrentFlag
     * @param address
     * @param aptNumber
     * @param city
     * @param country
     * @param state
     * @param zip
     */
    public static void fillHistoryForm(int index, String fromDate, String toDate, Boolean isCurrentFlag, String address, String aptNumber, String city, String country, String state, String zip) {
        typeFromDate(Integer.toString(index), fromDate);
        if (isCurrentFlag.equals(true)) {
            checkCurrentCheckbox(index);
        }
        else {
            typeToDate(Integer.toString(index), toDate);
        }
        typeStreetAddress(index, address);
        typeAptNumber(index, aptNumber);
        typeCity(index, city);
        selectCountry(index, country);
        selectState(index, state);
        typeZip(index, zip);
    }

    /**
     * Types zip code in the zip code text box.
     * @param index
     * @param zip
     */
    private static void typeZip(int index, String zip) {
        WebElement zipTextBox = Driver.getDriver().findElement(By.id(addressBaseID + index + "-2210_11_" + index));
        zipTextBox.sendKeys(zip);
    }

    /**
     * Selects state from the state drop down
     * @param index
     * @param state
     */
    private static void selectState(int index, String state) {
        WebElement stateDropDown = Driver.getDriver().findElement(By.id(addressBaseID + index + "-2210_10_" + index));
        final Select selection = new Select(stateDropDown);
        WaitUntil.waitUntil(60,2,() -> selection.getOptions().size() > 5);
        selection.selectByVisibleText(state);
    }

    /**
     * Selects country from the country drop down.
     * @param index
     * @param country
     */
    private static void selectCountry(int index, String country) {
        WebElement countryDropDown = Driver.getDriver().findElement(By.id(addressBaseID + index + "-2210_8_" + index));
        Select countryDD = new Select(countryDropDown);
        countryDD.selectByVisibleText(country);
    }

    /**
     * Types in city text box.
     * @param index
     * @param city
     */
    private static void typeCity(int index, String city) {
        WebElement cityTextBox = Driver.getDriver().findElement(By.id(addressBaseID + Integer.toString(index) + "-2210_9_" + index));
        cityTextBox.sendKeys(city);
    }

    /**
     * Types apartment number in apartment number text box.
     * @param index
     * @param aptNumber
     */
    private static void typeAptNumber(int index, String aptNumber) {
        WebElement apartmentTextBox = Driver.getDriver().findElement(By.cssSelector("input[name='2210-history-2-2210_3-2210_7_" + index));
        apartmentTextBox.sendKeys(aptNumber);
    }

    /**
     * Types address in street address text box.
     * @param index
     * @param address
     */
    private static void typeStreetAddress(int index, String address) {
        WebElement addressTextBox = Driver.getDriver().findElement(By.cssSelector("input[name='2210-history-2-2210_3-2210_6_" + index));
        addressTextBox.sendKeys(address);
    }

    /**
     * Returns the error message at the top of the page.
     * @return
     */
    public static String getErrorMsgAtTopOfPage() {
        return Driver.getDriver().findElement(By.id("2210-history-2-2210_3-err")).getText();
    }

    /**
     * Resets history form to blank.
     */
    public static void resetHistoryFormToBlank() {
        int removeBtnsCount = Driver.getDriver().findElements(By.className("simplebutton")).size();

        for (int maxIndex = removeBtnsCount - 1; maxIndex >= 0; maxIndex--) {
            int recordNumber = maxIndex + 2;
            if (maxIndex == 0) {
                FormID2210PuertoRicoResidentHistoryPage.clickAddButton(maxIndex);
                waitForRecordNumberVisible(recordNumber);
            }
            FormID2210PuertoRicoResidentHistoryPage.clickRemoveButton(maxIndex);
            waitForRecordNumberNotPresent(recordNumber);
        }
    }

    private static int staticRecordNumber;
    /**
     * Waits for a history record to be visible.
     * @param recordNumber
     */
    public static void waitForRecordNumberVisible(final int recordNumber) {
        staticRecordNumber = recordNumber;
        WaitUntil.waitUntil(() -> {
                    return Driver.getDriver().findElement(By.cssSelector("div.subTitle[ref='history-2-2210_3-label_" + staticRecordNumber + "']")).isDisplayed();
                }, NoSuchElementException.class);
    }

    /**
     * Wait for a particular history record to not be present on page
     * @param recordNumber
     */
    public static void waitForRecordNumberNotPresent(int recordNumber) {
        SeleniumTest.waitForElementNotPresent(By.cssSelector("div.subTitle[ref='history-2-2210_3-label_" + recordNumber + "']")); //Wait for the entry to get deleted
    }

    /**
     * Get error message displayed in a given history widget for From Field
     * @param index
     * @return
     */
    public static String getFromFieldErrorMessage(int index) {
        return Driver.getDriver().findElement(By.id("2210-history-2-2210_3-2210_3_" + index + "-err")).getText();
    }

    /**
     * Get error message displayed in a given history widget for To field
     * @param index
     * @return
     */
    public static String getToFieldErrorMessage(int index) {
        return Driver.getDriver().findElement(By.id("2210-history-2-2210_3-2210_4_" + index + "-err")).getText();
    }

    /**
     * Get error message displayed for field Street in history widget.
     * @param index
     * @return
     */
    public static String getStreetFieldErrorMessage(int index) {
        return Driver.getDriver().findElement(By.id("2210-history-2-2210_3-2210_6_" + index + "-err")).getText();
    }

    /**
     * Get error message displayed for field city in history widget.
     * @param index
     * @return
     */
    public static String getCityFieldErrorMessage(int index) {
        return Driver.getDriver().findElement(By.id("2210-history-2-2210_3-address2210_8_0-2210_9_0-err")).getText();
    }

    /**
     * Get error message displayed for field zip in history widget.
     * @param index
     * @return
     */
    public static String getZipFieldErrorMessage(int index) {
        return Driver.getDriver().findElement(By.id("2210-history-2-2210_3-address2210_8_0-2210_11_" + index + "-err")).getText();
    }

    /**
     * Returns the title of the current history record
     * @param recordNumber
     * @return
     */
    public static String getRecordNumberTitle(int recordNumber) {
        return Driver.getDriver().findElement(By.cssSelector("div.subTitle[ref='history-2-2210_3-label_" + recordNumber + "']")).getText();
    }
}
