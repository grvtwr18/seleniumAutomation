package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


/**
 * Created by jgupta on 3/27/2017.
 */
public class DmvDrivingRecordsPage extends FormPage {
    /**
     * Return the GroupId used in each SKU
     */
    private static String discoverGroupId(){
        return Driver.getDriver().findElement(By.xpath("//div[@id[starts-with(., 'divForm_Group')]]")).getAttribute("id").split("_")[1].substring(5);
    }

    /**
     * This method fills the Driving record information.
     * @param state Name of the state
     * @param license license number of the candidate
     */
    public static void enterDrivingRecordInformation(String state, String license){
        selectDrivingRecordState(state);
        typeLicenseNumber(license);
    }

    /**
     * This method will help to select the driving record state.
     * @param stateValue Value of state.
     */
    private static void selectDrivingRecordState(String stateValue){
        String groupId = discoverGroupId();
        WebElement stateDropDown = Driver.getDriver().findElement(By.id("qs_Group" + groupId +
                                                                        "_1"));
        SeleniumTest.selectByValueFromDropDown(stateDropDown, stateValue);
    }

    /**
     * This method types the license number.
     * @param license License number of candidate for given state
     */
    private static void typeLicenseNumber(String license) {
        String groupId = discoverGroupId();
        WebElement drivingLicenseTextBox = Driver.getDriver().findElement(
                By.id("qdl_Group" + groupId + "_1"));
        SeleniumTest.clearAndSetText(drivingLicenseTextBox, license);
    }
}
