package Sites.CandidatePortal.Forms.Objects.I9;

/**
 * Created by abrackett on 10/18/16.
 */
public class BusinessEntity {

    private String title = "Grand Poobah";
    private String name = "Generic Company";
    private String addressLine1 = "12345 NE 67th Street";
    private String city = "Woodinville";
    private String countryOrRegion = "United States";
    private String stateOrProvince = "Washington";
    private String zipCode = "98077";

    public BusinessEntity() {

    }

    public BusinessEntity(String title, String name, String addressLine1, String city, String
            countryOrRegion, String stateOrProvince, String zipCode) {
        this.title = title;
        this.name = name;
        this.addressLine1 = addressLine1;
        this.city = city;
        this.countryOrRegion = countryOrRegion;
        this.stateOrProvince = stateOrProvince;
        this.zipCode = zipCode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountryOrRegion() {
        return countryOrRegion;
    }

    public void setCountryOrRegion(String countryOrRegion) {
        this.countryOrRegion = countryOrRegion;
    }

    public String getStateOrProvince() {
        return stateOrProvince;
    }

    public void setStateOrProvince(String stateOrProvince) {
        this.stateOrProvince = stateOrProvince;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}
