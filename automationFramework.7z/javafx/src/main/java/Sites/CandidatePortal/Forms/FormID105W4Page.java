package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 8/13/2015.
 */
public class FormID105W4Page extends FormPage {

    @FindBy(how = How.ID, using = "105-formtitle")
    private WebElement w4PageTitleText;

    @FindBy(how = How.CSS, using = "label[for='105-105_37_Yes']")
    private WebElement lastYearNoTaxLiability_YesRadio;

    @FindBy(how = How.CSS, using = "label[for='105-105_37_No']")
    private WebElement lastYearNoTaxLiability_NoRadio;

    @FindBy(how = How.ID, using = "105-105_37-err")
    private WebElement lastYearNoTaxLiabilityRadioErrorMessage;

    private String lastYearNoTaxLiabilityRadioErrorMessageID="lastYearNoTaxLiabilityRadioErrorMessage";

    @FindBy(how = How.CSS, using = "label[for='105-105_40_Yes']")
    private WebElement thisYearNoTaxLiability_YesRadio;

    @FindBy(how = How.CSS, using = "label[for='105-105_40_No']")
    private WebElement thisYearNoTaxLiability_NoRadio;

    @FindBy(how = How.ID, using = "105-105_40-err")
    private WebElement thisYearNoTaxLiabilityRadioErrorMessage;

    @FindBy(how = How.ID, using = "105-105_5")
    private WebElement exemptTextBox;

    @FindBy(how = How.ID, using = "105-105_5-err")
    private WebElement exemptTextBoxErrorMessage;

    @FindBy(how = How.CSS, using = "label[for='105-105_44']")
    private WebElement iVerifyExemptCheckBox;

    @FindBy(how = How.ID, using = "105-105_44-err")
    private WebElement iVerifyExemptCheckBoxErrorMessage;

    @FindBy(how = How.XPATH, using = "//label[@for='105-105_1_Single']")
    private WebElement singleRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='105-105_1_Married']")
    private WebElement marriedRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='105-105_1_Married, but withhold at higher Single rate.']")
    private WebElement marriedButWithholdHigherSingleRateRadioBtn;

    @FindBy(how = How.ID, using = "105-105_1-err")
    private WebElement maritalStatusRadioErrorMessage;

    private final String maritalStatusRadioErrorMessageID="105-105_1-err";

    @FindBy(how = How.CSS, using = "label[for='105-105_2']")
    private WebElement myLastNameDiffersCheckBox;

    @FindBy(how = How.CSS, using = "label[for='105-105_31']")
    private WebElement nonResidentCheckBox;

    @FindBy(how = How.CSS, using = "label[for='105-105_58']")
    private WebElement claimingTaxTreatyCheckBox;

    @FindBy(how = How.ID, using = "105-105_3")
    private WebElement totalAllowanceNumber;

    @FindBy(how = How.ID, using = "105-105_3-err")
    private WebElement numberOfAllowancesErrorMessage;

    @FindBy(how = How.ID, using = "105-105_4")
    private WebElement additionalAmount;

    @FindBy(how = How.ID, using = "105-105_4-err")
    private WebElement additionalAmountErrorMessage;

    @FindBy(how = How.CSS, using = "button[value='Previous']")
    private WebElement previousButton;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private WebElement saveButton;

    @FindBy(how = How.CSS, using = "label[for='105-105_18']")
    private WebElement declarationCheckBox;

    @FindBy(how = How.XPATH,using = "//*[contains(@class,'checkboxLabel')]")
    private WebElement iAcknowledgeW4Label;

    @FindBy(how = How.XPATH,using = "//label[@for='1896-1896_4']")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.ID, using = "105-105_18-err")
    private WebElement iDeclareCheckboxErrorMessage;

    private String iDeclareCheckboxErrorMessageID="105-105_18-err";

    @FindBy(how = How.CSS, using = "label[for$='1785-1785_5_No']")
    private WebElement noToCompleteDR1059Label;

    @FindBy(how = How.CSS, using = "input[id$='1785-1785_5_No']")
    private WebElement noToCompleteDR1059RadioBtn;

    @FindBy(how = How.ID, using = "1785-previousnextbuttons-nextbutton")
    private WebElement nextBtnBR1059;

    @FindBy(how = How.ID, using = "1896-previousnextbuttons-nextbutton")
    private WebElement nextBtn1896;

    @FindBy(how = How.ID,using = "105-105_3-err")
    private WebElement totalAllowanceNumberErrorMessage;

    @FindBy(how = How.ID, using = "105-previousnextbuttons-nextbutton")
    private WebElement nextBtn105;

    @FindBy(how = How.ID,using = "105-105_37-err")
    private WebElement lastYearNoTaxLiabilityErrorMessage;

    @FindBy(how = How.ID,using = "105-105_1-err")
    private WebElement maritalStatusErrorMessage;

    @FindBy(how = How.ID,using = "105-105_18-err")
    private WebElement declarationCheckBoxErrorMessage;


    @FindBy(how = How.LINK_TEXT,using = "W-4")
    private WebElement W4sectionLink;

    @FindBy(how = How.ID,using = "1785-1785_5-err")
    private WebElement noToCompleteDR1059LabelErrorMessage;

    @FindBy(how = How.ID,using = "105-105_3")
    private WebElement totalAllowanceNumberElement;


    static{
        PageFactory.initElements(Driver.getDriver(), FormID105W4Page.class);
    }

    public static FormID105W4Page getInstance() {
         return PageFactory.initElements(Driver.getDriver(), FormID105W4Page.class);
    }

    /**
     * Select marital status.
     * @param maritalStatus
     */
    public void selectMaritalStatus(String maritalStatus) {
        if(maritalStatus=="Single")
            getInstance().singleRadioBtn.click();
        else if(maritalStatus=="Married")
            marriedRadioBtn.click();
        else if(maritalStatus=="Married, but withhold at higher Single rate.")
            marriedButWithholdHigherSingleRateRadioBtn.click();
    }

    public String w4PageTitleText() {
        return w4PageTitleText.getText();
    }

    public void selectLastYearNoTaxLiability_YesRadio() {
        lastYearNoTaxLiability_YesRadio.click();
    }

    public void selectLastYearNoTaxLiability_NoRadio() {
        lastYearNoTaxLiability_NoRadio.click();
    }

    public void selectThisYearNoTaxLiability_YesRadio() {
        thisYearNoTaxLiability_YesRadio.click();
    }

    public void selectThisYearNoTaxLiability_NoRadio() {
        thisYearNoTaxLiability_NoRadio.click();
    }

    public String getIDeclareErrorMessageText() {
        return iDeclareCheckboxErrorMessage.getText();
    }

    public String getLastYearNoTaxLiabilityErrorMessageText() {
        return lastYearNoTaxLiabilityRadioErrorMessage.getText();
    }

    public String getMaritalStatusErrorMessageText() {
        return maritalStatusRadioErrorMessage.getText();
    }

    public String getThisYearNoTaxLiabilityErrorMessageText() {
        return thisYearNoTaxLiabilityRadioErrorMessage.getText();
    }

    public String getExemptTextboxErrorMessageText() {
        return exemptTextBoxErrorMessage.getText();
    }

    public void clickIVerifyExemptCheckbox() {
        iVerifyExemptCheckBox.click();
    }

    public String getIVerifyCheckboxErrorMessageText() {
        return iVerifyExemptCheckBoxErrorMessage.getText();
    }

    public void enterExemptTextboxText(String exemptText) {
        SeleniumTest.clearAndSetText(exemptTextBox, exemptText);
    }

    public String getNumberOfAllowancesTextboxErrorMessageText() {
        return numberOfAllowancesErrorMessage.getText();
    }

    public String getAdditionalAmountTextboxErrorMessageText() {
        return additionalAmountErrorMessage.getText();
    }

    public void clickMyLastNameDiffersCheckbox() {
        myLastNameDiffersCheckBox.click();
    }

    public void checkNonResidentCheckbox() {
        nonResidentCheckBox.click();
    }

    public void checkTaxTreatyCheckbox() {
        claimingTaxTreatyCheckBox.click();
    }

    /**
     * Set number of allowances
     */
    public void setNumberOfAllowances(String number) {
        SeleniumTest.clearAndSetText(getInstance().totalAllowanceNumber, number);

    }


    public void enterTextTotalAllowanceNumberElement(String text){
        SeleniumTest.clearAndSetText(getInstance().totalAllowanceNumberElement,text);

    }

    public boolean isTotalAllowanceNumberElementVisible(){
        return SeleniumTest.isElementVisibleNoWaiting(By.id("105-105_3"));
    }
    public void setAdditionalAmount(String amount) {
        SeleniumTest.clearAndSetText(additionalAmount, amount);
    }

    /**
     * Checks the 'I Declare' checkbox
     */
    public void checkIDeclareCheckBox() {
        getInstance().declarationCheckBox.click();
    }

    /**
     * Click save button.
     */
    public void save() {
        saveButton.click();
    }

    /**
     * Click Next button.
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public FormID1083IRSW9Page fillFormID105W4() {
        selectLastYearNoTaxLiability_YesRadio();
        selectThisYearNoTaxLiability_NoRadio();
        selectMaritalStatus("Single");
        setNumberOfAllowances("2");
        SeleniumTest.clearAndSetText(additionalAmount, "0");
        checkIDeclareCheckBox();
        return (FormID1083IRSW9Page) clickNext(FormID1083IRSW9Page.class);
    }

    public  void fillW4FormID105(){
        selectMaritalStatus("Single");
        setNumberOfAllowances("2");
        SeleniumTest.clearAndSetText(getInstance().additionalAmount, "0");
        //checkIDeclareCheckBox();
        clickNextBtn105();
    }
    public void clickiAcknowledgeW4_Colorado(){

        SeleniumTest.check(iAcknowledgeW4Label,iAcknowledgeCheckbox);
    }

    public void clickIAcknowledgeW4Colorado(){
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(iAcknowledgeCheckbox);
        getInstance().iAcknowledgeCheckbox.click();
        clickNextBtn1896();
    }
    public void clickNextBtn1896(){
        SeleniumTest.click(getInstance().nextBtn1896);
    }

    public void clickNextBtn105(){
        SeleniumTest.click(getInstance().nextBtn105);
    }

    public void clickNoToCompleteDR1059(){
        SeleniumTest.check(getInstance().noToCompleteDR1059Label,getInstance().noToCompleteDR1059RadioBtn);
    }

    public FormID6018DirectDepositPage clickNextBtn(Class<? extends FormID6018DirectDepositPage> returnedClass) {
        SeleniumTest.check(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public FormID6018DirectDepositPage clickNextBtnBR10599(){
        return (FormID6018DirectDepositPage) clickNextBtn(FormID6018DirectDepositPage.class);
    }

    public boolean isErrorForMandatoryFieldsPresent()    {


        if(SeleniumTest.isElementVisibleNoWaiting(By.id(lastYearNoTaxLiabilityRadioErrorMessageID)))
        {
            if(SeleniumTest.isElementVisibleNoWaiting(By.id(maritalStatusRadioErrorMessageID)))
            {
                if(SeleniumTest.isElementVisibleNoWaiting(By.id(iDeclareCheckboxErrorMessageID)))

                {
                    return true;
                }
            }
        }
        return false;
    }

    public void clickW4SectionLink()
    {
        SeleniumTest.click(W4sectionLink);
    }

    public boolean isNoToCompleteDR1059LabelErrorMessageVisible()
    {
        return  SeleniumTest.isElementVisibleNoWaiting(By.id("1785-1785_5-err"));
    }
}
