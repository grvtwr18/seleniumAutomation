package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.DashboardPage;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/11/2015.
 */
public class FormI9ConfirmationTaskComplete extends FormPage{
    @FindBy(how = How.XPATH, using = "//input[@value='Confirm']")
    private WebElement confirmButton;

    /**
     * clicks on Confirm Button
     * @return
     */
    public DashboardPage clickConfirm() {
        confirmButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }
}
