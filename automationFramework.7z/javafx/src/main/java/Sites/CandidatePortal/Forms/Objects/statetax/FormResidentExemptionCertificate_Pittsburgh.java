package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class FormResidentExemptionCertificate_Pittsburgh extends CandidatePortalPages {

    private final Logger staticLogger = LoggerFactory.getLogger(FormResidentExemptionCertificate_Pittsburgh.class);

    @FindBy(how = How.XPATH, using = "//label[@for='1879-1879_5_Yes']")
    private WebElement ResidencyExemptionCertificateYesRadioButton;

    @FindBy(how = How.ID, using = "1879-1879_8-1879_8")
    private WebElement residencyDateTextBox;

    @FindBy(how = How.XPATH, using = "//label[@for='1879-1879_10']")
    private WebElement IconfirmCheckboxLabel;

    @FindBy(how = How.ID, using = "1879-1879_10")
    private WebElement IconfirmCheckbox;

    @FindBy(how = How.XPATH, using = "//button[@value='Next']")
    private WebElement nextButton;

    @FindBy(how = How.XPATH, using = "//img[contains(@src,'error.png')]")
    private WebElement ErrorImage;

    @FindBy(how = How.XPATH, using = "//*[@id='ui-datepicker-div']")
    private WebElement DatePickerPopUp;

    @FindBy(how = How.XPATH, using = "//*[@id='ui-datepicker-div']//*[@class='ui-datepicker-month']")
    private WebElement DatePickerMonthDropDown;

    @FindBy(how = How.XPATH, using = "//*[@id='ui-datepicker-div']//*[@class='ui-datepicker-year']")
    private WebElement DatePickerYearDropDown;

    @FindBy(how = How.XPATH, using = "//*[@class='ui-datepicker-calendar']//a[@class='ui-state-default']")
    private List<WebElement> DatePickerDaysLink;

    private String datePicker="//*[@id='ui-datepicker-div']";

    private String errorImage="//img[contains(@src,'error.png')]";


    public void completeResidencyExemptionCertificate() {
        SeleniumTest.click(ResidencyExemptionCertificateYesRadioButton);
    }

    public void enterResidencyDate(Candidate candidate) {
        SeleniumTest.click(residencyDateTextBox);

        staticLogger.info("Date Picker is displayed");
        selectDate(candidate);

    }

    public void clickIConfirm() {
        SeleniumTest.check(IconfirmCheckboxLabel, IconfirmCheckbox);
    }

    public void clickNext() {
        SeleniumTest.click(nextButton);
    }

    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public boolean isMandatoryFieldsErrorImageVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath(errorImage));
    }

    public void selectDate(Candidate candidate) {
        String strYear = candidate.getDobYear();
        String strMonth = candidate.getDobMonth();
        String strDay = candidate.getDobDay();
        SeleniumTest.selectByVisibleTextFromDropDown(DatePickerYearDropDown, strYear);
        SeleniumTest.selectByVisibleTextFromDropDown(DatePickerMonthDropDown, strMonth);

        for (WebElement aDatePickerDaysLink : DatePickerDaysLink) {
            if (aDatePickerDaysLink.getText().equalsIgnoreCase(strDay)) {
                SeleniumTest.click(aDatePickerDaysLink);
                WaitUntil.waitUntil(ExpectedConditions.invisibilityOfElementLocated(By.xpath(datePicker)));
                WaitUntil.waitUntil(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//*[@id='ui-datepicker-div']")));
                WaitUntil.waitUntil(ExpectedConditions.invisibilityOfElementLocated(By.xpath(datePicker)));
                break;
            }
        }

    }
}
