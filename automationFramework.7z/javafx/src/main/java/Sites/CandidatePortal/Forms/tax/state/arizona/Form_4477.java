package Sites.CandidatePortal.Forms.tax.state.arizona;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_4477 extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "4477-4477_18")
    private WebElement fullName;

    @FindBy(how = How.ID, using = "4477-100_5")
    private WebElement socialSecurityNumber;

    @FindBy(how = How.ID, using = "4477-100_7")
    private WebElement homeAddress;

    @FindBy(how = How.ID, using = "4477-100_8")
    private WebElement apartmentNumber;

    @FindBy(how = How.ID, using = "4477-100_10")
    private WebElement city;

    @FindBy(how = How.ID, using = "4477-100_11")
    private WebElement state;

    @FindBy(how = How.ID, using = "4477-100_12")
    private WebElement zip;

    @FindBy(how = How.XPATH, using = "//input[@name='4477-1780_10']")
    private WebElement box1Checkbox;

    @FindBy(how = How.ID, using = "4477-1780_8_2")
    private WebElement box2Checkbox;

    @FindBy(how = How.ID, using = "4477-1778_9_2.7%")
    private WebElement twoPointSevenPercent;

    @FindBy(how = How.ID, using = "4477-div-1780_13")
    private WebElement extraAmountChecked;

    @FindBy(how = How.ID, using = "4477-1778_13")
    private WebElement extraAmount;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_4477() {

    }

    public static Form_4477 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_4477.class);
    }


    public String getFullName() {
        return fullName.getText();
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber.getText();
    }

    public String getHomeAddress() {
        return homeAddress.getText();
    }

    public String getApartmentNumber() {
        return apartmentNumber.getText();
    }

    public String getCity() {
        return city.getText();
    }

    public String getState() {
        return state.getText();
    }

    public String getZip() {
        return zip.getText();
    }

    public boolean twoPointSevenPercentChecked() {
        String attr = twoPointSevenPercent.getAttribute("checked");
        if (attr != null && attr.equals("true")) {
            return true;
        }
        return false;
    }

    public boolean box1CheckboxChecked() {
        String attr = box1Checkbox.getAttribute("checked");
        if (attr != null && attr.equals("true")) {
            return true;
        }
        return false;
    }

    public boolean box2CheckboxChecked() {
        String attr = box2Checkbox.getAttribute("checked");
        if (attr != null && attr.equals("true")) {
            return true;
        }
        return false;
    }

    public boolean extraAmountChecked() {
        return extraAmountChecked.getAttribute("clasks").contains("checked");
    }

    public String getExtraAmount() {
        return extraAmount.getText();
    }
}
