package Sites.CandidatePortal.Forms.fairChance;

import Sites.CandidatePortal.Forms.individualizedReview.IrWorkflowPages;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

/**
 * Created by jayagupta on 3/19/18.
 */
public class FormID20751FairChanceOverviewPage extends IrWorkflowPages {

    /**
     * Returns whether or not you are on this page.
     * @return true or false
     */
    public static boolean onPage() {
        try {
            return Driver.getDriver().findElement(By.id("20751-formtitle")).getText()
                    .startsWith("Overview");
        } catch (NoSuchElementException nse) {
            return false;
        }
    }
}
