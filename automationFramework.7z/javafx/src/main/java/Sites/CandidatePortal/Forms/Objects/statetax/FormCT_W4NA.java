package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 8/3/17.
 */
public class FormCT_W4NA extends CandidatePortalPages {

    @FindBy(how = How.CSS, using = "label[for$='1787_5_No']")
    private WebElement noRadioButton;

    @FindBy(how = How.CSS, using = "label[for$='1787_5_Yes']")
    private WebElement yesRadioButton;

    public FormCT_W4NA_WithholdingInfo WithholdingInformation;

    public FormCT_W4NA_EmployeeCertification EmployeeCertification;

    public FormCT_W4NA() {
        this.WithholdingInformation =
                FormCT_W4NA_WithholdingInfo.getInstance();
        this.EmployeeCertification =
                FormCT_W4NA_EmployeeCertification.getInstance();
    }

    public static FormCT_W4NA getInstance() {
        return PageFactory.initElements(Driver.getDriver(), FormCT_W4NA.class);
    }

    public FormCT_W4NA chooseNo() {
        noRadioButton.click();
        return this;
    }

    public FormCT_W4NA chooseYes() {
        yesRadioButton.click();
        return this;
    }


}

