package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by jgupta on 3/18/2016.
 */
public class FormID2204EducationPage extends FormPage {
    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "input[fieldname='High School Name']")
    private static WebElement highSchoolNameTextBox;

    @FindBy(how = How.CSS, using = "input[fieldname='Address']")
    private static WebElement addressTextBox;

    @FindBy(how = How.ID, using = "2204-address2204_2-2204_3")
    private static WebElement cityTextBox;

    @FindBy(how = How.ID, using = "2204-address2204_2-2204_2")
    private static WebElement countryDropDown;

    @FindBy(how = How.ID, using = "2204-address2204_2-2204_4")
    private static WebElement stateDropDown;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_5_Completed']")
    private static WebElement completedRadioButton;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_5_In Progress']")
    private static WebElement inProgressRadioButton;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_5_Discontinued']")
    private static WebElement discontinuedRadioButton;

    @FindBy(how = How.ID, using = "2204-2204_6-2204_6")
    private static WebElement attendedFromDateTextBox;

    @FindBy(how = How.ID, using = "2204-2204_8-2204_8")
    private static WebElement graduationDateTextBox;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_9_GED']")
    private static WebElement gedRadioButton;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_9_High School']")
    private static WebElement highSchoolRadioButton;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_11_Yes']")
    private static WebElement schoolAttendedUnderPreviousNameYesRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_11_No']")
    private static WebElement schoolAttendedUnderPreviousNameNoRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_22_Yes']")
    private static WebElement additionalEducationHistoryYesRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2204-2204_22_No']")
    private static WebElement additionalEducationHistoryNoRadioBtn;

    /**
     * Clicks Next
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Fill the high school information
     * @param highSchoolName
     * @param address
     * @param city
     * @param country
     * @param state
     * @param degreeStatus
     * @param attendedFromDate
     * @param certificationValue
     * @param hasPreviousName
     */
    public static void fillHighSchoolSectionMandatoryFields(String highSchoolName, String address, String city, String country, String state, String degreeStatus, String attendedFromDate, String graduationDate, String certificationValue, String hasPreviousName){
        selectDegreeStatus(degreeStatus);

        SeleniumTest.clearAndSetText(attendedFromDateTextBox, attendedFromDate, true);
        attendedFromDateTextBox.sendKeys(Keys.TAB);

        SeleniumTest.clearAndSetText(graduationDateTextBox, graduationDate, true);

        SeleniumTest.clearAndSetText(highSchoolNameTextBox, highSchoolName);
        SeleniumTest.clearAndSetText(addressTextBox, address);
        SeleniumTest.clearAndSetText(cityTextBox, city);

        Select countryDD = new Select(countryDropDown);
        countryDD.selectByVisibleText(country);

        Select stateDD = new Select(stateDropDown);
        stateDD.selectByVisibleText(state);

        selectCertificationOption(certificationValue);
        selectAttendedUnderPreviousNameOption(hasPreviousName);
    }

    /**
     * Select the option if the school was attended under previous name
     * @param hasPreviousName
     */
    private static void selectAttendedUnderPreviousNameOption(String hasPreviousName) {
        if (hasPreviousName.equals("Yes")) {
            schoolAttendedUnderPreviousNameYesRadioBtn.click();
        }
        else {
            schoolAttendedUnderPreviousNameNoRadioBtn.click();
        }
    }

    /**
     * Select the certification option
     * @param certificationValue
     */
    private static void selectCertificationOption(String certificationValue) {
        if (certificationValue.equals("GED")) {
            gedRadioButton.click();
        }
        else {
            highSchoolRadioButton.click();
        }
    }

    /**
     * Select the option for degree status
     * @param degreeStatus
     */
    private static void selectDegreeStatus(String degreeStatus) {
        if (degreeStatus.equals("Completed")){
            completedRadioButton.click();
        }
        else if (degreeStatus.equals("In Progress")){
            inProgressRadioButton.click();
        }
        else if (degreeStatus.equals("Discontinued")){
            discontinuedRadioButton.click();
        }
    }

    /**
     * Clicks on Yes or No option for Add Additional History question.
     * @param option
     */
    public static void selectAddAdditionalHistoryOption(String option) {
        if (option.equals("Yes")) {
            additionalEducationHistoryYesRadioBtn.click();
        }
        else {
            additionalEducationHistoryNoRadioBtn.click();
        }
    }
}
