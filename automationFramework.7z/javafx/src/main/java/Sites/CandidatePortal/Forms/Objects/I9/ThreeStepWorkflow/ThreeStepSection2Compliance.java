package Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow;


import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;

/**
 * The first compliance user form in three step I-9 (FS 4577)
 */
public class ThreeStepSection2Compliance extends CandidatePortalPages {

    static {
        PageFactory.initElements(Driver.getDriver(), ThreeStepSection2Compliance.class);
    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {}

    // region Locators

    @FindBy(how = How.ID, using = "returnbtn")
    private static WebElement returnButton;

    @FindBy(how = How.CSS, using = "input[id$='-100_16-100_16']")
    public static  WebElement startDateCalendarControl;

    @FindBy(how = How.CSS, using = "input[id$='-100_16']")
    private static WebElement hiddenStartDateCalendarControl;

    @FindBy(how = How.CSS, using = "input[id$='-311_206']")
    private static WebElement additionalInfoTextBox;

    @FindBy(how = How.CSS, using = "select[id$='-311_141']")
    private static WebElement genderDropDown;

    // endregion

    public static void clickReturnButton() {
        returnButton.click();
    }

    public static void setStartDate(LocalDate date) {
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                date, startDateCalendarControl.getAttribute("id"),
                hiddenStartDateCalendarControl.getAttribute("id"));
    }

    public static void setAdditionalInfo(String additionalInfo) {
        SeleniumTest.clearAndSetText(additionalInfoTextBox, additionalInfo);
    }

    public static void selectGender(String gender) {
        SeleniumTest.selectByVisibleTextFromDropDown(genderDropDown, gender);
    }

    public static class Section2 extends Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow.Section2 {
        static {
                PageFactory.initElements(Driver.getDriver(), Section2.class);
            }
    }

}
