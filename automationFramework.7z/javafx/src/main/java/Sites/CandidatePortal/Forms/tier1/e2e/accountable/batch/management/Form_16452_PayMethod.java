package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_16452_PayMethod extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='16452-16452_144_English']")
    private WebElement englishRadiobutton;

    @FindBy(how = How.XPATH,using = "//label[@for='16452-16452_144_Spanish']")
    private WebElement spanishRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16452-16452_131_D']")
    private WebElement directDepositRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16452-16452_131_P']")
    private WebElement payCardRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16452-16452_131_X']")
    private WebElement declineSelectionRadiobutton;

    @FindBy(how = How.ID, using = "16452-16564_132")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16452-16564_132']")
    private WebElement iAcknowledgeLabel;

    protected Logger logger = LoggerFactory.getLogger(Form_16452_PayMethod.class);

    public static Form_16452_PayMethod getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16452_PayMethod.class);
    }

    public Form_16452_PayMethod chooseEnglish() {
        englishRadiobutton.click();
        logger.info("English Chosen");
        return this;
    }

    public Form_16452_PayMethod chooseSpanish() {
        spanishRadiobutton.click();
        logger.info("Spanish Chosen");
        return this;
    }

    public Form_16452_PayMethod chooseDirectDeposit() {
        directDepositRadiobutton.click();
        logger.info("Direct Deposit Chosen");
        return this;
    }

    public Form_16452_PayMethod choosePayCard() {
        payCardRadiobutton.click();
        logger.info("Pay Card Chosen");
        return this;
    }

    public Form_16452_PayMethod chooseDeclineSelection() {
        declineSelectionRadiobutton.click();
        logger.info("Decline Selection Chosen");
        return this;
    }

    public Form_16452_PayMethod checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_16452_PayMethod uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Unchecked");
        return this;
    }
}
