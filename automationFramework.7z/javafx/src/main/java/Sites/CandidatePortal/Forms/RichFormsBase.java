package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 6/3/2016.
 */

public class RichFormsBase extends FormPage {
    //TODO move to CandidatePortalPages and refactor existing code
    public enum NavigationButtonColor {
        BLUE("nextfield"),
        GREEN("nextfield formcomplete"),
        RED("nextfield nextfield-error");

        private String cssClass;

        NavigationButtonColor(String cssClass) {
            this.cssClass = cssClass;
        }

        public String getCssClass() {
            return cssClass;
        }
    }

    @FindBy(how = How.XPATH, using = "//div[contains(@class, 'title')]")
    private static WebElement formTitle;

    @FindBy(how = How.XPATH, using = "//button[contains(@id,'-previousnextbuttons-previousbutton')]")
    private static WebElement previousButton;

    @FindBy(how = How.XPATH, using = "//button[contains(@id,'-previousnextbuttons-nextbutton')]")
    private static WebElement nextButton;

    @FindBy(how = How.ID, using = "nextbtnaction")
    public static WebElement richFormNavigationButton;

    @FindBy(how = How.ID, using = "nextfieldbtn")
    public static WebElement richFormNavigationButtonDiv;

    @FindBy(how = How.XPATH, using = "//button[contains(@id,'-previousnextbuttons-savebutton')]")
    private static WebElement saveButton;

    private static ThreadLocal<RichFormsBase> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                RichFormsBase.class));
    }

    private static RichFormsBase getInstance() {
        return threadLocalInstance.get();
    }

    /**
     * Clicks the Navigation button on the Rich Text form.
     */
    public static void clickNavigationButton() {
        SeleniumTest.click(getInstance().richFormNavigationButton);
    }

    /**
     * Clicks the Next button on the Rich Text Form.
     * @param returnedClass The class to init with the Next button
     * @return Returns a page factory init on the CandidatePortalPages
     */
    public static CandidatePortalPages clickNextButton(Class<? extends CandidatePortalPages> returnedClass) {
        //TODO investigate why the button.click doesn't work
        Driver.getDriver().findElement(By.xpath("//button[contains(@id,'-previousnextbuttons-nextbutton')]")).click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks the Previous button on the Rich Text Form.
     * @param returnedClass The class to init with the Previous button
     * @return Returns a page factory init on the CandidatePortalPages
     */
    public static CandidatePortalPages clickPreviousButton(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.waitForElementToBeClickable(getInstance().previousButton);
        SeleniumTest.click(getInstance().previousButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks Go To Next of Form Complete button.  If it's form complete and there are no validation errors
     * it will go to the next page, otherwise it'll be the current page
     * @param returnedClass this should be the current page, or the next page
     * @return
     */
    public static CandidatePortalPages clickRichFormNavigationButton( Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(getInstance().richFormNavigationButton);
        SeleniumTest.waitForJQueryAjaxDone();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks the Save button on the Rich Text Form.
     */
    public static void clickSaveButton() {
        //TODO investigate why the button.click doesn't work
        SeleniumTest.click(Driver.getDriver().findElement(By.xpath("//button[contains(@id,'-previousnextbuttons-savebutton')]")));
    }

    public static WebElement getFormTitle() {
        return getInstance().formTitle;
    }

    public static WebElement getNavigationButton() {
        return getInstance().richFormNavigationButton;
    }

    /**
     * Checks if the Navigation button on the current rich forms page is the supplied color.
     *
     * @return True if the Navigation button on the current rich forms page is the supplied color.
     */
    public static boolean isNavigationButtonColor(NavigationButtonColor color) {
        return getInstance().richFormNavigationButtonDiv.getAttribute("class").equals(color.getCssClass());
    }
}