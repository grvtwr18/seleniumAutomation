package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.I9.ListAEligibilityDocument;
import Sites.CandidatePortal.Forms.Objects.I9.ListBEligibilityDocument;
import Sites.CandidatePortal.Forms.Objects.I9.ListCEligibilityDocument;
import Sites.CandidatePortal.Forms.Objects.I9.Section2;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.io.File;

/**
 * Created by abrackett on 10/18/16.
 * Handles Candidate Upload Documents Form for 3 step I-9
 */
public class Form_17060 {

    static {
        PageFactory.initElements(Driver.getDriver(), Form_17060.class);
    }


    /**
     * Contains the choose List A and List B and C
     */
    public static class EmployerReview extends Sites.CandidatePortal.Forms.Objects.I9.Section2
            .EmployerReview {
    }


    /**
     * Contains the previous, save and next buttons
     */
    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {
    }


    /**
     * Contains List A, B and C Document choices and data
     */
    public static class Documents extends Section2.Documents {
    }


    /**
     * Contains browse and attach widget to upload documents
     */
    public static class UploadDocuments extends Section2.UploadDocuments {
    }

    public static void fillListADocument(ListAEligibilityDocument document) {
        Form_17060.Documents.ListA.selectListADocument(document.getListADocument());
    }

    public static void fillListBDocument(ListBEligibilityDocument document) {
        Form_17060.Documents.ListB.selectlistBDocument(document.getListBDocument());
    }

    public static void fillListCDocument(ListCEligibilityDocument document) {
        Form_17060.Documents.ListC.selectListCDocument(document.getListCDocument());
    }

    public static void uploadDocument(File file) {
        Form_17060.UploadDocuments.setFileToUpload(file.getAbsolutePath());
        Form_17060.UploadDocuments.clickUploadFile();
    }

    public static void upload2ndDocument(File file) {
        Form_17060.UploadDocuments.set2ndFileToUpload(file.getAbsolutePath());
        Form_17060.UploadDocuments.clickUploadFile();
    }
    public static void upload3rdDocument(File file) {
        Form_17060.UploadDocuments.set3rdFileToUpload(file.getAbsolutePath());
        Form_17060.UploadDocuments.clickUploadFile();
    }
    public static void upload4thDocument(File file) {
        Form_17060.UploadDocuments.set4thFileToUpload(file.getAbsolutePath());
        Form_17060.UploadDocuments.clickUploadFile();
    }
    @FindBy(how = How.CSS, using = "input[id$='_9']")
    public static WebElement iAcknowledgeCheckBox;

    @FindBy(how = How.CSS, using = "label[for$='_9']")
    public static WebElement iAcknowledgeCheckBoxLabel;

    public static void checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
    }

    public static void uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
    }
}
