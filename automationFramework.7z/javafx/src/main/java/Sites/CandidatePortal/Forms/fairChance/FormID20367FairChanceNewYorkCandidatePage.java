package Sites.CandidatePortal.Forms.fairChance;

import Sites.CandidatePortal.Forms.individualizedReview.IrWorkflowPages;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

/**
 * @author sbashar
 */
public class FormID20367FairChanceNewYorkCandidatePage extends IrWorkflowPages {

    /**
     * Returns whether or not you are on this page.
     * @return true or false
     */
    public static boolean onPage() {
        try {
            return Driver.getDriver().findElement(By.id("20367-formtitle")).getText()
                    .startsWith("Fair Chance Form - New York");
        } catch (NoSuchElementException nse) {
            return false;
        }
    }
}
