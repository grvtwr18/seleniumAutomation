package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.PortalSignInPage;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import Utility.URLParameters;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

/**
 * Created by jgupta on 8/13/2015.
 */
public class FormID87253001ProfilePage extends FormPage {
    @FindBy(how = How.ID, using = "87253002-87253002_1")
    private static WebElement testFieldOne_no_no_noTextBox;

    @FindBy(how = How.ID, using = "tasknoteMessage")
    private WebElement reviewerNotes;

    @FindBy(how = How.CSS, using = "button")
    private WebElement launchTaskButton;

    @FindBy(how = How.CSS, using = "input[fieldname='First Name']")
    private static WebElement firstNameTextbox;

    @FindBy(how = How.ID, using = "87253001-qmi-87253001_2-100_2")
    private static WebElement middleNameTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Last Name']")
    private static WebElement lastNameTextbox;

    @FindBy(how = How.ID, using = "87253001-87253001_4")
    private WebElement suffixTextbox;

    @FindBy(how = How.CSS, using = "label.checkboxLabel")
    private static WebElement noMiddleNameCheckbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Social Security Number']")
    private static WebElement ssnTextbox;

    @FindBy(how = How.ID, using = "87253001-87253001_6-87253001_6")
    private static WebElement dobTextbox;

    @FindBy(how = How.ID, using = "87253001-87253001_6")
    private static WebElement hiddenDobTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Street address']")
    private static WebElement streetAddressTextbox;

    @FindBy(how = How.ID, using = "87253001-address87253001_9-87253001_10")
    private static WebElement aptNumberTextbox;

    @FindBy(how = How.ID, using = "87253001-address87253001_9-87253001_10")
    private static WebElement cityTextbox;

    @FindBy(how = How.ID, using = "87253001-address87253001_9-87253001_9")
    private static WebElement countryDropdown;

    @FindBy(how = How.ID, using = "87253001-address87253001_9-87253001_11")
    private static WebElement stateDropdown;

    @FindBy(how = How.ID, using = "87253001-address87253001_9-87253001_12")
    private static WebElement zipTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Primary Phone']")
    private static WebElement primaryPhoneNumberTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Other Phone']")
    private WebElement otherPhoneTextbox;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private static WebElement saveButton;

    @FindBy(how = How.ID, using = "returnbtn")
    private static WebElement returnButton;

    @FindBy(how = How.LINK_TEXT, using = "Form Data Test Profile Page")
    private WebElement formDataTestProfilePageLink;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    @FindBy(how = How.CSS, using = "div.title")
    private WebElement title;

    @FindBy(how = How.LINK_TEXT, using = "Candidate Custom Fields")
    private static WebElement candidateCustomFieldsLink;

    /**
     * Constructs a new Profile page object.
     *
     * @author guptaj
     */
    public FormID87253001ProfilePage() {

    }

    /**
     * Method to fill profile information in the form with middle name
     *
     * @param firstName
     * @param midName
     * @param lastName
     * @param ssn
     * @param dob
     */
    public static void fillProfileForm(String firstName, String midName, String lastName, String ssn, String dob) {
        SeleniumTest.waitForElementVisible(firstNameTextbox);
        SeleniumTest.clearAndSetText(firstNameTextbox, firstName);
        noMiddleNameCheckbox.click();
        middleNameTextbox.sendKeys(midName);

        SeleniumTest.clearAndSetText(lastNameTextbox, lastName);

        SeleniumTest.clearAndSetText(ssnTextbox, ssn);
        LocalDate dateOfBirth = LocalDate.parse(dob, LocaleHelper.getDateFormatShortDateSlash()); // "MM/dd/yyyy" for US

        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(dateOfBirth, dobTextbox.getAttribute("id"), hiddenDobTextbox.getAttribute("id"));
    }

    /**
     * Enters Date of Birth
     */
    public void typeDOB(String dob) {
        SeleniumTest.clearAndSetText(dobTextbox, dob);
    }

    /**
     * Click on the save button.
     */
    public static void save() {
        saveButton.click();
        SeleniumTest.waitForElementVisible(candidateCustomFieldsLink);
    }

    /**
     * Click on Next button
     *
     * @return
     */
    public static FormID87253002CandidateCustomFieldsPage clickNext() {
        nextButton.click();
        SeleniumTest.waitForPageLoad();
        SeleniumTest.waitMs(2000);
        SeleniumTest.waitForElementVisible(testFieldOne_no_no_noTextBox);
        return PageFactory.initElements(Driver.getDriver(), FormID87253002CandidateCustomFieldsPage.class);
    }

    /**
     * Method to fill Address information in the form.
     *
     * @param streetAddress
     * @param apt
     * @param city
     * @param country
     * @param state
     * @param zip
     */
    public static void fillAddressInformation(String streetAddress, String apt, String city, String country, String state, String zip) {
        SeleniumTest.clearAndSetText(streetAddressTextbox, streetAddress);

        SeleniumTest.clearAndSetText(aptNumberTextbox, apt);

        SeleniumTest.clearAndSetText(cityTextbox, city);

        Select countryDD = new Select(countryDropdown);
        if (country.length() < 3)
            countryDD.selectByValue(country);
        else
            countryDD.selectByVisibleText(country);

        Select stateDD = new Select(stateDropdown);
        if (state.length() < 3)
            stateDD.selectByValue(state);
        else
            stateDD.selectByVisibleText(state);

        SeleniumTest.clearAndSetText(zipTextbox, zip);
    }

    /**
     * Selects State from State dropdown
     *
     * @param state
     */
    public void selectState(String state) {
        Select stateDD = new Select(stateDropdown);
        stateDD.selectByValue(state);
    }

    /**
     * Method to type Primary and other phone number
     *
     * @param primaryPhone
     * @param otherPhone
     */
    public void contactInformation(String primaryPhone, String otherPhone) {
        SeleniumTest.clearAndSetText(primaryPhoneNumberTextbox, primaryPhone);

        SeleniumTest.clearAndSetText(primaryPhoneNumberTextbox, otherPhone);
    }

    /**
     * Method to type only the Primary Phone number
     *
     * @param primaryPhone
     */
    public static void contactInformation(String primaryPhone) {
        SeleniumTest.clearAndSetText(primaryPhoneNumberTextbox, primaryPhone);
    }

    /**
     * This method clicks on Return button to return the form back to candidate
     *
     * @return
     */
    public static ReturnWidgetPage clickReturnButton() {
        WaitUntil.waitUntil(() ->
                returnButton.isDisplayed());
        returnButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }

    /**
     * This method allows the verifier to type his review notes while returning the form back to candidate.
     *
     * @return
     */
    public String getReviewerNotes() {
        return reviewerNotes.getText().toString();
    }

    /**
     * This method returns the list of all links on the page.
     *
     * @return
     */
    public List getAllLinks() {
        List<WebElement> links = Driver.getDriver().findElements(By.tagName("a"));
        return links;
    }

    /**
     * Returns task id from the url.
     *
     * @return
     */
    public static String getTaskIDFromURL() {
        URLParameters parameters = new URLParameters();
        HashMap<String, String> valueMap = parameters.getValue(Driver.getDriver().getCurrentUrl());
        return valueMap.get("TaskID");
    }

    /**
     * Clicks on Sign Out link at top right of the page.
     *
     * @return
     */
    public static PortalSignInPage clickSignOutLink() {
        signOutLink.click();
        Driver.getDriver().manage().deleteAllCookies();
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Fills SSN
     *
     * @param ssn SSN to use
     */
    public void fillSSN(String ssn) {
        SeleniumTest.clearAndSetText(ssnTextbox, ssn);
    }


    /**
     * Fills DOB
     *
     * @param dob DOB to use
     */
    public void fillDOB(String dob) {
        SeleniumTest.clearAndSetText(dobTextbox, dob);
        dobTextbox.sendKeys(Keys.TAB);
    }

    /**
     * Fills DOB
     *
     * @param dob DOB to use
     */
    public void fillDOB(LocalDate dob) {
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(dob, dobTextbox.getAttribute("id"), hiddenDobTextbox.getAttribute("id"));
    }

    /**
     * Fills in the default values for the Profile page taking a Candidate Object as a parameter
     *
     * @param theCandidate
     * @return
     */
    public FormID87253001ProfilePage fillDefaultValues(Candidate theCandidate) {
        fillSSN(theCandidate.getSocialSecurityNumber());
        fillDOB(theCandidate.getDOB());
        fillAddressInformation(theCandidate.getAddressLine1(), theCandidate.getApartmentNumber(), theCandidate.getCity(), theCandidate.getCountryOrRegion(), theCandidate.getState(), theCandidate.getZip());
        contactInformation(theCandidate.getCandidatePhone());
        return this;
    }

    /**
     * Clicks on Candidate custom fields link in left nav
     *
     * @return
     */
    public static FormID87253002CandidateCustomFieldsPage clickCandidateCustomFieldsLink() {
        candidateCustomFieldsLink.click();
        return PageFactory.initElements(Driver.getDriver(), FormID87253002CandidateCustomFieldsPage.class);
    }
}
