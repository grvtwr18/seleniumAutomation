package Sites.CandidatePortal.Forms;

/**
 * Created by jayagupta on 4/23/18.
 */
public class FormId97000002WotcPage extends FormPage {
    public static boolean isWotcMessageVisible() {
        //TODO Click return if WOTC message is displayed.
        return false; //Will change on implementation.
    }
}
