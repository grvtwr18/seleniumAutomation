package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 2/22/2016.
 */
public class FormID5998OfferLetter extends FormPage {
    @FindBy(how = How.CSS, using = "label.checkboxLabel")
    private static WebElement signHereCheckBox;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    /**
     * Clicks the Sign Here checkbox.
     * Seemingly it has no way to determine whether it's really checked or not.
     */
    public static void clickSignHereCheckBox() {
        signHereCheckBox.click();
    }

    /**
     * Click on Next button
     * @return
     */
    public static FormID10eSignFormsPage clickNext() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID10eSignFormsPage.class);
    }
}
