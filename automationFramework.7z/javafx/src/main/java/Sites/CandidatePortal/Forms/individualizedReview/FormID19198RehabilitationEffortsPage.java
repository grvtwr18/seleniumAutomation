package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.ReturnWidgetPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * This file contains methods to interact with Rehabilitation efforts page.
 * Created by jgupta on 10/1/2017.
 */
public class FormID19198RehabilitationEffortsPage extends IrWorkflowPages {
    @FindBy(how = How.CSS, using = "#returnbtn")
    private static WebElement returnButton;

    public static void typeDescription(String description) {
        SeleniumTest.clearAndSetText(By.id("19198-19198_3"), description);
    }

    public static CandidatePortalPages typeDescriptionAndSubmit(String description, Class<? extends
            CandidatePortalPages> returnedClass) {
        typeDescription(description);
        return FormID19198RehabilitationEffortsPage.clickNext(returnedClass);
    }

    public static ReturnWidgetPage clickReturnBtn() {
        SeleniumTest.click(returnButton);
        return PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }
}
