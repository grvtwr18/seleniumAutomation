package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;
import TWFramework.SeleniumTest;


public class FormID22537W4Page extends FormPage {
    @FindBy(how = How.XPATH, using = "//label[@for='22537-22537_1_Single']")
    private WebElement maritalStatusSingle;

    @FindBy(how = How.CSS, using = "label[for='22537-22537_1_Married']")
    private WebElement marriedRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='22537-22537_1_Married, but withholding at the higher single rate']")
    private WebElement marriedButWithholdHigherSingleRateRadioBtn;

    @FindBy(how = How.ID, using = "22537-22537_25")
    private WebElement allowanceBox;

    @FindBy(how = How.ID, using = "22537-22537_26")
    private WebElement additionalAmountBox;

    @FindBy(how = How.ID, using = "22537-22537_37")
    private WebElement exemptionCode;

    @FindBy(how = How.ID, using = "22537-22537_39")
    private WebElement exemptBox;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private WebElement nextButton;

    /**
     * Click on Next button
     * @return
     */
    @FindBy(how = How.CSS, using = "label.checkboxLabel.formFieldLabelRequired")
    private WebElement acknowledgementCheckbox;

    static {
        PageFactory.initElements(Driver.getDriver(), FormID22537W4Page.class);
    }

    public static FormID22537W4Page getInstance() {
        return PageFactory.initElements(Driver.getDriver(), FormID22537W4Page.class);
    }

    public void selectMaritalStatus(String maritalStatus) {
        if(maritalStatus=="Single")
            maritalStatusSingle.click();
        else if(maritalStatus=="Married")
            marriedRadioBtn.click();
        else if(maritalStatus=="Married, but withhold at higher Single rate.")
            marriedButWithholdHigherSingleRateRadioBtn.click();
    }

    public void setNumberOfAllowances(String number) {
        SeleniumTest.clearAndSetText(allowanceBox, number);

    }

    public void setAdditionalAmount(String amount) {
        SeleniumTest.clearAndSetText(additionalAmountBox, amount);
    }

    public void setExemptionCode(String code) {
        SeleniumTest.clearAndSetText(exemptionCode, code);
    }

    public void setExempt(String text) {
        SeleniumTest.clearAndSetText(exemptBox, text);
    }

    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        if (!acknowledgementCheckbox.isSelected()) {
            acknowledgementCheckbox.click();
        }

        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
