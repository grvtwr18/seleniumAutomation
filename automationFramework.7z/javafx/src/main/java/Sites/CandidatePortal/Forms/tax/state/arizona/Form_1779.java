package Sites.CandidatePortal.Forms.tax.state.arizona;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_1779 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='1779-1779_5_Yes']")
    private WebElement completeFormA4CYesRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1779-1779_5_No']")
    private WebElement completeFormA4CNoRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1779-1779_48']")
    public WebElement creditAmountLabel;

    @FindBy(how = How.ID, using = "1779-1779_48")
    private WebElement creditAmountTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1779-1779_50']")
    public WebElement iConfirmCheckboxLabel;

    @FindBy(how = How.ID, using = "1779-1779_50")
    private WebElement iConfirmCheckbox;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_1779() {

    }

    public static Form_1779 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_1779.class);
    }

    public Form_1779 chooseCompleteFormA4CYesRadiobutton() {
        completeFormA4CYesRadiobutton.click();
        logger.info("Complete Form A4 Yes Radiobutton Chosen");
        return this;
    }

    public Form_1779 chooseCompleteFormA4CNoRadiobutton() {
        completeFormA4CNoRadiobutton.click();
        logger.info("Complete Form A4 No Radiobutton Chosen");
        return this;
    }

    public String getCreditAmount() {
        return creditAmountTextbox.getText();
    }

    public Form_1779 setCreditAmount(String amount) {
        SeleniumTest.clearAndSetText(creditAmountTextbox, amount);
        logger.info("Credit Amount set to {}", amount);
        return this;
    }

    public Form_1779 checkIConfirm() {
        SeleniumTest.check(iConfirmCheckboxLabel, iConfirmCheckbox);
        logger.info("I Confirm Checked");
        return this;
    }

    public Form_1779 uncheckIConfirm() {
        SeleniumTest.unCheck(iConfirmCheckboxLabel, iConfirmCheckbox);
        logger.info("I Confirm unchecked");
        return this;
    }

    public Form_1779 fillRequiredFields(boolean completeFormA4C, String creditAmount) {
        if (completeFormA4C) {
            chooseCompleteFormA4CYesRadiobutton();
            setCreditAmount(creditAmount);
            checkIConfirm();
        } else {
            chooseCompleteFormA4CNoRadiobutton();
        }
        return this;
    }
}
