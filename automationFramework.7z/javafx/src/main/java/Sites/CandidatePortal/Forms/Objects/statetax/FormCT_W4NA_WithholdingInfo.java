package Sites.CandidatePortal.Forms.Objects.statetax;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 8/3/17.
 */
public class FormCT_W4NA_WithholdingInfo {

    @FindBy(how = How.CSS, using = "input[id$='1787_9']")
    private WebElement totalWorkingDaysTextBox;

    @FindBy(how = How.CSS, using = "input[id$='1787_11']")
    private WebElement totalDaysPhysicallyInConnecticutForEmploymentTextBox;

    @FindBy(how = How.CSS, using = "input[id$='1787_13']")
    private WebElement totalDaysPhysicallyInConnecticutForEmploymentButNotWorkingTextBox;

    @FindBy(how = How.CSS, using = "input[id$='1787_15']")
    private WebElement calculatedDaysWorkingInConnecticutTextBox;

    @FindBy(how = How.CSS, using = "input[id$='1787_17']")
    private WebElement percentageOfDaysWorkingInConnecticutTextBox;

    public FormCT_W4NA_WithholdingInfo() {

    }

    public static FormCT_W4NA_WithholdingInfo getInstance() {
        return PageFactory.initElements(Driver.getDriver(), FormCT_W4NA_WithholdingInfo.class);
    }

    public int getTotalWorkingDays() {
        return Integer.parseInt(totalWorkingDaysTextBox.getText());
    }

    public FormCT_W4NA_WithholdingInfo setTotalWorkingDays(int numberOfDays) {
        SeleniumTest.clearAndSetText(totalWorkingDaysTextBox, Integer.toString(numberOfDays));
        return this;
    }

    public String getTotalDaysPhysicallyInConnecticutForEmployment() {
        return totalDaysPhysicallyInConnecticutForEmploymentTextBox.getText();
    }

    public FormCT_W4NA_WithholdingInfo setTotalDaysPhysicallyInConnecticutForEmployment(
            int numberOfDays) {
        SeleniumTest.clearAndSetText(totalDaysPhysicallyInConnecticutForEmploymentTextBox,
                                     Integer.toString(numberOfDays));
        return this;
    }

    public String getTotalDaysPhysicallyInConnecticutForEmploymentButNotWorking() {
        return totalDaysPhysicallyInConnecticutForEmploymentButNotWorkingTextBox.getText();
    }

    public FormCT_W4NA_WithholdingInfo setTotalDaysPhysicallyInConnecticutForEmploymentButNotWorking(
            int numberOfDays) {
        SeleniumTest
                .clearAndSetText(totalDaysPhysicallyInConnecticutForEmploymentButNotWorkingTextBox,
                                 Integer.toString(numberOfDays));
        return this;
    }

    public String getCalculatedDaysWorkingInConnecticut() {
        return calculatedDaysWorkingInConnecticutTextBox.getText();
    }

    public FormCT_W4NA_WithholdingInfo setCalculatedDaysWorkingInConnecticut(int numberOfDays) {

        SeleniumTest.clearAndSetText(calculatedDaysWorkingInConnecticutTextBox,
                                     Integer.toString(numberOfDays));
        return this;
    }

    public String getPercentageOfDaysWorkingInConnecticutTextBox() {
        return percentageOfDaysWorkingInConnecticutTextBox.getText();
    }

    /**
     * Sets the percentage as an integer (whole percentage only)
     * @param wholePercentage integer representation of percentage
     */
    public FormCT_W4NA_WithholdingInfo setPercentageOfDaysWorkingInConnecticut(
            int wholePercentage) {

        SeleniumTest.clearAndSetText(percentageOfDaysWorkingInConnecticutTextBox,
                                     Integer.toString(wholePercentage));
        return this;
    }

}
