package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 1/20/2016.
 */
public class FormID2844ConfidentialInformation extends FormPage {
    @FindBy(how = How.XPATH, using = "//label[@for='2844-2844_30']")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='2844-2844_33_Yes']")
    private WebElement yesRadioButton;

    @FindBy(how = How.XPATH, using = "//label[@for='2844-2844_33_No']")
    private WebElement noRadioButton;

    @FindBy(how = How.XPATH, using = "//label[@for='2844-2844_91']")
    private WebElement iAcknowledgeCheckbox2;

    @FindBy(how = How.ID, using = "2844-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * Checks I Acknowledge
     * @return
     */
    public FormID2844ConfidentialInformation clickIAcknowledge1() {
        SeleniumTest.waitForElementEnabled(By.id("2844-2844_30"));
        if(!Driver.getDriver().findElement(By.id("2844-2844_30")).isSelected())
            iAcknowledgeCheckbox.click();
        return this;
    }

    /**
     * Chooses Yes Radio Button
     * @return
     */
    public FormID2844ConfidentialInformation clickYesRadioButton() {
        yesRadioButton.click();
        return this;
    }

    /**
     * Chooses No Radio Button
     * @return
     */
    public FormID2844ConfidentialInformation clickNoRadioButton() {
        noRadioButton.click();
        return this;
    }

    /**
     * Checks I Acknowledge #2
     * @return
     */
    public FormID2844ConfidentialInformation clickIAcknowledge2() {
        if(!Driver.getDriver().findElement(By.id("2844-2844_91")).isSelected())
            iAcknowledgeCheckbox2.click();
        return this;
    }

    /**
     * Clicks Next
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

}
