package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.PortalSignInPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 1/19/2016.
 */
public class DocuSignReviewStandaloneI9Page extends FormPage {
    @FindBy(how = How.ID, using = "action-bar-btn-continue")
    private static WebElement continueButton;

    @FindBy(how = How.ID, using = "ds_hldrBdy_navnexttext_btnInline")
    private static WebElement startButton;

    @FindBy(how = How.CSS, using = "input[tabtype='SignHere']")
    private static WebElement signButton;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    /**
     * Clicks on Continue button
     */
    public static void clickContinueButton() {
        SeleniumTest.switchToFrame(By.id("iFrameDocuSign"));
        SeleniumTest.waitForElementEnabled(continueButton);
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 4);
        continueButton.click();
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 4);
    }

    /**
     * Clicks on Start Button
     */
    public static void clickStartButton() {
        SeleniumTest.switchToFrameById("iFrameDocuSign","signingIframe");
//        SeleniumTest.switchToFrame(By.id("iFrameDocuSign"));
//        SeleniumTest.getAllIframes();
        startButton.click();
    }

    /**
     * Click on Sign button
     */
    public static AdoptAndSignPage clickSignButton() {
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 20);
        signButton.click();
        return PageFactory.initElements(Driver.getDriver(), AdoptAndSignPage.class);
    }

    /**
     * Clicks on Finish button
     */
    public static ESigningCompleteForI9Page clickFinishButton() {
        Driver.getDriver().switchTo().defaultContent();
        SeleniumTest.switchToFrame(By.id("iFrameDocuSign"));
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 20);
        SeleniumTest.waitForElementVisible(By.id("action-bar-bottom-btn-finish")).click();
        return PageFactory.initElements(Driver.getDriver(), ESigningCompleteForI9Page.class);
    }

    /**
     * Clicks on Sign Out Link.
     * @return
     */
    public static PortalSignInPage clickSignOutLink() {
        Driver.getDriver().switchTo().defaultContent();
        signOutLink.click();
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }
}
