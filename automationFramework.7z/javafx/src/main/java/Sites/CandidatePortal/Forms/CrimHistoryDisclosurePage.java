package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by jgupta on 3/26/2017.
 */
public class CrimHistoryDisclosurePage extends FormPage {

    /**
     * Click on Yes or no radio button in Criminal History Disclosure section on candidate portal
     */
    public static void clickCrimHistoryDisclosureYesRadioBtn() {
        Actions action = new Actions(Driver.getDriver());
        WebElement yesRadioBtn = Driver.getDriver().findElement(By.xpath("//form[@id='UberSearch']//label[contains(text(),'No')]/following-sibling::input"));
        action.moveToElement(yesRadioBtn).click().build().perform();
    }

    /**
     * Type the offense history description in the text area. 
     * @param offenseDescription
     */
    public static void typeOffenseHistory(String offenseDescription) {
        clickCrimHistoryDisclosureYesRadioBtn();
        Actions action = new Actions(Driver.getDriver());
        WebElement offenseTextArea = Driver.getDriver().findElement(By.xpath("//form[@id='UberSearch']//label[contains(text(),'Yes')]/following-sibling::div/textarea"));
        action.moveToElement(offenseTextArea).sendKeys(offenseDescription).build().perform();
    }
}
