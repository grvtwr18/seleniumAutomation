package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MichiganStateForm extends CandidatePortalPages {
    protected static final Logger staticLogger = LoggerFactory.getLogger(MichiganStateForm.class);

    @FindBy(how = How.XPATH,using = "//*[@fieldname='License Number']")
    private WebElement licenseNumberTextbox;

    @FindBy(how = How.ID, using = "1823-1823_8-err")
    private WebElement licenseNumberErrorMessage;

    @FindBy(how = How.XPATH, using = "//label[@for='1823-1823_9_No']")
    private WebElement newEmployeeNoLabel;

    @FindBy(how = How.ID,using = "1823-1823_9-err")
    private WebElement newEmployeeLabelErrorMessage;

    @FindBy(how = How.ID, using = "1823-1823_9_No")
    private WebElement newEmployeeNoRadioButton;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Total Exemptions']")
    private WebElement totalExcemptionDropDown;

    @FindBy(how = How.XPATH,using = "//input[@fieldname='Additional Withholding']")
    private WebElement additionalWithholdingTextbox;

    @FindBy(how = How.XPATH,using = "//select[@fieldname='Withholding Status']")
    private WebElement withholdingStatusDropDown;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Reason']")
    private WebElement reasonDropdown;

    @FindBy(how = How.XPATH,using = "//label[@for='1823-1823_24']")
    private WebElement iCertifyLabel;

    @FindBy(how = How.ID,using = "1823-1823_24")
    private WebElement iCertifyCheckbox;

    @FindBy(how = How.ID, using = "1823-1823_24-err")
    private WebElement iCertifyErrorMessage;

    @FindBy(how = How.XPATH,using = "//select[@fieldname='Residency Statement']")
    private WebElement residencyStatementDropDown;

    @FindBy(how = How.XPATH,using = "//select[@fieldname='Employment Statement']")
    private WebElement employeeStatementDropDown;

    @FindBy(how = How.XPATH,using = "//button[@value='Next']")
    private WebElement nextButton;

    public void enterLicenseNumber(String number)
    {
        SeleniumTest.clearAndSetText(licenseNumberTextbox,number);
    }

    public void selectNewEmployeeStatusAsNo()
    {
        SeleniumTest.click(newEmployeeNoLabel);
    }

    public void selectTotalExcemptions(String totalExcemptionCount)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(totalExcemptionDropDown,totalExcemptionCount);
    }

    public void enterAdditionalWithholdings(String amount)
    {
        SeleniumTest.clearAndSetText(additionalWithholdingTextbox,amount);
    }

    public void selectWithholdingStatus(String status)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(withholdingStatusDropDown,status);
    }

    public void selectReason(String reason)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(reasonDropdown,reason);
    }

    public void checkIcertify()
    {
        SeleniumTest.check(iCertifyLabel,iCertifyCheckbox);
    }

    public void selectResidencyStatement(String statement)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropDown,statement);
    }

    public void selectEmployeementStatement(String statement)
    {
        SeleniumTest.selectByVisibleTextFromDropDown(employeeStatementDropDown,statement);
    }

    public void clickNext()
    {
        SeleniumTest.click(nextButton);
    }

    public boolean areErrorsForMandatoryFieldsVisible()
    {
        if(SeleniumTest.isElementVisibleNoWaiting(By.id("1823-1823_8-err")))
        {
            if(SeleniumTest.isElementVisibleNoWaiting(By.id("1823-1823_9-err")))
            {
                if(SeleniumTest.isElementVisibleNoWaiting(By.id("1823-1823_24-err")))
                {
                    return true;
                }
            }
        }
        return false;
    }

    public CandidatePortalPages clickNextBtn(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}

