package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.time.LocalDate;

/**
 * This file contains methods needed to interact with Related employment page.
 * Created by jgupta on 10/1/2017.
 */
public class FormID19196RelatedEmploymentPage extends IrWorkflowPages {
    /**
     * Types name of employer in text box.
     */
    public static void typeNameOfEmployer(int index, String nameOfEmployer) {
        SeleniumTest
                .clearAndSetText(By.id("19196-history-1-19196_7-19196_7_" + index), nameOfEmployer);
    }

    public static void typePhoneNumber(int index, String phoneNumber) {
        SeleniumTest.clearAndSetText(By.id("19196-history-1-19196_7-19196_8_" + index), phoneNumber);
    }

    public static void typeEmailAddress(int index, String emailAddress) {
        SeleniumTest.clearAndSetText(By.id("19196-history-1-19196_7-19196_9_" + index), emailAddress);
    }

    public static void typeStartDate(int index, LocalDate date) {
        WebElement startDateBox = Driver.getDriver().findElement(By.id
                        ("19196-history-1-19196_7-19196_10_0-19196_10_" + index));
        String hiddenStartDateBox = "19196-history-1-19196_7-19196_10_" + index;
        startDateBox.clear();
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(date, startDateBox.getAttribute("id"), hiddenStartDateBox);
    }

    public static void typeEndDate(int index, LocalDate date) {

        WebElement endDateBox = Driver.getDriver().findElement(By.id
                ("19196-history-1-19196_7-19196_11_0-19196_11_" + index));
        String hiddenEndDateBoxId = "19196-history-1-19196_7-19196_11_" + index;
        endDateBox.clear();
        SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(date,
                endDateBox.getAttribute("id"), hiddenEndDateBoxId);
    }

    public static void typeDescription(int index, String description) {
        SeleniumTest.clearAndSetText(By.id("19196-history-1-19196_7-19196_12_" + index),
                description);
    }

    public static void fillRelatedEmployment(int index, String nameOfEmployer, String phone, String email,
            LocalDate startDateOfEmployment, LocalDate endDateOfEmployment, String description) {
        typeNameOfEmployer(index, nameOfEmployer);
        typePhoneNumber(index, phone);
        typeEmailAddress(index, email);
        typeStartDate(index, startDateOfEmployment);
        typeEndDate(index, endDateOfEmployment);
        typeDescription(index, description);
    }

    public static CandidatePortalPages fillRelatedEmploymentAndSubmit(int index, String nameOfEmployer,
            String employerPhone, String employerEmail, LocalDate startDateOfEmployment, LocalDate endDateOfEmployment,
            String description, Class<? extends CandidatePortalPages> returnedClass) {
        fillRelatedEmployment(index, nameOfEmployer, employerPhone, employerEmail, startDateOfEmployment,
                endDateOfEmployment, description);
        return FormID19196RelatedEmploymentPage.clickNext(returnedClass);
    }
}
