package Sites.CandidatePortal.Forms.eDispute;

/**
 * Created by jgupta on 11/5/2017.
 */
public class DisputeEnums {

    public enum ProductLine {
        EMPLOYMENT,
        EDUCATION,
        MOTOR_VEHICLE_REGISTRATION;
    }

    public enum ReasonForDisputeMvr {
        VIOLATION_INACCURATE("A violation and/or infraction on the report is inaccurate", "201"),
        MY_DRIVERS_LICENSE_IS_VALID("My driver's license is valid", "202"),
        OTHER("Other (use comments)", "OTHER");

        private String reason;
        private String value;

        ReasonForDisputeMvr(String reason, String value) {
            this.reason = reason;
            this.value = value;
        }

        public String toString() {
            return reason;
        }

        public String getValue() {
            return value;
        }
    }

    public enum ReasonForDisputeEducation {
        INCORRECT_DATES_OF_ATTENDANCE("Incorrect dates of attendance verified", "301"),
        INCORRECT_GRADUATION_STATUS("Incorrect graduation status verified", "302"),
        INCORRECT_DEGREE("Incorrect degree verified", "303"),
        INCORRECT_MAJOR("Incorrect major verified", "304"), OTHER("Other (use comments)", "305");

        private String reason;
        private String value;

        ReasonForDisputeEducation(String reason, String value) {
            this.reason = reason;
            this.value = value;
        }

        public String toString() {
            return reason;
        }

        public String getValue() {
            return value;
        }
    }

    public enum ReasonForDisputeEmployment {
        INCORRECT_DATES("Incorrect dates verified", "401"),
        INCORRECT_SALARY("Incorrect salary verified", "402"),
        INCORRECT_JOB_TITLE("Incorrect job title verified", "403"),
        INCORRECT_ELIGIBILITY_FOR_RE_HIRE("Incorrect eligibility for re-hire verified", "404"),
        INCORRECT_REASON_FOR_LEAVING("Incorrect reason for leaving verified", "405"),
        OTHER("Other (use comments)", "OTHER");

        private String reason;
        private String value;

        ReasonForDisputeEmployment(String reason, String value) {
            this.reason = reason;
            this.value = value;
        }

        public String toString() {
            return reason;
        }

        public String getValue() {
            return value;
        }
    }

}
