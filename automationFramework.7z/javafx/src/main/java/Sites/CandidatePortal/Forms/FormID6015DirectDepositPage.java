package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import Workflows.candidate.CandidateBankAccount;
import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

/**
 * Created by btorbert on 8/29/16.
 */
public class FormID6015DirectDepositPage extends CandidatePortalPages {

    @FindBy(how = How.CSS, using = "label[for='6015-283_1_Yes']")
    private WebElement electDirectDepositRadioButtonValueYes;

    @FindBy(how = How.CSS, using = "label[for='6015-283_1_No']")
    private WebElement electDirectDepositRadioButtonValueNo;

    @FindBy(how = How.CSS, using = "input[id='6015-283_15']")
    private WebElement nameAsItAppearsOnTheAccountTextBox;

    @FindBy(how = How.CSS, using = "label[for='6015-6015_129']")
    private WebElement acknowledgementCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='6015-283_6_Checking']")
    private WebElement accountTypeRadioButtonValueChecking;

    @FindBy(how = How.XPATH, using = "//label[@for='6015-283_7_Net Check']")
    private WebElement depositAmountRadioButtonValueNetCheck;

    @FindBy(how = How.ID, using = "6015-283_9")
    private WebElement bankNameTextbox;

    @FindBy(how = How.ID, using = "6015-283_10")
    private WebElement routingNumberTextbox;

    @FindBy(how = How.ID, using = "6015-283_11")
    private WebElement accountNumberTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='6015-283_14_Yes']")
    private WebElement accountNameSameRadioButtonValueYes;

    @FindBy(how = How.XPATH, using = "//label[@for='6015-283_19_No']")
    private WebElement anotherAccountDepositValueNo;

    @FindBy(how = How.ID, using = "1037-283_16-filebrowse")
    private WebElement browseFile;

    @FindBy(how = How.CSS, using = "button.btnPostFileToServer.button")
    private WebElement uploadFileButton;

    @FindBy(how = How.ID, using = "6015-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "6015-283_16-filebrowse")
    private WebElement filePathBox;

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    /**
     * Selects the radio button "Yes" for elect Direct Deposit
     */
    public void electDirectDeposit() {
        SeleniumTest.waitForElementVisible(
                electDirectDepositRadioButtonValueYes, SeleniumTest.FLUENTWAIT_TIMEOUT, SeleniumTest.POLLING_TIMEOUT);
        electDirectDepositRadioButtonValueYes.click();
    }

    /**
     * Checks the "I acknowledge" checkbox
     */
    public void setAcknowledgementCheckbox() { acknowledgementCheckbox.click(); }

    /**
     * Do not deposit another account check
     */
    public void setAnotherAccountDepositValueNo()
    {
        anotherAccountDepositValueNo.click();
    }

    /**
     * Selects the radio button "Yes" for elect Direct Deposit
     */
    public void setAccountTypeRadioButtonValueChecking() { accountTypeRadioButtonValueChecking.click(); }

    /**
     * Set the deposit about to match the net check amount
     */
    public void setDepositAmountRadioButtonValueNetCheck()
    {
        depositAmountRadioButtonValueNetCheck.click();
    }

    /**
     * Sets the bank name passed to the method
     * @param bankName
     */
    public void setBankNameTextbox(String bankName)
    {
        SeleniumTest.clearAndSetText(bankNameTextbox, bankName);
    }

    /**
     * Sets account number passed to the method
     * @param accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        SeleniumTest.clearAndSetText(accountNumberTextbox, accountNumber);
    }

    /**
     * Sets routing number passed to the method
     * @param routingNumber
     */
    public void setRoutingNumber(String routingNumber) {
        SeleniumTest.clearAndSetText(routingNumberTextbox, routingNumber);
    }

    /**
     * Selects the radio button "Yes" for elect Direct Deposit
     */
    public void setAccountNameSameRadioButtonValueYes() { accountNameSameRadioButtonValueYes.click(); }

    /**
     * Set Choose File path
     */
    public void uploadFile() {
        File fileToUpload = new File(getClass().getResource("/HPM/VoidedCheck.jpg").getFile());
        setFileToUpload(fileToUpload.getAbsolutePath());
        uploadFileButton.click();
        WaitUntil.waitUntil(30, 2, () -> Driver.getDriver().findElement(
                By.partialLinkText("VoidedCheck.jpg")).isDisplayed(),
                            NoSuchElementException.class);
    }

    /**
     * clears and enters passed name string into nameAsItAppearsOnTheAccountTextBox
     * @param name
     */
    public void enterNameAsItAppearsOnAccountText(String name) {
        SeleniumTest.clearAndSetText(nameAsItAppearsOnTheAccountTextBox, name);
    }

    /**
     * Overload for enterNameAsItAppearsOnAccountText() that passes a default String.
     */
    public void enterNameAsItAppearsOnAccountText() { enterNameAsItAppearsOnAccountText("Same Name"); }

    /**
     * Fill the direct deposit form
     */
    public CandidatePortalPages fillDirectDepositForm(Candidate candidate, Class<? extends CandidatePortalPages> returnedClass) {
        electDirectDeposit();
        setAcknowledgementCheckbox();
        setAccountTypeRadioButtonValueChecking();
        setDepositAmountRadioButtonValueNetCheck();
        CandidateBankAccount.createCandidateBankAccount();
        setBankNameTextbox(CandidateBankAccount.getCurrentCandidateBankAccount().getBankName());
        setAccountNumber(CandidateBankAccount.getCurrentCandidateBankAccount().getBankAccountNumber());
        setRoutingNumber(CandidateBankAccount.getCurrentCandidateBankAccount().getBankRoutingNumber());
        enterNameAsItAppearsOnAccountText();
        uploadFile();
        return clickNext(returnedClass);
    }

    /**
     * Click on Next button
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Sets the file to upload
     * @param filePath
     */
    public void setFileToUpload(String filePath) {
        if (OS.isFamilyWindows())
            filePath = filePath.replace('/', '\\');

        //TODO investigate and test using JavaScriptHelper.runScript() instead.
        // making element visible using JS for later operations
        ((JavascriptExecutor)Driver.getDriver()).executeScript("document.getElementById('" + filePathBox.getAttribute("id") + "').style.visibility = 'visible';");
        logger.debug("Setting FilePath of Browse input field to {}", filePath);
        filePathBox.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(uploadFileButton, 10);
    }
}
