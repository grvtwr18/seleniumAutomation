package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by abrackett on 1/25/2016.
 */
public class FormID9053ConfidentialityAgreement extends FormPage {
    @FindBy(how = How.XPATH, using = "//label[@for='9053-8589_91']")
    private WebElement signHereCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='9053-8589_93']")
    private WebElement signHereCheckbox2;

    @FindBy(how = How.ID, using = "9053-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.XPATH, using = "//label[@for='9053-8589_95']")
    private WebElement verifierInitialCheckbox;

    private final String employeePrintedNameString = "//div[@class='panelSection shiftText fullname']/div/span";
    private By employeePrintedNameLocator = By.xpath(employeePrintedNameString);
    @FindBy(how = How.XPATH, using = employeePrintedNameString)
    private WebElement employeePrintedName;

    @FindBy(how = How.XPATH, using = "//div[@class='panelSection shiftText datesigned']/div/span")
    private WebElement employeeDateSigned;

    @FindBy(how = How.XPATH, using = "//span[@id='9053-100_7']")
    private WebElement employeeAddressLine1;

    @FindBy(how = How.XPATH, using = "//span[@id='9053-100_10']")
    private WebElement employeeCity;

    @FindBy(how = How.XPATH, using = "//span[@id='9053-100_12']")
    private WebElement employeeZip;

    private final String dateBoxesLocatorString = "//div[@class='panelSection shiftText datesigned']";
    private By dateBoxesLocator = By.xpath(dateBoxesLocatorString);
    @FindBy(how = How.XPATH, using = dateBoxesLocatorString)
    private WebElement dateBoxes;

    @FindBy(how = How.XPATH, using = "//label[@for='9053-8589_95']")
    private WebElement legalVerifierInitialCheckbox;

    @FindBy(how = How.ID, using = "9053-8589_99")
    private WebElement actianCorporationPrintedName;

    @FindBy(how = How.ID, using = "9053-8589_100")
    private WebElement actianCorporationTitle;

    private final String actianCorporationSignHereLocatorString = "//label[@for='9053-8589_97']";
    private By actianCorporationSignHereLocator = By.xpath(actianCorporationSignHereLocatorString);
    @FindBy(how = How.XPATH, using = actianCorporationSignHereLocatorString)
    private WebElement actianCorporationSignHereCheckbox;

    @FindBy(how = How.XPATH, using = "//div[@id='9053-div-8589_96']/div")
    private WebElement legalVerifierDateSigned;

    @FindBy(how = How.XPATH, using = "//div[@id='someUnknownValue']/div")
    private WebElement employeeDateSigned1;

    @FindBy(how = How.XPATH, using = "//div[@id='someOtherUnknownValue']/div")
    private WebElement actianCorporationDateSigned;

    @FindBy(how = How.XPATH, using = "//div[@id='someUnknownValue2']/div")
    private WebElement employeeDateSigned2;

    private final String employeeSignatureLocatorString = "//div[@id='signature-sign']/div/img";
    By employeeSignatureLocator = By.xpath(employeeSignatureLocatorString);
    @FindBy(how = How.XPATH, using = employeeSignatureLocatorString)
    private WebElement employeeSignature;

    /**
     * sets the Actian Printed Name
     * @param printedName
     * @return
     */
    public FormID9053ConfidentialityAgreement setActianPrintedName(String printedName) {
        SeleniumTest.clearAndSetText(actianCorporationPrintedName, "Financial Verifier Printed Name");
        return this;
    }

    /**
     * sets the Actian Title
     * @param title
     * @return
     */
    public FormID9053ConfidentialityAgreement setActianTitle(String title) {
        SeleniumTest.clearAndSetText(actianCorporationTitle, "Financial Verifier Title");
        return this;
    }

    /**
     * Checks the Actian Corporation Sign Here Checkbox for recipient = 3
     * @return
     */
    public FormID9053ConfidentialityAgreement checkActianCorporationSignHereCheckbox () {
        try {
            if(!Driver.getDriver().findElement(actianCorporationSignHereLocator).isSelected())
                actianCorporationSignHereCheckbox.click();
        }
        catch(NoSuchElementException nse) {
            return this;
        }
        return this;
    }

    /**
     * Checks the first Sign Here checkbox
     * @return
     */
    public FormID9053ConfidentialityAgreement checkSignHere() {
        if(!Driver.getDriver().findElement(By.id("9053-8589_91")).isSelected())
            signHereCheckbox.click();
        return this;
    }

    /**
     * Checks the second Sign Here checkbox
     * @return
     */
    public FormID9053ConfidentialityAgreement checkSignHere2() {
        if(!Driver.getDriver().findElement(By.id("9053-8589_93")).isSelected())
            signHereCheckbox2.click();
        return this;
    }

    /**
     * Clicks next
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Checks the verifier Initials Box
     * @return
     */
    public FormID9053ConfidentialityAgreement checkVerifierInitial() {
        if(!Driver.getDriver().findElement(By.id("9053-8589_95")).isSelected())
            verifierInitialCheckbox.click();
        return this;
    }

    /**
     * Gets the Employee Printed name as shown in the form
     * Looks like first and last name only by default.
     * @param index Zero based index of the employee name you are looking for
     * @return
     */
    public String getEmployeePrintedName(Integer index) {
        try {
            List<WebElement> employeePrintedNames = Driver.getDriver().findElements(employeePrintedNameLocator);
            return employeePrintedNames.get(index).getText();
        }
        catch(NoSuchElementException nse) {
            return null;
        }
    }

    /**
     * gets Employee Signature
     * @param index
     * @return
     */
    public Boolean getEmployeeSignature(Integer index) {
        try {
            if(Driver.getDriver().findElements(employeeSignatureLocator).size() > index)
                return Driver.getDriver().findElements(employeeSignatureLocator).get(index).isDisplayed();
        }
        catch(NoSuchElementException nse) {
            return false;
        }
        return false;
    }

    /**
     * Gets the employee address line 1
     * @return
     */
    public String getEmployeeAddressLine1() {
        return employeeAddressLine1.getText();
    }

    /**
     * gets the Employee City
     * @return
     */
    public String getEmployeeCity() {
        return employeeCity.getText();
    }

    /**
     * Gets the Employee Zip Code
     * @return
     */
    public String getEmployeeZip() {
        return employeeZip.getText();
    }

    /**
     * returns Legal Verifier Date Signed
     * @return
     */
    public String getLegalVerifierDateSigned() {
        try {
            return legalVerifierDateSigned.getText();
        }
        catch(NoSuchElementException nse) {
            return "";
        }
    }

    /**
     * returns Emploiyee Date Signed #1
     * @return
     */
    public String getEmployeeDateSigned1() {
        try {
            return employeeDateSigned1.getText();
        }
        catch(NoSuchElementException nse) {
            return "";
        }
    }

    /**
     * returns Actian Corporation Date Signed
     * @return
     */
    public String getActianCorporationDateSigned() {
        try {
            return actianCorporationDateSigned.getText();
        }
        catch(NoSuchElementException nse) {
            return "";
        }
    }

    /**
     * returns Employee Date Signed #2
     * @return
     */
    public String getEmployeeDateSigned2() {
        try {
            return employeeDateSigned2.getText();
        }
        catch(NoSuchElementException nse) {
            return "";
        }
    }
    /**
     * Gets the legal Verifiers date
     * @return
     */
    public String getDate(Integer index) {
        return Driver.getDriver().findElements(dateBoxesLocator).get(index).getText();
    }

    /**
     * Checks the legal Verifier Initials Box
     * @return
     */
    public FormID9053ConfidentialityAgreement checkLegalVerifierInitials() {
        if(!Driver.getDriver().findElement(By.id("9053-8589_95")).isSelected())
            legalVerifierInitialCheckbox.click();
        return this;
    }
}
