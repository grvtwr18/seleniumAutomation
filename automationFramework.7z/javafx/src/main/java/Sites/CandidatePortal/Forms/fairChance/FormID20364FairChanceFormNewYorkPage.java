package Sites.CandidatePortal.Forms.fairChance;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.individualizedReview.IrWorkflowPages;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.time.LocalDate;

/**
 * @author sbashar
 */
public class FormID20364FairChanceFormNewYorkPage extends IrWorkflowPages {

/*
    @FindBy(how = How.CSS, using = "label[for='20364-20364_101']")
    private static WebElement dutiesAndResponsibilities;

    @FindBy(how = How.CSS, using = "label[for='20364-20364_116']")
    private static WebElement fitnessOrAbility;

    @FindBy(how = How.CSS, using = "label[for='20364-20364_117']")
    private static WebElement criminalActivityOccurrenceTime;

    @FindBy(how = How.CSS, using = "label[for='20364-20364_118']")
    private static WebElement age;

    @FindBy(how = How.CSS, using = "label[for='20364-20364_119']")
    private static WebElement seriousnessOfTheConduct;

    @FindBy(how = How.CSS, using = "label[for='20364-20364_120']")
    private static WebElement evidenceOfRehabilitation;

    @FindBy(how = How.CSS, using = "label[for='20364-20364_122']")
    private static WebElement safetyAndWelfare;

    @FindBy(how = How.CSS, using = "label[for='20364-20364_123']")
    private static WebElement certificate;

    */

    @FindBy(how = How.ID, using = "20364-20364_142-20364_142")
    private static WebElement assessmentDateBox;

    public static void typeFirstName(String firstName) {
        SeleniumTest.clearAndSetText(By.id
                ("20364-20364_107"), firstName);
    }

    public static void typeLastName(String lastName) {
        SeleniumTest.clearAndSetText(By.id
                ("20364-20364_108"), lastName);
    }

    public static void typeEmailAddress(String emailAddress) {
        SeleniumTest.clearAndSetText(By.id
                ("20364-20364_105"), emailAddress);
    }

    public static void typePosition(String candidatePosition) {
        SeleniumTest.clearAndSetText(By.id
                ("20364-20364_103"), candidatePosition);
    }

    public static void typeDateOfAssessment(LocalDate date) {

        String hiddenAssessmentDateBox = "20364-20364_142-20364_142";

        if (Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date, assessmentDateBox.getAttribute("id"), hiddenAssessmentDateBox);
        } else {
            String strDate = date.format(LocaleHelper.getDateFormatShortDateSlash_uuuu());
            assessmentDateBox.sendKeys(strDate);
        }
    }

/*    public static void checkDutiesAndResponsibilitiesBox() {
        SeleniumTest.click(dutiesAndResponsibilities);
    }*/


    /**
     * Fills the form for fair chance information.
     */
    public static void fillNewYorkFairChanceForm(String firstName, String lastName, String emailAddress,
                                          LocalDate date, String candidatePosition) {
        typeFirstName(firstName);
        typeLastName(lastName);
        typeEmailAddress(emailAddress);
        typeDateOfAssessment(date);
        typePosition(candidatePosition);
    }

    public static CandidatePortalPages fillFairChanceFormAndSubmit(String firstName, String lastName, String emailAddress, LocalDate date,
                                                                   String candidatePosition, Class<? extends CandidatePortalPages> returnedClass) {
        fillNewYorkFairChanceForm(firstName, lastName, emailAddress, date, candidatePosition);
        return FormID20364FairChanceFormNewYorkPage.clickNext(returnedClass);
    }
}
