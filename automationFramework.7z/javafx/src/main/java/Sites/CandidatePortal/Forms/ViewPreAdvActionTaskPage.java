package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


/**
 * Created by sbashar on 8/10/2017.
 * This class contains functions to view pre-adverse action task
 *
 * @author sbashar
 */
public class ViewPreAdvActionTaskPage extends FormPage {
    @FindBy(how = How.CSS, using = "input#close")
    private static WebElement closeButton;

    @FindBy(how = How.CSS, using = "table>tbody>tr>td>div>img")
    private static WebElement sterlingLogo;

    static {
        PageFactory.initElements(Driver.getDriver(), ViewPreAdvActionTaskPage.class);
    }

    /**
     *  This method waits for sterling logo
     */
    public static void waitForSterlingLogo(){
        SeleniumTest.waitForElementVisible(sterlingLogo,30,3);
    }

    /**
     *  This method waits for close button
     */
    public static void clickCloseBtn() {
        final int windowCountBefore = Driver.getDriver().getWindowHandles().size();
        staticLogger.info("{} window(s) open before clicking Close on the ViewPreAdvActionTaskPage", windowCountBefore);
        SeleniumTest.click(closeButton);

        try {
            WaitUntil.waitUntil(30, 3, () -> {
                int windowCountAfter = Driver.getDriver().getWindowHandles().size();
                if (windowCountBefore > windowCountAfter) {
                    staticLogger.info("{} window(s) open after clicking Close on the ViewPreAdvActionTaskPage", windowCountAfter);
                    return true;
                } else {
                    staticLogger.info("Still waiting for one of the {} window(s) to close", windowCountAfter);
                    // DON'T try to click the closeButton again when the whole window may be closed.
                    // When we do that, we see it waste up to 30 minutes here as the WebDriver seems to hang.
                    return false;
                }
            });
        } catch (TimeoutException e) {
            staticLogger.warn("One of the {} window(s) never closed as was expected!",
                    Driver.getDriver().getWindowHandles().size());
        }

        WindowManagement.switchToMainWindow();
        WindowManagement.closeAllOtherWindows();
    }
}

