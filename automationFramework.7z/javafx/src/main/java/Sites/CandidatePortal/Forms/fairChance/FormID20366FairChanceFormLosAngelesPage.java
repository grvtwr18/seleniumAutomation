package Sites.CandidatePortal.Forms.fairChance;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.individualizedReview.IrWorkflowPages;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.time.LocalDate;

/**
 * Created by jgupta on 3/7/2018.
 */
public class FormID20366FairChanceFormLosAngelesPage extends IrWorkflowPages {
    @FindBy(how = How.CSS, using = "input[fieldname='Assessment Completed By:']")
    private static WebElement assessmentCompletedByTextBox;

    @FindBy(how = How.CSS, using = "input[fieldname='Position Applied For:']")
    private static WebElement positionAppliedForTextBox;

    @FindBy(how = How.XPATH, using = "//input[@fieldname='Position Applied "
                                     + "For:']/../following-sibling::div/input[2]")
    private static WebElement assessmentDateBox;

    @FindBy(how = How.ID, using = "20366-20366_183-20366_183")
    private static WebElement conditionalDateBox;

    @FindBy(how = How.ID, using = "20366-20366_186-20366_186")
    private static WebElement dateOfCriminalHistReportDateBox;

    public static void typeAssessmentCompletedBy(String assessmentCompletedBy) {
        SeleniumTest.clearAndSetText(assessmentCompletedByTextBox, assessmentCompletedBy);
    }

    public static void typePositionAppliedFor(String position) {
        SeleniumTest.clearAndSetText(positionAppliedForTextBox, position);
    }

    public static void typeDateOfAssessment(LocalDate date) {
        if (Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date,
                    assessmentDateBox.getAttribute("id"), "20366-20366_182");
        } else {
            String strDate = date.format(LocaleHelper.getDateFormatShortDateSlash_uuuu());
            assessmentDateBox.sendKeys(strDate);
        }
    }

    public static void typeDateOfConditionalOffer(LocalDate date) {
        if (Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date,
                    conditionalDateBox.getAttribute("id"), "20366-20366_183");
        } else {
            String strDate = date.format(LocaleHelper.getDateFormatShortDateSlash_uuuu());
            conditionalDateBox.sendKeys(strDate);
        }
    }

    public static void typeDateOfCriminalHistoryReport(LocalDate date) {
        if (Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date,
                    dateOfCriminalHistReportDateBox.getAttribute("id"), "20366-20366_186");
        } else {
            String strDate = date.format(LocaleHelper.getDateFormatShortDateSlash_uuuu());
            dateOfCriminalHistReportDateBox.sendKeys(strDate);
        }
    }

    /**
     * Fills the form for fair chance information.
     */
    public static void fillLosAngelesFairChanceForm(String assessmentCompletedBy,
            String positionAppliedFor, LocalDate dateOfAssessment, LocalDate
            dateOfConditionalOffer) {
        typeAssessmentCompletedBy(assessmentCompletedBy);
        typePositionAppliedFor(positionAppliedFor);
        typeDateOfAssessment(dateOfAssessment);
        typeDateOfCriminalHistoryReport(LocalDate.now());
        typeDateOfConditionalOffer(dateOfConditionalOffer);
    }

    public static CandidatePortalPages fillFairChanceFormAndSubmit(String assessmentCompletedBy,
            String positionAppliedFor, LocalDate dateOfAssessment, LocalDate
            dateOfConditionalOffer, Class<? extends CandidatePortalPages> returnedClass) {
        fillLosAngelesFairChanceForm(assessmentCompletedBy, positionAppliedFor, dateOfAssessment,
                dateOfConditionalOffer);
        return FormID20364FairChanceFormNewYorkPage.clickNext(returnedClass);
    }
}
