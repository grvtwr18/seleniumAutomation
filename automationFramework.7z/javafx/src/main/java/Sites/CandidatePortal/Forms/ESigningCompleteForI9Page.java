package Sites.CandidatePortal.Forms;

import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.apache.http.client.utils.URIBuilder;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.net.URISyntaxException;

/**
 * Created by jgupta on 4/5/2016.
 * This page is generated after DocuSign I9 Completion
 */
public class ESigningCompleteForI9Page extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "remoteI9Msg")
    private WebElement candidateParagraph1;

    @FindBy(how = How.ID, using = "bringCopiesMsg")
    private WebElement candidateParagraph2;

    @FindBy(how = How.ID, using = "pan_scheduling_link")
    private WebElement panSchedulingLink;

    // region panVerifier eSign complete text

    @FindBy(how = How.ID, using = "completeMessage")
    private WebElement panCompleteMessage;

    // endregion

    // region E-Verify Post Order Input text

    @FindBy(how = How.CLASS_NAME, using = "divEVerifyPostOrderInput")
    private WebElement eVerifyPostOrderMessage;

    // endregion

    private static ThreadLocal<ESigningCompleteForI9Page> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(
                Driver.getDriver(), ESigningCompleteForI9Page.class));
    }

    public static ESigningCompleteForI9Page getInstance() {
        return threadLocalInstance.get();
    }

    public String getAdditionalActionRequiredTextRemoteNetworkParagraph1() {
        return getInstance().candidateParagraph1.getText();
    }

    public String getAdditionalActionRequiredTextRemoteNetworkParagraph2() {
        return getInstance().candidateParagraph2.getText();
    }

    public URIBuilder getPanSchedulingLinkUri() throws URISyntaxException {
        return new URIBuilder(getInstance().panSchedulingLink.getAttribute("href"));
    }

    public String getPanVerifierESignCompleteMessage() {
        return getInstance().panCompleteMessage.getText();
    }

    public void clickPanSchedulingLink() {
        WindowManagement.clickElementToOpenNewWindow(
        getInstance().panSchedulingLink);
    }

    public String getEVerifyPostOrderInputMessage() {
        return getInstance().eVerifyPostOrderMessage.getText();
    }
}
