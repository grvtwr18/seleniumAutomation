package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;

/**
 * This file contains methods for References page in Individualized review workflow.
 * Created by jgupta on 10/1/2017.
 */
public class FormID19197ReferencesPage extends IrWorkflowPages {

    public enum TypeOfReference {
        EMPLOYMENT("Employment"),
        CHARACTER("Character");

        private final String name;

        TypeOfReference(String name) {
            this.name = name;
        }

        public String toString() {
            return name;
        }
    }

    /**
     * Types name of reference in text box.
     */
    public static void typeNameOfReference(int index, String nameOfReference) {
        SeleniumTest
                .clearAndSetText(By.id("19197-history-1-19197_03-19197_2_" + index), nameOfReference);
    }

    public static void typePhoneNumber(int index, String phone) {
        SeleniumTest
                .clearAndSetText(By.id("19197-history-1-19197_03-19197_4_" + index), phone);
    }

    public static void typeEmailAddress(int index, String email) {
        SeleniumTest
                .clearAndSetText(By.id("19197-history-1-19197_03-19197_5_" + index), email);
    }

    public static void selectTypeOfReference(int index, TypeOfReference reference) {
        SeleniumTest.selectByValueFromDropDown(Driver.getDriver().findElement(By.id
                ("19197-history-1-19197_03-19197_6_" + index)), reference.toString());
    }

    public static void fillReferences(int index, String nameOfReference, String phoneOfReference,
                                      String emailOfReference, TypeOfReference refType) {
        FormID19197ReferencesPage.typeNameOfReference(index, nameOfReference);
        FormID19197ReferencesPage.typePhoneNumber(index, phoneOfReference);
        FormID19197ReferencesPage.typeEmailAddress(index, emailOfReference);
        FormID19197ReferencesPage.selectTypeOfReference(index, refType);
    }

    public static CandidatePortalPages fillReferencesAndSubmit(int index, String referenceName,
                                       String referencePhone, String referenceEmail,
                                       TypeOfReference employment, Class<? extends CandidatePortalPages> returnedClass) {
        fillReferences(index, referenceName, referencePhone, referenceEmail, employment);
        return FormID19197ReferencesPage.clickNext(returnedClass);
    }

}
