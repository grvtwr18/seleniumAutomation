package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by abrackett on 12/21/2015.
 */
public class FormID7FormReviewResults extends FormPage {
    @FindBy(how = How.XPATH, using = "//label[text()='Approve Form']")
    private WebElement approveRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[text()='Return Form']")
    private WebElement returnFormRadiobutton;

    @FindBy(how = How.ID, using = "7-previousnextbuttons-submitbutton")
    private WebElement submitButton;

    /**
     * Choose Approve
     */
    public FormID7FormReviewResults chooseApprove() {
        approveRadiobutton.click();
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), 10);
        wait.until(ExpectedConditions.visibilityOf(Driver.getDriver().findElement(By.className("reviewTextArea"))));
        return this;
    }

    /**
     * Choose Return
     * @return
     */
    public FormID7FormReviewResults chooseReturn() {
        returnFormRadiobutton.click();
        return this;
    }

    /**
     * Click Submit
     * @return
     */
    public TaskCompletePage clickSubmit() {
        submitButton.click();
        return PageFactory.initElements(Driver.getDriver(), TaskCompletePage.class);
    }
}
