package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow.ThreeStepSection2Compliance;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.LocalDate;

/**
 * The first verifier user form in three step I-9 (FS 4577)
 */
public class FormID17523ThreeStepSection2Verifier extends CandidatePortalPages  {

    static {
        PageFactory.initElements(Driver.getDriver(), FormID17523ThreeStepSection2Verifier.class);
    }

    public static class Section2 extends Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow.Section2 {
        static {
            PageFactory.initElements(Driver.getDriver(), ThreeStepSection2Compliance.Section2.class);
        }
    }

    public static class Section2Documents {

        static {
            PageFactory.initElements(Driver.getDriver(), Section2Documents.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_9_1'][type='text']")
        private static WebElement documentExpirationDateCalendarControl;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_9_1'][type='hidden']")
        private static WebElement hiddenDocumentExpirationDateCalendarControl;

        @FindBy(how = How.CSS, using = "input[id$='-311_47_DocumentsMatch']")
        private static WebElement documentsMatchRadioButton;

        @FindBy(how = How.CSS, using = "label[for$='-311_47_DocumentsMatch']")
        private static WebElement documentsMatchRadioButtonLabel;

        @FindBy(how = How.CSS, using = "input[id$='-311_47_EditsRequired']")
        private static WebElement editsRequiredRadioButton;

        @FindBy(how = How.CSS, using = "label[for$='-311_47_EditsRequired']")
        private static WebElement editsRequiredRadioButtonLabel;

        public static void setExpirationDate(LocalDate date) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                    date,
                    documentExpirationDateCalendarControl.getAttribute("id"),
                    hiddenDocumentExpirationDateCalendarControl.getAttribute("id"));
        }

        public static void chooseDocumentsMatch() {
            documentsMatchRadioButtonLabel.click();
        }

        public static void chooseEditsRequired() {
            editsRequiredRadioButtonLabel.click();
        }
    }

    public static class Certification {

        static {
            PageFactory.initElements(Driver.getDriver(), Certification.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_44']")
        public static WebElement authorizedRepresentativeFirstNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_43']")
        public static WebElement authorizedRepresentativeLastNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-311_148']")
        private static WebElement authorizedRepresentativeTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-311_145']")
        private static WebElement businessNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-311_146']")
        private static WebElement addressLine1TextBox;

        @FindBy(how = How.CSS, using = "input[id$='-311_147']")
        private static WebElement phoneNumberTextBox;


        public static void setAuthorizedRepresentativeFirstName(String firstName) {
            SeleniumTest.clearAndSetText(authorizedRepresentativeFirstNameTextBox, firstName);
        }

        public static void setAuthorizedRepresentativeLastName(String lastName) {
            SeleniumTest.clearAndSetText(authorizedRepresentativeLastNameTextBox, lastName);
        }

        public static void setAuthorizedRepresentative(String representative) {
            SeleniumTest.clearAndSetText(authorizedRepresentativeTextBox, representative);
        }

        public static void setBusinessName(String businessName) {
            SeleniumTest.clearAndSetText(businessNameTextBox, businessName);
        }

        public static void setAddressLine1(String address) {
            SeleniumTest.clearAndSetText(addressLine1TextBox, address);
        }

        public static void setPhoneNumber(String phoneNumber) {
            SeleniumTest.clearAndSetText(phoneNumberTextBox, phoneNumber);
        }
    }

    public static class Acknowledgement {

        static {
            PageFactory.initElements(Driver.getDriver(), Acknowledgement.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_40']")
        private static WebElement iAcknowledgeCheckBox;

        @FindBy(how = How.CSS, using = "label[for$='-I9s2_40']")
        private static WebElement iAcknowledgeCheckBoxLabel;

        public static void checkIAcknowledge() {
            if (!iAcknowledgeCheckBox.isSelected()) {
                iAcknowledgeCheckBoxLabel.click();
            }
        }

        public static void uncheckIAcknowledge() {
            if (iAcknowledgeCheckBox.isSelected()) {
                iAcknowledgeCheckBoxLabel.click();
            }
        }
    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {

    }
}
