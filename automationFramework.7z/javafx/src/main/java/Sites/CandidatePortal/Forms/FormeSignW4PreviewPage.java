package Sites.CandidatePortal.Forms;

import Sites.TalentWiseDashboard.ProductFormPages.FormZero.FormZero_532;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FormeSignW4PreviewPage extends FormeSignPreviewPage {

    @FindBy(how = How.ID, using = "confirmButton")
    private static WebElement confirmAndeSignButton;

    @FindBy(how = How.ID, using = "4362-100_1")
    private static WebElement firstNameText;

    @FindBy(how = How.ID, using = "4362-100_3")
    private static WebElement lastNameText;

    @FindBy(how = How.ID, using = "4362-100_5")
    private static WebElement ssnText;

    @FindBy(how = How.ID, using = "4362-100_7")
    private static WebElement addressLine1Text;

    @FindBy(how = How.ID, using = "4362-100_8")
    private static WebElement apartmentNumberText;

    @FindBy(how = How.ID, using = "4362-100_10")
    private static WebElement cityText;

    @FindBy(how = How.ID, using = "4362-100_11")
    private static WebElement stateText;

    @FindBy(how = How.ID, using = "4362-100_12")
    private static WebElement zipCodeText;

    @FindBy(how = How.ID, using = "4362-105_3")
    private static WebElement numberOfAllowancesLine5Text;

    @FindBy(how = How.ID, using = "4362-105_4")
    private static WebElement additionalAmountLine6Text;

    @FindBy(how = How.ID, using = "4362-105_5")
    private static WebElement exemptLine7Text;

    @FindBy(how = How.CSS, using = "#sign-name > small")
    private static WebElement signaturePrintedSmallText;

    @FindBy(how = How.ID, using = "sign-date")
    private static WebElement dateSignedSmallText;

    @FindBy(how = How.XPATH, using = "//*[@id='4362-div-4362_20']/div")
    private static WebElement dateSignedLargeText;

    private static final String confirmButton = "confirmButton";

//    public FormeSignW4PreviewPage() {
//        // Waiting for the Due Date box to be clickable before returning from the constructor
//        SeleniumTest.waitForElementToBeClickable(By.id(confirmButton), SeleniumTest.waitForElementTimeout);
//        SeleniumTest.waitForJQueryAjaxDone();
//    }


    private static ThreadLocal<FormeSignW4PreviewPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                FormeSignW4PreviewPage.class));
    }

    private static FormeSignW4PreviewPage getInstance() {
        return threadLocalInstance.get();
    }

//    public static FormeSignW4PreviewPage getInstance() {
//        return PageFactory.initElements(Driver.getDriver(), FormeSignW4PreviewPage.class);
//    }

    public static String getFirstNameText() {
        return getInstance().firstNameText.getText();
    }

    public static String getLastNameText() {
        return getInstance().lastNameText.getText();
    }

    public static String getSocialSecurityNumberText() {
        return getInstance().ssnText.getText();
    }

    public static String getAddressLine1Text() {
        return getInstance().addressLine1Text.getText();
    }

    public static String getApartmentNumberText() {
        return getInstance().apartmentNumberText.getText();
    }

    public static String getCityText() {
        return getInstance().cityText.getText();
    }

    public static String getStateText() {
        return getInstance().stateText.getText();
    }

    public static String getZipCodeText() {
        return getInstance().zipCodeText.getText();
    }

    public static String getMaritalStatusSelection() {
        //TODO finish this getMaritalStatusSelection method
        return "";
    }

    public static String getNumberOfAllowancesText() {
        return getInstance().numberOfAllowancesLine5Text.getText();
    }

    public static String getAdditionalAmountText() {
        return getInstance().additionalAmountLine6Text.getText();
    }

    public static String getExemptText() {
        return getInstance().exemptLine7Text.getText();
    }

    public static String getSignaturePrintedSmallText() {
        return getInstance().signaturePrintedSmallText.getText();
    }

    public static String getSignatureDateSmallText() {
        return getInstance().dateSignedSmallText.getText();
    }

    public static String getLargeDateSignedText() {
        return getInstance().dateSignedLargeText.getText();
    }
}
