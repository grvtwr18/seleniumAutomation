package Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow;

import Sites.CandidatePortal.Forms.Objects.I9.I9Base;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by btorbert on 2/25/17.
 */
public class Section1 extends I9Base {

    static {
        PageFactory.initElements(Driver.getDriver(),
                Sites.CandidatePortal.Forms.Objects.I9.Section1.class);
    }

    protected static final Logger staticLogger
            = LoggerFactory.getLogger(Sites.CandidatePortal.Forms.Objects.I9.Section1.class);


    public static class CitizenAttestation {

        static {
            PageFactory.initElements(Driver.getDriver(),
                    Sites.CandidatePortal.Forms.Objects.I9.Section1.CitizenAttestation.class);
        }


        public static class AlienAuthorizedToWork {

            static {
                PageFactory.initElements(Driver.getDriver(),
                        Sites.CandidatePortal.Forms.Objects.I9.Section1
                                .CitizenAttestation.AlienAuthorizedToWork.class);
            }

            /**
             * Handles actions performed when Foreign Passport Number is chosen
             */
            public static class ForeignPassportNumber {

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_19_1']")
                private static WebElement foreignPassportNumberTextBox;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_19_1-err']")
                public static WebElement foreignPassportNumberErr;

                @FindBy(how = How.CSS, using = "select[id$='-I9s1_20_1']")
                private static WebElement foreignPassportCountryOfIssuanceDropDown;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_20_1-err']")
                private static WebElement foreignPassportCountryOfIssuanceErr;

                static {
                    PageFactory.initElements(Driver.getDriver(),
                            Sites.CandidatePortal.Forms.Objects.I9
                                    .ThreeStepWorkflow.Section1.CitizenAttestation
                                    .AlienAuthorizedToWork.ForeignPassportNumber.class);
                }

                /**
                 * Sets the Foreign Passport Number
                 * @param number Number to set
                 */
                public static void setForeignPassportNumber(String number) {
                    SeleniumTest.clearAndSetText(foreignPassportNumberTextBox, number, true);
                }

                public static String getForeignPassportNumberError() {
                    return foreignPassportNumberErr.getText();
                }

                /**
                 * Selects the Country of Issuance
                 * @param country Country to set
                 */
                public static void selectCountryOfIssuance(String country) {
                    SeleniumTest.selectByVisibleTextFromDropDown
                            (foreignPassportCountryOfIssuanceDropDown, country);
                }

                public static String getCountryOfIssuanceError() {
                    return foreignPassportCountryOfIssuanceErr.getText();
                }
            }
        }
    }
}
