package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.Form_17060;
import TWFramework.SeleniumTest;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import java.io.File;

/**
 * This file contains methods to interact with Additional Information page in IR workflow.
 * Created by jgupta on 10/1/2017.
 */
public class FormID19199AdditionalInfoPage extends IrWorkflowPages {

    public static void typeAdditionalInformation(String additionalInformation) {
        SeleniumTest.clearAndSetText(By.id
                ("19199-19199_3"), additionalInformation);
    }

    public static void uploadDocument(File file) {
        Form_17060.UploadDocuments.setFileToUpload(file.getAbsolutePath());
        Form_17060.UploadDocuments.clickUploadFile();
    }

    public static void uploadDocument(File file, String fileName) {
        Form_17060.UploadDocuments.setFileToUpload(file.getAbsolutePath());
        Form_17060.UploadDocuments.clickUploadFile();
        SeleniumTest.waitForElementVisible(By.linkText(fileName));
    }

    public static CandidatePortalPages addAditionalInformationUploadDocumentAndSubmit(String additionalInformation,
                                    File file, Class<? extends CandidatePortalPages> returnedClass) {
        typeAdditionalInformation(additionalInformation);
        uploadDocument(file);
        return FormID19199AdditionalInfoPage.clickNext(returnedClass);
    }

    public static AttachmentViewerPage clickAttachedDocument(String attachedDocumentName) {
        WindowManagement.runMethodToOpenNewWindow( () -> SeleniumTest.click(By.linkText
                (attachedDocumentName)), false);
        return PageFactory.initElements(Driver.getDriver(), AttachmentViewerPage.class);
    }
}
