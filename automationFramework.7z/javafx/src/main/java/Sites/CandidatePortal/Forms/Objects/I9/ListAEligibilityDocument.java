package Sites.CandidatePortal.Forms.Objects.I9;

import java.time.LocalDate;

/**
 * Created by abrackett on 10/17/16.
 */
public class ListAEligibilityDocument {

    private Section2.Documents.ListADocuments listADocument            = Section2.Documents.ListADocuments.USPASSPORT;
    private boolean                           receipt                  = false;
    private String                            documentType             = "";
    private String                            stateOfUnion             = "Washington";
    private String                            issuingAuthority         = "U.S. Department of State";
    private String                            documentNumber           = "123456789";
    private String                            associatedDocumentValue  = "";
    private LocalDate                         expirationDate           =  LocalDate.now().plusYears(5);
    private String                            secondIssuingAuthority   = "U.S. Department of State";
    private String                            secondDocumentNumber     = "00000000001";
    private LocalDate                         secondDocumentExpiration =  LocalDate.now().plusYears(5);

    public ListAEligibilityDocument() {

    }

    public ListAEligibilityDocument(Section2.Documents.ListADocuments document, boolean receipt,
                                    String documentType, String stateOfUnion,
                                    String issuingAuthority, String documentNumber,
                                    String associatedDocumentValue, LocalDate expirationDate) {

        this.listADocument = document;
        this.receipt = receipt;
        this.documentType = documentType;
        this.stateOfUnion = stateOfUnion;
        this.issuingAuthority = issuingAuthority;
        this.documentNumber = documentNumber;
        this.associatedDocumentValue = associatedDocumentValue;
        this.expirationDate = expirationDate;
    }


    public Section2.Documents.ListADocuments getListADocument() {
        return listADocument;
    }

    public void setListADocument(Section2.Documents.ListADocuments listADocument) {
        this.listADocument = listADocument;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getStateOfUnion() {
        return stateOfUnion;
    }

    public void setStateOfUnion(String stateOfUnion) {
        this.stateOfUnion = stateOfUnion;
    }

    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    public void setIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getAssociatedDocumentValue() {
        return associatedDocumentValue;
    }

    public void setAssociatedDocumentValue(String associatedDocumentValue) {
        this.associatedDocumentValue = associatedDocumentValue;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public boolean isReceipt() {
        return receipt;
    }

    public void setReceipt(boolean receipt) {
        this.receipt = receipt;
    }

    public String getSecondIssuingAuthority() {
        return secondIssuingAuthority;
    }

    public void setSecondIssuingAuthority(String secondIssuingAuthority) {
        this.secondIssuingAuthority = secondIssuingAuthority;
    }

    public String getSecondDocumentNumber() {
        return secondDocumentNumber;
    }

    public void setSecondDocumentNumber(String secondDocumentNumber) {
        this.secondDocumentNumber = secondDocumentNumber;
    }

    public LocalDate getSecondDocumentExpiration() {
        return secondDocumentExpiration;
    }

    public void setSecondDocumentExpiration(LocalDate secondDocumentExpiration) {
        this.secondDocumentExpiration = secondDocumentExpiration;
    }
}
