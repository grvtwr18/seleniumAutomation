package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_16670_MutualArbitration extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "16670-16670_6")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16670-16670_6']")
    private WebElement iAcknowledgeLabel;

    protected Logger logger = LoggerFactory.getLogger(Form_16670_MutualArbitration.class);

    public static Form_16670_MutualArbitration getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16670_MutualArbitration.class);
    }

    public Form_16670_MutualArbitration checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_16670_MutualArbitration uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Unchecked");
        return this;
    }

}
