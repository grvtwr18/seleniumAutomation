package Sites.CandidatePortal.Forms.eDispute;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 5/13/2017.
 */
public class ConfirmDisputePage {
    static {
        PageFactory.initElements(Driver.getDriver(), ConfirmDisputePage.class);
    }
    @FindBy(how = How.CSS, using = "button[class='dispute btn btn-primary pull-right']")
    private static WebElement submitButton;

    public static void clickSubmit() {
        SeleniumTest.click(submitButton);
    }
}
