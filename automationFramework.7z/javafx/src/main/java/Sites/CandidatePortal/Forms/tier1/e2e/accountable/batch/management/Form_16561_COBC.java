package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_16561_COBC extends CandidatePortalPages {

    @FindBy(how = How.CSS, using = "label[for^='16561-16561_5_I ack']")
    private WebElement iAcknowledgeRadioButton;

    @FindBy(how = How.CSS, using = "label[for^='16561-16561_5_I am']")
    private WebElement iAmNotInFullComplianceRadioButton;

    @FindBy(how = How.ID, using = "16561-16561_8")
    private WebElement exceptionTextBox;

    @FindBy(how = How.ID, using = "16561-16561_7")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16561-16561_7']")
    private WebElement iAcknowledgeLabel;

    protected Logger logger = LoggerFactory.getLogger(Form_16561_COBC.class);

    public static Form_16561_COBC getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16561_COBC.class);
    }

    public Form_16561_COBC checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_16561_COBC uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge unchecked");
        return this;
    }

    public Form_16561_COBC chooseIAcknowledgeRadioButton() {
        iAcknowledgeRadioButton.click();
        logger.info("I Acknowledge Radio Chosen");
        return this;
    }

    public Form_16561_COBC chooseIAmNotInFullComplianceRadioButton() {
        iAmNotInFullComplianceRadioButton.click();
        logger.info("I am Not in Full Compliance Radio Chosen");
        return this;
    }

    public String getExceptionText() {
        return exceptionTextBox.getText();
    }

    public Form_16561_COBC setExceptionText(String exception) {
        SeleniumTest.clearAndSetText(exceptionTextBox, exception);
        logger.info("Exception text set to {}", exception);
        return this;
    }
}
