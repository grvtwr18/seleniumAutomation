package Sites.CandidatePortal.Forms.tax.state.NorthCarolina;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class Form_1854 {

    @FindBy(how = How.XPATH, using = "//input[@fieldname='Total Allowances']")
    public WebElement txtTotalAllowance;

    @FindBy(how = How.XPATH, using = "//input[@fieldname='Additional Withholding']")
    public WebElement txtAdditionalWithholding;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Marital Status']")
    public WebElement selectMaritalStatus;

    @FindBy(how = How.XPATH, using = "//input[@fieldname='County']")
    public WebElement txtCounty;

    @FindBy(how = How.XPATH, using = "//label[@for='1854-1854_18']")
    public WebElement chkICertify;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Residency Statement']")
    public WebElement selectResidencyStatus;

    @FindBy(how = How.XPATH, using = "//select[@fieldname='Employment Statement']")
    public WebElement selectEmploymentStatus;

    @FindBy(how = How.XPATH, using = "//button[@value='Next']")
    public WebElement btnNext;

    @FindBy(how = How.ID, using = "1854-1854_7-err")
    private WebElement lblAllowanceErr;

    public WebElement getLblAllowanceErr() {
        return lblAllowanceErr;
    }

    public WebElement getLblAdditionalAmountErr() {
        return lblAdditionalAmountErr;
    }

    @FindBy(how = How.ID, using = "1854-1854_9-err")
    private WebElement lblAdditionalAmountErr;

    public WebElement getLblCountyErr() {
        return lblCountryErr;
    }

    public WebElement getChkICertifyError() {
        return chkICertifyError;
    }

    @FindBy(how = How.ID, using = "1854-1854_12-err")
    private WebElement lblCountryErr;

    @FindBy(how = How.ID, using = "1854-1854_18-err")
    private WebElement chkICertifyError;

    public static Form_1854 initElement() {
         return PageFactory.initElements(Driver.getDriver(), Form_1854.class);
    }

    public void fillNC4Details(String allowance, String additionalWithholding,String marital,String county,String residency, String employment){
        SeleniumTest.clearAndSetText(txtTotalAllowance,allowance);
        SeleniumTest.clearAndSetText(txtAdditionalWithholding,additionalWithholding);
        SeleniumTest.selectByVisibleTextFromDropDown(selectMaritalStatus,marital);
        SeleniumTest.clearAndSetText(txtCounty,county);
        SeleniumTest.click(chkICertify);
        SeleniumTest.selectByVisibleTextFromDropDown(selectResidencyStatus,residency);
        SeleniumTest.waitMs(2000);
        btnNext.click();
    }

    public void setAllowanceAndAdditionalAmounts(String amount) {
        SeleniumTest.clearAndSetText(txtAdditionalWithholding, amount);
        SeleniumTest.clearAndSetText(txtTotalAllowance, amount);
    }
}
