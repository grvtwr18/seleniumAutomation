package Sites.CandidatePortal.Forms.individualizedReview;

import TWFramework.SeleniumTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * This file contains supporting methods for Overview page displayed in IR workflow.
 * Created by jgupta on 10/1/2017.
 */
public class FormID20752IrOverviewPage extends IrWorkflowPages {
    @FindBy(how = How.CSS, using = "label[class='checkboxLabel formFieldLabelRequired']")
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.CSS, using = "div.panelSection")
    private static WebElement irOverviewSection;

    private static final String backgroundReportLinkText = "LINK TO THE BACKGROUND REPORT";

    /**
     * Checks the checkbox on IR overview page.
     */
    public static void checkIacknowledgeCheckbox() {
        SeleniumTest.click(iAcknowledgeCheckbox);
        SeleniumTest.isCheckboxChecked(iAcknowledgeCheckbox);
    }

    public static boolean isBgReportLinkVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.linkText(backgroundReportLinkText));
    }

    /**
     * Returns the text in IR Overview section.
     * @return Text
     */
    public static String getIrOverviewText() {
        return SeleniumTest.getText(irOverviewSection);
    }
}
