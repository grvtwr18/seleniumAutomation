package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_6845_EEOForm extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='6845-108_15_2']")
    private WebElement noRadiobutton;

    protected Logger logger = LoggerFactory.getLogger(Form_6845_EEOForm.class);

    public static Form_6845_EEOForm getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_6845_EEOForm.class);
    }

    public void chooseNo() {
        noRadiobutton.click();
        logger.info("No Radio Button Chosen");
    }

}
