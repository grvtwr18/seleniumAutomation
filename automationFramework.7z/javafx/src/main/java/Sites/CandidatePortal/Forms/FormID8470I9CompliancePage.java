package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

/**
 * Created by abrackett on 12/21/2015.
 */
public class FormID8470I9CompliancePage extends FormPage {
    @FindBy(how = How.ID, using = "8470-100_16-100_16")
    private WebElement firstDayOfEmploymentBox;

    @FindBy(how = How.XPATH, using = "//label[@for='8470-311_2_List A']")
    private WebElement listARadiobutton;

    @FindBy(how = How.ID, using = "8470-311_4")
    private WebElement listADocumentTitle;

    @FindBy(how = How.ID, using = "8470-311_5")
    private WebElement issuingAuthorityBox;

    @FindBy(how = How.ID, using = "8470-311_6")
    private WebElement passportCardNumberBox;

    @FindBy(how = How.XPATH, using = "//label[@for='8470-311_153']")
    private WebElement checkExpirationDateNA;

    @FindBy(how = How.ID, using = "8470-311_141")
    private WebElement genderDropDown;

    @FindBy(how = How.ID, using = "8470-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * Fills in the first day of employment
     * @param lDate
     * @return
     */
    public FormID8470I9CompliancePage setFirstDayOfEmployment(LocalDate lDate) {
        String twoDigitMonth = Integer.toString(lDate.getMonthValue());
        if(twoDigitMonth.length() < 2)
            twoDigitMonth = "0" + twoDigitMonth;

        String twoDigitDay = Integer.toString(lDate.getDayOfMonth());
        if(twoDigitDay.length() < 2)
            twoDigitDay = "0" + twoDigitDay;

        firstDayOfEmploymentBox.clear();
        firstDayOfEmploymentBox.sendKeys(twoDigitMonth + "/" + twoDigitDay + "/" + Integer.toString(lDate.getYear()));
        firstDayOfEmploymentBox.sendKeys(Keys.TAB);
        // Explicitly waiting for the calendar control to go away...
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 5);
        return this;
    }

    /**
     * Chooses list A
     * @return
     */
    public FormID8470I9CompliancePage chooseListA() {
        listARadiobutton.click();
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(listADocumentTitle).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        return this;
    }

    /**
     * Selects an option from list A
     * @param documentTitle
     * @return
     */
    public FormID8470I9CompliancePage selectDocumentA(String documentTitle) {
        Select listASelect = new Select(listADocumentTitle);
        listASelect.selectByVisibleText(documentTitle);
        return this;
    }

    /**
     * Sets the issuing authority 9 digits
     * @param issuingAuthority
     * @return
     */
    public FormID8470I9CompliancePage setIssuingAuthority(String issuingAuthority) {
        SeleniumTest.clearAndSetText(issuingAuthorityBox, issuingAuthority);
        return this;
    }

    /**
     * sets Passport number 9 digits
     * @param passportNumber
     * @return
     */
    public FormID8470I9CompliancePage setPassportNumber(String passportNumber) {
        SeleniumTest.clearAndSetText(passportCardNumberBox, passportNumber);
        return this;
    }

    /**
     * Checks expiration as NA
     * @return
     */
    public FormID8470I9CompliancePage checkExpirationNA() {
        if(!Driver.getDriver().findElement(By.id("8470-311_153")).isSelected())
            checkExpirationDateNA.click();
        return this;
    }

    /**
     * Selects gender
     * @param gender
     * @return
     */
    public FormID8470I9CompliancePage selectGender(String gender) {
        Select genderSelect = new Select(genderDropDown);
        genderSelect.selectByVisibleText(gender);
        return this;
    }

    /**
     * Clicks next Button
     * @return
     */
    public FormID7FormReviewResults clickNext() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID7FormReviewResults.class);
    }
}
