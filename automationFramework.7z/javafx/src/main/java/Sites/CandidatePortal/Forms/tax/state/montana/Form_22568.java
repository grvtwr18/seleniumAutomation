package Sites.CandidatePortal.Forms.tax.state.montana;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.apache.xpath.operations.Bool;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_22568 extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "22568-div-100_1")
    private WebElement firstName;

    @FindBy(how = How.ID, using = "22568-div-100_3")
    private WebElement lastName;

    @FindBy(how = How.ID, using = "22568-div-100_5")
    private WebElement socialSecurityNumber;

    @FindBy(how = How.ID, using = "22568-div-100_7")
    private WebElement homeAddress;

    @FindBy(how = How.ID, using = "22568-div-22568_8")
    private WebElement cityStateZip;

    @FindBy(how = How.ID, using = "22568-div-22551_7")
    private WebElement section1BoxA;

    @FindBy(how = How.ID, using = "22568-div-22551_9")
    private WebElement section1BoxB;

    @FindBy(how = How.ID, using = "22568-div-22551_11")
    private WebElement section1BoxC;

    @FindBy(how = How.ID, using = "22568-div-22551_13")
    private WebElement section1BoxD;

    @FindBy(how = How.ID, using = "22568-div-22551_15")
    private WebElement section1BoxE;

    @FindBy(how = How.ID, using = "22568-div-22551_17")
    private WebElement section1BoxF;

    @FindBy(how = How.ID, using = "22568-div-22551_19")
    private WebElement section1BoxG;

    @FindBy(how = How.ID, using = "22568-div-22551_21")
    private WebElement section1BoxH;

    @FindBy (how = How.ID, using = "22568-div-22551_23")
    private WebElement section2Checkbox1;

    @FindBy (how = How.ID, using = "22568-div-22551_40")
    private WebElement section2Checkbox3;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_22568() {
    }

    public static Form_22568 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(),Form_22568.class);
    }

    public String getFirstName() {
        return firstName.getText();
    }

    public String getLastName() {
        return lastName.getText();
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber.getText();
    }

    public String getHomeAddress() {
        return homeAddress.getText();
    }

    public String getCityStateZip() {
        return cityStateZip.getText();
    }

    public boolean section2CheckBox1Checked() {
        Boolean attr = section2Checkbox1.isEnabled();
        if (attr != null) {
            return true;
        }
        return false;
    }

    public boolean section2CheckBox3Checked() {
        Boolean attr = section2Checkbox3.isEnabled();
        if (attr != null) {
            return true;
        }
        return false;
    }

    public String getSection1BoxAValue() {
        return section1BoxA.getText();
    }

    public String getSection1BoxBValue() {
        return section1BoxB.getText();
    }

    public String getSection1BoxCValue() {
        return section1BoxC.getText();
    }

    public String getSection1BoxDValue() {
        return section1BoxD.getText();
    }

    public String getSection1BoxEValue() {
        return section1BoxE.getText();
    }

    public String getSection1BoxFValue() {
        return section1BoxF.getText();
    }

    public String getSection1BoxGValue() {
        return section1BoxG.getText();
    }

    public String getSection1BoxHValue() {
        return section1BoxH.getText();
    }
}
