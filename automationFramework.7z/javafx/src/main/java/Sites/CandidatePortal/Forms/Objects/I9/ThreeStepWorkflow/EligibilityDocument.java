package Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow;

import java.time.LocalDate;

public class EligibilityDocument {
    private Section2.Documents.ListDocuments document;
    private boolean                           receipt                  = false;
    private String                            issuingAuthority         = "U.S. Department of State";
    private String                            documentNumber           = "123456789";
    private LocalDate expirationDate           = LocalDate.now().plusYears(5);

    public EligibilityDocument() {}

    public EligibilityDocument(Section2.Documents.ListDocuments document, boolean receipt, String issuingAuthority, String documentNumber, LocalDate expirationDate) {
        this.document = document;
        this.receipt = receipt;
        this.issuingAuthority = issuingAuthority;
        this.documentNumber = documentNumber;
        this.expirationDate = expirationDate;
    }

    public Section2.Documents.ListDocuments getDocument() {
        return this.document;
    }

    public boolean isReceipt() {
        return receipt;
    }

    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }


}
