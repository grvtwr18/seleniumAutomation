package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Form_16499_PreviewPage extends CandidatePortalPages {

    public static final By BY_EMPLOYMENT_TYPE = By.xpath("//div[@id='16499-div-16453_27']");
    // region Employee Information
    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-100_3']/span")
    private WebElement lastNameField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-100_1']/span")
    private WebElement firstNameField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-100_2']/span")
    private WebElement middleNameField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16499_4']/span")
    private WebElement addressLine1Field;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16499_5']/span")
    private WebElement cityField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16499_6']/span")
    private WebElement stateField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16499_7']/span")
    private WebElement zipField;

    // endregion

    // region Position Information

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_1']/span")
    private WebElement businessUnitField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_2']/span")
    private WebElement jobTitleField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_4']/span")
    private WebElement supervisorField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_7']/span")
    private WebElement positionAddressLine1Field;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_9']/span")
    private WebElement positionCityField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_11']/span")
    private WebElement positionStateField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_12']/span")
    private WebElement positionZipField;


    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_15']/span")
    private WebElement hireEndDateField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_18']/span")
    private WebElement hourlyPayRateField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-100_16']/span")
    private WebElement startHireDateField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_19']/span")
    private WebElement payFrequencyField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_20']/span")
    private WebElement checkRoutingCodeField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_21']/span")
    private WebElement hoursStandardDayField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_23']/span")
    private WebElement unionLocalCodeField;

    @FindBy(how = How.XPATH, using = "//div[@id='16499-div-16453_25']/span")
    private WebElement notesField;

    @FindBy(how = How.ID, using = "17070-17070_2")
    private WebElement criminalNameField;

    @FindBy(how = How.XPATH, using = "//div[@id='17070-div-17070_3']/div[contains(@class,'datesigned-')]")
    private WebElement criminalDateField;

    @FindBy(how = How.XPATH, using = "//div[@id='17070-div-17056_2'][0]/input[@type='radio']")
    private WebElement criminalYesRadioField;

    @FindBy(how = How.XPATH, using = "//div[@id='17070-div-17056_2'][1]/input[@type='radio']")
    private WebElement criminalNoRadioField;

    //TODO:  Individual Criminal Yes Answers for possible permutations of more than one.

    @FindBy(how = How.XPATH, using = "//div[@id='17070-div-17070_4']/div[contains(@class, 'datesigned-')]")
    private WebElement criminalDateSignedField;

    // endregion
    public static Form_16499_PreviewPage getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16499_PreviewPage.class);
    }

    public String getLastNameField() {
        return lastNameField.getText();
    }

    public String getFirstNameField() {
        return firstNameField.getText();
    }

    public String getMiddleNameField() {
        return middleNameField.getText();
    }

    public String getAddressLine1Field() {
        return addressLine1Field.getText();
    }

    public String getCityField() {
        return cityField.getText();
    }

    public String getStateField() {
        return stateField.getText();
    }

    public String getZipField() {
        return zipField.getText();
    }

    public String getBusinessUnitField() {
        return businessUnitField.getText();
    }

    public String getJobTitleField() {
        return jobTitleField.getText();
    }

    public String getSupervisorField() {
        return supervisorField.getText();
    }

    public String getPositionAddressLine1Field() {
        return positionAddressLine1Field.getText();
    }

    public String getPositionCityField() {
        return positionCityField.getText();
    }

    public String getPositionStateField() {
        return positionStateField.getText();
    }

    public String getPositionZipField() {
        return positionZipField.getText();
    }

    public boolean getEmploymentTemporaryField() {
        return null !=
                ((EventFiringWebDriver)Driver.getDriver()).getWrappedDriver()
                        .findElements(BY_EMPLOYMENT_TYPE)
                        .get(0)
                        .findElement(By.xpath("./input[@type='radio']"))
                        .getAttribute("checked");
    }

    public boolean getEmploymentSeasonalField() {
        return null !=
                ((EventFiringWebDriver)Driver.getDriver()).getWrappedDriver()
                        .findElements(BY_EMPLOYMENT_TYPE)
                        .get(1)
                        .findElement(By.xpath("./input[@type='radio']"))
                        .getAttribute("checked");
    }

    public boolean getEmploymentRegularField() {
        return getEmploymentTemporaryField() == false && getEmploymentSeasonalField() == false;
    }

    public LocalDate getHireEndDateField() {
        return LocalDate.parse(hireEndDateField.getText(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    }

    public String getHourlyPayRateField() {
        return hourlyPayRateField.getText();
    }

    public LocalDate getStartHireDateField() {
        return LocalDate.parse(startHireDateField.getText(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    }

    public String getPayFrequencyField() {
        return payFrequencyField.getText();
    }

    public String getCheckRoutingCodeField() {
        return checkRoutingCodeField.getText();
    }

    public String getHoursStandardDayField() {
        return hoursStandardDayField.getText();
    }

    public String getUnionLocalCodeField() {
        return unionLocalCodeField.getText();
    }

    public String getNotesField() {
        return notesField.getText();
    }

    public String getCriminalNameField() {
        return criminalNameField.getText();
    }

    public LocalDate getCriminalDateField() {
        return LocalDate.parse(criminalDateField.getText(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    }

    public boolean getCriminalYesRadioField() {
        return null != criminalYesRadioField.getAttribute("checked");
    }

    public boolean getCriminalNoRadioField() {
        return null != criminalNoRadioField.getAttribute("checked");
    }

    public LocalDate getCriminalDateSignedField() {
        return LocalDate.parse(criminalDateSignedField.getText(), DateTimeFormatter.ofPattern("MM/dd/yyyy"));
    }
}
