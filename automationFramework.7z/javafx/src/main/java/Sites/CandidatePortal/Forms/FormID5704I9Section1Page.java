package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Created by jgupta on 4/6/2016.
 */
public class FormID5704I9Section1Page extends FormPage {

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    @FindBy(how = How.ID, using = "welcome")
    private static WebElement welcome;

    @FindBy (how = How.CSS, using = "#formi9forcandidate > span")
    private static WebElement formI9CandidateHeaderMessage;

    @FindBy(how = How.ID, using = "changeverifertext")
    private static WebElement changEveriferText;

    @FindBy(how = How.ID, using = "5704-I9s1_1")
    private static WebElement firstNameTextbox;

    @FindBy(how = How.ID, using = "5704-I9s1_2")
    private static WebElement lastNameTextbox;

    @FindBy(how = How.ID, using = "5704-I9s1_3_1")
    private static WebElement middleNameTextbox;

    @FindBy(how = How.CSS, using = "label.checkboxLabel")
    private static WebElement noMiddleNameCheckboxLabel;

    @FindBy(how = How.ID, using = "5704-I9s1_3NA")
    private static WebElement noMiddleNameCheckbox;

    @FindBy(how = How.ID, using = "5704-I9s1_4_1")
    private static WebElement otherNamesTextbox;

    @FindBy(how = How.CSS, using = "label.checkboxLabel[for='5704-I9s1_4NA']")
    private static WebElement otherNameCheckboxLabel;

    @FindBy(how = How.ID, using = "5704-I9s1_4NA")
    private static WebElement noOtherNamesCheckbox;

    @FindBy(how = How.ID, using = "5704-I9s1_11")
    private static WebElement ssnTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Date of Birth']")
    private static WebElement dateOfBirthTextbox;

    @FindBy(how = How.ID, using = "5704-I9s1_5")
    private static WebElement addressTextbox;

    @FindBy(how = How.ID, using = "5704-I9s1_6_1")
    private static WebElement apartmentNumberTextbox;

    @FindBy(how = How.CSS, using = "label[for='5704-I9s1_6NA']")
    private static WebElement noApartmentNumberCheckbox;

    @FindBy(how = How.ID, using = "5704-addressI9s1_7-I9s1_7")
    private static WebElement cityTextbox;

    @FindBy(how = How.ID, using = "5704-addressI9s1_7-I9s1_56")
    private static WebElement countryOrRegion;

    @FindBy(how = How.ID, using = "5704-addressI9s1_7-I9s1_8")
    private static WebElement stateOrProvince;

    @FindBy(how = How.ID, using = "5704-addressI9s1_7-I9s1_9")
    private static WebElement zip;

    @FindBy(how = How.ID, using = "5704-I9s1_12_1")
    private static WebElement email;

    @FindBy(how = How.ID, using = "5704-qEmailAddressNA")
    private static WebElement doNotProvideEmailToDHSCheckbox;

    @FindBy(how = How.ID, using = "5704-I9s1_13_1")
    private static WebElement telephoneNumber;

    @FindBy(how = How.ID, using = "5704-qPhoneNumberNA")
    private static WebElement doNotProvideTelephoneToDHSCheckbox;

    @FindBy(how = How.CSS, using = "label[for='5704-I9s1_14_USCITIZEN']")
    private static WebElement citizenRadiobutton;

    @FindBy(how = How.CSS, using = "label[for='5704-I9s1_14_USNONCITIZENNATIONAL']")
    private static WebElement nonCitizenRadiobutton;

    @FindBy(how = How.CSS, using = "label[for='5704-I9s1_14_LAWFULPERMANENTRESIDENT']")
    private static WebElement lawfulResidentRadiobutton;

    @FindBy(how = How.CSS, using = "label[for='5704-I9s1_14_ALIENAUTHORIZEDTOWORK']")
    private static WebElement alienAuthorizedRadiobutton;

    @FindBy(how = How.CSS, using = "label[for='5704-qCertifySigning']")
    private static WebElement iAcknowledgeLabel;

    @FindBy(how = How.ID, using = "5704-qCertifySigning")
    private static WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.ID, using = "5704-previousnextbuttons-nextbutton")
    private static WebElement nextButtonCandidate;

    @FindBy(how = How.ID, using = "5704-nextbutton")
    private static WebElement nextButtonVerifier;

    @FindBy(how = How.ID, using = "5704-previousnextbuttons-savebutton")
    private static WebElement saveButton;

    @FindBy(how = How.XPATH, using = "//label[@for='5704-I9s1_11']")
    private static WebElement ssnLabel;

    /**
     * Constructor static.
     */
    static {
        PageFactory.initElements(Driver.getDriver(), FormID5704I9Section1Page.class);
    }

    public static boolean isSSNRequired() {
        return ssnLabel.getAttribute("class").equals("formFieldLabelRequired");
    }

    /**
     * Types First name in form
     * @param fName
     */
    public void typeFirstName(String fName){
        SeleniumTest.clearAndSetText(firstNameTextbox, fName);
    }

    /**
     * Types Last name in form
     * @param lName
     */
    public void typeLastName(String lName){
        SeleniumTest.clearAndSetText(lastNameTextbox, lName);
    }

    /**
     * Types middle name in form
     * @param mName
     */
    public void typeMiddleName(String mName){
        SeleniumTest.clearAndSetText(middleNameTextbox, mName);
    }

    /**
     * Types other names in form
     * @param oName
     */
    public void typeOtherName(String oName){
        SeleniumTest.clearAndSetText(otherNamesTextbox, oName);
    }

    /**
     * Types SSN in form.
     * @param ssn
     */
    public void typeSSN(String ssn) {
        SeleniumTest.clearAndSetText(ssnTextbox, ssn);
    }

    /**
     * Types date of birth in form
     * @param dob
     */
    public void typedob(String dob) {
        SeleniumTest.clearAndSetText(dateOfBirthTextbox, dob);
    }

    /**
     * Types address in form
     * @param address
     */
    public void typeAddress(String address){
        SeleniumTest.clearAndSetText(addressTextbox, address);
    }

    /**
     * Types apartment number in form
     * @param aptNumber
     */
    public void typeApartmentNumber(String aptNumber){
        SeleniumTest.clearAndSetText(apartmentNumberTextbox, aptNumber);
    }

    /**
     * Types city in form
     * @param city
     */
    public void typeCity(String city){
        SeleniumTest.clearAndSetText(cityTextbox, city);
    }

    /**
     * Clicks next and returns appropriate page class
     * @param returnedClass appropriate page class
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        if(SeleniumTest.isElementPresent(nextButtonCandidate)) {
            nextButtonCandidate.click();
        }
        else {
            nextButtonVerifier.click();
        }
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static CandidatePortalPages clickSave() {
        saveButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID5704I9Section1Page.class);
    }

    /**
     * Fill in All Candidate Data in Form I-9 Section 1
     * @param candidate The Candidate Object to use
     * @param provideAKA Provide an also known as name
     * @param provideEmail Provide e-mail address to DHS
     * @param provideTelephone Provide telephone number to DHS
     * @param eligibility Provide type of Employment Eligibility
     */
    public static void fillCandidateData(Candidate candidate, boolean provideAKA, boolean provideEmail, boolean provideTelephone, EmploymentEligibility eligibility) {
        SeleniumTest.clearAndSetText(firstNameTextbox, candidate.getFirstName());
        if(candidate.getMiddleName().isEmpty()) {
            SeleniumTest.check(noMiddleNameCheckbox);
        }
        else {
            SeleniumTest.clearAndSetText(middleNameTextbox, candidate.getMiddleName());
        }
        SeleniumTest.clearAndSetText(lastNameTextbox, candidate.getLastName());
        String alsoKnownAs = candidate.getAlternateFirstName() + " " + candidate.getAlternateLastName();
        if(provideAKA) {
            if(alsoKnownAs.trim().isEmpty()) {
                SeleniumTest.check(noOtherNamesCheckbox);
            }
            else {
                SeleniumTest.clearAndSetText(otherNamesTextbox, alsoKnownAs);
            }
        }
        else {
            SeleniumTest.check(otherNameCheckboxLabel, noOtherNamesCheckbox);
        }
        SeleniumTest.clearAndSetText(ssnTextbox, candidate.getSocialSecurityNumber());
        SeleniumTest.clearAndSetText(dateOfBirthTextbox, candidate.getDOB().format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        SeleniumTest.clearAndSetText(addressTextbox, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(apartmentNumberTextbox, candidate.getApartmentNumber());
        SeleniumTest.clearAndSetText(cityTextbox, candidate.getCity());
        SeleniumTest.selectByVisibleTextFromDropDown(
                countryOrRegion,
                candidate.getCountryOrRegion()
        );
        SeleniumTest.selectByVisibleTextFromDropDown(
                stateOrProvince,
                candidate.getState()
        );
        SeleniumTest.clearAndSetText(zip, candidate.getZip());
        SeleniumTest.check(email, doNotProvideEmailToDHSCheckbox);
        if(provideEmail) {
            if(!candidate.getEmailAddress().isEmpty()) {
                SeleniumTest.clearAndSetText(email, candidate.getEmailAddress(), true);
            }
        }
        SeleniumTest.check(telephoneNumber, doNotProvideTelephoneToDHSCheckbox);
        if(provideTelephone) {
            if(!candidate.getCandidatePhone().isEmpty()) {
                SeleniumTest.clearAndSetText(telephoneNumber, candidate.getCandidatePhone(), true);
            }
        }
        switch(eligibility) {
            case CITIZEN:
                citizenRadiobutton.click();
                break;
            case NON_CITIZEN:
                nonCitizenRadiobutton.click();
                break;
            case LAWFUL_RESIDENT:
                lawfulResidentRadiobutton.click();
                break;
            case ALEN_AUTHORIZED_TO_WORK:
                alienAuthorizedRadiobutton.click();
                break;
        }
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
    }

    public enum EmploymentEligibility {
        CITIZEN,
        NON_CITIZEN,
        LAWFUL_RESIDENT,
        ALEN_AUTHORIZED_TO_WORK;
    }

    public static String getFormI9CandidateHeaderMessageText() {
        SeleniumTest.defaultWaitForElementWithMultiplier(.5);
        ArrayList<String> tabs = new ArrayList<String>(Driver.getDriver().getWindowHandles());
        if (tabs.size() > 1) {
            SeleniumTest.switchToTab(1);
        }

        WaitUntil.waitUntil(() -> formI9CandidateHeaderMessage.isDisplayed());
        return formI9CandidateHeaderMessage.getText();
    }

    public static String getCurrentUrlString() {
        return Driver.getDriver().getCurrentUrl();
    }

    public static void clickSignOut() {
        signOutLink.click();
    }
}
