package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.PortalSignInPage;
import TWFramework.SeleniumTest;
import Utility.URLParameters;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by jgupta on 8/31/2015.
 */
public class FormID87253002CandidateCustomFieldsPage extends FormPage {

    private static final String STRING_VALUE_1 = "String Value 1";
    private static final String STRING_VALUE_2 = "String Value 2";
    private static final String BOLD = "Bold";
    private static final String ONE = "One";
    private static final String VALUE = "=77.1*850";
    private static final String X05 = "0x05";
    private static final int HOW_LONG = 10;
    @FindBy(how = How.ID, using = "87253002-87253002_1")
    private static WebElement testFieldOne_no_no_noTextBox;

    @FindBy(how = How.ID, using = "87253002-87253002_3")
    private static WebElement textFieldTwo_yes_yes_yesTextBox;

    @FindBy(how = How.ID, using = "87253002-87253002_4")
    private static WebElement ListFieldOne_no_no_noDropDown;

    @FindBy(how = How.ID, using = "87253002-87253002_5")
    private static WebElement ListFieldTwo_no_no_yesDropDown;

    @FindBy(how = How.ID, using = "87253002-87253002_6")
    private static WebElement ListFieldThree_no_yes_noDropDown;

    @FindBy(how = How.ID, using = "87253002-87253002_7")
    private static WebElement ListFieldFour_no_yes_yesDropDown;

    @FindBy(how = How.ID, using = "87253002-87253002_8")
    private static WebElement ListFieldFive_yes_no_noDropDown;

    @FindBy(how = How.ID, using = "87253002-87253002_9")
    private static WebElement ListFieldSix_yes_no_yesDropDown;

    @FindBy(how = How.ID, using = "87253002-87253002_10")
    private static WebElement ListFieldSeven_yes_yes_noDropDown;

    @FindBy(how = How.ID, using = "87253002-87253002_11")
    private static WebElement ListFieldEight_yes_yes_yesDropDown;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private static WebElement saveButton;
    private String taskIDFromURL;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    @FindBy(how = How.LINK_TEXT, using = "IsVisible")
    private static WebElement isVisibleLink;

    /**
     * Constructs a new Profile page object.
     * @author guptaj
     */
    public FormID87253002CandidateCustomFieldsPage() {

    }

    /**
     * Types in the custom field with label FieldOne_no_no_no
     * @param value
     */
    public static void typeTextFieldOne_no_no_no(String value) {
        SeleniumTest.clearAndSetText(testFieldOne_no_no_noTextBox, value);
    }

    /**
     * Types value in custom field with label FieldTwo_yes_yes_yes
     * @param value
     */
    public static void typeTextFieldTwo_yes_yes_yes(String value){
        SeleniumTest.clearAndSetText(textFieldTwo_yes_yes_yesTextBox, value);
    }

    /**
     * Selects value from custom field drop down with label FieldOne_no_no_no
     * @param value
     */
    public static void selectListFieldOne_no_no_no(String value){
        Select dropDown = new Select(ListFieldOne_no_no_noDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Selects value from custom field drop down with label FieldTwo_no_no_yes
     * @param value
     */
    public static void selectListFieldTwo_no_no_yes(String value){
        Select dropDown = new Select(ListFieldTwo_no_no_yesDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Selects value from custom field drop down with label FieldThree_no_yes_no
     * @param value
     */
    public static void selectListFieldThree_no_yes_no(String value){
        Select dropDown = new Select(ListFieldThree_no_yes_noDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Selects value from custom field drop down with label FieldFour_no_yes_yes
     * @param value
     */
    public static void selectListFieldFour_no_yes_yes(String value){
        Select dropDown = new Select(ListFieldFour_no_yes_yesDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Selects value from custom field drop down with label FieldFive_yes_no_no
     * @param value
     */
    public static void selectListFieldFive_yes_no_no(String value){
        Select dropDown = new Select(ListFieldFive_yes_no_noDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Selects value from custom field drop down with label FieldSix_yes_no_yes
     * @param value
     */
    public static void selectListFieldSix_yes_no_yes(String value){
        Select dropDown = new Select(ListFieldSix_yes_no_yesDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Selects value from custom field drop down with label FieldSeven_yes_yes_no
     * @param value
     */
    public static void selectListFieldSeven_yes_yes_no(String value){
        Select dropDown = new Select(ListFieldSeven_yes_yes_noDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Selects value from custom field dropdown with label FieldEight_yes_yes_yes
     * @param value
     */
    public static void selectListFieldEight_yes_yes_yes(String value){
        Select dropDown = new Select(ListFieldEight_yes_yes_yesDropDown);
        dropDown.selectByVisibleText(value);
    }

    /**
     * Click on the save button.
     */
    public static void clickSaveButton() {
        saveButton.click();
    }

    /**
     * Click on Next button
     * @return
     */
    public static FormID87253003IsVisiblePage clickNextButtonToGoToFormID87253003IsVisiblePage() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID87253003IsVisiblePage.class);
    }

    /**
     * Returns task id from the url.
     * @return
     */
    public String getTaskIDFromURL() {
        return URLParameters.getValue(Driver.getDriver().getCurrentUrl())
              .get("TaskID");
    }

    /**
     * Clicks on Sign out link.
     * @return PortalSignInPage
     */
    public static PortalSignInPage clickSignOut() {
        signOutLink.click();
        Driver.getDriver().manage().deleteAllCookies();
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Fills Custom fields form
     * @param customTextFieldOne_no_no_noValue
     * @param customTextFieldTwo_yes_yes_yesValue
     * @param customsListFieldOne_no_no_noValue
     * @param customListFieldTwo_no_no_yesValue
     * @param customListFieldThree_no_yes_noValue
     * @param customListFieldFour_no_yes_yesValue
     * @param customListFieldFive_yes_no_noValue
     * @param customListFieldSix_yes_no_yesValue
     * @param customListFieldSeven_yes_yes_noValue
     * @param customListFieldEight_yes_yes_yesValue
     */
    public static void fillCustomFieldsForm(String customTextFieldOne_no_no_noValue, String customTextFieldTwo_yes_yes_yesValue, String customsListFieldOne_no_no_noValue,
                                            String customListFieldTwo_no_no_yesValue, String customListFieldThree_no_yes_noValue, String customListFieldFour_no_yes_yesValue,
                                            String customListFieldFive_yes_no_noValue, String customListFieldSix_yes_no_yesValue, String customListFieldSeven_yes_yes_noValue,
                                            String customListFieldEight_yes_yes_yesValue) {
        typeTextFieldOne_no_no_no(customTextFieldOne_no_no_noValue);
        typeTextFieldTwo_yes_yes_yes(customTextFieldTwo_yes_yes_yesValue);
        selectListFieldOne_no_no_no(customsListFieldOne_no_no_noValue);
        selectListFieldTwo_no_no_yes(customListFieldTwo_no_no_yesValue);
        selectListFieldThree_no_yes_no(customListFieldThree_no_yes_noValue);
        selectListFieldFour_no_yes_yes(customListFieldFour_no_yes_yesValue);
        selectListFieldFive_yes_no_no(customListFieldFive_yes_no_noValue);
        selectListFieldSix_yes_no_yes(customListFieldSix_yes_no_yesValue);
        selectListFieldSeven_yes_yes_no(customListFieldSeven_yes_yes_noValue);
        selectListFieldEight_yes_yes_yes(customListFieldEight_yes_yes_yesValue);
    }

    /**
     * Click on Next button
     * @return
     */
    public static CandidatePortalPages clickNextButton(Class<? extends CandidatePortalPages> returnClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Fills the mandatory fields on custom fields page
     * @return
     */
    public FormID87253002CandidateCustomFieldsPage fillMandatoryFieldsWithDefaults() {
        typeTextFieldOne_no_no_no(STRING_VALUE_1);
        typeTextFieldTwo_yes_yes_yes(STRING_VALUE_2);
        selectListFieldOne_no_no_no(BOLD);
        selectListFieldThree_no_yes_no(ONE);
        selectListFieldSix_yes_no_yes(VALUE);
        selectListFieldEight_yes_yes_yes(X05);
        return this;
    }

    /**
     * Clicks on Is Visible link in left nav
     * @return
     */
    public static FormID87253003IsVisiblePage clickIsVisibleLink() {
        isVisibleLink.click();
        return PageFactory.initElements(Driver.getDriver(), FormID87253003IsVisiblePage.class);
    }
}