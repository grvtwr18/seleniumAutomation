package Sites.CandidatePortal.Forms.eDispute;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 5/12/2017.
 */
public class DisputeReportPage {
    static {
        PageFactory.initElements(Driver.getDriver(), DisputeReportPage.class);
    }

    @FindBy(how = How.XPATH, using = "(//button[@type='button'])[3]")
    private static WebElement firstReasonForDisputeButton;

    @FindBy(how = How.CLASS_NAME, using = "dispute reasons required")
    private static WebElement reasonForDisputeDropdown;

    @FindBy(how = How.CSS, using = "table.subreport>tbody>tr>td.content")
    public static WebElement disclosureFirstParagraph;

    @FindBy(how = How.XPATH, using = "//div[@id='instructions-disclaimers-info']/div/table/tbody/tr[2]/td")
    private static WebElement disclosureSecondParagraph;

    private static WebElement getReasonForDisputeOptionElement(int reasonForDisputeOptionIndex) {
        return Driver.getDriver().findElement(By.xpath(
                        "(//input[@value='EXPUNGED'])[" + reasonForDisputeOptionIndex + "]"));
    }

    public static void selectReasonForDispute(int reasonForDisputeButtonIndex, int reasonForDisputeOptionIndex,
                                              ReasonForDispute reasonForDisputeValue) {
        clickReasonForDispute(reasonForDisputeButtonIndex);
        WebElement checkbox = getReasonForDisputeOptionElement(reasonForDisputeOptionIndex);
        SeleniumTest.waitForElementVisible(checkbox);

        switch (reasonForDisputeValue) {
            case EXPUNGED:
                SeleniumTest.click(checkbox);
                break;
            // TODO: Handle options other than EXPUNGED.
        }
    }

    public static void clickReasonForDispute(int reasonForDisputeButtonIndex) {
        WebElement reasonForDisputeButton = Driver.getDriver().findElement(
                By.xpath("(//button[@type='button'])[" + reasonForDisputeButtonIndex + "]"));
        SeleniumTest.click(reasonForDisputeButton, 7);
    }

    public static void typeAdditionalComments(int textAreaIndex, String additionalComments) {
        WebElement addnlCommentsTextArea = Driver.getDriver().
                findElement(By.xpath("(//textarea)[" + textAreaIndex + "]"));
        SeleniumTest.clearAndSetText(addnlCommentsTextArea, additionalComments);
    }

    public static void clickNextButton(int buttonIndex) {
        SeleniumTest.click(By.xpath("(//button[@type='button'])[" + buttonIndex + "]"));
    }

    public static String getEdisputeDisclosureFirstParagraph() {
        return disclosureFirstParagraph.getText();
    }

    public static String getEdisputeDisclosureSecondParagraph() {
        return disclosureSecondParagraph.getText();
    }

    public static String getModalMessage() {
        Driver.getDriver().switchTo().activeElement();
        return (Driver.getDriver().findElement(By.cssSelector("div#disputeModalDialog p")).getText());
    }

    public static void closeModal() {
        SeleniumTest.click(By.id("disputeModalConfirm"));
    }

    public static void clickCancelButton(int buttonIndex) {
        clickNextButton(buttonIndex);
    }

    public enum ReasonForDispute {
        EXPUNGED("This record was expunged, sealed, or dismissed"),
        IDENTITY_THEFT("I have been the victim of identity theft"),
        RECORD_BELONGS_TO_SOMEONE_ELSE("This record belongs to someone else"),
        DATA_NOT_UP_TO_DATE("The data in this report is not up to date"), OTHER("Other");

        private String name;

        ReasonForDispute(String name) {
            this.name = name;
        }

        public String toString() {
            return name;
        }
    }
}
