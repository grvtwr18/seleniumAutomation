package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.Form_1972_StateTaxFormsSelector;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_1918_WashingtonConfirmation extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "1918-1918_3")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1918-1918_3']")
    private WebElement iAcknowledgeLabel;

    @FindBy(how = How.ID, using = "1918-previousnextbuttons-nextbutton")
    private WebElement nextBtn;

    protected Logger logger = LoggerFactory.getLogger(Form_1918_WashingtonConfirmation.class);

    public static Form_1918_WashingtonConfirmation getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_1918_WashingtonConfirmation.class);
    }

    public Form_1918_WashingtonConfirmation checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_1918_WashingtonConfirmation uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledged Unchecked");
        return this;
    }

    public CandidatePortalPages clickNextBtn(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextBtn);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
