package Sites.CandidatePortal.Forms.eda;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class eda extends CandidatePortalPages {

    @FindBy(how = How.NAME, using = "Agree")
    private WebElement iHaveCarefullyReadAndUnderstandCheckbox;

    public static eda getInstance() {
        return PageFactory.initElements(Driver.getDriver(), eda.class);
    }

    /**
     * Blindly clicks the checkbox - apparently it has no client side notification
     * It has been clicked - you must click the form submit before the checkbox status is updated
     */
    public void checkIHaveCarefullyReadAndUnderstand() {
        SeleniumTest.waitForPageLoadToComplete();
        iHaveCarefullyReadAndUnderstandCheckbox.click();
    }
}
