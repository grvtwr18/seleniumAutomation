package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import org.openqa.selenium.By;

/**
 * Created by jgupta on 3/19/2017.
 *
 * Not to be confused with the Customer's ReviewInformationPage, this
 * page appears when the Candidate is supposed to review his/her information
 * before submitting.
 *
 */
public class CandidateReviewInformationPage {

    private static final By titleBarLocator = By.className("titleBar");
    private static final By submitButtonLocator = By.id("btnSubmit");
    private static final By editLinkLocator = By.className("searchAddRemoveLink");

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(titleBarLocator)
                && "Review Information".equals(SeleniumTest.getTextByLocator(titleBarLocator))
                && SeleniumTest.isElementVisibleNoWaiting(submitButtonLocator) &&
                SeleniumTest.isElementVisibleNoWaiting(editLinkLocator);

    }

    public static void clickSubmit() {
        SeleniumTest.click(submitButtonLocator);
    }

    public static void clickEditLink() {
        SeleniumTest.click(editLinkLocator);
    }
}