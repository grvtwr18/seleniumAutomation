package Sites.CandidatePortal.Forms;

import Sites.AdminConsole.Login.ExistingAccountLoginPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.apache.xpath.operations.Bool;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.io.File;
import java.util.Map;

/**
 * Created by Mayank.Jain on 2/22/2018.
 */
public class Form_17066 extends CandidatePortalPages {

    @FindBy(how = How.CSS, using = "label[for$='-17066_2_List A']")
    private WebElement listALabel;

    @FindBy(how = How.CSS, using = "input[id$='-17066_2_List A']")
    private WebElement listACheckBox;

    @FindBy(how = How.CSS, using = "select[id$='-17066_4']")
    private WebElement listDocumentTitle;

    @FindBy(how = How.CSS, using = "label[for$='-17066_134']")
    private WebElement lostReceiptLabel;

    @FindBy(how = How.CSS, using = "input[id$='-17066_134']")
    private WebElement lostReceiptCheckBox;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_3']")
    private WebElement passportNumber;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_4']")
    private WebElement documentNumber;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_7']")
    private WebElement documentNumberForEmpAuthDcoument;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_31']")
    private WebElement issuingAuthority;

    @FindBy(how = How.ID, using = "17066-I9s2_ISSUINGAUTH_PERMRES")
    private WebElement issuingAuthorityPerResDropDown;

    @FindBy(how = How.ID, using = "17066-I9s2_57")
    private WebElement AlienRegUSICNumberField;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_32']")
    private WebElement receipt;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_9-I9s2_9']")
    private WebElement expiryDate;

    @FindBy(how = How.ID, using = "17066-I9s2_9-err")
    private WebElement lblExpiryDateError;

    @FindBy(how = How.ID, using = "17066-I9s2_9_EAD-I9s2_9_EAD")
    private WebElement expiryDateForEmpAuthDocument;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_42']")
    private WebElement EmployerTitleI9s2_42;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_45']")
    private WebElement EmployerOrganizationNameI9s2_45;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_46']")
    private WebElement EmployerAddressI9s2_46;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_47']")
    private WebElement EmployerCityI9s2_47;

    @FindBy(how = How.CSS, using = "select[id$='-addressI9s2_47-I9s2B_44']")
    private WebElement EmployerCountryI9s2_47;

    @FindBy(how = How.CSS, using = "select[id$='-I9s2_48']")
    private WebElement EmployerStateI9s2_48;

    @FindBy(how = How.ID, using = "17066-addressI9s2_47-I9s2_49")
    private WebElement EmployerZipI9s2_49;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'photo page')]")
    private WebElement passprtPhotopageLabel;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'barcode page')]")
    private WebElement paasprtBarcodeLabel;


    public String getLblExpiryDateError() {
        return lblExpiryDateError.getText();
    }

    public String getLblUploadFile1Error() {
        return lblUploadFile1Error.getText();
    }

    public String getLblUploadFile2Error() {
        return lblUploadFile2Error.getText();
    }

    @FindBy(how = How.ID, using = "17066-17066_79-err")
    private WebElement lblUploadFile1Error;

    @FindBy(how = How.ID, using = "17066-17066_80-err")
    private WebElement lblUploadFile2Error;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'front')]")
    private WebElement frontPageDocumentLabel;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'back')]")
    private WebElement backPageDocumentLabel;

    @FindBy(how = How.XPATH, using = "(//a[contains(text(),'Documents in ')])[1]")
    public static WebElement reportViewdocument1stlabel;

    @FindBy(how = How.XPATH, using = "(//a[contains(text(),'Documents in ')])[2]")
    public static WebElement reportViewdocument2ndlabel;

    @FindBy(how = How.CSS, using = "label[for$='-I9s2_52']")
    private WebElement iAcknowledgeLabel;

    @FindBy(how = How.CSS, using = "input[id$='-I9s2_52']")
    private WebElement iAcknowledgeLabelCheckbox;

    @FindBy(how = How.CSS, using = "button[id$='-nextbutton']")
    private WebElement next;

    public Form_17066() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public void clickNext() {
        SeleniumTest.click(next);
    }

    public FormID1eSignPage fillFormi917066(Candidate candidate) {

        SeleniumTest.check(listALabel, listACheckBox);
        SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, "U.S. Passport");
        SeleniumTest.clearAndSetText(passportNumber, "C37310181");
        SeleniumTest.clearAndSetText(expiryDate, "02/23/2028");
        SeleniumTest.clearAndSetText(EmployerTitleI9s2_42, "SterlingTS");
        SeleniumTest.clearAndSetText(EmployerOrganizationNameI9s2_45, "Sterling");
        SeleniumTest.clearAndSetText(EmployerAddressI9s2_46, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(EmployerCityI9s2_47, candidate.getCity());

        Select countryDD = new Select(EmployerCountryI9s2_47);
        String countryName = candidate.getCountryOrRegion();
        if (countryName.length() < 3)
            countryDD.selectByValue(countryName);
        else
            countryDD.selectByVisibleText(countryName);

        Select stateDD = new Select(EmployerStateI9s2_48);
        String stateName = candidate.getState();
        if (stateName.length() < 3)
            stateDD.selectByValue(stateName);
        else
            stateDD.selectByVisibleText(stateName);
        SeleniumTest.clearAndSetText(EmployerZipI9s2_49, candidate.getZip());
        staticLogger.info("Choose and upload file.");
        Form_17060.uploadDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
        Sites.CandidatePortal.Forms.Objects.I9.Section2.UploadDocuments.clickUploadFile();

        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeLabelCheckbox);
        SeleniumTest.click(next);
        return PageFactory.initElements(Driver.getDriver(), FormID1eSignPage.class);


    }

    public FormID1eSignPage fillFormi9Section2(Boolean isBrowserAttach) {

        SeleniumTest.check(listALabel, listACheckBox);
        SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, "U.S. Passport");
        SeleniumTest.clearAndSetText(passportNumber, "C37310181");
        SeleniumTest.clearAndSetText(expiryDate, "02/23/2028");
        SeleniumTest.clearAndSetText(EmployerTitleI9s2_42, "SterlingTS");
        SeleniumTest.clearAndSetText(EmployerOrganizationNameI9s2_45, "Sterling");
        SeleniumTest.clearAndSetText(EmployerAddressI9s2_46, "123 Main Road");
        SeleniumTest.clearAndSetText(EmployerCityI9s2_47, "Los Angeles");

        Select countryDD = new Select(EmployerCountryI9s2_47);
        String countryName = "United States";
        if (countryName.length() < 3)
            countryDD.selectByValue(countryName);
        else
            countryDD.selectByVisibleText(countryName);

        Select stateDD = new Select(EmployerStateI9s2_48);
        String stateName = "California";
        if (stateName.length() < 3)
            stateDD.selectByValue(stateName);
        else
            stateDD.selectByVisibleText(stateName);
        SeleniumTest.clearAndSetText(EmployerZipI9s2_49, "90006");
        if (isBrowserAttach) {
            staticLogger.info("Choose and upload file.");
            Form_17060.uploadDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
            //Sites.CandidatePortal.Forms.Objects.I9.Section2.UploadDocuments.clickUploadFile();
        }
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeLabelCheckbox);
        SeleniumTest.click(next);
        return PageFactory.initElements(Driver.getDriver(), FormID1eSignPage.class);


    }

    public FormID1eSignPage fillFormi917066ForDifferentDcouments(Candidate candidate, String document) {

        SeleniumTest.check(listALabel, listACheckBox);
        switch (document) {
            case "U.S. Passport":
                SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, "U.S. Passport");
                SeleniumTest.clearAndSetText(passportNumber, "C37310181");
                SeleniumTest.clearAndSetText(expiryDate, "02/23/2028");
                String passportFrontPageLabel = "Attach photo page of U.S. Passport";
                Assert.assertEquals(passportFrontPageLabel, passprtPhotopageLabel.getText());
                String passportBackPageLabel = "Attach barcode page of U.S. Passport";
                Assert.assertEquals(passportBackPageLabel, paasprtBarcodeLabel.getText());
                break;
            case "U.S. Passport Card":
                SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, "U.S. Passport Card");
                SeleniumTest.clearAndSetText(passportNumber, "C37310181");
                SeleniumTest.clearAndSetText(expiryDate, "02/23/2028");
                String documentFrontPageLabel = "Attach front of document";
                Assert.assertEquals(documentFrontPageLabel, frontPageDocumentLabel.getText());
                String documentBackPageLabel = "Attach back of document";
                Assert.assertEquals(documentBackPageLabel, backPageDocumentLabel.getText());
                break;
            case "Perm. Resident Card (Form I-551)":
                SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, "Perm. Resident Card (Form I-551)");
                SeleniumTest.selectByVisibleTextFromDropDown(issuingAuthorityPerResDropDown, "U.S. Citizenship and Immigration Services");
                SeleniumTest.clearAndSetText(documentNumber, "LAN3731018134");
                SeleniumTest.clearAndSetText(expiryDate, "02/23/2028");
                String documentFrontPageLabel1 = "Attach front of document";
                Assert.assertEquals(documentFrontPageLabel1, frontPageDocumentLabel.getText());
                String documentBackPageLabel1 = "Attach back of document";
                Assert.assertEquals(documentBackPageLabel1, backPageDocumentLabel.getText());
                break;
            case "Employment Authorization Document (Form I-766)":
                SeleniumTest.selectByValueFromDropDown(listDocumentTitle, "EMPLOYMENTAUTHORIZATIONDOCUMENT");
                SeleniumTest.clearAndSetText(documentNumberForEmpAuthDcoument, "LAN3731018134");
                SeleniumTest.clearAndSetText(expiryDateForEmpAuthDocument, "02/23/2028");
                String documentFrontPageLabel2 = "Attach front of document";
                Assert.assertEquals(documentFrontPageLabel2, frontPageDocumentLabel.getText());
                String documentBackPageLabel2 = "Attach back of document";
                Assert.assertEquals(documentBackPageLabel2, backPageDocumentLabel.getText());
                break;
        }

        SeleniumTest.clearAndSetText(EmployerTitleI9s2_42, "SterlingTS");
        SeleniumTest.clearAndSetText(EmployerOrganizationNameI9s2_45, "Sterling");
        SeleniumTest.clearAndSetText(EmployerAddressI9s2_46, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(EmployerCityI9s2_47, candidate.getCity());

        Select countryDD = new Select(EmployerCountryI9s2_47);
        String countryName = candidate.getCountryOrRegion();
        if (countryName.length() < 3)
            countryDD.selectByValue(countryName);
        else
            countryDD.selectByVisibleText(countryName);

        Select stateDD = new Select(EmployerStateI9s2_48);
        String stateName = candidate.getState();
        if (stateName.length() < 3)
            stateDD.selectByValue(stateName);
        else
            stateDD.selectByVisibleText(stateName);
        SeleniumTest.waitForElementToBeClickable(EmployerZipI9s2_49);
        SeleniumTest.clearAndSetText(EmployerZipI9s2_49, candidate.getZip());
        if (document == "U.S. Passport") {
            staticLogger.info("Choose and upload file.");
            Form_17060.uploadDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
            SeleniumTest.waitMs(4000);
            staticLogger.info("Choose and upload file.");
            Form_17060.upload2ndDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
            SeleniumTest.waitMs(4000);
        } else {
            staticLogger.info("Choose and upload file.");
            Form_17060.upload3rdDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
            SeleniumTest.waitMs(4000);
            staticLogger.info("Choose and upload file.");
            Form_17060.upload4thDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
            SeleniumTest.waitMs(4000);
        }

        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeLabelCheckbox);
        SeleniumTest.click(next);
        return PageFactory.initElements(Driver.getDriver(), FormID1eSignPage.class);


    }

    public void validateErrorMessage(Candidate candidate, String document1, String document2) {
        SeleniumTest.check(listALabel, listACheckBox);
        SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, document1);
        SeleniumTest.clearAndSetText(passportNumber, "C37310181");
        SeleniumTest.clearAndSetText(expiryDate, "02/23/2028");
        SeleniumTest.clearAndSetText(EmployerTitleI9s2_42, "SterlingTS");
        SeleniumTest.clearAndSetText(EmployerOrganizationNameI9s2_45, "Sterling");
        SeleniumTest.clearAndSetText(EmployerAddressI9s2_46, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(EmployerCityI9s2_47, candidate.getCity());

        Select countryDD = new Select(EmployerCountryI9s2_47);
        String countryName = candidate.getCountryOrRegion();
        if (countryName.length() < 3)
            countryDD.selectByValue(countryName);
        else
            countryDD.selectByVisibleText(countryName);

        Select stateDD = new Select(EmployerStateI9s2_48);
        String stateName = candidate.getState();
        if (stateName.length() < 3)
            stateDD.selectByValue(stateName);
        else
            stateDD.selectByVisibleText(stateName);
        SeleniumTest.clearAndSetText(EmployerZipI9s2_49, candidate.getZip());
        staticLogger.info("Choose and upload file.");
        Form_17060.uploadDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
        SeleniumTest.waitMs(4000);
        staticLogger.info("Choose and upload file.");
        Form_17060.upload2ndDocument(new File(Form_17066.class.getClass().getResource("/HPM/Passport.jpg").getFile()));
        SeleniumTest.waitMs(4000);
        SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, document2);
        SeleniumTest.selectByVisibleTextFromDropDown(listDocumentTitle, document1);
        SeleniumTest.waitMs(4000);
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeLabelCheckbox);
        SeleniumTest.click(next);
        Assert.assertEquals("Missing U.S. Passport expiration date", getLblExpiryDateError());
        Assert.assertEquals("Attachment is required.", getLblUploadFile2Error());
        Assert.assertEquals("Attachment is required.", getLblUploadFile1Error());
    }
}
