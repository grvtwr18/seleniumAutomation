package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 4/5/2016.
 */
public class FormI9Section3Page extends FormPage {
    @FindBy(how = How.ID, using = "12532-I9s3_1")
    public static WebElement firstNameTextBox;

    @FindBy(how = How.ID, using = "12532-I9s3_3_1")
    public static WebElement middleNameTextBox;

    @FindBy(how = How.ID, using = "12532-I9s3_2")
    public static WebElement lastNameTextBox;

    @FindBy(how = How.ID, using = "12532-I9s3_52")
    public static WebElement iAcknowledgeClickableLabel;

    @FindBy(how = How.CSS, using = "label[class='checkboxLabel formFieldLabelRequired']")
    public static WebElement iAcknowledgeCheckableCheckbox;

    @FindBy(how = How.ID, using = "12532-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    /**
     * Fills the section 3 of I9 Rehire form
     * @param candidate
     */
    public static void fillSection3Form(Candidate candidate) {
        SeleniumTest.clearAndSetText(firstNameTextBox, candidate.getFirstName());
        SeleniumTest.clearAndSetText(middleNameTextBox, candidate.getMiddleName());
        SeleniumTest.clearAndSetText(lastNameTextBox, candidate.getLastName());
        SeleniumTest.check(iAcknowledgeCheckableCheckbox, iAcknowledgeClickableLabel);
    }

    /**
     * Click Next Button.
     * @return
     */
    public static CandidatePortalPages clickNextButton(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
