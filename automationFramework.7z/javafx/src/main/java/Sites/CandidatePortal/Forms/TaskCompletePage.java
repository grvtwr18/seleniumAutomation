package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.DashboardPage;
import Sites.CandidatePortal.PortalSignInPage;
import Sites.CandidatePortal.IDVerificationPage;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by jgupta on 8/31/2015.
 */
public class TaskCompletePage extends FormPage {

    @FindBy(how = How.CSS, using = "button")
    private WebElement returnToDashboardButton;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    @FindBy(how = How.ID, using = "btnOverDueContinue")
    private static WebElement continueBtn;

    @FindBy(how = How.ID, using = "qOverdueReason")
    private static WebElement overdueReasonDropdown;

    @FindBy(how = How.XPATH, using = "/html/body/div[1]/div[1]/div[7]/div[2]/button[2]")
    private static WebElement startNextTask;

    protected final static Logger staticLogger = LoggerFactory.getLogger("TaskCompletePage");

    /**
     * Constructs a new Task Completion Page object.
     */
    public TaskCompletePage() {
        WaitUntil.waitUntil(() -> {
            return Driver.getDriver().findElements(By.xpath("//span[contains(text(),'Complet')]")).size() > 0;
        });
    }

    static {
        PageFactory.initElements(Driver.getDriver(), TaskCompletePage.class);
    }

    /**
     * Attempts to make sure the TaskComplete page is loaded before returning
     * If no text is supplied it will wait for the url to contain tasks.php and
     * it will look for the Sterling Talent Solutions image in the footer
     * If you supply textToLookFor it will find this text in the page source before returning
     *
     * @param textToLookFor The text you want to search for on the page.
     */
    public static void waitForPageToLoad(String... textToLookFor) {
        waitForPageLoad("task.php", textToLookFor);
    }

    public static void waitForPageToLoad(int timeOut, int polling, String... textToLookFor) {
        waitForPageLoad(timeOut, polling, "task.php", textToLookFor);
    }

    /**
     * Clicks on "Return to Dashboard" button
     */
    public DashboardPage clickReturnToDashboardButton() {
        returnToDashboardButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Clicks on Sign Out Link.
     *
     * @return
     */
    public static PortalSignInPage clickSignOut() {
        signOutLink.click();
        Driver.getDriver().manage().deleteAllCookies();
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Click on Continue button
     */
    public static void clickContinueBtn() {
        continueBtn.click();
    }

    /**
     * Select Overdue Reason from Overdue Reason drop down
     *
     * @param overDueReason
     */
    public static void selectOverdueReason(String overDueReason) {
        Select overdueReasonDD = new Select(overdueReasonDropdown);
        overdueReasonDD.selectByVisibleText(overDueReason);
    }

    public static class ContinueCase {

        @FindBy(how = How.ID, using = "duplicateCase1")
        private static WebElement continueCaseRadioButton;

        @FindBy(how = How.ID, using = "duplicatecase0")
        private static WebElement closeCaseRadioButton;

        @FindBy(how = How.ID, using = "duplicateCaseReasonYes0")
        private static WebElement employeeIsRehireRadioButton;

        @FindBy(how = How.ID, using = "duplicateCaseReasonNo0")
        private static WebElement sameCaseRadioButton;

        @FindBy(how = How.ID, using = "duplicateCaseReasonNo1")
        private static WebElement employeeDataIncorrectRadioButton;

        @FindBy(how = How.ID, using = "duplicateCaseReasonYes2")
        private static WebElement otherRadioButton;

        @FindBy(how = How.ID, using = "divDuplicateCaseSubmitBtn")
        private static WebElement duplicateCaseContinueButton;

        @FindBy(how = How.ID, using = "duplicatecasereasonother")
        private static WebElement txtReason;

        @FindBy(how = How.XPATH, using = "//input[@id='btnDhsReverify']")
        private static WebElement btnDhsReverify;

        @FindBy(how = How.XPATH, using = "//input[@id='qLawfulPermanentResidentAlienID']")
        private static WebElement txtAlienNumber;

        static {
            PageFactory.initElements(Driver.getDriver(), ContinueCase.class);
        }

        public static void clickContinueCase() {
            SeleniumTest.waitForElementToBeClickable(continueCaseRadioButton, 70).click();
        }

        public static void clickCloseCase() {
            closeCaseRadioButton.click();
        }

        public static void clickEmployeeIsRehire() {
            employeeIsRehireRadioButton.click();
        }

        public static void clickEmployeeDataIncorrect() {
            employeeDataIncorrectRadioButton.click();
        }

        public static void clickOther() {
            otherRadioButton.click();
        }

        public static void clickContinue() {
            duplicateCaseContinueButton.click();
        }

        /**
         * Returns the number of masked SSN's found on the page
         * Specifically there should be one or more that are masked
         *
         * @return
         */
        public static boolean areSSNsMasked() {
            List<WebElement> maskedSSNs = Driver.getDriver().findElements(By.className("ssnCol"));
            for (WebElement element : maskedSSNs) {
                if (!element.getText().contains("*") && !element.getText().contains("SSN")) {
                    return false;
                }
            }
            return true;
        }

        public static void continueCase(String reason) {
            clickContinueCase();
            clickOther();
            SeleniumTest.clearAndSetText(txtReason, reason);
            clickContinue();
            SeleniumTest.waitMs(5000);
        }

        public static void closeCase() {
            clickCloseCase();
            employeeDataIncorrectRadioButton.click();
            clickContinue();
            SeleniumTest.waitMs(5000);
        }

        public static void closeSameCase() {
            clickCloseCase();
            sameCaseRadioButton.click();
            clickContinue();
            SeleniumTest.waitMs(5000);
        }

        public static void continueReverify(String alienNumber,boolean isAlienNumberUpdate){
            if(isAlienNumberUpdate){
            SeleniumTest.clearAndSetText(txtAlienNumber,alienNumber);}
            btnDhsReverify.click();
        }
    }

    public static class PhotoVerification {

        @FindBy(how = How.ID, using = "photoismatch1")
        private static WebElement yesRadioButton;

        @FindBy(how = How.ID, using = "photoismatch0")
        private static WebElement noRadioButton;

        @FindBy(how = How.ID, using = "btnPhotoVerify")
        private static WebElement continueButton;

        @FindBy(how = How.XPATH, using = "//div[@class='dbAlertColor']")
        private static WebElement lblEverifyStatus;

        static {
            PageFactory.initElements(Driver.getDriver(), PhotoVerification.class);
        }

        public static void waitForPageToLoad() {
            WaitUntil.waitUntil(30, 2, () -> yesRadioButton.isDisplayed(),
                    NoSuchElementException.class);
        }

        public static void clickYes() {
            waitForPageToLoad();
            yesRadioButton.click();
        }

        public static void clickNo() {
            waitForPageToLoad();
            noRadioButton.click();
        }

        /**
         * Clicks Continue and waits for particular DHS text to be returned
         *
         * @param DHSText
         */
        public static boolean clickContinue(String DHSText) {
            waitForPageToLoad();
            continueButton.click();
            try {
                WaitUntil.waitUntil(100, 3, () -> Driver.getDriver().findElement(By.xpath
                        ("//strong[text()" + "='" + DHSText + "']"))
                        .isDisplayed(), NoSuchElementException.class);
            } catch (TimeoutException toe) {
                return false;
            }
            return true;
        }

        public static void clickContinue() {
            waitForPageToLoad();
            continueButton.click();
            waitForPageToLoad();
        }

        public static IDVerificationPage clickStartNextTask() {
            Driver.getDriver().findElements(By.className("button")).get(3).click();
            return new IDVerificationPage();
        }

        public static DashboardPage clickReturnToDashboard() {
            Driver.getDriver().findElements(By.className("button")).get(2).click();
            return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
        }

        public static String getLblEverifyStatus() {
            return lblEverifyStatus.getText();
        }
    }
}
