package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by tjoshi on 11/30/2015.
 */
public class FormID4154IntendedPDFContentPage extends FormPage {
    @FindBy(how = How.ID, using = "acceptButton")
    public WebElement acceptButton;

    @FindBy(how = How.ID, using = "previewButton")
    public WebElement previewButton;

    @FindBy(how = How.ID, using = "confirmButton")
    public WebElement confirmButton;

    /**
     * Click the "I Agree to Use an Electronic Disclosure" button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickButton(Class<? extends CandidatePortalPages> returnedClass, WebElement button)
    {
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 2);
        button.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
