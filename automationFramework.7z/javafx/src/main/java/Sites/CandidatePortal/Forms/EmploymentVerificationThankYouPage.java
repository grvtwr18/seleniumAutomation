package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Page used for the page you get when you complete an EmploymentVerification additional documents task
 */
public class EmploymentVerificationThankYouPage extends CandidatePortalPages {
    //The css selectors used for this page are order-fixed. If the order of elements changes in the page this POM
    // will break (i.e. will be out of sync of the real page)

    /**
     * Button to go back to candidate portal dashboard
     */
    @FindBy(css = "#portalContent > p:nth-child(7) > button:nth-child(1)")
    private static WebElement returnToDashboardButton;

    /**
     * Button to start next available-additional-documents task
     */
    @FindBy(css = "#portalContent > p:nth-child(7) > button:nth-child(2)")
    private static WebElement startNextTaskButton;

    /**
     * Button to sign out of candidate portal
     */
    @FindBy(css = "#portalContent > p:nth-child(7) > button:nth-child(3)")
    private static WebElement signOutButton;

    /**
     * Thank you message
     */
    @FindBy(css = "#portalContent > h1")
    private static WebElement thankYouMessage;

    static {
        PageFactory.initElements(Driver.getDriver(), EmploymentVerificationThankYouPage.class);
    }

    /**
     * If there are more tasks available this button will be displayed
     */
    public static void clickStartNextTaskButton() {
        SeleniumTest.click(startNextTaskButton);
    }

    /**
     * If we click this button we will return to candidate portal dashboard
     */
    public static void clickReturnToDashboard() {
        SeleniumTest.click(returnToDashboardButton);
    }

    /**
     *
     * @return String containing a Thank you message
     */
    public static String getThankYouMessage() {
        return SeleniumTest.getText(thankYouMessage);
    }
}
