package Sites.CandidatePortal.Forms;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.apache.commons.exec.OS;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;


/**
 * Created by tjoshi on 11/24/2015.
 */
public class FormID1037DirectDepositPage extends FormPage {
    //@FindBy(how = How.ID, using = "1037-283_1_Yes")
    @FindBy(how = How.XPATH, using = "//label[@for='1037-283_1_Yes']")
    private WebElement electDirectDepositRadioButtonValueYes;

    @FindBy(how = How.CSS, using = "label.checkboxLabel.formFieldLabelRequired")
    private WebElement acknowledgementCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1037-283_6_Checking']")
    private WebElement accountTypeRadioButtonValueChecking;

    @FindBy(how = How.XPATH, using = "//label[@for='1037-283_7_Net Check']")
    private WebElement depositAmountRadioButtonValueNetCheck;

    @FindBy(how = How.ID, using = "1037-283_9")
    private WebElement bankNameTextbox;

    @FindBy(how = How.ID, using = "1037-283_10")
    private WebElement routingNumberTextbox;

    @FindBy(how = How.ID, using = "1037-283_11")
    private WebElement accountNumberTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1037-283_14_Yes']")
    private WebElement accountNameSameRadioButtonValueYes;

    @FindBy(how = How.XPATH, using = "//label[@for='1037-283_19_No']")
    private WebElement anotherAccountDepositValueNo;

    @FindBy(how = How.ID, using = "1037-283_16-filebrowse")
    private WebElement browseFile;

    //css=button.btnPostFileToServer.button
    @FindBy(how = How.CSS, using = "button.btnPostFileToServer.button")
    private WebElement uploadFileButton;

    @FindBy(how = How.ID, using = "1037-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "1037-283_16-filebrowse")
    private WebElement filePathBox;

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    /**
     * Selects the radio button "Yes" for elect Direct Deposit
     */
    public void electDirectDeposit()
    {
        SeleniumTest.waitForElementVisible(electDirectDepositRadioButtonValueYes, SeleniumTest.FLUENTWAIT_TIMEOUT, SeleniumTest.POLLING_TIMEOUT);
        electDirectDepositRadioButtonValueYes.click();
    }

    /**
     * Checks the "I acknowledge" checkbox
     */
    public void setAcknowledgementCheckbox()
    {
        acknowledgementCheckbox.click();
    }

    /**
     * Do not deposit another account check
     */
    public void setAnotherAccountDepositValueNo()
    {
        anotherAccountDepositValueNo.click();
    }

    /**
     * Selects the radio button "Yes" for elect Direct Deposit
     */
    public void setAccountTypeRadioButtonValueChecking()
    {
        accountTypeRadioButtonValueChecking.click();
    }

    /**
     * Set the deposit about to match the net check amount
     */
    public void setDepositAmountRadioButtonValueNetCheck()
    {
        depositAmountRadioButtonValueNetCheck.click();
    }

    /**
     * Sets the bank name passed to the method
     * @param bankName
     */
    public void setBankNameTextbox(String bankName)
    {
        SeleniumTest.clearAndSetText(bankNameTextbox, bankName);
    }

    /**
     * Sets account number passed to the method
     * @param accountNumber
     */
    public void setAccountNumber(String accountNumber)
    {
        SeleniumTest.clearAndSetText(accountNumberTextbox, accountNumber);
    }

    /**
     * Sets routing number passed to the method
     * @param routingNumber
     */
    public void setRoutingNumber(String routingNumber)
    {
        SeleniumTest.clearAndSetText(routingNumberTextbox, routingNumber);
    }

    /**
     * Selects the radio button "Yes" for elect Direct Deposit
     */
    public void setAccountNameSameRadioButtonValueYes()
    {
        accountNameSameRadioButtonValueYes.click();
    }

    /**
     * Set Choose File path
     * @return
     */
    public void uploadFile()
    {
        File fileToUpload = new File(getClass().getResource("/HPM/VoidedCheck.jpg").getFile());

        setFileToUpload(fileToUpload.getAbsolutePath());
        uploadFileButton.click();
    }

    /**
     * Fill the direct deposit form
     */
    public CandidatePortalPages fillDirectDepositForm(Class<? extends CandidatePortalPages> returnedClass)
    {
        electDirectDeposit();
        setAcknowledgementCheckbox();
        setAccountTypeRadioButtonValueChecking();
        setDepositAmountRadioButtonValueNetCheck();
        setBankNameTextbox("Bank Name");
        setAccountNumber("123456789");
        setRoutingNumber("125000024");
        setAccountNameSameRadioButtonValueYes();
        uploadFile();
        setAnotherAccountDepositValueNo();
        return clickNext(returnedClass);
    }

    /**
     * Click on Next button
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Sets the file to upload
     * @param filePath
     * @return
     */
    public void setFileToUpload(String filePath) {
        if(OS.isFamilyWindows())
            filePath = filePath.replace('/', '\\');
        ((JavascriptExecutor)Driver.getDriver()).executeScript("document.getElementById('" + filePathBox.getAttribute("id") + "').style.visibility = 'visible';");
        logger.debug("Setting FilePath of Browse input field to {}", filePath);
        filePathBox.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(uploadFileButton, 10);
    }
}
