package Sites.CandidatePortal.Forms;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Form105W4eSignPreviewPage extends FormeSignPreviewPage {

    @FindBy(how = How.ID, using = "4362-105_5")
    private static WebElement exemptTextbox;

    public static String getExemptTextboxText() {
        return exemptTextbox.getAttribute("value");
    }
}
