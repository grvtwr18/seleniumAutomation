package Sites.CandidatePortal.Forms.vro;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by jgupta on 11/3/2017.
 */
public class ViewVroReportPageNonResponsive {
    @FindBy(how = How.ID, using = "CandidateReportMenu")
    private static WebElement actionDropDown;

    @FindBy(how = How.CLASS_NAME, using = "dispute-checkbox")
    private static List<WebElement> allDisputeCheckboxes;

    @FindBy(how = How.CSS, using = "div[class='circle-text dispute-count']")
    private static WebElement initiateDisputeCount;

    @FindBy(how = How.CSS, using = "button[class='btn button dispute-report hidden-lg']")
    private static WebElement initiateDisputeForSelectedResultButton;

    static {
        PageFactory.initElements(Driver.getDriver(), ViewVroReportPageNonResponsive.class);
    }


    public static void selectActionDropDownOption(String option) {
        SeleniumTest.selectByValueFromDropDown(actionDropDown, option);
    }

    public static void selectAllCheckboxesForDispute() {
            for (WebElement disputeCheckbox: allDisputeCheckboxes){
                SeleniumTest.click(disputeCheckbox);
            }
    }

    public static int getInitiateDisputeCount() {
        return Integer.parseInt(SeleniumTest.getText(initiateDisputeCount));
    }

    public static void clickInitiateDisputeForSelectedResultButton() {
        SeleniumTest.click(initiateDisputeForSelectedResultButton);
    }
}
