package Sites.CandidatePortal.Forms.individualizedReview;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.FormID10eSignFormsPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 10/19/2017.
 */
public class SideLinksHelper extends CandidatePortalPages {
    @FindBy(how = How.ID, using = "taskNav_19199")
    private static WebElement additionalInformationLink;

    @FindBy(how = How.ID, using = "taskNav_19198")
    private static WebElement rehabilitationEffortsLink;

    @FindBy(how = How.ID, using = "taskNav_10")
    private static WebElement eSignLink;

    static {
        PageFactory.initElements(Driver.getDriver(), SideLinksHelper.class);
    }

    public static FormID19199AdditionalInfoPage clickAdditionalInformationLink() {
        SeleniumTest.click(additionalInformationLink);
        return PageFactory.initElements(Driver.getDriver(), FormID19199AdditionalInfoPage.class);
    }

    public static FormID19198RehabilitationEffortsPage clickRehabilitationEffortsLink() {
        SeleniumTest.click(rehabilitationEffortsLink);
        return PageFactory.initElements(Driver.getDriver(), FormID19198RehabilitationEffortsPage.class);
    }

    public static FormID10eSignFormsPage clickeSignLink() {
        SeleniumTest.click(eSignLink);
        return PageFactory.initElements(Driver.getDriver(), FormID10eSignFormsPage.class);
    }
}

