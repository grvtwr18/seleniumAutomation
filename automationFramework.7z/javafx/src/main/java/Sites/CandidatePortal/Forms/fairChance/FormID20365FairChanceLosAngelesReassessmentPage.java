package Sites.CandidatePortal.Forms.fairChance;

import Sites.CandidatePortal.Forms.individualizedReview.IrWorkflowPages;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import WebDriver.DriverType;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import java.time.LocalDate;

/**
 * @author sbashar
 */
public class FormID20365FairChanceLosAngelesReassessmentPage extends IrWorkflowPages {

    @FindBy(how = How.ID, using = "20365-20365_7-20365_7")
    private static WebElement assessmentDateBox;

    public static void typeEvidenceOfRehabilitation1(String evidenceOfRehabilitation1) {
        SeleniumTest.clearAndSetText(By.id
                ("20365-20365_14"), evidenceOfRehabilitation1);
    }

    public static void typeDateOfReAssessment(LocalDate date) {

        String hiddenReAssessmentDateBox = "20365-20365_7-20365_7";

        if (Driver.getBrowserType() == DriverType.FIREFOX) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_uu_Dash_MM_Dash_dd(date, assessmentDateBox.getAttribute("id"), hiddenReAssessmentDateBox);
        } else {
            String strDate = date.format(LocaleHelper.getDateFormatShortDateSlash_uuuu());
            assessmentDateBox.sendKeys(strDate);
        }
    }
}
