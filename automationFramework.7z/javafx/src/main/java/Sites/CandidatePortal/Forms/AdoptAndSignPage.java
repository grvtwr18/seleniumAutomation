package Sites.CandidatePortal.Forms;

/**
 * Created by jgupta on 1/19/2016.
 */

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;

public class AdoptAndSignPage extends FormPage {
    private static By adoptButtonSelector = By.cssSelector("div.footer > button.btn-main");

    /**
     * Click on Adopt and Sign button
     */
    public static void clickAdoptAndSignButton(){
        SeleniumTest.switchToFrameById("iFrameDocuSign");
        SeleniumTest.waitForElementVisible(adoptButtonSelector);
        Driver.getDriver().findElements(adoptButtonSelector).get(0).click();
    }

    /**
     * Click on Adopt and Initial button
     */
    public static void clickAdoptAndInitialButton(){
        SeleniumTest.switchToFrameById("iFrameDocuSign");
        SeleniumTest.waitForElementVisible(adoptButtonSelector);
        Driver.getDriver().findElements(adoptButtonSelector).get(1).click();
    }
}
