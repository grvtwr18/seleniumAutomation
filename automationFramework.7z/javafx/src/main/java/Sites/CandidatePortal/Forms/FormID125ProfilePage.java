package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import java.util.concurrent.TimeUnit;

/**
 * Created by abrackett on 11/5/2015.
 */
public class FormID125ProfilePage extends FormPage {

    @FindBy(how = How.ID, using = "125-100_1")
    private static WebElement firstNameBox;

    @FindBy(how = How.ID, using = "125-qmi-100_2-100_2")
    private static WebElement middleNameBox;

    @FindBy(how = How.ID, using = "125-100_3")
    private static WebElement lastNameBox;

    @FindBy(how = How.XPATH, using = "//label[@for='125-125_13_Yes']")
    private static WebElement yesRadioButton;

    private static By noRadioButtonLocator = By.xpath("//label[@for='125-125_13_No']");
    @FindBy(how = How.XPATH, using = "//label[@for='125-125_13_No']")
    private static WebElement noRadioButton;

    @FindBy(how = How.ID, using = "125-100_7")
    private static WebElement streetAddressBox;

    @FindBy(how = How.ID, using = "125-100_8")
    private static WebElement unitNumberBox;

    @FindBy(how = How.ID, using = "125-address100_9-100_10")
    private static WebElement cityBox;

    @FindBy(how = How.ID, using = "125-address100_9-100_9")
    private static WebElement countryRegionSelect;

    @FindBy(how = How.ID, using = "125-address100_9-100_11")
    private static WebElement stateOrProvinceSelect;

    @FindBy(how = How.ID, using = "125-address100_9-100_12")
    private static WebElement zipBox;

    @FindBy(how = How.ID, using = "125-100_13")
    private static WebElement primaryPhoneBox;

    @FindBy(how = How.ID, using = "125-100_14")
    private static WebElement otherPhoneBox;

    @FindBy(how = How.ID, using = "125-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    @FindBy(how = How.ID, using = "125-previousnextbuttons-savebutton")
    private static WebElement saveButton;

    static {
        PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Fills in first name
     * @param firstName
     * @return
     */
    public static FormID125ProfilePage setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameBox, firstName);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Fills in middle name
     * @param middleName
     * @return
     */
    public static FormID125ProfilePage setMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameBox, middleName);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Fills in last name
     * @param lastName
     * @return
     */
    public static FormID125ProfilePage setLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameBox, lastName);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    public static String getFirstName(){
        return firstNameBox.getAttribute("Value");
    }

    public static String getLastName(){
        return lastNameBox.getAttribute("Value");
    }

    /**
     * Clicks Yes Radio button
     * @return
     */
    public static FormID125ProfilePage clickYesRadioButton() {
        yesRadioButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    public static boolean isTheNoRadioButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(noRadioButtonLocator);
    }

    /**
     * Clicks no Radio button
     * @return
     */
    public static FormID125ProfilePage clickNoRadioButton() {
        SeleniumTest.waitForElementEnabled(noRadioButton);
        noRadioButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the street address
     * @param streetAddressLineOne
     * @return
     */
    public static FormID125ProfilePage setStreetAddress(String streetAddressLineOne) {
        SeleniumTest.clearAndSetText(streetAddressBox, streetAddressLineOne);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the unit number
     * @param unitNumber
     * @return
     */
    public static FormID125ProfilePage setUnitNumber(int unitNumber) {
        SeleniumTest.clearAndSetText(unitNumberBox, Integer.toString(unitNumber));
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the unit number
     * @param unitNumber
     * @return
     */
    public static FormID125ProfilePage setUnitNumber(String unitNumber) {
        SeleniumTest.clearAndSetText(unitNumberBox, unitNumber);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the city
     * @param city
     * @return
     */
    public static FormID125ProfilePage setCity(String city) {
        SeleniumTest.clearAndSetText(cityBox, city);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the Country or Region
     * @param countryOrRegion
     * @return
     */
    public static FormID125ProfilePage selectCountryRegion(String countryOrRegion) {
        final Select selection = new Select(countryRegionSelect);
      //TODO:  fix fluent wait
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(selection.getOptions().size() > 5) {
                            return true;
                        }
                        return false;
                    }
                });
        selection.selectByVisibleText(countryOrRegion);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the State or Province
     * @param stateOrProvince
     * @return
     */
    public static FormID125ProfilePage selectStateOrProvince(String stateOrProvince) {
        final Select selection = new Select(stateOrProvinceSelect);
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(selection.getOptions().size() > 5) {
                            return true;
                        }
                        return false;
                    }
                });
        selection.selectByVisibleText(stateOrProvince);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the Zip Code
     * @param zip
     * @return
     */
    public static FormID125ProfilePage setZip(String zip) {
        SeleniumTest.clearAndSetText(zipBox, zip);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the primary phone number
     * @param phoneNumber
     * @return
     */
    public static FormID125ProfilePage setPrimaryPhone(String phoneNumber) {
        SeleniumTest.clearAndSetText(primaryPhoneBox, phoneNumber);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Sets the "other" phone number
     * @param phoneNumber
     * @return
     */
    public static FormID125ProfilePage setOtherPhone(String phoneNumber) {
        SeleniumTest.clearAndSetText(otherPhoneBox, phoneNumber);
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }

    /**
     * Clicks the next button
     * @param returnedClass the class to return - either the next page or the same page
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Fills in Candidate Details on the Profile Page
     * @param candidate Incoming Candidate Object
     * @return
     */
    public static FormID125ProfilePage fillCandidateDetails(Candidate candidate) {
        setFirstName(candidate.getFirstName());
        setMiddleName(candidate.getMiddleName());
        setLastName(candidate.getLastName());
        // Having trouble getting past this particular line - adding a wait because that appears to help.
        // Adding a wait because nothing else seems to work.
        SeleniumTest.waitMs((1000 * SeleniumTest.waitForElementTimeout) / 5);
        clickNoRadioButton();
        setStreetAddress(candidate.getAddressLine1());
        setUnitNumber(candidate.getApartmentNumber() != null ? candidate.getApartmentNumber() : "");
        setCity(candidate.getCity());
        selectCountryRegion(candidate.getCountryOrRegion());
        selectStateOrProvince(candidate.getState());
        setZip(candidate.getZip());
        setPrimaryPhone(candidate.getCandidatePhone());
        return PageFactory.initElements(Driver.getDriver(), FormID125ProfilePage.class);
    }
}
