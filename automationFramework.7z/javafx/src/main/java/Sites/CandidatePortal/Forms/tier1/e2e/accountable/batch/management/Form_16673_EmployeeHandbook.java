package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_16673_EmployeeHandbook extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='16673-16673_1_English']")
    private WebElement englishRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16673-16673_1_Spanish']")
    private WebElement spanishRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16673-16673_3_A']")
    private WebElement reduceWasteRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16673-16673_3_B']")
    private WebElement paperCopyRadiobutton;

    @FindBy(how = How.ID, using = "16673-16673_5")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16673-16673_5']")
    private WebElement iAcknowledgeLabel;

    protected Logger logger = LoggerFactory.getLogger(Form_16673_EmployeeHandbook.class);

    public static Form_16673_EmployeeHandbook getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16673_EmployeeHandbook.class);

    }
    public Form_16673_EmployeeHandbook chooseEnglishRadioButton() {
        englishRadiobutton.click();
        logger.info("English Radio Button Chosen");
        return this;
    }

    public Form_16673_EmployeeHandbook chooseSpanishRadioButton() {
        spanishRadiobutton.click();
        logger.info("Spanish Radio Button Chosen");
        return this;
    }

    public Form_16673_EmployeeHandbook chooseReduceWasteRadioButton() {
        reduceWasteRadiobutton.click();
        logger.info("Reduce Waste Radio Button Chosen");
        return this;
    }

    public Form_16673_EmployeeHandbook chooseIWantAPaperCopy() {
        paperCopyRadiobutton.click();
        logger.info("Paper Copy Requested Radio Button");
        return this;
    }

    public Form_16673_EmployeeHandbook checkIAcknowledge() {
        SeleniumTest.check(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_16673_EmployeeHandbook uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAcknowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Unchecked");
        return this;
    }
}
