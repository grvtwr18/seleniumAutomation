package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Form_WTEX extends CandidatePortalPages {
    private static final Logger staticLogger = LoggerFactory.getLogger(Form_WTEX.class);

    @FindBy(how = How.XPATH, using = "//label[@for='1875-1875_5_Yes']")
    private WebElement completeFormWTEXYesRadioButton;

    @FindBy(how = How.ID, using = "1875-1875_9")
    private WebElement CityTextbox;

    @FindBy(how = How.ID, using = "1875-1875_10")
    private WebElement TaxYearTextbox;

    @FindBy(how = How.ID, using = "1875-1875_11-1875_11")
    private WebElement ResidencyBeginDateTextBox;

    @FindBy(how = How.ID, using = "1875-1875_12-1875_12")
    private WebElement ResidencyEndDateTextBox;

    @FindBy(how = How.ID, using = "1875-1875_13")
    private WebElement TotalEarningsTextbox;

    @FindBy(how = How.ID, using = "1875-1875_14")
    private WebElement TotalTaxPaidTextBox;

    @FindBy(how = How.ID, using = "1875-1875_21")
    private WebElement WithholdingsStatusDropDown;

    @FindBy(how = How.XPATH, using = "//label[@for='1875-1875_17']")
    private WebElement IconfirmCheckboxLabel;

    @FindBy(how = How.ID, using = "1875-1875_17")
    private WebElement IconfirmCheckbox;

    @FindBy(how = How.XPATH, using = "//button[@value='Next']")
    private WebElement nextButton;

    @FindBy(how = How.XPATH, using = "//img[contains(@src,'error.png')]")
    private WebElement ErrorImage;

    @FindBy(how = How.XPATH, using = "//*[@id='ui-datepicker-div']")
    private WebElement DatePickerPopUp;

    @FindBy(how = How.XPATH, using = "//*[@id='ui-datepicker-div']//*[@class='ui-datepicker-month']")
    private WebElement DatePickerMonthDropDown;

    @FindBy(how = How.XPATH, using = "//*[@id='ui-datepicker-div']//*[@class='ui-datepicker-year']")
    private WebElement DatePickerYearDropDown;

    @FindBy(how = How.XPATH, using = "//*[@class='ui-datepicker-calendar']//a[@class='ui-state-default']")
    private List<WebElement> DatePickerDaysLink;

    public void CompleteFormWTEX() {
        SeleniumTest.click(completeFormWTEXYesRadioButton);
    }

    public void enterCity(Candidate candidate) {
        SeleniumTest.clearAndSetText(CityTextbox, candidate.getCity());
    }

    public void enterTaxYear() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        staticLogger.info(dateFormat.format(date)); //2016/11/16 12:08:43
        String[] strDate = dateFormat.format(date).split("/");
        int year = Integer.parseInt(strDate[0]);
        staticLogger.info("Tax Year " + year);

        SeleniumTest.clearAndSetText(TaxYearTextbox, String.valueOf(year));
    }

    public void enterResidencyStartDate(Candidate candidate) {
        SeleniumTest.click(ResidencyBeginDateTextBox);
        staticLogger.info("select Date");
        selectDate(candidate);

    }

    public void enterResidencyEndDate() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MMM/dd");
        Date date = new Date();
        System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
        String strDate = dateFormat.format(date);
        String[] strDates = strDate.split("/");
        int year = Integer.parseInt(strDates[0]);
        String month = strDates[1];
        int day = Integer.parseInt(strDates[2]);

        SeleniumTest.click(ResidencyEndDateTextBox);
        staticLogger.info("select Date");
        selectDate(year, month, day);

        //SeleniumTest.clearAndSetText(ResidencyEndDateTextBox,date.getMonth()+"/"+date.getDay()+"/"+date.getYear());
    }

    public void enterTotalEarnings(int amount) {
        SeleniumTest.clearAndSetText(TotalEarningsTextbox, String.valueOf(amount));
    }

    public void enterTaxpaid(int taxAmount) {
        SeleniumTest.clearAndSetText(TotalTaxPaidTextBox, String.valueOf(taxAmount));
    }

    public void selectWithholdingStatus(String status) {
        SeleniumTest.selectByVisibleTextFromDropDown(WithholdingsStatusDropDown, status);
    }

    public void clickIconfirm() {
        SeleniumTest.check(IconfirmCheckboxLabel, IconfirmCheckbox);
    }

    public void clickNext() {
        SeleniumTest.click(nextButton);
    }

    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public boolean isMandatoryFieldsErrorImageVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//img[contains(@src,'error.png')]"));
    }

    public void selectDate(int year, String month, int day) {
        String strYear = String.valueOf(year);
        String strMonth = month;
        String strDay = String.valueOf(day - 1);
        SeleniumTest.selectByVisibleTextFromDropDown(DatePickerYearDropDown, strYear);
        SeleniumTest.selectByVisibleTextFromDropDown(DatePickerMonthDropDown, strMonth);

        for (WebElement aDatePickerDaysLink : DatePickerDaysLink) {
            if (aDatePickerDaysLink.getText().equalsIgnoreCase(strDay)) {
                SeleniumTest.click(aDatePickerDaysLink);
                break;
            }
        }

    }

    public void selectDate(Candidate candidate) {
        String strYear = String.valueOf(Integer.parseInt(candidate.getDobYear()) + 1);
        String strMonth = candidate.getDobMonth();
        String strDay = candidate.getDobDay();
        SeleniumTest.selectByVisibleTextFromDropDown(DatePickerYearDropDown, strYear);
        SeleniumTest.selectByVisibleTextFromDropDown(DatePickerMonthDropDown, strMonth);

        for (WebElement aDatePickerDaysLink : DatePickerDaysLink) {
            if (aDatePickerDaysLink.getText().equalsIgnoreCase(strDay)) {
                SeleniumTest.click(aDatePickerDaysLink);
                WaitUntil.waitUntil(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//*[@id='ui-datepicker-div']")));
                break;
            }
        }

    }
}
