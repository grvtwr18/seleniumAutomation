package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by derekwhittom on 7/12/16.
 */
public class FormPage extends CandidatePortalPages {
    // region Locators
    @FindBy(how = How.ID, using = "fillWithTestDataLink")
    private static WebElement fillWithTestDataLink;
    @FindBy(how = How.ID, using = "govtId-value-text")
    private static WebElement ssnBox;
    @FindBy(how = How.ID, using = "btnSubmit")
    private static WebElement submitContinueButton;
    @FindBy(how = How.ID, using = "returnbtn")
    private static WebElement returnButton;

    @FindBy(how = How.CSS, using = "form#UberSearch input#qfalias0")
    private static WebElement alternateFirstNameTextbox;

    @FindBy(how = How.CSS, using = "form#UberSearch input#qnalias0")
    private static WebElement alternateLastNameTextbox;
    //endregion

    static {
        PageFactory.initElements(Driver.getDriver(), FormPage.class);
    }

    public static String getCandidateId() {
        WebElement candidateId = WebDriver.Driver.getDriver().findElement(By.id("xCandidateId"));
        return candidateId.getAttribute("value");
    }

    public static void clickFillWithTestDataLink() {
        // Make sure the 'Fill with Test Data' link is actually available; if not, set the flag in the request vars to
        // force it to set in the session.
        if (!SeleniumTest.isElementVisibleNoWaiting(By.xpath("//a[contains(@onclick,'fillWithTestData')]"))) {
            String url = SeleniumTest.getCurrentUrl();
            if (!url.contains("&prefill=1")) {
                url += "&prefill=1";
                SeleniumTest.navigateToUrl(url);
                SeleniumTest.waitForPageLoad();
            }
        }
        SeleniumTest.click(fillWithTestDataLink);
    }

    public static String getSsn() {
        return SeleniumTest.getText(ssnBox);
    }

    public static void setSsn(String ssn) {
        SeleniumTest.clearAndSetText(ssnBox, ssn);
    }

    public static void clickSubmitContinueButton() {
        SeleniumTest.click(submitContinueButton);
    }

    public static ReturnWidgetPage clickReturnButton() {
        SeleniumTest.click(returnButton);
        return PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }

    public static void typeAlternateFirstName(String aliasFirstName) {
        SeleniumTest.clearAndSetText(alternateFirstNameTextbox, aliasFirstName);
    }

    public static void typeAlternateLastName(String aliasLastName) {
        SeleniumTest.clearAndSetText(alternateLastNameTextbox, aliasLastName);
    }
}
