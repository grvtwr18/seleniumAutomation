package Sites.CandidatePortal.Forms;

import Data.locations.countrycode.CountryCode;
import Data.locations.us.UsStateTerritory;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.candidate.CandidateEducation;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.springframework.expression.spel.ast.Literal;

import java.util.ArrayList;
import java.util.List;

/**
 This page is used to fill the candidate education details on candidate portal. this page comes in Education verification flow
 * Created by Vivek.Rai on 4/13/2018.
 */
public class EducationVerificationForm extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//*[contains(@id,'qshow_Group40-')]")
    private WebElement checkBoxEducationVerification;

    @FindBy(how = How.XPATH, using = "//select[contains(@id,'qcert_Group')]")
    private WebElement dropdownCertificationOrDegree;

    @FindBy(how = How.XPATH, using = "//input[contains(@id,'qdgre_Group')]")
    private WebElement major;

    @FindBy(how = How.XPATH, using = "//input[contains(@id,'qschn_Group')]")
    private WebElement school;

    @FindBy(how = How.XPATH, using = "//*[@id='ui-id-1']//li/a")
    private List<WebElement> schoolNameSuggestionList;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qo_Group')]")
    private WebElement schoolCountry;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qschc_Group')]")
    private WebElement schoolCity;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qschs_Group')]")
    private WebElement schoolState;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qdidgraduate_Group')]")
    private WebElement didYouGraduate;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qgraddtmm_Group')]")
    private WebElement graduationMonth;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qgraddtyy_Group')]")
    private WebElement graduationYear;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'sameascurrent_Group')]")
    private WebElement sameAsCurrent;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qfedalias_Group')]")
    private WebElement firstName;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qnedalias_Group')]")
    private WebElement lastName;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qscha_Group')]")
    private WebElement schoolAddress;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qschph_Group')]")
    private WebElement schoolPhoneNumber;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qschfax_Group')]")
    private WebElement schoolFaxNumber;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qschee_Group')]")
    private WebElement schoolEmailAddress;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qschdept_Group')]")
    private WebElement department;

    @FindBy(how = How.XPATH, using = "//input[starts-with(@id,'qschstudentid_Group')]")
    private WebElement seatOrOtherIdNumber;

    @FindBy(how = How.XPATH, using = "//input[@id='btnSubmit']")
    private WebElement continueBtn;

    @FindBy(how = How.XPATH, using = "//button[@id='btnSaveTicket']")
    private WebElement saveProgress;

    @FindBy(how = How.XPATH, using = "//*[@class='searchMessageBox']/span[2]")
    private WebElement messageBox;

    @FindBy(how = How.XPATH, using = "//*[@id='breadCrumbs']/a")
    private WebElement breadCrumbsLink;

    @FindBy(how = How.XPATH, using = "//*[@id='uberform']/div[1]/div/div[1]/h2")
    private WebElement certificationAuthorizationText;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qatndstmm_Group')]")
    private WebElement attendenceStartMonth;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qatndstyy_Group')]")
    private WebElement attendenceStartYear;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qatndendmm_Group')]")
    private WebElement attendenceEndDateMonth;

    @FindBy(how = How.XPATH, using = "//select[starts-with(@id,'qatndendyy_Group')]")
    private WebElement attendenceEndDateYear;


    @FindBy(how = How.XPATH, using = "//div[@id='userinfo']//a[2]")
    private WebElement signOutBtn;


    public EducationVerificationForm(){
        PageFactory.initElements(Driver.getDriver(),this);
    }

    /*Enter text in school */
    public void enterSchoolName(String schoolName){
        SeleniumTest.clearAndSetText(school,schoolName);
    }

    /* Returns the User Certification and Candidate Authorization text */
    public String getCertificationAuthorizationText(){
       return SeleniumTest.getText(certificationAuthorizationText).trim();
    }

    /*Return the List of texts */
    public List<String> getSchoolNameSuggestionBoxTexts(){
        List<String> elementTexts=new ArrayList<>();
        int listSize=schoolNameSuggestionList.size();
        for (int i=0;i<listSize;i++){
            elementTexts.add(i, schoolNameSuggestionList.get(i).getText());
        }
        return elementTexts;
    }

    /* Check Same as Current to replicate the candidate first name and last name */
    public void clickSameAsCurrent(){
        SeleniumTest.click(sameAsCurrent);
    }

    /* Save and Progress button to save the data */
    public EducationVerificationForm clickSaveProgress(){
        SeleniumTest.click(saveProgress);
        return PageFactory.initElements(Driver.getDriver(),EducationVerificationForm.class);
    }

    public void clickContinue(){
        SeleniumTest.click(continueBtn);
    }

    /* Message displayed after pressing save and progress */
    public String getMessage(){
        return SeleniumTest.getText(messageBox);
    }

    /* Breadcrumb to navigate to dashboard page*/
    public Sites.CandidatePortal.DashboardPage clickMyDashboard(){
        SeleniumTest.click(breadCrumbsLink);
        return PageFactory.initElements(Driver.getDriver(),Sites.CandidatePortal.DashboardPage.class);

    }

    /*  Enter the candidate education information on Education Verification form */
    public void enterEducationVerificationDetails(CandidateEducation candidateEducation,String certificationDegree){

        staticLogger.info("Attempting to select the certification and degree as "+certificationDegree);
        SeleniumTest.selectByVisibleTextFromDropDown(dropdownCertificationOrDegree,certificationDegree);
        staticLogger.info("Attempting to enter Study/Major "+candidateEducation.getFieldOfStudyMajor());
        SeleniumTest.clearAndSetText(major,candidateEducation.getFieldOfStudyMajor());
        staticLogger.info("Attempting to enter school name as "+candidateEducation.getSchoolName());
        SeleniumTest.clearAndSetText(school,candidateEducation.getSchoolName());
        if(SeleniumTest.isElementVisible(schoolCountry)) {
            staticLogger.info("Attempting to select school country as " + CountryCode.US.getName());
            SeleniumTest.selectByVisibleTextFromDropDown(schoolCountry, CountryCode.US.getName());
        }
        staticLogger.info("Attempting to enter school city as "+candidateEducation.getSchoolCity());
        SeleniumTest.clearAndSetText(schoolCity,candidateEducation.getSchoolCity());
        staticLogger.info("Attempting to select school state/territory as "+ candidateEducation.getSchoolStateTerritory());
        SeleniumTest.selectByVisibleTextFromDropDown(schoolState,candidateEducation.getSchoolStateTerritory().getFullName());
        SeleniumTest.selectByVisibleTextFromDropDown(didYouGraduate,candidateEducation.getDidCandidateGraduate().getValue());
        if(candidateEducation.getDidCandidateGraduate().getValue().equalsIgnoreCase("YES")) {
            SeleniumTest.selectByVisibleTextFromDropDown(graduationMonth, candidateEducation.getGraduationDate().getMonth().toString().substring(0, 1) + candidateEducation.getGraduationDate().getMonth().toString().substring(1, 3).toLowerCase());
            SeleniumTest.selectByVisibleTextFromDropDown(graduationYear, Integer.toString(candidateEducation.getGraduationDate().getYear()));
        }
        else if(candidateEducation.getDidCandidateGraduate().getValue().equalsIgnoreCase("NO")){
            SeleniumTest.selectByVisibleTextFromDropDown(attendenceStartMonth, candidateEducation.getAttendanceStartDate().getMonth().toString().substring(0, 1) + candidateEducation.getAttendanceStartDate().getMonth().toString().substring(1, 3).toLowerCase());
            SeleniumTest.selectByVisibleTextFromDropDown(attendenceStartYear, Integer.toString(candidateEducation.getAttendanceStartDate().getYear()));

            SeleniumTest.selectByVisibleTextFromDropDown(attendenceEndDateMonth, candidateEducation.getAttendanceEndOrGraduationDate().getMonth().toString().substring(0, 1) + candidateEducation.getAttendanceEndOrGraduationDate().getMonth().toString().substring(1, 3).toLowerCase());
            SeleniumTest.selectByVisibleTextFromDropDown(attendenceEndDateYear, Integer.toString(candidateEducation.getAttendanceEndOrGraduationDate().getYear()));

        }
        staticLogger.info("Click on check box Same as Current");
        clickSameAsCurrent();

    }

    /*Click on Sign-out button */
    public void  clickSignOutBtn(){
        SeleniumTest.click(signOutBtn);
    }

    public String getSelectedCountryInDropdown(){
        JavaScriptHelper.scrollElementIntoView(schoolCountry);
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(schoolCountry);
    }

    public boolean isCountryDisabled() {
        return SeleniumTest.isElementDisabled(schoolCountry);
    }

}

