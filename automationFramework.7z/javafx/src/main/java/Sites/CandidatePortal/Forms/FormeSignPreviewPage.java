package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.DashboardPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import Workflows.Candidate;
import com.google.common.base.Predicate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;

import java.util.concurrent.TimeUnit;

/**
 * Created by jgupta on 8/31/2015.
 */
public class FormeSignPreviewPage extends FormPage {
    public static final int FLUENTWAIT_TIMEOUT = 15;
    public static final int POLLING_TIMEOUT = 3;

    @FindBy(how = How.ID, using = "confirmButton")
    private static WebElement confirmAndeSignButtonAtTopOfPage;

    private static By taskCompleteLocator = By.xpath("//div/span[contains(text(), 'Complet')]");

    @FindBy(how = How.XPATH, using = "//div[@class='panel']/div[contains(text(),'eSign Forms')]")
    private static WebElement eSignCompleteHeader;

    @FindBy(how = How.ID, using = "tasknoteMessage")
    private static WebElement taskNoteMessage;

    @FindBy(how = How.CLASS_NAME, using = "intro")
    private static WebElement proxySuccessMessage;

    @FindBy(how = How.XPATH, using = "//button[@id='confirmButton']/following-sibling::button")
    private static WebElement saveAndSignLaterButton;

    private Boolean foundIt = false;

    static {
        PageFactory.initElements(Driver.getDriver(), FormeSignPreviewPage.class);
    }

    /**
     * Clicks on Confirm and eSign Forms button
     */
    public static void clickConfirmAndeSignFormsButtonAtTopOfPage() {
        confirmAndeSignButtonAtTopOfPage.click();
    }

    /**
     * Clicks on Confirm and eSign Forms button
     */
    public static CandidatePortalPages clickConfirmAndeSignFormsButtonAtTopOfPage(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(confirmAndeSignButtonAtTopOfPage);
        confirmAndeSignButtonAtTopOfPage.click();
        SeleniumTest.waitMs(5000);
        // Found that completing the task can take more than 10 seconds doubling the wait time below to accommodate
        if (returnedClass.equals(TaskCompletePage.class)) {
            SeleniumTest.waitForElementToBeClickable(taskCompleteLocator, SeleniumTest.waitForElementTimeout * 2);
            TaskCompletePage.waitForPageToLoad();
        } else if (returnedClass.equals(DashboardPage.class)) {
            waitForVisible(taskNoteMessage);
            DashboardPage.waitForPageToLoad();

        } else if (returnedClass.equals(ProxyUserTaskCompletionPage.class)) {
            SeleniumTest.waitForElementVisible(By.cssSelector("div.intro"));
        } else {
            waitForVisible(eSignCompleteHeader);
            ESigningCompletePage.waitForPageToLoad();
        }
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Clicks on eSign Button on top of page and wait for Proxy User Task Completion message to show up.
     *
     * @return
     */
    public static void clickConfirmAndeSignFormsButtonAsProxyUser() {
        confirmAndeSignButtonAtTopOfPage.click();
        DashboardPage.waitForPageToLoad("Proxy User Task Completion");
    }

    /**
     * Wait for visible
     *
     * @param element
     */
    private static void waitForVisible(final WebElement element) {
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(FLUENTWAIT_TIMEOUT, TimeUnit.SECONDS)
                .pollingEvery(POLLING_TIMEOUT, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        return element.isDisplayed();
                    }
                });
    }

    public static String getAttachedDocuments() {
        return SeleniumTest.getTextByLocator(By.cssSelector("form#form_10 div.rightWidth > div"
                + ".panelSection > div.formField"));
    }

    /**
     * Clicks on Save and Sign Later button
     *
     * @return
     */
    public DashboardPage clickSaveAndSignLater() {
        saveAndSignLaterButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public boolean isCandidateDetailsPresentInPreviewPage(Candidate candidate) {
        final By candidateFirstNameLocator = By.xpath("//*[@value='" + candidate.getFirstName() + "']");
        final By candidateLastNameLocator = By.xpath("//*[@value='" + candidate.getLastName() + "']");

        if (SeleniumTest.getTextByLocator(candidateFirstNameLocator).equalsIgnoreCase(candidate.getFirstName())) {
            staticLogger.info("Candidate firstname path : {}", candidateFirstNameLocator);
            if (SeleniumTest.getTextByLocator(candidateLastNameLocator).equalsIgnoreCase(candidate.getLastName())) {
                staticLogger.info("Candidate lastname path : {}", candidateLastNameLocator);
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }


}
