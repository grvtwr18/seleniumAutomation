package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.I9.ListAEligibilityDocument;
import Sites.CandidatePortal.Forms.Objects.I9.ListBEligibilityDocument;
import Sites.CandidatePortal.Forms.Objects.I9.ListCEligibilityDocument;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;

/**
 * Created by abrackett on 10/18/16. Handles 3 step I-9 Compliance Worksheet
 */
public class Form_17062 {


    public static void setStartDate(LocalDate date) {
        Form_17062.Certification.setStartDate(date);
    }

    public static void fillListADocument(ListAEligibilityDocument document) {

        Form_17062.Section2.Documents.ListA.selectListADocument(document.getListADocument());

        if (document.isReceipt()) {
            Form_17062.Section2.Documents.ListA.checkListAReceipt(document.getListADocument());
            Form_17062.Section2.Documents.ListA.setIssuingAuthority(document.getListADocument(),
                                                                    document.getIssuingAuthority());
            Form_17062.Section2.Documents.ListA
                    .setDocumentNumber(document.getListADocument(), document.getDocumentNumber());
        } else {
            Form_17062.Section2.Documents.ListA.uncheckListAReceipt(document.getListADocument());
            Form_17062.Section2.Documents.ListA.setIssuingAuthority(document.getListADocument(),
                                                                    document.getIssuingAuthority());
            Form_17062.Section2.Documents.ListA
                    .setDocumentNumber(document.getListADocument(), document.getDocumentNumber());

            if (Form_17062.Section2.isRequired(Form_17062.Section2.Documents.ListA
                                                       .getAssociatedDocumentElement(
                                                               document.getListADocument()))) {
                Form_17062.Section2.Documents.ListA
                        .setOrSelectAssociatedDocument(document.getListADocument(),
                                                       Sites.CandidatePortal.Forms.Objects.I9
                                                               .Section2.Documents.ListA
                                                               .getAssociatedDocument(
                                                                       document.getListADocument
                                                                               ()));
            }
            if (Form_17062.Section2.isRequired(Form_17062.Section2.Documents.ListA
                                                       .getExpirationDateControlElement(
                                                               document.getListADocument()))) {
                Form_17062.Section2.Documents.ListA.setExpirationDate(document.getListADocument(),
                                                                      document.getExpirationDate());
            }
            if (Form_17062.Section2.Documents.ListA.secondDocumentIssuingAuthorityTextBox
                    .isDisplayed()) {
                Form_17062.Section2.Documents.ListA
                        .setSecondDocumentIssuingAuthority(document.getSecondIssuingAuthority());
                Form_17062.Section2.Documents.ListA
                        .setSecondDocumentNumber(document.getSecondDocumentNumber());
                Form_17062.Section2.Documents.ListA
                        .setSecondDocumentExpirationDate(document.getSecondDocumentExpiration());
            }
        }
    }

    public static void fillListBDocument(ListBEligibilityDocument document) {

        Form_17062.Section2.Documents.ListB.selectlistBDocument(document.getListBDocument());

        if (document.isReceipt()) {
            // Check Receipt - Set Issuing Authority - Set Receipt Number
            Form_17062.Section2.Documents.ListB.checklistBReceipt(document.getListBDocument());
            Form_17062.Section2.Documents.ListB.setIssuingAuthority(document.getListBDocument(),
                                                                    document.getIssuingAuthority());
            Form_17062.Section2.Documents.ListB
                    .setDocumentNumber(document.getListBDocument(), document.getDocumentNumber());
        } else {
            if (Form_17062.Section2.isRequired(Form_17062.Section2.Documents.ListB
                                                       .getDocumentTypeElement(
                                                               document.getListBDocument()))) {
                // Set Document Type, Set State
                Form_17062.Section2.Documents.ListB
                        .setDocumentType(document.getListBDocument(), document.getDocumentType());
                Form_17062.Section2.Documents.ListB
                        .setState(document.getListBDocument(), document.getStateOfUnion());
            } else {
                // Set Issuing Authority
                Form_17062.Section2.Documents.ListB.setIssuingAuthority(document.getListBDocument(),
                                                                        document.getIssuingAuthority());
            }
            Form_17062.Section2.Documents.ListB
                    .setDocumentNumber(document.getListBDocument(), document.getDocumentNumber());
            Form_17062.Section2.Documents.ListB
                    .setExpirationDate(document.getListBDocument(), document.getExpirationDate());
        }
    }

    public static void fillListCDocument(ListCEligibilityDocument document) {

        Form_17062.Section2.Documents.ListC.selectListCDocument(document.getListCDocument());
        Form_17062.Section2.Documents.ListC
                .setIssuingAuthority(document.getListCDocument(), document.getIssuingAuthority());
        Form_17062.Section2.Documents.ListC
                .setDocumentNumber(document.getListCDocument(), document.getDocumentNumber());

        if (document.isReceipt()) {
            Form_17062.Section2.Documents.ListC.checkListCReceipt(document.getListCDocument());
        } else {
            if (Form_17062.Section2.Documents.ListC
                    .getExpirationDateControlElement(document.getListCDocument()).isDisplayed()) {
                Form_17062.Section2.Documents.ListC.setExpirationDate(document.getListCDocument(),
                                                                      document.getExpirationDate());
            }
        }
    }

    /**
     * Allows for the ability to add a start Date
     */
    private static class Certification
            extends Sites.CandidatePortal.Forms.Objects.I9.Section2.Certification {
    }

    private static class Section2 extends Sites.CandidatePortal.Forms.Objects.I9.Section2 {

    }

    public static class AdditionalInformation {
        static {
            PageFactory.initElements(Driver.getDriver(), AdditionalInformation.class);
        }
        @FindBy(how = How.CSS, using = "select[id$='_141']")
        public static WebElement genderDropDown;

        public static String getGender() {
            Select dropDown = new Select(genderDropDown);
            return dropDown.getFirstSelectedOption().getText();
        }

        public static void selectGender(String gender) {
            SeleniumTest.selectByVisibleTextFromDropDown(genderDropDown, gender);
        }
    }

    public static class Documents extends Sites.CandidatePortal.Forms.Objects.I9.Section2.Documents {

    }

    public static class Section2Information extends Sites.CandidatePortal.Forms.Objects.I9.Section2.EmployerReview {

    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {

    }
}
