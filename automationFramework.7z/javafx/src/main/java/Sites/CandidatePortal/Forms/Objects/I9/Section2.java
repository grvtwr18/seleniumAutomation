package Sites.CandidatePortal.Forms.Objects.I9;

import Data.locations.us.UsStateTerritory;
import Sites.CandidatePortal.Forms.Objects.Navigation;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import Workflows.HelperObjects.I9;
import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by abrackett on 10/17/16.
 */
public class Section2 extends I9Base {

    @FindBy(how = How.CSS, using = "#breadCrumbs > a")
    private static WebElement myDashboardLink;

    static {
        PageFactory.initElements(Driver.getDriver(), Section2.class);
    }


    public static void clickMyDashboardLink() {
        myDashboardLink.click();
    }

    private static final Logger staticLogger = LoggerFactory.getLogger(Section2.class);

    public static class Section2Info {

        @FindBy(how = How.ID, using = "i9Section2ExamineDocument")
        public static WebElement section2Instructions;

        static {
            PageFactory.initElements(Driver.getDriver(), Section2Info.class);
        }

        public static String getSection2Instructions() {
            return section2Instructions.getText();
        }

    }


    public static class EmployerReview {

        @FindBy(how = How.CSS, using = "input[id$='_List A']")
        public static WebElement listARadioButton;

        @FindBy(how = How.CSS, using = "input[id$='_List B and C']")
        public static WebElement listBRadioButton;

        @FindBy(how = How.CSS, using = "label[for$='_List A']")
        public static WebElement listARadioButtonLabel;

        @FindBy(how = How.CSS, using = "label[for$='_List B and C']")
        public static WebElement listBRadioButtonLabel;

        @FindBy(how = How.CSS, using = "[id$='_2-err']")
        public static WebElement selectedDocumentListError;

        static {
            PageFactory.initElements(Driver.getDriver(), EmployerReview.class);
        }

        public static void chooseListA() {
            listARadioButtonLabel.click();
        }

        public static void chooseListBAndC() {
            listBRadioButtonLabel.click();
        }

        public static String getSelectedDocumentList() {
            if (listARadioButton.isSelected()) {
                return "A";
            } else if (listBRadioButton.isSelected()) {
                return "BC";
            }
            return "";
        }

        public static String getSelectedDocumentListError() {
            return selectedDocumentListError.getText();
        }
    }


    public static class AdditionalInformation {

        @FindBy(how = How.CSS, using = "textarea[id$='-I9s2_60']")
        public static WebElement additionalInformationTextBox;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_60-err']")
        public static WebElement additionalInformationErr;

        static {
            PageFactory.initElements(Driver.getDriver(), AdditionalInformation.class);
        }

        public static void setAdditionalInformation(String additionalInfoText) {
            SeleniumTest.clearAndSetText(additionalInformationTextBox, additionalInfoText);
            staticLogger.info("Additional Information Text is set to {}", additionalInfoText);
        }

        public static String getAdditionalInformation() {
            return additionalInformationTextBox.getAttribute("value");
        }

        public static String getAdditionalInformationError() {
            return additionalInformationErr.getText();
        }
    }


    public static class Certification {

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_56'][type$='text']")
        public static WebElement startDateCalendarControl;

        @FindBy(how = How.CSS,
                using = "input[id$='-I9s2_56'" + "][type$='hidden']")
        public static WebElement hiddenStartDateCalendarControl;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_56-err']")
        public static WebElement startDateCalendarControlErr;

        @FindBy(how = How.CSS, using = "[id$='-100_16-err']")
        public static WebElement hiddenStartDateCalendarControlErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_44']")
        public static WebElement authorizedRepresentativeFirstNameTextBox;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_44-err']")
        private static WebElement authorizedRepresentativeFirstNameErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_43']")
        public static WebElement authorizedRepresentativeLastNameTextBox;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_43-err']")
        private static WebElement authorizedRepresentativeLastNameErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_42']")
        public static WebElement authorizedRepresentativeTextBox;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_42-err']")
        public static WebElement authorizedRepresentativeErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_45']")
        public static WebElement businessNameTextBox;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_45-err']")
        public static WebElement businessNameErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_46']")
        public static WebElement addressLine1TextBox;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_46-err']")
        public static WebElement addressLine1Err;

        @FindBy(how = How.CSS, using = "input[id$='-addressI9s2_47-I9s2_47']")
        public static WebElement cityTextBox;

        @FindBy(how = How.CSS, using = "[id$='-addressI9s2_47-I9s2_47-err']")
        public static WebElement cityError;

        @FindBy(how = How.CSS, using = "select[id$='-addressI9s2_47-I9s2B_44']")
        public static WebElement countryOrRegionDropDown;

        @FindBy(how = How.CSS, using = "[id$='-addressI9s2_47-I9s2B_44-err']")
        public static WebElement countryOrRegionError;

        @FindBy(how = How.CSS, using = "select[id$='-addressI9s2_47-I9s2_48']")
        public static WebElement stateOrProvinceDropDown;

        @FindBy(how = How.CSS, using = "[id$='-addressI9s2_47-I9s2_48-err']")
        public static WebElement stateOrProvinceError;

        @FindBy(how = How.CSS, using = "input[id$='-addressI9s2_47-I9s2_49']")
        public static WebElement zipCodeTextBox;

        @FindBy(how = How.CSS, using = "[id$='-addressI9s2_47-I9s2_49-err']")
        public static WebElement zipCodeError;

        @FindBy(how = How.CSS, using = "[id$='-addressI9s2_47-err']")
        public static WebElement addressError;

        static {
            PageFactory.initElements(Driver.getDriver(), Certification.class);
        }

        public static String getAuthorizedRepresentativeFirstName() {
            return authorizedRepresentativeFirstNameTextBox.getAttribute("value");
        }

        public static String getAuthorizedRepresentativeFirstNameError() {
            return authorizedRepresentativeFirstNameErr.getText();
        }

        public static void setAuthorizedRepresentativeFirstName(String firstName) {
            SeleniumTest.clearAndSetText(authorizedRepresentativeFirstNameTextBox, firstName);
            staticLogger.info("AuthorizedRepresentative First Name set to {}", firstName);
        }

        public static String getAuthorizedRepresentativeLastName() {
            return authorizedRepresentativeLastNameTextBox.getAttribute("value");
        }

        public static String getAuthorizedRepresentativeLastNameError() {
            return authorizedRepresentativeLastNameErr.getText();
        }

        public static void setAuthorizedRepresentativeLastName(String lastName) {
            SeleniumTest.clearAndSetText(authorizedRepresentativeLastNameTextBox, lastName);
            staticLogger.info("Authorized Representative Last Name set to {}", lastName);
        }

        public static String getAuthorizedRepresentative() {
            return authorizedRepresentativeTextBox.getAttribute("value");
        }

        public static String getAuthorizedRepresentativeError() {
            return authorizedRepresentativeErr.getText();
        }

        public static void setAuthorizedRepresentative(String representative) {
            SeleniumTest.clearAndSetText(authorizedRepresentativeTextBox, representative);
            staticLogger.info("AuthorizedRepresentative set to {}", representative);
        }

        public static String getBusinessName() {
            return businessNameTextBox.getAttribute("value");
        }

        public static String getBusinessNameError() {
            return businessNameErr.getText();
        }

        public static void setBusinessName(String businessName) {
            SeleniumTest.clearAndSetText(businessNameTextBox, businessName);
            staticLogger.info("Business Name set to {}", businessName);
        }

        public static String getAddressLine1() {
            return addressLine1TextBox.getAttribute("value");
        }

        public static String getAddressLine1Error() {
            return addressLine1Err.getText();
        }

        public static void setAddressLine1(String address) {
            SeleniumTest.clearAndSetText(addressLine1TextBox, address);
            staticLogger.info("Address Line 1 set to {}", address);
        }

        public static String getCity() {
            return cityTextBox.getAttribute("value");
        }

        public static String getCityError() {
            return cityError.getText();
        }

        public static void setCity(String city) {
            SeleniumTest.clearAndSetText(cityTextBox, city, true);
            staticLogger.info("City set to {}", city);
        }

        public static String getCountryOrRegion() {
            Select dropDown = new Select(countryOrRegionDropDown);
            return dropDown.getFirstSelectedOption().getText();
        }

        public static String getCountryOrRegionError() {
            return countryOrRegionError.getText();
        }

        public static void selectCountryOrRegion(String countryOrRegion) {
            SeleniumTest.selectByVisibleTextFromDropDown(countryOrRegionDropDown, countryOrRegion);
            staticLogger.info("Country or Region selected {}", countryOrRegion);
        }

        public static String getStateOrProvince() {
            Select dropDown = new Select(stateOrProvinceDropDown);
            return dropDown.getFirstSelectedOption().getText();
        }

        public static String getStateOrProvinceError() {
            return stateOrProvinceError.getText();
        }

        public static void selectStateOrProvince(UsStateTerritory state) {
            I9Base.selectStateOrProvince(state, stateOrProvinceDropDown);
        }

        public static void selectStateOrProvince(String state) {
            I9Base.selectStateOrProvince(state, stateOrProvinceDropDown);
            SeleniumTest.waitMs(1000);
        }

        public static String getZipCode() {
            return zipCodeTextBox.getAttribute("value");
        }

        public static String getZipCodeError() {
            return zipCodeError.getText();
        }

        public static void setZipCode(String zipCode) {
            SeleniumTest.clearAndSetText(zipCodeTextBox, zipCode);
            staticLogger.info("Zip Code set to {}", zipCode);
        }

        public static String getAddressError() {
            return addressError.getText();
        }

        public static void setStartDate(LocalDate date) {
            SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                    date, startDateCalendarControl.getAttribute("id"),
                    hiddenStartDateCalendarControl.getAttribute("id"));
            staticLogger.info("Start Date set to {}", date.format(DateTimeFormatter.ofPattern
                    ("MM/dd/yyy")));
        }

        public static String getStartDateError() {
            return startDateCalendarControlErr.getText();
        }

        public static String getHiddenStartDateError() {
            return hiddenStartDateCalendarControlErr.getText();
        }

        public static void fillPanCertification(String authorizedFirstName,
                                                String authorizedLastName) {
            Section2.Certification.setAuthorizedRepresentativeFirstName(authorizedFirstName);
            Section2.Certification.setAuthorizedRepresentativeLastName(authorizedLastName);
        }

        public static void fillCertification(BusinessEntity businessEntity, LocalDate startDate) {
            Section2.Certification.setStartDate(startDate);
            Section2.Certification.setAuthorizedRepresentative(businessEntity.getTitle());
            Section2.Certification.setBusinessName(businessEntity.getName());
            Section2.Certification.setAddressLine1(businessEntity.getAddressLine1());
            Section2.Certification.setCity(businessEntity.getCity());
            Section2.Certification.selectStateOrProvince(businessEntity.getStateOrProvince());
            Section2.Certification.setZipCode(businessEntity.getZipCode());
        }
    }


    public static class UploadDocuments {

        @FindBy(how = How.XPATH, using = "(//input[contains(@id,'-filebrowse')])[1]")
        public static WebElement chooseFileButton;

        @FindBy(how = How.XPATH, using = "(//input[contains(@id,'-filebrowse')])[2]")
        public static WebElement choose2ndFileButton;

        @FindBy(how = How.XPATH, using = "(//input[contains(@id,'-filebrowse')])[3]")
        public static WebElement choose3rdFileButton;

        @FindBy(how = How.XPATH, using = "(//input[contains(@id,'-filebrowse')])[4]")
        public static WebElement choose4thFileButton;

        @FindBy(how = How.XPATH, using = "(//input[contains(@id,'-filebrowse')])[5]")
        public static WebElement choose5thFileButton;

        @FindBy(how = How.XPATH, using = "//button[@class='btnPostFileToServer button']")
        public static WebElement uploadFileButton;

        @FindBy(how = How.CSS, using = "div[id$='17066_1-err']")
        public static WebElement uploadFileErrorMessage;

        static {
            PageFactory.initElements(Driver.getDriver(), UploadDocuments.class);
        }

        public static void setFileToUpload(String filePath) {
            staticLogger.info("File path : " + filePath);
            if (OS.isFamilyWindows()) {
                filePath = filePath.startsWith("/") ? filePath.substring(1) : filePath;
            }
            ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" +
                    chooseFileButton
                            .getAttribute("id") +
                    "').style.visibility = "
                    + "'visible';");
            if (!filePath.startsWith("/") && !filePath.contains(":")) {
                filePath = "/" + filePath;
            }

            chooseFileButton.sendKeys(filePath);
            SeleniumTest.waitForElementToBeClickable(uploadFileButton, 60);
            staticLogger.info("File Upload Path set to {}", filePath);
        }

        public static void set2ndFileToUpload(String filePath) {
            staticLogger.info("File path : " + filePath);
            if (OS.isFamilyWindows()) {
                filePath = filePath.startsWith("/") ? filePath.substring(1) : filePath;
            }
            ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" +
                    choose2ndFileButton
                            .getAttribute("id") +
                    "').style.visibility = "
                    + "'visible';");
            if (!filePath.startsWith("/") && !filePath.contains(":")) {
                filePath = "/" + filePath;
            }

            choose2ndFileButton.sendKeys(filePath);
            SeleniumTest.waitForElementToBeClickable(uploadFileButton, 60);
            staticLogger.info("File Upload Path set to {}", filePath);
        }

        public static void set3rdFileToUpload(String filePath) {
            staticLogger.info("File path : " + filePath);
            if (OS.isFamilyWindows()) {
                filePath = filePath.startsWith("/") ? filePath.substring(1) : filePath;
            }
            ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" +
                    choose3rdFileButton
                            .getAttribute("id") +
                    "').style.visibility = "
                    + "'visible';");
            if (!filePath.startsWith("/") && !filePath.contains(":")) {
                filePath = "/" + filePath;
            }

            choose3rdFileButton.sendKeys(filePath);
            SeleniumTest.waitForElementToBeClickable(uploadFileButton, 60);
            staticLogger.info("File Upload Path set to {}", filePath);
        }

        public static void set4thFileToUpload(String filePath) {
            staticLogger.info("File path : " + filePath);
            if (OS.isFamilyWindows()) {
                filePath = filePath.startsWith("/") ? filePath.substring(1) : filePath;
            }
            ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" +
                    choose4thFileButton
                            .getAttribute("id") +
                    "').style.visibility = "
                    + "'visible';");
            if (!filePath.startsWith("/") && !filePath.contains(":")) {
                filePath = "/" + filePath;
            }

            choose4thFileButton.sendKeys(filePath);
            SeleniumTest.waitForElementToBeClickable(uploadFileButton, 60);
            staticLogger.info("File Upload Path set to {}", filePath);
        }

        public static void set5thFileToUpload(String filePath) {
            staticLogger.info("File path : " + filePath);
            if (OS.isFamilyWindows()) {
                filePath = filePath.startsWith("/") ? filePath.substring(1) : filePath;
            }
            ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" +
                    choose5thFileButton
                            .getAttribute("id") +
                    "').style.visibility = "
                    + "'visible';");
            if (!filePath.startsWith("/") && !filePath.contains(":")) {
                filePath = "/" + filePath;
            }

            choose5thFileButton.sendKeys(filePath);
            SeleniumTest.waitForElementToBeClickable(uploadFileButton, 60);
            staticLogger.info("File Upload Path set to {}", filePath);
        }

        public static void clickUploadFile() {
            SeleniumTest.waitMs(2000);
            uploadFileButton.click();
            staticLogger.info("Upload File Button Pressed");
            SeleniumTest
                    .waitForElementToBeClickable(By.xpath("//label[text()='Previously Uploaded:']"),
                            90);
            WaitUntil.waitUntil(90, 3, () -> Driver.getDriver()
                    .findElement(By.className("btnPostFileToServer")).getAttribute("disabled")
                    .equals("true"), NullPointerException.class);
            staticLogger.info("Upload File Button Action Complete");
        }

        /**
         * Returns the error text when a file is not attached.
         *
         * @return
         */
        public String getUploadErrorText() {
            return uploadFileErrorMessage.getText();
        }

        public static void completeSection2(String document, WorkEligibilityDocument doc, String filePath) {
            Section2.Documents.fillDocumentInfo(doc);
            SeleniumTest.waitMs(2000);
            uploadDocument(document,filePath);
            SeleniumTest.waitMs(5000);
            Section2.Acknowledgement.checkIAcknowledge();
            Navigation.clickNext();
        }

        public static void uploadDocument(String document, String filePath){
            if (document == "U.S. Passport") {
                Section2.UploadDocuments.setFileToUpload(filePath);
                SeleniumTest.waitMs(2000);
                Section2.UploadDocuments.clickUploadFile();
                SeleniumTest.waitMs(5000);
                Section2.UploadDocuments.set2ndFileToUpload(filePath);
                Section2.UploadDocuments.clickUploadFile();
            } else if (document == "U.S. Passport Card" || document == "Perm. Resident Card (Form I-551)" || document == "Employment Authorization Document (Form I-766)") {
                Section2.UploadDocuments.set3rdFileToUpload(filePath);
                SeleniumTest.waitMs(2000);
                Section2.UploadDocuments.clickUploadFile();
                SeleniumTest.waitMs(5000);
                Section2.UploadDocuments.set4thFileToUpload(filePath);
                Section2.UploadDocuments.clickUploadFile();
            }
        }
        public static void CompleteSection2ForRetainNonePreference(WorkEligibilityDocument doc){
            Section2.Documents.fillDocumentInfo(doc);
            SeleniumTest.waitMs(2000);
            SeleniumTest.waitMs(5000);
            Section2.Acknowledgement.checkIAcknowledge();
            Navigation.clickNext();
        }
    }


    public static class Acknowledgement {

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_52']")
        public static WebElement iAcknowledgeCheckBox;

        @FindBy(how = How.CSS, using = "label[for$='-I9s2_52']")
        public static WebElement iAcknowledgeCheckBoxLabel;

        @FindBy(how = How.CSS, using = "[id$='-I9s2_52-err']")
        public static WebElement iAcknowledgeCheckBoxErr;

        static {
            PageFactory.initElements(Driver.getDriver(), Acknowledgement.class);
        }

        public static String getIAcknowledgeCheckBoxError() {
            return iAcknowledgeCheckBoxErr.getText();
        }

        public static void checkIAcknowledge() {
            SeleniumTest.check(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
            staticLogger.info("I Acknowledge checked");
        }

        public static void uncheckIAcknowledge() {
            SeleniumTest.unCheck(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
            staticLogger.info("I Acknowledge unchecked");
        }

    }


    public static class Documents {

        static {
            PageFactory.initElements(Driver.getDriver(), Documents.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_11']")
        public static WebElement secondDocumentIssuingAuthorityTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_13']")
        public static WebElement secondDocumentDocumentNumberTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_14_1'][@type='text']")
        public static WebElement secondDocumentExpirationDateControl;

        @FindBy(how = How.CSS, using = "select[id$='_4']")
        private static WebElement listADocumentDropDown;

        @FindBy(how = How.CSS, using = "select[id$='_25']")
        private static WebElement listBDocumentDropDown;

        @FindBy(how = How.CSS, using = "select[id$='_26']")
        private static WebElement listCDocumentDropDown;

        @FindBy(how = How.CSS, using = "select[id$='_77']")
        private static WebElement listC7DocumentDropDown;

        @FindBy(how = How.ID, using = "17066-17066_78") //17066-17066_78
        private static WebElement listC7_OtherDocumentTitleTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s2_14_1'][type$='hidden']")
        private static WebElement hiddenSecondDocumentExpirationDateControl;

        @FindBy(how = How.XPATH, using = "//div[@id='17066-I9s2_12-err']")
        public static WebElement lblSecondDocumentNumberErrorMsg;

        @FindBy(how = How.XPATH, using = "//div[@id='17066-I9s2_8-err']")
        public static WebElement lblFirstDocumentNumberErrorMsg;

        @FindBy(how = How.XPATH, using = "//input[@id='17066-I9s2_8']")
        public static WebElement txtSection1DocumentNumber;

        @FindBy(how = How.XPATH, using = "//input[@id='17066-I9s2_12']")
        public static WebElement txtSection2DocumentNumber;

        @FindBy(how = How.XPATH, using = "//input[@id='17066-I9s2_14_1-I9s2_14_1']")
        public static WebElement dateExpiration;

        @FindBy(how = How.XPATH, using = "//input[@id='17066-I9s2_9-I9s2_9']")
        public static WebElement dateExpirationListADocument;
        // endregion


        public static void fillDocumentInfo(WorkEligibilityDocument doc) {
            SeleniumTest.waitForPageLoadToComplete();
            String value = doc.getDocLocation().getValue();
            String docListType = doc.getType().toUpperCase();
            Section2.Documents.selectListDocument(doc);
            Section2.Documents.setOtherListC7DocumentTitles(doc);
            if (value == "FOREIGNPASSPORTWITHI-94/AFORM") {
                Section2.Documents.setIssuingAuthority(doc);
            } else if (value == "FSMPASSPORTWITHI-94/AFORM" || value == "RMIPASSPORTWITHI-94/AFORM" || value == "I-94/AFORMWITHREFUGEESTAMP" || value == "USPASSPORTCARD" && docListType == "A") {
            } else {
                Section2.Documents.setIssuingAuthority(doc);
            }
            Section2.Documents.setDocumentNumber(doc);
            Section2.Documents.setExpirationDate(doc);
            SeleniumTest.waitMs(2000);
            Section2.Documents.setState(doc);
            SeleniumTest.waitMs(2000);
        }

        /**
         * Filling multiple documents - The order of the fill will matter for subsequenty documents
         *
         * @param docs
         */
        public static void fillDocumentInfo(ArrayList<WorkEligibilityDocument> docs) {
            for (WorkEligibilityDocument doc : docs) {
                fillDocumentInfo(doc);
            }
        }

        /**
         * Selects List A or List B and C and fills document info for each document
         * in the passed WorkEligibilityDocument List
         *
         * @param docs
         */
        public static void selectDocumentListTypeRadioAndFillInfo(
                ArrayList<WorkEligibilityDocument> docs) {
            for (WorkEligibilityDocument doc : docs) {
                switch (doc.getType().toUpperCase()) {
                    case "A":
                        Sites.CandidatePortal.Forms.Objects.I9.Section2.EmployerReview.chooseListA();
                        break;
                    case "B":
                        Sites.CandidatePortal.Forms.Objects.I9.Section2.EmployerReview.chooseListBAndC();
                        break;
                    case "C":
                        Sites.CandidatePortal.Forms.Objects.I9.Section2.EmployerReview.chooseListBAndC();
                        break;
                }
                fillDocumentInfo(doc);
            }
        }


        public static void setIssuingAuthority(WorkEligibilityDocument doc) {
            WebElement issuingAuthorityElement = getIssuingAuthorityElement(doc.getDocLocation());

            switch (issuingAuthorityElement.getTagName().toLowerCase()) {
                case "input":
                    String isReadOnly = issuingAuthorityElement.getAttribute("readonly");
                    if (isReadOnly != null && isReadOnly.equals("true")) {
                        staticLogger.info("Issuing Authority is READ ONLY");
                        return;
                    }
                    SeleniumTest.clearAndSetText(issuingAuthorityElement, doc.getIssuingAuthority());
                    break;
                case "select":
                    SeleniumTest.selectByVisibleTextFromDropDown(issuingAuthorityElement, doc.getIssuingAuthority());
                    break;
                default:
                    throw new RuntimeException("Unable to determine the type of element -"
                            + " could not set issuing authority value");
            }
            staticLogger.info("Issuing Authority set to {}", doc.getIssuingAuthority());
        }

        public static WebElement getIssuingAuthorityElement(DocumentLocation document) {
            // must find the right element type input or select before returning.
            List<WebElement> elements = Driver.getDriver().findElements(
                    By.cssSelector("*[id$='" + document.getIssuingAuthorityId() + "']"));
            for (WebElement element : elements) {
                if (element.getTagName().equals("input") || element.getTagName().equals
                        ("select")) {
                    return element;
                }
            }
            return null;
        }

        public static WebElement getStateElement(DocumentLocation document) {
            return Driver.getDriver()
                    .findElement(By.cssSelector("select[id$='" + document.getIssuingAuthorityId() + "']"));
        }

        public static void setState(WorkEligibilityDocument doc) {
            if (Section2.Documents.ListBDocuments.USSTATEDRIVERSLICENSE == doc.getDocLocation()) {
                SeleniumTest.selectByVisibleTextFromDropDown(getStateElement(doc.getDocLocation()), doc.getIssuingAuthority());
                staticLogger.info("State set to {}", doc.getIssuingAuthority());
            } else {
                staticLogger.info("SetState called but invalid document");
            }
        }

        public static void selectListDocument(WorkEligibilityDocument document) {

            String value = document.getDocLocation().getValue();
            if (value.isEmpty()) {
                staticLogger.info("Document is pre-selected");
                return;
            }

            switch (document.getType().toLowerCase()) {
                case "a":
                    SeleniumTest.selectByValueFromDropDown(listADocumentDropDown, value);
                    break;
                case "b":
                    SeleniumTest.selectByValueFromDropDown(listBDocumentDropDown, value);
                    break;
                case "c":
                    SeleniumTest.selectByValueFromDropDown(listCDocumentDropDown, value);
                    break;
                case "c7":
                    SeleniumTest.selectByValueFromDropDown(listC7DocumentDropDown, value);
                    break;
                default:
                    // If this happens we should exit because the doc type we don't know about.
                    Assert.assertTrue(false, "Invalid List a/b/c Doc Type");
                    break;
            }

            staticLogger.info("List " + document.getType() + " Document Selected {}", document.getTitle());
        }

        public static void setOtherListC7DocumentTitles(WorkEligibilityDocument doc) {
            if ("c7" == doc.getType() && ListCDocuments.LIST_C7_SUB_DOC_OTHER == doc.getDocLocation()) {
                SeleniumTest.clearAndSetText(listC7_OtherDocumentTitleTextBox, doc.getTitle());
                staticLogger.info("List C #7 Other Document Title set to {}", doc.getTitle());
            }
        }

        public static void setDocumentNumber(WorkEligibilityDocument doc) {

            if ("c" == doc.getType() && ListCDocuments.SOCIAL_SECURITY_CARD == doc.getDocLocation()) {
                staticLogger.info("SSC has no input field");
                return;
            }

            SeleniumTest.clearAndSetText(getDocumentNumberElement(doc.getDocLocation()), doc.getDocNumber());
            staticLogger.info("Document Number set to {}", doc.getDocNumber());
        }

        public static boolean validateDocumentNumberInputs(I9 i9, String docNumber, WebElement elDocNum, WebElement dtExpiration) {
            // SeleniumTest.waitForElementToBeClickable(elDocNum);
            SeleniumTest.clearAndSetText(elDocNum, docNumber);
            staticLogger.info("Document Number set to {}", docNumber);

            SeleniumTest.click(dtExpiration);
            SeleniumTest.waitMs(2000);
            if (i9.coreI9WorkEligibilityDocuments.get(0).getDocLocation().getValue() == "I_94_AFORMWITHREFUGEESTAMP" || i9.coreI9WorkEligibilityDocuments.get(0).getDocLocation().getValue() == "I-94/AFORMWITHI-551STAMP") {
                if (Documents.lblFirstDocumentNumberErrorMsg.isDisplayed()) {
                    return false;
                } else {
                    return true;
                }
            } else {
                if (Section2.Documents.lblSecondDocumentNumberErrorMsg.isDisplayed()) {
                    return false;
                } else {
                    return true;
                }
            }
        }

        public static void setExpirationDate(WorkEligibilityDocument doc) {
            if (!doc.isHasExpDate()) {
                staticLogger.info("Document has no expiration field");
                return;
            }

            if (doc.getExpDate() == null) {
                getExpirationDateNaLabel(doc.getDocLocation()).click();
                // TODO Determine if the box is checked before just checking it
            } else {
                // do all the other work
                WebElement expirationDateControl = getExpirationDateControlElement(doc.getDocLocation());
                WebElement hiddenExpirationDateControl = Driver.getDriver().findElement(
                        By.cssSelector(
                                "input[id$='" + doc.getDocLocation().getExpirationId() + "'" + "][type$='hidden']"));
                SeleniumTest.FireFoxWorkArounds
                        .setCalendarControl_MM_Slash_dd_Slash_yyyy(doc.getExpDate(), expirationDateControl
                                .getAttribute("id"), hiddenExpirationDateControl
                                .getAttribute("id"));
                staticLogger.info("Expiration Date set to {}", doc.getExpDate().format
                        (DateTimeFormatter.ofPattern("MM/dd/yyyy")));
            }
        }

        public static void setExpirationDateNa(ListADocuments document) {
            WebElement expirationDateNaControl = getExpirationDateNaLabel(document);
            expirationDateNaControl.click();
        }

        public static WebElement getExpirationDateNaLabel(DocumentLocation document) {
            return Driver.getDriver().findElement(
                    By.cssSelector("label[for$='" + document.getExpirationNaId() + "']"));
        }

        public static WebElement getExpirationDateControlElement(DocumentLocation document) {
            return Driver.getDriver().findElement(
                    By.cssSelector("input[id$='" + document.getExpirationId() + "'][type$='text']"));
        }

        public static WebElement getDocumentNumberElement(DocumentLocation document) {
            return Driver.getDriver().findElement(
                    By.cssSelector("input[id$='" + document.getDocumentNumberId() + "']"));
        }

        /**
         * Enum of List A Documents
         */
        public enum ListADocuments implements DocumentLocation {
            // String,
            // dropdown value,
            // receipt,
            // issuing authority,
            // number,
            // dropdown,
            // expiration,
            // second doc issuing authority,
            // second number,
            // second expiration

            USPASSPORT(
                    "U.S. Passport",
                    "USPASSPORT",
                    "_134",
                    "-I9s2_USPASSPORT_ISSUINGAUTH",
                    "-I9s2_3",
                    "",
                    "-I9s2_9",
                    "",
                    "",
                    ""),
            USPASSPORTCARD(
                    "U.S. Passport Card",
                    "USPASSPORTCARD",
                    "_134",
                    "I9s2_2",
                    "-I9s2_3",
                    "",
                    "-I9s2_9",
                    "",
                    "",
                    ""),
            PERMANENTRESIDENTCARD(
                    "Permanent Resident Card",
                    "PERMANENTRESIDENTCARD",
                    "_134",
                    "-I9s2_ISSUINGAUTH_PERMRES",
                    "-I9s2_4",
                    "",
                    "-I9s2_9",
                    "",
                    "",
                    ""),
            ALIENREGISTRATIONRECEIPTCARD(
                    "Alien Registration Receipt Card (Form I-551)",
                    "ALIENREGISTRATIONRECEIPTCARD",
                    "_134",
                    "-I9s2_ALIENREG_ISSUINGAUTH",
                    "-I9s2_5",
                    "",
                    "-I9s2_9",
                    "",
                    "",
                    ""),
            FOREIGNPASSPORTWITHI_551STAMP(
                    "Foreign PP with I-551",
                    "FOREIGNPASSPORTWITHI-551STAMP",
                    "_134",
                    "-I9s2_FP_I94_OR_I551STAMP_ISSUINGAUTH",
                    "-I9s2_6",
                    "-I9s2_53",
                    "-I9s2_9",
                    "-I9s2_11I551",
                    "-I9s2_13",
                    "-I9s2_14_1"),
            FOREIGNPASSPORTWITHI_551MRIV(
                    "Foreign Passport containing a temp. I-551 MRIV",
                    "FOREIGNPASSPORTWITHI-551MRIV",
                    "_134",
                    "-I9s2_FP_I94_OR_I551STAMP_ISSUINGAUTH",
                    "-I9s2_6",
                    "-I9s2_53",
                    "-I9s2_9",
                    "-I9s2_64",
                    "-I9s2_63",
                    "-I9s2_14_1"),
            EMPLOYMENTAUTHORIZATIONDOCUMENT(
                    "Employment Auth (I-766)",
                    "EMPLOYMENTAUTHORIZATIONDOCUMENT",
                    "_134",
                    "-I9s2_EMPLOYMENTAUTH_ISSUINGAUTH",
                    "-I9s2_7",
                    "-I9s2_57",
                    "-I9s2_9_EAD",
                    "",
                    "",
                    ""),
            FOREIGNPASSPORTWITHI_94_AFORM(
                    "Foreign PP with I-94/A", "FOREIGNPASSPORTWITHI-94/AFORM",
                    "_134",
                    "-I9s2_FP_I94_OR_I551STAMP_ISSUINGAUTH",
                    "-I9s2_6",
                    "-I9s2_53",
                    "-I9s2_9",
                    "-I9s2_11",
                    "-I9s2_12",
                    "-I9s2_14_1"),
            FSMPASSPORTWITHI_94_AFORM(
                    "FSM PP with I-94/A",
                    "FSMPASSPORTWITHI-94/AFORM",
                    "_134",
                    "-I9s2_FP_I94_OR_I551STAMP_ISSUINGAUTH",
                    "-I9s2_6",
                    "-I9s2_53",
                    "-I9s2_9",
                    "-I9s2_11",
                    "-I9s2_12",
                    "-I9s2_14_1"),
            RMIPASSPORTWITHI_94_AFORM(
                    "RMI PP with I-94/A",
                    "RMIPASSPORTWITHI-94/AFORM",
                    "_134",
                    "-I9s2_FP_I94_OR_I551STAMP_ISSUINGAUTH",
                    "-I9s2_6",
                    "-I9s2_53",
                    "-I9s2_9",
                    "-I9s2_11",
                    "-I9s2_12",
                    "-I9s2_14_1"),
            I_94_AFORMWITHREFUGEESTAMP(
                    "I-94/A w/Refugee Stamp",
                    "I-94/AFORMWITHREFUGEESTAMP",
                    "_134",
                    "-I9s2_FP_I94_OR_I551STAMP_ISSUINGAUTH",
                    "-I9s2_8",
                    "",
                    "-I9s2_9",
                    "",
                    "",
                    ""),
            I_94_AFORMWITHI_551STAMP(
                    "I-94/AFORMWITHI-551STAMP",
                    "I-94/AFORMWITHI-551STAMP",
                    "_134",
                    "17066-I9s2_REFUGEE_STAMP_ISSUINGAUTH",
                    "17066-I9s2_8",
                    "",
                    "-I9s2_9",
                    "",
                    "",
                    ""),
            Form_I_94_I_94A(
                    "Form_I-94_I-94A",
                    "",
                    "",
                    "-I9s2_11",
                    "-I9s2_12",
                    "",
                    "-I9s2_14_1",
                    "",
                    "",
                    ""),
            Form_I_551(
                    "I-551 Stamp on Passport",
                    "PERMANENTRESIDENTCARD",
                    "",
                    "17066-I9s2_ISSUINGAUTH_PERMRES",
                    "-I9s2_4",
                    "",
                    "-I9s2_9",
                    "",
                    "",
                    "");


            public final String text;
            public final String value;
            public final String receiptId;
            public final String issuingAuthorityId;
            public final String documentNumberId;
            public final String associatedDocumentValue;
            public final String expirationId;
            public final String expirationNaId;
            public final String secondDocIssuingAuthorityId;
            public final String secondDocDocumentNumberId;
            public final String secondDocExpirationId;
            public final String secondDocExpirationNaId;


            ListADocuments(final String text,
                           final String value,
                           final String receiptId,
                           final String issuingAuthorityId,
                           final String documentNumberId,
                           final String numberSelectorId,
                           final String expirationId,
                           final String secondIssuingAuthorityId,
                           final String secondDocumentNumberId,
                           final String secondExpirationId
            ) {
                this.text = text;
                this.value = value;
                this.receiptId = receiptId;
                this.issuingAuthorityId = issuingAuthorityId;
                this.documentNumberId = documentNumberId;
                this.associatedDocumentValue = numberSelectorId;
                this.expirationId = expirationId;
                this.expirationNaId = this.expirationId.concat("NA");
                this.secondDocIssuingAuthorityId = secondIssuingAuthorityId;
                this.secondDocDocumentNumberId = secondDocumentNumberId;
                this.secondDocExpirationId = secondExpirationId;
                this.secondDocExpirationNaId = this.secondDocExpirationId.concat("NA");
                ;
            }

            @Override
            public String toString() {
                return text;
            }

            public String getValue() {
                return this.value;
            }

            public String getDocumentNumberId() {
                return this.documentNumberId;
            }

            public String getReceiptId() {
                return this.receiptId;
            }

            public String getIssuingAuthorityId() {
                return this.issuingAuthorityId;
            }

            public String getExpirationId() {
                return this.expirationId;
            }

            public String getExpirationNaId() {
                return this.expirationNaId;
            }

            @Override
            public String getRichformDocTitle() {
                return null;
            }

            @Override
            public String getRichformDocExpDate() {
                return null;
            }

            @Override
            public String getRichformDocNumber() {
                return null;
            }

        }

        /**
         * enum of List B Documents
         */
        public enum ListBDocuments implements DocumentLocation {
            // String, receipt, type, state, issuing authority, number, dropdown, expiration
            USSTATEDRIVERSLICENSE(
                    "Driver's license issued by a State or outlying possession of the United States",
                    "USSTATEDRIVERSLICENSE",
                    "_135",
                    "-I9s2_20",
                    "-licenseI9s2_21-I9s2_21",
                    "",
                    "-licenseI9s2_21-I9s2_24",
                    "",
                    "-I9s2_25"),
            USSTATEID(
                    "ID card issued by a State or outlying possession of the United States",
                    "USSTATEID",
                    "_135",
                    "",
                    "-licenseI9s2_21-I9s2_21",
                    "-licenseI9s2_21-I9s2_21",
                    "-licenseI9s2_21-I9s2_24",
                    "",
                    "-I9s2_25"),
            GOVERNMENTID(
                    "Government Issued ID with Photo",
                    "GOVERNMENTID",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            SCHOOLID(
                    "School ID with Photo",
                    "SCHOOLID",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            VOTERREGISTRATIONCARD(
                    "Voter's Registration Card",
                    "VOTERREGISTRATIONCARD",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            USMILITARYCARD(
                    "U.S. Military ID",
                    "USMILITARYCARD",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            USMILITARYDRAFT(
                    "U.S. Draft Record",
                    "USMILITARYDRAFT",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            MILITARYDEPENDENTIDCARD(
                    "Military Dependent's ID Card",
                    "MILITARYDEPENDENTIDCARD",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            USCOASTGUARDMERCHANTMARINERCARD(
                    "U.S. Coast Guard Merchant Mariner Card",
                    "USCOASTGUARDMERCHANTMARINERCARD",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            NATIVEAMERICANTRIBALDOCUMENT(
                    "Native American Tribal Document",
                    "NATIVEAMERICANTRIBALDOCUMENT",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            CAGOVERNMENTDRIVERSLICENSE(
                    "Driver's license issued by a Canadian government authority",
                    "CAGOVERNMENTDRIVERSLICENSE",
                    "_135",
                    "",
                    "",
                    "-I9s2_CANADA_DL_ISSUINGAUTH",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            SCHOOLRECORD(
                    "School Record (under age 18)",
                    "SCHOOLRECORD",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            MEDICALRECORD(
                    "Clinical Record (under age 18)",
                    "MEDICALRECORD",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25"),
            PRE_SCHOOLRECORD(
                    "Day-care Record (under age 18)",
                    "PRE-SCHOOLRECORD",
                    "_135",
                    "",
                    "",
                    "-I9s2_22",
                    "-I9s2_23",
                    "",
                    "-I9s2_25");

            private final String text;
            private final String value;
            private final String receiptId;
            private final String type;
            private final String state; // TODO : Call this stateId
            private final String issuingAuthorityId;
            private final String documentNumberId;
            private final String associatedDocumentValue;
            private final String expirationId;
            private final String expirationNaId;

            ListBDocuments(final String text, final String value, final String receiptId, final String type,
                           final String state, final String issuingAuthorityId,
                           final String documentNumberId, final String numberSelectorId,
                           final String expirationId) {

                this.text = text;
                this.value = value;
                this.receiptId = receiptId;
                this.type = type;
                this.state = state;
                this.issuingAuthorityId = issuingAuthorityId;
                this.documentNumberId = documentNumberId;
                this.associatedDocumentValue = numberSelectorId;
                this.expirationId = expirationId;
                this.expirationNaId = this.expirationId.concat("NA");
            }

            @Override
            public String toString() {
                return text;
            }

            public String getValue() {
                return this.value;
            }

            public String getDocumentNumberId() {
                return this.documentNumberId;
            }

            public String getReceiptId() {
                return this.receiptId;
            }

            public String getIssuingAuthorityId() {
                if ("USSTATEDRIVERSLICENSE" == this.value) {
                    return this.state;
                }
                return this.issuingAuthorityId;
            }

            public String getExpirationId() {
                return this.expirationId;
            }

            public String getExpirationNaId() {
                return this.expirationNaId;
            }

            @Override
            public String getRichformDocTitle() {
                return null;
            }

            @Override
            public String getRichformDocExpDate() {
                return null;
            }

            @Override
            public String getRichformDocNumber() {
                return null;
            }
        }

        /**
         * enum of List C Documents
         */
        public enum ListCDocuments implements DocumentLocation {
            // String, receipt, issuing authority, number, expiration
            SOCIAL_SECURITY_CARD(
                    "Social Security Card without restrictions",
                    "SSACCOUNTNUMBERCARD",
                    "_136",
                    "-I9s2_ISSUINGAUTH_SSN",
                    "-I9s2_28",
                    ""),
            SSACCOUNTNUMBERCARD(
                    "Social Security Card",
                    "SSACCOUNTNUMBERCARD",
                    "_136",
                    "-I9s2_ISSUINGAUTH_SSN",
                    "-I9s2_28",
                    ""),
            BIRTHABROADCERTIFICATEFS_545(
                    "Certification of Birth Abroad (Form FS-545)",
                    "BIRTHABROADCERTIFICATEFS-545",
                    "_136",
                    "-I9s2_BIRTHCERT_545_ISSUINGAUTH",
                    "-I9s2_28",
                    ""),
            BIRTHABROADCERTIFICATEDS_1350(
                    "Certification of Report of Birth (Form DS-1350)",
                    "BIRTHABROADCERTIFICATEDS-1350",
                    "_136",
                    "-I9s2_27",
                    "-I9s2_28",
                    ""),
            BIRTHCERTIFICATEWITHSEAL(
                    "Original or certified copy of U.S. birth certificate bearing an official seal",
                    "BIRTHCERTIFICATEWITHSEAL",
                    "_136",
                    "-I9s2_27",
                    "-I9s2_28",
                    ""),
            NATIVEAMERICANTRIBALDOCUMENT(
                    "Native American Tribal Document",
                    "NATIVEAMERICANTRIBALDOCUMENT",
                    "_136",
                    "-I9s2_27",
                    "-I9s2_28",
                    ""),
            USCITIZENIDCARD(
                    "U.S. Citizen ID Card (Form I-197)",
                    "USCITIZENIDCARD",
                    "_136",
                    "-I9s2_I197_ISSUINGAUTH",
                    "-I9s2_28",
                    ""),
            RESIDENTCITIZENIDCARD(
                    "Resident Citizen ID Card (Form I-179)",
                    "RESIDENTCITIZENIDCARD",
                    "_136",
                    "-I9s2_I179_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            DHSEMPLOYMENTAUTHORIZATIONDOCUMENT(
                    "Employment Auth. Document (DHS) List C #7",
                    "DHSEMPLOYMENTAUTHORIZATIONDOCUMENT",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            //(DHS) List C #7" sub documents
            LIST_C7_SUB_DOC_I94_WITH_F1_STATUS_AND_I20(
                    "Form I-94 indicating F-1 Nonimmigrant Status & Form I-20",
                    "I-94FORMWITHF-1STATUSANDI-20FORM",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_I94_WITH_DS2019(
                    "Form I-94 & Form DS-2019",
                    "I-94FORMWITHDS-2019FORM",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_I94_FOR_ASYLEE(
                    "Form I-94 Issued to Asylee",
                    "I-94FORMFORASYLEE",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_I94_FOR_WORK_AUTHORIZED_NONIMMIGRANT(
                    "Form I-94 Issued to Work Authorized Nonimmigrant",
                    "I-94FORMFORWORKAUTHORIZEDNONIMMIGRANT",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_REENTRY_PERMIT_I327(
                    "Reentry Permit (Form I-327)",
                    "REENTRYPERMIT",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_CERTIFICATE_OF_USCITIZENSHIP_N560(
                    "Certificate of U.S. Citizenship (Form N-560)",
                    "CERTIFICATEOFUSCITIZENSHIP",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_REPLACEMENT_CERTIFICATE_OF_CITIZENSHIP_N561(
                    "Replacement Certificate of Citizenship (Form N-561)",
                    "REPLACEMENTCERTIFICATEOFCITIZENSHIP",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_CERTIFICATE_OF_NATURALIZATION_N550_OR_N570(
                    "Certificate of Naturalization (Form N-550 or N-570)",
                    "CERTIFICATEOFNATURALIZATION",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_EXPIRED_I551_AND_I797_NOTICE_OF_ACTION(
                    "Expired Form I-551 and Form I-797, Notice of Action",
                    "EXPIREDFORMI-551ANDNOTICEOFACTION",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30"),
            LIST_C7_SUB_DOC_OTHER(
                    "Other",
                    "OTHER",
                    "_136",
                    "17066-I9s2_DHS_ISSUINGAUTH",
                    "-I9s2_28",
                    "-I9s2_30");

            private final String text;
            private final String value;
            private final String receiptId;
            private final String issuingAuthorityId;
            private final String documentNumberId;
            private final String expirationId;
            private final String expirationNaId;

            ListCDocuments(final String text, final String value, final String receiptId,
                           final String issuingAuthorityId, final String documentNumberId,
                           final String expirationId) {

                this.text = text;
                this.value = value;
                this.receiptId = receiptId;
                this.issuingAuthorityId = issuingAuthorityId;
                this.documentNumberId = documentNumberId;
                this.expirationId = expirationId;
                this.expirationNaId = this.expirationId.concat("NA");
            }

            @Override
            public String toString() {
                return text;
            }

            public String getValue() {
                return this.value;
            }

            public String getDocumentNumberId() {
                return this.documentNumberId;
            }

            public String getReceiptId() {
                return this.receiptId;
            }

            public String getIssuingAuthorityId() {
                return this.issuingAuthorityId;
            }

            public String getExpirationId() {
                return this.expirationId;
            }

            public String getExpirationNaId() {
                return this.expirationNaId;
            }

            @Override
            public String getRichformDocTitle() {
                return null;
            }

            @Override
            public String getRichformDocExpDate() {
                return null;
            }

            @Override
            public String getRichformDocNumber() {
                return null;
            }
        }


        public static class ListA {

            static {
                PageFactory.initElements(Driver.getDriver(), ListA.class);
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s2_11']")
            public static WebElement secondDocumentIssuingAuthorityTextBox;

            @FindBy(how = How.XPATH, using = "//select[@id='17066-I9s2_11']")
            public static WebElement ddlSecondDocumentIssuingAuthority;

            @FindBy(how = How.CSS, using = "[id$='-I9s2_11-err']")
            public static WebElement secondDocumentIssuingAuthorityErr;

            @FindBy(how = How.XPATH, using = "//input[@id='17066-I9s2_12']")
            public static WebElement secondDocumentDocumentNumberTextBox;

            @FindBy(how = How.CSS, using = "[id$='-I9s2_13-err']")
            public static WebElement secondDocumentDocumentNumberErr;

            @FindBy(how = How.XPATH, using = "//input[@id='17066-I9s2_14_1-I9s2_14_1']")
            public static WebElement secondDocumentExpirationDateControl;

            @FindBy(how = How.CSS, using = "[id$='-I9s2_14_1-err']")
            public static WebElement secondDocumentExpirationDateErr;

            @FindBy(how = How.CSS, using = "[id$='-I9s2_14_1-err']")
            public static WebElement hiddenSecondDocumentExpirationDateErr;

            @FindBy(how = How.CSS, using = "select[id$='_4']")
            public static WebElement listADocumentDropDown;

            @FindBy(how = How.CSS, using = "[id$='_4-err']")
            public static WebElement listADocumentDropDownErr;

            @FindBy(how = How.CSS, using = "select[id$='_25']")
            private static WebElement listBDocumentDropDown;

            @FindBy(how = How.CSS, using = "select[id$='_26']")
            private static WebElement ListCDocumentDropDown;

            @FindBy(how = How.CSS, using = "input[id$='-I9s2_14_1'][type$='hidden']")
            private static WebElement hiddenSecondDocumentExpirationDateControl;

            // endregion

            public static void selectListADocument(DocumentLocation document) {
                SeleniumTest.selectByValueFromDropDown(listADocumentDropDown, document.getValue());
                staticLogger.info("List A Document Selected {}", document);
            }

            // region List A Receipt
            public static void checkListAReceipt(ListADocuments document) {
                WebElement receiptCheckBox = Driver.getDriver()
                        .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                WebElement receiptCheckBoxLabel = Driver.getDriver()
                        .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                SeleniumTest.check(receiptCheckBoxLabel, receiptCheckBox);
                staticLogger.info("List A Receipt checked");
            }
            // endregion

            public static void uncheckListAReceipt(ListADocuments document) {
                WebElement receiptCheckBox = Driver.getDriver()
                        .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                WebElement receiptCheckBoxLabel = Driver.getDriver()
                        .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                SeleniumTest.unCheck(receiptCheckBoxLabel, receiptCheckBox);
                staticLogger.info("List A Receipt unchecked");
            }

            public static String getListADocumentError() {
                return listADocumentDropDownErr.getText();
            }

            public static String getIssuingAuthority(ListADocuments document) {
                return getIssuingAuthorityElement(document).getText();
            }

            public static String getIssuingAuthorityError(ListADocuments document) {
                return getIssuingAuthorityErrorElement(document).getText();
            }

            // region Issuing Authority
            public static WebElement getIssuingAuthorityElement(ListADocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.issuingAuthorityId + "']"));
                for (WebElement element : elements) {
                    if (element.getTagName().equals("input") || element.getTagName().equals
                            ("select")) {
                        return element;
                    }
                }
                return null;
            }

            public static WebElement getIssuingAuthorityErrorElement(ListADocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.issuingAuthorityId + "-err']"));
                if (elements.size() == 0) {
                    return null;
                }
                return elements.get(0);
            }

            public static WebElement getSecondDocumentIssuingAuthorityElement(ListADocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.secondDocIssuingAuthorityId + "']"));
                for (WebElement element : elements) {
                    if (element.getTagName().equals("input") || element.getTagName().equals
                            ("select")) {
                        return element;
                    }
                }
                return null;
            }

            public static WebElement getSecondDocumentIssuingAuthorityErrorElement(ListADocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.secondDocIssuingAuthorityId + "-err']"));
                if (elements.size() == 0) {
                    return null;
                }
                return elements.get(0);
            }

            // endregion

            // region document Associated Value

            public static void setIssuingAuthority(ListADocuments document,
                                                   String issuingAuthority) {
                WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                switch (issuingAuthorityElement.getTagName().toLowerCase()) {
                    case "input":
                        if (issuingAuthorityElement.getAttribute("readonly") == null) {
                            SeleniumTest.clearAndSetText(issuingAuthorityElement, issuingAuthority);
                        } else {
                            staticLogger.info("Issuing Authority is Read Only");
                        }
                        break;
                    case "select":
                        SeleniumTest.selectByVisibleTextFromDropDown(issuingAuthorityElement, issuingAuthority);
                        break;
                    default:
                        throw new RuntimeException("Unable to determine the type of element -"
                                + " could not set issuing authority value");
                }
                staticLogger.info("Issuing Authority set to {}", issuingAuthority);
            }

            public static String getDocumentNumber(ListADocuments document) {
                return getDocumentNumberElement(document).getText();
            }

            public static String getDocumentNumberError(ListADocuments document) {
                return getDocumentNumberErrorElement(document).getText();
            }

            // region Document Number
            public static WebElement getDocumentNumberElement(DocumentLocation document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("input[id$='" + document.getDocumentNumberId() + "']"));
            }

            public static WebElement getDocumentNumberErrorElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("[id$='" + document.documentNumberId + "-err']"));
            }


            public static WebElement getSecondDocumentNumberElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("input[id$='" + document.secondDocDocumentNumberId + "']"));
            }

            public static WebElement getSecondDocumentNumberErrorElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("[id$='" + document.secondDocDocumentNumberId + "-err']"));
            }
            // endregion

            // region Set Expiration Date Control

            public static void setDocumentNumber(DocumentLocation document, String documentNumber) {
                SeleniumTest.clearAndSetText(getDocumentNumberElement(document), documentNumber);
                staticLogger.info("Document Number set to {}", documentNumber);
            }

            public static String getAssociatedDocument(ListADocuments document) {
                try {

                    WebElement associatedDocument = getAssociatedDocumentElement(document);
                    switch (associatedDocument.getTagName().toLowerCase()) {
                        case "input":
                            return associatedDocument.getText();
                        case "select":
                            Select dropDown = new Select(associatedDocument);
                            return dropDown.getFirstSelectedOption().getText();
                        default:
                            return "";
                    }
                } catch (NoSuchElementException nse) {
                    return "";
                }
            }

            public static void setExpirationDate(ListADocuments document, LocalDate expiration) {
                WebElement expirationDateControl = getExpirationDateControlElement(document);
                WebElement hiddenExpirationDateControl = Driver.getDriver().findElement(
                        By.cssSelector(
                                "input[id$='" + document.expirationId + "'" + "][type$='hidden']"));
                SeleniumTest.FireFoxWorkArounds
                        .setCalendarControl_MM_Slash_dd_Slash_yyyy(expiration, expirationDateControl
                                .getAttribute("id"), hiddenExpirationDateControl
                                .getAttribute("id"));
                staticLogger.info("Expiration Date set to {}", expiration.format
                        (DateTimeFormatter.ofPattern("MM/dd/yyyy")));
            }


            public static void setExpirationDateNa(ListADocuments document) {
                WebElement expirationDateNaControl = getExpirationDateNaLabel(document);
                expirationDateNaControl.click();
            }

            public static String getAssociatedDocumentNumberError(ListADocuments document) {
                return getAssociatedDocumentErrorElement(document).getText();
            }

            // endregion

            // region Second Document

            public static WebElement getAssociatedDocumentElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.xpath("//*[contains(@id, '" + document.associatedDocumentValue + "')]"));
            }

            public static WebElement getAssociatedDocumentErrorElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.xpath("//*[contains(@id, '" + document.associatedDocumentValue + "-err')]"));
            }

            public static void setOrSelectAssociatedDocument(ListADocuments document,
                                                             String value) {
                try {
                    WebElement associatedDocument = getAssociatedDocumentElement(document);
                    switch (associatedDocument.getTagName().toLowerCase()) {
                        case "input":
                            SeleniumTest.clearAndSetText(associatedDocument, value);
                            break;
                        case "select":
                            SeleniumTest.selectByVisibleTextFromDropDown(associatedDocument, value);
                            break;
                        default:
                            throw new RuntimeException("Unable to determine the type of element -"
                                    + " could not set document value");
                    }
                    staticLogger.info("Associated Document set to {}", value);

                } catch (NoSuchElementException nse) {
                    throw new RuntimeException("Unable to determine the type of element - could "
                            + "not set document value");
                }
            }


            public static WebElement getExpirationDateControlElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("input[id$='" + document.expirationId + "'][type$='text']"));
            }

            public static WebElement getExpirationDateControlErrorElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("[id$='" + document.expirationId + "-err']"));
            }

            public static WebElement getSecondExpirationDateControlElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("input[id$='" + document.secondDocExpirationId + "'][type$='text']"));
            }

            public static WebElement getSecondExpirationDateControlErrorElement(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("[id$='" + document.secondDocExpirationId + "-err']"));
            }

            public static String getExpirationDateError(ListADocuments document) {
                return getExpirationDateControlErrorElement(document).getText();
            }

            public static WebElement getExpirationDateNaLabel(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("label[for$='" + document.secondDocExpirationNaId + "']"));
            }

            public static String getSecondExpirationDateError(ListADocuments document) {
                return getSecondExpirationDateControlErrorElement(document).getText();
            }

            public static String getSecondDocumentNumberError(ListADocuments document) {
                return getSecondDocumentNumberErrorElement(document).getText();
            }

            public static String getSecondDocumentIssuingAuthorityError(ListADocuments document) {
                return getSecondDocumentIssuingAuthorityErrorElement(document).getText();
            }

            public static WebElement getSecondExpirationDateNaLabel(ListADocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("label[for$='" + document.secondDocExpirationNaId + "']"));
            }

            public static void setSecondDocumentIssuingAuthority(ListADocuments document,
                                                                 String issuingAuthority) {
                WebElement issuingAuthorityElement = getSecondDocumentIssuingAuthorityElement(document);
                switch (issuingAuthorityElement.getTagName().toLowerCase()) {
                    case "input":
                        SeleniumTest.clearAndSetText(issuingAuthorityElement, issuingAuthority);
                        break;
                    case "select":
                        SeleniumTest.selectByVisibleTextFromDropDown(issuingAuthorityElement, issuingAuthority);
                        break;
                    default:
                        throw new RuntimeException("Unable to determine the type of element -"
                                + " could not set issuing authority value");
                }
                staticLogger.info("Second Issuing Authority set to {}", issuingAuthority);
            }

            public static void setSecondDocumentExpirationDate(ListADocuments document, LocalDate expiration) {
                if (expiration == null) {
                    getSecondExpirationDateNaLabel(document).click();
                    // TODO Determine if the box is checked before just checking it
                } else {
                    // do all the other work
                    WebElement expirationDateControl = getSecondExpirationDateControlElement(document);
                    WebElement hiddenExpirationDateControl = Driver.getDriver().findElement(
                            By.cssSelector(
                                    "input[id$='" + document.secondDocExpirationId + "'" + "][type$='hidden']"));
                    SeleniumTest.FireFoxWorkArounds
                            .setCalendarControl_MM_Slash_dd_Slash_yyyy(expiration, expirationDateControl
                                    .getAttribute("id"), hiddenExpirationDateControl
                                    .getAttribute("id"));
                    staticLogger.info("Expiration Date set to {}", expiration.format
                            (DateTimeFormatter.ofPattern("MM/dd/yyyy")));
                }
            }

            public static void setSecondDocumentNumber(ListADocuments document, String documentNumber) {
                SeleniumTest.clearAndSetText(getSecondDocumentNumberElement(document), documentNumber);
                staticLogger.info("Second Document Number set to {}", documentNumber);
            }

            /**
             * @return String
             * @deprecated
             */
            public static String getSecondDocumentIssuingAuthority() {
                return secondDocumentIssuingAuthorityTextBox.getAttribute("value");
            }

            /**
             * @return String
             * @deprecated
             */
            public static String getSecondDocumentIssuingAuthorityError() {
                return secondDocumentIssuingAuthorityErr.getAttribute("value");
            }

            /**
             * @deprecated
             */
            public static void setSecondDocumentIssuingAuthority(String issuingAuthority) {
                SeleniumTest
                        .clearAndSetText(secondDocumentIssuingAuthorityTextBox, issuingAuthority);
                staticLogger.info("Second document Issuing Authority set to {}", issuingAuthority);
            }

            /**
             * @return String
             * @deprecated
             */
            public static String getSecondDocumentNumber() {
                return secondDocumentDocumentNumberTextBox.getAttribute("value");
            }

            /**
             * @return String
             * @deprecated
             */
            public static String getSecondDocumentNumberError() {
                return secondDocumentDocumentNumberErr.getAttribute("value");
            }

            /**
             * @deprecated
             */
            public static void setSecondDocumentNumber(String documentNumber) {
                SeleniumTest.clearAndSetText(secondDocumentDocumentNumberTextBox, documentNumber);
                staticLogger.info("Second Document Number set to {}", documentNumber);
            }

            /**
             * @deprecated
             */
            public static void setSecondDocumentExpirationDate(LocalDate date) {
                SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(date,
                        secondDocumentExpirationDateControl
                                .getAttribute(
                                        "id"),
                        hiddenSecondDocumentExpirationDateControl
                                .getAttribute(
                                        "id"));
                staticLogger.info("Second document expiration date set to {}", date.format
                        (DateTimeFormatter.ofPattern("MM/dd/yyyy")));
            }

            /**
             * @deprecated
             */
            public static String getSecondDocumentExpirationDateError() {
                return secondDocumentExpirationDateErr.getAttribute("value");
            }


            public static void setSecondDocumentDetails(I9 i9, String issuingAuthority, String docNumber, String expirationDate, WebElement dtExpiration) {
                Assert.assertFalse(Section2.Documents.validateDocumentNumberInputs(i9, I9.invalidDocumentNumber, txtSection2DocumentNumber, dtExpiration));
                Assert.assertTrue(Section2.Documents.validateDocumentNumberInputs(i9, I9.numericDocumentNumber, txtSection2DocumentNumber, dtExpiration));
                Assert.assertTrue(Section2.Documents.validateDocumentNumberInputs(i9, I9.alphanumericDocumentNumber, txtSection2DocumentNumber, dtExpiration));
                SeleniumTest.clearAndSetText(secondDocumentDocumentNumberTextBox, docNumber);
                SeleniumTest.clearAndSetText(secondDocumentExpirationDateControl, expirationDate);
                SeleniumTest.selectByVisibleTextFromDropDown(ddlSecondDocumentIssuingAuthority, issuingAuthority);
            }

            // endregion
        }


        public static class ListB {

            private static Pattern docNumberSuffixPattern = Pattern.compile("-I9s2_\\d+\\z");

            @FindBy(how = How.CSS, using = "select[id$='_25']")
            public static WebElement listBDocumentDropDown;

            @FindBy(how = How.CSS, using = "*[id$='_25-err']")
            public static WebElement listBDocumentDropDownErr;

            static {
                PageFactory.initElements(Driver.getDriver(), ListB.class);
            }

            public static void selectlistBDocument(ListBDocuments document) {
                SeleniumTest.selectByValueFromDropDown(listBDocumentDropDown, document.value);
                staticLogger.info("List B Document selected {}", document);
            }

            // region List B Receipt
            public static void checklistBReceipt(ListBDocuments document) {
                WebElement receiptCheckBox = Driver.getDriver()
                        .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                WebElement receiptCheckBoxLabel = Driver.getDriver()
                        .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                SeleniumTest.check(receiptCheckBoxLabel, receiptCheckBox);
                staticLogger.info("List B Receipt checked");
            }

            public static void unchecklistBReceipt(ListBDocuments document) {
                WebElement receiptCheckBox = Driver.getDriver()
                        .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                WebElement receiptCheckBoxLabel = Driver.getDriver()
                        .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                SeleniumTest.unCheck(receiptCheckBoxLabel, receiptCheckBox);
                staticLogger.info("List B Receipt unchecked");
            }

            public static String getListBDocumentError() {
                return listBDocumentDropDownErr.getText();
            }

            // endregion

            public static String getDocumentType(ListBDocuments document) {
                Select dropDown = new Select(getDocumentTypeElement(document));
                return dropDown.getFirstSelectedOption().getText();
            }

            public static String getDocumentTypeError(ListBDocuments document) {
                return getDocumentTypeErrorElement(document).getText();
            }

            // region DocumentType
            public static WebElement getDocumentTypeElement(ListBDocuments document) {
                return Driver.getDriver()
                        .findElement(By.cssSelector("select[id$='" + document.type + "']"));
            }

            public static WebElement getDocumentTypeErrorElement(ListBDocuments document) {
                return Driver.getDriver()
                        .findElement(By.cssSelector("[id$='" + document.type + "-err']"));
            }

            public static void setDocumentType(ListBDocuments document, String type) {
                SeleniumTest
                        .selectByVisibleTextFromDropDown(getDocumentTypeElement(document), type);
                staticLogger.info("Document Type set to {}", type);
            }

            // endregion

            public static String getState(ListBDocuments document) {
                Select dropDown = new Select(getStateElement(document));
                return dropDown.getFirstSelectedOption().getText();
            }

            public static String getStateError(ListBDocuments document) {
                return getStateErrorElement(document).getText();
            }

            // region State of Union
            public static WebElement getStateElement(ListBDocuments document) {
                return Driver.getDriver()
                        .findElement(By.cssSelector("select[id$='" + document.state + "']"));
            }

            public static WebElement getStateErrorElement(ListBDocuments document) {
                return Driver.getDriver()
                        .findElement(By.cssSelector("[id$='" + document.state + "-err']"));
            }

            public static void setState(ListBDocuments document, String state) {
                SeleniumTest.selectByVisibleTextFromDropDown(getStateElement(document), state);
                staticLogger.info("State set to {}", state);
            }
            // endregion

            public static String getIssuingAuthority(ListBDocuments document) {
                return getIssuingAuthorityElement(document).getText();
            }

            public static String getIssuingAuthorityError(ListBDocuments document) {
                return getIssuingAuthorityErrorElement(document).getText();
            }

            // region Issuing Authority
            public static WebElement getIssuingAuthorityElement(ListBDocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.issuingAuthorityId + "']"));
                for (WebElement element : elements) {
                    if (element.getTagName().equals("input") || element.getTagName().equals
                            ("select")) {
                        return element;
                    }
                }
                return null;
            }

            public static WebElement getIssuingAuthorityErrorElement(ListBDocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.issuingAuthorityId + "-err']"));
                if (elements.size() == 0) {
                    return null;
                }
                return elements.get(0);
            }

            public static void setIssuingAuthority(ListBDocuments document,
                                                   String issuingAuthority) {
                SeleniumTest
                        .clearAndSetText(getIssuingAuthorityElement(document), issuingAuthority);
                staticLogger.info("Issuing Authority set to {}", issuingAuthority);
            }
            // endregion

            public static String getDocumentNumber(ListBDocuments document) {
                return getDocumentNumberElement(document).getText();
            }

            public static String getDocumentNumberError(ListBDocuments document) {
                return getDocumentNumberErrorElement(document).getText();
            }

            // region Document Number
            public static WebElement getDocumentNumberElement(ListBDocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("input[id$='" + document.documentNumberId + "']"));
            }

            public static WebElement getDocumentNumberErrorElement(ListBDocuments document) {
                WebElement result = null;
                try {
                    result = Driver.getDriver().findElement(By.cssSelector("*[id$='" + document.documentNumberId + "-err']"));
                } catch (NoSuchElementException e) {
                    Matcher matcher = docNumberSuffixPattern.matcher(document.documentNumberId);
                    if (matcher.find()) {
                        String trimmedId = matcher.replaceFirst("");
                        try {
                            result = Driver.getDriver().findElement(By.cssSelector("*[id$='" + trimmedId + "-err']"));
                        } catch (NoSuchElementException e2) {
                            result = null;
                        }
                    }
                }
                return result;
            }

            public static void setDocumentNumber(ListBDocuments document, String documentNumber) {
                SeleniumTest.clearAndSetText(getDocumentNumberElement(document), documentNumber);
                staticLogger.info("Document number set to {}", documentNumber);
            }
            // endregion

            // region document Associated Value

            public static String getAssociatedDocument(ListBDocuments document) {
                try {

                    WebElement associatedDocument = getAssociatedDocumentElement(document);
                    switch (associatedDocument.getTagName().toLowerCase()) {
                        case "input":
                            return associatedDocument.getText();
                        case "select":
                            Select dropDown = new Select(associatedDocument);
                            return dropDown.getFirstSelectedOption().getText();
                        default:
                            return "";
                    }
                } catch (NoSuchElementException nse) {
                    return "";
                }
            }

            public static WebElement getAssociatedDocumentElement(ListBDocuments document) {
                return Driver.getDriver().findElement(
                        By.xpath("//*[contains(@id, '" + document.associatedDocumentValue + "')]"));
            }

            public static void setOrSelectAssociatedDocument(ListBDocuments document,
                                                             String value) {
                try {
                    WebElement associatedDocument = getAssociatedDocumentElement(document);
                    switch (associatedDocument.getTagName().toLowerCase()) {
                        case "input":
                            SeleniumTest.clearAndSetText(associatedDocument, value);
                            break;
                        case "select":
                            SeleniumTest.selectByVisibleTextFromDropDown(associatedDocument, value);
                            break;
                        default:
                            throw new RuntimeException("Unable to determine the type of element -"
                                    + " could not set document value");
                    }
                    staticLogger.info("Set Associated Document to {}", value);

                } catch (NoSuchElementException nse) {
                    throw new RuntimeException("Unable to determine the type of element - could "
                            + "not set document value");
                }
            }
            // endregion

            // region Set Expiration Date Control

            public static void setExpirationDate(ListBDocuments document, LocalDate expiration) {
                WebElement expirationDateControl = getExpirationDateControlElement(document);
                WebElement hiddenExpirationDateControl = Driver.getDriver().findElement(
                        By.cssSelector(
                                "input[id$='" + document.expirationId + "'" + "][type$='hidden']"));
                SeleniumTest.FireFoxWorkArounds
                        .setCalendarControl_MM_Slash_dd_Slash_yyyy(expiration, expirationDateControl
                                .getAttribute("id"), hiddenExpirationDateControl
                                .getAttribute("id"));
                staticLogger.info("Expiration Date set to {}", expiration.format
                        (DateTimeFormatter.ofPattern("MM/dd/yyyy")));
            }


            public static void setExpirationDateNa(ListBDocuments document) {
                WebElement expirationDateNaControl = getExpirationDateNaLabel(document);
                expirationDateNaControl.click();
            }

            public static String getExpirationDateError(ListBDocuments document) {
                return getExpirationDateErrorElement(document).getText();
            }

            public static WebElement getExpirationDateControlElement(ListBDocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("input[id$='" + document.expirationId + "'][type$='text']"));
            }

            public static WebElement getExpirationDateErrorElement(ListBDocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("[id$='" + document.expirationId + "-err']"));
            }

            public static WebElement getExpirationDateNaLabel(ListBDocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("label[for$='" + document.expirationNaId + "']"));
            }

            // endregion

        }


        public static class ListC {

            @FindBy(how = How.CSS, using = "select[id$='_26']")
            public static WebElement listCDocumentDropDown;

            @FindBy(how = How.CSS, using = "*[id$='_26-err']")
            public static WebElement listCDocumentDropDownErr;

            @FindBy(how = How.CSS, using = "select[id$='_77']")
            public static WebElement listEmploymentAuthDocType;


            static {
                PageFactory.initElements(Driver.getDriver(), ListC.class);
            }

            public static void selectListCDocument(ListCDocuments document) {
                SeleniumTest.selectByValueFromDropDown(listCDocumentDropDown, document.value);
                staticLogger.info("List C Document selected {}", document);
            }

            public static void selectlistEmploymentAuthDocType(ListCDocuments document) {
                SeleniumTest.selectByValueFromDropDown(listEmploymentAuthDocType, document.value);
                staticLogger.info("Employment Auth Doc Type selected {}", document);
            }

            // region List C Receipt
            public static void checkListCReceipt(ListCDocuments document) {
                WebElement receiptCheckBox = Driver.getDriver()
                        .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                WebElement receiptCheckBoxLabel = Driver.getDriver()
                        .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                SeleniumTest.check(receiptCheckBoxLabel, receiptCheckBox);
                staticLogger.info("List C Receipt checked");
            }

            public static void uncheckListCReceipt(ListCDocuments document) {
                WebElement receiptCheckBox = Driver.getDriver()
                        .findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));

                WebElement receiptCheckBoxLabel = Driver.getDriver()
                        .findElement(By.cssSelector("label[for$='" + document.receiptId + "']"));

                SeleniumTest.unCheck(receiptCheckBoxLabel, receiptCheckBox);
                staticLogger.info("List C Receipt unchecked");
            }

            public static String getListCDocumentError() {
                return listCDocumentDropDownErr.getText();
            }

            // endregion

            public static String getIssuingAuthority(ListCDocuments document) {
                return getIssuingAuthorityElement(document).getText();
            }

            public static String getIssuingAuthorityError(ListCDocuments document) {
                return getIssuingAuthorityErrorElement(document).getText();
            }

            // region Issuing Authority
            public static WebElement getIssuingAuthorityElement(ListCDocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.issuingAuthorityId + "']"));
                for (WebElement element : elements) {
                    if (element.getTagName().equals("input") || element.getTagName().equals
                            ("select")) {
                        return element;
                    }
                }
                return null;
            }

            public static WebElement getIssuingAuthorityErrorElement(ListCDocuments document) {
                // must find the right element type input or select before returning.
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.issuingAuthorityId + "-err']"));
                if (elements.size() == 0) {
                    return null;
                }
                return elements.get(0);
            }

            public static void setIssuingAuthority(ListCDocuments document,
                                                   String issuingAuthority) {
                WebElement issuingAuthorityElement = getIssuingAuthorityElement(document);
                switch (issuingAuthorityElement.getTagName()) {
                    case "input":
                        if (issuingAuthorityElement.getAttribute("readonly") == null) {
                            SeleniumTest
                                    .clearAndSetText(issuingAuthorityElement, issuingAuthority);
                        }
                        break;
                    case "select":
                        SeleniumTest
                                .selectByVisibleTextFromDropDown(
                                        issuingAuthorityElement, issuingAuthority);
                        break;
                }
                staticLogger.info("Issuing Authority set to {}", issuingAuthority);
            }
            // endregion

            public static String getDocumentNumber(ListCDocuments document) {
                return getDocumentNumberElement(document).getText();
            }

            public static String getDocumentNumberError(ListCDocuments document) {
                return getDocumentNumberErrorElement(document).getText();
            }

            // region Document Number
            public static WebElement getDocumentNumberElement(ListCDocuments document) {
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.documentNumberId + "']"));
                for (WebElement element : elements) {
                    if (element.getTagName().equals("input") ||
                            element.getTagName().equals("span")) {
                        return element;
                    }
                }
                return null;
            }

            public static WebElement getDocumentNumberErrorElement(ListCDocuments document) {
                List<WebElement> elements = Driver.getDriver().findElements(
                        By.cssSelector("*[id$='" + document.documentNumberId + "-err']"));
                if (elements.size() == 0) {
                    return null;
                }
                return elements.get(0);
            }

            public static void setDocumentNumber(ListCDocuments document, String documentNumber) {
                WebElement documentElement = getDocumentNumberElement(document);
                switch (documentElement.getTagName()) {
                    case "input":
                        SeleniumTest.clearAndSetText(documentElement, documentNumber);
                        staticLogger.info("Document Number set to {}", documentNumber);
                        break;

                    case "span":
                        staticLogger.info("Document Number is read only");
                        break;
                }
            }
            // endregion

            // region Set Expiration Date Control

            public static void setExpirationDate(ListCDocuments document, LocalDate expiration) {
                if (expiration == null) {
                    staticLogger.info("Expiration to set is null, nothing changed");
                    return;
                }
                WebElement expirationDateControl = getExpirationDateControlElement(document);
                WebElement hiddenExpirationDateControl = Driver.getDriver().findElement(
                        By.cssSelector(
                                "input[id$='" + document.expirationId + "'" + "][type$='hidden']"));
                SeleniumTest.FireFoxWorkArounds
                        .setCalendarControl_MM_Slash_dd_Slash_yyyy(expiration, expirationDateControl
                                .getAttribute("id"), hiddenExpirationDateControl
                                .getAttribute("id"));
                staticLogger.info("Expiration Date set to {}", expiration.format
                        (DateTimeFormatter.ofPattern("MM/dd/yyyy")));
            }

            public static void setExpirationDateNa(ListCDocuments document) {
                WebElement expirationDateNaControl = getExpirationDateNaLabel(document);
                expirationDateNaControl.click();
            }

            public static WebElement getExpirationDateControlElement(ListCDocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("input[id$='" + document.expirationId + "'][type$='text']"));
            }

            public static WebElement getExpirationDateErrorElement(ListCDocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("[id$='" + document.expirationId + "-err']"));
            }

            public static String getExpirationDateError(ListCDocuments document) {
                return getExpirationDateErrorElement(document).getText();
            }

            public static WebElement getExpirationDateNaLabel(ListCDocuments document) {
                return Driver.getDriver().findElement(
                        By.cssSelector("label[for$='" + document.expirationNaId + "']"));
            }

            // endregion

        }
    }

    // Helper functions to simplify filling in portions of section 2

    public static void selectDocumentList(String list) {

        if (list.equalsIgnoreCase("A")) {
            Sites.CandidatePortal.Forms.Objects.I9.Section2.EmployerReview.chooseListA();
        } else if (list.equalsIgnoreCase("BC")) {
            Sites.CandidatePortal.Forms.Objects.I9.Section2.EmployerReview.chooseListBAndC();
        }
    }

    public static void populateDocument(ListAEligibilityDocument document) {

        // Populate primary list A document
        Documents.ListA.selectListADocument(document.getListADocument());
        /*if (document.isReceipt()) {
            Documents.ListA.checkListAReceipt(document.getListADocument());
        } else {
            Documents.ListA.uncheckListAReceipt(document.getListADocument());
        }*/
        Documents.ListA.setIssuingAuthority(document.getListADocument(), document.getIssuingAuthority());
        Documents.ListA.setDocumentNumber(document.getListADocument(), document.getDocumentNumber());
        Documents.ListA.setExpirationDate(document.getListADocument(), document.getExpirationDate());

        // Populate second list A document if required
        if (!document.getAssociatedDocumentValue().isEmpty()) {
            Documents.ListA.setOrSelectAssociatedDocument(document.getListADocument(),
                    document.getAssociatedDocumentValue());
            Documents.ListA.setIssuingAuthority(document.getListADocument(), document.getSecondIssuingAuthority());
            Documents.ListA.setSecondDocumentNumber(document.getListADocument(), document.getSecondDocumentNumber());
            Documents.ListA.setSecondDocumentExpirationDate(document.getListADocument(),
                    document.getSecondDocumentExpiration());
        }

        // TODO ONB-916 Populate third document if required and present
    }

    public static void populateDocument(ListBEligibilityDocument document) {

        Documents.ListB.selectlistBDocument(document.getListBDocument());
        if (document.isReceipt()) {
            Documents.ListB.checklistBReceipt(document.getListBDocument());
        } else {
            Documents.ListB.unchecklistBReceipt(document.getListBDocument());
        }
        if (!document.getStateOfUnion().isEmpty()) {
            Documents.ListB.setState(document.getListBDocument(), document.getStateOfUnion());
        } else {
            Documents.ListB.setIssuingAuthority(document.getListBDocument(), document.getIssuingAuthority());
        }
        Documents.ListB.setDocumentNumber(document.getListBDocument(), document.getDocumentNumber());
        Documents.ListB.setExpirationDate(document.getListBDocument(), document.getExpirationDate());
    }

    public static void populateDocument(ListCEligibilityDocument document) {

        Documents.ListC.selectListCDocument(document.getListCDocument());
        Documents.ListC.selectlistEmploymentAuthDocType(document.getDocumentType());
        if (document.isReceipt()) {
            Documents.ListC.checkListCReceipt(document.getListCDocument());
        } else {
            Documents.ListC.uncheckListCReceipt(document.getListCDocument());
        }
        Documents.ListC.setIssuingAuthority(document.getListCDocument(), document.getIssuingAuthority());
        Documents.ListC.setDocumentNumber(document.getListCDocument(), document.getDocumentNumber());
        Documents.ListC.setExpirationDate(document.getListCDocument(), document.getExpirationDate());
    }

    public static void populateAdditionalInformation(String infoText) {

        if (infoText != null && !infoText.isEmpty()) {
            AdditionalInformation.setAdditionalInformation(infoText);
        } else {
            AdditionalInformation.setAdditionalInformation("");
        }
    }

    public static void populateEmployerCertification(LocalDate firstDayOfEmployment, BusinessEntity company,
                                                     boolean acknowledged) {

        // Fill in start date of employement, set to today if null
        if (firstDayOfEmployment == null) {
            firstDayOfEmployment = LocalDate.now();
        }
        Certification.setStartDate(firstDayOfEmployment);

        // Populate company information
        Certification.setAuthorizedRepresentative(company.getTitle());
        Certification.setBusinessName(company.getName());
        Certification.setAddressLine1(company.getAddressLine1());
        Certification.setCity(company.getCity());
        Certification.selectCountryOrRegion(company.getCountryOrRegion());
        SeleniumTest.waitMs(2000);
        Certification.selectStateOrProvince(company.getStateOrProvince());
        SeleniumTest.waitMs(2000);
        Certification.setZipCode(company.getZipCode());
    }

    public static void uploadDocumentFile(String documentFileName) {

        UploadDocuments.setFileToUpload(documentFileName);
        UploadDocuments.clickUploadFile();
    }

    public static void acknowledge(boolean acknowledged) {

        // Check or uncheck the acknowledgement checkbox as requested
        if (acknowledged) {
            Acknowledgement.checkIAcknowledge();
        } else {
            Acknowledgement.uncheckIAcknowledge();
        }
    }
}
