package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/18/2015.
 */
public class FormID8913FormI9Section1 extends FormPage {
    @FindBy(how = How.ID, using = "returnbtn")
    private WebElement returnButton;

    @FindBy(how = How.ID, using = "8913-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * Clicks Return Button
     * @return
     */
    public ReturnWidgetPage clickReturn() {
        returnButton.click();
        return PageFactory.initElements(Driver.getDriver(), ReturnWidgetPage.class);
    }

    /**
     * Clicks Next Button
     * @return
     */
    public FormID8470I9CompliancePage clickNext() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID8470I9CompliancePage.class);
    }
}
