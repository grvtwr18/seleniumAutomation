package Sites.CandidatePortal.Forms.tax.state.arizona;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.tax.state.CommonFunctions;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_1778 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_6']")
    public WebElement withholdingLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_6_1']")
    private WebElement withholdFromGrossTaxableRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_8']")
    private WebElement chkWithholdFromGrossTaxable;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_6_2']")
    private WebElement withholdingPercentageOfZeroRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9']")
    public WebElement conditionalCheckOnlyOnePercentageLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9_0.8%']")
    public WebElement pointEightPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9_1.3%']")
    private WebElement onePointThreePercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9_1.8%']")
    private WebElement onePointEightPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9_2.7%']")
    private WebElement twoPointSevenPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9_3.6%']")
    private WebElement threePointSixPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9_4.2%']")
    private WebElement fourPointTwoPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_9_5.1%']")
    private WebElement fivePointOnePercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_11']")
    private WebElement additionalWithholdingCheckboxLabel;

    @FindBy(how = How.ID, using = "1778-1778_11")
    private WebElement additionalWithholdingCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_13']")
    public WebElement additionalWithholdingAmountLabel;

    @FindBy(how = How.ID, using = "1778-1778_13")
    private WebElement additionalWithholdingAmountInput;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_23']")
    private WebElement iUnderstandCheckboxLabel;

    @FindBy(how = How.ID, using = "1778-1778_23")
    private WebElement iUnderstandCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_18']")
    public WebElement iCertifyLabel;

    @FindBy(how = How.ID, using = "1778-1778_18")
    private WebElement iCertifyCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_25']")
    public WebElement residencyStatementLabel;

    @FindBy(how = How.ID, using = "1778-1778_25")
    private WebElement residencyStatementDropdown;

    @FindBy(how = How.XPATH, using = "//label[@for='1778-1778_26']")
    public WebElement employmentStatementLabel;

    @FindBy(how = How.ID, using = "1778-1778_26")
    private WebElement employmentStatementDropdown;


    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_1778() {

    }

    public static Form_1778 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_1778.class);
    }


    public Form_1778 choosePointEightPercentRadiobutton() {
        SeleniumTest.click(pointEightPercentRadiobutton);
        logger.info(".8% Radio Button Chosen");
        return this;
    }

    public Form_1778 chooseOnePointThreePercentRadiobutton() {
        SeleniumTest.click(onePointThreePercentRadiobutton);
        logger.info("1.3% Radio Button Chosen");
        return this;
    }

    public Form_1778 chooseOnePointEightPercentRadiobutton() {
        SeleniumTest.click(onePointEightPercentRadiobutton);
        logger.info("1.8% Radio Button Chosen");
        return this;
    }

    public Form_1778 chooseTwoPointSevenPercentRadiobutton() {
        SeleniumTest.click(twoPointSevenPercentRadiobutton);
        logger.info("2.7% Radio Button Chosen");
        return this;
    }

    public Form_1778 chooseThreePointSixPercentRadiobutton() {
        SeleniumTest.click(threePointSixPercentRadiobutton);
        logger.info("3.6% Radio Button Chosen");
        return this;
    }

    public Form_1778 chooseFourPointTwoPercentRadiobutton() {
        SeleniumTest.click(fourPointTwoPercentRadiobutton);
        logger.info("4.2% Radio Button Chosen");
        return this;
    }

    public Form_1778 chooseFivePointOnePercentRadiobutton() {
        SeleniumTest.click(fivePointOnePercentRadiobutton);
        logger.info("5.1% Radio Button Chosen");
        return this;
    }

    public Form_1778 checkAdditionalWithholding() {
        SeleniumTest.check(additionalWithholdingCheckboxLabel, additionalWithholdingCheckbox);
        logger.info("Additional Withholding Checked");
        return this;
    }

    public Form_1778 uncheckAdditionalWithholding() {
        SeleniumTest.unCheck(additionalWithholdingCheckboxLabel, additionalWithholdingCheckboxLabel);
        logger.info("Additional Withholding unchecked");
        return this;
    }

    public String getAdditionalWithholdingAmount() {
        return additionalWithholdingAmountInput.getText();
    }

    public Form_1778 setAdditionalWithholdingAmount(String amount) {
        SeleniumTest.clearAndSetText(additionalWithholdingAmountInput, amount);
        logger.info("Additional Withholding set to {}", amount);
        return this;
    }

    public Form_1778 checkICertify() {
        SeleniumTest.check(iCertifyLabel, iCertifyCheckbox);
        logger.info("I Certify Checked");
        return this;
    }

    public Form_1778 uncheckICertify() {
        SeleniumTest.unCheck(iCertifyLabel, iCertifyCheckbox);
        logger.info("I Certify Checked");
        return this;
    }

    public String getResidencyStatement() {
        Select dropdown = new Select(residencyStatementDropdown);
        return dropdown.getFirstSelectedOption().getText();
    }

    public Form_1778 selectResidencyStatement(String residencyStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropdown, residencyStatement);
        logger.info("Withholding Status Selected {}", residencyStatement);
        return this;
  }

    public String getEmploymentStatement() {
        Select dropdown = new Select(employmentStatementDropdown);
        return dropdown.getFirstSelectedOption().getText();
    }

    public Form_1778 selectEmploymentStatementDropdown(String employmentStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(employmentStatementDropdown, employmentStatement);
        logger.info("Withholding Status Selected {}", employmentStatement);
        return this;
    }

    public Form_1778 chooseWithholdFromGrossTaxable() {
        chkWithholdFromGrossTaxable.click();
        logger.info("Withhold from gross taxable income chosen");
        return this;
    }

    public Form_1778 chooseWithholdingPercentageOfZero() {
        withholdingPercentageOfZeroRadiobutton.click();
        logger.info("Withholding of Zero Chosen");
        return this;
    }

    public Form_1778 checkIUnderstand() {
        SeleniumTest.check(iUnderstandCheckboxLabel, iUnderstandCheckbox);
        logger.info("I Understand Checked");
        return this;
    }

    public Form_1778 uncheckIUnderstand() {
        SeleniumTest.unCheck(iUnderstandCheckboxLabel, iUnderstandCheckbox);
        logger.info("I Understand Unchecked");
        return this;
    }

    public void fillRequiredFields(CommonFunctions.Withholding withholdingType, String amount) {
        switch(withholdingType) {
            case GROSS:
                this.chooseWithholdFromGrossTaxable();
                this.chooseTwoPointSevenPercentRadiobutton();
                this.checkAdditionalWithholding();
                this.setAdditionalWithholdingAmount(amount);
                break;
            case ZERO:
                this.checkIUnderstand();
                break;
        }
        this.checkICertify();
    }

}

