package Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management;

import Data.locations.us.UsStateTerritory;
import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_16496_EmergencyContact extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "16496-16496_2")
    private WebElement lastNameTextbox;

    @FindBy(how = How.ID, using = "16496-16496_3")
    private WebElement firstNameTextbox;

    @FindBy(how = How.ID, using = "16496-16496_5")
    private WebElement middleNameTextbox;

    @FindBy(how = How.ID, using = "16496-16496_7")
    private WebElement addressLine1Textbox;

    @FindBy(how = How.ID, using = "16496-address16496_10-16496_11")
    private WebElement cityTextBox;

    @FindBy(how = How.ID, using = "16496-address16496_10-16496_10")
    private WebElement countryDropdown;

    @FindBy(how = How.ID, using = "16496-address16496_10-16496_12")
    private WebElement stateDropdown;

    @FindBy(how = How.ID, using = "16496-address16496_10-16496_13")
    private WebElement zipTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16496-16496_15_Home']")
    private WebElement homeRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16496-16496_15_Cell']")
    private WebElement cellRadiobutton;

    @FindBy(how = How.ID, using = "16496-16496_16")
    private WebElement areaCodeTextbox;

    @FindBy(how = How.ID, using = "16496-16496_17")
    private WebElement phoneNumberTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16496-16496_20_Home']")
    private WebElement home2Radiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='16496-16496_20_Cell']")
    private WebElement cell2Radiobutton;

    @FindBy(how = How.ID, using = "16496-16496_22")
    private WebElement areaCodeTextbox2;

    @FindBy(how = How.ID, using = "16496-16496_23")
    private WebElement phoneNumberTextbox2;

    @FindBy(how = How.XPATH, using = "//label[@for='16496-16496_51_No']")
    private WebElement noRadiobutton;

    @FindBy(how = How.ID, using = "16496-16496_49")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='16496-16496_49']")
    private WebElement iAckowledgeLabel;

    protected Logger logger = LoggerFactory.getLogger(Form_16496_EmergencyContact.class);

    public static Form_16496_EmergencyContact getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_16496_EmergencyContact.class);
    }
    public String getLastName() {
        return lastNameTextbox.getText();
    }

    public Form_16496_EmergencyContact setLastName(String lastName) {
        SeleniumTest.clearAndSetText(lastNameTextbox, lastName);
        logger.info("Last name set to {}", lastName);
        return this;
    }

    public String getFirstName() {
        return firstNameTextbox.getText();
    }

    public Form_16496_EmergencyContact setFirstName(String firstName) {
        SeleniumTest.clearAndSetText(firstNameTextbox,firstName);
        logger.info("First name set to {}", firstName);
        return this;
    }

    public String getMiddleName() {
        return middleNameTextbox.getText();
    }

    public Form_16496_EmergencyContact setMiddleName(String middleName) {
        SeleniumTest.clearAndSetText(middleNameTextbox, middleName);
        logger.info("Middle name set to {}", middleName);
        return this;
    }

    public String getAddressLine1() {
        return addressLine1Textbox.getText();
    }

    public Form_16496_EmergencyContact setAddressLine1(String addressLine1) {
        SeleniumTest.clearAndSetText(addressLine1Textbox, addressLine1);
        logger.info("Address line 1 is set to {}", addressLine1);
        return this;
    }

    public Form_16496_EmergencyContact setCity(String city) {
        SeleniumTest.clearAndSetText(cityTextBox, city);
        logger.info("City set to {}", city);
        return this;
    }

    public Form_16496_EmergencyContact selectCountry(String country) {
        Select dropdown = new Select(countryDropdown);
        dropdown.selectByVisibleText(country);
        logger.info("Country set to {}", country);
        return this;
    }

    public UsStateTerritory getState() {
        Select dropdown = new Select(stateDropdown);
        return UsStateTerritory.parse(dropdown.getFirstSelectedOption().getText());
    }

    public Form_16496_EmergencyContact selectState(UsStateTerritory state) {
        Select dropdown = new Select(stateDropdown);
        dropdown.selectByVisibleText(state.getFullName());
        logger.info("State set to {}", state.getFullName());
        return this;
    }

    public String getZip() {
        return zipTextbox.getText();
    }

    public Form_16496_EmergencyContact setZip(String zip) {
        SeleniumTest.clearAndSetText(zipTextbox, zip);
        logger.info("Zip set to {}", zip);
        return this;
    }

    public Form_16496_EmergencyContact chooseHome() {
        homeRadiobutton.click();
        logger.info("Home Radio Button Chosen");
        return this;
    }

    public Form_16496_EmergencyContact chooseCell() {
        cellRadiobutton.click();
        logger.info("Phone 1 Cell Chosen");
        return this;
    }

    public String getAreaCode() {
        return areaCodeTextbox.getText();
    }

    public Form_16496_EmergencyContact setAreaCode(String areaCode) {
        SeleniumTest.clearAndSetText(areaCodeTextbox, areaCode);
        logger.info("Area Code set to {}", areaCode);
        return this;
    }

    public String getPhoneNumber() {
        return phoneNumberTextbox.getText();
    }

    public Form_16496_EmergencyContact setPhoneNumber(String phone) {
        SeleniumTest.clearAndSetText(phoneNumberTextbox, phone);
        logger.info("Phone number set to {}", phone);
        return this;
    }

    public String getAreaCode2() {
        return areaCodeTextbox2.getText();
    }

    public Form_16496_EmergencyContact setAreaCode2(String areaCode2) {
        SeleniumTest.clearAndSetText(areaCodeTextbox2, areaCode2);
        logger.info("Area Code set to {}", areaCode2);
        return this;
    }

    public String getPhoneNumber2() {
        return phoneNumberTextbox2.getText();
    }

    public Form_16496_EmergencyContact setPhoneNumber2(String phone2) {
        SeleniumTest.clearAndSetText(phoneNumberTextbox2, phone2);
        logger.info("Phone number set to {}", phone2);
        return this;
    }

    public Form_16496_EmergencyContact chooseHome2() {
        home2Radiobutton.click();
        logger.info("Home 2 Radio Button Chosen");
        return this;
    }

    public Form_16496_EmergencyContact chooseCell2() {
        cell2Radiobutton.click();
        logger.info("Cell 2 Radio Button Chosen");
        return this;
    }

    public Form_16496_EmergencyContact chooseNo() {
        noRadiobutton.click();
        logger.info("No Radio Button Chosen");
        return this;
    }

    public Form_16496_EmergencyContact checkIAcknowledge() {
        SeleniumTest.check(iAckowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_16496_EmergencyContact uncheckIAcknowledge() {
        SeleniumTest.unCheck(iAckowledgeLabel, iAcknowledgeCheckbox);
        logger.info("I Acknowledge unchecked");
        return this;
    }
}
