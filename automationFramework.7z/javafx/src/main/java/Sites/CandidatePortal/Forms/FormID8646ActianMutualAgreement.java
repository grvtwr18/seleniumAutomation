package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by abrackett on 1/20/2016.
 */
public class FormID8646ActianMutualAgreement extends FormPage {
    private By dateSignedLocator = By.xpath("//div[contains(@class,'dateSigned']/div/span");

    @FindBy(how = How.XPATH, using = "//label[@for='8646-8646_6']")
    private WebElement signHereCheckbox;

    @FindBy(how = How.ID, using = "8646-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "8646-8646_3")
    private WebElement employeePrintedName;

    @FindBy(how = How.ID, using = "8646-8646_10")
    private WebElement actianCorporationPrintedName;

    @FindBy(how = How.ID, using = "8646-8646_11")
    private WebElement actianCorporationTitle;

    @FindBy(how = How.XPATH, using = "//label[@for='8646-8646_8']")
    private WebElement actianCorporationSignHereCheckbox;

    /**
     * sets Actian Corporation Printed Name
     * @param printedName
     * @return
     */
    public FormID8646ActianMutualAgreement setActianCorporationPrintedName(String printedName) {
        SeleniumTest.clearAndSetText(actianCorporationPrintedName, "Actian Corporation Printed Name");
        return this;
    }

    /**
     * sets Actian Corporation Title
     * @param title
     * @return
     */
    public FormID8646ActianMutualAgreement setActianCorporationTitle(String title) {
        SeleniumTest.clearAndSetText(actianCorporationTitle, "Actian Corporation Title");
        return this;
    }

    /**
     * checks Actian Corporation Sign Here Checkbox
     * @return
     */
    public FormID8646ActianMutualAgreement checkActianCorporationSignHere() {
        if(!Driver.getDriver().findElement(By.id("8646-8646_8")).isSelected())
            actianCorporationSignHereCheckbox.click();
        return this;
    }

    /**
     * Checks Sign Here
     * @return
     */
    public FormID8646ActianMutualAgreement checkSignHere() {
        if(!Driver.getDriver().findElement(By.id("8646-8646_6")).isSelected())
            signHereCheckbox.click();
        return this;
    }

    /**
     * clicks next button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Gets date Signed value
     * @param index 0 based index of date signed to look for
     * @return
     */
    public String getDateSigned(Integer index) {
        try {
            List<WebElement> elements = Driver.getDriver().findElements(dateSignedLocator);
            if(elements.size() > index)
                return elements.get(index).getText();
            else
                return "";
        }
        catch(NoSuchElementException nse) {
            return "";
        }
    }

    /**
     * Gets the Employee Signature
     * @return
     */
    public String getEmployeePrintedName() {
        return employeePrintedName.getText();
    }

}
