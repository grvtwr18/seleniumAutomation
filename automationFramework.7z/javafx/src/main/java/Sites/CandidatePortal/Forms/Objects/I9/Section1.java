package Sites.CandidatePortal.Forms.Objects.I9;

import Data.locations.us.UsStateTerritory;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import static WebDriver.Driver.getDriver;
import Workflows.Candidate;
import Workflows.CoreI9.CitizenshipStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Created by abrackett on 10/14/16.
 */
public class Section1 extends I9Base {

    @FindBy(how = How.CSS, using = "#breadCrumbs > a")
    private static WebElement myDashboardLink;

    static {
        PageFactory.initElements(Driver.getDriver(), Section1.class);
    }

    public static void clickMyDashboardLink() {
        myDashboardLink.click();
    }

    protected static final Logger staticLogger = LoggerFactory.getLogger(Section1.class);

    public static class Section1Intro {

        static {
            PageFactory.initElements(Driver.getDriver(), Section1Intro.class);
        }

        @FindBy(how = How.ID, using = "completeSection1")
        private static WebElement completeSection1Intro;

        public static String getSection1Summary() {
            return completeSection1Intro.getText();
        }

        @FindBy(how = How.PARTIAL_LINK_TEXT, using = "asset.php?Name=Form_I-9_English.pdf")
        public static WebElement i9EnglishPDF;

        @FindBy(how = How.PARTIAL_LINK_TEXT, using = "asset.php?Name=Form_I-9_Spanish.pdf")
        public static WebElement i9SpanishPDF;

        @FindBy(how = How.ID, using = "readinstructions")
        private static WebElement instructions;

        public static String getInstructions() {
            return instructions.getText();
        }

        @FindBy(how = How.ID, using = "antiDiscrimination")
        private static WebElement antiDiscriminationNotice;

        public static String getAntiDiscriminationNotice() {
            return antiDiscriminationNotice.getText();
        }

    }

    public static class EmployeeInfo {

        public static class Name {

            static {
                PageFactory.initElements(Driver.getDriver(), Name.class);
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_1']")
            public static WebElement firstNameTextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_1']")
            public static WebElement firstNameSpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_1-err']")
            public static WebElement firstNameError;

            /**
             * Gets the first name from the form
             * @param previewPage Boolean is a preview Page
             * @return
             */
            public static String getFirstName(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return firstNameSpan.getText();
                }
                return firstNameTextBox.getText();

            }

            public static void setFirstName(String firstName) {
                SeleniumTest.clearAndSetText(firstNameTextBox, firstName);
                staticLogger.info("First Name set to {}", firstName);
            }

            public static String getFirstNameError() {
                return firstNameError.getText();
            }

            public static class MiddleName {

                static {
                    PageFactory.initElements(getDriver(), MiddleName.class);
                }

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_3_1']")
                public static WebElement middleNameTextBox;

                @FindBy(how = How.CSS, using = "span[id$='-I9s1_3']")
                public static WebElement middleNameSpan;

                @FindBy(how = How.CSS, using = "label[for$='-I9s1_3NA']")
                private static WebElement middleNameCheckBoxLabel;

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_3NA']")
                private static WebElement middleNameCheckBox;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_3_1-err']")
                private static WebElement middleNameErr;

                /**
                 * Gets the middle name from the form
                 * @param previewPage Boolean is this a preview page
                 * @return
                 */
                public static String getMiddleName(Boolean... previewPage) {
                    if(previewPage.length > 0 ? previewPage[0] : false) {
                        return middleNameSpan.getText();
                    }
                    return middleNameTextBox.getText();
                }

                public static void setMiddleName(String middleName) {
                    if(middleName.isEmpty()) {
                        checkNoMiddleName();
                    } else {
                        SeleniumTest.unCheck(middleNameCheckBoxLabel, middleNameCheckBox);
                        SeleniumTest.clearAndSetText(middleNameTextBox, middleName, true);
                    }
                    staticLogger.info("Middle Name set to {}", middleName);
                }

                public static String getMiddleNameError()
                {
                    return middleNameErr.getText();
                }

                public static void checkNoMiddleName() {
                    SeleniumTest.check(middleNameCheckBoxLabel, middleNameCheckBox);
                }

                public static void uncheckNoMiddleNameCheckBox() {
                    SeleniumTest.unCheck(middleNameCheckBoxLabel, middleNameCheckBox);
                }

            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_2']")
            public static WebElement lastNameTextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_2']")
            public static WebElement lastNameSpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_2-err']")
            public static WebElement lastNameErr;

            /**
             * Gets the last name from the form
             * @param previewPage Boolean if you are on the preview page
             * @return
             */
            public static String getLastName(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return lastNameSpan.getText();
                }
                return lastNameTextBox.getText();
            }

            public static void setLastName(String lastName) {
                SeleniumTest.clearAndSetText(lastNameTextBox, lastName, true);
                staticLogger.info("Last Name set to {}", lastName);
            }

            public static String getLastNameError() {
                return lastNameErr.getText();
            }

            public static class AlternateNames {

                static {
                    PageFactory.initElements(getDriver(), AlternateNames.class);
                }

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_4_1']")
                public static WebElement AKAsUsedTextBox;

                @FindBy(how = How.CSS, using = "span[id$='-I9s1_4']")
                public static WebElement AKAsUsedSpan;

                @FindBy(how = How.CSS, using = "label[for$='-I9s1_4NA']")
                private static WebElement noAKAsLabel;

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_4NA']")
                private static WebElement noAKAsCheckBox;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_4-err']")
                private static WebElement noAKAsErr;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_4_1-err']")
                private static WebElement threeStepNoAKAsErr;

                public static String getAKAsError() {
                    return noAKAsErr.getText();
                }

                public static String getAlternateNamesUsed(Boolean... previewPage) {
                    if(previewPage.length > 0 ? previewPage[0] : false) {
                        return AKAsUsedSpan.getText();
                    }
                    return AKAsUsedTextBox.getText();
                }

                public static void setAlternateNamesUsed(String alternateNames) {
                    if(alternateNames.isEmpty()) {
                        checkNoOtherNames();
                    } else {
                        SeleniumTest.unCheck(noAKAsLabel, noAKAsCheckBox);
                        SeleniumTest.clearAndSetText(AKAsUsedTextBox, alternateNames, true);
                    }
                    staticLogger.info("Alternate Names Used set to {}", alternateNames);
                }

                public static void checkNoOtherNames() {
                    SeleniumTest.check(noAKAsLabel, noAKAsCheckBox);
                    staticLogger.info("No Other Names checked");
                }

                public static String getAlternateNamesError() {
                    return lastNameErr.getText();
                }

                public static String getThreeStepAlternateNamesError() {
                    return threeStepNoAKAsErr.getText();
                }

                public static void uncheckNoAlternateNamesCheckBox() {
                    SeleniumTest.unCheck(noAKAsLabel, noAKAsCheckBox);
                }
            }
        }

        public static class SocialSecurityNumber {

            static {
                PageFactory.initElements(Driver.getDriver(), SocialSecurityNumber.class);
            }


            @FindBy(how = How.CSS, using = "label[for$='-I9s1_11']")
            public static WebElement socialSecurityLabel;

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_11']")
            public static WebElement socialSecurityTextBox;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_11-err']")
            private static WebElement socialSecurityErr;

            @FindBy(how = How.CSS, using = "label[for$='-I9s1_11NA']")
            private static WebElement awaitingSSNLabel;

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_11NA']")
            private static WebElement awaitingSSNCheckBox;

            public static String getSocialSecurityError() {
                return socialSecurityErr.getText();
            }

            /**
             * Gets the Social Security number from the form
             * @param previewPage Boolean whether this is the preview page
             * @return
             */
            public static String getSocialSecurityNumber(Boolean... previewPage) {
                //@FindBy(how = How.XPATH, using = "//span[contains(@id, '-I9s1_11_')]")
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    final List<WebElement> elements = Driver.getDriver()
                            .findElements(By.xpath("//span[contains(@id, '-I9s1_11_')]"));
                    StringBuilder ssn = new StringBuilder();
                    for (WebElement element : elements) {
                        ssn.append(element.getText());
                    }
                    return ssn.toString();
                }
                return socialSecurityTextBox.getText();
            }

            public static void setSocialSecurityNumber(String socialSecurityNumber) {
                if(Section2.isRequired(socialSecurityTextBox)) {
                    if(socialSecurityNumber.isEmpty()) {
                        checkAwaitingSSN();
                    } else {
                        SeleniumTest.unCheck(awaitingSSNLabel, awaitingSSNCheckBox);
                        SeleniumTest.clearAndSetText(socialSecurityTextBox, socialSecurityNumber);
                    }
                } else {
                    if(!socialSecurityNumber.isEmpty()) {
                        SeleniumTest.clearAndSetText(socialSecurityTextBox, socialSecurityNumber);
                    }
                }
                staticLogger.info("Social Security Number set to {}", socialSecurityNumber);
            }

            public static void checkAwaitingSSN() {
                SeleniumTest.check(awaitingSSNLabel, awaitingSSNCheckBox);
                staticLogger.info("Awaiting SSN checked");
            }

            public static void uncheckAwaitingSSN() {
                SeleniumTest.unCheck(awaitingSSNLabel, awaitingSSNCheckBox);
                staticLogger.info("Awaiting SSN unchecked");
            }
        }

        public static class DateOfBirth {

            static {
                PageFactory.initElements(Driver.getDriver(), DateOfBirth.class);
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_10']")
            public static WebElement dateOfBirthTextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_10']")
            public static WebElement dateOfBirthSpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_10-err']")
            public static WebElement dateOfBirthErr;

            public static String getDateOfBirthError() {
                return dateOfBirthErr.getText();
            }

            public static String getDateOfBirth(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return dateOfBirthSpan.getText();
                }
                return dateOfBirthTextBox.getText();
            }

            public static void setDateOfBirth(LocalDate date) {
                SeleniumTest.clearAndSetText(
                        dateOfBirthTextBox,
                        date.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
                staticLogger.info("Date of Birth set to {}", date.format(DateTimeFormatter
                        .ofPattern
                                ("MM/dd/yyyy")));
            }

            public static void setDateOfBirth(String date) {
                SeleniumTest.clearAndSetText(dateOfBirthTextBox, date);
                staticLogger.info("Date Of Birth set to {}", date);
            }
        }

        public static class Address {

            static {
                PageFactory.initElements(Driver.getDriver(), Address.class);
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_5']")
            public static WebElement addressLine1TextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_5']")
            public static WebElement addressLine1Span;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_5-err']")
            public static WebElement addressLine1Err;

            public static String getAddressLineError() {
                return addressLine1Err.getText();
            }
            public static String getAddressLine1(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return addressLine1Span.getText();
                }
                return addressLine1TextBox.getText();
            }

            public static void setAddressLine1(String addressLine1) {
                SeleniumTest.clearAndSetText(addressLine1TextBox, addressLine1);
                staticLogger.info("Address Line 1 set to {}", addressLine1);
            }

            public static class ApartmentNumber {

                static {
                    PageFactory.initElements(Driver.getDriver(), ApartmentNumber.class);
                }

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_6_1']")
                public static WebElement apartmentNumberTextBox;

                @FindBy(how = How.CSS, using = "span[id$='-I9s1_6']")
                public static WebElement apartmentNumberSpan;

                @FindBy(how = How.CSS, using = "label[for$='-I9s1_6NA']")
                private static WebElement noApartmentNumberCheckBoxLabel;

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_6NA']")
                private static WebElement noApartmentNumberCheckBox;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_6-err']")
                private static WebElement noApartmentNumberErr;

                public static String getApartmentNumberError() {
                    return noApartmentNumberErr.getText();
                }

                /**
                 * Gets the apartment number from the form
                 * @param previewPage Boolean on the preview page
                 * @return
                 */
                public static String getApartmentNumber(Boolean... previewPage) {
                    if(previewPage.length > 0 ? previewPage[0] : false) {
                        return apartmentNumberSpan.getText();
                    }
                    return apartmentNumberTextBox.getText();
                }

                public static void setApartmentNumber(String apartmentNumber) {
                    SeleniumTest.unCheck(noApartmentNumberCheckBoxLabel, noApartmentNumberCheckBox);
                    SeleniumTest.clearAndSetText(apartmentNumberTextBox, apartmentNumber);
                    staticLogger.info("Apartment Number set to {}", apartmentNumber);
                }

                public static void checkNoAparmentNumber() {
                    SeleniumTest.check(noApartmentNumberCheckBoxLabel, noApartmentNumberCheckBox);
                    staticLogger.info("No Apartment Number checked");
                }
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_7']")
            public static WebElement cityTextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_7']")
            public static WebElement citySpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_7-err']")
            public static WebElement cityErr;

            public static String getCityError() {
                return cityErr.getText();
            }

            /**
             * Gets the City from the form
             * @param previewPage Boolean on the preview Page
             * @return
             */
            public static String getCity(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return citySpan.getText();
                }
                return cityTextBox.getText();
            }

            public static void setCity(String city) {
                SeleniumTest.clearAndSetText(cityTextBox, city);
                staticLogger.info("City set to {}", city);
            }

            @FindBy(how = How.CSS, using = "select[id$='-addressI9s1_7-I9s1_56']")
            public static WebElement countryOrRegionDropDown;

            public static String getCountryOrRegion() {
                Select dropDown = new Select(countryOrRegionDropDown);
                return dropDown.getFirstSelectedOption().getText();
            }

            public static void selectCountryOrRegion(String country) {
                SeleniumTest.selectByVisibleTextFromDropDown(countryOrRegionDropDown, country);
                staticLogger.info("Country or Region set to {}", country);
            }

            @FindBy(how = How.CSS, using = "select[id$='-I9s1_8']")
            private static WebElement stateOrProvinceDropDown;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_8']")
            private static WebElement stateOrProvinceSpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_8-err']")
            private static WebElement stateOrProvinceErr;

            @FindBy(how = How.CSS, using = "div[id$='-addressI9s1_7-err']")
            public static WebElement cityStateZipComboErr;

            public static String getStateOrProvinceError() {
                return stateOrProvinceErr.getText();
            }

            public static String getCityStateZipComboError() {
                return cityStateZipComboErr.getText();
            }

            public static String getStateOrProvince(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return stateOrProvinceSpan.getText();
                }
                Select dropDown = new Select(stateOrProvinceDropDown);
                return dropDown.getFirstSelectedOption().getText();
            }

            public static void selectStateOrProvince(UsStateTerritory state) {
                I9Base.selectStateOrProvince(state, stateOrProvinceDropDown);
            }

            public static void selectStateOrProvince(String state) {
                I9Base.selectStateOrProvince(state, stateOrProvinceDropDown);
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_9']")
            private static WebElement zipCodeTextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_9']")
            private static WebElement zipCodeSpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_9-err']")
            private static WebElement zipCodeErr;

            public static String getZipCodeError() {
                return zipCodeErr.getText();
            }

            /**
             * Gets the zip code from the form
             * @param previewPage Boolean on the preview Page
             * @return
             */
            public static String getZipCode(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return zipCodeSpan.getText();
                }
                return zipCodeTextBox.getText();
            }

            public static void setZipCode(String zipCode) {
                SeleniumTest.clearAndSetText(zipCodeTextBox, zipCode);
                staticLogger.info("Zip Code set to {}", zipCode);
            }
        }

        public static class ContactInfo {

            static {
                PageFactory.initElements(Driver.getDriver(), ContactInfo.class);
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_12_1']")
            public static WebElement emailTextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_12']")
            public static WebElement emailSpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_12_1-err']")
            public static WebElement emailErr;

            @FindBy(how = How.CSS, using = "input[id$='-qEmailAddressNA']")
            private static WebElement emailCheckBox;

            @FindBy(how = How.CSS, using = "label[for$='-qEmailAddressNA']")
            private static WebElement emailCheckBoxLabel;

            public static String getEmailError() {
                return emailErr.getText();
            }

            /**
             * Gets the email address from the form
             * @param previewPage Boolean on preview page
             * @return
             */
            public static String getEmail(Boolean... previewPage) {
                if(previewPage.length > 0 ? previewPage[0] : false) {
                    return emailSpan.getText();
                }
                return emailTextBox.getText();
            }

            public static void setEmail(String email) {
                // this works differently for standard I-9 vs RHI 3-step I-9
                // decided to leave this here in case needed later for 3-step form
//                if (email.isEmpty()) {
//                    checkDoNotProvideEmailToDHS();
//                } else {
//                    SeleniumTest.unCheck(emailCheckBoxLabel, emailCheckBox);
//                    SeleniumTest.clearAndSetText(emailTextBox, email);
//                }
                SeleniumTest.clearAndSetText(emailTextBox, email);
                staticLogger.info("Email set to {}", email);
            }

            // need to keep this for 3-step form
            public static void checkDoNotProvideEmailToDHS() {
                SeleniumTest.check(emailCheckBoxLabel, emailCheckBox);
                staticLogger.info("Do Not Provide Email to DHS checked");
            }

            @FindBy(how = How.CSS, using = "input[id$='-I9s1_13_1']")
            public static WebElement telephoneTextBox;

            @FindBy(how = How.CSS, using = "span[id$='-I9s1_13']")
            public static WebElement telephoneSpan;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_13_1-err']")
            public static WebElement telephoneErr;

            @FindBy(how = How.CSS, using = "input[id$='-qPhoneNumberNA']")
            private static WebElement telephoneCheckBox;

            @FindBy(how = How.CSS, using = "label[for$='-qPhoneNumberNA']")
            private static WebElement telephoneCheckBoxLabel;

            public static String getTelephoneError() {
                return telephoneErr.getText();
            }

            /**
             * Gets the telephone number from the form
             * @param previewPage Boolean on the preview page
             * @return
             */
            public static String getTelephone(Boolean... previewPage) {
                if (previewPage.length > 0 ? previewPage[0] : false) {
                    return telephoneSpan.getText();
                }
                return telephoneTextBox.getText();
            }

            public static void setTelephone(String telephone) {
                // this works differently for standard I-9 vs RHI 3-step I-9
                // decided to leave this here in case needed later for 3-step form
//                if (telephone.isEmpty()) {
//                    checkDoNotProvideTelephoneToDHS();
//                } else {
//                    SeleniumTest.unCheck(telephoneCheckBoxLabel, telephoneCheckBox);
//                    SeleniumTest.clearAndSetText(telephoneTextBox, telephone, true);
//                }
                SeleniumTest.clearAndSetText(telephoneTextBox, telephone, true);
                staticLogger.info("Telephone set to {}", telephone);
            }

            // need to keep this for 3-step form
            public static void checkDoNotProvideTelephoneToDHS() {
                SeleniumTest.check(telephoneCheckBoxLabel, telephoneCheckBox);
                staticLogger.info("Do not Provide Telephone checked");
            }
        }
    }

    public static class CitizenAttestation {

        static {
            PageFactory.initElements(Driver.getDriver(), CitizenAttestation.class);
        }

        @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_USCITIZEN']")
        private static WebElement citizenRadioButtonLabel;

        @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_USNONCITIZENNATIONAL']")
        private static WebElement nonCitizenRadioButtonLabel;

        @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_LAWFULPERMANENTRESIDENT']")
        private static WebElement lawfulPermanentResidentRadioButtonLabel;

        public static class LawfulPermanentResident {

            static {
                PageFactory.initElements(Driver.getDriver(), LawfulPermanentResident.class);
            }

            @FindBy(how = How.XPATH, using = "//select[contains(@id,'I9s1_38')]")
            private static WebElement documentTypeDropDown;

            @FindBy(how = How.CSS, using = "div[id$='I9s1_38-err']")
            private static WebElement documentTypeErr;

            @FindBy(how = How.XPATH, using = "//input[contains(@id,'I9s1_15')]")
            private static WebElement alienRegistrationNumberTextBox;

            @FindBy(how = How.CSS, using = "div[id$='-I9s1_15-err")
            private static WebElement alienRegistrationNumberErr;

            public static String getDocumentTypeError() {
                return documentTypeErr.getText();
            }

            /**
             * Retrieves the document type that has been chosen
             * @return Dropdown selected option
             */
            public static String getDocumentType() {
                Select dropDown = new Select(documentTypeDropDown);
                return dropDown.getFirstSelectedOption().getText();
            }

            /**
             * Selects the document Type
             * @param type Type of document to select
             */
            public static void selectDocumentType(String type) {
                SeleniumTest.selectByVisibleTextFromDropDown(documentTypeDropDown, type);
            }

            /**
             * Retrieves the alien number
             * @return alien number
             */
            public static String getAlienRegistrationNumber() {
                return alienRegistrationNumberTextBox.getText();
            }

            public static String getAlienRegistrationNumberError() {
                return alienRegistrationNumberErr.getText();
            }

            /**
             * Sets the alien number
             * @param alienNumber the number to set
             */
            public static void setAlienRegistrationNumber(String alienNumber) {
                SeleniumTest.clearAndSetText(alienRegistrationNumberTextBox, alienNumber, true);
            }
        }

        @FindBy(how = How.CSS, using = "label[for$='-I9s1_14_ALIENAUTHORIZEDTOWORK']")
        private static WebElement alienAuthorizedToWorkRadioButtonLabel;

        // These radio buttons are always hidden
        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_USCITIZEN']")
        private static WebElement citizenRadioButton;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_USNONCITIZENNATIONAL']")
        private static WebElement nonCitizenRadioButton;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_LAWFULPERMANENTRESIDENT']")
        private static WebElement lawfulPermanentResidentRadioButton;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14_ALIENAUTHORIZEDTOWORK']")
        private static WebElement alienAuthorizedToWorkRadioButton;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_14']")
        public static WebElement isRequiredAttestation;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_14-err']")
        public static WebElement isRequiredAttestationErr;

        @FindBy(how = How.CSS, using = "select[id$='-I9s1_38']")
        private static WebElement lprAlienNumberDropDown;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_15']")
        private static WebElement lprAlienNumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_15-err']")
        private static WebElement lprAlienNumberErr;

        @FindBy(how = How.CSS, using = "select[id$='-I9s1_37']")
        private static WebElement aawAlienNumberDropDown;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_37-err']")
        private static WebElement aawAlienDocTypeErr;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_17']")
        private static WebElement aawAlienNumberTextBox;

        @FindBy(how = How.CSS, using = "div[id$='-I9s1_17-err']")
        private static WebElement aawAlienNumberErr;

        public static void chooseUSCitizen() {
            citizenRadioButtonLabel.click();
        }

        public static void chooseNonCitizen() {
            nonCitizenRadioButtonLabel.click();
        }

        public static String getAAWAlienNumberError() {
            return aawAlienNumberErr.getText();
        }

        public static String getAttestationError() {
            return isRequiredAttestationErr.getText();
        }

        public static String getlprAlienNumberError() {
            return lprAlienNumberErr.getText();
        }

        public static void chooseAlienAuthorizedToWork() {
            alienAuthorizedToWorkRadioButtonLabel.click();
            staticLogger.info("Alien Authorized to work chosen");
        }

        public static class AlienAuthorizedToWork {

            // Work authorization expiration Date visible and hidden controls
            @FindBy(how = How.XPATH, using =
                    "//input[@type='text'][contains(@id, '-I9s1_16_1-I9s1_16_1')]")
            private static WebElement workAuthorizationExpirationDateControl;

            @FindBy(how = How.XPATH, using =
                    "//input[@type='hidden'][contains(@id, '-I9s1_16_1')]")
            private static WebElement workAuthorizationExpirationDateControlHidden;


            @FindBy(how = How.CSS, using = "div[id$='-I9s1_16_1-err']")
            private static WebElement workAuthorizationExpirationDateErr;

            // Static constructor
            static {
                PageFactory.initElements(Driver.getDriver(), AlienAuthorizedToWork.class);
            }

            /**
             * Sets the Work Authorization Expiration Date
             * @param date Date to set
             */
            public static void setWorkAuthorizationExpirationDate(LocalDate date) {
                SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                        date,
                        workAuthorizationExpirationDateControl.getAttribute("id"),
                        workAuthorizationExpirationDateControlHidden.getAttribute("id")
                );
            }

            public static void setWorkAuthorizationExpirationDate(String date) {
                SeleniumTest.clearAndSetText(workAuthorizationExpirationDateControl, date);
            }

            public static String getWorkAuthExpDateError() {
                return workAuthorizationExpirationDateErr.getText();
            }

            // Choose Alien Registration Number
            @FindBy(how = How.CSS, using =
                    "label[for$='-qAlienAuthorizedToWorkDocument_Alien Registration Number/USCIS "
                            + "Number']")
            private static WebElement alienRegistrationNumberRadioLabel;

            /**
             * Chooses the Alien Registration Number checkbox
             */
            public static void chooseAlienRegistrationNumber() {
                alienRegistrationNumberRadioLabel.click();
            }

            /**
             * Handles actions performed when Alien Registration Number is chosen
             */
            public static class AlienRegistrationNumber {

                static {
                    PageFactory.initElements(Driver.getDriver(), AlienRegistrationNumber.class);
                }

                public static String getAlienRegistrationDocTypeError() {
                    return aawAlienDocTypeErr.getText();
                }

                public static String getAlienRegistrationDocNumberError() {
                    return aawAlienNumberErr.getText();
                }

                /**
                 * Sets the Alien Registration Type - AKA Label Description says "Document Type"
                 * @param type Enum of the type to set
                 */
                public static void selectAlienRegistrationType(AlienRegistrationType type) {
                    Section1.CitizenAttestation.setAlienNumberType(type.text);
                }

                public enum AlienRegistrationType {
                    NOT_ALIEN("None"),
                    ALIEN_NUMBER("Alien Number"),
                    USCIS_NUMBER("USCIS Number");

                    private final String text;

                    AlienRegistrationType(String text) {
                        this.text = text;
                    }
                }

                /**
                 * Sets the Alien Registration Number
                 * @param number Number to Set
                 */
                public static void setAlienRegistrationNumber(String number) {
                    Section1.CitizenAttestation.setAlienNumber(number);
                }

            }


            @FindBy(how = How.CSS, using =
                    "label[for$='-qAlienAuthorizedToWorkDocument_Form I-94 Admission Number']")
            private static WebElement formI94AdmissionNumberRadioLabel;

            /**
             * Chooses the I94 Admission Number Radio Button
             */
            public static void chooseI94AdmissionNumber() {
                formI94AdmissionNumberRadioLabel.click();
            }

            /**
             * Handles actions performed when Form I94 Admission Number is chosen
             */
            public static class FormI94AdmissionNumber {

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_18']")
                private static WebElement i94AdmissionNumberTextBox;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_18-err']")
                private static WebElement i94AdmissionNumberErr;

                static {
                    PageFactory.initElements(Driver.getDriver(), FormI94AdmissionNumber.class);
                }

                /**
                 * Sets the I94 Admission Number
                 * @param number
                 */
                public static void setI94AdmissionNumber(String number) {
                    SeleniumTest.clearAndSetText(i94AdmissionNumberTextBox, number, true);
                }

                public static String getI94AdmissionNumberError() {
                    return i94AdmissionNumberErr.getText();
                }
            }

            // Choose Foreign Passport Number
            @FindBy(how = How.CSS,using =
                    "label[for$='-qAlienAuthorizedToWorkDocument_Foreign Passport Number']")
            private static WebElement foreignPassportNumberRadioLabel;

            /**
             * Chooses the Foreign Passport Number Radio Button
             */
            public static void chooseForeignPassportNumber() {
                foreignPassportNumberRadioLabel.click();
            }

            /**
             * Handles actions performed when Foreign Passport Number is chosen
             */
            public static class ForeignPassportNumber {

                @FindBy(how = How.CSS, using = "input[id$='-I9s1_19']")
                private static WebElement foreignPassportNumberTextBox;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_19-err']")
                private static WebElement foreignPassportNumberErr;

                @FindBy(how = How.CSS, using = "select[id$='-I9s1_20']")
                private static WebElement foreignPassportCountryOfIssuanceDropDown;

                @FindBy(how = How.CSS, using = "div[id$='-I9s1_20-err']")
                private static WebElement foreignPassportCountryOfIssuanceErr;

                static {
                    PageFactory.initElements(Driver.getDriver(), ForeignPassportNumber.class);
                }

                /**
                 * Sets the Foreign Passport Number
                 * @param number Number to set
                 */
                public static void setForeignPassportNumber(String number) {
                    SeleniumTest.clearAndSetText(foreignPassportNumberTextBox, number, true);
                }

                public static String getForeignPassportNumberError() {
                    return foreignPassportNumberErr.getText();
                }

                /**
                 * Selects the Country of Issuance
                 * @param country Country to set
                 */
                public static void selectCountryOfIssuance(String country) {
                    SeleniumTest.selectByVisibleTextFromDropDown
                            (foreignPassportCountryOfIssuanceDropDown, country);
                }

                public static String getCountryOfIssuanceError() {
                    return foreignPassportCountryOfIssuanceErr.getText();
                }
            }

            private static void fillFromCitizenshipStatus(CitizenshipStatus citizenshipStatus) {
                setWorkAuthorizationExpirationDate(citizenshipStatus.getWorkAuthorizationExpiration());
                if (!citizenshipStatus.getAlienNumber().isEmpty()) {
                    chooseAlienRegistrationNumber();
                    setAlienNumberType(citizenshipStatus.getAlienNumberType());
                    setAlienNumber(citizenshipStatus.getAlienNumber());
                }

                if (!citizenshipStatus.getI94Number().isEmpty()) {
                    chooseI94AdmissionNumber();
                    FormI94AdmissionNumber.setI94AdmissionNumber(citizenshipStatus.getI94Number());
                }

                if (!citizenshipStatus.getForeignPassportNumber().isEmpty()) {
                    chooseForeignPassportNumber();
                    ForeignPassportNumber.setForeignPassportNumber(citizenshipStatus.getI94Number());
                    ForeignPassportNumber.selectCountryOfIssuance(citizenshipStatus.getForeignPassportCountry());
                }
            }
        }

        public static void chooseLawfulPermanentResident() {
            lawfulPermanentResidentRadioButtonLabel.click();
            staticLogger.info("Lawful Permanent Resident chosen");
        }

        /**
         * Sets the alien number type
         * @param alienNumberType Alien number type, Alien Number or USCIS Number
         */
        public static void setAlienNumberType(String alienNumberType) {
            WebElement t = lawfulPermanentResidentRadioButton;
            if(lawfulPermanentResidentRadioButton.getAttribute("checked") != null) { // TODO This is always false?
                SeleniumTest.selectByVisibleTextFromDropDown(
                        lprAlienNumberDropDown, alienNumberType);
            } else {
                SeleniumTest.selectByVisibleTextFromDropDown(
                        aawAlienNumberDropDown, alienNumberType);
            }
            staticLogger.info("Alien Number Type set to {}", alienNumberType);
        }

        /**
         * Sets the alien number
         * @param alienNumber alien/USCIS number to set
         */
        public static void setAlienNumber(String alienNumber) {
            if (lawfulPermanentResidentRadioButton.getAttribute("checked") != null) {
                SeleniumTest.clearAndSetText(lprAlienNumberTextBox, alienNumber, true);
            } else {
                SeleniumTest.clearAndSetText(aawAlienNumberTextBox, alienNumber, true);
            }
            staticLogger.info("Alien Number set to {}", alienNumber);
        }

        /**
         * Gets the current citizen status
         * @param previewPage Boolean on preview page
         */
        public static String getCitizenStatus(Boolean... previewPage) {
            if(previewPage.length > 0 ? previewPage[0] : false) {
                List<WebElement> elements = Driver.getDriver().findElements(By.cssSelector
                        ("input[name$='-I9s1_14']"));
                for(WebElement element : elements) {
                    if(element.getAttribute("checked") != null) {
                        return element.getAttribute("value");
                    }
                }
            }
            return "Unknown - not yet implemented";
        }

        public enum Eligibility {
            USCITIZEN,
            NONCITIZEN,
            LAWFUL_PERMANENT_RESIDENT,
            ALIEN_AUTHORIZED_TO_WORK
        }

        public static void fillFromCitizenshipStatus(CitizenshipStatus citizenshipStatus) {
            switch(citizenshipStatus.getEligibilityType()) {
                case USCITIZEN:
                    chooseUSCitizen();
                    break;
                case NONCITIZEN:
                    chooseNonCitizen();
                    break;
                case LAWFUL_PERMANENT_RESIDENT:
                    chooseLawfulPermanentResident();
                    LawfulPermanentResident.selectDocumentType(citizenshipStatus.getAlienNumberType());
                    LawfulPermanentResident.setAlienRegistrationNumber(citizenshipStatus.getAlienNumber());
                    break;
                case ALIEN_AUTHORIZED_TO_WORK:
                    chooseAlienAuthorizedToWork();
                    AlienAuthorizedToWork.fillFromCitizenshipStatus(citizenshipStatus);
                    break;
            }
        }
    }

    public static class Acknowledgement {

        static {
            PageFactory.initElements(Driver.getDriver(), Acknowledgement.class);
        }

        @FindBy(how = How.CSS, using = "input[id$='-qCertifySigning']")
        public static WebElement iAcknowledgeCheckBox;

        @FindBy(how = How.CSS, using = "label[for$='-qCertifySigning']")
        private static WebElement iAcknowledgeCheckBoxLabel;

        @FindBy(how = How.CSS, using = "div[id$='-qCertifySigning-err']")
        private static WebElement iAcknowledgeErr;

        public static void checkIAcknowledge() {
            SeleniumTest.check(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
            staticLogger.info("I Acknowledge checked");
        }

        public static void uncheckIAcknowledge() {
            SeleniumTest.unCheck(iAcknowledgeCheckBoxLabel, iAcknowledgeCheckBox);
            staticLogger.info("I Acknowledge unchecked");
        }

        public static String getIAcknowledgeError() {
            return iAcknowledgeErr.getText();
        }
    }

    public static class PreparerCertification {

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_27']")
        protected static WebElement preparerFirstNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_26']")
        protected static WebElement preparerLastNameTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-I9s1_28']")
        public static WebElement preparerAddressLine1TextBox;

        @FindBy(how = How.CSS, using = "input[id$='-addressI9s1_29-I9s1_29']")
        protected static WebElement preparerCityTextBox;

        @FindBy(how = How.CSS, using = "input[id$='-addressI9s1_29-I9s1_31']")
        protected static WebElement preparerZipCodeTextBox;

        @FindBy(how = How.CSS, using = "label[for$='-qCertifySigningPreparer']")
        private static WebElement iAttestCheckBoxLabel;

        @FindBy(how = How.CSS, using = "input[id$='-qCertifySigningPreparer']")
        public static WebElement iAttestCheckBox;

        @FindBy(how = How.CSS, using = "select[id$='-addressI9s1_29-I9s1_29_1']")
        public static WebElement preparerCountryOrRegionDropDown;

        @FindBy(how = How.CSS, using = "select[id$='-addressI9s1_29-I9s1_30']")
        private static WebElement preparerStateOrProvinceDropDown;

        static {
            PageFactory.initElements(Driver.getDriver(), PreparerCertification.class);
        }

        public static void checkIAttest() {
            SeleniumTest.check(iAttestCheckBoxLabel, iAttestCheckBox);
            staticLogger.info("I Attest checked");
        }

        /**
         * Retrieves the preparer first name as shown in the text box
         * @return String representation of the preparer first name
         */
        public static String getPreparerFirstName() {
            return preparerFirstNameTextBox.getText();
        }

        /**
         * Sets the preparer first name
         * @param preparerFirstName preparer first name to set
         */
        public static void setPreparerFirstName(String preparerFirstName) {
            if(!preparerFirstNameTextBox.getText().equals(preparerFirstName)) {
                SeleniumTest.clearAndSetText(preparerFirstNameTextBox, preparerFirstName);
            }
        }

        /**
         * Retrieves the preparer last name as shown in the text box
         * @return String representation of the preparer last name
         */
        public static String getPreparerLastName() {
            return preparerLastNameTextBox.getText();
        }

        /**
         * Sets the preparer last name
         * @param preparerLastName preparer last name to set
         */
        public static void setPreparerLastName(String preparerLastName) {
            if(!preparerLastNameTextBox.getText().equals(preparerLastName)) {
                SeleniumTest.clearAndSetText(preparerLastNameTextBox, preparerLastName);
            }
        }

        /**
         * Retrieves the preparer AddressLine1 as shown in the text box
         * @return String representation of the preparer AddressLine1
         */
        public static String getPreparerAddressLine1() {
            return preparerAddressLine1TextBox.getText();
        }

        /**
         * Sets the preparer AddressLine1
         * @param preparerAddressLine1 preparer AddressLine1 to set
         */
        public static void setPreparerAddressLine1(String preparerAddressLine1) {
            if(!preparerAddressLine1TextBox.getText().equals(preparerAddressLine1)) {
                SeleniumTest.clearAndSetText(preparerAddressLine1TextBox, preparerAddressLine1);
            }
        }

        /**
         * Retrieves the preparer city as shown in the text box
         * @return String representation of the preparer city
         */
        public static String getPreparerCity() {
            return preparerCityTextBox.getText();
        }

        /**
         * Sets the preparer city
         * @param preparerCity preparer city to set
         */
        public static void setPreparerCity(String preparerCity) {
            if(!preparerCityTextBox.getText().equals(preparerCity)) {
                SeleniumTest.clearAndSetText(preparerCityTextBox, preparerCity);
            }
        }

        public static void selectPreparerCountryOrRegion(String country) {
            SeleniumTest.selectByVisibleTextFromDropDown(preparerCountryOrRegionDropDown, country);
            staticLogger.info("Country or Region set to {}", country);
        }

        public static void selectPreparerStateOrProvince(UsStateTerritory state) {
            SeleniumTest.selectByVisibleTextFromDropDown(
                    preparerStateOrProvinceDropDown, state.getFullName());
            staticLogger.info("State or Province set to {}", state);
        }

        /**
         * Retrieves the preparer Zip Code as shown in the text box
         * @return String representation of the preparer Zip Code
         */
        public static String getPreparerZipCode() {
            return preparerZipCodeTextBox.getText();
        }

        /**
         * Sets the preparer Zip Code
         * @param preparerZipCode preparer Zip Code to set
         */
        public static void setPreparerZipCode(String preparerZipCode) {
            if(!preparerZipCodeTextBox.getText().equals(preparerZipCode)) {
                SeleniumTest.clearAndSetText(preparerZipCodeTextBox, preparerZipCode);
            }
        }
    }

    public static void populateEmployeeInformation(Candidate candidate) {
        // Fill in all Pertinent Section 1 Details
        EmployeeInfo.Name.setFirstName(candidate.getFirstName());
        EmployeeInfo.Name.setLastName(candidate.getLastName());
        EmployeeInfo.Name.AlternateNames
            .setAlternateNamesUsed(candidate.getAlternateLastName());
        EmployeeInfo.SocialSecurityNumber
            .setSocialSecurityNumber(candidate.getSocialSecurityNumber());
        EmployeeInfo.DateOfBirth.setDateOfBirth(candidate.getDOB());
        EmployeeInfo.Address.setAddressLine1(candidate.getAddressLine1());
        EmployeeInfo.Address.setCity(candidate.getCity());
        EmployeeInfo.Address.selectStateOrProvince(candidate.getState());
        EmployeeInfo.Address.setZipCode(candidate.getZip());
    }

    public static void populateCitizenAttestation(Candidate candidate,
                                                  CitizenAttestation.Eligibility citizenStatus,
                                                  LocalDate workAuthExpirationDate,
                                                  CitizenAttestation
                                                      .AlienAuthorizedToWork
                                                      .AlienRegistrationNumber
                                                      .AlienRegistrationType alienRegistrationType,
                                                  String alienRegistrationNumber) {

        switch(citizenStatus) {
        case USCITIZEN:
            CitizenAttestation.chooseUSCitizen();
            break;
        case NONCITIZEN:
            CitizenAttestation.chooseNonCitizen();
            break;
        case LAWFUL_PERMANENT_RESIDENT:
            CitizenAttestation.chooseLawfulPermanentResident();
            CitizenAttestation.setAlienNumberType(
                CitizenAttestation.AlienAuthorizedToWork.AlienRegistrationNumber.AlienRegistrationType.ALIEN_NUMBER.text);
            CitizenAttestation.setAlienNumber(candidate.getLawfulPermanentResidentAlienNumber());
            break;
        case ALIEN_AUTHORIZED_TO_WORK:
            CitizenAttestation.chooseAlienAuthorizedToWork();
            CitizenAttestation.AlienAuthorizedToWork
                .setWorkAuthorizationExpirationDate(workAuthExpirationDate);
            if(!alienRegistrationNumber.isEmpty()) {
                CitizenAttestation.AlienAuthorizedToWork.chooseAlienRegistrationNumber();
                CitizenAttestation.AlienAuthorizedToWork.AlienRegistrationNumber
                    .selectAlienRegistrationType(alienRegistrationType);
                CitizenAttestation.AlienAuthorizedToWork.AlienRegistrationNumber
                    .setAlienRegistrationNumber(alienRegistrationNumber);
            }
            break;
        }
    }

    public static void acknowledge(boolean acknowledged) {

        // Check or uncheck the acknowledgement checkbox as requested
        if (acknowledged) {
            Acknowledgement.checkIAcknowledge();
        } else {
            Acknowledgement.uncheckIAcknowledge();
        }
    }
}
