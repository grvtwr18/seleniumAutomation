package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.w3c.dom.stylesheets.LinkStyle;
import javax.swing.text.html.CSS;
import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Page object that represents Verify Your Employment Page for candidates.
 *
 * @author mramos
 */
public class VerifyYourEmploymentPage extends CandidatePortalPages {

    @FindBy(id = "backToDashboardBtn")
    private static WebElement backToDashboardBtn;

    @FindBy(id = "docUploadOkButton")
    private static WebElement yesButton;

    @FindBy(id = "docUploadCancelButton")
    private static WebElement cancelButton;

    @FindBy(id = "divDocUploadModal")
    private static WebElement areYouSureModal;

    @FindBy(id = "forewords2")
    private static WebElement candidateInstructions;

    @FindBy(id = "forewords3")
    private static WebElement instructionsByAcceptDocument;

    @FindBy(id = "yearbuttonarea")
    private static WebElement yearAreaDiv;

    @FindBy(id = "nodoccheck")
    private static WebElement documentationNotAvailableButton;

    @FindBy(id = "uploadlabel")
    private static WebElement uploadFileButton;

    @FindBy(id = "filechooser")
    private static WebElement fileChooser;

    @FindBy(id = "startToPost")
    private static WebElement submitButton;

    @FindBy(xpath="//*[@id='fileyears1']//input")
    private static WebElement applicableYearsDropdown;

    @FindBy(xpath="//*[@id='fileyears2']//input")
    private static WebElement applicableYearsDropdown2;

    @FindBy(xpath="//*[@id='filepath1']/input")
    private static WebElement fileDeleteIcon1;

    @FindBy(css="#fileyearsselector1-list")
    private static WebElement allYearList;

    @FindBy(xpath="//*[@id='portalContent']/h1")
    private static WebElement thankYouMsg;

    @FindBy(xpath="//*[@value='grant']")
    private static WebElement grantUploadButton;

    @FindBy(css="button.button.buttonwidth200")
    private static WebElement returnToDashboardButton;

    @FindBy(css=".status")
    private static List<WebElement> statusOfUploadDocuments;

    @FindBy(css=".leftMost")
    private static List<WebElement> noOfUploadRequest;

    static {
        PageFactory.initElements(Driver.getDriver(), VerifyYourEmploymentPage.class);
    }

    public static void clickBackToDashboard() {
        SeleniumTest.click(backToDashboardBtn);
    }

    public static String getCandidateInstructions() {
        return SeleniumTest.getText(candidateInstructions);
    }

    /**
     * Depending on CUSTOMER NOTES set in Salesforce DB you will get different instructions. If you change CUSTOMER
     * NOTES you will need to refresh the page to see the change.
     */
    public static String getInstructionsByAcceptDocument(boolean refreshBefore) {
        if (refreshBefore) {
            SeleniumTest.refreshCurrentPage();
        }
        return SeleniumTest.getText(instructionsByAcceptDocument);
    }

    public static void selectApplicableYears(Integer dropdownNumber,String textToSelect){

        if(dropdownNumber==1){
            SeleniumTest.click(applicableYearsDropdown);
        }
        else if(dropdownNumber==2){
            SeleniumTest.click(applicableYearsDropdown2);
        }
        allYearList.findElement(By.xpath("//*[@id='fileyearsselector"+dropdownNumber+"_listbox']/li[text()='"+textToSelect+"']")).click();
        staticLogger.info(textToSelect+" is selected a year");
    }

    public static boolean isFileUploadedIconVisible(Integer dropdownNumber){

        return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//*[@id='filepath"+dropdownNumber+"']/input[@type='image']"));
    }

    public static boolean isThankYouMsgVisible(){
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//*[@id='portalContent']/h1"));
    }
    /**
     * This method select All Years in applicable years for your first row (File or Documentation Not Available)
     * @param row Which row is going to use "All Years". First index is 1.
     */
    public static void selectAllYearsForRow(int row) {
        SeleniumTest.click(By.cssSelector(String.format("#fileyears%s  > div", row)));
        SeleniumTest.click(By.cssSelector(String.format("#fileyearsselector%s_listbox  > li", row)));
    }

    public static void selectYear(int row, int year){
        SeleniumTest.click(By.cssSelector(String.format("#fileyears%s  > div", row)));
        SeleniumTest.click(By.xpath(String.format("//ul[@id='fileyearsselector%s_listbox']/li[text()='%s']", row, year)));
    }

    public static void deleteRow(int row){
        SeleniumTest.click(By.xpath(String.format("//td[@id='filepath%s']/input[@type='image']", row)));
    }

    public static void clickDocumentationNotAvailableButton() {
        SeleniumTest.click(documentationNotAvailableButton);
    }

    public static void clickSubmit() {
        SeleniumTest.click(submitButton);
    }

    public static void selectYearsWithoutDocumentationAndSubmit() {
        clickDocumentationNotAvailableButton();
        selectAllYearsForRow(1);
        clickSubmit();
    }

    public static boolean isUploadFileButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("uploadlabel"));
    }

    public static boolean isDocumentationNotAvailableButtonVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("nodoccheck"));
    }

    public static void selectFile(String canonicalPath) {
        fileChooser.sendKeys(canonicalPath);
    }

    public static boolean isErrorListPresent(){
        return SeleniumTest.isElementVisibleNoWaiting(By.cssSelector("#AllErrors"));
    }

    /**
     * Get file name by row (start at 1)
     * @param row
     * @return file name
     */
    public static String getFilePath(int row){
        return SeleniumTest.getTextByLocator(By.id("filepath" + row));
    }

    /**
     * Modal to confirm that the candidate is going going back to dashboard
     */
    public static class AreYouSureModal {
        @FindBy(id = "docUploadOkButton")
        private static WebElement yesButton;

        @FindBy(id = "docUploadCancelButton")
        private static WebElement cancelButton;

        static {
            PageFactory.initElements(Driver.getDriver(), AreYouSureModal.class);
        }

        public static Sites.CandidatePortal.DashboardPage clickYesButton() {
            SeleniumTest.click(yesButton);
            return PageFactory.initElements(Driver.getDriver(), Sites.CandidatePortal.DashboardPage.class);
        }

        public static void clickCancelButton() {
            SeleniumTest.click(cancelButton);
        }

        public static boolean isVisible() {
            return SeleniumTest.isElementVisibleNoWaiting(By.id("divDocUploadModal"));
        }
    }

    public static void selectFileAndUpload(Integer dropdownNumber,String yearToSelect) throws IOException {

        //formID310UploadI9DocumentsPage.clickUploadFileButton(5,"test");
        //SeleniumTest.click(uploadFileButton);
        //Create temp file to select
        File tempFile = SeleniumTest.createTempFileToUpload("test", "pdf");
        VerifyYourEmploymentPage.selectFile(tempFile.getCanonicalPath());
        staticLogger.info("Select the file type as W2");
        SeleniumTest.selectByVisibleTextFromDropDown(By.id("documenttypeselector1"),"W2");
        staticLogger.info("Select Applicable years as "+yearToSelect);
        VerifyYourEmploymentPage.selectApplicableYears(dropdownNumber,yearToSelect);


    }

    public void isGrantUploadButtonDisplayed(){  SeleniumTest.isElementVisible(grantUploadButton);}

    public void clickReturnToDashboard(){  SeleniumTest.click(returnToDashboardButton);}

    public String statusOfUploadDocument(int index){ return SeleniumTest.getText(statusOfUploadDocuments.get(index));}

    public List getNoOfStatusUploadRequest(){ return noOfUploadRequest; }
}
