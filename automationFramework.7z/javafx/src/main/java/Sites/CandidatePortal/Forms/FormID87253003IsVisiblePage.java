package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Created by jgupta on 8/31/2015.
 */
public class FormID87253003IsVisiblePage extends FormPage {

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private static WebElement saveButton;

    @FindBy(how = How.CSS, using = "div#taskNav_87253004>a")
    private static WebElement isVisiblePage2Link;

    @FindBy(how = How.LINK_TEXT, using = "Form Review Results")
    private static WebElement formReviewResultsLink;

    @FindBy(how = How.LINK_TEXT, using = "eSign Forms")
    private static WebElement eSignFormsLink;

    /**
     * Constructs a new IsVisible page object.
     */
    public FormID87253003IsVisiblePage() {

    }

    /**
     * Generic method to fill up the history secion in Form ID 87253003 Is visible page
     * @param radioLabel
     * @param text
     * @param widgetIndex
     */
    public static void fillHistoryWidgetSection(String radioLabel, String text, int widgetIndex) {
        int barneyRubbleIndex = widgetIndex;

        if (widgetIndex>0)
            widgetIndex = (widgetIndex*3);

        List<WebElement> radioLabelsList = Driver.getDriver().findElements(By.className("radioLabel"));

        List<WebElement> barneyRubbleTextBoxList = Driver.getDriver().findElements(By.cssSelector("input[fieldname^='Barney Rubble goes']"));

        if(radioLabel.equals("Yes")){
            (radioLabelsList.get(widgetIndex)).click();
            (radioLabelsList.get(widgetIndex)).click();
        }
        else if(radioLabel.equals("No")) {
            widgetIndex = widgetIndex+1;
            (radioLabelsList.get(widgetIndex)).click();
        }
        else{
            widgetIndex = widgetIndex +2;
            (radioLabelsList.get(widgetIndex)).click();
        }
        SeleniumTest.clearAndSetText((barneyRubbleTextBoxList.get(barneyRubbleIndex)), text, true);
    }

    /**
     * Click on the save button.
     */
    public static void clickSaveButton() {
        saveButton.click();
    }

    /**
     * Click on Next button
     * @return
     */
    public static FormID1eSignPage clickNextButtonToGoToFormID1eSignPage() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID1eSignPage.class);
    }

    /**
     * This method clicks on the Next button to go to FormID87253003IsVisible Page
     * @return FormID87253003IsVisiblePage
     */
    public static FormID87253003IsVisiblePage clickNextButtonToGoToFormID87253003IsVisiblePage(){
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID87253003IsVisiblePage.class);
    }

    /**
     * This method clicks on the Next button to go to FormReviewResults Page
     * @return FormReviewResultsPage
     */
    public static FormReviewResultsPage clickNextButtonToGoToFormReviewResults() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormReviewResultsPage.class);
    }

    /**
     * Click on Next button
     * @return
     */
    public static CandidatePortalPages clickNextButton(Class<? extends CandidatePortalPages> returnClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Click on Is visible link for next page in left hand nav
     * @return
     */
    public static FormID87253003IsVisiblePage clickIsVisiblePage2Link() {
        isVisiblePage2Link.click();
        return PageFactory.initElements(Driver.getDriver(), FormID87253003IsVisiblePage.class);
    }

    /**
     * Clicks on Form Review Results Link in left nav
     */
    public static FormReviewResultsPage clickFormReviewResultsLink() {
        formReviewResultsLink.click();
        return PageFactory.initElements(Driver.getDriver(), FormReviewResultsPage.class);
    }

    /**
     * Clicks on eSign Forms link in left hand nav.
     * @return
     */
    public static FormID1eSignPage clickeSignFormsLink() {
        eSignFormsLink.click();
        return PageFactory.initElements(Driver.getDriver(), FormID1eSignPage.class);
    }
}