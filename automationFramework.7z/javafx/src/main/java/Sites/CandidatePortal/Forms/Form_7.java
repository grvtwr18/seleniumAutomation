package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by abrackett on 10/18/16.
 * Form handles:  approve and return form as part of 3 step I-9
 */
public class Form_7 {

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {

    }

    public static class FormReviewResults {

        static {
            PageFactory.initElements(Driver.getDriver(), FormReviewResults.class);
        }

        @FindBy(how = How.XPATH, using = "//label[text()='Approve Form']")
        private static WebElement approveRadiobutton;

        @FindBy(how = How.XPATH, using = "//label[text()='Return Form']")
        private static WebElement returnFormRadiobutton;

        @FindBy(how = How.CLASS_NAME, using = "reviewTextArea")
        private static WebElement reviewTextArea;

        @FindBy(how = How.CSS, using = "label[for$='previoustaskowners_1")
        private static WebElement taskOwner1RadioButton;

        /**
         * Choose Approve
         */
        public static void chooseApprove() {
            approveRadiobutton.click();
            WebDriverWait wait = new WebDriverWait(Driver.getDriver(), 10);
            wait.until(ExpectedConditions.visibilityOf(Driver.getDriver().findElement(
                    By.className("reviewTextArea"))));
        }

        public static void chooseApprove(String text) {
            chooseApprove();
            SeleniumTest.clearAndSetText(reviewTextArea, text);
        }

        public static void chooseReturn(String returnReason) {
            returnFormRadiobutton.click();
            taskOwner1RadioButton.click();
            SeleniumTest.clearAndSetText(reviewTextArea, returnReason);
        }
    }

}
