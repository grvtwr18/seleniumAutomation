package Sites.CandidatePortal.Forms;

import Workflows.Candidate;

/**
 * Created by abrackett on 10/16/16.
 * Handles complete Section 1 for Core I-9
 */
public class Form_5704 extends CandidatePortalPages {

    public static class Section1 extends Sites.CandidatePortal.Forms.Objects.I9.Section1 {
        // Enables derived class access to Section 1
    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {
        // Enables derived class access to Navigation
    }

    public static void fillEmployeeName(Candidate candidate) {
        Form_5704.Section1.EmployeeInfo.Name.setFirstName(candidate.getFirstName());
        Form_5704.Section1.EmployeeInfo.Name.MiddleName.setMiddleName(candidate.getMiddleName());
        Form_5704.Section1.EmployeeInfo.Name.setLastName(candidate.getLastName());
        Form_5704.Section1.EmployeeInfo.Name.AlternateNames.setAlternateNamesUsed(
                candidate.getAlternateFirstName() + candidate.getAlternateLastName());

    }

    public static void fillEmployeeSSN(Candidate candidate) {
        Form_5704.Section1.EmployeeInfo.SocialSecurityNumber.setSocialSecurityNumber(
                candidate.getSocialSecurityNumber());
    }

    public static void fillEmployeeDateOfBirth(Candidate candidate) {
        Form_5704.Section1.EmployeeInfo.DateOfBirth.setDateOfBirth(candidate.getDOB());
    }

    public static void fillEmployeeAddress(Candidate candidate) {
        Form_5704.Section1.EmployeeInfo.Address.setAddressLine1(candidate.getAddressLine1());
        Form_5704.Section1.EmployeeInfo.Address.ApartmentNumber.setApartmentNumber(
                candidate.getApartmentNumber());
        Form_5704.Section1.EmployeeInfo.Address.setCity(candidate.getCity());
        Form_5704.Section1.EmployeeInfo.Address.selectCountryOrRegion(
                candidate.getCountryOrRegion());
        Form_5704.Section1.EmployeeInfo.Address.selectStateOrProvince(
                candidate.getState());
        Form_5704.Section1.EmployeeInfo.Address.setZipCode(candidate.getZip());
    }

    public static void fillContactInformation(Candidate candidate) {
        Form_5704.Section1.EmployeeInfo.ContactInfo.setEmail(candidate.getEmailAddress());
        Form_5704.Section1.EmployeeInfo.ContactInfo.setTelephone(candidate.getCandidatePhone());
    }

    public static void chooseEligibility(
            Form_5704.Section1.CitizenAttestation.Eligibility eligibleType) {

        switch(eligibleType) {
            case USCITIZEN:
                Form_5704.Section1.CitizenAttestation.chooseUSCitizen();
                break;
            case NONCITIZEN:
                Form_5704.Section1.CitizenAttestation.chooseNonCitizen();
                break;
            case LAWFUL_PERMANENT_RESIDENT:
                Form_5704.Section1.CitizenAttestation.chooseLawfulPermanentResident();
                break;
            case ALIEN_AUTHORIZED_TO_WORK:
                Form_5704.Section1.CitizenAttestation.chooseAlienAuthorizedToWork();
                break;
        }
    }

    public static void chooseIAcknowledge() {
        Form_5704.Section1.Acknowledgement.checkIAcknowledge();
    }

    public static void fillSection1(
            Candidate candidate,
            Form_5704.Section1.CitizenAttestation.Eligibility eligibleType) {
        fillEmployeeName(candidate);
        fillEmployeeSSN(candidate);
        fillEmployeeDateOfBirth(candidate);
        fillEmployeeAddress(candidate);
        fillContactInformation(candidate);
        chooseEligibility(eligibleType);
        chooseIAcknowledge();
    }
}
