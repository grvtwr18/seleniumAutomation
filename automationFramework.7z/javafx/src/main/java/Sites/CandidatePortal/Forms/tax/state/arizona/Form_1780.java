package Sites.CandidatePortal.Forms.tax.state.arizona;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_1780 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_5_Yes']")
    private WebElement completeFormA4VYesRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_5_No']")
    private WebElement completeFormA4VNoRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_5']")
    public WebElement withholdingLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_8']")
    public WebElement chooseEitherOneOrTwoLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_5_Yes']")
    private WebElement chooseOneRadiobutton;

    @FindBy(how = How.ID, using = "//label[@for='1780-1780_8_2']")
    private WebElement chooseTwoRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1778_9']")
    public WebElement conditionalCheckOnlyOnePercentageLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_10']")
    public WebElement chkCheckForOne;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'0.8%')]")
    public WebElement pointEightPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'1.3%')]")
    private WebElement onePointThreePercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'1.8%')]")
    private WebElement onePointEightPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'2.7%')]")
    private WebElement twoPointSevenPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'3.6%')]")
    private WebElement threePointSixPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'4.2%')]")
    private WebElement fourPointTwoPercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'5.1%')]")
    private WebElement fivePointOnePercentRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_13']")
    private WebElement additionalWithholdingCheckboxLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_13']")
    private WebElement additionalWithholdingCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1778_13']")
    public WebElement additionalWithholdingLabel;

    @FindBy(how = How.ID, using = "1780-1778_13")
    private WebElement additionalWithholdingAmountInput;

    @FindBy(how = How.ID, using = "1780-1778_20")
    private WebElement withholdingStatusDropdown;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_23']")
    private WebElement iUnderstandCheckboxlabel;

    @FindBy(how = How.ID, using = "1780-1780_23")
    private WebElement iUnderstandCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1780_20']")
    public WebElement iCertifyLabel;

    @FindBy(how = How.ID, using = "1780-1780_20")
    private WebElement iCertifyCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1778_25']")
    public WebElement residencyStatementLabel;

    @FindBy(how = How.ID, using = "1780-1778_25")
    private WebElement residencyStatementDropdown;

    @FindBy(how = How.XPATH, using = "//label[@for='1780-1778_26']")
    public WebElement employmentStatementLabel;

    @FindBy(how = How.ID, using = "1780-1778_26")
    private WebElement employmentStatementDropdown;


    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_1780() {

    }

    public static Form_1780 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_1780.class);
    }

    public Form_1780 choosePointEightPercentRadiobutton() {
        SeleniumTest.click(pointEightPercentRadiobutton);
        logger.info(".8% Radio Button Chosen");
        return this;
    }

    public Form_1780 chooseOnePointThreePercentRadiobutton() {
        SeleniumTest.click(onePointThreePercentRadiobutton);
        logger.info("1.3% Radio Button Chosen");
        return this;
    }

    public Form_1780 chooseOnePointEightPercentRadiobutton() {
        SeleniumTest.click(onePointEightPercentRadiobutton);
        logger.info("1.8% Radio Button Chosen");
        return this;
    }

    public Form_1780 chooseTwoPointSevenPercentRadiobutton() {
        SeleniumTest.click(twoPointSevenPercentRadiobutton);
        logger.info("2.7% Radio Button Chosen");
        return this;
    }

    public Form_1780 chooseThreePointSixPercentRadiobutton() {
        SeleniumTest.click(threePointSixPercentRadiobutton);
        logger.info("3.6% Radio Button Chosen");
        return this;
    }

    public Form_1780 chooseFourPointTwoPercentRadiobutton() {
        SeleniumTest.click(fourPointTwoPercentRadiobutton);
        logger.info("4.2% Radio Button Chosen");
        return this;
    }

    public Form_1780 chooseFivePointOnePercentRadiobutton() {
        SeleniumTest.click(fivePointOnePercentRadiobutton);
        logger.info("5.1% Radio Button Chosen");
        return this;
    }

    public Form_1780 checkAdditionalWithholding() {
        SeleniumTest.click(additionalWithholdingCheckbox);
        logger.info("Additional Withholding Checked");
        return this;
    }

    public Form_1780 uncheckAdditionalWithholding() {
        SeleniumTest.click(additionalWithholdingCheckbox);
        logger.info("Additional Withholding unchecked");
        return this;
    }

    public String getAdditionalWithholdingAmount() {
        return additionalWithholdingAmountInput.getText();
    }

    public Form_1780 setAdditionalWithholdingAmount(String amount) {
        SeleniumTest.clearAndSetText(additionalWithholdingAmountInput, amount);
        logger.info("Additional Withholding set to {}", amount);
        return this;
    }
    public Form_1780 chooseCheckForOne() {
        SeleniumTest.click(chkCheckForOne);
        logger.info("Check For One selected");
        return this;
    }
    public String getWithholdingStatus() {
        Select dropdown = new Select(withholdingStatusDropdown);
        return dropdown.getFirstSelectedOption().getText();
    }

    public Form_1780 selectWithholdingStatusDropdown(String withholdingStatus) {
        SeleniumTest.selectByVisibleTextFromDropDown(withholdingStatusDropdown, withholdingStatus);
        logger.info("Withholding Status Selected {}", withholdingStatus);
        return this;
    }

    public Form_1780 checkICertify() {
        SeleniumTest.check(iCertifyLabel, iCertifyCheckbox);
        logger.info("I Certify Checked");
        return this;
    }

    public Form_1780 uncheckICertify() {
        SeleniumTest.unCheck(iCertifyLabel, iCertifyCheckbox);
        logger.info("I Certify Checked");
        return this;
    }

    public String getResidencyStatement() {
        Select dropdown = new Select(residencyStatementDropdown);
        return dropdown.getFirstSelectedOption().getText();
    }

    public Form_1780 selectResidencyStatement(String residencyStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropdown, residencyStatement);
        logger.info("Withholding Status Selected {}", residencyStatement);
        return this;
    }

    public String getEmploymentStatement() {
        Select dropdown = new Select(employmentStatementDropdown);
        return dropdown.getFirstSelectedOption().getText();
    }

    public Form_1780 selectEmploymentStatementDropdown(String employmentStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(employmentStatementDropdown, employmentStatement);
        logger.info("Withholding Status Selected {}", employmentStatement);
        return this;
    }

    public void fillRequiredFields(boolean completeFormA4V, boolean takeTaxes, String additionalWithholdingAmount) {
        if (completeFormA4V) {
                if (takeTaxes) {
                    this.chooseOne();
                    this.chooseTwoPointSevenPercentRadiobutton();
                    this.checkAdditionalWithholding();
                    this.setAdditionalWithholdingAmount(additionalWithholdingAmount);
                } else {
                    this.chooseTwo();
                    this.checkIUnderstand();
                }
                this.checkICertify();
                this.selectResidencyStatement("I live in Arizona");
                this.selectEmploymentStatementDropdown("I work out of state");
        } else {
                this.chooseCompleteFormA4VNo();
        }
    }

    public Form_1780 chooseCompleteFormA4VYes() {
        completeFormA4VYesRadiobutton.click();
        logger.info("Complete form A4V Yes Chosen");
        return this;
    }

    public Form_1780 chooseCompleteFormA4VNo() {
        completeFormA4VNoRadiobutton.click();
        logger.info("Complete form A4V No Chosen");
        return this;
    }

    public Form_1780 chooseOne() {
        chooseOneRadiobutton.click();
        logger.info("Arizona Resident choosing to have taxes removed");
        return this;
    }

    public Form_1780 chooseTwo() {
        chooseTwoRadiobutton.click();
        logger.info("Arizona Resident choosing to NOT have taxes removed");
        return this;
    }

    public Form_1780 checkIUnderstand() {
        SeleniumTest.check(iUnderstandCheckboxlabel, iUnderstandCheckbox);
        logger.info("I Understand Checked");
        return this;
    }

    public Form_1780 uncheckIUnderstand() {
        SeleniumTest.unCheck(iUnderstandCheckboxlabel, iUnderstandCheckbox);
        logger.info("I Understand unChecked");
        return this;
    }
}
