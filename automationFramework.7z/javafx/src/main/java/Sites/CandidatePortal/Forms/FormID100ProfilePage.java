package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.statetax.StateTaxFormsSelector;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.Map;

/**
 * Created by jgupta on 8/13/2015.
 */
public class FormID100ProfilePage  extends FormPage {

    @FindBy(how = How.CSS, using = "button")
    private WebElement launchTaskButton;

    @FindBy(how = How.CSS, using = "input[fieldname='First Name']")
    private static WebElement firstNameTextbox;

    @FindBy(how = How.XPATH, using = "//label[text()='Middle Name']/following-sibling::input")
    private static WebElement middleNameTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Last Name']")
    private static WebElement lastNameTextbox;

    @FindBy(how = How.ID, using = "100-100_4")
    private WebElement suffixTextbox;

    @FindBy(how = How.CSS, using = "label.checkboxLabel")
    private static WebElement noMiddleNameCheckbox;

    private static final By ssnTextBoxLocator = By.cssSelector("input[fieldname='Social Security Number']");
    @FindBy(how = How.CSS, using = "input[fieldname='Social Security Number']")
    private static WebElement ssnTextbox;

    @FindBy(how = How.CSS, using = "input.hasDatepicker")
    private static WebElement dobTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Mother\\'s Maiden Name']")
    private static WebElement maidenNameTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Street address']")
    private static WebElement streetAddressTextbox;

    @FindBy(how = How.ID, using = "100-100_8")
    private static WebElement apartmentNumberBox;

    @FindBy(how = How.ID, using = "100-address100_9-100_10")
    private static WebElement cityTextbox;

    @FindBy(how = How.ID, using = "100-address100_9-100_9")
    private static WebElement countryDropdown;

    @FindBy(how = How.ID, using = "100-address100_9-100_11")
    private static WebElement stateDropdown;

    @FindBy(how = How.ID, using = "100-address100_9-100_12")
    private static WebElement zipTextbox;

    @FindBy(how = How.CSS, using = "input[fieldname='Primary Phone']")
    private static WebElement primaryPhoneNumberTextbox;

    @FindBy(how = How.ID, using = "100-100_14")
    private static WebElement otherPhoneTextbox;

    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private WebElement saveButton;

    static {
        PageFactory.initElements(Driver.getDriver(), FormID100ProfilePage.class);
    }

    /**
     * Method to fill profile information in the form with middle name
     * @param firstName
     * @param midName
     * @param lastName
     * @param ssn
     * @param dob
     */
    public static void fillRequiredProfileFormData(String firstName, String midName, String lastName, String ssn, String dob)
    {
        SeleniumTest.clearAndSetText(firstNameTextbox, firstName);
        noMiddleNameCheckbox.click();
        SeleniumTest.clearAndSetText(middleNameTextbox, midName);
        SeleniumTest.clearAndSetText(lastNameTextbox, lastName);
        SeleniumTest.clearAndSetText(ssnTextbox, ssn);
        SeleniumTest.clearAndSetText(dobTextbox, dob);
    }

    public static String getFirstName(){
        return firstNameTextbox.getAttribute("Value");
    }

    public static String getLastName(){
        return lastNameTextbox.getAttribute("Value");
    }

    public static String getMiddleName(){
        return SeleniumTest.getText(middleNameTextbox);
    }


    /**
     * Fills profile information based on incoming candidate
     * @param candidate
     */
    public static FormID100ProfilePage fillRequiredProfileFormData(Candidate candidate) {
        SeleniumTest.clearAndSetText(firstNameTextbox, candidate.getFirstName());
        if(!candidate.getMiddleName().isEmpty()) {
            SeleniumTest.clearAndSetText(middleNameTextbox, candidate.getMiddleName());
        }
        else {
            if(!noMiddleNameCheckbox.isSelected()) {
                noMiddleNameCheckbox.click();
            }
        }
        SeleniumTest.clearAndSetText(lastNameTextbox, candidate.getLastName());
        SeleniumTest.clearAndSetText(ssnTextbox, candidate.getSocialSecurityNumber());
        if(!dobTextbox.getAttribute("value")
                .equals(candidate.getDOB()
                                .format(LocaleHelper.getDateFormatShortDateSlash())));
        {
            SeleniumTest.clearAndSetText(dobTextbox,
                                         candidate
                                                 .getDOB()
                                                 .format(LocaleHelper.getDateFormatShortDateSlash()));
        }
        SeleniumTest.clearAndSetText(streetAddressTextbox, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(apartmentNumberBox, candidate.getApartmentNumber());
        SeleniumTest.clearAndSetText(cityTextbox, candidate.getCity());
        FormID100ProfilePage.selectCountry(candidate.getCountryOrRegion());
        FormID100ProfilePage.selectState(candidate.getState());
        SeleniumTest.clearAndSetText(zipTextbox, candidate.getZip());
        SeleniumTest.clearAndSetText(primaryPhoneNumberTextbox, candidate.getCandidatePhone());
        return PageFactory.initElements(Driver.getDriver(), FormID100ProfilePage.class);
    }

    public static boolean isSsnTextBoxVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(ssnTextBoxLocator);
    }

    public static void typeSsn(String ssn) {
        SeleniumTest.clearAndSetText(ssnTextbox, ssn);
    }

    public static void typeDob(String dob){
        SeleniumTest.clearAndSetText(dobTextbox,dob);
    }
    /**
     * Selects the country
     * @param country
     */
    public static void selectCountry(String country) {
        final Select selection = new Select(countryDropdown);
        WaitUntil.waitUntil(6,2,() -> selection.getOptions().size() > 5);
        selection.selectByVisibleText(country);
    }

    /**
     * Selects the state or province
     * @param state
     */
    public static void selectState(String state) {
        final Select selection = new Select(stateDropdown);
        WaitUntil.waitUntil(6,2,() -> selection.getOptions().size() > 5);
        selection.selectByVisibleText(state);
    }

    /**
     * Click on the save button.
     */
    public void save()
    {
        saveButton.click();
    }

    /**
     * Click on Next button
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        SeleniumTest.waitForElementToBeClickable(nextButton);
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Method to fill Address information in the form.
     * @param candidateInfo
     *
     */
    public static void fillAddressInformation(Map<String, String> candidateInfo)
    {
        SeleniumTest.clearAndSetText(streetAddressTextbox, candidateInfo.get("CANDIDATE_STREET_ADDRESS"));
        SeleniumTest.clearAndSetText(apartmentNumberBox, candidateInfo.get("CANDIDATE_APARTMENT_NUMBER"));
        SeleniumTest.clearAndSetText(cityTextbox, candidateInfo.get("CANDIDATE_CITY"));

        SeleniumTest.selectByValueFromDropDown(countryDropdown, candidateInfo.get("CANDIDATE_COUNTRY"));
        SeleniumTest.selectByValueFromDropDown(stateDropdown, candidateInfo.get("CANDIDATE_STATE"));

        SeleniumTest.clearAndSetText(zipTextbox, candidateInfo.get("CANDIDATE_ZIP"));
    }

    public static void fillAddressInformation(Candidate candidate)
    {
        SeleniumTest.clearAndSetText(streetAddressTextbox, candidate.getAddressLine1());
        SeleniumTest.clearAndSetText(apartmentNumberBox, candidate.getApartmentNumber());
        SeleniumTest.clearAndSetText(cityTextbox, candidate.getCity());

        SeleniumTest.selectByVisibleTextFromDropDown(countryDropdown, candidate.getCountryOrRegion() );
        SeleniumTest.selectByVisibleTextFromDropDown(stateDropdown, candidate.getState());

        SeleniumTest.clearAndSetText(zipTextbox, candidate.getZip());
    }

    /**
     * Method to type Primary and other phone number
     * @param primaryPhone
     * @param otherPhone
     */
    public static void contactInformation(String primaryPhone, String otherPhone)
    {
        SeleniumTest.clearAndSetText(primaryPhoneNumberTextbox, primaryPhone);
        SeleniumTest.clearAndSetText(otherPhoneTextbox, otherPhone);
    }

    /**
     * Method to type only the Primary Phone number
     * @param primaryPhone
     */
    public static void contactInformation(String primaryPhone)
    {
        SeleniumTest.clearAndSetText(primaryPhoneNumberTextbox, primaryPhone);
    }

    /**
     *
     * @param firstName
     * @param middleName
     * @param lastName
     */
    public void verifyName(String firstName, String middleName, String lastName)
    {
        System.out.println(firstNameTextbox.getText());
        /*TODO: Need to figure out why the getText is returning empty string */
        //Assert.assertEquals(firstName, firstNameTextbox.getText());
        //Assert.assertEquals(middleName, middleNameTextbox.getText());
        //Assert.assertEquals(lastName, lastNameTextbox.getText());
    }

    /**
     * Method to fill Address information in the form.
     * @param streetAddress
     * @param apt
     * @param city
     * @param country
     * @param state
     * @param zip
     */
    public static void fillAddressInformation(String streetAddress, String apt, String city, String country, String state, String zip) {
        SeleniumTest.clearAndSetText(streetAddressTextbox, streetAddress);
        SeleniumTest.clearAndSetText(apartmentNumberBox, apt);
        SeleniumTest.clearAndSetText(cityTextbox, city);

        Select countryDD = new Select(countryDropdown);
        if(country.length() < 3)
            countryDD.selectByValue(country);
        else
            countryDD.selectByVisibleText(country);

        Select stateDD = new Select(stateDropdown);
        if(state.length() < 3)
            stateDD.selectByValue(state);
        else
            stateDD.selectByVisibleText(state);

        SeleniumTest.clearAndSetText(zipTextbox, zip);
    }

    /**
     * Types name in Mother's Maiden Name Textbox
     * @param name
     */
    public static void typeMothersMaidenName(String name) {
        SeleniumTest.clearAndSetText(maidenNameTextbox, name);
    }

    /**
     *
     * @param candidate
     * @return
     */
    public static StateTaxFormsSelector fillFormID100ProfilePage(Candidate candidate)
    {
        SeleniumTest.waitForElementVisible(By.id("100-qmi-100_2-100_2"));
        fillAddressInformation(candidate);
        contactInformation(candidate.getCandidatePhone(),candidate.getCandidatePhone());
        return (StateTaxFormsSelector) clickNext(StateTaxFormsSelector.class);
    }
}
