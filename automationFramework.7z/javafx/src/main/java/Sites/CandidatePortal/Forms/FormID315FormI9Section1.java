package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 12/11/2015.
 */
public class FormID315FormI9Section1 extends FormPage {
    @FindBy(how = How.ID, using = "315-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    /**
     * Presses the next button
     * @return
     */
    public FormID314I9WorksheetCompliance clickNextButton() {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID314I9WorksheetCompliance.class);
    }
}
