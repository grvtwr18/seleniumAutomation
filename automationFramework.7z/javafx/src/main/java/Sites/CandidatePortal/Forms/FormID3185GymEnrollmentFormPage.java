package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 6/8/2016.
 */
public class FormID3185GymEnrollmentFormPage extends RichFormsBase {

    @FindBy(how = How.ID, using = "3185-3185_6")
    private static WebElement name;

    @FindBy(how = How.ID, using = "3185-100_14")
    private static WebElement workPhoneNumber;

    @FindBy(how = How.ID, using = "3185-3185_34")
    private static WebElement emergencyContactNameTextField;

    @FindBy(how = How.ID, using = "3185-3185_35")
    private static WebElement emergencyContactPhoneNumberField;

    @FindBy(how = How.ID, using = "3185-3185_39")
    private static WebElement floatingTextField;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_36']")
    private static WebElement authorizationSignHereCheckBox;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_5_Yes']")
    private static WebElement one_HeartRadioButtonYes;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_5_No']")
    private static WebElement one_HeartRadioButtonNo;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_22_Yes']")
    private static WebElement two_ChestPainActiveRadioButtonYes;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_22_No']")
    private static WebElement two_ChestPainActiveRadioButtonNo;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_24_Yes']")
    private static WebElement three_ChestPainInactiveRadioButtonYes;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_24_No']")
    private static WebElement three_ChestPainInactiveRadioButtonNo;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_26_Yes']")
    private static WebElement four_DizzyRadioButtonYes;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_26_No']")
    private static WebElement four_DizzyRadioButtonNo;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_28_Yes']")
    private static WebElement five_BoneRadioButtonYes;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_28_No']")
    private static WebElement five_BoneRadioButtonNo;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_30_Yes']")
    private static WebElement six_DrugsRadioButtonYes;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_30_No']")
    private static WebElement six_DrugsRadioButtonNo;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_32_Yes']")
    private static WebElement seven_AnyRadioButtonYes;

    @FindBy(how = How.XPATH, using = "//label[@for='3185-3185_32_No']")
    private static WebElement seven_AnyRadioButtonNo;

    private static ThreadLocal<FormID3185GymEnrollmentFormPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(Driver.getDriver(),
                FormID3185GymEnrollmentFormPage.class));
    }

    private static FormID3185GymEnrollmentFormPage getInstance() {
        return threadLocalInstance.get();
    }

    public static boolean isAuthorizationSignHereCheckBoxVisible() {
        // this returns false even if we are scrolled to it
        // TODO: test this with the dynamic loading
        return getInstance().authorizationSignHereCheckBox.isDisplayed();
    }

    public static WebElement getEmergencyContactNameTextField() {
        return getInstance().emergencyContactNameTextField;
    }

    public static void setEmergencyContactNameTextField(String newEmergencyContactName) {
        SeleniumTest.clearAndSetText(getInstance().emergencyContactNameTextField, newEmergencyContactName);
    }

    public static WebElement getNameField() {
        return getInstance().name;
    }

    public static void setNameField(String newName) {
        SeleniumTest.clearAndSetText(getInstance().name, newName);
    }

    public static WebElement getWorkPhoneNumberField() {
        return getInstance().workPhoneNumber;
    }

    public static void setWorkPhoneNumberField(String newWorkPhoneNumber) {
        SeleniumTest.clearAndSetText(getInstance().workPhoneNumber, newWorkPhoneNumber);
    }

    public static WebElement getEmergencyContactPhoneNumberField() {
        return getInstance().emergencyContactPhoneNumberField;
    }

    public static void setEmergencyContactPhoneNumberField(
            String newEmergencyContactPhoneNumber) {
        SeleniumTest.clearAndSetText(getInstance().emergencyContactPhoneNumberField, newEmergencyContactPhoneNumber);
    }

    public static WebElement getFloatingTextField() {
        return getInstance().floatingTextField;
    }

    public static void setFloatingTextField(String newFloatingString) {
        SeleniumTest.clearAndSetText(getInstance().floatingTextField, newFloatingString);
    }

    public static WebElement getAuthorizationSignHereCheckBox() {
        return getInstance().authorizationSignHereCheckBox;
    }

    public static void clickAuthorizationSignHereCheckBox() {
        SeleniumTest.click(getInstance().authorizationSignHereCheckBox);
    }

    public static WebElement getOne_HeartRadioButtonYes() {
        return getInstance().one_HeartRadioButtonYes;
    }

    public static void clickOne_HeartRadioButtonYes() {
        SeleniumTest.click(getInstance().one_HeartRadioButtonYes);
    }

    public static void clickOne_HeartRadioButtonNo() {
        SeleniumTest.click(getInstance().one_HeartRadioButtonNo);
    }

    public static void clickTwo_ChestPainActiveRadioButtonYes() {
        SeleniumTest.click(getInstance().two_ChestPainActiveRadioButtonYes);
    }

    public static void clickTwo_ChestPainActiveRadioButtonNo() {
        SeleniumTest.click(getInstance().two_ChestPainActiveRadioButtonNo);
    }

    public static void clickThree_ChestPainInactiveRadioButtonYes() {
        SeleniumTest.click(getInstance().three_ChestPainInactiveRadioButtonYes);
    }

    public static void clickThree_ChestPainInactiveRadioButtonNo() {
        SeleniumTest.click(getInstance().three_ChestPainInactiveRadioButtonNo);
    }

    public static void clickFour_DizzyRadioButtonYes() {
        SeleniumTest.click(getInstance().four_DizzyRadioButtonYes);
    }

    public static void clickFour_DizzyRadioButtonNo() {
        SeleniumTest.click(getInstance().four_DizzyRadioButtonNo);
    }

    public static void clickFive_BoneRadioButtonYes() {
        SeleniumTest.click(getInstance().five_BoneRadioButtonYes);
    }

    public static void clickFive_BoneRadioButtonNo() {
        SeleniumTest.click(getInstance().five_BoneRadioButtonNo);
    }

    public static void clickSix_DrugsRadioButtonYes() {
        SeleniumTest.click(getInstance().six_DrugsRadioButtonYes);
    }

    public static void clickSix_DrugsRadioButtonNo() {
        SeleniumTest.click(getInstance().six_DrugsRadioButtonNo);
    }

    public static void clickSeven_AnyRadioButtonYes() {
        SeleniumTest.click(getInstance().seven_AnyRadioButtonYes);
    }

    public static void clickSeven_AnyRadioButtonNo() {
        SeleniumTest.click(getInstance().seven_AnyRadioButtonNo);
    }

    public static void fillOutAllTheThings() {
        getInstance().setEmergencyContactNameTextField("Clark Kent");
        getInstance().setEmergencyContactPhoneNumberField("425-888-1212");
        getInstance().setFloatingTextField("What is this field for?");

        getInstance().clickAuthorizationSignHereCheckBox();

        getInstance().clickOne_HeartRadioButtonYes();
        getInstance().clickTwo_ChestPainActiveRadioButtonNo();
        getInstance().clickThree_ChestPainInactiveRadioButtonYes();
        getInstance().clickFour_DizzyRadioButtonNo();
        getInstance().clickFive_BoneRadioButtonYes();
        getInstance().clickSix_DrugsRadioButtonNo();
        getInstance().clickSeven_AnyRadioButtonYes();
    }
}