package Sites.CandidatePortal.Forms.Objects;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.eda.eda;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by abrackett on 10/14/16.
 */
public class Navigation {

    protected static final Logger staticLogger = LoggerFactory.getLogger(Navigation.class);

    @FindBy(how = How.CSS, using = "button[id$='-nextbutton']")
    private static WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[id$='-savebutton']")
    private static WebElement saveButton;

    @FindBy(how = How.CSS, using = "button[id$='-previousbutton']")
    private static WebElement previousButton;

    @FindBy(how = How.CSS, using = "button[id$='-acceptButton']")
    private static WebElement completeTaskButton;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    static {
        PageFactory.initElements(Driver.getDriver(), Navigation.class);
    }

    public static void clickCompleteTask() {
        completeTaskButton.click();
        staticLogger.info("Clicked on Complete Task");
        SeleniumTest.waitForPageLoadToComplete();
    }


    public static void clickNext() {
        SeleniumTest.waitForElementToBeClickable(nextButton);
        nextButton.click();
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static CandidatePortalPages clickNext(
            Class<? extends CandidatePortalPages> returnedClass) {
        clickNext();
        SeleniumTest.waitForPageLoadToComplete();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static void clickSave() {
        saveButton.click();
    }

    public static void clickPrevious() {
        previousButton.click();
    }

    public static void clickSubmit() {
        // Oddly enough this submit button is generated on the fly so it does not properly
        // locate the button with the @FindBy utility.  Calling the find Element directly here
        // to ensure once it is created it can be found.
        Driver.getDriver().findElement(By.cssSelector("button[id$='-submitbutton']")).click();
    }

    public static void clickSignOut() {
        signOutLink.click();
    }

    public static class TwSign {

        @FindBy(how = How.ID, using = "acceptButton")
        private static WebElement agreeToSignButton;

        @FindBy(how = How.ID, using = "previewButton")
        private static WebElement proceedToESignPreviewButton;

        @FindBy(how = How.ID, using = "confirmButton")
        private static WebElement confirmAndSignFormsButton;

        @FindBy(how = How.XPATH, using = "//button[@class='button'][.,Save and Sign Later]")
        private static WebElement saveAndSignLaterButton;

        @FindBy(how = How.XPATH, using = "//a[contains(@onclick,'showEsignModal')]")
        private static WebElement declineLink;

        @FindBy(how = How.ID, using = "declineReason")
        private static WebElement reasonTextArea;

        @FindBy(how = How.ID, using = "declineButton")
        private static WebElement declineButton;

        static {
            PageFactory.initElements(Driver.getDriver(), TwSign.class);
        }

        /**
         * First Button to click in order to start TwSignature workflow
         */
        public static void clickIAgreeToUseAnElectronicSignature() {
            agreeToSignButton.click();
            staticLogger.info("Clicked I Agree to Use an Electronic Signature");
            WaitUntil.waitUntil(
                    () -> SeleniumTest.isElementVisible(proceedToESignPreviewButton),
                    NoSuchElementException.class);
        }

        /**
         * Follows clickIAgreeToUseAnElectronicSignature
         */
        public static void clickProceedToESignPreview() {
            proceedToESignPreviewButton.click();
            staticLogger.info("Clicked Proceed to eSign Preview");
            WaitUntil.waitUntil(60, 3,
                    () -> SeleniumTest.isElementVisible(confirmAndSignFormsButton),
                    NoSuchElementException.class);
        }

        /**
         * Follows clickProceedToESignPreview
         */
        public static void clickConfirmAndESignForms() {
            confirmAndSignFormsButton.click();
            staticLogger.info("Clicked Confirm and eSign Forms");
            SeleniumTest.waitForPageLoadToComplete();
        }

        /**
         * Follows clickProceedToESignPreview
         */
        public static void clickSaveAndSignLater() {
            saveAndSignLaterButton.click();
            staticLogger.info("Clicked Save and Sign Later");
            SeleniumTest.waitForPageLoadToComplete();
        }

        /**
         * Completes the TW eSign Workflow
         * @param logOut Optionally logs out
         */
        public static void completeTWeSign(boolean logOut) {
            SeleniumTest.waitForPageLoadToComplete();
            completeToPreviewPage();
            completeFromPreviewPage(logOut);
        }

        /**
         * Starts Signature Process and stops at the e-Sign Preview Page Richform
         */
        public static void completeToPreviewPage() {
            clickIAgreeToUseAnElectronicSignature();
            clickProceedToESignPreview();
        }

        /**
         * Completes Signature Process from Preview Page to completed e-Sign
         */
        public static void completeFromPreviewPage(boolean logOut) {
            clickConfirmAndESignForms();
            if(logOut) {
                CandidatePortalPages.signOut();
            }
        }

        public static void clickIDeclineLink() {
            declineLink.click();
        }

        public static void setDeclineReason(String reason) {
            SeleniumTest.clearAndSetText(reasonTextArea, reason);
            staticLogger.info("Text Area set to {}", reason);
        }

        public static void clickDeclineButton() {
            declineButton.click();
            staticLogger.info("Decline to Sign Button pressed");
        }
    }

    public static class RichFormFieldNav {
        @FindBy(how = How.ID, using = "nextbtnaction")
        private static WebElement nextEntryButton;

        static {
            PageFactory.initElements(Driver.getDriver(), RichFormFieldNav.class);
        }

        public static void clickNextEntry() {
            nextEntryButton.click();
        }

    }
    public static class Form {
        static {
            PageFactory.initElements(Driver.getDriver(), Form.class);
        }

        /**
         * Grab all the links found within the task nav div
         */
        @FindBy(how = How.XPATH, using = "//div[@class='taskNav']")
        public static WebElement TaskNavDiv;

        public static void jumpTo(String navString) {
            Driver.getDriver().findElement(By.xpath("//a[text()='" + navString + "']")).click();
            SeleniumTest.waitForPageLoadToComplete();
        }
        /**
         * Will click a task nav link based on the name of the link
         *
         * @param formName
         */
        public static void goTo(String formName) {
            WebElement linkEle = getFormLinkElement(formName);
            if (null != linkEle) {
                linkEle.click();
            }
        }

        /**
         *
         * @param which The display name of the task nav link
         */
        private static WebElement getFormLinkElement(String which) {
            List<WebElement> aLinks = getAllFormLinkElements();
            for (int i = 0; i < aLinks.size(); i++) {
                WebElement linkEle = aLinks.get(i);
                if (linkEle.getText().equals(which)) {
                    // found it
                    return linkEle;
                }
            }
            return null;
        }

        private static List<WebElement> getAllFormLinkElements() {
            return TaskNavDiv.findElements(By.cssSelector("a"));
        }
    }

    public static class EDA {

        @FindBy(how = How.XPATH, using = "//input[@type='submit'][contains(@onclick, 'submitConsent')]")
        private static WebElement iAgreeToUseElectronicSignatureButton;

        @FindBy(how = How.XPATH, using = "//input[@type='submit'][contains(@value,'>>')]")
        private static WebElement continueButton;

        @FindBy(how = How.ID, using = "submitEdaButton")
        private static WebElement iUnderstandAndAgreeButton;

        public static void clickIAgreeToUseElectronicSignature() {
            SeleniumTest.waitForPageLoadToComplete();
            iAgreeToUseElectronicSignatureButton.click();
        }

        public static void clickContinue() {
            SeleniumTest.waitForPageLoadToComplete();
            continueButton.click();
        }

        public static void clickIUnderstandAndAgree() {
            SeleniumTest.waitForPageLoadToComplete();
            iUnderstandAndAgreeButton.click();
        }

        public static void clickThroughEDAToComplete(boolean signOut) {
            clickIAgreeToUseElectronicSignature();
            clickContinue();
            clickContinue();
            eda.getInstance().checkIHaveCarefullyReadAndUnderstand();
            clickIUnderstandAndAgree();
            SeleniumTest.waitForPageLoadToComplete();
            if (signOut) {
                CandidatePortalPages.signOut();
            }
        }
    }
}
