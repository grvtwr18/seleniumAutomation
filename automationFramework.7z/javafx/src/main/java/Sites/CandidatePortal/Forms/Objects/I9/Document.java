package Sites.CandidatePortal.Forms.Objects.I9;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.format.DateTimeFormatter;

/**
 * Created by btorbert on 2/10/17.
 */
public class Document {

    private static final Logger staticLogger = LoggerFactory.getLogger(Document.class);

    public static class Helper
    {

        public static void setDocumentNumber(WorkEligibilityDocument doc) {
            if ("c" == doc.getType() && Section2.Documents.ListCDocuments.SOCIAL_SECURITY_CARD == doc.getDocLocation()) {
                staticLogger.info("SSC has no input field");
                return;
            }

            SeleniumTest.clearAndSetText(getDocumentNumberElement(doc.getDocLocation()), doc.getDocNumber());
            staticLogger.info("Document Number set to {}", doc.getDocNumber());
        }

        public static void selectDocumentTypeInReverify(WorkEligibilityDocument doc) {
            staticLogger.info("Selecting Document Type {}", doc.getTitle());
            SeleniumTest.selectByVisibleTextFromDropDown(Section3.SectionC.ListDocumentDropDown, doc.getTitle());
            return;
        }

        public static WebElement getDocumentNumberElement(DocumentLocation document) {
            staticLogger.info("Get Document Number");
            return Driver.getDriver().findElement(
                    By.cssSelector("input[id$='" + document.getDocumentNumberId() + "']"));
        }

        public static void setExpirationDate(WorkEligibilityDocument doc) {
            if (!doc.isHasExpDate()) {
                staticLogger.info("Document has no expiration field");
                return;
            }

            if (doc.getExpDate() == null) {
                getExpirationDateNaLabel(doc.getDocLocation()).click();
                // TODO Determine if the box is checked before just checking it
            } else {
                // do all the other work
                WebElement expirationDateControl = getExpirationDateControlElement(doc.getDocLocation());
                WebElement hiddenExpirationDateControl = Driver.getDriver().findElement(
                        By.cssSelector(
                                "input[id$='" + doc.getDocLocation().getExpirationId() + "'" + "][type$='hidden']"));
                SeleniumTest.FireFoxWorkArounds
                        .setCalendarControl_MM_Slash_dd_Slash_yyyy(doc.getExpDate(), expirationDateControl
                                .getAttribute("id"), hiddenExpirationDateControl
                                .getAttribute("id"));
                staticLogger.info("Expiration Date set to {}", doc.getExpDate().format
                        (DateTimeFormatter.ofPattern("MM/dd/yyyy")));
            }
        }

        public static WebElement getExpirationDateControlElement(DocumentLocation document) {
            return Driver.getDriver().findElement(
                    By.cssSelector("input[id$='" + document.getExpirationId() + "'][type$='text']"));
        }

        public static void setExpirationDateNa(WorkEligibilityDocument document) {
            WebElement expirationDateNaControl = getExpirationDateNaLabel(document.getDocLocation());
            expirationDateNaControl.click();
        }

        public static WebElement getExpirationDateNaLabel(DocumentLocation document) {
            return Driver.getDriver().findElement(
                    By.cssSelector("label[for$='" + document.getExpirationNaId() + "']"));
        }
    }

}