package Sites.CandidatePortal.Forms.tax.state.NorthCarolina;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Form_4070 {

    @FindBy(how = How.ID, using = "4070-100_1")
    private WebElement firstName;

    @FindBy(how = How.ID, using = "4070-100_3")
    private WebElement lastName;

    @FindBy(how = How.ID, using = "4070-100_5")
    private WebElement socialSecurityNumber;

    @FindBy(how = How.ID, using = "4070-100_7")
    private WebElement homeAddress;

    @FindBy(how = How.ID, using = "4070-100_8")
    private WebElement apartmentNumber;

    @FindBy(how = How.ID, using = "4070-div-100_10")
    private WebElement city;

    @FindBy(how = How.ID, using = "4070-div-100_11")
    private WebElement state;

    @FindBy(how = How.ID, using = "4070-div-100_12")
    private WebElement zip;

    @FindBy(how = How.ID, using = "22642-22537_1_Single")
    private WebElement singleCheckBox;


    @FindBy(how = How.ID, using = "4070-1854_7")
    private WebElement allowance;

    @FindBy(how = How.ID, using = "4070-1854_9")
    private WebElement additionalAmount;


    private WebElement rdoFillingStatus(String filling) {
        return Driver.getDriver().findElement(By.xpath("//input[@id='4070-1854_10_" + filling + "']"));
    }

    public static Form_4070 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_4070.class);
    }

    public String getFirstName() {
        return firstName.getText();
    }

    public String getLastName() {
        return lastName.getText();
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber.getText();
    }

    public String getHomeAddress() {
        return homeAddress.getText();
    }

    public String getApartmentNumber() {
        return apartmentNumber.getText();
    }

    public String getCity() {
        return city.getText();
    }

    public String getState() {
        return state.getText();
    }

    public String getZip() {
        return zip.getText();
    }

    public String getAllowanceAmount() {
        return allowance.getText();
    }

    public String getAdditionalAmount() {
        return additionalAmount.getText();
    }

    public boolean isMaritalStatusDisplayed(String filling) {
        try {
            rdoFillingStatus(filling);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}
