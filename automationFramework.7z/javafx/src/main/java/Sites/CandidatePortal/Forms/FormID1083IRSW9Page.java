package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 8/13/2015.
 */

public class FormID1083IRSW9Page extends FormPage {

    @FindBy(how = How.ID, using = "1083-1239_2")
    private WebElement nameAsInIncomeTaxReturnTextBox;

    @FindBy(how = How.ID, using = "1083-1239_3")
    private WebElement businessNameTextBox;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_4_Individual/sole proprietor']")
    private WebElement individualSoleProprietorRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_4_C Corporation']")
    private WebElement cCorporationRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_4_S Corporation']")
    private WebElement sCorporationRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_4_Partnership']")
    private WebElement partnershipRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_4_Trust/estate']")
    private WebElement trustEstateRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_4_Limited liability company']")
    private WebElement limitedLiabilityCompanyRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_4_Other']")
    private WebElement otherRadioBtn;

    @FindBy(how = How.ID, using = "1083-1239_17")
    private WebElement exemptPayeeCodeDropdown;

    @FindBy(how = How.ID, using = "1083-1239_18")
    private WebElement exemptionFromFATCADropdown;

    @FindBy(how = How.ID, using = "1083-1239_8")
    private WebElement ssnTextbox;

    @FindBy(how = How.ID, using = "1083-1239_9")
    private WebElement employeeIdentificationNumberTextbox;

    @FindBy(how = How.CSS, using = "label[for='1083-616_17']")
    private WebElement certificationRequirementCheckbox;

    @FindBy(how = How.CSS, using = "label[for='1083-1239_13']")
    private WebElement signatureCheckbox;

    @FindBy(how = How.CSS, using = "button[value='Previous']")
    private WebElement previousButton;

    @FindBy(how = How.ID, using = "1083-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.CSS, using = "button[value='Save']")
    private WebElement saveButton;

    /**
     * Constructs a new W9 Form page object.
     * @author guptaj
     */
    public FormID1083IRSW9Page() {

    }

    /**
     * Fills W-9 Form
     * @param name
     * @param businessName
     * @param federalTaxClassification
     * @param exemptPayeeCode
     * @param exemptPayeeFATCACode
     * @param ssn
     * @param employeeIdentificationNumber
     * @param certificationRequirementFlag
     * @param signatureFlag
     */
    public void fillW9Form(
            String name,
            String businessName,
            String federalTaxClassification,
            String exemptPayeeCode,
            String exemptPayeeFATCACode,
            String ssn,
            String employeeIdentificationNumber,
            String certificationRequirementFlag,
            String signatureFlag
    )
    {
        SeleniumTest.clearAndSetText(nameAsInIncomeTaxReturnTextBox, name);
        SeleniumTest.clearAndSetText(businessNameTextBox, businessName);

        if (federalTaxClassification=="Individual/sole proprietor")
            individualSoleProprietorRadioBtn.click();
        else if (federalTaxClassification=="C Corporation")
            cCorporationRadioBtn.click();
        else if (federalTaxClassification=="S Corporation")
            sCorporationRadioBtn.click();
        else if (federalTaxClassification=="Partnership")
            partnershipRadioBtn.click();
        else if (federalTaxClassification=="Trust/estate")
            trustEstateRadioBtn.click();
        else if (federalTaxClassification=="Limited liability company")
            limitedLiabilityCompanyRadioBtn.click();
        else if (federalTaxClassification=="Other")
            otherRadioBtn.click();

        SeleniumTest.selectByVisibleTextFromDropDown(exemptPayeeCodeDropdown, exemptPayeeCode);

        SeleniumTest.selectByVisibleTextFromDropDown(exemptionFromFATCADropdown, exemptPayeeFATCACode);

        SeleniumTest.clearAndSetText(ssnTextbox, ssn);
        SeleniumTest.clearAndSetText(employeeIdentificationNumberTextbox, employeeIdentificationNumber);

        if(certificationRequirementFlag=="true")
            certificationRequirementCheckbox.click();

        if (signatureFlag=="true")
            signatureCheckbox.click();
    }

    /**
     * Click on Save button
     */
    public void save()
    {
        saveButton.click();
    }

    /**
     * Click on Next button.
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
