package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.FormID100ProfilePage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by abrackett on 8/3/17.
 */
public class StateTaxFormsSelector extends CandidatePortalPages {

    @FindBy(how = How.CSS, using = "select[id$='1972_5']")
    private WebElement firstLocationSelector;

    @FindBy(how = How.CSS, using = "select[id$='1972_7']")
    private WebElement secondLocationSelector;

    @FindBy(how = How.CSS, using = "select[id$='1972_9']")
    private WebElement thirdLocationSelector;

    @FindBy(how = How.CSS, using = "label[for$='1972_139']")
    private WebElement iConfirmLabel;

    @FindBy(how = How.CSS, using = "input[id$='1972_139']")
    private WebElement iConfirmCheckbox;

    @FindBy(how = How.ID, using = "1972-previousnextbuttons-nextbutton")
    private WebElement nextBtn;

    @FindBy(how = How.XPATH,using = "//label[@for='1972-1972_22_Federal W-4']")
    private WebElement federalW4Label;

    @FindBy(how = How.ID, using = "1972-1972_22_Federal W-4")
    private WebElement federalW4Checkbox;

    @FindBy(how = How.ID, using = "1972-1972_66")
    private WebElement selectMichiganStateCity;

    @FindBy(how = How.ID,using = "1972-label-1972_66")
    private WebElement selectMichiganStateCityLabel;

    @FindBy(how = How.XPATH,using = "//label[@for='1972-1972_97_NC-4']")
    private WebElement NC4RadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1972-1972_161_Pennsylvania Withholding']")
    private WebElement PennsylvaniaWWithholdingRadioButton;

    @FindBy(how = How.XPATH,using = "//label[@for='1972-1972_155_Yes']")
    private WebElement PennsylvaniaResidencyStatusYesRadioButton;

    @FindBy(how = How.ID, using = "1972-1972_5")
    private WebElement select;

    public static StateTaxFormsSelector getInstance() {
        return PageFactory.initElements(Driver.getDriver(), StateTaxFormsSelector.class);
    }

    public String getFirstLocationSelectedItem() {
        return new Select(firstLocationSelector).getFirstSelectedOption().getText();
    }

    public StateTaxFormsSelector selectFirstLocation(String selection) {
        SeleniumTest.selectByVisibleTextFromDropDown(firstLocationSelector, selection);
        return this;
    }

    public String getSecondLocationSelectedItem() {
        return new Select(secondLocationSelector).getFirstSelectedOption().getText();
    }

    public StateTaxFormsSelector selectSecondLocation(String selection) {
        SeleniumTest.selectByVisibleTextFromDropDown(secondLocationSelector, selection);
        return this;
    }

    public String getThirdLocationSelectedItem() {
        return new Select(thirdLocationSelector).getFirstSelectedOption().getText();
    }

    public StateTaxFormsSelector selectThirdLocation(String selection) {
        SeleniumTest.selectByVisibleTextFromDropDown(thirdLocationSelector, selection);
        return this;
    }

    public StateTaxFormsSelector checkIConfirm() {
        SeleniumTest.check(iConfirmLabel, iConfirmCheckbox);
        return this;
    }

    public StateTaxFormsSelector uncheckIConfirm() {
        SeleniumTest.unCheck(iConfirmLabel, iConfirmCheckbox);
        return this;
    }

    public CandidatePortalPages clickNextBtn(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextBtn);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public StateTaxFormsSelector checkFederalW4() {
        if(!SeleniumTest.getText(federalW4Label).isEmpty())
        {
            SeleniumTest.check(federalW4Label, federalW4Checkbox);

        }
        return this;
    }

    public StateTaxFormsSelector selectMichiganStateCity(String stateName,String cityName)
    {
        if(SeleniumTest.getText(selectMichiganStateCityLabel).contains(stateName))
        {
            SeleniumTest.selectByVisibleTextFromDropDown(selectMichiganStateCity,cityName);
        }
        return this;
    }

    public StateTaxFormsSelector selectNC4Option()
    {
        staticLogger.info("NC-4 option selected");
        SeleniumTest.click(NC4RadioButton);
        return this;
    }

    public StateTaxFormsSelector pennsylvaniaStateWithholdingFormOption()
    {
        SeleniumTest.click(PennsylvaniaWWithholdingRadioButton);
        return this;
    }

    public StateTaxFormsSelector pennslyvaniaResidencyStatusOption()
    {
        SeleniumTest.click(PennsylvaniaResidencyStatusYesRadioButton);
        return this;
    }
}
