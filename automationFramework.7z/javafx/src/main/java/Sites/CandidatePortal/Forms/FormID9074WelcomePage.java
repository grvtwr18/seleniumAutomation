package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import WebDriver.Driver;

/**
 * Created by abrackett on 12/17/2015.
 */
public class FormID9074WelcomePage extends FormPage {
    @FindBy(how = How.ID, using = "9074-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    @FindBy(how = How.ID, using = "9024-I9s1_1")
    private static WebElement firstNameBox;
    /**
     * Clicks next Button
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.waitForPageLoadToComplete();
        SeleniumTest.waitForElementToBeClickable(nextButton);
        nextButton.click();
        SeleniumTest.waitForElementVisible(firstNameBox);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
