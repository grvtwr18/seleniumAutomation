package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by jgupta on 3/18/2016.
 */
public class FormID2208EmploymentInformationPage extends FormPage {
    @FindBy(how = How.CSS, using = "button[value='Next']")
    private static WebElement nextButton;

    @FindBy(how = How.ID, using = "2208-history-2-2208_1-2208_1_0-2208_1_0")
    private static WebElement fromDateTextBox;

    @FindBy(how = How.ID, using = "2208-history-2-2208_1-2208_2_0-2208_2_0")
    private static WebElement toDateTextBox;

    @FindBy(how = How.CSS, using = "label[for='2208-history-2-2208_1-2208_4_0_Still Employed']")
    private static WebElement stillEmployedRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2208-history-2-2208_1-2208_4_0_Resigned']")
    private static WebElement resignedRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2208-history-2-2208_1-2208_4_0_Terminated']")
    private static WebElement terminatedRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2208-history-2-2208_1-2208_4_0_Laid Off']")
    private static WebElement laidOffRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2208-history-2-2208_1-2208_4_0_Other']")
    private static WebElement otherRadioBtn;

    @FindBy(how = How.CSS, using = "input[fieldname='Job Title']")
    private static WebElement jobTitleTextBox;

    @FindBy(how = How.CSS, using = "input[fieldname='Name of Employer']")
    private static WebElement nameOfEmployerTextBox;

    @FindBy(how = How.CSS, using = "input[fieldname='Phone']")
    private static WebElement phoneTextBox;

    @FindBy(how = How.ID, using = "2208-history-2-2208_1-address2208_8_0-2208_9_0")
    private static WebElement cityTextBox;

    @FindBy(how = How.ID, using = "2208-history-2-2208_1-address2208_8_0-2208_8_0")
    private static WebElement countryDropDown;

    @FindBy(how = How.ID, using = "2208-history-2-2208_1-address2208_8_0-2208_10_0")
    private static WebElement stateDropDown;

    @FindBy(how = How.CSS, using = "label[for='2208-history-2-2208_1-2208_13_0_Yes']")
    private static WebElement employedUnderPreviousNameYesRadioBtn;

    @FindBy(how = How.CSS, using = "label[for='2208-history-2-2208_1-2208_13_0_No']")
    private static WebElement employedUnderPreviousNameNoRadioBtn;

    private static final String removeHistoryString = "historyRemove";

    /**
     * Clicks Next
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Fill the Mandatory fields of Employment Information form
     * @param fromDate
     * @param toDate
     * @param employmentStatus
     * @param jobTitle
     * @param nameOfEmployer
     * @param phone
     * @param city
     * @param country
     * @param state
     * @param isEmployedUnderPreviousName
     */
    public static void fillEmployment1MandatoryFields(String fromDate, String toDate, String employmentStatus, String jobTitle, String nameOfEmployer, String phone, String city, String country, String state, String isEmployedUnderPreviousName ){
        SeleniumTest.clearAndSetText(fromDateTextBox, fromDate, true);
        SeleniumTest.clearAndSetText(toDateTextBox, toDate, true);
        selectEmploymentStatus(employmentStatus);
        SeleniumTest.clearAndSetText(jobTitleTextBox, jobTitle);
        SeleniumTest.clearAndSetText(nameOfEmployerTextBox, nameOfEmployer);
        SeleniumTest.clearAndSetText(phoneTextBox, phone);
        SeleniumTest.clearAndSetText(cityTextBox, city);
        Select countryDD = new Select(countryDropDown);
        countryDD.selectByVisibleText(country);
        Select stateDD = new Select(stateDropDown);
        stateDD.selectByVisibleText(state);
        selectHasPreviousNameOption(isEmployedUnderPreviousName);
    }

    /**
     * Select the option if the user is employed under previous name
     * @param isEmployedUnderPreviousName
     */
    private static void selectHasPreviousNameOption(String isEmployedUnderPreviousName) {
        if (isEmployedUnderPreviousName.equals("Yes")) {
            employedUnderPreviousNameYesRadioBtn.click();
        }
        else {
            employedUnderPreviousNameNoRadioBtn.click();
        }
    }

    /**
     * Selects the employment status option.
     * @param employmentStatus
     */
    private static void selectEmploymentStatus(String employmentStatus) {
        switch (employmentStatus) {
            case "Still Employed":
                stillEmployedRadioBtn.click();
                break;
            case "Resigned":
                resignedRadioBtn.click();
                break;
            case "Terminated":
                terminatedRadioBtn.click();
                break;
            case "Laid Off":
                laidOffRadioBtn.click();
                break;
            default:
                otherRadioBtn.click();
                break;
        }
    }

    /**
     * Remove History Entry
     * @param index One based index of the history to remove
     */
    public static void removeHistory(Integer index) {
        Driver.getDriver().findElement(By.id(removeHistoryString + (index -1))).click();
    }
}
