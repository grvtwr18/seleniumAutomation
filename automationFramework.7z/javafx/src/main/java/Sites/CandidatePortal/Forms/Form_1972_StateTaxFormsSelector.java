package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.tier1.e2e.accountable.batch.management.Form_16647_PriorEmployment;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_1972_StateTaxFormsSelector extends CandidatePortalPages {
    @FindBy(how = How.ID, using = "1972-1972_139")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1972-1972_139']")
    private WebElement iAcknowledgeLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='1972-1972_159_Form A-4']")
    private WebElement arizonaFormA4Radiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1972-1972_159_Form A-4V']")
    private WebElement arizonaFormA4VRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1972-1972_97_NC-4']")
    private WebElement ncFormN4Radiobutton;

    protected Logger logger = LoggerFactory.getLogger(Form_1972_StateTaxFormsSelector.class);

    public static Form_1972_StateTaxFormsSelector getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Form_1972_StateTaxFormsSelector.class);
    }

    public Form_1972_StateTaxFormsSelector checkIAcknowledge() {
        SeleniumTest.check(getInstance().iAcknowledgeLabel, getInstance().iAcknowledgeCheckbox);
        logger.info("I Acknowledge Checked");
        return this;
    }

    public Form_1972_StateTaxFormsSelector uncheckIAcknowledge() {
        SeleniumTest.unCheck(getInstance().iAcknowledgeLabel, getInstance().iAcknowledgeCheckbox);
        logger.info("I Acknowledged Unchecked");
        return this;
    }

    public Form_1972_StateTaxFormsSelector chooseArizonaFormA4() {
        getInstance().arizonaFormA4Radiobutton.click();
        logger.info("Arizona Form A4 Chosen");
        return this;
    }

    public Form_1972_StateTaxFormsSelector chooseArizonaFormA4V() {
        getInstance().arizonaFormA4VRadiobutton.click();
        logger.info("Arizona Form A4V Chosen");
        return this;
    }

    public Form_1972_StateTaxFormsSelector chooseNorthCarolinaForm() {
        getInstance().ncFormN4Radiobutton.click();
        logger.info("North Carolina Form NC-4 Chosen");
        return this;
    }
}
