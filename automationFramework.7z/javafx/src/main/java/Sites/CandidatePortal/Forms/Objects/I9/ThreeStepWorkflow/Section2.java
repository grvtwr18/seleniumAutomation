package Sites.CandidatePortal.Forms.Objects.I9.ThreeStepWorkflow;

import Sites.CandidatePortal.Forms.Objects.I9.I9Base;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import java.time.LocalDate;

public class Section2 extends I9Base {

    static {
        PageFactory.initElements(Driver.getDriver(), Section2.class);
    }

    @FindBy(how = How.CSS, using = "label[for$='-311_2_List A']")
    private static WebElement listALabel;

    @FindBy(how = How.CSS, using = "input[id$='-311_2_List A']")
    private static WebElement listARadioButton;

    @FindBy(how = How.CSS, using = "label[for$='-311_2_List B and C']")
    private static WebElement listBCLabel;

    @FindBy(how = How.CSS, using = "input[id$='-311_2_List B and C']")
    private static WebElement listBCRadioButton;

    @FindBy(how = How.CSS, using = "select[id$='-311_4']")
    private static WebElement listADropDown;

    @FindBy(how = How.CSS, using = "select[id$='-311_20']")
    private static WebElement listA3DropDown;

    @FindBy(how = How.CSS, using = "select[id$='-311_25']")
    private static WebElement listBDropDown;

    @FindBy(how = How.CSS, using = "select[id$='-311_33']")
    private static WebElement listCDropDown;

    @FindBy(how = How.CSS, using = "select[id$='-311_26']")
    private static WebElement stateIdType;

    @FindBy(how = How.CSS, using = "div[id$='-formtitle']")
    private static WebElement formTitle;

    public static void resetFocus() {
        formTitle.click();
    }

    public static void fillDocumentData(EligibilityDocument eligibilityDocument) {
        Documents.ListDocuments document = eligibilityDocument.getDocument();
        String listType = document.getListType();
        switch(listType) {
            case "A":
                chooseListA();
                selectListADocument(document);
                break;
            case "B":
                chooseListBC();
                selectListBDocument(document);
                break;
            case "C":
                chooseListBC();
                selectListCDocument(document);
                break;
        }

        if (eligibilityDocument.isReceipt()) {
            Documents.checkReceipt(document);
        } else {
            Documents.uncheckReceipt(document);
        }

        Documents.setIssuingAuthority(document, eligibilityDocument.getIssuingAuthority());
        Documents.setDocumentNumber(document, eligibilityDocument.getDocumentNumber());
        if (eligibilityDocument.getExpirationDate() != null) {
            Documents.uncheckExpirationNa(document);
            Documents.setExpirationDate(document, eligibilityDocument.getExpirationDate());
        } else {
            Documents.checkExpirationNa(document);
        }

        resetFocus();
    }


    public static void chooseListA() {
        resetFocus();
        SeleniumTest.defaultWaitForElementWithMultiplier(.1);
        listALabel.click();
        SeleniumTest.waitForElementVisible(listADropDown);
    }

    public static void chooseListBC() {
        resetFocus();
        SeleniumTest.defaultWaitForElementWithMultiplier(.1);
        listBCLabel.click();
        SeleniumTest.waitForElementVisible(listBDropDown);
        SeleniumTest.waitForElementVisible(listCDropDown);
    }

    public static void selectListADocument(Documents.ListDocuments document) {
        if (document == Documents.ListDocuments.I_20 || document == Documents.ListDocuments.DS_2019 || document == Documents.ListDocuments.NA) {
            SeleniumTest.selectByValueFromDropDown(listA3DropDown, document.getValue());
        } else if(!document.getValue().isEmpty()) {
            SeleniumTest.selectByValueFromDropDown(listADropDown, document.getValue());
        }
    }

    public static void selectListBDocument(Documents.ListDocuments document) {
        SeleniumTest.selectByVisibleTextFromDropDown(listBDropDown, document.getName());
        if (document == Documents.ListDocuments.USSTATEID) {
            SeleniumTest.selectByVisibleTextFromDropDown(stateIdType, "ID Card");
        } else if (document == Documents.ListDocuments.USDRIVERSLICENSE) {
            SeleniumTest.selectByVisibleTextFromDropDown(stateIdType, "License");
        }
    }

    public static void selectListCDocument(Documents.ListDocuments document) {
        SeleniumTest.selectByVisibleTextFromDropDown(listCDropDown, document.getName());
    }

    public static class Documents {
        public enum ListDocuments {
            //                               Dropdown text,                     dropdown value,              list type, receipt ID, doc number id, issuing auth id, expiration id, expiration na id
            USPASSPORT(                        "US Passport",                     "US Passport",                     "A", "-311_134", "-311_6",  "-311_5",  "_12", "-311_153"),
            USPASSPORTCARD(                    "US Passport Card",                "US Passport Card",                "A", "-311_134", "-311_6",  "-311_5",  "_12", "-311_153"),
            PERMANENTRESIDENTCARD(             "Perm. Resident Card",             "Perm. Resident Card",             "A", "-311_134", "-311_9",  "-311_5",  "_12", "-311_153"),
            ALIENREGISTRATIONRECEIPTCARD(      "Alien Reg Card (I-551)",          "Alien Reg Card (I-551)",          "A", "-311_134", "-311_8",  "-311_5",  "_12", "-311_153"),
            FOREIGNPASSPORTWITHI_551STAMP(     "Foreign PP with I-551",           "Foreign PP with I-551",           "A", "-311_134", "-311_11", "-311_5",  "_12", "-311_153"),
            EMPLOYMENTAUTHORIZATIONDOCUMENT(   "Employment Auth (I-766)",         "Employment Auth (I-766)",         "A", "-311_134", "-311_7",  "-311_5",  "_12", "-311_153"),
            FOREIGNPASSPORTWITHI_94_AFORM(     "Foreign PP with I-94/A",          "Foreign PP with I-94/A",          "A", "-311_134", "-311_11", "-311_5",  "_12", "-311_153"),
            FSMPASSPORTWITHI_94_AFORM(         "FSM PP with I-94/A",              "FSM PP with I-94/A",              "A", "-311_134", "-311_11", "-311_5",  "_12", "-311_153"),
            RMIPASSPORTWITHI_94_AFORM(         "RMI PP with I-94/A",              "RMI PP with I-94/A",              "A", "-311_134", "-311_11", "-311_5",  "_12", "-311_153"),
            I_94_AFORMWITHREFUGEESTAMP(        "I-94/A w/Refugee Stamp",          "I-94/A w/Refugee Stamp",          "A", "-311_134", "-311_10", "-311_5",  "_12", "-311_153"),
            I_551STAMP(                        "I-551 Stamp/MRIV on Passport",    "",                                "A", "-311_177", "-311_17", "-311_16", "_18", "-311_175"),
            I_94A(                             "Form I-94 / I-94A",               "",                                "A", "-311_177", "-311_17", "-311_16", "_18", "-311_175"),
            NA(                                "N/A",                             "N/A",                             "A", "",         "",        "",        "",    "-311_176"),
            I_20(                              "I-20",                            "I-20",                            "A", "-311_178", "-311_22", "-311_21", "_23", "-311_176"),
            DS_2019(                           "DS-2019",                         "DS-2019",                         "A", "-311_178", "-311_22", "-311_21", "_23", "-311_176"),
            //                               Dropdown text,                     dropdown value,              list type, receipt ID, doc number id, issuing auth id, expiration id, expiration na id
            USDRIVERSLICENSE(                  "State Drivers License",           "State Drivers License",           "B", "-311_136", "-311_30", "-311_27", "_31", "-311_154"),
            USSTATEID(                         "State Drivers License",           "State Drivers License",           "B", "-311_136", "-311_30", "-311_27", "_31", "-311_154"),
            GOVERNMENTID(                      "Government Issued ID",            "Government Issued ID",            "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            SCHOOLID(                          "School ID with Photo",            "School ID with Photo",            "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            VOTERREGISTRATIONCARD(             "Voter Registration Card",         "Voter Registration Card",         "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            USMILITARYCARD(                    "US Military ID",                  "US Military ID",                  "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            MILITARYDEPENDENTIDCARD(           "Military Dependent ID",           "Military Dependent ID",           "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            USCOASTGUARDMERCHANTMARINERCARD(   "US CG Merchant Mariner Card",     "US CG Merchant Mariner Card",     "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            NATIVEAMERICANTRIBALDOCUMENTB(     "Native American Tribal Document", "Native American Tribal Document", "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            CAGOVERNMENTDRIVERSLICENSE(        "CA Government Drivers License",   "CA Government Drivers License",   "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            SCHOOLRECORD(                      "School Record",                   "School Record",                   "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            MEDICALRECORD(                     "Medical Record",                  "Medical Record",                  "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            PRE_SCHOOLRECORD(                  "Pre-school Record",               "Pre-school Record",               "B", "-311_136", "-311_29", "-311_28", "_31", "-311_154"),
            //                               Dropdown text,                     dropdown value,               list type, receipt ID, doc number id, issuing auth id, expiration id, expiration na id
            SOCIAL_SECURITY_CARD(              "Social Security Card",            "Social Security Card",            "C", "-311_138", "",        "-311_34", "_37", "-311_155"),
            BIRTHABROADCERTIFICATEFS_545(      "Birth Abroad Cert (FS-545)",      "Birth Abroad Cert (FS-545)",      "C", "-311_138", "-311_35", "-311_34", "_37", "-311_155"),
            BIRTHABROADCERTIFICATEDS_1350(     "Certification of Report of Birth (DS-1350)", "Certification of Report of Birth (DS-1350)", "C", "-311_138", "-311_35", "-311_34", "_37", "-311_155"),
            BIRTHCERTIFICATEWITHSEAL(          "Birth Certificate with Seal",     "Birth Certificate with Seal",     "C", "-311_138", "-311_35", "-311_34", "_37", "-311_155"),
            NATIVEAMERICANTRIBALDOCUMENTC(     "Native American Tribal Doc",      "Native American Tribal Doc",      "C", "-311_138", "-311_35", "-311_34", "_37", "-311_155"),
            USCITIZENIDCARD(                   "US Citizen ID",                   "US Citizen ID",                   "C", "-311_138", "-311_35", "-311_34", "_37", "-311_155"),
            RESIDENTID(                        "Resident Citizen ID",             "Resident Citizen ID",             "C", "-311_138", "-311_35", "-311_34", "_37", "-311_155"),
            DHSEMPLOYMENTAUTHORIZATIONDOCUMENT("DHS Emp. Auth. Doc",              "DHS Emp. Auth. Doc",              "C", "-311_138", "-311_35", "-311_34", "_37", "-311_155");

            private final String name;
            private final String value;
            private final String listType;
            private final String receiptId;
            private final String inputId;
            private final String issuingAuthId;
            public final String expirationDateId;
            private final String expirationDateNaId;

            ListDocuments(final String name, final String value, final String listType, final String receiptId, final String inputId, final String issuingAuthId, final String expirationDateId, final String  expirationDateNaId) {
                this.name = name;
                this.value = value;
                this.listType = listType;
                this.receiptId = receiptId;
                this.inputId = inputId;
                this.issuingAuthId = issuingAuthId;
                this.expirationDateId = expirationDateId; // We prepend -314 or -311 when setting for compliance, or verifier.
                this.expirationDateNaId = expirationDateNaId;
            }

            public String getName() {
                return this.name;
            }

            public String getValue() { return this.value; }

            public String getListType() { return this.listType; }

        }

        public static void checkReceipt(ListDocuments document) {
            if (!document.receiptId.isEmpty()) {
                WebElement checkbox = Driver.getDriver().findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));
                if (!checkbox.isSelected()) {
                    String checkboxId = checkbox.getAttribute("id");
                    WebElement label = Driver.getDriver().findElement(By.cssSelector("label[for='" + checkboxId + "']"));
                    WaitUntil.waitUntil(label::isDisplayed);
                    label.click();
                }
            }
        }

        public static void uncheckReceipt(ListDocuments document) {
            if (!document.receiptId.isEmpty()) {
                WebElement checkbox = Driver.getDriver().findElement(By.cssSelector("input[id$='" + document.receiptId + "']"));
                if (checkbox.isSelected()) {
                    String checkboxId = checkbox.getAttribute("id");
                    WebElement label = Driver.getDriver().findElement(By.cssSelector("label[for='" + checkboxId + "']"));
                    WaitUntil.waitUntil(label::isDisplayed);
                    label.click();
                }
            }
        }

        public static void setDocumentNumber(ListDocuments document, String number) {
            if (!document.inputId.isEmpty()) {
                WebElement textBox = Driver.getDriver().findElement(By.cssSelector("input[id$='" + document.inputId + "']"));
                WaitUntil.waitUntil(textBox::isDisplayed);
                SeleniumTest.clearAndSetText(textBox, number, true);
            }
        }

        public static void setIssuingAuthority(ListDocuments document, String authority) {
            if (!document.issuingAuthId.isEmpty()) {
                String xpathEndsWith = "substring(@id, string-length(@id) - string-length('" + document.issuingAuthId  + "') +1) = '" + document.issuingAuthId  + "'";
                WebElement element = Driver.getDriver().findElement(By.xpath("//input[" + xpathEndsWith + "]|//select[" + xpathEndsWith + "]"));
                WaitUntil.waitUntil(element::isDisplayed);
                if(element.getTagName().equals("input")) {
                    SeleniumTest.clearAndSetText(element, authority, true);
                } else if(element.getTagName().equals("select")) {
                    SeleniumTest.selectByVisibleTextFromDropDown(element, authority);
                }
            }
        }

        public static void setExpirationDate(ListDocuments document, LocalDate date) {
            if (!document.expirationDateId.isEmpty() && date != null) {
                String complianceId = "-314" + document.expirationDateId;
                String verifierId = "-311" + document.expirationDateId;
                WebElement dateControl = Driver.getDriver().findElement(By.cssSelector("input[id$='" + complianceId + "'][type='text'], input[id$='" + verifierId + "'][type='text']"));
                WebElement hiddenInput;

                WaitUntil.waitUntil(dateControl::isDisplayed);
                if (dateControl.getAttribute("id").endsWith(complianceId)) {
                    hiddenInput = Driver.getDriver().findElement(By.cssSelector("input[id$='" + complianceId + "'][type='hidden']"));
                } else {
                    hiddenInput = Driver.getDriver().findElement(By.cssSelector("input[id$='" + verifierId + "'][type='hidden']"));
                }
                SeleniumTest.FireFoxWorkArounds.setCalendarControl_MM_Slash_dd_Slash_yyyy(
                        date,
                        dateControl.getAttribute("id"),
                        hiddenInput.getAttribute("id"));
            }
        }

        public static void checkExpirationNa(ListDocuments document) {

            takeFocusAwayFromCalendarControl(document.expirationDateId);

            if (!document.expirationDateNaId.isEmpty()) {
                WebElement checkbox = Driver.getDriver().findElement(By.cssSelector("input[id$='" + document.expirationDateNaId + "']"));
                if (!checkbox.isSelected()) {
                    String checkboxId = checkbox.getAttribute("id");
                    WebElement label = Driver.getDriver().findElement(By.cssSelector("label[for='" + checkboxId + "']"));
                    WaitUntil.waitUntil(label::isDisplayed);
                    label.click();
                }
            }
        }

        public static void uncheckExpirationNa(ListDocuments document) {

            takeFocusAwayFromCalendarControl(document.expirationDateId);

            if (!document.expirationDateNaId.isEmpty()) {
                WebElement checkbox = Driver.getDriver().findElement(By.cssSelector("input[id$='" + document.expirationDateNaId + "']"));
                if (checkbox.isSelected()) {
                    String checkboxId = checkbox.getAttribute("id");
                    WebElement label = Driver.getDriver().findElement(By.cssSelector("label[for='" + checkboxId + "']"));
                    WaitUntil.waitUntil(label::isDisplayed);
                    label.click();
                }
            }
        }

        public static void takeFocusAwayFromCalendarControl(String expirationId) {
            try {
                final WebElement element =
                        ((EventFiringWebDriver)Driver.getDriver()).getWrappedDriver().findElement(By.cssSelector
                                ("input[id$='" + expirationId + "'][class='hasDatepicker "
                                 + "hasDatepickerFocused']"));
                element.sendKeys(Keys.ESCAPE);
                WaitUntil.waitUntil(() -> !element.getAttribute("class").contains
                        ("hasDatepickerFocused"));
                // This is required because the widget does not go away quick enough and web driver
                // gets confused and can't click under the control until it's completely gone.
                SeleniumTest.waitMs(3000);
            } catch (NoSuchElementException nse) {
                // This is fine as there is no calendar control box open
            }

        }
    }

}
