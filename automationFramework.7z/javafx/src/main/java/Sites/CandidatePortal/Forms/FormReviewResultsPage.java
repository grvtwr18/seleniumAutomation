package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.DashboardPage;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 9/1/2015.
 */
public class FormReviewResultsPage extends FormPage {

    @FindBy(how = How.CSS, using = "label.radioLabel")
    private static WebElement approveRadioButton;

    @FindBy(how = How.ID, using = "7-previousnextbuttons-submitbutton")
    private static WebElement submitButton;

    /**
     * Clicks on Approve Radio Button.
     */
    public static void selectApproveForm() {
        approveRadioButton.click();
    }

    /**
     * Clicks on Submit Button.
     */
    public static DashboardPage submitFormReviewResults() {
        submitButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }
}
