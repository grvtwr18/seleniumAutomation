package Sites.CandidatePortal.Forms;

/**
 * Created by abrackett on 10/18/16.
 * Handles 3 Step I-9 Workflow Page 1
 */
public class Form_17058 {

    public class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {

    }
}
