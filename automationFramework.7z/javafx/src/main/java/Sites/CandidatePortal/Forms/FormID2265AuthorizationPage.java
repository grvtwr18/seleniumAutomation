package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 3/18/2016.
 */
public class FormID2265AuthorizationPage extends FormPage {
    @FindBy(how = How.CSS, using = "label[class='checkboxLabel formFieldLabelRequired']")
    private static WebElement confirmationLabel;

    @FindBy(how = How.ID, using = "2265-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    /**
     * Check the confirmation checkbox.
     */
    public static FormID2265AuthorizationPage checkConfirmationCheckbox() {
        if(!Driver.getDriver().findElement(By.id("2265-2265_2")).isSelected())
            confirmationLabel.click();
        return PageFactory.initElements(Driver.getDriver(), FormID2265AuthorizationPage.class);
    }

    /**
     * Clicks Next
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
