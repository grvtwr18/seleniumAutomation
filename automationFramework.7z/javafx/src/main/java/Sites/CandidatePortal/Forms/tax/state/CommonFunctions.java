package Sites.CandidatePortal.Forms.tax.state;

import Sites.CandidatePortal.Forms.Objects.TwESign;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class CommonFunctions extends SeleniumTest {


    public static boolean isRequired(WebElement element) {
        return element.getAttribute("class").toLowerCase().contains("required");
    }

    public static String getErrorText(WebElement element) {
        try {
            return ((EventFiringWebDriver) Driver.getDriver()).getWrappedDriver()
                    .findElement(By.id(element.getAttribute("for") + "-err")).getText();
        } catch (NoSuchElementException nse) {
            return "";
        }
    }
    public CommonFunctions() {

    }

    public void verifySignatures(int countToVerify) {

        for (int signatureCount = 0; signatureCount < countToVerify; signatureCount++) {
            verifyTrue(
                    (new StringBuilder()
                            .append("Signature  ")
                            .append(Integer.toString((signatureCount + 1)))
                            .append(" image is not empty ")).toString(),
                    !TwESign.Signature.getSignatureImageSrc(signatureCount).isEmpty());

            String dateNowString = LocalDate.now().format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG));
            // Strip "Signed: " from the date retrieved out of the signature before comparing dates
            LocalDate signatureDate = LocalDate.parse(TwESign.Signature.getSignDate(signatureCount).split("Signed: ")[1], DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG));
            String signatureDateString = signatureDate.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG));

            verifyTrue(
                    (new StringBuilder()
                            .append("Signature ")
                            .append(Integer.toString((signatureCount + 1)))
                            .append(" Signed Date matches ")
                            .append(dateNowString)
                            .append(" : ")
                            .append(signatureDateString))
                            .toString(),
                    dateNowString.equals(signatureDateString));

            verifyTrue(
                    (new StringBuilder()
                            .append("Signature ")
                            .append(Integer.toString((signatureCount + 1)))
                            .append(" Time is not empty")).toString(),
                    !TwESign.Signature.getSignTime(signatureCount).isEmpty());

            verifyTrue(
                    (new StringBuilder()
                            .append("Signature  ")
                            .append(Integer.toString((signatureCount + 1)))
                            .append(" ID is not empty")).toString(),
                    !TwESign.Signature.getSignId(signatureCount).isEmpty());

            verifyTrue(
                    (new StringBuilder()
                            .append("Signature  ")
                            .append(Integer.toString((signatureCount + 1)))
                            .append(" IP is not empty")).toString(),
                    !TwESign.Signature.getSignIP(signatureCount).isEmpty());

        }
    }

    public enum Withholding {
        GROSS(),
        ZERO()
    }
}
