package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.DashboardPage;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by jgupta on 11/28/2015.
 */
public class ESigningCompletePage extends FormPage {

    @FindBy(how = How.CSS, using = "button")
    private static WebElement returnToDashboardButton;

    @FindBy(how = How.LINK_TEXT, using = "My Dashboard")
    private static WebElement myDashboardLink;

    protected final static Logger staticLogger = LoggerFactory.getLogger("ESigningCompletePage");

    static {
        PageFactory.initElements(Driver.getDriver(), ESigningCompletePage.class);
    }

    public static WebElement getReturnToDashboardButton() {
        return returnToDashboardButton;
    }

    /**
     * Attempts to make sure the ESign Complete page is loaded before returning
     * If no text is supplied it will wait for the url to contain task.php and
     * it will look for the Sterling Talent Solutions image in the footer
     * If you supply textToLookFor it will find this text in the page source before returning
     * @param textToLookFor The text you want to search for on the page.
     */
    public static void waitForPageToLoad(String... textToLookFor) {
        waitForPageLoad("task.php", textToLookFor);
    }

    /**
     * Clicks on "Return to Dashboard" button
     */
    public static DashboardPage clickReturnToDashboardButton() {
        returnToDashboardButton.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Clicks on the 'My Dashboard' link in the bread crumbs at the top of the page to go to dashboard.
     * @return
     */
    public static DashboardPage clickMyDashboardLink() {
        myDashboardLink.click();
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }
}

