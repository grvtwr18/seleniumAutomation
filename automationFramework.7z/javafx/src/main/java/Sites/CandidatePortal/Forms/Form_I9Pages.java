package Sites.CandidatePortal.Forms;

/**
 * Created by abrackett on 4/16/2016.
 */
public class Form_I9Pages extends FormPage {

    /**
     * Enum of List A Documents
     */
    public enum ListADocuments {
        USPASSPORT("U.S. Passport"),
        USPASSPORTCARD("U.S. Passport Card"),
        PERMANENTRESIDENTCARD("Permanent Resident Card"),
        ALIENREGISTRATIONRECEIPTCARD("Alien Reg Card (I-551)"),
        FOREIGNPASSPORTWITHI_551STAMP("Foreign PP with I-551"),
        EMPLOYMENTAUTHORIZATIONDOCUMENT("Employment Auth (I-766)"),
        FOREIGNPASSPORTWITHI_94_AFORM("Foreign PP with I-94/A"),
        FSMPASSPORTWITHI_94_AFORM("FSM PP with I-94/A"),
        RMIPASSPORTWITHI_94_AFORM("RMI PP with I-94/A"),
        I_94_AFORMWITHREFUGEESTAMP("I-94/A w/Refugee Stamp");

        private final String text;

        ListADocuments(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * enum of List B Documents
     */
    public enum ListBDocuments {
        USSTATEDRIVERSLICENSE("State ID or Driver's License"),
        GOVERNMENTID("Government Issued ID"),
        SCHOOLID("School ID with Photo"),
        VOTERREGISTRATIONCARD("Voter Registration Card"),
        USMILITARYCARD("U.S. Military ID"),
        MILITARYDEPENDENTIDCARD("Military Dependent ID"),
        USCOASTGUARDMERCHANTMARINERCARD("U.S. CG Merchant Mariner Card"),
        NATIVEAMERICANTRIBALDOCUMENT("Native American Tribal Document"),
        CAGOVERNMENTDRIVERSLICENSE("CA Government Driver's License"),
        SCHOOLRECORD("School Record"),
        MEDICALRECORD("Medical Record"),
        PRE_SCHOOLRECORD("Pre-school Record");

        private final String text;

        ListBDocuments(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /**
     * enum of List C Documents
     */
    public enum ListCDocuments {
        I_20("I-20"), //
        DS_2019("DS-2019"), //Document number must begin with an 'N' followed by 10 digits
        SSACCOUNTNUMBERCARD("Social Security Card"),
        BIRTHABROADCERTIFICATEFS_545("Birth Abroad Cert (FS-545)"),
        BIRTHABROADCERTIFICATEDS_1350("Birth Abroad Cert (DS-1350)"),
        BIRTHCERTIFICATEWITHSEAL("Birth Certificate with Seal"),
        NATIVEAMERICANTRIBALDOCUMENT("Native American Tribal Doc"),
        USCITIZENIDCARD("U.S. Citizen ID"),
        RESIDENTCITIZENIDCARD("Resident Citizen ID"),
        DHSEMPLOYMENTAUTHORIZATIONDOCUMENT("Employment Auth. Document (DHS) List C #7");

        private final String text;

        ListCDocuments(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}
