package Sites.CandidatePortal.Forms.tax.state.oklahoma;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_1873 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//label[@for='1873-1873_5_Yes']")
    private WebElement completeTheFormYesRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='1873-1873_5_No']")
    private WebElement completeTheFormNoRadiobutton;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_1873() {
    }

    public static Form_1873 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_1873.class);
    }

    public Form_1873 navigateTo() {
        return PageFactory.initElements(Driver.getDriver(), Form_1873.class);
    }

    public void chooseCompleteOW9MSEForm() {
        completeTheFormYesRadiobutton.click();
        logger.info("Complete the OW9MSE Form Chosen");
    }

    public void chooseDoNotCompleteOW9MSEForm() {
        completeTheFormNoRadiobutton.click();
        logger.info("Do Not Complete the OW9MSE Form Chosen");
    }
}
