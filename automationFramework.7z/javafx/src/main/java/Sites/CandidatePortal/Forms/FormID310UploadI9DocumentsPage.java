package Sites.CandidatePortal.Forms;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import com.google.common.base.Predicate;
import org.apache.commons.exec.OS;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

/**
 * Created by abrackett on 11/17/2015.
 */
public class FormID310UploadI9DocumentsPage extends FormPage {

    private static final Logger logger = LoggerFactory.getLogger("Sites.CandidatePortal.Forms.FormID310UploadI9DocumentsPage");

    @FindBy(how = How.XPATH, using = "//label[@for='310-310_15_List A']")
    private WebElement listARadiobutton;

    private final String listAID = "310-311_4";
    By listALocator = By.id(listAID);
    @FindBy(how = How.ID, using = listAID)
    private WebElement listADocumentDropdown;

    @FindBy(how = How.XPATH, using = "//label[@for='310-310_15_List B and C']")
    private WebElement listBAndCRadiobutton;

    @FindBy(how = How.ID, using = "310-310_3-filebrowse")
    private WebElement chooseFileTextbox;

    @FindBy(how = How.CSS, using = "button.btnPostFileToServer.button")
    private WebElement uploadFileButton;

    @FindBy(how = How.XPATH, using = "//label[@for='310-310_24_Yes']")
    private WebElement yesRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='310-310_24_No']")
    private WebElement noRadiobutton;

    @FindBy(how = How.XPATH, using = "//label[@for='310-310_9']")
    private WebElement iAcknowledgeCheckbox;

    @FindBy(how = How.ID, using = "310-previousnextbuttons-previousbutton")
    private WebElement previousButton;

    @FindBy(how = How.ID, using = "310-previousnextbuttons-nextbutton")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "310-previousnextbuttons-savebutton")
    private WebElement saveButton;

    @FindBy(how = How.ID, using = "browseAttachMsgSuccess")
    private WebElement browseAndAttachMessage;

    @FindBy(how = How.ID, using = "documenttypeselector1")
    private WebElement fileTypeDrobdown;

    @FindBy(how = How.ID, using = "acceptButton")
    private static WebElement acceptButton;
    // Upping timeout to 30 seconds - taking longer to save a 15 MB file
    private final int TIMEOUT = 30;
    /**
     * Choose List A Radiobuton
     * @return
     */
    public FormID310UploadI9DocumentsPage chooseListARadiobutton() {
        if(!listARadiobutton.isSelected())
            listARadiobutton.click();
        return this;
    }

    /**
     * Choose list B and C Radio button
     * @return
     */
    public FormID310UploadI9DocumentsPage chooseListBAndCRadiobutton() {
        if(!listBAndCRadiobutton.isSelected())
            listBAndCRadiobutton.click();
        return this;
    }

    /**
     * Select List A Document Title
     * @param documentTitle
     * @return
     */
    public FormID310UploadI9DocumentsPage selectListADocumentTitle(String documentTitle) {
        Select listASelect = new Select(listADocumentDropdown);
        new FluentWait<WebDriver>(Driver.getDriver())
                .withTimeout(6, TimeUnit.SECONDS)
                .pollingEvery(2, TimeUnit.SECONDS)
                .until(new Predicate<WebDriver>() {
                    public boolean apply(WebDriver d) {
                        if(new Select(d.findElement(listALocator)).getOptions().size() > 2) {
                            return true;
                        }
                        return false;
                    }
                });
        listASelect.selectByVisibleText(documentTitle);
        return this;
    }

    /**
     * Set Choose File path
     * @param filePath
     * @return
     */
    public FormID310UploadI9DocumentsPage setChooseFile(String filePath) {

        if(OS.isFamilyWindows())
            filePath = filePath.replace('/', '\\');
        ((JavascriptExecutor)Driver.getDriver()).executeScript("document.getElementById('" + chooseFileTextbox.getAttribute("id") + "').style.visibility = 'visible';");
        chooseFileTextbox.sendKeys(filePath);
        SeleniumTest.waitForElementToBeClickable(uploadFileButton, 30);
        return this;
    }

    /**
     * Clicks the upload file button
     * @param fileName the filename ONLY do not include the path
     * @return
     */
    public FormID310UploadI9DocumentsPage clickUploadFileButton(String fileName) {
        uploadFileButton.click();
        new WebDriverWait(Driver.getDriver(), TIMEOUT).until(ExpectedConditions.visibilityOf(Driver.getDriver().findElement(By.linkText(fileName))));
        return this;
    }

    /**
     * Clicks the upload file button
     * @param fileName the filename ONLY do not include the path
     * @return
     */
    public FormID310UploadI9DocumentsPage clickUploadFileButton(int timeOut, String fileName) {
        uploadFileButton.click();
        WaitUntil.waitUntil(timeOut, 2, () -> Driver.getDriver().findElement(By.linkText(fileName))
                                        .isDisplayed(), NoSuchElementException.class);
        return this;
    }

    /**
     * Choose Additional Documents Yes
     * @return
     */
    public FormID310UploadI9DocumentsPage chooseAdditionalDocumentYes() {
        yesRadiobutton.click();
        return this;
    }

    /**
     * Choose Additional Documents No
     * @return
     */
    public FormID310UploadI9DocumentsPage chooseAdditionalDocumentNo() {
        noRadiobutton.click();
        return this;
    }

    /**
     * Check the I acknowledge checkbox
     * @return
     */
    public FormID310UploadI9DocumentsPage checkIAcknowledgeCheckbox() {
        if(!iAcknowledgeCheckbox.isSelected())
            iAcknowledgeCheckbox.click();
        return this;
    }

    /**
     * Click Next Button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickNextButton(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        SeleniumTest.waitForElementVisible(acceptButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Click Save Button
     * @return
     */
    public FormID310UploadI9DocumentsPage clickSaveButton() {
        saveButton.click();
        return PageFactory.initElements(Driver.getDriver(), FormID310UploadI9DocumentsPage.class);
    }

    /**
     * Click Previous Button
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages clickPreviousButton(Class<? extends CandidatePortalPages> returnedClass) {
        previousButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public void selectFileType(String fileType){

        SeleniumTest.selectByValueFromDropDown(fileTypeDrobdown,fileType);
    }

    public void uploadFile(String filePath,By elmTextBox, By elmUploadButton) {
        if(OS.isFamilyWindows())
            filePath = filePath.replace('/', '\\');
        ((JavascriptExecutor) Driver.getDriver()).executeScript("document.getElementById('" + Driver.getDriver().findElement(elmTextBox).getAttribute("id") + "').style.visibility = 'visible';");
        Driver.getDriver().findElement(elmTextBox).sendKeys(filePath);
        SeleniumTest.click(elmUploadButton,30);
    }
}
