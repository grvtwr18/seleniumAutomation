package Sites.CandidatePortal.Forms;

import Sites.CandidatePortal.Forms.Objects.I9.BusinessEntity;
import Sites.CandidatePortal.Forms.Objects.I9.ListAEligibilityDocument;
import Sites.CandidatePortal.Forms.Objects.I9.ListBEligibilityDocument;
import Sites.CandidatePortal.Forms.Objects.I9.ListCEligibilityDocument;

import java.io.File;

/**
 * Created by abrackett on 10/17/16.
 * Handles complete Section 2 for I-9
 */
public class Form_5077 {

    public static void fillListADocument(ListAEligibilityDocument document) {

        Form_5077.Section2.Documents.ListA.selectListADocument(document.getListADocument());

        if (document.isReceipt()) {
            Form_5077.Section2.Documents.ListA.checkListAReceipt(document.getListADocument());
            Form_5077.Section2.Documents.ListA.setIssuingAuthority(document.getListADocument(),
                                                                   document.getIssuingAuthority());
            Form_5077.Section2.Documents.ListA
                    .setDocumentNumber(document.getListADocument(), document.getDocumentNumber());
        } else {
            Form_5077.Section2.Documents.ListA.uncheckListAReceipt(document.getListADocument());
            Form_5077.Section2.Documents.ListA.setIssuingAuthority(document.getListADocument(),
                                                                   document.getIssuingAuthority());
            Form_5077.Section2.Documents.ListA
                    .setDocumentNumber(document.getListADocument(), document.getDocumentNumber());

            if (Form_5077.Section2.isRequired(
                    Form_5077.Section2.Documents.ListA
                                                      .getAssociatedDocumentElement(
                                                              document.getListADocument()))) {
                Form_5077.Section2.Documents.ListA
                        .setOrSelectAssociatedDocument(document.getListADocument(),
                                                       Sites.CandidatePortal.Forms.Objects.I9
                                                               .Section2.Documents.ListA
                                                               .getAssociatedDocument(
                                                                       document.getListADocument
                                                                               ()));
            }
            if (Form_5077.Section2.isRequired(Form_5077.Section2.Documents.ListA
                                                      .getExpirationDateControlElement(
                                                              document.getListADocument()))) {
                Form_5077.Section2.Documents.ListA.setExpirationDate(document.getListADocument(),
                                                                     document.getExpirationDate());
            }
            if (Form_5077.Section2.Documents.ListA.secondDocumentIssuingAuthorityTextBox.isDisplayed()) {
                Form_5077.Section2.Documents.ListA
                        .setSecondDocumentIssuingAuthority(document.getSecondIssuingAuthority());
                Form_5077.Section2.Documents.ListA
                        .setSecondDocumentNumber(document.getSecondDocumentNumber());
                Form_5077.Section2.Documents.ListA
                        .setSecondDocumentExpirationDate(document.getSecondDocumentExpiration());
            }
        }
    }

    public static void fillListBDocument(ListBEligibilityDocument document) {

        Form_5077.Section2.Documents.ListB.selectlistBDocument(document.getListBDocument());

        if (document.isReceipt()) {
            // Check Receipt - Set Issuing Authority - Set Receipt Number
            Form_5077.Section2.Documents.ListB.checklistBReceipt(document.getListBDocument());
            Form_5077.Section2.Documents.ListB.setIssuingAuthority(
                    document.getListBDocument(), document.getIssuingAuthority());
            Form_5077.Section2.Documents.ListB.setDocumentNumber(
                    document.getListBDocument(), document.getDocumentNumber());
        } else {
            if (Form_5077.Section2.isRequired(
                    Form_5077.Section2.Documents.ListB.getDocumentTypeElement
                    (document.getListBDocument()))) {
                // Set Document Type, Set State
                Form_5077.Section2.Documents.ListB.setDocumentType(document.getListBDocument(),
                                                                   document.getDocumentType());
                Form_5077.Section2.Documents.ListB.setState(document.getListBDocument(), document.getStateOfUnion());
            } else {
                // Set Issuing Authority
                Form_5077.Section2.Documents.ListB.setIssuingAuthority(
                        document.getListBDocument(), document.getIssuingAuthority());
            }
            Form_5077.Section2.Documents.ListB.setDocumentNumber(document.getListBDocument(),
                                                                 document.getDocumentNumber());
            Form_5077.Section2.Documents.ListB.setExpirationDate(document.getListBDocument(),
                                                                 document.getExpirationDate());
        }
    }

    public static void fillListCDocument(ListCEligibilityDocument document) {

        Form_5077.Section2.Documents.ListC.selectListCDocument(document.getListCDocument());
        Form_5077.Section2.Documents.ListC.setIssuingAuthority(document.getListCDocument(),
                                                               document.getIssuingAuthority());
        Form_5077.Section2.Documents.ListC.setDocumentNumber(document.getListCDocument(),
                                                             document.getDocumentNumber());

        if(document.isReceipt()) {
            Form_5077.Section2.Documents.ListC.checkListCReceipt(document.getListCDocument());
        } else {
            if(Form_5077.Section2.Documents.ListC
                    .getExpirationDateControlElement
                    (document.getListCDocument()).isDisplayed()) {
                Form_5077.Section2.Documents.ListC.setExpirationDate(document.getListCDocument(),
                                                                     document.getExpirationDate());
            }
        }
    }

    public static void fillCertification(BusinessEntity businessEntity) {

        Form_5077.Section2.Certification.setAuthorizedRepresentative(businessEntity.getTitle());
        Form_5077.Section2.Certification.setBusinessName(businessEntity.getName());
        Form_5077.Section2.Certification.setAddressLine1(businessEntity.getAddressLine1());
        Form_5077.Section2.Certification.setCity(businessEntity.getCity());
        Form_5077.Section2.Certification.selectCountryOrRegion(businessEntity.getCountryOrRegion());
        Form_5077.Section2.Certification.selectStateOrProvince(businessEntity.getStateOrProvince());
        Form_5077.Section2.Certification.setZipCode(businessEntity.getZipCode());
    }

    public static void uploadDocument(File file) {
        Form_5077.Section2.UploadDocuments.setFileToUpload(file.getAbsolutePath());
        Form_5077.Section2.UploadDocuments.clickUploadFile();
    }

    public static void checkAcknowledgement() {
        Form_5077.Section2.Acknowledgement.checkIAcknowledge();
    }

    public static class Section2 extends Sites.CandidatePortal.Forms.Objects.I9.Section2 {

    }

    public static class Navigation extends Sites.CandidatePortal.Forms.Objects.Navigation {

    }


}
