package Sites.CandidatePortal.Forms.tax.state.Oregon;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_22642 extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "22642-div-100_1")
    private WebElement firstName;

    @FindBy(how = How.ID, using = "22642-div-100_3")
    private WebElement lastName;

    @FindBy(how = How.ID, using = "22642-div-100_5")
    private WebElement socialSecurityNumber;

    @FindBy(how = How.ID, using = "22642-div-100_7")
    private WebElement homeAddress;

    @FindBy(how = How.ID, using = "4477-100_8")
    private WebElement apartmentNumber;

    @FindBy(how = How.ID, using = "22642-div-100_10")
    private WebElement city;

    @FindBy(how = How.ID, using = "22642-div-100_11")
    private WebElement state;

    @FindBy(how = How.ID, using = "22642-div-100_12")
    private WebElement zip;

    @FindBy(how = How.ID, using = "22642-22537_1_Single")
    private WebElement singleCheckBox;

    @FindBy(how = How.ID, using = "22642-22537_25")
    private WebElement allowance;

    @FindBy(how = How.ID, using = "22642-div-22537_26")
    private WebElement additionalAmount;

    @FindBy(how = How.ID, using = "22642-div-22537_37")
    private WebElement exemptCode;

    @FindBy(how = How.ID, using = "22642-div-22537_39")
    private WebElement exempt;

    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_22642() {

    }

    public static Form_22642 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_22642.class);
    }

    public String getFirstName() {
        return firstName.getText();
    }

    public String getLastName() {
        return lastName.getText();
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber.getText();
    }

    public String getHomeAddress() {
        return homeAddress.getText();
    }

    public String getApartmentNumber() {
        return apartmentNumber.getText();
    }

    public String getCity() {
        return city.getText();
    }

    public String getState() {
        return state.getText();
    }

    public String getZip() {
        return zip.getText();
    }

    public boolean singleCheckBoxChecked() {
        String attr = singleCheckBox.getAttribute("checked");
        if (attr != null && attr.equals("true")) {
            return true;
        }
        return false;
    }

    public String getAllowanceAmount() {
        return allowance.getText();
    }

    public String getAdditionalAmount() {
        return additionalAmount.getText();
    }

    public String getExemptCode() {
        return exemptCode.getText();
    }

    public String getExempt() {
        return exempt.getText();
    }
}
