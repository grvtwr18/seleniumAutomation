package Sites.CandidatePortal.Forms.Objects.I9;

import java.time.LocalDate;

/**
 * Created by abrackett on 10/17/16.
 */
public class ListBEligibilityDocument {

    private Section2.Documents.ListBDocuments listBDocument           =
            Section2.Documents.ListBDocuments.USSTATEDRIVERSLICENSE;
    private boolean                           receipt                 = false;
    private String                            documentType            = "License";
    private String                            stateOfUnion            = "Washington";
    private String                            issuingAuthority        = "U.S. Department of State";
    private String                            documentNumber          = "XXXXXXX434X4";
    private String                            associatedDocumentValue = "";
    private LocalDate                         expirationDate          =
            LocalDate.now().plusYears(5);

    public ListBEligibilityDocument() {

    }

    public ListBEligibilityDocument(Section2.Documents.ListBDocuments document, boolean receipt,
                                    String documentType, String stateOfUnion,
                                    String issuingAuthority, String documentNumber,
                                    String associatedDocumentValue, LocalDate expirationDate) {

        this.listBDocument = document;
        this.receipt = receipt;
        this.documentType = documentType;
        this.stateOfUnion = stateOfUnion;
        this.issuingAuthority = issuingAuthority;
        this.documentNumber = documentNumber;
        this.associatedDocumentValue = associatedDocumentValue;
        this.expirationDate = expirationDate;
    }


    public Section2.Documents.ListBDocuments getListBDocument() {
        return listBDocument;
    }

    public void setListBDocument(Section2.Documents.ListBDocuments listBDocument) {
        this.listBDocument = listBDocument;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getStateOfUnion() {
        return stateOfUnion;
    }

    public void setStateOfUnion(String stateOfUnion) {
        this.stateOfUnion = stateOfUnion;
    }

    public String getIssuingAuthority() {
        return issuingAuthority;
    }

    public void setIssuingAuthority(String issuingAuthority) {
        this.issuingAuthority = issuingAuthority;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getAssociatedDocumentValue() {
        return associatedDocumentValue;
    }

    public void setAssociatedDocumentValue(String associatedDocumentValue) {
        this.associatedDocumentValue = associatedDocumentValue;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public boolean isReceipt() {
        return receipt;
    }

    public void setReceipt(boolean receipt) {
        this.receipt = receipt;
    }

}
