package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 3/17/2016.
 */
public class FormID2264DisclosurePage extends FormPage {
    @FindBy(how = How.CSS, using = "label[class='checkboxLabel formFieldLabelRequired']")
    private static WebElement confirmationLabel;

    @FindBy(how = How.ID, using = "2264-previousnextbuttons-nextbutton")
    private static WebElement nextButton;

    /**
     * Check the confirmation checkbox.
     */
    public static FormID2264DisclosurePage checkConfirmationCheckbox() {
        if(!Driver.getDriver().findElement(By.id("2264-2264_2")).isSelected())
            confirmationLabel.click();
        return PageFactory.initElements(Driver.getDriver(), FormID2264DisclosurePage.class);
    }

    /**
     * Clicks Next
     * @param returnedClass
     * @return
     */
    public static CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
