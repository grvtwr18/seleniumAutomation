package Sites.CandidatePortal.Forms.eDispute;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by jgupta on 5/13/2017.
 */
public class DisputeInitiationCompletedPage {
    static {
        PageFactory.initElements(Driver.getDriver(), DisputeInitiationCompletedPage.class);
    }

    @FindBy(how = How.CLASS_NAME, using = "content-container")
    private static WebElement textContainer;

    @FindBy(how = How.CSS, using = "button[class='dispute btn btn-primary pull-right']")
    private static WebElement doneButton;

    public static String getPageContents() {
        System.out.println("*********************************");
        System.out.println(textContainer.getText());
        System.out.println("*********************************");
        return textContainer.getText();
    }

    public static void clickDone() {
        SeleniumTest.click(doneButton);
    }
}
