package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by tjoshi on 11/23/2015.
 */
public class FormID1972W4OregonPage extends FormPage {

    @FindBy(how = How.CSS, using = "label.checkboxLabel.formFieldLabelRequired")
    private WebElement stateTaxFormSelectorCheckbox;


    @FindBy(how = How.ID, using = "1972-previousnextbuttons-nextbutton")
    private WebElement nextButton;


    /**
     * Check the I confirm check-box if not checked
     */
    public void checkTaxFormSelectorCheckBox()
    {
        if (!stateTaxFormSelectorCheckbox.isSelected()) {
            stateTaxFormSelectorCheckbox.click();
        }
    }

    /**
     * Click on Next button
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    /**
     * Fills in the form and submits the tax state form
     * @param returnedClass
     * @return
     */
    public CandidatePortalPages fillStateTaxFormsSelector(Class<? extends CandidatePortalPages> returnedClass)
    {
        this.checkTaxFormSelectorCheckBox();
        return this.clickNext(returnedClass);
    }
}
