package Sites.CandidatePortal.Forms.tax.state.montana;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Form_22551 extends CandidatePortalPages {

    @FindBy(how = How.XPATH, using = "//a[@href='https://app.mt.gov/myrevenue/Endpoint/DownloadPdf?yearId=871']")
    public WebElement linkOfMontanaState;
    //Montana Allowances
    @FindBy(how = How.XPATH, using = "//span[contains(text(),'Section 1: Montana Allowances')]")
    public WebElement lblSection1;

    @FindBy(how = How.XPATH, using = "//select[@name='22551-22551_7']")
    public WebElement montanaAllowanceBoxADropDown;

    @FindBy(how = How.XPATH, using = "//select[@name='22551-22551_9']")
    public WebElement montanaAllowanceBoxBDropDown;

    @FindBy(how = How.XPATH, using = "//select[@name='22551-22551_11']")
    public WebElement montanaAllowanceBoxCDropDown;

    @FindBy(how = How.XPATH, using = "//select[@name='22551-22551_13']")
    public WebElement montanaAllowanceBoxDDropDown;

    @FindBy(how = How.XPATH, using = "//select[@name='22551-22551_15']")
    public WebElement montanaAllowanceBoxEDropDown;

    @FindBy(how = How.XPATH, using = "//select[@name='22551-22551_17']")
    public WebElement montanaAllowanceBoxFDropDown;

    @FindBy(how = How.XPATH, using = "//label[@for='22551-22551_19']")
    public WebElement totalAllowanceLabel;

    @FindBy(how = How.ID, using = "22551-22551_19")
    public WebElement totalAllowanceBox;

    @FindBy(how = How.XPATH, using = "//label[@for='22551-22551_21']")
    public WebElement additionalAmountLabel;

    @FindBy(how = How.ID, using = "22551-22551_21")
    public WebElement additionalAmountBox;

    @FindBy(how = How.XPATH, using = "//label[@for='22551-22551_23']")
    public WebElement section2Checkbox1;

    @FindBy(how = How.ID, using = "22551-22551_39")
    public WebElement section2Checkbox2;

    @FindBy(how = How.XPATH, using = "//label[@for='22551-22551_40']")
    public WebElement section2Checkbox3;

    @FindBy(how = How.ID, using = "22551-22551_41")
    public WebElement section2Checkbox4;

    @FindBy(how = How.ID, using = "22551-22551_25")
    public WebElement withholdingStatusDropdown;

    @FindBy(how = How.ID, using = "22551-22551_31")
    public WebElement residencyStatementDropdown;

    @FindBy(how = How.ID, using = "22551-22551_32")
    public WebElement employmentStatementDropdown;

    @FindBy(how = How.XPATH, using = "//label[@for='22551-22551_27']")
    public WebElement iUnderstandLabel;

    @FindBy(how = How.XPATH, using = "//label[@for='22551-22551_30']")
    public WebElement iDeclareLabel;


    public final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public Form_22551() {

    }

    public static Form_22551 initializeElements() {
        return PageFactory.initElements(Driver.getDriver(), Form_22551.class);
    }

    public boolean stateOfMontanaLinkExists() {
        return linkOfMontanaState.isDisplayed();
    }

    public Form_22551 setMontanaAllowanceBoxAValue(String boxAvalue) {
        SeleniumTest.selectByVisibleTextFromDropDown(montanaAllowanceBoxADropDown, boxAvalue);
        logger.info("Box A value {} selected", boxAvalue);
        return this;
    }

    public Form_22551 setMontanaAllowanceBoxBValue(String boxBvalue) {
        SeleniumTest.selectByVisibleTextFromDropDown(montanaAllowanceBoxBDropDown, boxBvalue);
        logger.info("Box B value {} selected", boxBvalue);
        return this;
    }

    public Form_22551 setMontanaAllowanceBoxCValue(String boxCvalue) {
        SeleniumTest.selectByVisibleTextFromDropDown(montanaAllowanceBoxCDropDown, boxCvalue);
        logger.info("Box C value {} selected", boxCvalue);
        return this;
    }

    public Form_22551 setMontanaAllowanceBoxDValue(String boxDvalue) {
        SeleniumTest.selectByVisibleTextFromDropDown(montanaAllowanceBoxDDropDown, boxDvalue);
        logger.info("Box D value {} selected", boxDvalue);
        return this;
    }

    public Form_22551 setMontanaAllowanceBoxEValue(String boxEvalue) {
        SeleniumTest.selectByVisibleTextFromDropDown(montanaAllowanceBoxEDropDown, boxEvalue);
        logger.info("Box E value {} selected", boxEvalue);
        return this;
    }

    public Form_22551 setMontanaAllowanceBoxFValue(String boxFvalue) {
        SeleniumTest.selectByVisibleTextFromDropDown(montanaAllowanceBoxFDropDown, boxFvalue);
        logger.info("Box F value {} selected", boxFvalue);
        return this;
    }

    public Form_22551 setTotalAllowancesAmount(String amount) {
        SeleniumTest.clearAndSetText(totalAllowanceBox, amount);
        logger.info("Total Allowance amount is entered", amount);
        return this;
    }

    public Form_22551 setAdditionalAmount(String amount) {
        SeleniumTest.clearAndSetText(additionalAmountBox, amount);
        logger.info("Additional amount is entered", amount);
        return this;
    }

    public Form_22551 selectWithholdingStatus(String withholdingStatus) {
        SeleniumTest.selectByVisibleTextFromDropDown(withholdingStatusDropdown, withholdingStatus);
        logger.info("Withholding Status of {} selected", withholdingStatus);
        return this;
    }

    public Form_22551 selectResidencyStatement(String residencyStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(residencyStatementDropdown, residencyStatement);
        logger.info("Residency Status Selected {}", residencyStatement);
        return this;
    }

    public Form_22551 selectEmploymentStatementDropdown(String employmentStatement) {
        SeleniumTest.selectByVisibleTextFromDropDown(employmentStatementDropdown, employmentStatement);
        logger.info("Employment Status Selected {}", employmentStatement);
        return this;
    }

    public Form_22551 checkideclare() {
        SeleniumTest.click(iDeclareLabel);
        logger.info("Ideclare button is clicked");
        return this;
    }


    public void fillRequiredFields(boolean stateTaxForm, WithholdingStatus withholdingStatus, String flow) {
        if (stateTaxForm) {
            this.setMontanaAllowanceBoxAValue("1");
            this.setMontanaAllowanceBoxBValue("1");
            this.setMontanaAllowanceBoxCValue("1");
            this.setMontanaAllowanceBoxDValue("1");
            this.setMontanaAllowanceBoxEValue("1");
            this.setMontanaAllowanceBoxFValue("1");
            this.setTotalAllowancesAmount("23");
            this.setAdditionalAmount("2332");

            if (flow != "normal") {
                selectWithholdingStatus(withholdingStatus.toString());
                switch (withholdingStatus) {
                    case EXEMPT:
                        this.iUnderstandLabel.click();
                        this.selectResidencyStatement("I live in Montana");
                        this.selectEmploymentStatementDropdown("I work out of state");
                        break;
                    case FULLY_SUBJECT_TO_TAXES:
                        this.selectResidencyStatement("I live out of state");
                        this.selectEmploymentStatementDropdown("I work in Montana");
                        break;


                }
            }
            else {
                this.selectResidencyStatement("I live in Montana");
                this.selectEmploymentStatementDropdown("I work in Montana");
            }

            this.checkideclare();
        }


    }

    public void verifyRequiredErrorLables(String totalallowanceamount, String additionalamount) {
        this.setTotalAllowancesAmount(totalallowanceamount);
        this.setAdditionalAmount(additionalamount);
    }

    public enum WithholdingStatus {
        EXEMPT("Exempt"),
        FULLY_SUBJECT_TO_TAXES("Fully Subject to Taxes");

        private final String text;

        WithholdingStatus(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
}