package Sites.CandidatePortal.Forms.Objects.statetax;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class FormCLGS326Page extends CandidatePortalPages {
    protected static final Logger staticLogger = LoggerFactory.getLogger(FormCLGS326Page.class);

    @FindBy(how = How.XPATH, using = "//label[@for='1876-1876_24_Yes']")
    private WebElement pennsylvaniaEmploymentStatusYes;

    @FindBy(how = How.XPATH, using = "//button[@value='Next']")
    private WebElement nextButton;

    @FindBy(how = How.ID, using = "1876-1876_24-err")
    private WebElement pennsylvaniaEmploymentStatusYesErrorMessage;

    @FindBy(how = How.XPATH, using = "//*[@fieldname='Municipality (City, Borough, Township)']")
    private List<WebElement> municipalityTextbox;

    @FindBy(how = How.XPATH, using = "//*[@fieldname='County']")
    private List<WebElement> countyDropDown;

    @FindBy(how = How.ID, using = "1876-1876_12")
    private WebElement addressLine1Textbox;

    @FindBy(how = How.ID, using = "1876-1876_14")
    private WebElement cityTextbox;

    @FindBy(how = How.ID, using = "1876-1876_15")
    private WebElement stateTextbox;

    @FindBy(how = How.ID, using = "1876-1876_16")
    private WebElement zipCodeTextbox;

    @FindBy(how = How.XPATH, using = "//label[@for='1876-1876_9']")
    private WebElement iConfirmCheckboxLabel;

    @FindBy(how = How.ID, using = "1876-1876_9")
    private WebElement iConfirmCheckbox;


    public void clickPennsylvaniaEmploymentStatus() {
        SeleniumTest.click(pennsylvaniaEmploymentStatusYes);
    }

    public void clickNext() {
        SeleniumTest.click(nextButton);
    }

    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass) {
        SeleniumTest.click(nextButton);
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public boolean isErrorForMandatoryFieldsVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("1876-1876_24-err"));
    }

    public void enterEmployeeAddress(String municipality, String county, String AddressLine1, String City, String State, String Zipcode) {
        if (!municipalityTextbox.isEmpty()) {
            for (WebElement aMunicipalityTextbox : municipalityTextbox) {
                SeleniumTest.clearAndSetText(aMunicipalityTextbox, municipality);
            }
        }

        if (!countyDropDown.isEmpty()) {
            for (WebElement aCountyDropDown : countyDropDown) {
                SeleniumTest.selectByVisibleTextFromDropDown(aCountyDropDown, county);
            }
        }

        SeleniumTest.clearAndSetText(addressLine1Textbox, AddressLine1);
        SeleniumTest.clearAndSetText(cityTextbox, City);
        SeleniumTest.clearAndSetText(stateTextbox, State);
        SeleniumTest.clearAndSetText(zipCodeTextbox, Zipcode);
    }

    public void clickIconfirm() {
        SeleniumTest.check(iConfirmCheckboxLabel, iConfirmCheckbox);
    }
}
