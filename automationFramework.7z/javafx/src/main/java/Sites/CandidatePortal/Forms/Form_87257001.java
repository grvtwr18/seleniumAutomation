package Sites.CandidatePortal.Forms;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by abrackett on 6/15/17.
 */
public class Form_87257001 extends CandidatePortalPages {

    public static final String PREPEND_ID = "87257001-87257001";
    public static final String PAGE_LABEL = "//label[@for='" + PREPEND_ID;

    private Logger localLogger = LoggerFactory.getLogger(Form_87257001.class);

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_1_Yes']")
    private WebElement yesRadioLabel1;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_1_No']")
    private WebElement noRadioLabel1;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_2']")
    private WebElement checkBoxLabel1;

    @FindBy(how = How.ID, using = PREPEND_ID + "_2")
    private WebElement checkBox1;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_3_A']")
    private WebElement radioALabel1;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_3_B']")
    private WebElement radioBLabel1;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_3_C']")
    private WebElement radioCLabel1;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_3_D']")
    private WebElement radioDLabel1;

    @FindBy(how = How.ID, using = PREPEND_ID + "_4")
    private WebElement textInput1;

    @FindBy(how = How.ID, using = PREPEND_ID + "_5")
    private WebElement dropDown1;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_6_Yes']")
    private WebElement addAnotherYesRadioLabel2;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_6_No']")
    private WebElement addAnotherNoRadioLabel2;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_7']")
    private WebElement checkBoxLabel2;

    @FindBy(how = How.ID, using = PREPEND_ID + "_7")
    private WebElement checkBox2;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_8_E']")
    private WebElement radioALabel2;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_8_F']")
    private WebElement radioBLabel2;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_8_G']")
    private WebElement radioCLabel2;

    @FindBy(how = How.XPATH, using = PAGE_LABEL + "_8_H']")
    private WebElement radioDLabel2;

    @FindBy(how = How.ID, using = PREPEND_ID + "_9")
    private WebElement textInput2;

    @FindBy(how = How.ID, using = PREPEND_ID + "_10")
    private WebElement dropDown2;
    
    public Form_87257001() {
    }

    public String getOutputValue(String textOutputFieldName) {
        return Driver.getDriver().findElement(
                By.xpath("//span[@fieldname='" + textOutputFieldName + "']")).getText();
    }

    public void chooseYesRadioLabel1() {
        yesRadioLabel1.click();
        localLogger.info("Yes Radio Button chosen");
    }

    public void chooseNoRadioLabel1() {
        noRadioLabel1.click();
        localLogger.info("No Radio Button chosen");
    }

    public void checkCheckBoxLabel1() {
        SeleniumTest.check(checkBoxLabel1, checkBox1);
        localLogger.info("Checkbox Label 1 checked");
    }

    public void uncheckCheckBoxLabel1() {
        SeleniumTest.unCheck(checkBoxLabel1, checkBox1);
        localLogger.info("Checkbox Label 1 unchecked");
    }

    public void chooseRadioALabel1() {
        radioALabel1.click();
        localLogger.info("Radio A Chosen");
    }

    public void chooseRadioBLabel1() {
        radioBLabel1.click();
        localLogger.info("Radio B Chosen");
    }

    public void chooseRadioCLabel1() {
        radioCLabel1.click();
        localLogger.info("Radio C Chosen");
    }

    public void chooseRadioDLabel1() {
        radioDLabel1.click();
        localLogger.info("Radio D Chosen");
    }

    public void setTextInput1(String text) {
        SeleniumTest.clearAndSetText(textInput1, text);
        localLogger.info("Text input set to {}", text);
    }

    public void selectDropDown1(String selection) {
        SeleniumTest.selectByVisibleTextFromDropDown(dropDown1, selection);
        localLogger.info("DropDown 1 selection set to {}", selection);
    }

    public void chooseAddAnotherYesRadioLabel2() {
        addAnotherYesRadioLabel2.click();
        localLogger.info("Yes 2 radio button chosen");
    }

    public void chooseAddAnotherNoRadioLabel2() {
        addAnotherNoRadioLabel2.click();
        localLogger.info("No 2 radio button chosen");
    }

    public void checkCheckBoxLabel2() {
        SeleniumTest.check(checkBoxLabel2, checkBox2);
        localLogger.info("Checkbox 2 checked");
    }

    public void uncheckCheckBoxLabel2() {
        SeleniumTest.unCheck(checkBoxLabel2, checkBox1);
        localLogger.info("Checkbox 2 unchecked");
    }

    public void chooseRadioALabel2() {
        radioALabel2.click();
        localLogger.info("Radio button E chosen");
    }

    public void chooseRadioBLabel2() {
        radioBLabel2.click();
        localLogger.info("Radio button F chosen");
    }

    public void chooseRadioCLabel2() {
        radioCLabel2.click();
        localLogger.info("Radio button G chosen");
    }

    public void chooseRadioDLabel2() {
        radioDLabel2.click();
        localLogger.info("Radio button H chosen");
    }

    public void setTextInput2(String text) {
        SeleniumTest.clearAndSetText(textInput2, text);
        localLogger.info("Text Input 2 set to {}", text);
    }

    public void selectDropDown2(String selection) {
        SeleniumTest.selectByVisibleTextFromDropDown(dropDown2, selection);
        localLogger.info("DropDown 2 selection set to {}", selection);
    }
}
