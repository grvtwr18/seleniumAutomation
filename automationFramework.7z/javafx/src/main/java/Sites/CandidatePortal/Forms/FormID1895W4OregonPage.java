package Sites.CandidatePortal.Forms;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by tjoshi on 11/20/2015.
 */
public class FormID1895W4OregonPage extends FormPage {
    @FindBy(how = How.CSS, using = "button[value='Next']")
    private WebElement nextButton;

    @FindBy(how = How.CSS, using = "label.checkboxLabel.formFieldLabelRequired")
    private WebElement acknowledgementCheckbox;

    /**
     * Click on Next button
     * @return
     */
    public CandidatePortalPages clickNext(Class<? extends CandidatePortalPages> returnedClass)
    {
        if (!acknowledgementCheckbox.isSelected()) {
            acknowledgementCheckbox.click();
        }

        nextButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }
}
