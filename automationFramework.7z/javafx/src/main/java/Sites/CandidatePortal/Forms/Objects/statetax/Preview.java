package Sites.CandidatePortal.Forms.Objects.statetax;

import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by abrackett on 8/11/17.
 */
public class Preview {

    @FindBy(how = How.CSS, using = "span[id$='1968_11']")
    private WebElement connecticutStateTaxBox;

    @FindBy(how = How.CSS, using = "span[id$='1968_1")
    private WebElement employerNameBox;

    @FindBy(how = How.CSS, using = "span[id$='1968_2']")
    private WebElement employerAddressBox;

    @FindBy(how = How.CSS, using = "span[id$='1968_3']")
    private WebElement employerCityBox;

    @FindBy(how = How.CSS, using = "span[id$='1968_4']")
    private WebElement employerStateBox;

    @FindBy(how = How.CSS, using = "span[id$='1968_5']")
    private WebElement employerZipCodeBox;

    public static Preview getInstance() {
        return PageFactory.initElements(Driver.getDriver(), Preview.class);
    }


    public String getConnecticutTaxRegistrationNumber() {
        return connecticutStateTaxBox.getText();
    }

    public String getEmployerName() {
        return employerNameBox.getText();
    }

    public String getEmployerAddress() {
        return employerAddressBox.getText();
    }

    public String getEmployerCity() {
        return employerCityBox.getText();
    }

    public String getEmployerState() {
        return employerStateBox.getText();
    }

    public String getEmployerZipCode() {
        return employerZipCodeBox.getText();
    }
}
