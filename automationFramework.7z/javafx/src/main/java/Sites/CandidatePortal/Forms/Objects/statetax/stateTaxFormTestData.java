package Sites.CandidatePortal.Forms.Objects.statetax;

public class stateTaxFormTestData {

    public final static String strUserID = "990077362";
    public final static String strEmailAddress = "Eabgjgbhmcqeldhefdkhfee@SterlingONE.com";
    public final static String strUserPassword = "rQtw4PIlc7DNXvQCDhe3yQ=="; //Test!234
    public final static String strCandidatePortalID = "OTkwMDc3MzYy";
    public static int [] packageIDs = {8418303};
    public static String[] packageName = {"New Hire Forms FS532"};

    public enum ColoradoStatesDetails
    {
        MARTIALSTATUS("Single"),
        NOOFALLOWANCES("2"),
        ADDITIONALAMOUNT("0");

        private String strData;

        private ColoradoStatesDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  UtahAndOregonStatesDetails
    {
        MARTIALSTATUS("Single"),
        NOOFALLOWANCES("2"),
        ADDITIONALAMOUNT("0");

        private String strData;

        private UtahAndOregonStatesDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  CaliforniaStatesDetails
    {
        MARTIALSTATUS("Single"),
        NOOFALLOWANCES("2"),
        ADDITIONALAMOUNT("0");

        private String strData;

        private CaliforniaStatesDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichiganStatesDetails
    {
        TOTALEXCEMPTION("0"),
        ADDITIONALWITHHOLDINGS("0"),
        WITHHOLDINGSTATUS("Fully Subject to Taxes"),
        REASON("a. no tax liability"),
        CITY("Flint");

        private String strData;

        private MichiganStatesDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  NorthCarolinaStateDetails
    {
        TOTALALLOWANCES("0"),
        ADDITIONALWITHHOLDINGS("0"),
        MARTIALSTATUS("Single"),
        COUNTRYINITIALS("Unite");

        private String strData;

        private NorthCarolinaStateDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum PennsylvaniaStateDetails
    {
        MUNICIPALITY("Pittsburgh"),
        COUNTRY("Philadelphia County"),
        ADDRESSLINE1("texas delas"),
        CITY("Pittsburgh"),
        ZIPCODE("17212"),
        WITHHOLDINGSTATUS("Fully Subject to Taxes"),
        TOTALEARNINGS("1000000"),
        TOTALTAXPAID("40000");

        private String strData;

        private PennsylvaniaStateDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }

    }

    public enum  MichigenAlbinoCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenAlbinoCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenBattleCreekCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenBattleCreekCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenBigRapidsCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRESOROTHERDEPENDENT("0");

        private String strData;

        private MichigenBigRapidsCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenDetroitCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenDetroitCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichcigenFlintDetails
    {
        EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND("2"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichcigenFlintDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenGrandRapidsCittDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenGrandRapidsCittDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenGraylingCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenGraylingCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenHamtramckCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenHamtramckCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenHighlandParkCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenHighlandParkCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenHudsonCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenHudsonCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenIoniaCityDetails
    {
        EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND("2"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenIoniaCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenJacksonCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenJacksonCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenLansingCityDetails
    {
        EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND("2"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenLansingCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenLapeerCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenLapeerCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenMuskegonCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenMuskegonCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenMuskegonHeightsDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenMuskegonHeightsDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenPontiacCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenPontiacCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenPortHuronDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenPortHuronDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenPortlandCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRESNOTHERDEPENDENT("0");

        private String strData;

        private MichigenPortlandCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenSaginawCityDetails
    {
        EXCEMPTIONFORYOURSELFNYOURWIFEORHUSBAND("2"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenSaginawCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum MichigenSpringfieldCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenSpringfieldCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }

    public enum  MichigenWalkerCityDetails
    {
        EXCEMPTIONFORYOURSELF("1"),
        EXCEMPTIONFORYOURWIFEORHUSBAND("1"),
        EXCEMPTIONFORYOURCHILDRES("0"),
        EXCEMPTIONFORYOUROTHERDEPENDENT("0");

        private String strData;

        private MichigenWalkerCityDetails(String strData)
        {
            this.strData = strData;
        }

        public String toString() {
            return strData;
        }
    }
}


