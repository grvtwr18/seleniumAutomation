package Sites.CandidatePortal;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.CandidatePortal.Forms.ViewPreAdvActionTaskPage;
import Sites.CandidatePortal.Forms.FormID87253001ProfilePage;
import Sites.Site;
import Sites.TalentWiseDashboard.ProductFormPages.AllSpecialReleasesPage;
import Sites.TalentWiseDashboard.ProductFormPages.ProductFormPages;
import Sites.TalentWiseDashboard.Search.Records.CandidateDetailsPage;
import Sites.TalentWiseDashboard.TimeOutWarningModal;
import Sites.URL;
import TWFramework.BodyTextHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import Workflows.Candidate;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;

/**
 * Page object that represents the Dashboard page for the Candidate Portal website.
 * @author eelefson
 * @author ssmith
 */
public class DashboardPage extends CandidatePortalPages {
    protected final static Logger staticLogger = LoggerFactory.getLogger("DashboardPage");
    @FindBy(how = How.ID, using = "tasknoteMessage")
    public static WebElement notificationMessage;

    @FindBy(how = How.CSS, using = "button")
    public static WebElement launchTaskButton;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    private static WebElement signOutLink;

    private static By redirectProxyDivLocator = By.xpath("//div[@class='intro']");

    @FindBy(how = How.ID, using = "lastFourSsn")
    private static WebElement lastFourSsnBox;

    @FindBy(how = How.ID, using = "permissionsSubmit")
    public static WebElement permissionsSubmitButton;

    private static String myDashboardID = "breadCrumbs";

    @FindBy(how = How.ID, using = "qmm")
    public static WebElement monthDropDown;

    @FindBy(how = How.ID, using = "qdd")
    public static WebElement dayDropDown;

    @FindBy(how = How.ID, using = "qyy")
    public static WebElement yearDropDown;

    @FindBy(how = How.ID, using = "driverLicense")
    public static WebElement driverLicenseTextBox;

    @FindBy(how = How.ID, using = "welcome")
    public static WebElement welcomeMessage;

    @FindBy(how = How.XPATH, using = ".//*[@class=\"statusNew\"]/*[@class=\"status\"]")
    public static WebElement statusNEW;

    @FindBy(how = How.XPATH, using = ".//*[@class=\"statusComplete\"]/*[@class=\"status\"]")
    public static WebElement statusComplete;

    @FindBy(how = How.XPATH, using = ".//*[@id='permissionsDialog']/following-sibling::table[1]//table/tbody/tr/td[1]")
    public static WebElement reportNumber;

    @FindBy(how = How.ID, using = "qf")
    private static WebElement firstName;

    @FindBy(how = How.ID, using = "qn")
    private static WebElement lastName;

    @FindBy(how = How.XPATH, using = "//b")
    private static WebElement baseProfileEmail;

    @FindBy(how = How.CSS, using = "//div[@class = \"dbContentWrapper\"]")
    private static WebElement screeningContent;

    @FindBy(how = How.XPATH, using = "//td[contains(text(), 'Complete and Sign Individualized Assessment')]/following-sibling::td/button")
    private static WebElement irLaunchButton;

    @FindBy(how = How.XPATH, using = "//td[contains(text(), 'Review Fair Chance Initiative and Complete Individual Assessment')]/following-sibling::td/button")
    private static WebElement nyFcLaunchButton;

    @FindBy(how = How.CLASS_NAME, using = "status")
    private static WebElement taskStatus;

    @FindBy(how = How.ID, using = "uberform")
    private static WebElement uberFormContent;

    @FindBy(how = How.XPATH, using = "//*[@id='widgetright2']//td[text()='Candidate tax documents']/following-sibling::td/a")
    private static List<WebElement> taxDocumentsLink;

    @FindBy(how = How.XPATH, using = "//*[@id='widgetright1']//td[starts-with(text(),'Upload Tax Document')]//following-sibling::td[text()='Complete']")
    private static WebElement uploadTaxDocumentStatus;

    @FindBy(how = How.LINK_TEXT, using = "A Summary of Your Rights Under the Fair Credit Reporting Act")
    private WebElement summaryLink;

    @FindBy(how = How.XPATH, using = "//th[text()='Requested by']/../td")
    private WebElement requestedBy;

    static {
        PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    public DashboardPage() {
        // Adding a wait to the constructor so the page load completes before the call returns
        SeleniumTest.waitForJQueryAjaxDone();
    }

    public static int getCandidateIdFromUrl() {
        return SeleniumTest.getParameterIdFromUrl("OverrideCandidateID");
    }

    public static CandidatePortalPages launchTaskByReportID(String reportID, Class<? extends CandidatePortalPages> returnedClass) {
        Driver.getDriver().findElement(By.id("launch-" + reportID)).click();
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static void launchTaskByReportID(String reportId) {
        Driver.getDriver().findElement(By.id("launch-" + reportId)).click();
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static void launchEDA() {
        Driver.getDriver().findElement(By.id("launch-")).click();
        SeleniumTest.waitForPageLoadToComplete();
    }

    /**
     * Returns intro text of proxy task completion page, value returned is "Proxy User Task Completion"
     *
     * @return
     */
    public static String getProxyPageIntroText() {
        return Driver.getDriver().findElement(By.cssSelector("div[class='intro']>span")).getText();
    }

    /**
     * Attempts to make sure the Dashboard page is loaded before returning
     * If no text is supplied it will wait for the url to contain dashboard.php and
     * it will look for the Sterling Talent Solutions image in the footer
     * If you supply textToLookFor it will find this text in the page source before returning
     *
     * @param textToLookFor The text you want to search for on the page.
     */
    public static void waitForPageToLoad(String... textToLookFor) {
        waitForPageLoad("dashboard.php", textToLookFor);
    }

    /**
     * Click on Launch Task
     *
     * @return
     * @author jgupta
     */
    public static CandidatePortalPages launchTask(Class<? extends CandidatePortalPages> returnedClass) {
        launchTaskButton.click();
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), 10);
        if (!SeleniumTest.getPageSource().contains("Adverse Action"))
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.panel>div.title")));
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static ViewPreAdvActionTaskPage launchAdvActionTask() {
        WindowManagement.runMethodToOpenNewWindow(
                () -> SeleniumTest.click(By.xpath("//td[contains(text(), 'Adverse Action')]/"
                        + "following-sibling::td/button[@id='launch-']")),
                false
        );

        return PageFactory.initElements(Driver.getDriver(), ViewPreAdvActionTaskPage.class);
    }

    public static CandidatePortalPages launchIrTask(Class<? extends CandidatePortalPages> returnedClass) {
        final By locator = By.xpath("//td[contains(text(), 'Complete and Sign Individualized Assessment')]/following-sibling::td/button");
        try {
            SeleniumTest.clickUntilElementDisappearsNoWaiting(locator);
        } catch (WebDriverException e) {
            staticLogger.warn("Could not click to launch IR Task : {}", e.toString());
            e.printStackTrace();
            if (TimeOutWarningModal.isVisible()) {
                staticLogger.warn("Clicking Continue on \"Time out warning\" Modal Dialog");
                TimeOutWarningModal.clickContinueButton();
                SeleniumTest.clickUntilElementDisappearsNoWaiting(locator);
            } else {
                throw e;
            }
        }
        return PageFactory.initElements(Driver.getDriver(), returnedClass);
    }

    public static boolean isIrTaskDisabled() {
        return SeleniumTest.isElementDisabled(irLaunchButton);
    }

    public static boolean isFcTaskDisabled() {
        return SeleniumTest.isElementDisabled(nyFcLaunchButton);
    }

    public static AllSpecialReleasesPage clickLaunchTask() {
        SeleniumTest.click(launchTaskButton);
        return PageFactory.initElements(Driver.getDriver(),AllSpecialReleasesPage.class);
    }


    public static ProductFormPages clickLaunchTask(Class<? extends ProductFormPages> returnClass) {
        clickLaunchTask();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Clicks on launch button corresponding to the task id.
     *
     * @param TaskID
     * @return
     */
    public static CandidatePortalPages launchTask(String TaskID) {
        // Wait for the buttons to be visible
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("button")));

        //Get a list of all the launch buttons and click on the launch button with the corresponding task ID.
        List<WebElement> launchButtons = Driver.getDriver().findElements(By.tagName("button"));
        for (WebElement item : launchButtons) {
            String onclick = item.getAttribute("onclick");
            if (onclick.contains(TaskID)) {
                item.click();
                break;
            }


        }
        return PageFactory.initElements(Driver.getDriver(), FormID87253001ProfilePage.class);
    }

    /**
     * Clicks on launch button corresponding to the task id.
     *
     * @param TaskID
     * @return
     */
    public static CandidatePortalPages launchTask(String TaskID, Class<? extends CandidatePortalPages> returnClass) {
        staticLogger.info("Launch Task");
        // Wait for the buttons to be visible
        WebDriverWait wait = new WebDriverWait(Driver.getDriver(), 30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("button")));

        //Get a list of all the launch buttons and click on the launch button with the corresponding task ID.
        List<WebElement> launchButtons = Driver.getDriver().findElements(By.tagName("button"));
        for (WebElement item : launchButtons) {
            String onclick = item.getAttribute("onclick");
            String attrId = item.getAttribute("id") != null ? item.getAttribute("id") : "";
            if (onclick.contains(TaskID) && attrId.contains("launch")) {
                item.click();
                break;
            }
        }
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Click the button to view the report associated with the given reportId.
     *
     * @param reportId
     */
    public static DashboardPage clickViewReport(String reportId) {
        SeleniumTest.click(Driver.getDriver().findElement(By.id("report_" + reportId)));
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Type in the last 4 chars of the given lastFourSsn.
     *
     * @param lastFourSsn
     */
    public static void typeLastFourSsn(String lastFourSsn) {
        SeleniumTest.clearAndSetText(lastFourSsnBox, lastFourSsn.substring(lastFourSsn.length() - 4));
    }

    /**
     * Retruns the task ID of the first launch button on dashboard page.
     *
     * @return
     */
    public String getTaskID() {
        String[] parts = (launchTaskButton.getAttribute("onclick")).split("&");
                /* For Debugging
                for (String x: parts){
                    System.out.println(x);
                }*/
        String[] taskID = parts[2].split("=");
        return taskID[1];
    }

    /**
     * Clicks on Sign out link.
     *
     * @return PortalSignInPage
     */
    public static PortalSignInPage clickSignOut() {
        signOutLink.click();
        Driver.getDriver().manage().deleteAllCookies();
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    /**
     * Get the notification message displayed in Notification bubble.
     *
     * @return
     */
    public static String getNotificationMessage() {
        return notificationMessage.getText();
    }

    /**
     * Returns the text displayed when redirected to the dashboard on task completion.
     *
     * @return String representation of the text
     */
    public static String getRedirectedTextOnCompletion() {
        SeleniumTest.waitForElementVisible(redirectProxyDivLocator);
        return Driver.getDriver().findElement(redirectProxyDivLocator).getText();

    }

    /**
     * This method selects the DOB in the report authentication dialog displayed for VRO reports
     * when candidate tries to open them.
     *
     * @param dob Date of birth of the candidate.
     */
    public static void selectDobForReportAuthentication(LocalDate dob) {
        Select monthSelect = new Select(monthDropDown);
        Select daySelect = new Select(dayDropDown);
        Select yearSelect = new Select(yearDropDown);

        String month = dob.getMonth().getDisplayName(TextStyle.SHORT, Locale.US);
        String day = (Integer.toString(dob.getDayOfMonth()));
        String year = (Integer.toString(dob.getYear()));

        monthSelect.selectByVisibleText(month);
        daySelect.selectByVisibleText(day);
        yearSelect.selectByVisibleText(year);
    }

    /**
     * This method clicks on the submit button in the report authentication dialog displayed for
     * VRO reports.
     */
    public static void clickSubmit() {
        WindowManagement.clickElementToOpenNewWindow(permissionsSubmitButton, 2, false);
    }

    /**
     * This method types the driving license in the report authentication dialog displayed for
     * VRO reports.
     *
     * @param license
     */
    public static void typeDriversLicenseForReportAuthentication(String license) {
        SeleniumTest.clearAndSetText(driverLicenseTextBox, license);
    }

    public static String getColumnValueByReportId(String reportId, column c) {
        return WebDriver.Driver.getDriver().findElement(By.xpath("//button[contains(@id,'" +
                reportId + "')]/../parent::tr/td[" +
                c.getVal() + "]")).getText();
    }

    public static String getButtonText(String reportId) {
        return WebDriver.Driver.getDriver().findElement(By.id("launch-" + reportId)).getText();
    }

    public static String getWelcomeText() {
        return welcomeMessage.getText();
    }

    /**
     * @return The number of Tasks that are with status "NEW"
     */
    public static int getNewTaskCount() {
        return Driver.getDriver().findElements(By.cssSelector("tr.statusNew")).size();
    }

    public static boolean isDobFieldForVroAuthVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("qmm"));
    }

    public static boolean isLicenseFieldForVroAuthVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("driverLicense"));
    }

    public static boolean isSsnFieldForVroAuthVisible() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("lastFourSsn"));
    }

    public static String getTaskStatus() {
        return SeleniumTest.getText(taskStatus);
    }

    public static String getCompleteStatus() {
        return SeleniumTest.getText(statusComplete);
    }

    public static String getReportNumber() {
        return SeleniumTest.getText(reportNumber);
    }

    public static String getStatusForNewTask() {
        return SeleniumTest.getText(statusNEW);
    }

    public static void navigateTo(String portal) {
        String urlPath = URL.getURL(Site.CANDIDATE_PORTAL)
                + "/" + portal + "/ptl/verifydashboard.php";
        Driver.getDriver().get(urlPath);
        staticLogger.info("Navigating to {} directly", urlPath);

    }

    public enum column {
        TASK(1, "Task"),
        DUE_DATE(2, "Due Date"),
        STATUS(3, "Status");

        private int val;
        private final String text;

        column(int val, final String text) {
            this.val = val;
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }

        public int getVal() {
            return val;
        }
    }

    public static WebElement getScreeningContent() {
        return screeningContent;
    }

    public static void launchTask() {
        SeleniumTest.click(Driver.getDriver().findElement(By.id("launch-")));
    }

    public static WebElement getUberformContent() {
        return uberFormContent;
    }

    public static void hideStaticElements() {
        BodyTextHelper.hideElement(firstName);
        BodyTextHelper.hideElement(lastName);
        BodyTextHelper.hideElement(baseProfileEmail);

    }

    public static String getHiringProcessStatus(String positionName) {
        return SeleniumTest.getTextByLocator(By.xpath(".//*[text()='" + positionName + "']/../../../td[3]"));
    }

    public static String getReportID() {
        String id = launchTaskButton.getAttribute("id");
        return id.split("-")[1];
    }

    public static IDVerificationPage launchIdVerifyTask() {
        SeleniumTest.click(By.id("launch-"));
        return new IDVerificationPage();
    }

    public static String getFirstTaskName() {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"widgetright1\"]/div[2]/div[3]/table/tbody/tr[2]/td[1]"));
    }

    public static String getSecondTaskName() {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"widgetright1\"]/div[2]/div[3]/table/tbody/tr[3]/td[1]"));
    }

    public static String getFirstTaskStatus() {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"widgetright1\"]/div[2]/div[3]/table/tbody/tr[2]/td[3]"));
    }

    public static String getSecondTaskStatus() {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"widgetright1\"]/div[2]/div[3]/table/tbody/tr[3]/td[3]"));
    }

    public static String getFirstTaskDueDate() {
        return SeleniumTest.getTextByLocator(By.xpath("//*[@id=\"widgetright1\"]/div[2]/div[3]/table/tbody/tr[2]/td[2]"));
    }

    /*Get the total number of Tax documents link in My Documents section */
    public static int getTaxDocsLinkCount() {
        return taxDocumentsLink.size();
    }


    public static String getTextForUploadTaxDocumentStatus(){
        return SeleniumTest.getText(uploadTaxDocumentStatus);
    }

    public boolean verifyReportContent(String text){
        SeleniumTest.isElementVisibleNoWaiting(By.linkText("A Summary of Your Rights Under the Fair Credit Reporting Act"));
        return SeleniumTest.getText(requestedBy).contains(text);
    }
}
