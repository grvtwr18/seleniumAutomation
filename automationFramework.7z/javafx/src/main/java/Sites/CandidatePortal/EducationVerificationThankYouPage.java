package Sites.CandidatePortal;


import TWFramework.SeleniumTest;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Vivek.Rai on 4/17/2018.
 * This page is used in Education verification flow. This page has the Thank You! message and the ticket id which was created in the flow.
 */
public class EducationVerificationThankYouPage {

    /* Thank you message */
    @FindBy(css = ".dbFixedWidth>h2")
    private static WebElement thankYouMessage;

    /* Ticket ID number */
    @FindBy(css = "#ticketId")
    private static WebElement ticketIDNumber;

    /* Sign Out link */
    @FindBy(linkText = "Sign Out")
    private static WebElement signOut;


    public String getThankYouMessage(){
        return thankYouMessage.getText();
    }

    public String getTicketID(){

        return ticketIDNumber.getText();
    }

    public void clickSignOut(){
        SeleniumTest.click(signOut);
    }
}

