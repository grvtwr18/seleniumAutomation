package Sites.CandidatePortal;

import Sites.AdminConsole.AdminHomePage;
import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Page object that represents the Change Password page for the Candidate Portal website.
 * Created by jgupta on 11/28/2015.
 */

public class ChangePasswordPage extends CandidatePortalPages {

    @FindBy(how = How.NAME, using = "OldPassword")
    private static WebElement oldPasswordTextBox;

    @FindBy(how = How.NAME, using = "NewPassword")
    private static WebElement newPasswordTextBox;

    @FindBy(how = How.NAME, using = "NewPassword_Confirm")
    private static WebElement reTypePasswordTextBox;

    @FindBy(how = How.XPATH, using = "//input[@class='button']")
    private static WebElement changeButton;

    @FindBy(how = How.XPATH, using = "//*[@id=\"widgetleft1\"]/div[2]/div/form/div[4]/input")
    private static WebElement changeButtonStaticUrl;

    @FindBy(how = How.XPATH, using = "//*[@id=\"widgetleft1\"]/div[2]/div/p")
    private static WebElement changePasswordErrorMessage;

    @FindBy(xpath = "//h3[contains(@class,'bold green')]")
    private static WebElement changePasswordSuccessMessage;

    @FindBy(how = How.ID, using = "breadCrumbs")
    private static WebElement breadcrumbs;

    @FindBy(how = How.ID, using = "contentLeft")
    private static WebElement form;

    @FindBy(how = How.ID, using = "contentRight")
    private static WebElement criteria;

    private static final String NOT_MATCH_EXPECTED_TEXT = "Passwords do not match.";

    protected static Logger logger = LoggerFactory.getLogger("ChangePasswordPage");

    static {
        PageFactory.initElements(Driver.getDriver(), ChangePasswordPage.class);
    }

    /**
     * This method fills and submits the change password form when verifier has to reset temporary password
     * @param newPassword
     */
    public static CandidatePortalPages changePassword(String newPassword, Class<? extends CandidatePortalPages> returnClass) {
        logger.info("Set new password");
        SeleniumTest.clearAndSetText(newPasswordTextBox,newPassword);
        retypeNewPassword("This will totally not match");
        clickChangeButton(ChangePasswordPage.class);
        SeleniumTest.verifyElementTextEquals(getPasswordsNotMatchExpectedText(), changePasswordErrorMessage);
        retypeNewPassword(newPassword);
        return clickChangeButton(returnClass);

    }

    /**
     * This method fills and submits the change password form when verifier has to reset temporary password
     * @param newPassword
     */
    public static CandidatePortalPages changePasswordAndSubmit(String newPassword, Class<? extends
            CandidatePortalPages> returnClass) {
        logger.info("Set new password");
        SeleniumTest.clearAndSetText(newPasswordTextBox,newPassword);
        retypeNewPassword(newPassword);
        return clickChangeButton(returnClass);

    }

    /**
     * This method fills and submits the change password form when verifier has to reset temporary password
     * it's a new method because on the staticURL flow, the locator changes.
     * //TODO get dev to add an ID
     * @param newPassword
     */
    public static void changePasswordStaticURL(String newPassword) {
        logger.info("Set new password");
        SeleniumTest.clearAndSetText(newPasswordTextBox, newPassword);
        logger.info("Confirm new password");
        SeleniumTest.clearAndSetText(reTypePasswordTextBox, newPassword);
        logger.info("Click change");
        SeleniumTest.click(changeButtonStaticUrl);
    }

    /**
     * This method fills and submits the change password form when verifier has to reset expired password
     * @param oldPassword
     * @param newPassword
     * @param returnClass
     * @return
     */
    public static CandidatePortalPages changeExpiredPassword(String oldPassword, String newPassword, Class<? extends CandidatePortalPages> returnClass) {
        typeOldPassword(oldPassword);
        typeNewPassword(newPassword);
        retypeNewPassword(newPassword);
        changeButton.click();
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    /**
     * Types old password in old password text box.
     * @param oldPassword
     * @return
     */
    public static ChangePasswordPage typeOldPassword(String oldPassword){
        SeleniumTest.clearAndSetText(oldPasswordTextBox, oldPassword);
        return PageFactory.initElements(Driver.getDriver(), ChangePasswordPage.class);
    }

    /**
     * Types new password in new password text box.
     * @param newPassword
     * @return
     */
    public static ChangePasswordPage typeNewPassword(String newPassword){
        SeleniumTest.clearAndSetText(newPasswordTextBox, newPassword);
        return PageFactory.initElements(Driver.getDriver(), ChangePasswordPage.class);
    }

    /**
     * Types new password in retype new password text box.
     * @param newPassword
     * @return
     */
    public static ChangePasswordPage retypeNewPassword(String newPassword){
        SeleniumTest.clearAndSetText(reTypePasswordTextBox, newPassword);
        return PageFactory.initElements(Driver.getDriver(), ChangePasswordPage.class);
    }

    /**
     * clicks on change password button
     * @param returnClass
     * @return
     */
    public static CandidatePortalPages clickChangeButton(Class<? extends CandidatePortalPages> returnClass) {
        try {
            changeButton.click();
        } catch (NoSuchElementException | ElementNotVisibleException e) {
            // Use an alternate way to find this button -
            // using this method to find the button in the case this is an I-9 Initial candidate login
            // not changing the original .click() method to ensure we don't break other tests
            Driver.getDriver().findElement(By.xpath("//input[contains(@value,'Change')]")).click();
        }
        return PageFactory.initElements(Driver.getDriver(), returnClass);
    }

    public static String getPasswordsNotMatchExpectedText() {
        return NOT_MATCH_EXPECTED_TEXT;
    }

    public static String getChangePasswordErrorMessage() {
        return changePasswordErrorMessage.getText();
    }

    public static Boolean isPasswordResetMessagePresent() {
        WaitUntil.waitUntil(60, 3, () -> changePasswordSuccessMessage.isDisplayed());
        return true;
    }

    /**
     * Change password: enter old password and retype new password and click change
     */
    public static void changeToNewPassword(String newPassword) {
        typeNewPassword(newPassword);
        retypeNewPassword(newPassword);
        changeButton.click();
    }

    public static WebElement getBreadcrumb(){
        return breadcrumbs;
    }

    public static WebElement getForm(){
        return form;
    }

    public static WebElement getCriteria(){
        return criteria;
    }
}
