package Sites.CandidatePortal;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import static TWFramework.JavaScriptHelper.runScript;

/**
 * Page object that represents the Forgot Password page for the Candidate Portal website.
 * @author eelefson
 */
public class ForgotPasswordPage extends CandidatePortalPages {
	@SuppressWarnings("unused")

	@FindBy(how = How.NAME, using = "Email")
	private static WebElement emailBox;
	
	@FindBy(how = How.XPATH, using = "//input[@value='Submit']")
	private static WebElement submitButton;

	@FindBy(how = How.CLASS_NAME, using = "resetloginfail")
	private static WebElement resetPasswordNeededMessage;
    //TODO: change this when FDN-877 is fixed
	private final static String resetPasswordNeededMessageExpectedText = "You have made too many attempts. Please reset your password";

	@FindBy(how = How.XPATH, using = "//*[@id=\"widgetleft1\"]/div[2]/div")
	private static WebElement passwordResetMessage;
	//TODO: change this when FDN-877 is fixed

	//note that this is a hidden field which only shows up in dev
	@FindBy(how = How.ID, using = "tempPassword")
	private static WebElement tempPassword;

	@FindBy(how = How.NAME, using = "csrf_token")
	private static WebElement csrfToken;

	@FindBy(how = How.XPATH, using = "//*[@id=\"widgetleft1\"]/div[2]/div/p")
	private static WebElement csrfErrorMessage;

	private static final String csrfErrorMessageExpectedText = "The page has expired.";

	static {
		PageFactory.initElements(Driver.getDriver(), Sites.CandidatePortal.ForgotPasswordPage.class);
	}
	
	/**
	 * Constructs a new Forgot Password page object.
	 */
	public ForgotPasswordPage() {
		SeleniumTest.waitForJQueryAjaxDone();
    }

	public static String getResetPasswordNeededMessage() {
		return resetPasswordNeededMessage.getText();
	}

	public static String getResetPasswordNeededMessageExpectedText() {
		return resetPasswordNeededMessageExpectedText;
	}

	//FDN-615 AC2
	public static String getPasswordResetMessage() {
		return passwordResetMessage.getText();
	}

	//TODO: update this for FDN-615
	public static String getPasswordResetMessageExpectedText(String email) {
		return "A new, temporary password has been sent to you.\n"
				+"\n"
				+"If you don't receive an email containing your temporary password within ten minutes, please check to see that you are using the correct email address and try again.\n"
				+"After you receive your new, temporary password, you can use it to sign in to your account.\n"
				+"\n"
				+"Sign In";
	}

	public static String getEmail() {
		return emailBox.getAttribute("Value");
	}

	public static String getTempPassword() {
		// getText doesn't work for hidden fields, thus textContent
		return tempPassword.getAttribute("textContent");
	}

	/**
	 * Types the specified email into the email text box.
	 * @param email The email to be typed
	 */
	public static void typeEmail(String email) {
		SeleniumTest.clearAndSetText(emailBox, email);
	}
	
	/**
	 * Clicks the "Submit" button.
	 */
	public static void clickSubmitButton() {
		submitButton.click();
        PageFactory.initElements(Driver.getDriver(), Sites.CandidatePortal.ForgotPasswordPage.class);
	}

	public static boolean isCsrfTokenHidden() {
		return !csrfToken.isDisplayed();
	}

	public static String getCsrfErrorMessageExpectedText() {
		return csrfErrorMessageExpectedText;
	}

	public static String getCsrfErrorMessage() {
		return csrfErrorMessage.getText();
	}

	public static String getCsrfTokenValue() {
		return csrfToken.getAttribute("value");
	}

	public static void clearCsrfTokenValue() {
		setCsrfTokenValue("");
	}

	public static void setCsrfTokenValue(String newValue) {
		runScript("document.getElementsByName('csrf_token')[0].value = '" + newValue + "'");
	}
}
