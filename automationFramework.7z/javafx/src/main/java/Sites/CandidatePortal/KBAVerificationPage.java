package Sites.CandidatePortal;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by MNam on 4/4/2018.
 */
public class KBAVerificationPage {
    @FindBy(how = How.XPATH, using = "//input[@type='radio']")
    private WebElement question1;

    @FindBy(how = How.ID, using = "kba-question-submit")
    private WebElement nextButton;

    @FindBy(how = How.XPATH, using = "//b[contains(text(),'Canada Post Physical Identity Verification')]")
    private WebElement canadaPostIDVerificationHeader;

    @FindBy(how = How.XPATH, using = "//input[@value='Create my Document']")
    private WebElement createMyDoc;


    public KBAVerificationPage() {
        initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public void selectQuestion1() {
        SeleniumTest.check(question1);
    }

    public void clickNext() {
        SeleniumTest.click(nextButton);
    }

    //alert Resend Cancel
    public void clickResend() {
        if(SeleniumTest.isAlertPresent()) {
            SeleniumTest.acceptAlert();
        }
    }

    public String getMessageHeaderText() {
        return SeleniumTest.getTextByLocator(By.className("idverification-header"));
    }

    // Boolean function to return if Canada Post ID Verification page is displayed or not
    public boolean iscanadaPostIdVerHeaderVisible() {
        boolean isCanadaPostHeaderVisible = SeleniumTest.isElementVisible(canadaPostIDVerificationHeader);
        return isCanadaPostHeaderVisible;
    }
    // Boolean function to return if Download Canada Post Form is displayed or not
    public boolean iscreateMyDocBtnVisible() {
        boolean iscreatemyDocBtnVisible = SeleniumTest.isElementVisible(createMyDoc);
        return iscreatemyDocBtnVisible;
    }
}