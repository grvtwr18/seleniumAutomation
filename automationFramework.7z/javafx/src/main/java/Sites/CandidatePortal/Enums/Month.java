package Sites.CandidatePortal.Enums;

/**
 * Stores and enumerates months for dates in the portal.  Contains the full month name,
 * the month abbreviation, and the numeric value of the month (1-12)
 * @author kparker
 */
public enum Month {
    JAN("January", "Jan", 1),
    FEB("February", "Feb", 2),
    MAR("March", "Mar", 3),
    APR("April", "Apr", 4),
    MAY("May", "May", 5),
    JUNE("June", "June", 6),
    JULY("July", "July", 7),
    AUG("August", "Aug", 8),
    SEPT("September", "Sept", 9),
    OCT("October", "Oct", 10),
    NOV("November", "Nov", 11),
    DEC("December", "Dec", 12);

    private String name;
    private String abbreviation;
    private Integer numeric;

    Month(String name, String abbreviation, Integer numeric) {
        this.name = name;
        this.abbreviation = abbreviation;
        this.numeric = numeric;
    }

    public String full() {
        return name;
    }

    public String abbreviation() {
        return abbreviation;
    }

    public Integer numeric() {
        return numeric;
    }

    public static Month parse(String input) {
        if (null == input) {
            throw new IllegalArgumentException("Cannot parse Month for input null.");
        }
        input = input.trim();
        for (Month month : values()) {
            if (month.name.equalsIgnoreCase(input)
                || month.abbreviation.equalsIgnoreCase(input)) {
                return month;
            }
        }
        // If we didn't find a month by exact string, try again by finding a month
        // name that starts with the input ...
        for (Month month : values()) {
            if (month.name.startsWith(input)) {
                return month;
            }
        }
        // If we get here, no Month value comes close to the given string.
        throw new IllegalArgumentException("No such Month resembles the given input: " + input);
    }

    public static Month from(java.time.Month javaMonth) {
        for (Month month : values()) {
            if (month.numeric.equals(javaMonth.getValue())) {
                return month;
            }
        }
        throw new IllegalArgumentException("No such Month appears to match: " + javaMonth);
    }

    @Override
    public String toString() {
        return full();
    }
}