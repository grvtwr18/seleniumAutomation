package Sites.CandidatePortal;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by MNam on 4/2/2018.
 */
public class IDVerificationPage {

    @FindBy(how = How.ID, using = "submitWelcome")
    private WebElement verifyMyIdentity;

    @FindBy(how = How.ID, using = "optOutKBA")
    private WebElement optOutOfTUAuth;

    @FindBy(how = How.ID, using = "candidateKBAConsent")
    private WebElement consent;

    @FindBy(how = How.ID, using = "submitOffRamp")
    private WebElement continueCanadaDPOIBtn;

    @FindBy(how = How.ID, using = "qrescountryconfirm")
    private WebElement confirmCountryCheckBox;

    @FindBy(how = How.ID, using = "submitVerifyResidenceBtn")
    private WebElement continueBtn;



    public IDVerificationPage() {
        initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public void checkConsent() {
        SeleniumTest.check(consent);
    }

    public KBAVerificationPage clickVerifyMyIdentity() {
        SeleniumTest.click(verifyMyIdentity);
        return new KBAVerificationPage();
    }
    public void clickOptOutOfTransUnionAuth() {
        SeleniumTest.click(optOutOfTUAuth);
    }
    public void clickContinueBtnCanadaDPOI() {
        SeleniumTest.click(continueCanadaDPOIBtn);
    }

    public void clickconfirmCountryCheckBox() {
        SeleniumTest.click(confirmCountryCheckBox);
    }

    public void clickContinueBtn() {
        SeleniumTest.click(continueBtn);
    }
}