package Sites.CandidatePortal;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.Site;
import Sites.URL;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class CompletedInfoForBGSPage extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "ticketId")
    private static WebElement ticketIdField;

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalContent\"]/div[1]/div[1]/span")
    private static WebElement orderField;

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalContent\"]/button[1]")
    private static WebElement returnToDashboardButton;

    @FindBy(how = How.XPATH, using = "//a[contains(.,'Sign Out')]")
    private static WebElement signOutButton;

    static {
        PageFactory.initElements(Driver.getDriver(), CompletedInfoForBGSPage.class);
    }

    /**
     * @return the generated ticket id displayed on this page.
     */
    public static String getTicketId() {
        return SeleniumTest.getText(ticketIdField).replaceAll("\\D", "");
    }

    public static String getOrderId() {
        return SeleniumTest.getText(orderField).replaceAll("\\D", "");
    }

    /**
     * Clicks the "Return to Dashboard" button.
     * @return A new Dashboard page object
     */
    public static DashboardPage clickReturnToDashboardButton() {
        SeleniumTest.click(returnToDashboardButton);
        return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
    }

    /**
     * Clicks the "Sign Out" button.
     * @return A new Portal Sign In page object
     */
    public static PortalSignInPage clickSignOutButton() {
        SeleniumTest.click(signOutButton);
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

    public static boolean onPage() {
        return SeleniumTest.isElementVisibleNoWaiting(By.id("ticketId"))
                && SeleniumTest.isElementVisibleNoWaiting(By.xpath("//*[@id=\"portalContent\"]/button[1]"));
    }

    //the order of signout button is different in id verification portal, safe way click sign-out link
    public static PortalSignInPage clickSignOutLink() {
        SeleniumTest.click(By.xpath("//a[@href='ptl/signout.php']"));
        return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
    }

}
