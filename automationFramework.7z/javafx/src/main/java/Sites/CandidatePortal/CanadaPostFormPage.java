package Sites.CandidatePortal;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CanadaPostFormPage {
    @FindBy(how = How.ID, using = "submitWelcome")
    private WebElement createMyDocument;

    @FindBy(how = How.ID, using = "qf")
    private WebElement fname;

    @FindBy(how = How.ID, using = "qn")
    private WebElement lname;

    @FindBy(how = How.ID, using = "qmm")
    private WebElement dobMonth;

    @FindBy(how = How.ID, using = "qdd")
    private WebElement dobDay;

    @FindBy(how = How.ID, using = "qyy")
    private WebElement dobYear;

    @FindBy(how = How.NAME, using = "qa")
    private WebElement address;

    @FindBy(how = How.NAME, using = "qc")
    private WebElement city;

    @FindBy(how = How.NAME, using = "qs")
    private WebElement province;

    @FindBy(how = How.NAME, using = "qz")
    private WebElement zcode;

    @FindBy(how = How.CLASS_NAME, using = "dpoi-center dpoi-congrat-msg")
    private WebElement successText;

    @FindBy(how = How.ID, using = "dpoiFormLink")
    private WebElement dpoiDocumentlink;

    @FindBy(how = How.ID, using = "scheduleAnotherCandidate")
    private WebElement returnToDashboard;


    public CanadaPostFormPage() {
        initializePageFactory();
    }

    public void initializePageFactory() {
        PageFactory.initElements(Driver.getDriver(), this);
    }

    public String getFirstName() {
        return SeleniumTest.getText(fname);
    }

    public String getLastName() {
        return SeleniumTest.getText(lname);
    }

    public String getDOBMonth() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(dobMonth);
    }

    public String getDOBDay() {
        return  SeleniumTest.getSingleSelectedVisibleTextFromDropDown(dobDay);
    }

    public String getDOBYear() {
        return  SeleniumTest.getSingleSelectedVisibleTextFromDropDown(dobYear);
    }

    public String getAddress() {
        return SeleniumTest.getText(address);
    }

    public String getCity() {
        return SeleniumTest.getText(city);
    }

    public String getProvince() {
        return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(province);
    }

    public String getZipCode() {
        return SeleniumTest.getText(zcode);
    }

    public void clickCreateMyDocument() {
        SeleniumTest.click(createMyDocument);
    }

    public String getSuccessTextMessage() {
        return SeleniumTest.getText(successText);
    }
}
