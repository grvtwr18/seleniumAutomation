package Sites.CandidatePortal.Eda;

import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the "Sign the Disclosure and Authorization Offline" page for the Candidate Portal website.
 * @author eelefson
 */
public class SignDisclosureOfflinePage {

    // The following assumes that the "Confirm" button will always show up before the "<< Start Over" button,
    // so it will always be found first with this XPATH.
    // The problem is the document.submitConsent.Page.value has been observed to alternate between 6 and 10 ...
    @FindBy(how = How.XPATH, using = "//input[starts-with(@onclick, 'document.submitConsent.Page.value=')]")
    private static WebElement confirmButton;

    @FindBy(how = How.XPATH, using = "//input[@onclick='document.submitConsent.Page.value=2;']")
    private static WebElement startOverButton;

    @FindBy(how = How.XPATH, using = "//*[@id=\"portalContent\"]/div[1]")
    private static WebElement mainDisclosure;

    static {
        PageFactory.initElements(Driver.getDriver(), ElectronicDisclosurePage.class);
    }

    /**
     * Clicks the "I'm Done" button.
     * @return A new Completed Electronic Disclosure page object
     */
    public CompletedElectronicDisclosurePage clickConfirmButton() {
        SeleniumTest.click(confirmButton);
        return PageFactory.initElements(Driver.getDriver(), CompletedElectronicDisclosurePage.class);
    }

    /**
     * Clicks the "<< Start Over" button.
     * @return A new Electronic Disclosure page object
     */
    public ElectronicDisclosurePage clickStartOverButton() {
        startOverButton.click();
        return PageFactory.initElements(Driver.getDriver(), ElectronicDisclosurePage.class);
    }

    public static WebElement getMainDisclosure() {
        return mainDisclosure;
    }

    public static String getConfirmButtonText() {
        return confirmButton.getAttribute("value");
    }

    public static String getStartOverButtonText() {
        return startOverButton.getAttribute("value");
    }

    public static String getExpectedConfirmButtonText(LocaleHelper.Locale locale) {
        switch (locale.toString()) {
            case "en_US":       return "Confirm";

            case "qps_PLOC":    return "[{70d9} Ƈǿƞƒīřḿ]";

            default:            return "Confirm";
        }
    }

    public static String getExpectedStartOverButtonText(LocaleHelper.Locale locale) {
        switch (locale.toString()) {
            case "en_US":       return "<< Start Over";

            case "qps_PLOC":    return "<< [{82d6} Şŧȧřŧ Ǿṽḗř]";

            default:            return "<< Start Over";
        }
    }
}