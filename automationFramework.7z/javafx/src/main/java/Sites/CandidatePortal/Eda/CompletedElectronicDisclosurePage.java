package Sites.CandidatePortal.Eda;

import Sites.CandidatePortal.DashboardPage;
import Sites.CandidatePortal.PortalSignInPage;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Completed Electronic Disclosure page for the Candidate Portal website.
 * @author tjoshi
 */
public class CompletedElectronicDisclosurePage extends SeleniumTest{

	@FindBy(how = How.XPATH, using = ".//*[contains(text(),'Return to Dashboard')]")
	private WebElement returnToDashboardButton;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(), 'Sign Out')]")
	private WebElement signOutButton;
	
	@FindBy(how = How.CSS, using = "body > div:nth-child(3) > div > div > h2")
	private WebElement confirmationMessage;
	
	/**
	 * Constructs a new Completed Electronic Disclosure page object.
	 */
	public CompletedElectronicDisclosurePage() {
    }
	
	/**
	 * Clicks the "Return to Dashboard" button.
	 * @return A new Dashboard page object
	 */
	public DashboardPage clickReturnToDashboardButton() {
		returnToDashboardButton.click();
		return PageFactory.initElements(Driver.getDriver(), DashboardPage.class);
	}

	public void clickReturnToDashboard(){
		SeleniumTest.waitForPageLoad();
		SeleniumTest.click(returnToDashboardButton);
	}
	
	/**
	 * Clicks the "Sign Out" button.
	 * @return A new Portal Sign In page object
	 */
	public PortalSignInPage clickSignOutButton() {
		signOutButton.click();
		return PageFactory.initElements(Driver.getDriver(), PortalSignInPage.class);
	}

	/**
	 * Get generated ticket id from the message
	 * @return
     */
	public static String getGeneratedTicketId() {
		String ticket = Driver.getDriver().findElement(By.xpath("//p[contains(text(),'Your ticket ID is ')]")).getText();
		String ticketID = ticket.replaceAll("Your ticket ID is ", "");
		ticketID = ticketID.replaceAll("\\D","");
		return ticketID;
	}
}
