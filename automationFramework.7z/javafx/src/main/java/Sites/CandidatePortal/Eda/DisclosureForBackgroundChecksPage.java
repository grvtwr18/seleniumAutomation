package Sites.CandidatePortal.Eda;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Disclosure For Background Checks page for the Candidate Portal website.
 * @author eelefson
 */
public class DisclosureForBackgroundChecksPage {

	@FindBy(how = How.XPATH, using = "//*/form[@name='submitConsent']/*/input")
	private WebElement continueButton;

	@FindBy(how = How.XPATH, using = "//*[@id='portalContent']/div[1]")
	private static WebElement legalText;

	private static final ThreadLocal<DisclosureForBackgroundChecksPage> threadLocalInstance;

	static {
		threadLocalInstance = ThreadLocal.withInitial(
					            () -> PageFactory.initElements(Driver.getDriver(), DisclosureForBackgroundChecksPage.class));
	}

	private static DisclosureForBackgroundChecksPage getInstance() {
		return threadLocalInstance.get();
	}
	
	/**
	 * Clicks the "Continue" button, expecting one of two possible subsequent pages.
	 * @return A new NoticePerCaliforniaLawPage object.
	 */
	public static NoticePerCaliforniaLawPage clickContinueButtonExpectingNoticePerCaliforniaLawPage() {
		SeleniumTest.click(getInstance().continueButton);
		return PageFactory.initElements(Driver.getDriver(), NoticePerCaliforniaLawPage.class);
	}
	/**
	 * Clicks the "Continue" button, expecting the other of two possible subsequent pages.
	 * @return A new NoticePerCaliforniaLawPage object.
	 */
	public static AuthorizationForBackgroundChecksPage clickContinueButtonExpectingAuthorizationForBackgroundChecksPage() {
		getInstance().continueButton.click();
		return PageFactory.initElements(Driver.getDriver(), AuthorizationForBackgroundChecksPage.class);
	}

	public static String getLegalText(){
		return legalText.getText().trim();
	}
}