package Sites.CandidatePortal.Eda;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.JavaScriptHelper;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import Sites.AdminConsole.EditUser.EditPreferencesPage;
import Sites.AdminConsole.EditUser.UserManagementPage;

/**
 * Page object that represents the Electronic Disclosure page for the Candidate Portal website.
 * @author eelefson
 */
public class ElectronicDisclosurePage extends CandidatePortalPages {

	// The following assumes that the "I Agree ..." button will always show up before the "I Decline ..." button,
	// so it will always be found first with this XPATH.
	// The problem is the document.submitConsent.Page.value has been observed to alternate between 3 and 4 ...
	@FindBy(how=How.XPATH, using = "//input[starts-with(@onclick, 'document.submitConsent.Page.value=')]")
	private static WebElement agreeButton;
	
	@FindBy(how = How.XPATH, using = "//input[@onclick='document.submitConsent.Page.value=5;']")
	private static WebElement declineButton;

    @FindBy(how = How.CLASS_NAME, using = "disclosureSection")
    private static WebElement disclosure;

	@FindBy(how = How.XPATH, using = "//*[@id='portalContent']/div[1]")
	private static WebElement legalText;

	@FindBy(how = How.XPATH, using = "//*[@id='portalContent']/form/div/input")
	private static WebElement continueButton;

	@FindBy(how = How.XPATH,using = "//div[@class='disclosureButton']/input")
	private WebElement disclosureBackgroundCheckContinueButton;

	@FindBy(how = How.XPATH,using = "//input[@type='submit' and @value='Continue >>']")
	private WebElement continueEDA;

	@FindBy(how = How.ID, using = "qo_Group24-0_1")
	private WebElement drivingLicenseIssuedCountry;

	@FindBy(how = How.ID,using = "qs_Group24-0_1_CA")
	private WebElement drivingLicenseIssuedState;

	@FindBy(how = How.ID,using = "qdl_Group24-0_1")
	private WebElement drivingLicenseNumber;

	@FindBy(how = How.ID, using = "agreeBtn")
	private WebElement iAgreeBtn;

	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Data Transfer Consent')]")
	private WebElement dataTransferConsentHeader;

    static {
		PageFactory.initElements(Driver.getDriver(), ElectronicDisclosurePage.class);
	}
	
	/**
	 * Clicks the "I Agree to Use an Electronic Signature" button.
	 * @return A new Disclosure For Background Checks page object
	 */
	public static DisclosureForBackgroundChecksPage clickAgreeButton() {
		SeleniumTest.waitForElementVisible(agreeButton);
		agreeButton.click();
		return PageFactory.initElements(Driver.getDriver(), DisclosureForBackgroundChecksPage.class);
	}
	
	/**
	 * Clicks the "I Decline to Use an Electronic Signature" button.
	 * @return A new Sign Offline page object
	 */
	public static SignDisclosureOfflinePage clickDeclineButton() {
		declineButton.click();
		return PageFactory.initElements(Driver.getDriver(), SignDisclosureOfflinePage.class);
	}

    public static WebElement getDisclosure() {
        return disclosure;
    }

    public static String getAgreeButtonText() {
	    return agreeButton.getAttribute("value");
    }

    public static String getDeclineButtonText() {
	    return declineButton.getAttribute("value");
    }

    public static String getExpectedAgreeButtonText(LocaleHelper.Locale locale) {
	    switch (locale.toString()) {
            case "en_US":       return "I Agree to Use an Electronic Signature";

            case "qps_PLOC":    return "[{bfb7} .Ī Ȧɠřḗḗ ŧǿ Ŭşḗ ȧƞ Ḗŀḗƈŧřǿƞīƈ Şīɠƞȧŧŭřḗ.]";

            default:            return "I Agree to Use an Electronic Signature";
        }
    }

    public static String getExpectedDeclineButtonText(LocaleHelper.Locale locale) {
        switch (locale.toString()) {
            case "en_US":       return "I Decline to Use an Electronic Signature";

            case "qps_PLOC":    return "[{4053} .Ī Ḓḗƈŀīƞḗ ŧǿ Ŭşḗ ȧƞ Ḗŀḗƈŧřǿƞīƈ Şīɠƞȧŧŭřḗ.]";

            default:            return "I Decline to Use an Electronic Signature";
        }
    }

	public static boolean enableEDAforUberForm()
	{
		EditPreferencesPage editPreferencesPage = UserManagementPage.clickPreferencesLink();
		staticLogger.info("Click on the \"Ticketing\" tab");
		editPreferencesPage.clickParentTab(EditPreferencesPage.ParentTab.TICKETING);
		staticLogger.info("Click to \"Enable Electronic Disclosure and Autorization for Ticketing\"");
		editPreferencesPage.clickEnableElectronicDisclosureAndAuthorizationForTicketing();
		staticLogger.info("Click to Update Preferences");
		editPreferencesPage.clickUpdatePreferences();
		staticLogger.info("Click to \"Enable Electronic Disclosure and Autorization for Uberform\"");
		editPreferencesPage.enableEdaForUberform();
		staticLogger.info("Click to Update Preferences");
		editPreferencesPage.clickUpdatePreferences();

		if(!SeleniumTest.getPageSource().contains("successfully updated the user's preferences"))
		{
			return false;
		}else{
			return true;
		}
	}

	public static String getLegalText(){
		return legalText.getText().trim();
	}


	public static void clickContinue (){
		SeleniumTest.click(continueButton);
	}

	public AuthorizationForBackgroundChecksPage clickDisclosureBackgroundCheckContinueButton() {
		SeleniumTest.click(disclosureBackgroundCheckContinueButton);
		return PageFactory.initElements(Driver.getDriver(), AuthorizationForBackgroundChecksPage.class);
	}

	public void fillCandidateDrivingDetails(String drivingLicenseCountry,String drivingLicenseState,String drivingLicenseNo) {
		SeleniumTest.selectByVisibleTextFromDropDown(drivingLicenseIssuedCountry,drivingLicenseCountry);
		SeleniumTest.selectByVisibleTextFromDropDown(drivingLicenseIssuedState,drivingLicenseState);
		SeleniumTest.clearAndSetText(drivingLicenseNumber,drivingLicenseNo);
	}
	//Click on continue button
	public void clickContinueBtnEDA(){
		SeleniumTest.click(continueEDA);
	}

	//Testcase with Mexico as the Country of Residence is navigating to a Data Transfer Consent form Page, So I have initialized this function with Auth page
	public  AuthorizationForBackgroundChecksPage clickiAgreeBtn() {
		JavaScriptHelper.scrollElementIntoView(iAgreeBtn);
		JavaScriptHelper.click(iAgreeBtn);
		return PageFactory.initElements(Driver.getDriver(), AuthorizationForBackgroundChecksPage.class);

	}
	public boolean isDataTransferConsentHeaderVisible(){
		return SeleniumTest.isElementVisible(dataTransferConsentHeader);
	}

}
