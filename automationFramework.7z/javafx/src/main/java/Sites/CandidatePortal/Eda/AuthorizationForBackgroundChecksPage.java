package Sites.CandidatePortal.Eda;

import Sites.CandidatePortal.Enums.Country;
import Sites.CandidatePortal.Enums.StateOrProvince;
import Sites.TalentWiseDashboard.ProductFormPages.ScreeningLaunchPage;
import TWFramework.JavaScriptHelper;
import TWFramework.LocaleHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import Workflows.Candidate;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Page object that represents the Authorization For Background Checks page for the Candidate Portal website.
 * @author eelefson
 */
public class AuthorizationForBackgroundChecksPage {
	List<String> headers = new ArrayList<>();
	public enum SignatureOption {

		PRE_RENDERED_SIGNATURE(5), // Changed from 3 to 5 by GL-1800
		DRAW_OWN_SIGNATURE(4);

		private final int value;

		SignatureOption(final int value) { this.value = value; }

		public int getValue() { return value; }
	}

	@FindBy(how = How.NAME, using = "qf")
	private static WebElement firstNameBox;

	@FindBy(how = How.NAME, using = "qmi")
	private static WebElement middleNameBox;
	
	@FindBy(how = How.NAME, using = "qn")
	private static WebElement lastNameBox;
	
	@FindBy(how = How.NAME, using = "qmm")
	private static WebElement monthDropDownBox;
	
	@FindBy(how = How.NAME, using = "qdd")
	private static WebElement dayDropDownBox;
	
	@FindBy(how = How.NAME, using = "qyy")
	private static WebElement yearDropDownBox;
	
	@FindBy(how = How.NAME, using = "qee")
	private static WebElement emailBox;
	
	@FindBy(how = How.NAME, using = "qssn")
	private static WebElement ssnBox;
	
	@FindBy(how = How.NAME, using = "qo")
	private static WebElement countryDropDown;
	
	@FindBy(how = How.NAME, using = "qa")
	public static WebElement addressBox;
	
	@FindBy(how = How.NAME, using = "qc")
	private static WebElement cityBox;
	
	@FindBy(how = How.NAME, using = "qs")
	private static WebElement stateOrProvinceDropDown;
	
	@FindBy(how = How.NAME, using = "qz")
	private static WebElement postalCodeBox;
	
	@FindBy(how = How.NAME, using = "Agree")
	private static WebElement agreeCheckBox;
	
	@FindBy(how = How.NAME, using = "RequestReport")
	private static WebElement requestReportCheckBox;
	
	@FindBy(how = How.ID, using = "signatureName")
	private WebElement signatureNameBox;
	
	@FindBy(how = How.LINK_TEXT, using = "Update Signature")
	private WebElement updateSignatureLink;

	@FindBy(how = How.ID, using = "submitEdaButton")
	private static WebElement understandAndAgreeButton;

	@FindBy(how = How.XPATH, using = "//*[@id=\"portalContent\"]/form/div[4]")
	private static WebElement disclosureForm;

	@FindBy(how = How.ID, using = "eSignature")
	private static WebElement eSignature;

	@FindBy(how = How.XPATH, using = "//*[text()=\"Signature\"]/../../../*[contains(@id,'esign-radio')]")
	private static WebElement preRenderSignature;

	@FindBy(how = How.ID, using = "eda-as-www-edit-PostalCode")
	private WebElement postalCode;

	@FindBy(how = How.ID, using = "qsbirth")
	private WebElement birthProvinceSelect;

	@FindBy(how = How.ID, using = "qp")
	private static WebElement phoneNumberBox;

	@FindBy(how = How.XPATH, using = "//*[@id='portalContent']/div[1]")
	private static WebElement errorMessage;

	@FindBy(how = How.XPATH, using = "//*[@id='portalContent']/form/div[1]/h2")
	private static WebElement candidateAuthorizationText;

	@FindBy(how = How.ID, using = "textForSignature")
	private WebElement electronicSignatureConfirmYourNameBox;

	@FindBy(how = How.ID, using = "textForInitials")
	private WebElement electronicSignatureIntialsBox;

	@FindBy(how = How.NAME, using = "qdls")
	private WebElement licenseState;

	@FindBy(how = How.NAME, using = "qdlo")
	private WebElement licenseCountry;

	@FindBy(how = How.NAME, using = "qdl")
	private WebElement license;

	@FindBy(how = How.NAME, using = "qdlp")
	private WebElement licenseStateForCA;

	@FindBy(how = How.XPATH, using = "//input[@type='submit'][@value='Attach']")
	private WebElement attachBtn;

	@FindBy(how = How.NAME, using = "fEdaWetSignature")
	private WebElement chooseFileBtn;

	@FindBy(how = How.XPATH, using = "//input[@value='Continue >>']")
	private WebElement continueBtnCandidatePortal;

	@FindBy(how = How.ID, using = "file_document_1_Group232-0_1")
	private WebElement chooseFileBtnEmp;

	private final By invalidDriverLicenseErrorLabel = By.xpath("//div[@class='dbAnnouncement']/ol/li[text()='Invalid Driver License']");
	private final By licenseStateUS = By.name("qdls");

	@FindBy(how = How.CLASS_NAME, using = "disclosureCheckbox")
	private static WebElement disclosureCheckbox;

	@FindBy(how = How.XPATH, using = "//div[@class='_uploadFileFormField']/h4")
	private List<WebElement> additionalDocsHeadersList;

	/**
	 * Constructs a new "Authorization For Background Checks" page object.
	 */
	public AuthorizationForBackgroundChecksPage() {
	}

	static {
		PageFactory.initElements(Driver.getDriver(), AuthorizationForBackgroundChecksPage.class);
	}
	
	/**
	 * Types the specified first name into the first name text box.
	 * @param firstName The first name to be typed
	 */
	public static void typeFirstName(String firstName) {
		SeleniumTest.clearAndSetText(firstNameBox, firstName);
	}
	
	/**
	 * Types the specified middle name into the middle name text box.
	 * @param middleName The middle name to be typed
	 */
	public static void typeMiddleName(String middleName) {
		SeleniumTest.clearAndSetText(middleNameBox, middleName);
	}
	
	/**
	 * Types the specified last name into the last name text box.
	 * @param lastName The last name to be typed
	 */
	public static void typeLastName(String lastName) {
		SeleniumTest.clearAndSetText(lastNameBox, lastName);
	}
	
	/**
	 * Selects a month from the month drop down box based on the date provided.
	 * @param month The month to be selected
	 */
	public static void selectMonth(String month) {
		SeleniumTest.waitForElementToBeClickable(monthDropDownBox);
		Select monthSelect = new Select(monthDropDownBox);
		monthSelect.selectByVisibleText(month);
	}

	public static void selectMonth(LocalDate date) {
		SeleniumTest.selectShortMonthByVisibleText(monthDropDownBox, date);
	}

	public static void selectMonth(Integer month) {
		SeleniumTest.selectByValueFromDropDown(monthDropDownBox, month.toString());
	}

	/**
	 * Selects a day from the day drop down box based on the date provided.
	 * @param day The day to be selected
	 */
	public static void selectDay(String day) {
		Select daySelect = new Select(dayDropDownBox);
		daySelect.selectByVisibleText(day);
	}

	public static void selectDay(LocalDate date) {
		new Select(dayDropDownBox).selectByVisibleText(String.valueOf(date.getDayOfMonth()));
	}
	
	/**
	 * Selects a year from the year drop down box based on the date provided.
	 * @param year The year to be selected
	 */
	public static void selectYear(String year) {
		Select yearSelect = new Select(yearDropDownBox);
		yearSelect.selectByVisibleText(year);
	}

	public static void selectYear(LocalDate date) {
		new Select(yearDropDownBox).selectByVisibleText(String.valueOf(date.getYear()));
	}
	
	/**
	 * Types the specified email into the email text box.
	 * @param email The email to be typed
	 */
	public static void typeEmail(String email) {
		SeleniumTest.clearAndSetText(emailBox, email);
	}
	
	/**
	 * Types the specified SSN into the SSN text box.
	 * @param ssn The SSN to be typed
	 */
	public static void typeSSN(String ssn) {
		SeleniumTest.clearAndSetText(ssnBox, ssn);
	}

	public static boolean isSSNVisible() {
		return SeleniumTest.isElementVisibleNoWaiting(By.name("qssn"));
	}
	
	/**
	 * Selects the specified country from the country drop down box.
	 * @param country The country to be selected
	 */
	public static void selectCountry(Country country) {
		Select countrySelect = new Select(countryDropDown);
		countrySelect.selectByVisibleText(country.toString());
	}

	public static void selectCountryAbbreviation(String country) {
		SeleniumTest.selectByValueFromDropDown(countryDropDown, country);
	}
	
	/**
	 * Types the specified address into the address text box.
	 * @param address The address to be typed
	 */
	public static void typeAddress(String address) {
		WaitUntil.waitUntil(() -> {return addressBox.isEnabled();});
		SeleniumTest.clearAndSetText(addressBox, address);
	}

	/**
	 * Types the specified city into the city text box.
	 * @param city The city to be typed
	 */
	public static void typeCity(String city) {
		SeleniumTest.clearAndSetText(cityBox, city);
	}
	
	/**
	 * Selects the specified state or province from the state or province drop down box.
	 * @param stateOrProvince The state or province to be selected
	 */
	public static void selectState(StateOrProvince stateOrProvince) {
		Select stateSelect = new Select(stateOrProvinceDropDown);
		stateSelect.selectByVisibleText(stateOrProvince.toString());
	}

	public static void selectStateAbbreviation(String stateOrProvince) {
		SeleniumTest.selectByValueFromDropDown(stateOrProvinceDropDown, stateOrProvince);
	}
	
	/**
	 * Types the specified postal code into the postal code text box.
	 * @param postalCode The postal code to be typed
	 */
	public static void typePostalCode(String postalCode) {
		SeleniumTest.clearAndSetText(postalCodeBox, postalCode);
	}

	/**
	 * Clicks the agree check box.
	 */
	public static void clickAgreeCheckBox() {
		SeleniumTest.check(agreeCheckBox);
	}
	
	/**
	 * Clicks the request report check box.
	 */
	public static void clickRequestReportCheckBox() {
		requestReportCheckBox.click();
	}
	
	/**
	 * Clicks the "Update Signature" link.
	 */
	public void clickUpdateSignatureLink() {
		updateSignatureLink.click();
	}
	
	/**
	 * Types the specified signature name into the signature name text box.
	 * @param signatureName The signature name to be typed
	 */
	public void typeSignatureName(String signatureName) {
		SeleniumTest.clearAndSetText(signatureNameBox, signatureName);
	}

	
	/**
	 * Selects one of the premade electronic signature options provided.
	 * @param signatureOption option whether to use a pre-rendered signature or draw one's own signature
	 */
	public static void selectElectronicSignatureRadioOption(SignatureOption signatureOption) {
		SeleniumTest.click(By.id("esign-radio" + signatureOption.getValue()));
	}

	/**
	 * Clicks the "I Understand and Agree" button.
	 *
	 * @return null
	 */
	public static <T> T clickUnderstandAndAgreeButton() {
		return clickUnderstandAndAgreeButton(null);
	}

	/**
	 * Clicks the "I Understand and Agree" button.
	 *
	 * @param pageClassToProxy the expected class of the Page to land on
	 *
	 * @return An instance of the expected Page class
	 */
	public static <T> T clickUnderstandAndAgreeButton(Class<T> pageClassToProxy) {
		SeleniumTest.click(understandAndAgreeButton);
		// Do not wait for the understandAndAgreeButton to not be present; that wastes about 15 seconds of time unnecessarily.
		// Callers who relied on this method waiting for understandAndAgree to go away, should
		// instead rely on some new WebElement expected to become visible.
		return (null == pageClassToProxy) ? null : PageFactory.initElements(Driver.getDriver(), pageClassToProxy);
	}

	public static <T> T fillAndSubmit(Candidate candidate, Class<T> pageClassToProxy) {
		typeFirstName(candidate.getFirstName());
		typeMiddleName(candidate.getMiddleName());
		typeLastName(candidate.getLastName());
		selectMonth(candidate.getDobMonthValue());
		selectDay(candidate.getDobDay());
		selectYear(candidate.getDobYear());
		typeEmail(candidate.getEmailAddress());

		if (SeleniumTest.isElementVisibleNoWaiting(By.name("qssn"))) {
			typeSSN(candidate.getSocialSecurityNumber());
		}

		if (countryDropDown.isDisplayed()) {
			Country country = Country.valueOf(candidate.getCountryOrRegion().toUpperCase().replaceAll(" ", "_"));
			selectCountry(country);

			// Need to pause for the country logic to complete
			SeleniumTest.waitMs(2000);
		}

		typeAddress(candidate.getAddressLine1());
		typeCity(candidate.getCity());

		StateOrProvince state = StateOrProvince.valueOf(candidate.getState().toUpperCase().replaceAll(" ", "_"));
		selectState(state);

		typePostalCode(candidate.getZip());
		clickAgreeCheckBox();

                // Apparently the index of the Pre-Rendered Signature radio button changes, but PRE_RENDERED_SIGNATURE
                // was here first, so it can be in place until they come up with a better solution ...

		selectElectronicSignatureRadioOption(SignatureOption.PRE_RENDERED_SIGNATURE);

		return clickUnderstandAndAgreeButton(pageClassToProxy);
	}

	//Fill out the ticket form using drop down values rather than visible text to work on
	// localized pages
	public static <T> T fillAndSubmitLocalized(Candidate candidate, Class<T> pageClassToProxy) {
		typeFirstName(candidate.getFirstName());
		typeMiddleName(candidate.getMiddleName());
		typeLastName(candidate.getLastName());
		selectMonth(candidate.getDobMonthValue());
		selectDay(candidate.getDobDay());
		selectYear(candidate.getDobYear());
		typeEmail(candidate.getEmailAddress());
		typeSSN(candidate.getSocialSecurityNumber());

		if (countryDropDown.isDisplayed()) {
			String country = Country.valueOf(candidate.getCountryOrRegion().toUpperCase().replaceAll
					(" ", "_")).abbreviation();
			selectCountryAbbreviation(country);

			// Need to pause for the country logic to complete
			SeleniumTest.waitMs(2000);
		}

		typeAddress(candidate.getAddressLine1());
		typeCity(candidate.getCity());

		String state = StateOrProvince.valueOf(candidate.getState().toUpperCase().replaceAll(" ", "_")).abbreviation();
		selectStateAbbreviation(state);

		typePostalCode(candidate.getZip());
		clickAgreeCheckBox();
		selectElectronicSignatureRadioOption(SignatureOption.PRE_RENDERED_SIGNATURE);

		return clickUnderstandAndAgreeButton(pageClassToProxy);
	}


	public static WebElement getDisclosureForm() {
		return disclosureForm;
	}

	public static WebElement getESignature() {
		return eSignature;
	}

	public static String getAgreeButtonText() {
		return understandAndAgreeButton.getAttribute("value");
	}

	public static String getExpectedAgreeButtonText(LocaleHelper.Locale locale) {
		switch (locale.toString()) {
			case "en_US":		return "I Understand and Agree";

			case "qps_PLOC":	return "[{a3ed} Ī Ŭƞḓḗřşŧȧƞḓ ȧƞḓ Ȧɠřḗḗ]";

			default:			return "I Understand and Agree";
		}
	}

	public static <T> T fillDataAndSubmit(Candidate candidate, Class<T> pageClassToProxy) {
		typeFirstName(candidate.getFirstName());
		typeMiddleName(candidate.getMiddleName());
		typeLastName(candidate.getLastName());
		selectMonth(candidate.getDobMonthValue());
		selectDay(candidate.getDobDay());
		selectYear(candidate.getDobYear());
		typeEmail(candidate.getEmailAddress());

		if(candidate.getSocialSecurityNumber()==null) {
			candidate.setSocialSecurityNumber(candidate.ssnFaker());
		}

		candidate.setSocialSecurityNumber(candidate.getSocialSecurityNumber());

		if (SeleniumTest.isElementVisibleNoWaiting(By.name("qssn"))) {
			typeSSN(candidate.getSocialSecurityNumber());
		}

		if (SeleniumTest.isElementVisibleNoWaiting(By.name("qo"))){
			Country country = Country.valueOf(candidate.getCountryOrRegion().toUpperCase().replaceAll(" ", "_"));
			selectCountry(country);

			// Need to pause for the country logic to complete
			SeleniumTest.waitMs(2000);
		}

		typeAddress(candidate.getAddressLine1());
		typeCity(candidate.getCity());

		StateOrProvince state = StateOrProvince.valueOf(candidate.getState().toUpperCase().replaceAll(" ", "_"));
		selectState(state);

		typePostalCode(candidate.getZip());
		clickAgreeCheckBox();
		SeleniumTest.click(preRenderSignature);

		return clickUnderstandAndAgreeButton(pageClassToProxy);
	}


	/**
	 * Types the specified phone number into the phone number text box.
	 * @param phoneNumber The Phone Number to be typed
	 */
	public static void typePhoneNumber(String phoneNumber) {
		SeleniumTest.clearAndSetText(phoneNumberBox, phoneNumber);
	}

	public static String getErrorMessage(){
		return errorMessage.getText().trim();
	}

	public String getFirstNameBox() {
		JavaScriptHelper.scrollElementIntoView(firstNameBox);
		return SeleniumTest.getText(firstNameBox);
	}

	public String getLastNameBox() {
		return SeleniumTest.getText(lastNameBox);
	}

	public String  getEmailBox() {
		return SeleniumTest.getText(emailBox);
	}

	public void typeElectronicSignatureConfirmYourNameBox(String name) {

		SeleniumTest.clearAndSetText(electronicSignatureConfirmYourNameBox,name);
	}

	public void typeElectronicSignatureIntialsBox(String name) {

		SeleniumTest.clearAndSetText(electronicSignatureIntialsBox,name);
	}

	public void selectLicenseState(StateOrProvince stateOrProvince) {
		if(SeleniumTest.isElementVisibleNoWaiting(licenseStateUS))
		SeleniumTest.selectByVisibleTextFromDropDown(licenseState,stateOrProvince.toString());
		else
			SeleniumTest.selectByVisibleTextFromDropDown(licenseStateForCA,stateOrProvince.toString());
	}

	public boolean isLicenseStateVisible() {
		return SeleniumTest.isElementVisibleNoWaiting(By.name("qdls"));
	}

	public void selectLicenseCountry(Country country) {
		SeleniumTest.selectByVisibleTextFromDropDown(licenseCountry,country.toString());
	}

	public boolean isLicenseCountryVisible() {
		return SeleniumTest.isElementVisibleNoWaiting(By.name("qdlo"));
	}

	public void typeLicenseNumber(String dl) {
		SeleniumTest.clearAndSetText(license,dl);
	}

	public boolean isLicenseNumberVisible(){
		return  SeleniumTest.isElementVisibleNoWaiting(By.name("qdl"));
	}

	public void fillCandidateDrivingDetails(String licenseNo) {
		if(SeleniumTest.isElementVisibleNoWaiting(invalidDriverLicenseErrorLabel))
		{
			selectLicenseCountry(Country.CANADA);
			selectLicenseState(StateOrProvince.QUEBEC);
			typeLicenseNumber(licenseNo);
			clickUnderstandAndAgreeButton();
		}
	}

	public static void checkDisclosureCheckBox(){
		SeleniumTest.check(disclosureCheckbox);
	}

	public String getMiddleNameBox() {
		return SeleniumTest.getText(middleNameBox);
	}

	public void fillUpTicketCandidateDetailsWithAKA (Candidate candidateDetails)
	{
		ScreeningLaunchPage.typeAlternateFirstName(candidateDetails.getAlternateFirstName());
		ScreeningLaunchPage.typeAlternateLastName(candidateDetails.getAlternateLastName());
		AuthorizationForBackgroundChecksPage.typeSSN(candidateDetails.getSocialSecurityNumber());
		AuthorizationForBackgroundChecksPage.selectMonth(candidateDetails.getDobMonth());
		AuthorizationForBackgroundChecksPage.selectDay(candidateDetails.getDobDay());
		AuthorizationForBackgroundChecksPage.selectYear(candidateDetails.getDobYear());
		AuthorizationForBackgroundChecksPage.typePhoneNumber(candidateDetails.getCandidatePhone());
		AuthorizationForBackgroundChecksPage.typeAddress(candidateDetails.getAddressLine1());
		AuthorizationForBackgroundChecksPage.typePostalCode(candidateDetails.getZip());
		AuthorizationForBackgroundChecksPage.typeCity(candidateDetails.getCity());
		AuthorizationForBackgroundChecksPage.selectState(StateOrProvince.GEORGIA);
	}

	/*
	This method compares the header of the the EDA description on Autorization Page in ticketing Flow. As we have two langauge
	display at this page header for them is common, so input repective header tag i.e 1 ,2 wiht repective order they are
	placed on the page.
	 */

	public boolean checkEDAHeadersOnTicketingPage(String headerToBeVerified, int hTagNumber, int respectiveHeaderNumber) {
        String EDAHeader = "//*[@class='disclosureSection flushTop']/h"+hTagNumber+"["+respectiveHeaderNumber+"]";

        return SeleniumTest.getTextByLocator(By.xpath(EDAHeader)).equals(headerToBeVerified);
    }
	public  void clickuploadFileEDA(String filePath) {
		JavaScriptHelper.scrollElementIntoView(chooseFileBtn);
		chooseFileBtn.sendKeys(filePath);
	}
	public  void clickAttachBtn() {
		JavaScriptHelper.scrollElementIntoView(attachBtn);
		JavaScriptHelper.click(attachBtn);
	}
	public  void clickContinueBtn() {
		JavaScriptHelper.scrollElementIntoView(continueBtnCandidatePortal);
		JavaScriptHelper.click(continueBtnCandidatePortal);

	}
	public  void uploadEmpFile(String filePath) {
		JavaScriptHelper.scrollElementIntoView(chooseFileBtnEmp);
		chooseFileBtnEmp.sendKeys(filePath);
	}
	public String getSelectedCountryInDropdown(){
		JavaScriptHelper.scrollElementIntoView(countryDropDown);
		return SeleniumTest.getSingleSelectedVisibleTextFromDropDown(countryDropDown);
	}

	public boolean isCountryDisabled() {
		return SeleniumTest.isElementDisabled(countryDropDown);
	}
	public List<String> additionalDocList(){
		for(WebElement e : additionalDocsHeadersList){
			String s =  SeleniumTest.getText(e);
			headers.add(s);
		}
		return headers;
	}
}