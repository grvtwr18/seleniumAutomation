package Sites.CandidatePortal.Eda;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object representing the EDA's "NOTICE REGARDING BACKGROUND CHECKS PER CALIFORNIA LAW" page.
 * Created by jpflager on 12/13/2015.
 */
public class NoticePerCaliforniaLawPage {

    @FindBy(how = How.XPATH, using = "//*/form[@name='submitConsent']/*/input")
    private static WebElement continueButton;

    private static final ThreadLocal<NoticePerCaliforniaLawPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(
                () -> PageFactory.initElements(Driver.getDriver(), NoticePerCaliforniaLawPage.class));
    }

    private static NoticePerCaliforniaLawPage getInstance() {
        return threadLocalInstance.get();
    }

    /**
     * Clicks the "Continue" button.
     * @return A new Authorization For Background Checks page object
     */
    public static AuthorizationForBackgroundChecksPage clickContinueButton() {
        SeleniumTest.click(getInstance().continueButton);
        return PageFactory.initElements(Driver.getDriver(), AuthorizationForBackgroundChecksPage.class);
    }

    public static boolean isContinueButtonDisplayed() {
        try {
            SeleniumTest.isElementVisible(continueButton);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}
