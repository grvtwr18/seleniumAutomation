package Sites.CandidatePortal;

import Sites.CandidatePortal.Forms.CandidatePortalPages;
import Sites.Site;
import Sites.URL;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by wogden on 5/23/2016 using Selenium Page Object Generator
 */

public class StaticUrlPage extends CandidatePortalPages {

    //region Page elements
    @FindBy(name = "EmailAddr")
    private static WebElement emailAddressNewUser;

    @FindBy(css = "div.content > div.contentInner > form > div.formField > input[name=\"EmailAddr\"]")
    private static WebElement emailAddressReturningUser;

    @FindBy(id = "FirstName")
    private static WebElement firstName;

    @FindBy(linkText = "Forget your password?")
    private static WebElement forgotYourPassword;

    @FindBy(id = "LastName")
    private static WebElement lastName;

    private final String pageLoadedText = "";

    @FindBy(name = "Password")
    private static WebElement password;

    @FindBy(xpath = "//input[@value=\"Sign In\"]")
    private static WebElement signIn;

    @FindBy(xpath = "//input[@value=\"Sign Up\"]")
    private static WebElement signUp;

    private static final By notificationBoxLocator =
            By.xpath("//div[@id='widgettop1']/div[@class='content']/div[1]/div[@class='noticeIcon']"
                     + "/following-sibling::div[1]");
    // TODO: is it worth separating this WebElement based on the type of notification (e.g.
    // class="Warning" for the numerically-determined div).

    @FindBy(css = "div.dbMessage")
    public static WebElement errorMessage;

    @FindBy(id = "tempPassword")
    private static WebElement tempPassword;
    //endregion

    public StaticUrlPage() {
    }

    /**
     * it loads the static URL page
     * @param staticLaunch for example, "/0720d0c0f1/ptl/staticlaunch.php?tk=LjpfbHdQTS46Xw"
     * @return the static url page
     */
    public static StaticUrlPage loadStaticUrlPage(String staticLaunch) {
        Driver.getDriver().get(URL.getURL(Site.CANDIDATE_PORTAL) + staticLaunch);
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    /**
     * Click on Forgot Your Password Link.
     *
     * @return the userDetails class instance.
     */
    public static ForgotPasswordPage clickForgotYourPasswordLink() {
        forgotYourPassword.click();
        return PageFactory.initElements(Driver.getDriver(), ForgotPasswordPage.class);
    }

    /**
     * Click on Sign In Button.
     *
     * @return the userDetails class instance.
     */
    public static StaticUrlPage clickSignInButton() {
        signIn.click();
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    public static String getTempPassword() {
        //Note that this is implemented in FDN-482
        PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
        return tempPassword.getAttribute("textContent");
    }

    /**
     * Click on Sign Up Button.  In most cases, next page will be StaticURL page
     * If you are bypassing password, it'll be the ChangePasswordPage
     * @return
     */
    public static CandidatePortalPages clickSignUpButton(Class<? extends CandidatePortalPages> nextPage) {
        signUp.click();
        return PageFactory.initElements(Driver.getDriver(), nextPage);
    }

    /**
     * Set value to Email Address Text field.
     *
     * @return the userDetails class instance.
     */
    public static StaticUrlPage setEmailAddressNewUserTextField(String emailAddressNewUserValue) {
        SeleniumTest.clearAndSetText(emailAddressNewUser,emailAddressNewUserValue);
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    /**
     * Set value to Email Address Text field.
     *
     * @return the userDetails class instance.
     */
    public static StaticUrlPage setEmailAddressReturningUserTextField(String emailAddressReturningUserValue) {
        SeleniumTest.clearAndSetText(emailAddressReturningUser,emailAddressReturningUserValue);
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    /**
     * Set value to First Name Text field.
     *
     * @return the userDetails class instance.
     */
    public static StaticUrlPage setFirstNameTextField(String firstNameValue) {
        SeleniumTest.clearAndSetText(firstName,firstNameValue);
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    /**
     * Set value to Last Name Text field.
     *
     * @return the userDetails class instance.
     */
    public static StaticUrlPage setLastNameTextField(String lastNameValue) {
        SeleniumTest.clearAndSetText(lastName,lastNameValue);
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    /**
     * Set value to Password Password field.
     *
     * @return the userDetails class instance.
     */
    public static StaticUrlPage setPasswordField(String passwordValue) {
        SeleniumTest.clearAndSetText(password,passwordValue);
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    /**
     * Submit the form to target page.
     *
     * @return the userDetails class instance.
     */
    public static StaticUrlPage submit() {
        clickSignInButton();
        return PageFactory.initElements(Driver.getDriver(), StaticUrlPage.class);
    }

    public static boolean isNotificationDisplayed() {
        return SeleniumTest.isElementVisibleNoWaiting(notificationBoxLocator);
    }

    /**
     * Set value to Password Password field.
     *
     * @return the userDetails class instance.
     */
    public static String getNotificationText() {
        return SeleniumTest.getTextByLocator(notificationBoxLocator);
    }

    public static String getErrorMessage() {
        return errorMessage.getText();
    }

}
