package Sites;

/**
 * Created by ssmith on 3/26/2015.
 */
public enum Site {
    NONE(null),
    APPS("apps"),
    ADMIN_CONSOLE("admin"),
    CANDIDATE_PORTAL("portal"),
    CUSTOMER_DASHBOARD(null),
    PLATFORM("platform"),
    SELFSCREEN("selfscreen"),
    VENDOR("vendor"),
    US_CUSTOMER("US customer"),
    CA_CUSTOMER("Create customer of CA instance");

    private String subdomain;

    Site(String subdomain) {
        this.subdomain = subdomain;
    }

    public String getSubdomain() {
        return subdomain;
    }
}