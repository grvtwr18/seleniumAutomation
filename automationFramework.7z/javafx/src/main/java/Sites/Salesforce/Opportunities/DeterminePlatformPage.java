package Sites.Salesforce.Opportunities;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Determine Platform page for the Salesforce website
 * Created by WBoyde on 2/8/2017.
 */
public class DeterminePlatformPage {

    /**
     * Static Constructor
     */
    static {
        PageFactory.initElements(Driver.getDriver(), DeterminePlatformPage.class);
    }

    /**
     * "Next" button
     * //*[@id="flowContainer"]/article/div/div[3]/footer/div[2]/button[2]/span
     */
    @FindBy(how = How.XPATH, using = "//div[@id='flowContainer']//button[contains(text(), 'Next')]")
    private static WebElement nextButton;
    public static void clickNextButton() { SeleniumTest.click(nextButton); }

    /**
     * "Previous" button
     * //*[@id="flowContainer"]/article/div/div[3]/footer/div[2]/button[1]/span
     */
    @FindBy(how = How.XPATH, using = "//div[@id='flowContainer']//span[contains(text(), 'Previous')]")
    private static WebElement previousButton;
    public static void clickPrevButton() { SeleniumTest.click(previousButton); }

    /**
     * "Finish" button
     * //*[@id="flowContainer"]/article/div/div[3]/footer/div[2]/button[2]/span
     */
    @FindBy(how = How.XPATH, using = "//div[@id='flowContainer']//button[contains(text(), 'Finish')]")
    private static WebElement finishButton;
    public static void clickFinishButton() {
        SeleniumTest.click(finishButton);
    }

    /**
     * Private helper method used to track down "select" element based on label text
     * (In Salesforce, you cannot always depend on the identifiers being consistent)
     *
     * example xpaths (for reference):
     * label:  //*[@id="flowContainer"]/article/div/div[3]/div[2]/div/div[1]/label/div/div/div[1]/div/div
     * select: //*[@id="flowContainer"]/article/div/div[3]/div[2]/div/div[1]/label/div/div/div[2]/select
     *
     * @param labelText
     * @return
     */
    private static WebElement findSelectElementByLabelText(String labelText) {
        // first, find element that contains the label text - from there, go up three levels, then down to select
        String xpathTemplate = "//div[@class='inputHeader'][div//div[contains(text(), '%s')]]//following-sibling::div//select";
        String xpath = String.format(xpathTemplate, labelText);
        WebElement elemSelect = Driver.getDriver().findElement(By.xpath(xpath));
        return elemSelect;
    }

    /**
     * Private helper method used to track down "textarea" element based on label text
     * (In Salesforce, you cannot always depend on the identifiers being consistent)
     *
     * example xpaths (for reference):
     * label:    //*[@id="flowContainer"]/article/div/div[3]/div[2]/div/label[5]/div/div/div[1]/div/div
     * textarea: //*[@id="flowContainer"]/article/div/div[3]/div[2]/div/label[5]/div/div/div[2]/div/textarea
     *
     * @param labelText
     * @return
     */
    private static WebElement findTextareaElementByLabelText(String labelText) {
        // first, find element that contains the label text - from there, go up three levels, then down to textarea
       String xpathTemplate = "//div[@class='inputHeader'][div//div[contains(text(), '%s')]]//following-sibling::div//textarea";
        String xpath = String.format(xpathTemplate, labelText);
        WebElement elemTextarea = Driver.getDriver().findElement(By.xpath(xpath));
        return elemTextarea;
    }

    /**
     * "Is this a Bishops, Verified Volunteers, or On Demand API Opportunity?"
     * @param value
     */
    public static void setBishopsVerifiedDemand(String value) {
        WebElement elemSel = findSelectElementByLabelText("Is this a Bishops");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "What is the primary country for where the searches are conducted?"
     * @param value
     */
    public static void setPrimaryCountry(String value) {
        WebElement elemSel = findSelectElementByLabelText("What is the primary country");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Is this an Xpera (CKR) account?"
     * @param value
     */
    public static void setXperaAccount(String value) {
        WebElement elemSel = findSelectElementByLabelText("Is this an Xpera");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Is this a subaccount, franchise, or contractor for a legacy customer?"
     * @param value
     */
    public static void setSubaccountFranchiseContractor(String value) {
        WebElement elemSel = findSelectElementByLabelText("Is this a subaccount");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Priced Currency"
     * @param value
     */
    public static void selectPricedCurrency(String value) {
        WebElement elemSel = findSelectElementByLabelText("Priced Currency");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Opportunity location: please select the invoice region for this opportunity."
     * @param value
     */
    public static void selectOppLocation(String value) {
        WebElement elemSel = findSelectElementByLabelText("Opportunity location:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Mobile: does the prospect require mobile-friendly candidate or client experience?"
     * @param value
     */
    public static void selectMobileStatus(String value) {
        WebElement elemSel = findSelectElementByLabelText("Mobile:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "API: does the prospect require On-Demand API?"
     * @param value
     */
    public static void selectOnDemandApi(String value) {
        WebElement elemSel = findSelectElementByLabelText("API:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Languages / localization: does the prospect require any aspects of the candidate
     *  or client experience to be in a language other than English?"
     * @param value
     */
    public static void selectLanguages(String value) {
        WebElement elemSel = findSelectElementByLabelText("Languages / localization:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Currency: does the prospect require to be invoiced / billed in a currency other than US dollar?"
     * @param value
     */
    public static void selectCurrency(String value) {
        WebElement elemSel = findSelectElementByLabelText("Currency:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Data residency: where does the prospect require their data to be stored? If there is no
     * specific requirement, select "Either"."
     * @param value
     */
    public static void selectDataResidency(String value) {
        WebElement elemSel = findSelectElementByLabelText("Data residency:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Onshore fulfillment: does the prospect have a legal requirement to have their data
     *  handled strictly by onshore staff (ex: government contractors)? If Yes, select specific
     *  country. If no, select "Any"."
     * @param value
     */
    public static void selectOnshoreFulfillment(String value) {
        WebElement elemSel = findSelectElementByLabelText("Onshore fulfillment:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Sub or franchisee: is the prospect a subsidiary or franchisee of an existing client? If yes,
     * select the platform where the existing client is currently set up. If no, select "No""
     * @param value
     */
    public static void selectSubsidiaryFranchise(String value) {
        WebElement elemSel = findSelectElementByLabelText("Sub or franchisee:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Sub or franchisee - unified account & billing currency (only if you responded "yes" to the
     * previous question): does the prospect require a single unified account + single billing currency?"
     * @param value
     */
    public static void selectSubFranchiseUnified(String value) {
        WebElement elemSel = findSelectElementByLabelText("Sub or franchisee - unified account");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Integrations: does the prospect require an integration with any of the following ATS/HRIS providers
     * NOT currently available on SterlingONE? If yes, select all that apply using Control-click (Windows)
     * or Command-click (Mac). If no, select "Existing or No Integration Required""
     * @param value
     */
    public static void selectIntegrations(String value) {
        WebElement elemSel = findSelectElementByLabelText("Integrations:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Platform features: does the prospect a require a platform feature NOT currently available on
     * SterlingONE? If yes, select all that apply using Control-click (Windows) or Command-click (Mac).
     * If no, select "None Required""
     * @param value
     */
    public static void selectPlatformFeatures(String value) {
        WebElement elemSel = findSelectElementByLabelText("Platform features:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "US products: does the prospect a require a US product NOT currently available on SterlingONE?
     * If yes, select all that apply using Control-click (Windows) or Command-click (Mac). If no, select "No""
     * @param value
     */
    public static void selectAmericanProducts(String value) {
        WebElement elemSel = findSelectElementByLabelText("US products:");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Non-US (aka "global") products: does the prospect a require a non-US product NOT currently available
     * on SterlingONE? If yes, select all that apply using Control-click (Windows) or Command-click (Mac).
     * If no, select "None Required""
     * @param value
     */
    public static void selectGlobalProducts(String value) {
        WebElement elemSel = findSelectElementByLabelText("Non-US (aka \"global\") products: does the prospect");
        SeleniumTest.selectByVisibleTextFromDropDown(elemSel, value);
    }

    /**
     * "Non-US (aka "global") products - countries & volume: for every non-US product selected in the
     * previous question, please provide all countries required, and expected volume by country (if known)"
     * @param value
     */
    public static void typeGlobalProductList(String value) {
        WebElement elemText = findTextareaElementByLabelText("Non-US (aka \"global\") products - countries & volume:");
        SeleniumTest.clearAndSetText(elemText, value);
    }

    /**
     * "Additional Comments on Platform"
     * @param value
     */
    public static void typeAdditionalComments(String value) {
        WebElement elemText = findTextareaElementByLabelText("Additional Comments");
        SeleniumTest.clearAndSetText(elemText, value);
    }
}
