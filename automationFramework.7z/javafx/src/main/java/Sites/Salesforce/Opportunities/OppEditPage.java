package Sites.Salesforce.Opportunities;

import Sites.Salesforce.Shared.RecordEditPageBase;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;

/**
 * Page object that represents the Create New Opportunity page for the Salesforce website
 * Created by WBoyde on 2/7/2017.
 */
public class OppEditPage extends RecordEditPageBase {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), OppEditPage.class);
    }


    public static void clickProcessedCheckBox(String Processed) {
        WebElement chkProcessedWE = Driver.getDriver().findElement(By.xpath("//table[@class='detailList']//td[span[label[.='" + Processed + "']]]//following-sibling::td//input"));
        JavaScriptHelper.scrollElementIntoView(chkProcessedWE);
        SeleniumTest.unCheck(chkProcessedWE);
    }


    public static void clickSaveButton() {
        WebElement lnkSaveWE = Driver.getDriver().findElement(By.xpath("(//input[@name='save'])[1]"));
        JavaScriptHelper.scrollElementIntoView(lnkSaveWE);
        SeleniumTest.click(lnkSaveWE);
    }
    // Page elements
}
