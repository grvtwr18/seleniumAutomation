package Sites.Salesforce.Opportunities;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Opportunities page for the Salesforce website
 * Created by WBoyde on 2/2/2017.
 */
public class OppOverviewPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), OppOverviewPage.class);
    }

    // Page elements
    // "New" button
    @FindBy(how = How.NAME, using = "new")
    private static WebElement newOpportunityButton;

    /**
     * Click on the "New" button to initiate creating a new Opportunity
     */
    public static void clickNewOpportunityButton() {
        JavaScriptHelper.scrollElementIntoView(newOpportunityButton);
        SeleniumTest.click(newOpportunityButton);
    }
}
