package Sites.Salesforce.Opportunities;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WindowManagement;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Page object that represents an Opportunity page for a specific Salesforce opportunity
 * Created by WBoyde on 2/7/2017.
 */
public class OppDetailPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), OppDetailPage.class);
    }

    // Opportunity Name
    @FindBy(how = How.CLASS_NAME, using = "pageDescription")
    private static WebElement opportunityName;

    /**
     * Retrieve Opportunity name from page
     * @return name of Opportunity
     */
    public static String getOpportunityName(){
        return opportunityName.getText();
    }

    // "edit" button
    @FindBy(how = How.NAME, using = "edit")
    private static WebElement editButton;

    /**
     * Click on "Edit" button to put record into edit mode
     */
    public static void clickEditButton() {
        JavaScriptHelper.scrollElementIntoView(editButton);
        SeleniumTest.click(editButton);
        SeleniumTest.waitForPageLoadToComplete();
    }

    /**
     * Helper method used to check if a specific page section is open or closed,
     * and if closed, open it
     * @param sectionName
     */
    private static void verifySectionOpen(String sectionName)
    {
        // get element that is section header
        String xPathSection = String.format("//*[@name='%s']", sectionName);
        WebElement elemSection = Driver.getDriver().findElement(By.xpath(xPathSection));

        // get class name
        String className = elemSection.getAttribute("class");

        // if class is currently "show" action (meaning "click to show")
        if (className.contains("showListButton"))
        {
            JavaScriptHelper.scrollElementIntoView(elemSection);
            SeleniumTest.click(elemSection);
        }

    }

    // Opportunity owner "change" button
    @FindBy(how = How.XPATH, using = "//div[@id='opp1_ileinner']//a[contains(text(),'Change')]")
    private static WebElement changeOppOwnerButton;

    /**
     * Click on "Change Opportunity Owner" button
     */
    public static void clickChangeOppOwnerButton() {
        verifySectionOpen("Opportunity Information");
        JavaScriptHelper.scrollElementIntoView(changeOppOwnerButton);
        SeleniumTest.click(changeOppOwnerButton);
    }

    // Opportunity "determine platform" button
    @FindBy(how = How.NAME, using = "determine_platform")
    private static WebElement determinePlatformButton;

    /**
     * Click on "Determine Platform" button
     */
    public static void clickDeterminePlatformButton() {
        JavaScriptHelper.scrollElementIntoView(determinePlatformButton);
        SeleniumTest.click(determinePlatformButton);
    }

    // "new quote" button
    @FindBy(how = How.NAME, using = "new_quote")
    private static WebElement newQuoteButton;

    /**
     * Click on the "New Quote" button to initiate creating a new quote
     */
    public static void clickNewQuoteButton() {
        // Surprise, this opens a new browser tab
        JavaScriptHelper.scrollElementIntoView(newQuoteButton);
        WindowManagement.clickElementToOpenNewWindow(
                newQuoteButton,
                2,
                false
        );
    }

    // "Credentialing Account Status"
    @FindBy(how = How.XPATH, using = "//div[@id='00N3600000P0ESY_ileinner']")
    private static WebElement credAccountStatus;

    /**
     * Get current setting of "Credentialing Account Status"
     * @return the status, trimmed of spaces
     */
    public static String getCredentialingAccountStatus(){
        String status = credAccountStatus.getText();
        return status.trim();
    }

    /**
     * Click on "edit" button corresponding to first entry in Credentialing Form list
     */
    public static void clickFirstCredFormEditButton() {
        // "Edit" button on first "Credentialing Form" entry

        // find "Credentialing Forms" section by looking for
        // "h3" element with text "Credentialing Forms"
        String xPathH3 = "//h3[contains(text(), 'Credentialing Forms')]";
        WebElement header = Driver.getDriver().findElement(By.xpath(xPathH3));

        // pull the id from this element, and change it to id used by form table
        // by changing "title" to "body"
        String idH3 = header.getAttribute("id");
        String idForms = idH3.replace("title", "body");

        // construct xpath to button using new id
        String xPathButtonTmp = "//div[@id='FORM_ID']/table/tbody/tr[2]/td[1]/a[1]";
        String xPathButton = xPathButtonTmp.replace("FORM_ID", idForms);

        // find button, and click it
        WebElement button = Driver.getDriver().findElement(By.xpath(xPathButton));
        JavaScriptHelper.scrollElementIntoView(button);
        SeleniumTest.click(button);
    }
}
