package Sites.Salesforce.Opportunities;

/**
 * Created by WBoyde on 2/3/2017.
 */
public class FieldInfo {
    /**
     * These map field names to field ids in Salesforce - Opportunity page
     *
     * Note: These class members represent named data fields on Salesforce web pages, and typically
     * map directly to "custom" fields.  As such, it would cause confusion for them to be "all
     * uppercase" - and so, I will declare them as "Non-constant fields" (as opposed to
     * "Constants") per the "Google Java Style Guide"
     * https://google.github.io/styleguide/javaguide.html
     *
     * For more information regarding Salesforce fields on this page, see:
     * https://cs26.salesforce.com/p/setup/layout/LayoutFieldList?type=Opportunity&setupid=OpportunityFields&retURL=%2Fui%2Fsetup%2FSetup%3Fsetupid%3DOpportunity
     */
    public String Estimated_Annual_Value__c = "00N3600000P0ESp";
    public String New_Account_Start_Date__c = "00N3600000P0ETk";
    public String First_Appointment_Date__c = "00N3600000P0ESy";
    public String Contract_Executed__c = "00N3600000P0ESL";
    public String Estimated_Net_Amount__c = "00N3600000P0ESr";
    public String One_Time_Revenue__c = "00N3600000P0ETp";
    public String Competitor__c = "00N3600000P0ESD";
    public String Platform__c = "00N3600000P0EUD";
    public String Lead_Source_Detail__c = "00N3600000P0ETX";
    public String Estimated_Yearly_File_Volume__c = "00N3600000P0ESs";
    public String BriefStatus_LastContact__c = "00N3600000P0ES8";
    public String Processed__c = "00N3600000P0EUP";
    public String Reasons_Won__c = "00N3600000P0EUX";
    public String Loser_Was__c = "00N3600000P0ETZ";
    public String Primary_Contact__c = "CF00N3600000P0EUJ";

    public String Opportunity_Name = "opp3";
    public String Close_Date = "opp9";
    public String Stage = "opp11";
    public String Lead_Source = "opp6";
    public String Alliance_Partner_Name = "00N3600000P0ETX";
    public String Type = "opp5";
    public String Opportunity_Currency = "opp16";
    public String Incumbent_Provider = "00N3600000P0ESc";
}
