package Sites.Salesforce.Opportunities;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Credentialing Form Edit Page for the Salesforce website
 * Created by WBoyde on 2/15/2017.
 */
public class CredentialingFormEditPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), CredentialingFormEditPage.class);
    }

    // Page elements

    // "Save" button
    @FindBy(how = How.NAME, using = "save")
    private static WebElement saveButton;

    /**
     * Click on the "Save" button
     */
    public static void clickSaveButton() {
        JavaScriptHelper.scrollElementIntoView(saveButton);
        SeleniumTest.click(saveButton);
    }

    // "Credentialing Account Name" textbox
    @FindBy(how = How.ID, using = "CF00N3600000P0Dd5")
    private static WebElement credentialingAccountNameTextbox;

    // "Credentialing Account Status" dropdown
    @FindBy(how = How.ID, using = "00N3600000P0E6M")
    private static WebElement credentialingAccountStatusDropdown;

    // "Currency" dropdown
    @FindBy(how = How.ID, using = "CurrencyIsoCode")
    private static WebElement credCurrency;

    /**
     * Set value in "Credentialing Account Name" textbox
     *
     * @param value value to set it to
     */
    public static void setCredentialingAccountName(String value) {
        SeleniumTest.clearAndSetText(credentialingAccountNameTextbox, value);
    }

    /**
     * Set value in "Credentialing Account Status" dropdown
     *
     * @param value value to set it to (must be one of allowed values)
     */
    public static void setCredentialingAccountStatus(String value) {
        SeleniumTest.selectByValueFromDropDown(credentialingAccountStatusDropdown, value);
    }

    /**
     * Set value in "Currency" dropdown
     *
     * @param value value to set it to (must be one of allowed values)
     */
    public static void setCredCurrency(String value) {
        SeleniumTest.selectByValueFromDropDown(credCurrency, value);
    }
}
