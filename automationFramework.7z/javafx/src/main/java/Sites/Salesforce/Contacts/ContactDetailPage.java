package Sites.Salesforce.Contacts;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents a Contact page for a specific Salesforce contact
 * Created by WBoyde on 2/3/2017.
 */
public class ContactDetailPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), ContactDetailPage.class);
    }

    // Contact Name
    @FindBy(how = How.CLASS_NAME, using = "topName")
    private static WebElement contactName;

    /**
     * Retrieve Contact name from page
     * @return name of Contact
     */
    public static String getContactName() {
        return contactName.getText();
    }

    // "create new opportunity" button
    @FindBy(how = How.NAME, using = "newOpp")
    private static WebElement newOpportunityButton;

    /**
     * Click on the "New Opportunity" button to initiate creating a new Opportunity
     */
    public static void clickNewOpportunityButton() {
        JavaScriptHelper.scrollElementIntoView(newOpportunityButton);
        SeleniumTest.click(newOpportunityButton);
    }
}
