package Sites.Salesforce.Contacts;

import Sites.Salesforce.Shared.RecordEditPageBase;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Create New Contact page for the Salesforce website
 * Created by WBoyde on 2/3/2017.
 */
public class ContactEditPage extends RecordEditPageBase {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), ContactEditPage.class);
    }

    // Page elements
}
