package Sites.Salesforce.Contacts;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Contacts page for the Salesforce website
 * Created by WBoyde on 2/2/2017.
 */
public class ContactOverviewPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), ContactOverviewPage.class);
    }

    // Page elements
    // "New" button
    @FindBy(how = How.NAME, using = "new")
    private static WebElement newContactButton;

    /**
     * Click on the "New" button to initiate creating a new contact
     */
    public static void clickNewContactButton() {
        JavaScriptHelper.scrollElementIntoView(newContactButton);
        SeleniumTest.click(newContactButton);
    }
}
