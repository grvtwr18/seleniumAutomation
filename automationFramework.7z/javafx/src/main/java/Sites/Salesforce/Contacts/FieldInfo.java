package Sites.Salesforce.Contacts;

/**
 * Created by WBoyde on 2/3/2017.
 */
public class FieldInfo {
    /**
     * These map field names to field ids in Salesforce - Contact page
     *
     * Note: These class members represent named data fields on Salesforce web pages, and typically
     * map directly to "custom" fields.  As such, it would cause confusion for them to be "all
     * uppercase" - and so, I will declare them as "Non-constant fields" (as opposed to
     * "Constants") per the "Google Java Style Guide"
     * https://google.github.io/styleguide/javaguide.html
     *
     * For more information regarding Salesforce fields on this page, see:
     * https://cs26.salesforce.com/p/setup/layout/LayoutFieldList?type=Contact&setupid=ContactFields
     */
    public String Contact_Type__c = "00N3600000P0E1W";
    public String Contact_Status__c = "00N3600000P0E1U";
    public String Role__c = "00N3600000P0E3b";
    public String AM_Primary_Contact__c = "00N3600000P0E0n";
    public String Sales_Primary_Contact__c = "00N3600000P0E3k";
    public String Billing_Primary_Contact__c  = "00N3600000P0E14";
    public String Decision_Maker__c = "00N3600000P0E1r";

    public String Phone = "con10";
    public String Mobile = "con12";
    public String Fax = "con11";
    public String Email = "con15";
    public String Title = "con5";
    public String Mailing_Street = "con19street";
    public String Mailing_City = "con19city";
    public String Mailing_Zip = "con19zip";
}
