package Sites.Salesforce;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by Vivek.Rai on 10/24/2018.
 */
public class RecordsPage {

    @FindBy(how = How.XPATH, using = "//a[@href='/001m000000bhRrO?srPos=0&srKp=001']")
    private static WebElement accountNameLink;

    static {
        PageFactory.initElements(Driver.getDriver(),RecordsPage.class);
    }

    public static void clickAccountNameLink(){
        SeleniumTest.click(accountNameLink);
    }
}
