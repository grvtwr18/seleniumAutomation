package Sites.Salesforce.Search;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Page object that represents the search results page for the Salesforce website
 * Created by WBoyde on 2/7/2017.
 */
public class SearchResultsPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), SearchResultsPage.class);
    }

    /**
     * Scan search results for specific Account name, then open it
     *
     * @param accountName name to look for
     * @return true if found it, false otherwise
     */
    public static boolean selectAccountResultByName(String accountName) {
        String xPath = "//*[@id='Account_body']/table/tbody//th[contains(@class,'dataCell')]/a";
        return selectObjectByName(accountName, xPath);
    }

    /**
     * Scan search results for specific Contact name, then open it
     *
     * @param contactName name to look for
     * @return true if found it, false otherwise
     */
    public static boolean selectContactResultByName(String contactName) {
        String xPath = "//*[@id='Contact_body']/table/tbody//th[contains(@class,'dataCell')]/a";
        return selectObjectByName(contactName, xPath);
    }

    /**
     * Scan search results for specific Opportunity name, then open it
     *
     * @param oppName name to look for
     * @\return true if found it, false otherwise
     */
    public static boolean selectOppResultByName(String oppName) {
        String xPath = "//*[@id='Opportunity_body']/table/tbody//th[contains(@class,'dataCell')]/a";
        return selectObjectByName(oppName, xPath);
    }

    /**
     * Private helper method to generically search for items
     *
     * @param itemName
     * @param xpath
     * @return
     */
    private static boolean selectObjectByName(String itemName, String xpath) {
        // gather list of elements at location pointed to by Xpath
        List<WebElement> elems = Driver.getDriver().findElements(By.xpath(xpath));

        // iterate through list, looking for exact match with target item
        for (WebElement e : elems) {
            // if we find it, click on it . . .
            if (e.getText().equals(itemName))
            {
                SeleniumTest.click(e);
                return true;
            }
        }

        // could not find target item in list
        return false;
    }
}
