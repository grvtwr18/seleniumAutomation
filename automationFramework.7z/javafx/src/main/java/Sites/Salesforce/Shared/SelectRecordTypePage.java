package Sites.Salesforce.Shared;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents a generic "Select Record Type" page for the Salesforce website
 * Created by WBoyde on 3/1/2017.
 */
public class SelectRecordTypePage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), SelectRecordTypePage.class);
    }

    // Page elements
    // Dropdown select list for "Record Type"
    @FindBy(how = How.NAME, using = "p3")
    private static WebElement recordTypeSelect;

    // "Continue" button
    @FindBy(how = How.XPATH, using = "//input[@class='btn' and @value='Continue']")
    private static WebElement continueButton;

    /**
     * Set the record type to specified value and click the "Continue" button
     * to continue with process of creating a new record
     */
    public static void chooseRecordTypeAndContinue(String recordType) {
        // set value in dropdown
        SeleniumTest.selectByVisibleTextFromDropDown(recordTypeSelect, recordType);

        // click on "Continue" button
        JavaScriptHelper.scrollElementIntoView(continueButton);
        SeleniumTest.click(continueButton);
    }
}
