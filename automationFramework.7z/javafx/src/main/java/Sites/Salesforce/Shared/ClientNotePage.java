package Sites.Salesforce.Shared;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by WBoyde on 3/1/2017.
 */
public class ClientNotePage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), ClientNotePage.class);
    }

    // Page elements

    // Client note name
    @FindBy(how = How.NAME, using = "Name")
    private static WebElement clientNoteNameTextBox;

    /**
     * Types the specified name into the client note name text box.
     * @param newName note name to use
     */
    public static void typeClientNoteName(String newName) {
        SeleniumTest.clearAndSetText(clientNoteNameTextBox, newName);
    }

    // "Save" button
    @FindBy(how = How.NAME, using = "save")
    private static WebElement saveButton;

    /**
     * Click on the "Save" button to create a new note
     */
    public static void clickSaveButton() {
        JavaScriptHelper.scrollElementIntoView(saveButton);
        SeleniumTest.click(saveButton);
    }
}
