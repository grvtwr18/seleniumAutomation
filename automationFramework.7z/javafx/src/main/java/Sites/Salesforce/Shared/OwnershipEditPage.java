package Sites.Salesforce.Shared;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Ownership Edit Page in Salesforce
 * Created by WBoyde on 2/8/2017.
 */
public class OwnershipEditPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), OwnershipEditPage.class);
    }

    // Page elements
    @FindBy(how = How.NAME, using = "newOwn_mlktp")
    private static WebElement newOwnerSelect;

    @FindBy(how = How.NAME, using = "newOwn")
    private static WebElement newOwnerTextBox;

    @FindBy(how = How.NAME, using = "save")
    private static WebElement saveButton;

    /**
     * Types the specified name into the new owner text box.
     * @param newOwner username to use
     */
    public static void typeOwnerName(String newOwner) {
        SeleniumTest.clearAndSetText(newOwnerTextBox, newOwner);
    }

    /**
     * Click on "save" button
     */
    public static void clickSaveButton() {
        JavaScriptHelper.scrollElementIntoView(saveButton);
        SeleniumTest.click(saveButton);
    }
}
