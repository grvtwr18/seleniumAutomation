package Sites.Salesforce.Shared;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * This is the base class for the "Edit xxx Record Pages" in Salesforce, containing common methods
 * Created by WBoyde on 2/21/2017.
 */
public class RecordEditPageBase {

    // "Save" button
    @FindBy(how = How.NAME, using = "save")
    private static WebElement saveButton;

    /**
     * Click on the "Save" button to create a new account
     */
    public static void clickSaveButton() {
        JavaScriptHelper.scrollElementIntoView(saveButton);
        SeleniumTest.click(saveButton);
        SeleniumTest.waitForPageLoadToComplete();
    }

    // error message string
    @FindBy(how = How.ID, using = "errorDiv_ep")
    private static WebElement errorText;

    /**
     * Retrieve the error message text from the page
     * @return error text
     */
    public static String getErrorMsg() {
        return (errorText.getText());
    }

    /**
     * Sets the value in a text field identified by element ID
     *
     * @param id id of page element to set
     * @param value value to set it to
     */
    public void setFieldById(String id, String value) {
        WebElement elem = SeleniumTest.waitForElementVisible(By.id(id));
        JavaScriptHelper.scrollElementIntoView(elem);
        SeleniumTest.clearAndSetText(elem, value);
    }

    /**
     * Sets the value in a dropdown field identified by element ID
     * Note: Value must exist as one of the options
     *
     * @param id id of page element to set
     * @param value value to set it to
     */
    public void setDropdownById(String id, String value) {
        WebElement elem = SeleniumTest.waitForElementVisible(By.id(id));
        JavaScriptHelper.scrollElementIntoView(elem);
        SeleniumTest.selectByValueFromDropDown(elem, value);
    }

    /**
     * Sets the value in a checkbox field identified by element ID
     *
     * @param id id of page element to set
     * @param bChecked true to make it checked, false for unchecked
     */
    public void setCheckboxById(String id, boolean bChecked) {
        WebElement elem = SeleniumTest.waitForElementVisible(By.id(id));
        JavaScriptHelper.scrollElementIntoView(elem);

        if (bChecked)
            SeleniumTest.check(elem);
        else
            SeleniumTest.unCheck(elem);
    }
}
