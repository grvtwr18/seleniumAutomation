package Sites.Salesforce;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.NoSuchElementException;
import java.net.UnknownHostException;

/**
 * Page object that represents the login page for the Salesforce website (Ex. "https://test.salesforce.com/").
 * Created by WBoyde on 1/23/2017.
 */
public class LoginPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), LoginPage.class);
    }

    // private class variables
    // TODO move this to Sites.URL/Sites.Site ?
    private static String login_url = "https://test.salesforce.com/";
    private static String login_Url_PVT = "https://login.salesforce.com/";
    // Pre determined element locators
    @FindBy(how = How.ID, using = "username")
    private static WebElement usernameTextBox;

    @FindBy(how = How.ID, using = "password")
    private static WebElement passwordTextBox;

    @FindBy(how = How.ID, using = "Login")
    private static WebElement loginButton;

    @FindBy(how = How.CSS, using = "#globalHeaderNameMink > span:nth-child(2)")
    private static WebElement loggedinUsername;

    @FindBy(how = How.CSS, using = "#globalHeaderNameMink > b:nth-child(1)")
    private static WebElement globalHeaderNameDropdown;

    @FindBy(how = How.XPATH, using = "//div[@class='globalHeaderNameMenuContainer']//a[@title='Logout']")
    private static WebElement logoutLink;

    @FindBy(how = How.CSS, using = "#tls_close")
    private static WebElement tlsClose;

    // region Public Accessor methods

    /**
     * Types the specified username into the username text box.
     * @param username username to use
     */
    public static void typeUsername(String username) {
        SeleniumTest.clearAndSetText(usernameTextBox, username);
    }

    /**
     * Types the specified password into the password text box.
     * @param password The password to be typed
     */
    public static void typePassword(String password) {
        SeleniumTest.clearAndSetText(passwordTextBox, password);
    }

    /**
     * Clicks on the "Log In to Sandbox" button to initiate logon
     */
    public static void clickLoginButton() {
        loginButton.click();
    }

    /**
     * Queries and returns the name of the currently logged on user
     */
    public static String getLoggedInUsername(){
        return loggedinUsername.getText();
    }

    /**
     * Logs out the current user by opening the menu and clicking the "Logout" link
     */
    public static void logOut(){
        globalHeaderNameDropdown.click();
        logoutLink.click();
    }

    /**
     * Attempts to sign in the user with valid credentials. The provided credentials
     * must be ones that would result in a successful sign in attempt.
     * @param username The username to be typed
     * @param password The password to be typed
     * @return A new dashboard page object
     */
    private void signInAs(String username, String password) {
        typeUsername(username);
        typePassword(password);
        clickLoginButton();
    }

    /** Conditionally clicks through the TLS warning message on a page. */
    private static void conditionalClickThroughTLSMessage() {
        // If the new Window has a TLS warning container - click through it
        try {
            if (tlsClose.isDisplayed())
                tlsClose.click();
        }
        catch (NoSuchElementException e) {
        }
    }

    /**
     * Utility method to automate the process of getting to the login page.
     * @return A new login page object
     */
    private static LoginPage navigateTo() {
        Driver.getDriver().get(login_url);
        SeleniumTest.conditionalClickThroughCertMessage();
        return PageFactory.initElements(Driver.getDriver(), LoginPage.class);
    }

    /**
     * Logs into the customer Dashboard using AccountType.CUSTOMER_ACCOUNT
     * @param userName email to use for login
     * @param userPassword password to use for login
     */
    public static void navigateToAndLogin(String userName, String userPassword) {

        // attempt to load the page
        LoginPage theLoginPage = LoginPage.navigateTo();

        // sign in as the specified user
        theLoginPage.signInAs(userName, userPassword);

        // TODO decide if really need this and if so, make it faster
        // there may be a warning message about TLS - deal with it
        //conditionalClickThroughTLSMessage();
    }

    /**
     * Attempts to sign in the user with valid credentials. The provided credentials
     * must be ones that would result in a successful sign in attempt.
     * @param username The username to be typed
     * @param password The password to be typed
     * @return A new dashboard page object
     */
    private void signInAs_PVT(String username, String password) {
        typeUsername(username);
        typePassword(password);
        clickLoginButton();
    }

    /**
     * Utility method to automate the process of getting to the login page.
     * @return A new login page object
     */
    private LoginPage navigateToSF_PVT() {
        Driver.getDriver().get(login_Url_PVT);
        SeleniumTest.conditionalClickThroughCertMessage();
        return PageFactory.initElements(Driver.getDriver(), LoginPage.class);
    }


    /**
     * Logs into the customer Dashboard using AccountType.CUSTOMER_ACCOUNT
     * @param userName email to use for login
     * @param userPassword password to use for login
     */
    public void navigateToAndLogin_PVT(String userName, String userPassword) {
        // attempt to load the page
        this.navigateToSF_PVT();
        // sign in as the specified user
        this.signInAs_PVT(userName, userPassword);
        // TODO decide if really need this and if so, make it faster
        // there may be a warning message about TLS - deal with it
        //conditionalClickThroughTLSMessage();
    }
}
