package Sites.Salesforce;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Page object that represents the navigation tabs header on Salesforce web pages
 * Created by WBoyde on 2/2/2017.
 */
public class NavHeader {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), NavHeader.class);
    }

    // TODO currently only fully supports: Contacts / Accounts / Opportunities
    // TODO need to implement: Home / Leads / Cases / Reports / etc

    // Page elements
    @FindBy(how = How.ID, using = "home_Tab")
    private static WebElement homeTabButton;

    @FindBy(how = How.ID, using = "AllTab_Tab")
    private static WebElement allTabButton;

    @FindBy(how = How.ID, using = "phSearchInput")
    private static WebElement searchInputTextBox;

    @FindBy(how = How.ID, using = "phSearchButton")
    private static WebElement searchButton;

    // search mechanism - enter text in entry field
    private static void typeSearchText(String searchText) {
        SeleniumTest.clearAndSetText(searchInputTextBox, searchText);
    }

    // search mechanism - click on search button
    private static void clickSearchButton() {
        JavaScriptHelper.scrollElementIntoView(searchButton);
        SeleniumTest.click(searchButton);
    }

    /**
     * Initiate search for specifeid input
     *
     * @param searchInput text to enter into search bar
     */
    public static void searchFor(String searchInput) {
        typeSearchText(searchInput);
        clickSearchButton();
    }

    public static void clickHomeTab() {
        JavaScriptHelper.scrollElementIntoView(homeTabButton);
        SeleniumTest.click(homeTabButton);
    }

    public static void clickContactsTab() {
        clickTabByName("Contacts");
    }

    public static void clickAccountsTab() {
        clickTabByName("Accounts");
    }

    public static void clickLeadsTab() {
        clickTabByName("Leads");
    }

    public static void clickOpportunitiesTab() {
        clickTabByName("Opportunities");
    }

    public static void clickCasesTab() {
        clickTabByName("Cases");
    }

    public static void clickReportsTab() {
        clickTabByName("Reports");
    }

    public static void clickQuotesTab() {
        clickTabByName("Quotes");
    }

    // open "All Tabs" page, then click on link for requested tab
    // TODO what if it is not found? findElement will throw exception
    private static void clickTabByName(String tabText) {
        // click on button to display page showing all tabs
        JavaScriptHelper.scrollElementIntoView(allTabButton);
        SeleniumTest.click(allTabButton);

        // look for link on this page that matches what we are looking for
        String xpath = String.format("//a//img[@title='%s']", tabText);
        WebElement elem = Driver.getDriver().findElement(By.xpath(xpath));
        JavaScriptHelper.scrollElementIntoView(elem);
        SeleniumTest.click(elem);
    }

    /**
     * Query current page title.
     *
     * @return current page title
     */
    public static String getPageTitle() {
        return (Driver.getDriver().getTitle());
    }

    @FindBy(how = How.ID, using = "tryLexDialogX")
    private static WebElement btnLightningexpPopUpcqancel;

    public static void searchOppByName(String name) {
        WebElement lnkOppNameWE = Driver.getDriver().findElement(By.xpath("(//div[@id='Opportunity']//tr[contains(@class,'dataRow')]//a[normalize-space()='" + name + "'])[1]"));
        JavaScriptHelper.scrollElementIntoView(lnkOppNameWE);
        SeleniumTest.click(lnkOppNameWE);
    }
    // click cancel button on Lightning pop up
    public static void clickLightningexpPopUp() {
        if (btnLightningexpPopUpcqancel.isDisplayed()) {
            SeleniumTest.waitForElementVisible(btnLightningexpPopUpcqancel);
            JavaScriptHelper.click(btnLightningexpPopUpcqancel);
        }
    }

}
