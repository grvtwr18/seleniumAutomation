package Sites.Salesforce.Accounts;

/**
 * Created by WBoyde on 2/3/2017.
 */
public class FieldInfo {

    /**
     * These map field names to field ids in Salesforce - Account page
     *
     * Note: These class members represent named data fields on Salesforce web pages, and typically
     * map directly to "custom" fields.  As such, it would cause confusion for them to be "all
     * uppercase" - and so, I will declare them as "Non-constant fields" (as opposed to
     * "Constants") per the "Google Java Style Guide"
     * https://google.github.io/styleguide/javaguide.html
     *
     * For more information regarding Salesforce fields on this page, see:
     * https://cs26.salesforce.com/p/setup/layout/LayoutFieldList?type=Account&setupid=AccountFields&retURL=%2Fui%2Fsetup%2FSetup%3Fsetupid%3DAccount
     */
    public String Integration_Partner__c = "00N3600000P0DfW";
    public String Account_Legal_Name__c = "00N3600000P0DdW";
    public String Employee_Range_2__c = "00N3600000P0Df4";
    public String Permissible_Purpose__c = "00N3600000P0DgP";
    public String How_many_applications_per_month__c = "00N3600000P0DfQ";
    public String Applicant_Tracking_System__c = "00N3600000P0Ddt";
    public String Client_Services_Support_Level__c = "00N3600000P0DeJ";
    public String Current_Platform__c = "00N3600000P0DeX";
    public String Legacy_Platform__c = "00N3600000P0Dfh";
    public String Brand__c = "00N3600000P0De9";
    public String POD_Name__c = "00N3600000P0DgG";
    public String TalentWise_UID__c = "00N3600000P0Dhi";
    public String Salesperson__c = "CF00N3600000P0DhV";
    public String Territory_Type__c = "00N3600000P0Dhj";
    public String Account_Manager_User__c = "CF00N3600000P0DdZ";
    public String Relationship_Type__c = "00N3600000P0Dgc";
    public String Lead_Source_from_Oppty__c = "00N3600000P0Dfg";
    public String Parent_Admin_Account__c = "CF00N3600000P0DgL";
    public String Billing_Contact_Lookup__c = "CF00N3600000P0De1";
    public String Priced_Currency__c = "00N3600000SdZCw";
    public String Revenue_Market__c = "00N3600000P0Dgq";

    public String Invoice_Language = "00N3600000P0Dfb";
    public String Billing_Currency = "00N3600000P0De3";
    public String Account_Currency = "acc24";

    public String Account_Name = "acc2";
    public String Industry = "acc7";
    public String Phone = "acc10";
    public String Type = "acc6";
    public String Ownership = "acc14";
    public String Website = "acc12";
    public String Employees = "acc15";

    public String Shipping_Street = "acc18street";
    public String Shipping_City = "acc18city";
    public String Shipping_State = "acc18state";
    public String Shipping_Zip = "acc18zip";
    public String Shipping_Country = "acc18country";

    public String Billing_Street = "acc17street";
    public String Billing_City = "acc17city";
    public String Billing_State = "acc17state";
    public String Billing_Zip = "acc17zip";
    public String Billing_Country = "acc17country";
}
