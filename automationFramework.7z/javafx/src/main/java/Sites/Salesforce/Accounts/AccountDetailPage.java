package Sites.Salesforce.Accounts;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents an Account page for a specific Salesforce account
 * Created by WBoyde on 2/3/2017.
 */
public class AccountDetailPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), AccountDetailPage.class);
    }

    // Account Name
    @FindBy(how = How.CLASS_NAME, using = "topName")
    private static WebElement accountName;

    /**
     * Retrieve Account name from page
     * @return name of account
     */
    public static String getAccountName() {
        return accountName.getText();
    }

    // "create new contact" button
    @FindBy(how = How.NAME, using = "newContact")
    private static WebElement newContactButton;

    /**
     * Click on the "New Contact" button to initiate creating a new contact
     */
    public static void clickNewContactButton() {
        JavaScriptHelper.scrollElementIntoView(newContactButton);
        SeleniumTest.click(newContactButton);
    }

    // "edit" button
    @FindBy(how = How.NAME, using = "edit")
    private static WebElement editButton;

    /**
     * Click on "Edit" button to put record into edit mode
     */
    public static void clickEditButton() {
        JavaScriptHelper.scrollElementIntoView(editButton);
        SeleniumTest.click(editButton);
    }

    // Account owner "change" button
    @FindBy(how = How.XPATH, using = "//div[@id='acc1_ileinner']//a[contains(text(),'Change')]")
    private static WebElement changeAccountOwnerButton;

    /**
     * Click on "Change Account Owner" button
     */
    public static void clickChangeAccountOwnerButton() {
        JavaScriptHelper.scrollElementIntoView(changeAccountOwnerButton);
        SeleniumTest.click(changeAccountOwnerButton);
    }

    // Client Notes - "new" note button
    @FindBy(how = How.XPATH, using = "//input[@value='New Client Note']")
    private static WebElement newClientNoteButton;
    public static void clickNewClientNoteButton() {
        JavaScriptHelper.scrollElementIntoView(newClientNoteButton);
        SeleniumTest.click(newClientNoteButton);
    }
}
