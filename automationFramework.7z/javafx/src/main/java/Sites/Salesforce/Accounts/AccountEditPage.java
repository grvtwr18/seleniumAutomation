package Sites.Salesforce.Accounts;

import Sites.Salesforce.Shared.RecordEditPageBase;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Create New Account page for the Salesforce website
 * Created by WBoyde on 2/2/2017.
 */
public class AccountEditPage extends RecordEditPageBase {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), AccountEditPage.class);
    }

    // Page elements
}
