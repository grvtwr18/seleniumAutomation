package Sites.Salesforce.Accounts;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Accounts overview page for the Salesforce website
 * Created by WBoyde on 2/2/2017.
 */
public class AccountOverviewPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), AccountOverviewPage.class);
    }

    // Page elements
    // "New" button
    @FindBy(how = How.NAME, using = "new")
    private static WebElement newAccountButton;

    /**
     * Click on the "New" button to initiate creating a new account
     */
    public static void clickNewAccountButton() {
        JavaScriptHelper.scrollElementIntoView(newAccountButton);
        SeleniumTest.click(newAccountButton);
    }
}
