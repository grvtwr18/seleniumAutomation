package Sites.Salesforce.Quotes;

import TWFramework.JavaScriptHelper;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;

/**
 * Page object that represents the Quote Line Editor page for the Salesforce website
 * Created by WBoyde on 2/10/2017.
 */
public class LineEditerPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), LineEditerPage.class);
    }

    @FindBy(how = How.XPATH,using = "//*[@name='Save']//paper-button")
    private static WebElement saveBtn;
    /**
     * Click on "Save" button
     */
    public static void clickSaveButton() {
        SeleniumTest.click(saveBtn);
    }

    // "Add Group" button
    @FindBy(how = How.XPATH, using = "//li[contains(@class,'addGroupBtn')]")
    private static WebElement addGroupButton;

    // click on "Add Group" button
    public static void clickAddGroupButton() {
        SeleniumTest.click(addGroupButton);
    }

    @FindBy(how = How.XPATH,using = "//paper-button[contains(@class,'sb-pricebook-dialog')]")
    private static WebElement savePriceBookBtn;
    /**
     * Click on "Save" button in "Choose Price Book" dialog
     */
    public static void clickSavePriceBookButton() {
        SeleniumTest.waitForElementToBeClickable(savePriceBookBtn,10);
        JavaScriptHelper.click(savePriceBookBtn);
    }


    @FindBy(how = How.XPATH,using = "//sb-select[@id='select']/select")
    private static WebElement choosePriceBookDropDown;
    /**
     * Select item in Price Book dropdown
     * @param value
     */
    public static void setPriceBookSelect(String value) {
        SeleniumTest.selectByValueFromDropDown(choosePriceBookDropDown,value);
    }

    /**
     * Helper used to wait for a specified select element to be visible, then set it's value
     * @param jsControl
     * @param value
     */
    private static void waitForSelectThenSetValue(String jsControl, String value) {
        SeleniumTest.waitForPageLoadToComplete();

        // wait for control to really be loaded
        WaitUntil.waitUntil(300, 2, () -> isControlAvailable(jsControl) );

        // build js code to set the value in the select element
        String script = String.format("%s.value='%s'", jsControl, value);
        runJavascript(script);

        SeleniumTest.waitForPageLoadToComplete();
    }

    @FindBy(how = How.XPATH,using = "//sb-custom-action[@name='Add Products']//paper-menu-button//paper-button")
    private static WebElement addProductToggleButton;
    /**
     * Click on "Add Products" toggle button
     */
    public static void clickAddProductToggleButton() {
        SeleniumTest.waitForElementToBeClickable(addProductToggleButton);
        SeleniumTest.click(addProductToggleButton);
    }

    /**
     * Helper used to wait for a specified control to be visible, then click it
     * @param jsControl
     */
    private static void waitForButtonThenClickIt(String jsControl) {
        SeleniumTest.waitForPageLoadToComplete();

        // wait for control to really be loaded
        WaitUntil.waitUntil(300, 2, () -> isControlAvailable(jsControl) );

        // build js code to click the button
        String script = String.format("%s.click()", jsControl);
        runJavascript(script);

        SeleniumTest.waitForPageLoadToComplete();
    }

    /**
     * Helper used by WaitUntil to confirm that button is available
     * @param jsControl
     * @return
     */
    private static boolean isControlAvailable(String jsControl) {
        // build javascript to check access to control
        String script = String.format("return %s", jsControl);

        // try to get the control
        WebElement button = (WebElement)runJavascript(script);

        // return true if we found it
        return (button == null ? false : true);
    }

    /**
     * Helper to run javascript code, handle exceptions,
     * and allow being able to edit and rerun via debugger
     * TODO clean this up whem able to make JS calls more stable
     * @param script
     * @return
     */
    private static Object runJavascript(String script) {
        // put in hook so that can run multiple times in debugger
        Object retVal = null;
        for (int i = 0; i < 1; i++) {
            try {
                retVal = JavaScriptHelper.runScript((script));
            } catch (Exception e) {
                String msg = e.getMessage();
            }
            // if failed, change script here, set i to -1, redo . . .
        }

        return retVal;
    }

    @FindBy(how = How.XPATH,using = "//sb-custom-action[@name='Add Favorites']//span")
    private static WebElement addFavoritesBtn;
    /**
     * Click on "Add Favorites" toggle button
     */
    public static void clickAddFavoritesButton() {
       SeleniumTest.waitForElementToBeClickable(addFavoritesBtn);
       SeleniumTest.click(addFavoritesBtn);
    }

    @FindBy(how = How.ID,using = "selectFavBtn")
    private static WebElement selectBtn;
    /**
     * Click the "Select" button
     */
    public static void clickSelectButton() {
       SeleniumTest.click(selectBtn);
    }

    // "Annual Volume" entry field
    @FindBy(how = How.ID, using = "Estimated_Profile_Annual_Volume__c_SYS3")
    private static WebElement annualVolumeTextBox;

    /**
     * Enter text in "Annual Volume" entry field
     * @param value
     */
    public static void typeAnnualVolumeTextBox(String value) {
        SeleniumTest.clearAndSetText(annualVolumeTextBox, value);
    }

    /**
     * Locate indicated product by name in product table, and select it
     *
     * @param desiredProduct name of product to look for (can be partial)
     */
    public static void selectProductFromTable(String desiredProduct) {
        // get count of items on web page
        int rowCount = getProductListCount();

        // go through each one
        for (int i=0; i<rowCount; i++)
        {
            // get product name from web page table
            String productName = getProductNameByRow(i);

            // if this matches our desired product, check the checkbox in the row
            if (productName.contains(desiredProduct)) {
                // check the checkbox for this row
                selectChecboxByRow(i);
            }
        }
    }
@FindBy(how = How.XPATH,using = "//div[@id='pageBody']//div[contains(@class,'tbody')]//sb-table-row")
private static List<WebElement> items;
    /**
     * Get count of products being displayed on web page
     * @return
     */
    public static int getProductListCount() {
        SeleniumTest.waitForPageLoadToComplete();
        return (items == null ? 0 : items.size());
    }

    /**
     * Query name of product on specific row in table
     * @param rowIdx
     * @return
     */
    private static String getProductNameByRow(int rowIdx) {
        return items.get(rowIdx).getText();
    }

    /**
     * Select "checkbox" in specific row by clicking on it
     * (Note: this is not your basic checkbox, so we have to do this silliness)
     * @param rowIdx
     */
    private static void selectChecboxByRow(int rowIdx) {
        String path = "//div[@id='pageBody']//div[contains(@class,'tbody')]//sb-table-row["+(rowIdx+1)+"]//div[@id='selectionContainer']/sb-group";
        System.out.println("checkbox-->"+path);
        WebElement itemCheckbox = Driver.getDriver().findElement(By.xpath(path));
        SeleniumTest.click(itemCheckbox);
        SeleniumTest.waitForPageLoadToComplete();
    }
}
