package Sites.Salesforce.Quotes;

import TWFramework.SeleniumTest;
import WebDriver.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents a Quote page for a specific Salesforce opportunity
 * Created by WBoyde on 2/10/2017.
 */
public class QuoteDetailPage {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), QuoteDetailPage.class);
    }

    // "Edit" button
    @FindBy(how = How.NAME, using = "edit")
    private static WebElement editButton;

    /**
     * Click on "Edit" button to put record into edit mode
     */
    public static void clickEditButton() {
        SeleniumTest.click(editButton);
    }
}
