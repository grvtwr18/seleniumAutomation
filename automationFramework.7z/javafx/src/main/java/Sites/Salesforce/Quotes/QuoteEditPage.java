package Sites.Salesforce.Quotes;

import Sites.Salesforce.Shared.RecordEditPageBase;
import WebDriver.Driver;
import org.openqa.selenium.support.PageFactory;

/**
 * Page object that represents the Create New Quote page for the Salesforce website
 * Created by WBoyde on 2/7/2017.
 */
public class QuoteEditPage extends RecordEditPageBase {

    // Static Constructor
    static {
        PageFactory.initElements(Driver.getDriver(), QuoteEditPage.class);
    }

    // Page elements
}
