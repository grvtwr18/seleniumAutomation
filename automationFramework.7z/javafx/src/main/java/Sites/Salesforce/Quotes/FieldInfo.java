package Sites.Salesforce.Quotes;

/**
 * Created by WBoyde on 2/9/2017.
 */
public class FieldInfo {
    /**
     * These map field names to field ids in Salesforce - Quote page
     * (also, this is "Not the standard quote object: Create > Objects > Quote" )
     *
     * Note: These class members represent named data fields on Salesforce web pages, and typically
     * map directly to "custom" fields.  As such, it would cause confusion for them to be "all
     * uppercase" - and so, I will declare them as "Non-constant fields" (as opposed to
     * "Constants") per the "Google Java Style Guide"
     * https://google.github.io/styleguide/javaguide.html
     *
     * For more information regarding Salesforce fields on this page, see:
     * https://cs26.salesforce.com/01I36000002HXHH?setupid=CustomObjects
     */
    // Opportunity (Managed) 'prepened with new for button that creates new quote
    public String  SBQQ__Opportunity2__c = "00N3600000OgL5b";
    // Method of Contract Delivery
    public String  Method_of_Contract_Delivery__c = "00N3600000P0EeR";
    // Contract Type
    public String  Contract_Type__c = "00N3600000P0EeI";
    // Primary Contact (Managed) 'prepened with CN
    public String  SBQQ__PrimaryContact__c = "CF00N3600000OgL5i";
    // Authorized Signer  'prepened with CN
    public String  Authorized_Signer__c = "CF00N3600000P0EeC";
    // Estimated Annual Volume
    public String  Estimated_Annual_Volume__c = "00N3600000P0EeL";
    // Estimated Number of New Hires Annually
    public String  Estimated_Number_of_I9s__c = "00N3600000P0EeM";
    // Primary (Managed)
    public String  SBQQ__Primary__c = "00N3600000OgL5j";
    // Status (Managed)
    public String  SBQQ__Status__c = "00N3600000OgL5v";
    public String  Quote_Currency = "CurrencyIsoCode";

    // items in Price Book dropdown
    public String  PriceBook_SterlingONE = "01s36000006TaDQAA0";
}
