package Sites;

import java.util.EnumMap;
import java.util.Map;
import org.apache.http.client.utils.URIBuilder;

public class MonolithUrlBuilder {

    private static final String DOMAIN = "talentwise.com";

    private final String environment;

    private String region;

    private int httpsPort;

    private final Map<Site, String> applicationHosts = new EnumMap<>(Site.class);

    MonolithUrlBuilder(String environment, String region, int httpsPort) {
        this.environment = environment;
        this.region = region;
        this.httpsPort = httpsPort;
    }

    public static String getDomain() {
        return DOMAIN;
    }

    void setRegion(String region) {
        this.region = region;
        applicationHosts.clear();
    }

    public String getEnvironment() {
        return environment;
    }

    public String getRegion() {
        return region;
    }

    String getApplicationHost(Site application) {
        return applicationHosts.computeIfAbsent(application, this::computeApplicationHost);
    }

    URIBuilder getApplicationUriBuilder(Site application) {
        return new URIBuilder()
                .setScheme("https")
                .setHost(getApplicationHost(application));
    }

    private String computeApplicationHost(Site application) {
        StringBuilder urlSb = new StringBuilder();
        String subdomain = application.getSubdomain();
        if (subdomain != null && !subdomain.isEmpty()) {
            urlSb.append(subdomain).append('.');
        }
        urlSb.append(environment).append('.');
        if (region != null && !region.isEmpty()) {
            urlSb.append(region).append('.');
        }
        urlSb.append(DOMAIN);
        if(httpsPort != 443) {
            urlSb.append(':').append(httpsPort);
        }
        return urlSb.toString();
    }
}
