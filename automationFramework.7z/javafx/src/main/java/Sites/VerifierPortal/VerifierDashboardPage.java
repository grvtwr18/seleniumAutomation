package Sites.VerifierPortal;

import DataBase.DbReader;
import Sites.CandidatePortal.Forms.CandidatePortalPages;
import TWFramework.SeleniumTest;
import TWFramework.WaitUntil;
import WebDriver.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;
import java.util.List;

import static WebDriver.Driver.getDriver;

/**
 * Created by abrackett on 10/27/2015.
 */
public class VerifierDashboardPage extends CandidatePortalPages {

    @FindBy(how = How.ID, using = "welcome")
    public static WebElement welcomeMessage;

    @FindBy(how = How.LINK_TEXT, using = "Sign Out")
    WebElement signOutLink;

    @FindBy(how = How.ID, using = "modalActionBtn")
    static
    WebElement reassignModalSubmitButton;

    @FindBy(how = How.ID, using = "modalCloseBtn")
    WebElement reassignModalCloseButton;

    @FindBy(how = How.ID, using = "newverifier")
    static
    WebElement reassignModalNewVerifierDropDown;

    @FindBy(how = How.XPATH, using = "//span[@id='17065-I9s1_text_2']/p[1]/a")
    private static WebElement delegateToAnotherVerifier;

    @FindBy(how = How.ID, using = "windowDialogContent")
    private static WebElement delegateMessageVerifierNotSignIn;

    @FindBy(how = How.ID, using = "windowDialog")
    WebElement reassignModalWindow;

    private static ThreadLocal<VerifierDashboardPage> threadLocalInstance;

    static {
        threadLocalInstance = ThreadLocal.withInitial(() -> PageFactory.initElements(
                WebDriver.Driver.getDriver(), VerifierDashboardPage.class));
    }

    public static VerifierDashboardPage getInstance() {
        return threadLocalInstance.get();
    }

    /**
     * Clicks on the Sign Out Link
     */
    public void SignOut() {
        signOutLink.click();
    }

    /**
     * Clicks on the appropriate "Launch Task" button and navigates to the expected page
     * @param formSetID FormSetID of the Task to launch
     * @param taskID TaskID to find on the dashboard
     * @param returnedClass The class declaration of the page you intend to have returned
     * @return The appropriate PageObject
     */
    public CandidatePortalPages clickLaunchTask(int formSetID, int taskID, Class<? extends CandidatePortalPages> returnedClass) {
        List<WebElement> listOfButtons = getDriver().findElements(By.className("button"));
        for(WebElement we : listOfButtons) {
            String onclickAttribute = we.getAttribute("onclick");
            if(onclickAttribute.contains(Integer.toString(formSetID)) && onclickAttribute.contains(Integer.toString(taskID))) {
                we.click();
                break;
            }
        }
        return PageFactory.initElements(WebDriver.Driver.getDriver(), returnedClass);
    }

    /**
     * Retrieves the latest task ID associated with the email provided
     * @param email email to use for task ID retrieval
     * @return Task ID
     */
    public int getLatestTaskID(String email) {
        DbReader dbReader = new DbReader();
        List<HashMap<String, Object>> results = dbReader.executeQuery("TalentWise", "SELECT `LoginID` FROM `Login` WHERE `EmailAddress` LIKE '" + email + "' LIMIT 0 , 1");
        HashMap<String, Object> loginID = results.get(0);
        results = null;
        results = dbReader.executeQuery(
                "TalentWise",
                "SELECT wfTask1.`WF_Task_ID` FROM `SmartFormV2_WFInstance_Tasks` wfTask1 LEFT JOIN `SmartFormV2_WFInstance_Tasks` wfTask2 ON wfTask1.`WFInstanceID` = wfTask2.`WFInstanceID` WHERE wfTask1.`LoginID` = '" +
                        loginID.get("LoginID").toString() +
                        "' ORDER BY wfTask1.`WFInstanceID` DESC LIMIT 0 , 1");
        return Integer.parseInt(results.get(0).get("WF_Task_ID").toString());
    }

    /**
     * Launches an associated task by it's report ID
     * @param reportID The reportID of the task to launch
     * @param returnedClass The page you are intending to land on
     * @return
     */
    public static CandidatePortalPages launchTaskByReportID(String reportID, Class<? extends CandidatePortalPages> returnedClass) {
        WebDriver.Driver.getDriver().findElement(By.id("launch-" + reportID)).click();
        return PageFactory.initElements(getDriver(), returnedClass);
    }

    public static void launchTaskByReportID(String reportId) {
        WebDriver.Driver.getDriver().findElement(By.id("launch-" + reportId)).click();
        SeleniumTest.waitForPageLoadToComplete();
    }

    public static boolean isTaskAvailableForLaunch() {
        return SeleniumTest.isElementVisibleNoWaiting(By.xpath("//button[starts-with(@id, 'launch-')]"));
    }

    public static void launchFirstTask() {
        SeleniumTest.click(By.xpath("//button[starts-with(@id, 'launch-')]"));
        SeleniumTest.waitMs(3000);
    }

    public static void clickReassignButton(String reportId) {
        WebDriver.Driver.getDriver().findElement(By.cssSelector("button[id$='" + reportId + "']")).click();
    }

    public static void clickReassignModalSubmitButton() {
        WaitUntil.waitUntil(() -> reassignModalSubmitButton.isDisplayed());
        getInstance().reassignModalSubmitButton.click();
    }

    public void clickReassignModalCloseButton() {
        getInstance().reassignModalCloseButton.click();
    }

    public static void clickReassignNewVerifierDropDown() {
        WaitUntil.waitUntil(() -> reassignModalNewVerifierDropDown.isDisplayed());
        getInstance().reassignModalNewVerifierDropDown.click();
    }

    public static void delegateToAnotherVerifierLink() {
        getInstance().delegateToAnotherVerifier.click();
        WaitUntil.waitUntil(() -> getInstance().delegateToAnotherVerifier.isDisplayed());
        SeleniumTest.waitMs(2000);
    }

    public static String getMessage_DelegateToAnotherVerifierLink_WhenVerifierNotSignIn() {
        return delegateMessageVerifierNotSignIn.getText();
    }

    public static void reassignTask(String reportId, String assignee) {
        Driver.getDriver().navigate().refresh();
        clickReassignButton(reportId);
        getInstance().waitUntilReassignWindowIsDisplayed();
        getInstance().clickReassignNewVerifierDropDown();
        Select s = new Select(reassignModalNewVerifierDropDown);
        s.selectByVisibleText(assignee);
        clickReassignModalSubmitButton();
    }

    public static void waitUntilReassignWindowIsDisplayed() {
        WaitUntil.waitUntil(() ->
                WebDriver.Driver.getDriver().findElement(By.id("windowDialog"))
                        .getAttribute("style").contains("display: block"));
    }

    public static void waitUntilReassignWindowIsNotDisplayed() {
        WaitUntil.waitUntil(() ->
                WebDriver.Driver.getDriver().findElement(By.id("windowDialog"))
                        .getAttribute("style").contains("display: none"));
    }

    public static String getColumnValueByReportId(String reportId, column c) {
       return WebDriver.Driver.getDriver().findElement(By.xpath("//button[contains(@id,'" +
               reportId + "')]/../parent::tr/td[" +
               c.getVal() + "]")).getText();
    }

    public static String getReassignButtonText(String reportId) {
        return WebDriver.Driver.getDriver().findElement(By.id("delegate-" + reportId)).getText();
    }

    public static String getStartButtonText(String reportId) {
        return WebDriver.Driver.getDriver().findElement(By.id("launch-" + reportId)).getText();
    }

    public static Boolean isStartButtonEnabled(String reportId) {
        return WebDriver.Driver.getDriver().findElement(By.id("launch-" + reportId)).isEnabled();
    }

    public String getCalimButtonText(String reportId) {
        return WebDriver.Driver.getDriver().findElement(By.id("unassigned-" + reportId)).getText();
    }

    public static String getWelcomeText() {
        return getInstance().welcomeMessage.getText();
    }

    public enum column {
        TASK(1, "Task"),
        CANDIDATE(2, "Candidate"),
        DUE_DATE(3, "Due Date"),
        STATUS(4, "Status");

        private int val;
        private final String text;
        column(int val, final String text) {
            this.val = val;
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
        public int getVal() {return val;}
    }
}
