package Sites.VerifierPortal;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.net.UnknownHostException;

import Sites.Site;
import Sites.URL;
import TWFramework.SeleniumTest;
import WebDriver.Driver;

/**
 * Created by abrackett on 10/27/2015.
 */
public class
VerifierLoginPage {

    private static String login_url = "/ptl/signin.php?";
    private static String sender_var = "Sender=";
    private static String email_var = "&Email=";
    private static String loginType = "&LoginType=1";

    @FindBy(how = How.NAME, using = "Email")
    private WebElement emailAddressBox;

    @FindBy(how = How.NAME, using = "Password")
    private WebElement passwordBox;

    @FindBy(how = How.LINK_TEXT, using = "Forgot your password?")
    private WebElement forgotPasswordLink;

    @FindBy(how = How.CLASS_NAME, using = "button")
    private WebElement signInButton;

    /**
     * Navigates to the Verifier portal URL using incoming parameters
     * @param portalName Verifier portal name
     * @param sender CustomerID
     * @param email verifier e-mail address
     * @return LoginPage Object
     * @throws UnknownHostException
     */
    public static VerifierLoginPage navigateTo(String portalName, int sender, String email) {
    Driver.getDriver().get(URL.getURL(Site.CANDIDATE_PORTAL) + "/" + portalName + login_url + sender_var + Integer.toString(sender) + email_var + email + loginType);
        SeleniumTest.conditionalClickThroughCertMessage();
        return PageFactory.initElements(Driver.getDriver(), VerifierLoginPage.class);
    }

    /**
     * Sets the Email Address in the Sign in box
     * @param email full e-mail address for verifier
     */
    public void setEmailAddress(String email) {
        SeleniumTest.clearAndSetText(emailAddressBox, email);
    }

    /**
     * Sets the password in the Sign in box
     * @param password password for verifier
     */
    public void setPassword(String password) {
        SeleniumTest.clearAndSetText(passwordBox, password);
    }

    /**
     * Clicks the Sign in button
     * @return DashboardPage object for the Verifier portal
     */
    public VerifierDashboardPage clickSignIn() {
        signInButton.click();
        return PageFactory.initElements(Driver.getDriver(), VerifierDashboardPage.class);
    }

    /**
     * Signs directly into the Verifier portal using parameters
     * @param portalName portalName as defined in your customer dashboard (also found in the URL to the verifier portal)
     * @param sender CustomerAccountID owning the verifier portal task (usually the main customer)
     * @param email full e-mail address for the verifier being logged in
     * @param password password for the verifier being logged in
     * @return Verifier Portal DashboardPage object
     * @throws UnknownHostException
     */
    public static VerifierDashboardPage logInToVerifierDashboard (String portalName, int sender, String email, String password) {
        VerifierLoginPage loginPage = VerifierLoginPage.navigateTo(portalName, sender, email);
        loginPage.setEmailAddress(email);
        loginPage.setPassword(password);
        return loginPage.clickSignIn();
    }
}
